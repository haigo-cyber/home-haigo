import json, os, sys, tempfile, time, urllib.request
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1])); sys.path.insert(0, str(Path(__file__).resolve().parent))
home = tempfile.mkdtemp(); os.environ["HOME"] = home
os.environ.pop("XDG_CONFIG_HOME", None); os.environ.pop("XDG_DATA_HOME", None)
import fakedrive
fake = fakedrive.Fake(); srv = fakedrive.serve(fake)
os.environ["SZ_DRIVE_API"] = "http://127.0.0.1:%d/drive/v3" % srv.server_address[1]
os.environ["SZ_DRIVE_UPLOAD"] = "http://127.0.0.1:%d/upload/drive/v3" % srv.server_address[1]
from seiffert_zeit.config import Settings
from seiffert_zeit.store import Store
from seiffert_zeit.server import App

def mk():
    s = Settings(); st = Store(s); a = App(s, st, lambda: None); a.start(); return s, st, a
def call(a, method, path, body=None, host=None):
    r = urllib.request.Request("http://127.0.0.1:%d/%s/%s" % (a.port, a.secret, path), method=method, data=json.dumps(body).encode() if body is not None else None,
                               headers={"Content-Type": "application/json", "Host": host or "127.0.0.1:%d" % a.port})
    return json.loads(urllib.request.urlopen(r).read())
def login(a):
    s = a.s; s.set(handoff_url="https://example.invalid/zeit.html", client_id="cid")
    assert a.sync.pending is None
    # Browser nicht starten: begin_login direkt nachbauen
    import webbrowser; webbrowser.open = lambda u: True
    assert a.sync.begin_login()
    st = a.sync.pending
    u = "http://127.0.0.1:%d/auth/token?state=%s&token=TESTTOKEN&expires=3599" % (a.port, st)
    assert b"Angemeldet" in urllib.request.urlopen(u).read()
    time.sleep(1.0)
def wait():
    time.sleep(0.8)

E = lambda n, u=2: {"id": "i%d" % n, "date": "2026-11-0%d" % n, "u": u, "cat": "Unterricht", "school": "EvT", "note": ""}
# --- 1. Erster Start, leer, Seite liefert Defaults
s, st, a = mk()
html = urllib.request.urlopen(a.url()).read().decode()
assert "window.SZ_LINUX" in html and "linuxHandOff" in html
assert call(a, "GET", "api/status")["drive"]["label"].startswith("anmelden")
# --- 2. Daten speichern -> Hauptdatei + Tagessicherung
d1 = {"entries": [E(2), E(3)], "free": [], "set": {"soll": 25}}
call(a, "PUT", "api/state", d1)
assert json.loads((st.main).read_text())["data"]["entries"][0]["u"] == 2
assert list(st.backups.glob("zeit-sicherung-*.json"))
# --- 3. Fremder Host und fremde Origin werden abgelehnt
try:
    call(a, "GET", "api/status", host="evil.example"); raise SystemExit("Host nicht geprueft")
except urllib.error.HTTPError as e: assert e.code == 403
try:
    urllib.request.urlopen("http://127.0.0.1:%d/falsch/api/status" % a.port); raise SystemExit("Geheimpfad nicht geprueft")
except urllib.error.HTTPError as e: assert e.code == 404
# falscher Token-Zustand
a.sync.pending = "abc"
try:
    urllib.request.urlopen("http://127.0.0.1:%d/auth/token?state=xxx&token=T&expires=1" % a.port); raise SystemExit("State nicht geprueft")
except urllib.error.HTTPError as e: assert e.code == 400
a.sync.pending = None
# --- 4. Anmeldung -> Erstsicherung nach Drive
login(a)
files = [f for f in fake.files.values() if f["name"] == "zeit-daten.json"]
assert len(files) == 1 and json.loads(files[0]["data"])["data"]["entries"][1]["id"] == "i3", fake.log
assert call(a, "GET", "api/status")["drive"]["label"] == "verbunden", call(a, "GET", "api/status")
# --- 5. Aenderung -> automatischer Abgleich (5 s) mit PATCH
d2 = {**d1, "entries": d1["entries"] + [E(4)]}
call(a, "PUT", "api/state", d2); time.sleep(6.5)
assert json.loads(files[0]["data"])["data"]["entries"][2]["id"] == "i4"
# --- 6. Drive wurde anderswo geaendert, Laptop hat Aenderung: Laptop gewinnt, Kopie entsteht
files[0]["data"] = json.dumps({"data": {"entries": [E(9)], "free": [], "set": {}}}).encode(); files[0]["mod"] = fake.now()
call(a, "PUT", "api/state", {**d2, "entries": d2["entries"] + [E(5)]}); time.sleep(6.5)
names = [f["name"] for f in fake.files.values()]
assert any(n.startswith("zeit-daten-vor-ueberschreiben-") for n in names), names
assert len(json.loads(files[0]["data"])["data"]["entries"]) == 4
# --- 7. Drive neuer, Laptop ohne offene Aenderung: Drive wird uebernommen, Seite laedt neu (seq)
seq0 = call(a, "GET", "api/status")["seq"]
files[0]["data"] = json.dumps({"data": {"entries": [E(7), E(8)], "free": [], "set": {}}}).encode(); files[0]["mod"] = fake.now()
r = call(a, "POST", "api/drive/sync"); assert r.get("ok"); wait()
assert call(a, "GET", "api/status")["seq"] == seq0 + 1
assert [e["id"] for e in st.state["entries"]] == ["i7", "i8"]
assert list(st.backups.glob("*vor-drive-uebernahme*"))
# --- 8. Neustart mit leerem Laptop: Drive-Stand wird geladen
import shutil; shutil.rmtree(st.dir)
s2 = Settings(); s2.set(drive_remote_modified="", drive_dirty=True)
st2 = Store(s2); a2 = App(s2, st2, lambda: None); a2.start(); a2.sync.drive.set_token("TESTTOKEN", 3000)
assert st2.is_empty(); a2.sync.run()
assert [e["id"] for e in st2.state["entries"]] == ["i7", "i8"]
# --- 9. Abgelaufene Anmeldung (401)
a2.sync.drive.set_token("FALSCH", 3000)
r = a2.sync.run(); assert "error" in r and not a2.sync.drive.valid()
assert a2.sync.status()["label"] == "Fehler"
# --- 10. Hauptdatei von aussen geaendert
st2.main.write_text(json.dumps({"data": {"entries": [E(1)], "free": [], "set": {}}})); os.utime(st2.main, (time.time() + 5, time.time() + 5))
assert st2.check_external() and st2.state["entries"][0]["id"] == "i1"
# --- 11. Defekte Hauptdatei -> Sicherung
st2.backup(None); st2.main.write_text("{kaputt")
st3 = Store(Settings()); assert st3.state and st3.state["entries"][0]["id"] == "i1"
log = Path(home, ".local/share/seiffert-zeit/protokoll.txt").read_text()
assert "TESTTOKEN" not in log and "FALSCH" not in log
print("ALLE TESTS BESTANDEN")
