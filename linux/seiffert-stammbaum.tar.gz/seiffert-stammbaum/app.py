#!/usr/bin/env python3
"""Seifferts Stammbaum fuer Linux.

Ein Fenster mit QtWebEngine zeigt dieselbe HTML-Datei wie die Browser-Version
(stammbaum.html, unveraendert). Dieses Programm liefert nur das nach, was ein
eingebetteter Browser nicht kann: Dateien und Ordner mit echten Pfaden,
Speichern-Dialoge, die Anmeldung bei Google Drive ueber den normalen Browser,
Drucken als PDF und die Kartenbibliothek ohne Netz.
"""
import base64
import json
import mimetypes
import os
import secrets
import shutil
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, HTTPServer

from PySide6.QtCore import (QBuffer, QByteArray, QIODevice, QObject, QStandardPaths, Qt, QTimer, QUrl,
                            Signal, Slot, QFile)
from PySide6.QtGui import QDesktopServices, QIcon, QKeySequence, QShortcut
from PySide6.QtNetwork import QLocalServer, QLocalSocket
from PySide6.QtWebChannel import QWebChannel
from PySide6.QtWebEngineCore import (QWebEnginePage, QWebEngineProfile, QWebEngineScript, QWebEngineSettings,
                                     QWebEngineUrlRequestInterceptor, QWebEngineUrlScheme,
                                     QWebEngineUrlSchemeHandler)
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWidgets import (QApplication, QDialog, QDialogButtonBox, QFileDialog, QLabel, QLineEdit,
                               QMainWindow, QMessageBox, QVBoxLayout)

APP_NAME = "seiffert-stammbaum"
TITLE = "Seifferts Stammbaum"
HERE = os.path.dirname(os.path.abspath(__file__))
SCHEME = b"stammbaum"
START_URL = "stammbaum://app/index.html"

API_ORIGIN = os.environ.get("STAMMBAUM_API_ORIGIN", "https://www.googleapis.com")


def xdg(var, default):
    return os.environ.get(var) or os.path.join(os.path.expanduser("~"), default)


CONFIG_DIR = os.path.join(xdg("XDG_CONFIG_HOME", ".config"), APP_NAME)
DATA_DIR = os.path.join(xdg("XDG_DATA_HOME", ".local/share"), APP_NAME)
LOGFILE = os.path.join(DATA_DIR, "protokoll.txt")
CACHE_DIR = os.path.join(xdg("XDG_CACHE_HOME", ".cache"), APP_NAME)
SETTINGS_FILE = os.path.join(CONFIG_DIR, "settings.json")


def plog(msg):
    """Kurzes Protokoll der Google-Zugriffe (ohne Token, ohne Dateiinhalte), nur zur Fehlersuche."""
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        if os.path.exists(LOGFILE) and os.path.getsize(LOGFILE) > 200000:
            os.replace(LOGFILE, LOGFILE + ".alt")
        with open(LOGFILE, "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + msg + "\n")
    except Exception:
        pass


# ---------------------------------------------------------------- Einstellungen
class Settings:
    """Kleine JSON-Datei: freigegebene Pfade, letzte Ordner, Drive-Zugang, Fenstergroesse."""

    def __init__(self, path=None):
        self.path = path or SETTINGS_FILE
        self.lock = threading.Lock()
        self.d = {}
        try:
            with open(self.path, encoding="utf-8") as f:
                self.d = json.load(f)
        except (OSError, ValueError):
            self.d = {}

    def get(self, key, default=None):
        return self.d.get(key, default)

    def set(self, key, value):
        with self.lock:
            self.d[key] = value
            self._save()

    def _save(self):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        tmp = self.path + ".tmp"
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(self.d, f, ensure_ascii=False, indent=1)
        os.replace(tmp, self.path)


# ---------------------------------------------------------------- Dateizugriff
def real(path):
    return os.path.realpath(os.path.expanduser(path))


def atomic_write(path, data: bytes):
    path = real(path)
    d = os.path.dirname(path)
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix="." + os.path.basename(path) + ".", suffix=".tmp", dir=d)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        if os.path.exists(path):
            try:
                shutil.copymode(path, tmp)
            except OSError:
                pass
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


class Bridge(QObject):
    """Wird per QWebChannel als window.bridge-Objekt in die Seite gereicht."""

    httpDone = Signal(int, str)
    authDone = Signal(int, str)
    _httpInternal = Signal(int, str)
    _authInternal = Signal(int, str)

    def __init__(self, window):
        super().__init__()
        self.win = window
        self.settings = window.settings
        self.pool = ThreadPoolExecutor(max_workers=6)
        self._httpInternal.connect(self.httpDone, Qt.QueuedConnection)
        self._authInternal.connect(self.authDone, Qt.QueuedConnection)
        self.auth_lock = threading.Lock()
        self.auth_cancel = None   # Ereignis der gerade wartenden Anmeldung
        self.quitting = threading.Event()
        self.token = None

    # --- Freigaben: Die Seite darf nur Pfade lesen und schreiben, die der Nutzer gewaehlt hat
    def grant(self, path):
        path = real(path)
        roots = list(self.settings.get("grants", []))
        if path not in roots:
            roots.append(path)
            self.settings.set("grants", roots)

    def allowed(self, path):
        p = real(path)
        for r in self.settings.get("grants", []):
            if p == r or p.startswith(r.rstrip("/") + "/"):
                return True
        return False

    def _startdir(self, key, hint=""):
        if hint and os.path.exists(hint):
            return hint if os.path.isdir(hint) else os.path.dirname(hint)
        last = self.settings.get("lastdir", {}).get(key or "default")
        if last and os.path.isdir(last):
            return last
        return os.path.expanduser("~")

    def _remember(self, key, path):
        m = dict(self.settings.get("lastdir", {}))
        m[key or "default"] = path if os.path.isdir(path) else os.path.dirname(path)
        self.settings.set("lastdir", m)

    # --- Auswahldialoge
    @Slot(str, result=str)
    def pickOpen(self, opts_json):
        o = json.loads(opts_json or "{}")
        test = os.environ.get("STAMMBAUM_PICK_OPEN")
        if test:
            paths = [p for p in test.split(os.pathsep) if p]
        else:
            filt = ";;".join(o.get("filters", []) + ["Alle Dateien (*)"])
            start = self._startdir(o.get("id"), o.get("startIn", ""))
            if o.get("multiple"):
                paths, _ = QFileDialog.getOpenFileNames(self.win, "Dateien wählen", start, filt)
            else:
                p, _ = QFileDialog.getOpenFileName(self.win, "Datei wählen", start, filt)
                paths = [p] if p else []
        out = []
        for p in paths:
            self.grant(p)
            out.append({"path": real(p), "name": os.path.basename(p)})
        if out:
            self._remember(o.get("id"), out[0]["path"])
        return json.dumps(out)

    @Slot(str, result=str)
    def pickSave(self, opts_json):
        o = json.loads(opts_json or "{}")
        test = os.environ.get("STAMMBAUM_PICK_SAVE")
        if test:
            p = test
        else:
            filt = ";;".join(o.get("filters", []) + ["Alle Dateien (*)"])
            start = os.path.join(self._startdir(o.get("id"), o.get("startIn", "")), o.get("suggestedName", ""))
            p, _ = QFileDialog.getSaveFileName(self.win, "Speichern unter", start, filt)
        if not p:
            return "null"
        self.grant(p)
        if not os.path.exists(p):
            atomic_write(p, b"")
        self._remember(o.get("id"), real(p))
        return json.dumps({"path": real(p), "name": os.path.basename(p)})

    @Slot(str, result=str)
    def pickDir(self, opts_json):
        o = json.loads(opts_json or "{}")
        test = os.environ.get("STAMMBAUM_PICK_DIR")
        if test:
            p = test
        else:
            p = QFileDialog.getExistingDirectory(self.win, "Ordner wählen", self._startdir(o.get("id"), o.get("startIn", "")))
        if not p:
            return "null"
        self.grant(p)
        self._remember(o.get("id"), real(p))
        return json.dumps({"path": real(p), "name": os.path.basename(real(p).rstrip("/")) or "/"})

    # --- Dateien und Ordner
    @Slot(str, result=str)
    def stat(self, path):
        if not self.allowed(path):
            return json.dumps({"exists": False, "denied": True})
        try:
            st = os.stat(real(path))
        except OSError:
            return json.dumps({"exists": False})
        return json.dumps({"exists": True, "isDir": os.path.isdir(real(path)), "size": st.st_size,
                           "mtime": int(st.st_mtime * 1000)})

    @Slot(str, result=str)
    def listDir(self, path):
        if not self.allowed(path):
            return json.dumps({"error": "Zugriff nicht freigegeben"})
        out = []
        try:
            with os.scandir(real(path)) as it:
                for e in it:
                    try:
                        out.append({"name": e.name, "kind": "directory" if e.is_dir() else "file"})
                    except OSError:
                        pass
        except OSError as ex:
            return json.dumps({"error": str(ex)})
        return json.dumps(out)

    @Slot(str, str, result=str)
    def writeFile(self, path, b64):
        if not self.allowed(path):
            return json.dumps({"error": "Schreiben in diesen Pfad ist nicht freigegeben"})
        try:
            atomic_write(path, base64.b64decode(b64 or ""))
        except OSError as ex:
            return json.dumps({"error": str(ex)})
        return json.dumps({"ok": True})

    @Slot(str, result=str)
    def makeDir(self, path):
        if not self.allowed(path):
            return json.dumps({"error": "Zugriff nicht freigegeben"})
        try:
            os.makedirs(real(path), exist_ok=True)
        except OSError as ex:
            return json.dumps({"error": str(ex)})
        return json.dumps({"ok": True})

    @Slot(str, bool, result=str)
    def removeEntry(self, path, recursive):
        if not self.allowed(path):
            return json.dumps({"error": "Zugriff nicht freigegeben"})
        try:
            p = real(path)
            if os.path.isdir(p):
                shutil.rmtree(p) if recursive else os.rmdir(p)
            else:
                os.unlink(p)
        except OSError as ex:
            return json.dumps({"error": str(ex)})
        return json.dumps({"ok": True})

    # --- Sonstiges
    @Slot(str)
    def openExternal(self, url):
        if url.startswith(("http://", "https://", "mailto:")):
            QDesktopServices.openUrl(QUrl(url))

    @Slot()
    def printPdf(self):
        self.win.print_to_pdf()

    @Slot(str)
    def log(self, msg):
        if os.environ.get("STAMMBAUM_DEBUG"):
            print("JS:", msg, flush=True)

    # --- Netzzugriff auf die Google-APIs (ohne CORS-Probleme, im Hintergrund)
    @Slot(int, str)
    def httpStart(self, rid, req_json):
        self.pool.submit(self._http_work, rid, req_json)

    def _http_work(self, rid, req_json):
        try:
            r = json.loads(req_json)
            url = r["url"]
            if not url.startswith("https://www.googleapis.com/"):
                raise ValueError("Adresse nicht erlaubt")
            url = API_ORIGIN + url[len("https://www.googleapis.com"):]
            hdr = {k: v for k, v in (r.get("headers") or {}).items() if k.lower() not in ("host", "content-length")}
            data = base64.b64decode(r["body"]) if r.get("body") else None
            req = urllib.request.Request(url, data=data, headers=hdr, method=r.get("method") or "GET")
            try:
                with urllib.request.urlopen(req, timeout=180) as resp:
                    body, status, headers = resp.read(), resp.status, dict(resp.headers)
            except urllib.error.HTTPError as e:
                body, status, headers = e.read(), e.code, dict(e.headers)
            out = {"status": status, "headers": headers, "body": base64.b64encode(body).decode()}
            path = urllib.parse.urlparse(r["url"]).path
            plog("Google %s %s -> %s (%d Bytes gesendet)%s" % (r.get("method") or "GET", path, status, len(data or b""),
                 "" if status < 400 else " Antwort: " + body[:300].decode("utf-8", "replace").replace("\n", " ")))
        except Exception as ex:  # Netzfehler an die Seite weitergeben
            out = {"error": str(ex)}
            plog("Google Netzfehler: %s" % ex)
        self._httpInternal.emit(rid, json.dumps(out))

    # --- Google-Anmeldung: Die veroeffentlichte Seite des Stammbaum-Tools meldet im normalen Browser bei Google an
    #     und reicht das Token an dieses Programm weiter (127.0.0.1, zufaelliger Anschluss, Zufallswert gegen Fremdzugriff).
    @Slot(int, str, str, str)
    def authStart(self, rid, client_id, scope, opts_json):
        self.pool.submit(self._auth_work, rid, json.loads(opts_json or "{}"))

    @Slot()
    def forgetToken(self):
        self.token = None

    def _login_url(self):
        url = os.environ.get("STAMMBAUM_LOGIN_URL") or self.settings.get("drive", {}).get("login_url")
        if url:
            return url
        box = {}
        done = threading.Event()

        def ask():
            dlg = LoginUrlDialog(self.win)
            if dlg.exec() == QDialog.Accepted:
                box["url"] = dlg.value()
            done.set()

        self.win.run_in_gui(ask)
        done.wait()
        url = box.get("url")
        if url:
            d = dict(self.settings.get("drive", {}))
            d["login_url"] = url
            self.settings.set("drive", d)
        return url

    def shutdown(self):
        """Beim Beenden: wartende Anmeldung abbrechen, damit das Programm sofort endet."""
        self.quitting.set()
        c = self.auth_cancel
        if c:
            c.set()
        self.pool.shutdown(wait=False, cancel_futures=True)

    def _auth_work(self, rid, opts):
        c = self.auth_cancel
        if c and opts.get("gesture"):
            c.set()   # ein neuer Klick ersetzt eine noch wartende Anmeldung (Browserfenster geschlossen o. ae.)
        with self.auth_lock:
            try:
                out = self._auth(opts)
            except Exception as ex:
                out = {"error": "auth_failed", "message": str(ex)}
        plog("Anmeldung: " + ("Token erhalten" if out.get("access_token") else "%s %s" % (out.get("error"), out.get("message", ""))))
        self._authInternal.emit(rid, json.dumps(out))

    def _auth(self, opts):
        if self.token and self.token[1] - 120 > time.time():
            return {"access_token": self.token[0], "expires_in": int(self.token[1] - time.time())}
        if not opts.get("gesture") and not os.environ.get("STAMMBAUM_TEST_BROWSER"):
            return {"error": "interaction_required", "message": "Bitte melde dich bei Google an (Knopf in der Drive-Anzeige)."}
        url = self._login_url()
        if not url:
            return {"error": "cancelled", "message": "Die Einrichtung von Google Drive wurde abgebrochen."}
        state = secrets.token_urlsafe(16)
        got = {}
        evt = threading.Event()
        cancel = threading.Event()

        class H(BaseHTTPRequestHandler):
            def do_GET(self):
                q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                if "access_token" in q or "error" in q:
                    ok = "access_token" in q and q.get("state", [""])[0] == state
                    if ok:
                        got.update({k: v[0] for k, v in q.items()})
                    else:
                        got["error"] = q.get("error", ["state_mismatch"])[0]
                    body = ("<html><meta charset='utf-8'><body style='font-family:sans-serif'><h2>%s</h2>"
                            "<p>Du kannst dieses Fenster schließen und zum Stammbaum zurückkehren.</p>"
                            "<script>try{history.replaceState(null,'','/')}catch(e){}</script></body></html>"
                            % ("Anmeldung erfolgreich" if ok else "Anmeldung fehlgeschlagen")).encode()
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.send_header("Content-Length", str(len(body)))
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers()
                    self.wfile.write(body)
                    evt.set()
                else:
                    self.send_response(404)
                    self.end_headers()

            def log_message(self, *a):
                pass

        srv = HTTPServer(("127.0.0.1", 0), H)
        srv.timeout = 1
        port = srv.server_address[1]
        full = url + ("&" if "?" in url else "?") + urllib.parse.urlencode({"linuxport": port, "linuxstate": state})
        if os.environ.get("STAMMBAUM_TEST_BROWSER"):
            threading.Thread(target=lambda: urllib.request.urlopen(full, timeout=20).read(), daemon=True).start()
        else:
            self.win.run_in_gui(lambda: QDesktopServices.openUrl(QUrl(full)))
        plog("Anmeldung: Browser geöffnet (%s)" % url)
        self.auth_cancel = cancel
        t0 = time.time()
        try:
            while not evt.is_set() and not cancel.is_set() and not self.quitting.is_set() and time.time() - t0 < 300:
                srv.handle_request()
        finally:
            self.auth_cancel = None
            srv.server_close()
        if not evt.is_set() and (cancel.is_set() or self.quitting.is_set()):
            return {"error": "cancelled", "message": "Die Anmeldung wurde durch einen neuen Versuch ersetzt."}
        if not evt.is_set():
            return {"error": "timeout", "message": "Keine Anmeldung innerhalb von fünf Minuten. Ist die neue Fassung des Tools unter dieser Adresse veröffentlicht?"}
        if "access_token" not in got:
            return {"error": got.get("error", "denied"), "message": "Die Anmeldung wurde nicht abgeschlossen."}
        secs = int(got.get("expires_in") or 3300)
        self.token = (got["access_token"], time.time() + secs)
        return {"access_token": got["access_token"], "expires_in": secs}


class LoginUrlDialog(QDialog):
    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle("Google Drive einrichten")
        lay = QVBoxLayout(self)
        info = QLabel("Gib die Internetadresse deines Stammbaum-Tools ein, also die Adresse, die du auch im Browser benutzt.\n"
                      "Zum Anmelden öffnet das Programm diese Seite in deinem Browser. Die Adresse wird gespeichert.")
        info.setWordWrap(True)
        lay.addWidget(info)
        self.url = QLineEdit()
        self.url.setPlaceholderText("https://…")
        lay.addWidget(self.url)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self.resize(560, 180)

    def value(self):
        u = self.url.text().strip()
        if u and "://" not in u:
            u = "https://" + u
        return u


# ---------------------------------------------------------------- Schema und Anfragen
class SchemeHandler(QWebEngineUrlSchemeHandler):
    def __init__(self, bridge_getter, parent=None):
        super().__init__(parent)
        self.bridge_getter = bridge_getter

    def _reply(self, job, data: bytes, mime: str):
        buf = QBuffer(job)
        buf.setData(QByteArray(data))
        buf.open(QIODevice.ReadOnly)
        job.reply(mime.encode(), buf)

    def requestStarted(self, job):
        url = job.requestUrl()
        path = urllib.parse.unquote(url.path())
        try:
            if path == "/__fs/read":
                q = urllib.parse.parse_qs(url.query())
                p = q.get("p", [""])[0]
                br = self.bridge_getter()
                if not br or not br.allowed(p) or not os.path.isfile(real(p)):
                    job.fail(job.Error.UrlNotFound)
                    return
                f = QFile(real(p), job)
                if not f.open(QIODevice.ReadOnly):
                    job.fail(job.Error.RequestFailed)
                    return
                job.reply((mimetypes.guess_type(p)[0] or "application/octet-stream").encode(), f)
                return
            if path in ("/", "/index.html"):
                rel = "stammbaum.html"
            else:
                rel = path.lstrip("/")
            full = os.path.normpath(os.path.join(HERE, rel))
            allowed_prefix = (os.path.join(HERE, "vendor") + os.sep, os.path.join(HERE, "stammbaum.html"))
            if not (full.startswith(allowed_prefix[0]) or full == allowed_prefix[1]) or not os.path.isfile(full):
                job.fail(job.Error.UrlNotFound)
                return
            with open(full, "rb") as f:
                data = f.read()
            self._reply(job, data, mimetypes.guess_type(full)[0] or "application/octet-stream")
        except Exception:
            job.fail(job.Error.RequestFailed)


class Interceptor(QWebEngineUrlRequestInterceptor):
    """Die Google-Anmeldebibliothek aus dem Netz wird nicht geladen, die Seite bekommt eine eigene Nachbildung."""

    def interceptRequest(self, info):
        u = info.requestUrl()
        if u.host() == "accounts.google.com" and u.path().startswith("/gsi/"):
            info.block(True)


class PopupPage(QWebEnginePage):
    """Neue Fenster: Webadressen gehen in den Systembrowser, alles andere (etwa ein PDF) in ein eigenes Fenster."""

    def __init__(self, profile, parent_win):
        super().__init__(profile, parent_win)
        self.pw = parent_win
        self.view = None

    def acceptNavigationRequest(self, url, nav_type, is_main):
        if url.scheme() in ("http", "https", "mailto"):
            QDesktopServices.openUrl(url)
            QTimer.singleShot(0, self.deleteLater)
            return False
        if self.view is None:
            self.view = QWebEngineView()
            self.view.setPage(self)
            self.view.resize(900, 700)
            self.view.show()
            self.pw.popups.append(self.view)
        return True


class StPage(QWebEnginePage):
    def __init__(self, profile, win):
        super().__init__(profile, win)
        self.win = win

    def createWindow(self, wtype):
        return PopupPage(self.profile(), self.win)

    def acceptNavigationRequest(self, url, nav_type, is_main):
        if is_main and url.scheme() in ("http", "https", "mailto"):
            QDesktopServices.openUrl(url)
            return False
        return super().acceptNavigationRequest(url, nav_type, is_main)

    def javaScriptConsoleMessage(self, level, msg, line, src):
        if os.environ.get("STAMMBAUM_DEBUG"):
            print("CONSOLE[%s] %s (%s:%s)" % (level, msg, src, line), flush=True)


# ---------------------------------------------------------------- Hauptfenster
class MainWindow(QMainWindow):
    _gui_call = Signal(object)

    def __init__(self, settings=None):
        super().__init__()
        self.settings = settings or Settings()
        self.popups = []
        self._force_close = False
        self.setWindowTitle(TITLE)
        self.profile = QWebEngineProfile(APP_NAME, self)
        os.makedirs(os.path.join(DATA_DIR, "web"), exist_ok=True)
        os.makedirs(CACHE_DIR, exist_ok=True)
        self.profile.setPersistentStoragePath(os.path.join(DATA_DIR, "web"))
        self.profile.setCachePath(CACHE_DIR)
        self.profile.setPersistentCookiesPolicy(QWebEngineProfile.PersistentCookiesPolicy.ForcePersistentCookies)
        self.handler = SchemeHandler(lambda: self.bridge, self)
        self.profile.installUrlSchemeHandler(SCHEME, self.handler)
        self.interceptor = Interceptor(self)
        self.profile.setUrlRequestInterceptor(self.interceptor)
        self.profile.downloadRequested.connect(self.on_download)

        self.view = QWebEngineView()
        self.page = StPage(self.profile, self)
        self.view.setPage(self.page)
        st = self.page.settings()
        for attr in (QWebEngineSettings.WebAttribute.LocalStorageEnabled,
                     QWebEngineSettings.WebAttribute.JavascriptCanAccessClipboard,
                     QWebEngineSettings.WebAttribute.JavascriptCanPaste,
                     QWebEngineSettings.WebAttribute.PdfViewerEnabled,
                     QWebEngineSettings.WebAttribute.PluginsEnabled,
                     QWebEngineSettings.WebAttribute.FullScreenSupportEnabled):
            st.setAttribute(attr, True)
        try:
            self.page.permissionRequested.connect(self.on_permission)
        except AttributeError:
            pass

        self.bridge = Bridge(self)
        self.channel = QWebChannel(self.page)
        self.channel.registerObject("bridge", self.bridge)
        self.page.setWebChannel(self.channel, QWebEngineScript.ScriptWorldId.MainWorld)
        self._gui_call.connect(lambda fn: fn(), Qt.QueuedConnection)
        self._install_shim()

        self.setCentralWidget(self.view)
        geo = self.settings.get("geometry")
        if geo:
            self.resize(geo[0], geo[1])
        else:
            self.resize(1280, 860)
        if self.settings.get("maximized"):
            self.setWindowState(self.windowState() | Qt.WindowMaximized)
        self.page.pdfPrintingFinished.connect(self.on_pdf_done)
        self.page.fullScreenRequested.connect(self.on_fullscreen)
        # Schriftgroesse: Strg und Plus, Minus, Null (wird gemerkt)
        for keys, fn in ((("Ctrl++", "Ctrl+="), lambda: self.set_zoom(self.page.zoomFactor() + 0.1)),
                         (("Ctrl+-",), lambda: self.set_zoom(self.page.zoomFactor() - 0.1)),
                         (("Ctrl+0",), lambda: self.set_zoom(1.0))):
            for k in keys:
                QShortcut(QKeySequence(k), self, activated=fn)
        self.view.page().windowCloseRequested.connect(self.close)
        self.page.loadFinished.connect(self.on_loaded)
        self.view.setUrl(QUrl(START_URL))

    def run_in_gui(self, fn):
        """Fuehrt fn im Oberflaechen-Thread aus (und wartet nicht)."""
        self._gui_call.emit(fn)

    def _install_shim(self):
        with open(os.path.join(HERE, "shim.js"), encoding="utf-8") as f:
            shim = f.read()
        qf = QFile(":/qtwebchannel/qwebchannel.js")
        qf.open(QIODevice.ReadOnly)
        qwc = bytes(qf.readAll()).decode("utf-8")
        qf.close()
        s = QWebEngineScript()
        s.setName("stammbaum-shim")
        s.setSourceCode(qwc + "\n" + shim)
        s.setInjectionPoint(QWebEngineScript.InjectionPoint.DocumentCreation)
        s.setWorldId(QWebEngineScript.ScriptWorldId.MainWorld)
        s.setRunsOnSubFrames(False)
        self.page.scripts().insert(s)

    def on_loaded(self, ok):
        z = self.settings.get("zoom")
        if ok and z and abs(z - 1.0) > 0.01:
            self.page.setZoomFactor(z)
        if not ok or os.environ.get("STAMMBAUM_NO_AUTOOPEN"):
            return
        # Zuletzt benutzte Hauptdatei und Ordner wieder verbinden (Definition liegt in der Seite gespeichert)
        QTimer.singleShot(600, lambda: self.page.runJavaScript(
            "(async()=>{try{if(typeof S!=='undefined'&&!S.db&&await IDB.get('ged'))ACT.openLast();}catch(e){}})()"))

    def on_permission(self, perm):
        try:
            name = str(perm.permissionType())
            perm.grant() if "Clipboard" in name else perm.deny()
        except Exception:
            pass

    # --- Herunterladen: Speichern-Dialog
    def on_download(self, item):
        name = item.downloadFileName() or "download"
        test = os.environ.get("STAMMBAUM_DOWNLOAD_DIR")
        if test:
            target = os.path.join(test, name)
        else:
            start = self.settings.get("lastdir", {}).get("download") or QStandardPaths.writableLocation(
                QStandardPaths.DownloadLocation)
            target, _ = QFileDialog.getSaveFileName(self, "Speichern unter", os.path.join(start, name))
            if not target:
                item.cancel()
                return
            m = dict(self.settings.get("lastdir", {}))
            m["download"] = os.path.dirname(target)
            self.settings.set("lastdir", m)
        item.setDownloadDirectory(os.path.dirname(target))
        item.setDownloadFileName(os.path.basename(target))
        def fin():
            ok = "Completed" in str(item.state())
            self.page.runJavaScript("typeof toast==='function'&&toast(%s,5000)" % json.dumps(
                ("Gespeichert: " + target) if ok else "Die Datei konnte nicht gespeichert werden"))
        item.isFinishedChanged.connect(fin)
        item.accept()

    def print_to_pdf(self):
        test = os.environ.get("STAMMBAUM_PRINT_TO")
        if test:
            target = test
        else:
            start = os.path.join(self.settings.get("lastdir", {}).get("download") or os.path.expanduser("~"), "stammbaum.pdf")
            target, _ = QFileDialog.getSaveFileName(self, "Als PDF speichern", start, "PDF (*.pdf)")
        if not target:
            return
        self.page.printToPdf(target)

    def on_pdf_done(self, p, ok):
        self.page.runJavaScript("typeof toast==='function'&&toast(%s,5000)" % json.dumps(
            ("PDF gespeichert: " + p) if ok else "PDF konnte nicht erstellt werden"))

    def on_fullscreen(self, req):
        req.accept()
        if req.toggleOn():
            self._was_max = self.isMaximized()
            self.showFullScreen()
        else:
            self.showMaximized() if getattr(self, "_was_max", False) else self.showNormal()

    def set_zoom(self, z):
        z = max(0.5, min(2.5, round(z, 2)))
        self.page.setZoomFactor(z)
        self.settings.set("zoom", z)

    def raise_window(self):
        if self.isMinimized():
            self.showNormal()
        self.raise_()
        self.activateWindow()

    def closeEvent(self, ev):
        if not (self.isMaximized() or self.isFullScreen()):
            self.settings.set("geometry", [self.width(), self.height()])
        self.settings.set("maximized", bool(self.isMaximized()))
        if self._force_close:
            ev.accept()
            return
        ev.ignore()
        answered = []

        def cb(dirty):
            if answered:
                return
            answered.append(1)
            if dirty:
                r = QMessageBox.question(self, TITLE, "Es gibt ungespeicherte Änderungen. Trotzdem beenden?",
                                         QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
                if r != QMessageBox.Yes:
                    return
            self._force_close = True
            self.bridge.shutdown()
            self.close()
            QApplication.quit()

        self.page.runJavaScript("typeof isDirty==='function'&&!!isDirty()", cb)
        QTimer.singleShot(2500, lambda: cb(False))   # falls die Seite nicht mehr antwortet


def load_app_icon(app):
    """Fensterbild: icon.png neben app.py (installiert) oder icons/ im Paket."""
    here = os.path.dirname(os.path.abspath(__file__))
    for c in (os.path.join(here, "icon.png"), os.path.join(here, "icons", "seiffert-stammbaum-256.png")):
        if os.path.exists(c):
            app.setWindowIcon(QIcon(c))
            return True
    return False


def register_scheme():
    sch = QWebEngineUrlScheme(SCHEME)
    sch.setSyntax(QWebEngineUrlScheme.Syntax.Host)
    sch.setFlags(QWebEngineUrlScheme.Flag.SecureScheme | QWebEngineUrlScheme.Flag.LocalAccessAllowed
                 | QWebEngineUrlScheme.Flag.CorsEnabled | QWebEngineUrlScheme.Flag.FetchApiAllowed)
    QWebEngineUrlScheme.registerScheme(sch)


def main():
    register_scheme()
    QApplication.setApplicationName(APP_NAME)
    QApplication.setDesktopFileName(APP_NAME)
    app = QApplication(sys.argv)
    load_app_icon(app)
    # Nur ein Fenster je Benutzer: Zwei Programme auf demselben Datenordner koennten sich die gespeicherten
    # Verbindungen gegenseitig beschaedigen. Ein zweiter Start holt das vorhandene Fenster nach vorn.
    key = APP_NAME + "-" + str(os.getuid())
    sock = QLocalSocket()
    sock.connectToServer(key)
    if sock.waitForConnected(400):
        sock.write(b"zeigen")
        sock.waitForBytesWritten(400)
        return 0
    QLocalServer.removeServer(key)
    server = QLocalServer()
    server.listen(key)
    win = MainWindow()
    server.newConnection.connect(lambda: (server.nextPendingConnection(), win.raise_window()))
    plog("Programm gestartet")
    win.show()
    code = app.exec()
    win.bridge.shutdown()
    return code


if __name__ == "__main__":
    sys.exit(main())
