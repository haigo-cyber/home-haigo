"""Neue Fenster von Dateien und Programmen in eine eigene Arbeitsfläche (virtuelle Arbeitsfläche) schieben, wenn der Desktop das erlaubt.

Arbeitsweise: Vor dem Start merkt sich das Programm, welche Fenster es gibt (wmctrl -l). Nach dem Start wartet ein Hintergrundfaden auf neue
Fenster, sucht die erste Arbeitsfläche ohne Fenster (oder legt eine neue an), schiebt die neuen Fenster dorthin und wechselt hin.
Geht das nicht (kein wmctrl, Wayland, kein Anzeigeserver), startet alles wie gewohnt; es gibt keine Fehlermeldung.
Nur Standardbibliothek, damit es ohne Oberfläche getestet werden kann.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import threading
import time

MAX_DESKTOPS = 12
WAIT, SETTLE = 8.0, 1.2        # wie lange auf ein neues Fenster gewartet wird, und wie lange es ruhig bleiben muss, bis es verschoben wird
_lock = threading.Lock()
_claimed: set[str] = set()


def status() -> dict:
    """Ob die Funktion hier möglich ist, und warum nicht."""
    session = (os.environ.get("XDG_SESSION_TYPE") or "").lower()
    tool = shutil.which("wmctrl")
    if session == "wayland":
        return {"available": False, "reason": "Unter Wayland dürfen Programme keine fremden Fenster verschieben.", "tool": tool or "", "session": session}
    if not os.environ.get("DISPLAY"):
        return {"available": False, "reason": "Kein X11-Anzeigeserver gefunden.", "tool": tool or "", "session": session}
    if not tool:
        return {"available": False, "reason": "Das Programm wmctrl fehlt (Paket wmctrl installieren, zum Beispiel: sudo pacman -S wmctrl).", "tool": "", "session": session}
    return {"available": True, "reason": "", "tool": tool, "session": session}


def _run(args: list[str], timeout: float = 2.5) -> str | None:
    tool = shutil.which("wmctrl")
    if not tool:
        return None
    try:
        r = subprocess.run([tool] + args, capture_output=True, text=True, timeout=timeout)
    except (OSError, subprocess.SubprocessError):
        return None
    return r.stdout if r.returncode == 0 else None


def windows() -> dict[str, int] | None:
    """Fenster-Kennung -> Arbeitsfläche (-1 = auf allen Flächen sichtbar, etwa Leisten)."""
    out = _run(["-l"])
    if out is None:
        return None
    res: dict[str, int] = {}
    for line in out.splitlines():
        parts = line.split(None, 3)
        if len(parts) >= 2 and parts[0].startswith("0x"):
            try:
                res[parts[0]] = int(parts[1])
            except ValueError:
                continue
    return res


def desktops() -> tuple[int, int] | None:
    """(Anzahl der Arbeitsflächen, aktuelle Arbeitsfläche)."""
    out = _run(["-d"])
    if out is None:
        return None
    n, cur = 0, 0
    for line in out.splitlines():
        parts = line.split()
        if len(parts) >= 2 and parts[0].isdigit():
            if parts[1] == "*":
                cur = int(parts[0])
            n += 1
    return (n, cur) if n else None


def place(before: set[str], wait: float | None = None, settle: float | None = None, stop=None) -> int | None:
    """Wartet auf neue Fenster und schiebt sie auf eine freie Arbeitsfläche. Gibt die Zielfläche zurück oder None."""
    wait = WAIT if wait is None else wait
    settle = SETTLE if settle is None else settle
    t0 = time.time()
    new: set[str] = set()
    changed = t0
    while time.time() - t0 < wait:
        if stop is not None and stop():
            return None
        now = windows()
        if now is None:
            return None
        fresh = {i for i, d in now.items() if i not in before and i not in _claimed and d != -1}
        if fresh != new:
            new, changed = fresh, time.time()
        if new and time.time() - changed >= settle:
            break
        time.sleep(0.25)
    if not new:
        return None
    with _lock:
        now = windows()
        if now is None:
            return None
        new = {i for i in new if i in now and i not in _claimed}
        if not new:
            return None
        dk = desktops()
        if dk is None:
            return None
        count, _cur = dk
        busy = {d for i, d in now.items() if i not in new and d >= 0}
        mine = {now[i] for i in new}
        free = [i for i in range(count) if i not in busy]
        if len(mine) == 1 and next(iter(mine)) in free:
            target = next(iter(mine))                     # liegt schon allein auf einer freien Fläche
        elif free:
            target = free[0]
        elif count < MAX_DESKTOPS:
            if _run(["-n", str(count + 1)]) is None:
                return None
            target = count
        else:
            return None
        for i in sorted(new):
            if now[i] != target:
                _run(["-i", "-r", i, "-t", str(target)])
        _run(["-s", str(target)])
        _claimed.update(new)
        if len(_claimed) > 400:
            _claimed.intersection_update(set(windows() or {}))
        return target


def launch(argv: list[str], enabled: bool = True, **kw) -> "subprocess.Popen":
    """Startet ein Programm wie subprocess.Popen; wenn aktiviert und möglich, wandert sein neues Fenster auf eine eigene Arbeitsfläche."""
    before = None
    if enabled and status()["available"]:
        w = windows()
        before = set(w) if w is not None else None
    p = subprocess.Popen(argv, **kw)
    if before is not None:
        def work() -> None:
            # Ein Programm, das sofort mit Fehler endet, hat kein Fenster zu verschieben; nicht länger warten (sonst würde ein später
            # von Hand geöffnetes Fenster versehentlich mitgenommen)
            place(before, stop=lambda: p.poll() not in (None, 0))
        threading.Thread(target=work, daemon=True).start()
    return p
