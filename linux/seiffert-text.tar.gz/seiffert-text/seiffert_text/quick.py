"""Modell des Schnelleditors: eine LaTeX-Vorlage wird in Zeilen mit bearbeitbaren Textfeldern zerlegt.

Das ist eine Übertragung des Kerns von „Seifferts LaTeX-Schnelleditor 2.5“ (HTML-Werkzeug) nach Python.
Es gibt keine Oberfläche in diesem Modul. Nur die Textfelder einer Zeile werden verändert, alles andere
(Befehle, Abstände, Klammern) bleibt Zeichen für Zeichen erhalten."""
import copy
import json
import math
import re

# Befehle, deren Klammerinhalte reine Steuerung sind (nie als Text anbieten)
LAYOUT_CMDS = set(("documentclass usepackage begin end fontsize hspace vspace hskip vskip kern rule "
                   "includegraphics setlength addtolength settowidth setcounter addtocounter newcommand renewcommand "
                   "providecommand def let label ref pageref eqref cite input include color definecolor pagecolor "
                   "geometry pagestyle thispagestyle newlength newcounter bibliography bibliographystyle vphantom "
                   "hphantom phantom cline lstset tikzset usetikzlibrary newenvironment renewenvironment hypersetup "
                   "selectlanguage setmainfont setsansfont newpage clearpage pagebreak nopagebreak linebreak hline "
                   "arraystretch").split(" "))

# Befehle, bei denen nur bestimmte Klammergruppen (Zählung ab 0) Text sind
GROUP_POLICY = {
    "textcolor": [1], "colorbox": [1], "fcolorbox": [2], "multicolumn": [2], "multirow": [2], "parbox": [1],
    "raisebox": [1], "scalebox": [1], "rotatebox": [1], "resizebox": [2], "href": [1], "foreignlanguage": [1],
    "hyperlink": [1], "hypertarget": [1]}

# Befehle, die mitten im Text stehen und Teil des Textes bleiben
GLYPH_CMDS = set(("ss SS glqq grqq glq grq flqq frqq dq ldots dots textbackslash textasciitilde textasciicircum "
                  "euro texteuro textendash textemdash textbullet copyright pounds dag ddag S P o O ae AE oe OE aa AA "
                  "l L i j LaTeX TeX today textellipsis textquotedblleft textquotedblright degree textdegree "
                  "textregistered texttrademark checkmark").split(" "))

# Umgebungen, deren Inhalt nie als Text angeboten wird
RAW_ENVS = ["tikzpicture", "verbatim", "lstlisting", "minted", "align", "align*", "equation", "equation*",
            "gather", "gather*", "multline", "multline*", "eqnarray", "eqnarray*", "displaymath", "math",
            "pgfpicture", "filecontents", "filecontents*"]

_uid = [1]


def new_id():
    _uid[0] += 1
    return _uid[0] - 1


def clone(o):
    return copy.deepcopy(o)


def fmt_cm(w):
    r = math.floor(w * 100 + 0.5) / 100
    return str(int(r)) if r == int(r) else repr(r)


# ------------------------------------------------------------------ Zerlegung einer Zeile
_UNIT_RE = re.compile(r"^[-+]?([0-9]+\.?[0-9]*|\.[0-9]+)\s*(pt|em|ex|cm|mm|in|bp|sp|pc|dd|cc|mu|px)$")
_ALNUM = re.compile("[A-Za-z0-9\u00c0-\u024f]")
_CMD = re.compile(r"\\([A-Za-z@]+)(\*?)")
_SPLIT3 = re.compile(r"^(\s*)([\s\S]*?)(\s*)\Z")


def is_text_core(t):
    if not _ALNUM.search(t):
        return False
    if _UNIT_RE.match(t.strip()):
        return False
    return True


def group_editable(name, idx):
    if name in LAYOUT_CMDS:
        return False
    if name in GROUP_POLICY:
        return idx in GROUP_POLICY[name]
    return True


def find_close(line, i, close):
    d = 0
    j = i + 1
    n = len(line)
    while j < n:
        c = line[j]
        if c == "\\":
            j += 2
            continue
        if c == "{":
            d += 1
        elif c == "}":
            d -= 1
        elif c == close and d <= 0:
            return j
        j += 1
    return -1


def tokenize_line(line, raw=False):
    if raw:
        return [] if line == "" else [{"k": "s", "v": line}]
    out = []
    n = len(line)
    st = {"i": 0, "pend": None, "owner": None, "buf": ""}
    stack = []

    def push_s(v):
        if not v:
            return
        if out and out[-1]["k"] == "s":
            out[-1]["v"] += v
        else:
            out.append({"k": "s", "v": v})

    def owner_ok():
        if stack:
            return stack[-1]["e"]
        return (st["owner"] not in LAYOUT_CMDS) if st["owner"] else True

    def flush():
        if not st["buf"]:
            return
        t = st["buf"]
        st["buf"] = ""
        m = _SPLIT3.match(t)
        if m.group(2) and owner_ok() and is_text_core(m.group(2)):
            push_s(m.group(1))
            sg = {"k": "x", "v": m.group(2)}
            if stack and stack[-1]["name"] == "url":
                sg["raw"] = True
            out.append(sg)
            push_s(m.group(3))
        else:
            push_s(t)

    i = 0
    while i < n:
        c = line[i]
        if st["pend"] and c != "{" and c != "[":
            st["pend"] = None
        if c == "%":
            flush()
            push_s(line[i:])
            i = n
            break
        if c == "\\":
            m = _CMD.match(line, i)
            if m:
                name = m.group(1)
                if name in GLYPH_CMDS:
                    st["buf"] += m.group(0)
                    i += len(m.group(0))
                    continue
                flush()
                push_s(m.group(0))
                i += len(m.group(0))
                st["pend"] = {"name": name, "idx": 0}
                st["owner"] = name
                continue
            d = line[i + 1] if i + 1 < n else None
            if d is None:
                st["buf"] += "\\"
                i += 1
                continue
            if d == "\\":
                flush()
                push_s("\\\\")
                i += 2
                st["owner"] = None
                if i < n and line[i] == "[":
                    j = find_close(line, i, "]")
                    e = n - 1 if j < 0 else j
                    push_s(line[i:e + 1])
                    i = e + 1
                continue
            if d == "(" or d == "[":
                flush()
                close = "\\)" if d == "(" else "\\]"
                j = line.find(close, i + 2)
                end = n if j < 0 else j + 2
                push_s(line[i:end])
                i = end
                st["owner"] = None
                continue
            if d == ")" or d == "]":
                flush()
                push_s(line[i:i + 2])
                i += 2
                continue
            st["buf"] += line[i:i + 2]
            i += 2
            continue
        if c == "{":
            flush()
            pend = st["pend"]
            if pend:
                parent_e = stack[-1]["e"] if stack else True
                stack.append({"e": parent_e and group_editable(pend["name"], pend["idx"]),
                              "name": pend["name"], "idx": pend["idx"]})
                st["pend"] = None
            else:
                stack.append({"e": stack[-1]["e"] if stack else True, "name": None, "idx": 0})
            push_s("{")
            i += 1
            st["owner"] = None
            continue
        if c == "}":
            flush()
            push_s("}")
            i += 1
            e = stack.pop() if stack else None
            st["pend"] = {"name": e["name"], "idx": e["idx"] + 1} if (e and e["name"]) else None
            st["owner"] = None
            continue
        if c == "[" and st["pend"]:
            j = find_close(line, i, "]")
            e = n - 1 if j < 0 else j
            push_s(line[i:e + 1])
            i = e + 1
            continue
        if c == "$":
            flush()
            if i + 1 < n and line[i + 1] == "$":
                j = line.find("$$", i + 2)
                end = n if j < 0 else j + 2
            else:
                j = i + 1
                while j < n:
                    if line[j] == "\\":
                        j += 2
                        continue
                    if line[j] == "$":
                        break
                    j += 1
                end = n if j >= n else j + 1
            push_s(line[i:end])
            i = end
            st["owner"] = None
            continue
        if c == "&":
            flush()
            push_s("&")
            i += 1
            st["owner"] = None
            continue
        st["buf"] += c
        i += 1
    flush()
    return out


# ------------------------------------------------------------------ Datei -> Dokument
def strip_comment(line):
    return re.sub(r"(^|[^\\])%.*$", r"\1", line, count=1)


def raw_state_for(line, st):
    lc = strip_comment(line)
    raw = st["rawDepth"] > 0 or st["disp"]
    for m in re.finditer(r"\\(begin|end)\{([^}]*)\}", lc):
        if m.group(2) in RAW_ENVS:
            raw = True
            st["rawDepth"] += 1 if m.group(1) == "begin" else -1
    if st["rawDepth"] < 0:
        st["rawDepth"] = 0
    o = lc.count("\\[")
    c = lc.count("\\]")
    if o > c:
        st["disp"] = True
        raw = True
    elif c > o:
        raw = True
        st["disp"] = False
    return raw


IMG_RE = re.compile(r"\\noindent\\makebox\[\\linewidth\]\[([lcr])\]\{\\includegraphics\[width=([0-9]+(?:\.[0-9]+)?)cm\]"
                    r"\{([^{}\s]+)\}\}\\par")


def img_line(im):
    return "\\noindent\\makebox[\\linewidth][%s]{\\includegraphics[width=%scm]{%s}}\\par" % (
        im["a"], fmt_cm(im["w"]), im["file"])


def make_unit(line, raw=False):
    u = {"id": new_id(), "segs": tokenize_line(line, raw), "raw": bool(raw)}
    if not raw:
        m = IMG_RE.fullmatch(line)
        if m:
            u["img"] = {"a": m.group(1), "w": float(m.group(2)), "file": m.group(3)}
    return u


def is_content(u):
    return has_fields(u) or bool(u.get("img"))


class TexError(Exception):
    pass


def parse_tex(text):
    eol = "\n"
    if "\r\n" in text:
        eol = "\r\n"
        text = text.replace("\r\n", "\n")
    tag = "\\begin{document}"
    b = text.find(tag)
    e = text.rfind("\\end{document}")
    if b < 0 or e < 0 or e < b:
        raise TexError("In der Datei fehlen \\begin{document} und \\end{document}. "
                       "Das ist keine vollständige LaTeX-Vorlage.")
    head_end = b + len(tag)
    head, body, tail = text[:head_end], text[head_end:e], text[e:]
    lines = body.split("\n")
    st = {"rawDepth": 0, "disp": False}
    units = [make_unit(l, raw_state_for(l, st)) for l in lines]
    if len(units) >= 2:
        if lines[0].strip() == "":
            units[0]["fixed"] = True
        if lines[-1].strip() == "":
            units[-1]["fixed"] = True
    return {"eol": eol, "head": head, "tail": tail, "units": units}


# ------------------------------------------------------------------ Ausgabe
def esc_special(s):
    def f(m):
        if m.group(1):
            return m.group(1)
        if m.group(2):
            return "\\" + m.group(2)
        return "\\textbackslash{}"
    return re.sub(r"(\\[\s\S])|([&%#_$])|(\\\Z)", f, s)


def seg_out(sg, opts):
    if sg["k"] == "x" and sg.get("edited") and not sg.get("raw") and opts and opts.get("autoEscape"):
        return esc_special(sg["v"])
    return sg["v"]


UB_DEF = ("% Automatischer Zeilenumbruch in festen Boxen (vom LaTeX-Schnelleditor)\n"
          "\\newlength{\\umbruchbreite}\n"
          "\\newcommand{\\umbruchbox}[3]{%\n"
          "\t\\settowidth{\\umbruchbreite}{#3}%\n"
          "\t\\ifdim\\umbruchbreite>0.6\\linewidth\n"
          "\t\t\\parbox[t]{0.6\\linewidth}{\\if#2c\\centering\\fi\\if#2l\\raggedright\\fi\\if#2r\\raggedleft\\fi #3}%\n"
          "\t\\else\n"
          "\t\t\\makebox[#1][#2]{#3}%\n"
          "\t\\fi}\n\n")
EM_DEF = "% Text nie über den Rand laufen lassen (vom LaTeX-Schnelleditor)\n\\emergencystretch=3em\n\n"


def closes_early(t):
    d = 0
    i = 0
    n = len(t)
    while i < n:
        c = t[i]
        if c == "\\":
            i += 2
            continue
        if c == "{":
            d += 1
        elif c == "}":
            d -= 1
            if d < 0:
                return True
        i += 1
    return False


_MAKEBOX = re.compile(r"\\makebox\[([^\]]*)\]\[([lcrs])\]\{")


def auto_break_out(u, opts):
    parts = [seg_out(sg, opts) for sg in u["segs"]]
    res = []
    for i, t in enumerate(parts):
        if u["segs"][i]["k"] != "s" or not any(x["k"] == "x" for x in u["segs"][i + 1:]):
            res.append(t)
            continue

        def f(m, t=t):
            if closes_early(t[m.end():]):
                return m.group(0)
            return "\\umbruchbox{" + m.group(1) + "}{" + m.group(2) + "}{"
        res.append(_MAKEBOX.sub(f, t))
    return "".join(res)


def unit_out(u, opts):
    if opts and opts.get("autoBreak") and not u["raw"] and has_fields(u):
        return auto_break_out(u, opts)
    return "".join(seg_out(s, opts) for s in u["segs"])


def body_out(doc, opts):
    return "\n".join(unit_out(u, opts) for u in doc["units"])


def serialize(doc, opts):
    body = body_out(doc, opts)
    head = doc["head"]
    tagb = "\\begin{document}"
    if head[-len(tagb):] == tagb and re.search(r"\\square|\\boxtimes|\\checkmark", body) \
            and not re.search(r"^[^%\n]*\\usepackage(?:\[[^\]]*\])?\{[^}]*\bams(?:symb|fonts)\b[^}]*\}", head, re.M):
        dm = re.search(r"\\documentclass(?:\[[^\]]*\])?\{[^}]*\}[^\n]*\n", head)
        if dm:
            head = head[:dm.end()] + "\\usepackage{amssymb}\n" + head[dm.end():]
        else:
            head = head[:len(head) - len(tagb)] + "\\usepackage{amssymb}\n" + tagb
    if opts and opts.get("autoBreak") and head[-len(tagb):] == tagb:
        extra = ""
        if "\\umbruchbox{" in body and "\\umbruchbox" not in head:
            extra += UB_DEF
        if not re.search(r"\\emergencystretch|\\sloppy", head):
            extra += EM_DEF
        if extra:
            head = head[:len(head) - len(tagb)] + extra + tagb
    return head + body + doc["tail"]


def serialize_file(doc, opts):
    t = serialize(doc, opts)
    return t.replace("\n", "\r\n") if doc["eol"] == "\r\n" else t


def has_fields(u):
    return any(s["k"] == "x" for s in u["segs"])


def is_blank_unit(u):
    return all(s["k"] == "s" and s["v"].strip() == "" for s in u["segs"])


def raw_of_unit(u):
    return "".join(s["v"] for s in u["segs"])


def brace_delta(s):
    d = 0
    i = 0
    n = len(s)
    while i < n:
        c = s[i]
        if c == "\\":
            i += 2
            continue
        if c == "{":
            d += 1
        elif c == "}":
            d -= 1
        i += 1
    return d


def strip_comments_all(t):
    return "\n".join(strip_comment(l) for l in t.split("\n"))


def check_doc(doc, opts):
    w = []
    for u in doc["units"]:
        for s in u["segs"]:
            if s["k"] == "x" and s.get("edited"):
                t = seg_out(s, opts)
                if brace_delta(t) != 0:
                    w.append({"id": u["id"], "msg": "Ein Textfeld enthält ungleich viele { und }: „" + t[:30] + "“"})
    has_gfx = re.search(r"^[^%\n]*\\usepackage(?:\[[^\]]*\])?\{[^}]*\bgraphicx\b[^}]*\}", doc["head"], re.M)
    for u in doc["units"]:
        im = u.get("img")
        if not im:
            continue
        if not has_gfx:
            w.append({"id": u["id"], "msg": "Die Vorlage lädt das Paket graphicx nicht, Grafiken lassen sich so nicht kompilieren."})
        if re.search(r"[\s%#&{}\\~^$]", im["file"]):
            w.append({"id": u["id"], "msg": "Der Dateiname „" + im["file"] + "“ enthält Leerzeichen oder Sonderzeichen. "
                                              "Das macht LaTeX Probleme, bitte die Datei umbenennen."})
    seen = []
    out = []
    for x in w:
        if x["msg"] not in seen:
            seen.append(x["msg"])
            out.append(x)
    return out


def find_images(doc, opts):
    text = strip_comments_all(doc["head"] + "\n" + body_out(doc, opts))
    out = []
    for m in re.finditer(r"\\includegraphics\s*(?:\[[^\]]*\])?\s*\{([^}]+)\}", text):
        p = m.group(1).strip()
        if p not in out:
            out.append(p)
    return out


# ------------------------------------------------------------------ Zeilenoperationen
def template_of(u):
    c = clone(u)
    c["id"] = new_id()
    c.pop("fixed", None)
    for s in c["segs"]:
        if s["k"] == "x":
            s["v"] = ""
            s["edited"] = True
    return c


def op_insert_below(doc, idx):
    t = doc["units"][idx]
    nu = template_of(t) if has_fields(t) else {"id": new_id(), "segs": [], "raw": False}
    doc["units"].insert(idx + 1, nu)
    return nu


def op_duplicate(doc, idx):
    c = clone(doc["units"][idx])
    c["id"] = new_id()
    c.pop("fixed", None)
    doc["units"].insert(idx + 1, c)
    return c


def op_remove(doc, idx):
    del doc["units"][idx]


def op_move(doc, frm, to):
    u = doc["units"].pop(frm)
    doc["units"].insert(to, u)


def op_move_relative(doc, idx, d, is_visible):
    j = idx + d
    while 0 <= j < len(doc["units"]) and not is_visible(doc["units"][j]):
        j += d
    if j < 0 or j >= len(doc["units"]):
        return False
    op_move(doc, idx, j)
    return True


def op_bulk(doc, idx, text):
    t = doc["units"][idx]
    if not has_fields(t):
        return []
    lines = [l for l in re.split(r"\r?\n", text) if l.strip() != ""]
    made = []
    at = idx
    for l in lines:
        u = template_of(t)
        cells = l.split("\t")
        xs = [s for s in u["segs"] if s["k"] == "x"]
        for k, s in enumerate(xs):
            if k == len(xs) - 1:
                s["v"] = " ".join(cells[k:]).strip()
            else:
                s["v"] = cells[k].strip() if k < len(cells) else ""
        at += 1
        doc["units"].insert(at, u)
        made.append(u)
    return made


def op_set_raw(doc, idx, raw_line):
    u = doc["units"][idx]
    u["segs"] = tokenize_line(raw_line, u["raw"])


# ------------------------------------------------------------------ Zeilenarten, Themenblöcke
def defined_macros(head):
    s = set()
    for m in re.finditer(r"\\(?:re|provide)?newcommand\*?\s*(?:\{\\([A-Za-z@]+)\}|\\([A-Za-z@]+))", head):
        s.add(m.group(1) or m.group(2))
    return s


def unit_macro(u, macros):
    if not has_fields(u):
        return None
    m = re.match(r"^\s*\\([A-Za-z@]+)", raw_of_unit(u))
    return m.group(1) if m and m.group(1) in macros else None


def theme_macro(doc):
    macros = defined_macros(doc["head"])
    for u in doc["units"]:
        m = unit_macro(u, macros)
        if m and re.search("thema", m, re.I):
            return m
    return None


def blocks_of(doc, theme):
    if not theme:
        return []
    macros = defined_macros(doc["head"])
    U = doc["units"]
    starts = [i for i, u in enumerate(U) if unit_macro(u, macros) == theme]
    res = []
    for k, st in enumerate(starts):
        lim = starts[k + 1] if k + 1 < len(starts) else len(U)
        e = lim
        while e > st + 1 and not is_content(U[e - 1]):
            e -= 1
        res.append({"start": st, "end": e, "next": lim, "id": U[st]["id"]})
    return res


def clone_units(arr):
    out = []
    for u in arr:
        c = clone(u)
        c["id"] = new_id()
        c.pop("fixed", None)
        out.append(c)
    return out


def gap_for(U, bl, k):
    own = U[bl[k]["end"]:bl[k]["next"]]
    if own:
        return own
    if k > 0:
        return U[bl[k - 1]["end"]:bl[k - 1]["next"]]
    return []


def insert_after_block(doc, bl, k, units):
    U = doc["units"]
    b = bl[k]
    has_own_gap = b["next"] > b["end"]
    gap = clone_units(gap_for(U, bl, k))
    if has_own_gap:
        U[b["next"]:b["next"]] = units + gap
    else:
        U[b["end"]:b["end"]] = gap + units


def _find_block(bl, id_):
    for k, b in enumerate(bl):
        if b["id"] == id_:
            return k
    return -1


def op_block_move(doc, theme, id_, d):
    bl = blocks_of(doc, theme)
    k = _find_block(bl, id_)
    j = k + d
    if k < 0 or j < 0 or j >= len(bl):
        return False
    a, b = bl[min(k, j)], bl[max(k, j)]
    U = doc["units"]
    A = U[a["start"]:a["end"]]
    gap = U[a["end"]:b["start"]]
    B = U[b["start"]:b["end"]]
    U[a["start"]:b["end"]] = B + gap + A
    return True


def op_block_duplicate(doc, theme, id_):
    bl = blocks_of(doc, theme)
    k = _find_block(bl, id_)
    if k < 0:
        return None
    cp = clone_units(doc["units"][bl[k]["start"]:bl[k]["end"]])
    insert_after_block(doc, bl, k, cp)
    return cp[0]


def op_block_remove(doc, theme, id_):
    bl = blocks_of(doc, theme)
    k = _find_block(bl, id_)
    if k < 0:
        return 0
    b = bl[k]
    frm, to = b["start"], b["next"]
    if b["next"] == b["end"] and k > 0:
        frm, to = bl[k - 1]["end"], b["end"]
    del doc["units"][frm:to]
    return b["end"] - b["start"]


def op_insert_type_after_block(doc, theme, id_, exemplar):
    bl = blocks_of(doc, theme)
    k = _find_block(bl, id_)
    if k < 0:
        return None
    nu = template_of(exemplar)
    insert_after_block(doc, bl, k, [nu])
    return nu


def op_insert_type(doc, idx, exemplar):
    nu = template_of(exemplar)
    doc["units"].insert(idx + 1, nu)
    return nu


def op_insert_image(doc, idx, file, w=3, a="l"):
    im = {"a": a or "l", "w": w or 3, "file": file}
    nu = {"id": new_id(), "segs": [{"k": "s", "v": img_line(im)}], "raw": False, "img": im}
    doc["units"].insert(idx + 1, nu)
    return nu


def op_set_img(u, **patch):
    u["img"].update(patch)
    try:
        w = float(u["img"].get("w") or 0.2)
    except (TypeError, ValueError):
        w = 0.2
    u["img"]["w"] = max(0.2, min(40.0, w))
    u["segs"] = [{"k": "s", "v": img_line(u["img"])}]


def line_types(doc):
    macros = defined_macros(doc["head"])
    seen = set()
    out = []
    for u in doc["units"]:
        m = unit_macro(u, macros)
        if m and m not in seen:
            seen.add(m)
            out.append({"macro": m, "unit": u, "fields": sum(1 for s in u["segs"] if s["k"] == "x")})
    return out


# ------------------------------------------------------------------ Kopfdaten
def is_simple_text(b):
    if b == "":
        return True
    if re.search("%", b.replace("\\%", "")):
        return False
    if re.search(r"#[0-9]", b):
        return False
    if re.match(r"^\s*-?[0-9.,]+\s*(cm|mm|pt|em|ex|bp|in|sp|px)?\s*\Z", b):
        return False
    t = b.replace("\\textbar{}", " ")
    t = re.sub(r"\\(?:textbf|textit|emph|textsc|texttt|underline)\{", "{", t)
    t = re.sub(r"\\[&%#_$,;\- ]", " ", t)
    t = re.sub(r"\\(?:quad|qquad|ldots|dots|ss|glqq|grqq|enspace)\b\s*(?:\{\})?", " ", t)
    t = re.sub(r'\\"[A-Za-z]', " ", t)
    return not re.search(r"\\", t)


_NEWCMD = re.compile(r"\\(?:re)?newcommand\*?\s*\{\\([A-Za-z@]+)\}\s*\{")


def head_fields(head, only=None):
    all_ = []
    pos = 0
    while True:
        m = _NEWCMD.search(head, pos)
        if not m:
            break
        pos = m.end()
        ls = head.rfind("\n", 0, m.start()) + 1
        if re.search(r"(^|[^\\])%", head[ls:m.start()]):
            continue
        op = m.end() - 1
        d = 0
        j = op
        while j < len(head):
            c = head[j]
            if c == "\\":
                j += 2
                continue
            if c == "{":
                d += 1
            elif c == "}":
                d -= 1
                if d == 0:
                    break
            j += 1
        if j >= len(head):
            continue
        body = head[op + 1:j]
        pos = j + 1
        if "\n" in body:
            continue
        ok = (m.group(1) in only) if only else is_simple_text(body)
        if ok:
            all_.append({"name": m.group(1), "start": op + 1, "end": j, "value": body})
    order = []
    last = {}
    for f in all_:
        if f["name"] not in last:
            order.append(f["name"])
        last[f["name"]] = f
    return [last[n] for n in order]


def set_head_field(doc, name, value, opts=None, only=None):
    f = next((x for x in head_fields(doc["head"], only) if x["name"] == name), None)
    if not f:
        return False
    v = re.sub(r"\r?\n", " ", str(value))
    if opts and opts.get("autoEscape"):
        v = esc_special(v)
    doc["head"] = doc["head"][:f["start"]] + v + doc["head"][f["end"]:]
    return True


# ------------------------------------------------------------------ Schriftgröße des Dateinamens im Seitenkopf
def name_macros(head):
    names = ["jobname"]
    for l in head.split("\n"):
        if re.match(r"^\s*%", l):
            continue
        m = re.search(r"\\(?:re)?newcommand\*?\s*\{\\([A-Za-z@]+)\}.*\\jobname", l)
        if m and m.group(1) not in names:
            names.append(m.group(1))
    return names


def find_name_size(head):
    off = 0
    for l in head.split("\n"):
        code = strip_comment(l)
        for nm in name_macros(head):
            if re.search(r"\\(?:re)?newcommand", code):
                continue
            m = re.search(r"(\\fontsize\{)([0-9.]+)(pt)?(\}\{)([0-9.]+)(pt)?(\}\s*\\selectfont\s*(?:\\textbf\{)?\\"
                          + re.escape(nm) + r"\b)", code)
            if m:
                return {"start": off + m.start(), "len": len(m.group(0)), "size": float(m.group(2)),
                        "base": float(m.group(5)), "unit": m.group(3) or "", "unit2": m.group(6) or "",
                        "pre": m.group(1), "mid": m.group(4), "post": m.group(7)}
        off += len(l) + 1
    return None


def headheight_cm(head):
    m = re.search(r"headheight\s*=\s*([0-9.]+)\s*(cm|mm|pt)", head)
    if not m:
        return None
    v = float(m.group(1))
    return v if m.group(2) == "cm" else (v / 10 if m.group(2) == "mm" else v * 0.0351464)


def set_name_size(doc, size):
    f = find_name_size(doc["head"])
    if not f:
        return None
    if "nameMeta" not in doc:
        doc["nameMeta"] = {"ratio": f["base"] / f["size"], "hh": headheight_cm(doc["head"])}
    sz = max(6, min(96, size))
    base = math.floor(sz * doc["nameMeta"]["ratio"] * 2 + 0.5) / 2
    rep = f["pre"] + fmt_cm(sz) + f["unit"] + f["mid"] + fmt_cm(base) + f["unit2"] + f["post"]
    doc["head"] = doc["head"][:f["start"]] + rep + doc["head"][f["start"] + f["len"]:]
    note = ""
    hh = headheight_cm(doc["head"])
    if hh is not None and doc["nameMeta"]["hh"] is not None:
        need = math.ceil((base * 0.0351464 + 0.2) * 10) / 10
        want = max(doc["nameMeta"]["hh"], need)
        want_txt = fmt_cm(want) + "cm"
        if abs(want - hh) > 0.001:
            doc["head"] = re.sub(r"(headheight\s*=\s*)[0-9.]+\s*(?:cm|mm|pt)",
                                 lambda m: m.group(1) + want_txt, doc["head"], count=1)
        if want > doc["nameMeta"]["hh"] + 0.001:
            note = "Kopfhöhe auf " + fmt_cm(want).replace(".", ",") + " cm erhöht, damit die Schrift hineinpasst."
    return {"size": sz, "note": note}


# ------------------------------------------------------------------ Hilfen für die Oberfläche
def snap(doc):
    return json.dumps({"u": doc["units"], "h": doc["head"]}, sort_keys=True)


def restore(doc, s):
    o = json.loads(s)
    doc["units"] = o["u"]
    doc["head"] = o["h"]


def clean_name(n):
    return re.sub(r"[\\/:*?\"<>|]", "", re.sub(r"\.tex$", "", n or "", flags=re.I)).strip()


def template_base(tpl_name, existing):
    """Name ohne laufende Nummer: „Name01“ gehört zu „Name“, wenn „Name.tex“ im Ordner liegt."""
    b = clean_name(tpl_name) or "Vorlage"
    m = re.match(r"^(.*\D)(\d{2})\Z", b)
    if m and (m.group(1) + ".tex") in existing:
        return m.group(1)
    return b


def next_template_name(tpl_name, names):
    """names: Dateinamen im Zielordner. Liefert (Dateiname, erste_Fassung)."""
    existing = set(names)
    base = template_base(tpl_name, existing)
    rx = re.compile("^" + re.escape(base) + r"(\d{2,})\.tex\Z", re.I)
    mx = 0
    for n in names:
        m = rx.match(n)
        if m:
            mx = max(mx, int(m.group(1)))
    n = mx + 1
    while ("%s%02d.tex" % (base, n)) in existing:
        n += 1
    return "%s%02d.tex" % (base, n), mx == 0
