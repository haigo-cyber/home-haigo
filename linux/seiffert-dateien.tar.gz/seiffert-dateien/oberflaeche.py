#!/usr/bin/env python3
"""Seifferts Oberfläche: der Schreibtisch für COSMIC (Wayland) und andere Umgebungen.

Das Programm zeichnet Hintergrund, Symbole (Schreibtisch-Ordner und/oder Favoriten im Look von Seifferts Dateien) und ein
Starter-Symbol ohne Beschriftung, das den Seifferts Starter ruft. Unter Wayland legt es sich über das Layer-Shell-Protokoll als
Fläche unter alle Fenster (COSMIC unterstützt das); unter X11 ist es ein Desktop-Fenster (zum Beispiel unter Cinnamon).

Gezeichnet wird mit GTK 3 und cairo, ohne Web-Engine, damit der dauernd laufende Teil sparsam bleibt. Alle Einstellungen verwaltet
Seifferts Dateien (Einstellungen, "Oberfläche einrichten ..."); sie liegen in surface.json (siehe surfacecfg.py).

Start:   seiffert-oberflaeche            (--autostart wartet auf die Sitzung, siehe README)
Steuern: seiffert-oberflaeche --quit | --reload | --status | --check
Benötigt: python-gobject, gtk3, gtk-layer-shell (Arch: sudo pacman -S python-gobject gtk3 gtk-layer-shell librsvg)
"""
from __future__ import annotations

import datetime
import json
import math
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import surfacecfg as SC  # noqa: E402

NAME = "Seifferts Oberfläche"
UID = os.getuid() if hasattr(os, "getuid") else "user"
SOCKET = os.path.join(tempfile.gettempdir(), "seiffert-oberflaeche-%s" % UID)
DATEIEN_SOCKET = os.path.join(tempfile.gettempdir(), "seiffert-dateien-%s" % UID)
STARTER_SOCKET = os.path.join(tempfile.gettempdir(), "seiffert-starter-%s" % UID)

# Metalltöne der Sorten (dieselben wie im Starter): (heller Schein, Grundton)
METAL = {"app": ("#cfe6f5", "#6f9cb9"), "folder": ("#f6e3b0", "#b8873a"), "file": ("#e3d6f6", "#8a6fb5"),
         "text": ("#cdeedd", "#5b9876"), "system": ("#f8c9bd", "#b1523f")}
SKIN_COL = {"petrol": ("#245d73", "#6fb7cf"), "wald": ("#2b6a3d", "#7fc68f"), "bernstein": ("#85530a", "#e6b04f"),
            "beere": ("#8a2b5c", "#e69ac3"), "indigo": ("#3f4ba8", "#a3aef2"), "graphit": ("#38424d", "#b9c4d0"),
            "terrakotta": ("#9c3f26", "#f0a58c")}


# ---------------------------------------------------------------------------------------------- Einstellungen und Symbole
LOOKS = ("metall", "aurora", "hud", "obsidian")        # Aussehen des Starter-Symbols, folgt der Einstellung des Starters
NEON = {"app": "#35d0ff", "folder": "#ffb347", "file": "#b37bff", "text": "#4dffb0", "system": "#ff6a5c"}


def main_config() -> dict:
    """config.json von Seifferts Dateien, nur lesend: Farbdesign, Ordnerstil, Favoriten und Dateizuordnungen."""
    out = {"skin": "petrol", "folder_style": "flach", "folder_color": "design", "favorites": [], "assoc": {}, "starter_look": "metall"}
    try:
        with open(SC.config_dir() / "config.json", encoding="utf-8") as f:
            stored = json.load(f)
        if isinstance(stored, dict):
            out.update({k: stored[k] for k in out if k in stored})
            look = (stored.get("starter") or {}).get("look") if isinstance(stored.get("starter"), dict) else None
            if look in LOOKS:
                out["starter_look"] = look
    except (OSError, ValueError):
        pass
    return out


def xdg_desktop_dir() -> str:
    home = os.path.expanduser("~")
    f = os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config"), "user-dirs.dirs")
    try:
        import re
        for line in open(f, encoding="utf-8"):
            m = re.match(r'XDG_DESKTOP_DIR="?([^"]*)"?', line.strip())
            if m:
                return m.group(1).replace("$HOME", home)
    except OSError:
        pass
    for n in ("Desktop", "Schreibtisch"):
        if os.path.isdir(os.path.join(home, n)):
            return os.path.join(home, n)
    return os.path.join(home, "Desktop")


@dataclass
class Item:
    kind: str            # dir | file | launcher | url
    name: str
    path: str            # Pfad oder Adresse
    ext: str = ""
    color: str = ""      # Favoritenfarbe (nur Favoriten)
    icon: str = ""       # Icon-Name aus .desktop-Dateien


def read_launcher(path: str) -> tuple[str, str]:
    """(Name, Icon) aus einer .desktop-Datei."""
    name = icon = ""
    try:
        sec = False
        for line in open(path, encoding="utf-8", errors="replace"):
            s = line.strip()
            if s.startswith("["):
                sec = s == "[Desktop Entry]"
            elif sec and "=" in s and not s.startswith("#"):
                k, v = s.split("=", 1)
                if k == "Name[de]" or (k == "Name" and not name):
                    name = v.strip() if k == "Name[de]" or not name else name
                elif k == "Icon":
                    icon = v.strip()
    except OSError:
        pass
    return name, icon


def make_item(path: str, name: str = "", color: str = "") -> Item:
    name = name or os.path.basename(path.rstrip("/")) or path
    if os.path.isdir(path):
        return Item("dir", name, path, color=color)
    ext = os.path.splitext(path)[1].lower().lstrip(".")
    if ext == "desktop":
        n, icon = read_launcher(path)
        return Item("launcher", n or os.path.splitext(name)[0], path, ext, color, icon)
    return Item("file", name, path, ext, color)


def list_items(conf: dict, mcfg: dict) -> list[Item]:
    """Die Symbole des Schreibtischs: Schreibtisch-Ordner und/oder Favoriten, sortiert nach den Einstellungen."""
    items: list[Item] = []
    seen: set[str] = set()
    src = conf["icons_source"]
    if src in ("desktop", "both"):
        d = xdg_desktop_dir()
        try:
            names = os.listdir(d)
        except OSError:
            names = []
        own = []
        for n in names:
            if n.startswith(".") and not conf["hidden"]:
                continue
            p = os.path.join(d, n)
            own.append(make_item(p, n))
        def key(it: Item):
            try:
                mt = -os.stat(it.path).st_mtime
            except OSError:
                mt = 0.0
            k = {"name": (it.name.casefold(),), "type": (it.ext, it.name.casefold()), "mtime": (mt, it.name.casefold())}[conf["sort"]]
            return ((0 if it.kind == "dir" else 1) if conf["dirs_first"] else 0,) + k
        own.sort(key=key)
        for it in own:
            items.append(it)
            seen.add(it.path)
    if src in ("favorites", "both"):
        for f in mcfg.get("favorites") or []:
            if not isinstance(f, dict):
                continue
            target, title, color = str(f.get("target", "")), str(f.get("title", "")), str(f.get("color", ""))
            if not target or target in seen:
                continue
            if f.get("kind") == "url":
                items.append(Item("url", title or target, target, color=color))
            else:
                it = make_item(target, title, color)
                if it.kind == "launcher":
                    it.name = title or it.name
                items.append(it)
            seen.add(target)
    return items


# ---------------------------------------------------------------------------------------------- Anordnung
def cell_geometry(conf: dict) -> tuple[int, int, int]:
    px = conf["icon_px"]
    cw = max(px + 30, 92) if conf["labels"] else px + 20
    ch = px + (46 if conf["labels"] else 14) + 14
    return cw, ch, conf["spacing"]


def starter_rect(conf: dict, w: int, h: int) -> tuple[int, int, int, int] | None:
    if not conf["show_starter"]:
        return None
    s = conf["starter_px"]
    ml, mt, mr, mb = conf["margin_left"], conf["margin_top"], conf["margin_right"], conf["margin_bottom"]
    c = conf["starter_corner"]
    x = ml if c in ("tl", "bl") else w - mr - s
    y = mt if c in ("tl", "tr") else h - mb - s
    return (x, y, s, s)


WEEKDAYS = ("Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag")
MONTHS = ("Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember")


def clock_strings(conf: dict, now) -> tuple[str, str]:
    """Uhrzeit und Datum als Text (Datum immer deutsch, unabhängig von der Spracheinstellung des Systems)."""
    h, m, s = now.hour, now.minute, now.second
    if conf["clock_24h"]:
        t = "%02d:%02d" % (h, m)
        if conf["clock_seconds"]:
            t += ":%02d" % s
    else:
        t = "%d:%02d" % (h % 12 or 12, m)
        if conf["clock_seconds"]:
            t += ":%02d" % s
        t += " AM" if h < 12 else " PM"
    d = "%s, %d. %s" % (WEEKDAYS[now.weekday()], now.day, MONTHS[now.month - 1])
    return t, d


def clock_angles(now, seconds: bool) -> tuple[float, float, float]:
    """Winkel von Stunden-, Minuten- und Sekundenzeiger in Bogenmaß, von 12 Uhr im Uhrzeigersinn gemessen."""
    s = now.second if seconds else 0
    minute = now.minute + s / 60.0
    hour = (now.hour % 12) + minute / 60.0
    tau = 2 * math.pi
    return hour / 12.0 * tau, minute / 60.0 * tau, s / 60.0 * tau


def clock_next_ms(conf: dict, now) -> int:
    """Wartezeit bis zur nächsten sichtbaren Änderung (volle Sekunde mit Sekunden, sonst volle Minute)."""
    micro = now.microsecond // 1000
    if conf["clock_seconds"]:
        ms = 1000 - micro
    else:
        ms = (60 - now.second) * 1000 - micro
    return max(50, ms + 20)


def clock_fonts(conf: dict) -> tuple[int, int]:
    """Schriftgröße der Uhrzeit und des Datums in Pixeln."""
    s = conf["clock_px"]
    return s, max(10, int(round(s * 0.28)))


def clock_rect(conf: dict, w: int, h: int, starter: tuple | None = None) -> tuple[int, int, int, int] | None:
    """Platz der Uhr (x, y, Breite, Höhe). Steht sie auf dem Starter-Symbol, weicht sie nach innen aus."""
    if not conf["clock_on"]:
        return None
    s, fd = clock_fonts(conf)
    chars = 5 + (3 if conf["clock_seconds"] else 0) + (3 if not conf["clock_24h"] else 0)
    date_h = int(fd * 1.5) + 4 if conf["clock_date"] else 0
    date_w = int(25 * fd * 0.52) if conf["clock_date"] else 0
    if conf["clock_style"] == "analog":
        d = 3 * s
        cw, ch = max(d, date_w), d + date_h
    else:
        cw, ch = max(int(chars * s * 0.6), date_w), int(s * 1.25) + date_h
    ml, mt, mr, mb = conf["margin_left"], conf["margin_top"], conf["margin_right"], conf["margin_bottom"]
    c = conf["clock_corner"]
    if c in ("tl", "bl"):
        x = ml
    elif c in ("tr", "br"):
        x = w - mr - cw
    else:
        x = (w - cw) // 2
    if c in ("tl", "tc", "tr"):
        y = mt
    elif c in ("bl", "br"):
        y = h - mb - ch
    else:
        y = (h - ch) // 2
    r = (max(0, x), max(0, y), cw, ch)
    if starter and _hit(r, starter):
        y2 = starter[1] - 8 - ch if c in ("bl", "br", "c") else starter[1] + starter[3] + 8
        r = (r[0], max(0, y2), cw, ch)
    return r


def _hit(r, q) -> bool:
    return not (r[0] + r[2] <= q[0] or q[0] + q[2] <= r[0] or r[1] + r[3] <= q[1] or q[1] + q[3] <= r[1])


def layout(n: int, conf: dict, w: int, h: int, reserve: tuple | None = None) -> list[tuple[int, int, int, int]]:
    """Positionen der Symbole (x, y, Breite, Höhe) in logischen Pixeln. Symbole, die nicht mehr auf die Fläche passen, fehlen."""
    cw, ch, gap = cell_geometry(conf)
    x0, y0 = conf["margin_left"], conf["margin_top"]
    x1, y1 = w - conf["margin_right"], h - conf["margin_bottom"]
    sx, sy = cw + gap, ch + gap
    pad = 6
    if reserve and isinstance(reserve[0], (int, float)):
        reserve = [reserve]                            # eine einzelne Sperrfläche
    ress = [(q[0] - pad, q[1] - pad, q[2] + 2 * pad, q[3] + 2 * pad) for q in (reserve or []) if q]
    out: list[tuple[int, int, int, int]] = []
    down = conf["flow"] == "down"
    x, y = x0, y0
    for _ in range(100000):
        if len(out) >= n:
            break
        if down:
            if y + ch > y1 and y > y0:
                y, x = y0, x + sx
        else:
            if x + cw > x1 and x > x0:
                x, y = x0, y + sy
        if x + cw > w or y + ch > h:
            break                                      # außerhalb der Fläche: der Rest passt nicht mehr
        r = (x, y, cw, ch)
        if any(_hit(r, res) for res in ress):
            if down:
                y += sy
            else:
                x += sx
            continue
        out.append(r)
        if down:
            y += sy
        else:
            x += sx
    return out


def hit_index(rects: list, px: float, py: float) -> int:
    for i, r in enumerate(rects):
        if r[0] <= px < r[0] + r[2] and r[1] <= py < r[1] + r[3]:
            return i
    return -1


def neighbor(rects: list, sel: int, dx: int, dy: int) -> int:
    """Nächstes Symbol in Pfeilrichtung (für die Tastatur)."""
    if not rects:
        return -1
    if sel < 0 or sel >= len(rects):
        return 0
    cx, cy = rects[sel][0] + rects[sel][2] / 2, rects[sel][1] + rects[sel][3] / 2
    best, bd = -1, 1e18
    for i, r in enumerate(rects):
        if i == sel:
            continue
        rx, ry = r[0] + r[2] / 2 - cx, r[1] + r[3] / 2 - cy
        if dx and (rx * dx <= 0 or abs(ry) > abs(rx) * 2.5 + r[3]):
            continue
        if dy and (ry * dy <= 0 or abs(rx) > abs(ry) * 2.5 + r[2]):
            continue
        d = rx * rx + ry * ry
        if d < bd:
            best, bd = i, d
    return best if best >= 0 else sel


# ---------------------------------------------------------------------------------------------- Öffnen und Starten
def starter_cmd() -> list[str]:
    env = os.environ.get("SEIFFERT_STARTER_CMD")
    if env:
        return env.split()
    for p in (os.path.expanduser("~/.local/bin/seiffert-starter"), shutil.which("seiffert-starter")):
        if p and os.access(p, os.X_OK):
            return [p]
    return [shutil.which("python3") or "python3", os.path.join(HERE, "starter.py")]


def dateien_cmd() -> list[str]:
    env = os.environ.get("SEIFFERT_DATEIEN_CMD")
    if env:
        return env.split()
    for p in (os.path.expanduser("~/.local/bin/seiffert-dateien"), shutil.which("seiffert-dateien")):
        if p and os.access(p, os.X_OK):
            return [p]
    return [shutil.which("python3") or "python3", os.path.join(HERE, "app.py")]


def spawn(argv: list[str]) -> bool:
    env = dict(os.environ)
    if env.pop("SEIFFERT_PRELOADED", None):                 # LD_PRELOAD galt nur für diesen Prozess, nicht für gestartete Programme
        env.pop("LD_PRELOAD", None)
    try:
        subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True,
                         cwd=os.path.expanduser("~"), env=env)
        return True
    except OSError as e:
        sys.stderr.write("%s: Start nicht möglich (%s): %s\n" % (NAME, " ".join(argv), e))
        return False


def send(path: str, text: str, timeout: float = 0.4) -> bool:
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(timeout)
    try:
        s.connect(path)
        s.sendall(text.encode("utf-8"))
        return True
    except OSError:
        return False
    finally:
        s.close()


def is_running(path: str) -> bool:
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(0.4)
    try:
        s.connect(path)
        return True
    except OSError:
        return False
    finally:
        s.close()


def open_in_dateien(path: str, select: str | None = None) -> bool:
    """Ordner in Seifferts Dateien öffnen: laufende Instanz (gleiche Nachricht wie der Starter) oder neuer Start."""
    if send(DATEIEN_SOCKET, path + ("\x1f" + select if select else "")):
        return True
    return spawn(dateien_cmd() + [path])


def open_dateien_settings(what: str = "surface") -> bool:
    """Seifferts Dateien mit dem Einstellungsdialog der Oberfläche öffnen."""
    if send(DATEIEN_SOCKET, "\x1dsettings\x1f" + what):
        return True
    return spawn(dateien_cmd() + ["--settings=" + what])


def ensure_starter() -> None:
    if not is_running(STARTER_SOCKET):
        spawn(starter_cmd() + ["--daemon"])


# ---------------------------------------------------------------------------------------------- Oberfläche (GTK)
def load_gtk():
    """Importiert GTK erst hier, damit Anordnung und Einstellungen ohne GTK testbar sind."""
    import gi
    gi.require_version("Gtk", "3.0")
    gi.require_version("Gdk", "3.0")
    try:
        gi.require_version("GtkLayerShell", "0.1")
        from gi.repository import GtkLayerShell as LS
    except (ValueError, ImportError):
        LS = None
    gi.require_version("Pango", "1.0")
    gi.require_version("PangoCairo", "1.0")
    from gi.repository import Gdk, GdkPixbuf, Gio, GLib, GObject, Gtk, Pango, PangoCairo
    import cairo
    return gi, Gtk, Gdk, GdkPixbuf, Gio, GLib, GObject, Pango, PangoCairo, cairo, LS


def build_ui():
    gi, Gtk, Gdk, GdkPixbuf, Gio, GLib, GObject, Pango, PangoCairo, cairo, LS = load_gtk()
    import foldericons as FI
    import icongen as IG
    import backend as B
    from apps import Apps

    class Light(Apps):
        """Nur die Programmzuordnung von Seifferts Dateien (ohne Index, Datenbank und Fenster)."""
        def __init__(self, cfg: dict) -> None:
            self.cfg = cfg

        def _mime_of(self, path: str) -> str:
            return Gio.content_type_guess(path, None)[0] or ""

    def rgba(cr, hexs: str, a: float = 1.0) -> None:
        h = hexs.lstrip("#")
        cr.set_source_rgba(int(h[0:2], 16) / 255, int(h[2:4], 16) / 255, int(h[4:6], 16) / 255, a)

    def rounded(cr, x, y, w, h, r) -> None:
        r = min(r, w / 2, h / 2)
        cr.new_sub_path()
        cr.arc(x + w - r, y + r, r, -math.pi / 2, 0)
        cr.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
        cr.arc(x + r, y + h - r, r, math.pi / 2, math.pi)
        cr.arc(x + r, y + r, r, math.pi, 3 * math.pi / 2)
        cr.close_path()

    class Icons:
        """Erzeugt und merkt sich die Symbole als cairo-Flächen (mit Geräteskalierung für HiDPI)."""

        def __init__(self, light: Light) -> None:
            self.light = light
            self.cache: dict = {}
            self.theme = Gtk.IconTheme.get_default()

        def clear(self) -> None:
            self.cache.clear()

        def _svg_pixbuf(self, data: bytes, px: int):
            ld = GdkPixbuf.PixbufLoader.new_with_type("svg")
            ld.set_size(px, px)
            ld.write(data)
            ld.close()
            return ld.get_pixbuf()

        def _surface(self, pb, scale: int):
            return Gdk.cairo_surface_create_from_pixbuf(pb, scale, None) if pb is not None else None

        def prog_pixbuf(self, icon: str, px: int):
            """Programmsymbol aus dem Symbolthema des Desktops (GTK), sonst über die Suche in den Symbolordnern."""
            if not icon:
                return None
            try:
                if os.path.isabs(icon):
                    return GdkPixbuf.Pixbuf.new_from_file_at_size(icon, px, px) if os.path.isfile(icon) else None
                info = self.theme.lookup_icon(icon, px, Gtk.IconLookupFlags.FORCE_SIZE)
                if info is not None:
                    return info.load_icon()
                p = IG.find_icon_file(icon)
                if p and p.lower().endswith((".svg", ".png")):
                    return GdkPixbuf.Pixbuf.new_from_file_at_size(p, px, px)
            except GLib.Error:
                return None
            return None

        def folder(self, style: str, base: str, px: int, scale: int):
            k = ("dir", style, base, px, scale)
            if k not in self.cache:
                try:
                    self.cache[k] = self._surface(self._svg_pixbuf(FI.svg_doc(style, base, px * scale), px * scale), scale)
                except GLib.Error:
                    self.cache[k] = None
            return self.cache[k]

        def extfile(self, ext: str, group: str, icon: str, px: int, scale: int):
            """Blatt mit Endung und, wenn vorhanden, dem Symbol des zugeordneten Programms (wie in Seifferts Dateien)."""
            k = ("ext", ext, group, icon, px, scale)
            if k in self.cache:
                return self.cache[k]
            S = px * scale
            try:
                prog = self.prog_pixbuf(icon, max(8, round(26 / 64 * S))) if icon else None
                page = self._svg_pixbuf(IG.ext_svg_doc(ext, group, with_prog=prog is not None, px=S), S)
                surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, S, S)
                cr = cairo.Context(surf)
                Gdk.cairo_set_source_pixbuf(cr, page, 0, 0)
                cr.paint()
                if prog is not None:
                    bx, by, bw, bh = [v / 64 * S for v in IG.PROG_BOX]
                    pw, ph = prog.get_width(), prog.get_height()
                    k2 = min(bw / pw, bh / ph)
                    cr.save()
                    cr.translate(bx + (bw - pw * k2) / 2, by + (bh - ph * k2) / 2)
                    cr.scale(k2, k2)
                    Gdk.cairo_set_source_pixbuf(cr, prog, 0, 0)
                    cr.paint()
                    cr.restore()
                surf.set_device_scale(scale, scale)
                self.cache[k] = surf
            except GLib.Error:
                self.cache[k] = None
            return self.cache[k]

        def program(self, icon: str, px: int, scale: int):
            k = ("prog", icon, px, scale)
            if k not in self.cache:
                self.cache[k] = self._surface(self.prog_pixbuf(icon, px * scale), scale)
            return self.cache[k]

        def thumb(self, path: str, px: int, scale: int):
            k = ("thumb", path, px, scale)
            if k not in self.cache:
                surf = None
                try:
                    if os.path.getsize(path) <= 12_000_000:
                        pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(path, px * scale, px * scale, True)
                        pb = pb.apply_embedded_orientation() or pb
                        surf = self._surface(pb, scale)
                except (GLib.Error, OSError):
                    surf = None
                self.cache[k] = surf
            return self.cache[k]

    class Desk(Gtk.Window):
        """Eine Fläche auf einem Bildschirm; die Fläche des Hauptbildschirms trägt Symbole und Starter-Symbol."""

        def __init__(self, app: "App", monitor, primary: bool) -> None:
            super().__init__(type=Gtk.WindowType.TOPLEVEL)
            self.app, self.monitor, self.primary = app, monitor, primary
            self.rects: list = []
            self.sel = self.hover = -1
            self.hover_starter = False
            self.backdrop = None
            self.backdrop_key = None
            self.set_title(NAME)
            self.set_decorated(False)
            self.set_app_paintable(True)
            self.set_skip_taskbar_hint(True)
            self.set_skip_pager_hint(True)
            self.set_accept_focus(True)
            geo = monitor.get_geometry()
            self.set_default_size(geo.width, geo.height)
            self.area = Gtk.DrawingArea()
            self.area.set_can_focus(True)
            self.area.add_events(Gdk.EventMask.BUTTON_PRESS_MASK | Gdk.EventMask.BUTTON_RELEASE_MASK | Gdk.EventMask.POINTER_MOTION_MASK
                                 | Gdk.EventMask.LEAVE_NOTIFY_MASK | Gdk.EventMask.KEY_PRESS_MASK)
            self.area.connect("draw", self.on_draw)
            self.area.connect("button-press-event", self.on_press)
            self.area.connect("button-release-event", self.on_release)
            self.area.connect("motion-notify-event", self.on_motion)
            self.area.connect("leave-notify-event", self.on_leave)
            self.area.connect("key-press-event", self.on_key)
            self.add(self.area)
            self.connect("key-press-event", self.on_key)
            self.connect("realize", lambda *_: None)
            self.pressed_starter = False
            self.clock_rc = None
            self.clock_src = 0
            self.connect("destroy", lambda *_: self.clock_stop())
            self.place()

        # ---- Fläche anlegen: Layer-Shell (Wayland) oder Desktop-Fenster (X11)
        def place(self) -> None:
            conf = self.app.conf
            geo = self.monitor.get_geometry()
            if self.app.layer_ok:
                LS.init_for_window(self)
                LS.set_namespace(self, "seiffert-oberflaeche")
                LS.set_layer(self, LS.Layer.BACKGROUND if conf["layer"] == "background" else LS.Layer.BOTTOM)
                for e in (LS.Edge.TOP, LS.Edge.BOTTOM, LS.Edge.LEFT, LS.Edge.RIGHT):
                    LS.set_anchor(self, e, True)
                LS.set_exclusive_zone(self, -1 if conf["extend"] else 0)
                LS.set_monitor(self, self.monitor)
                try:
                    LS.set_keyboard_mode(self, LS.KeyboardMode.ON_DEMAND)
                except (AttributeError, TypeError):
                    LS.set_keyboard_interactivity(self, True)
            elif self.app.x11:
                self.set_type_hint(Gdk.WindowTypeHint.DESKTOP)
                self.move(geo.x, geo.y)
                self.resize(geo.width, geo.height)
                self.stick()
                self.set_keep_below(True)
            else:                                                  # Wayland ohne Layer-Shell (zum Beispiel GNOME): Vollbild als Notlösung
                self.fullscreen_on_monitor(self.get_screen(), self.app.display_monitors().index(self.monitor))

        # ---- Hintergrund
        def make_backdrop(self, w: int, h: int, scale: int):
            conf = self.app.conf
            surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, w * scale, h * scale)
            surf.set_device_scale(scale, scale)
            cr = cairo.Context(surf)
            rgba(cr, conf["bg_color"])
            cr.paint()
            path = conf["bg_image"]
            if path and os.path.isfile(path):
                try:
                    W, H = w * scale, h * scale
                    fit = conf["bg_fit"]
                    info = GdkPixbuf.Pixbuf.get_file_info(path)
                    iw, ih = info[1], info[2]
                    if info[0] is None or iw <= 0 or ih <= 0:
                        raise GLib.Error("kein Bild")
                    cr.save()
                    cr.scale(1 / scale, 1 / scale)               # ab hier in Gerätepixeln
                    if fit in ("cover", "contain"):
                        k = max(W / iw, H / ih) if fit == "cover" else min(W / iw, H / ih)
                        tw, th = max(1, math.ceil(iw * k)), max(1, math.ceil(ih * k))
                        pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(path, tw, th, False)
                        Gdk.cairo_set_source_pixbuf(cr, pb, (W - tw) / 2, (H - th) / 2)
                        cr.paint()
                    elif fit == "stretch":
                        pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(path, W, H, False)
                        Gdk.cairo_set_source_pixbuf(cr, pb, 0, 0)
                        cr.paint()
                    elif fit == "center":
                        pb = GdkPixbuf.Pixbuf.new_from_file(path)
                        Gdk.cairo_set_source_pixbuf(cr, pb, (W - iw) / 2, (H - ih) / 2)
                        cr.paint()
                    else:                                         # tile
                        pb = GdkPixbuf.Pixbuf.new_from_file(path)
                        Gdk.cairo_set_source_pixbuf(cr, pb, 0, 0)
                        cr.get_source().set_extend(cairo.EXTEND_REPEAT)
                        cr.paint()
                    cr.restore()
                    if conf["bg_dim"] > 0:
                        cr.set_source_rgba(0, 0, 0, conf["bg_dim"] / 100)
                        cr.paint()
                except (GLib.Error, OSError, ValueError, TypeError) as e:
                    sys.stderr.write("%s: Hintergrundbild nicht lesbar (%s)\n" % (NAME, e))
            return surf

        def invalidate(self) -> None:
            self.backdrop = self.backdrop_key = None
            self.area.queue_draw()
            self.clock_restart()

        # ---- Zeichnen
        def on_draw(self, widget, cr) -> bool:
            conf = self.app.conf
            w, h = widget.get_allocated_width(), widget.get_allocated_height()
            scale = self.get_scale_factor()
            key = (w, h, scale, conf["bg_image"], conf["bg_fit"], conf["bg_color"], conf["bg_dim"])
            if self.backdrop is None or self.backdrop_key != key:
                self.backdrop, self.backdrop_key = self.make_backdrop(w, h, scale), key
            cr.set_source_surface(self.backdrop, 0, 0)
            cr.paint()
            if not self.primary:
                return True
            srect = starter_rect(conf, w, h)
            crect = clock_rect(conf, w, h, srect)
            self.clock_rc = crect
            items = self.app.items if conf["icons_on"] else []
            self.rects = layout(len(items), conf, w, h, [srect, crect]) if items else []
            if self.sel >= len(self.rects):
                self.sel = -1
            mc = self.app.mcfg
            acc = SKIN_COL.get(mc["skin"], SKIN_COL["petrol"])
            px = conf["icon_px"]
            light = conf["label_color"] == "hell"
            fd = Pango.FontDescription(self.area.get_pango_context().get_font_description().to_string())
            fd.set_size(int(max(8, min(14, 9 + (px - 48) / 24)) * Pango.SCALE))
            cx0, cy0, cx1, cy1 = cr.clip_extents()             # beim Zeittakt der Uhr ist das nur der Bereich der Uhr
            vis = lambda q: q[0] < cx1 and q[0] + q[2] > cx0 and q[1] < cy1 and q[1] + q[3] > cy0
            for i, (it, r) in enumerate(zip(items, self.rects)):
                x, y, cw, ch = r
                if not vis(r):
                    continue
                if i == self.sel or i == self.hover:
                    rounded(cr, x, y, cw, ch, 10)
                    cr.set_source_rgba(1, 1, 1, 0.22 if i == self.sel else 0.12)
                    cr.fill_preserve()
                    if i == self.sel:
                        rgba(cr, acc[1], 0.95)
                        cr.set_line_width(1.6)
                        cr.stroke()
                    else:
                        cr.new_path()
                ix, iy = x + (cw - px) / 2, y + 8
                surf = self.icon_for(it, mc, px, scale)
                if surf is not None:
                    cr.set_source_surface(surf, ix, iy)
                    cr.paint()
                if conf["labels"]:
                    lay = PangoCairo.create_layout(cr)
                    lay.set_font_description(fd)
                    lay.set_width(int((cw - 8) * Pango.SCALE))
                    lay.set_alignment(Pango.Alignment.CENTER)
                    lay.set_wrap(Pango.WrapMode.WORD_CHAR)
                    lay.set_ellipsize(Pango.EllipsizeMode.END)
                    lay.set_height(-2)
                    lay.set_text(it.name, -1)
                    tx, ty = x + 4, y + 8 + px + 6
                    cr.move_to(tx + 1, ty + 1)
                    cr.set_source_rgba(0, 0, 0, 0.75) if light else cr.set_source_rgba(1, 1, 1, 0.7)
                    PangoCairo.show_layout(cr, lay)
                    cr.move_to(tx, ty)
                    cr.set_source_rgba(1, 1, 1, 1) if light else cr.set_source_rgba(0.04, 0.07, 0.10, 1)
                    PangoCairo.show_layout(cr, lay)
            if srect and vis((srect[0] - srect[2], srect[1] - srect[3], 3 * srect[2], 3 * srect[3])):   # großzügig wegen des Leuchtrands
                self.draw_starter(cr, srect, acc)
            if crect and vis((crect[0] - 4, crect[1] - 4, crect[2] + 8, crect[3] + 8)):
                self.draw_clock(cr, crect, acc)
            return True

        # ---- Uhr
        def draw_clock(self, cr, rc, acc) -> None:
            """Zeichnet die Uhr; die Deckkraft gilt für die ganze Uhr gemeinsam (auch Schatten und Datum)."""
            conf = self.app.conf
            x, y, cw, ch = rc
            now = datetime.datetime.now()
            tstr, dstr = clock_strings(conf, now)
            col = self._rgb(conf["clock_color"])
            align = 0.0 if conf["clock_corner"] in ("tl", "bl") else 1.0 if conf["clock_corner"] in ("tr", "br") else 0.5
            s, fdate = clock_fonts(conf)
            analog = conf["clock_style"] == "analog"
            cr.save()
            cr.new_path()                                  # sonst verbindet arc() die Uhr mit dem letzten Textpunkt davor
            cr.push_group()
            ty = y
            if analog:
                dia = 3 * s
                cx, cy = x + (cw - dia) * align + dia / 2, y + dia / 2
                lw = max(1.5, dia / 70)
                r = dia / 2 - lw / 2 - 1                    # Rand samt Kantenglättung bleibt im Platz der Uhr
                cr.arc(cx, cy, r, 0, 2 * math.pi)
                cr.set_source_rgba(0, 0, 0, 0.30)
                cr.fill_preserve()
                cr.set_source_rgba(col[0], col[1], col[2], 0.9)
                cr.set_line_width(lw)
                cr.stroke()
                cr.set_line_cap(cairo.LINE_CAP_ROUND)
                for i in range(12):
                    a = i * math.pi / 6
                    big = i % 3 == 0
                    r0, r1 = r * (0.80 if big else 0.87), r * 0.94
                    cr.move_to(cx + math.sin(a) * r0, cy - math.cos(a) * r0)
                    cr.line_to(cx + math.sin(a) * r1, cy - math.cos(a) * r1)
                    cr.set_line_width(max(1.2, dia / (30 if big else 55)))
                    cr.set_source_rgba(col[0], col[1], col[2], 1)
                    cr.stroke()
                ah, am, asec = clock_angles(now, conf["clock_seconds"])
                for ang, ln, wd, c3 in ((ah, 0.48, dia / 28, col), (am, 0.72, dia / 40, col)):
                    cr.set_line_width(max(2.0, wd))
                    cr.set_source_rgba(c3[0], c3[1], c3[2], 1)
                    cr.move_to(cx, cy)
                    cr.line_to(cx + math.sin(ang) * r * ln, cy - math.cos(ang) * r * ln)
                    cr.stroke()
                if conf["clock_seconds"]:
                    sc = self._rgb(acc[1])
                    cr.set_line_width(max(1.2, dia / 90))
                    cr.set_source_rgba(sc[0], sc[1], sc[2], 1)
                    cr.move_to(cx - math.sin(asec) * r * 0.15, cy + math.cos(asec) * r * 0.15)
                    cr.line_to(cx + math.sin(asec) * r * 0.85, cy - math.cos(asec) * r * 0.85)
                    cr.stroke()
                cr.arc(cx, cy, max(2.5, dia / 40), 0, 2 * math.pi)
                cr.set_source_rgba(col[0], col[1], col[2], 1)
                cr.fill()
                ty = y + dia + 4
            else:
                lay = self.clock_layout(cr, tstr, s, cw, light=True)
                tw, th = lay.get_pixel_size()
                tx = x + (cw - tw) * align
                self.clock_text(cr, lay, tx, y, col, max(1.0, s / 38))
                ty = y + int(s * 1.25)
            if conf["clock_date"]:
                lay = self.clock_layout(cr, dstr, fdate, cw, light=False)
                tw, th = lay.get_pixel_size()
                self.clock_text(cr, lay, x + (cw - tw) * align, ty + 2, col, 1.0)
            cr.pop_group_to_source()
            cr.paint_with_alpha(conf["clock_opacity"] / 100.0)
            cr.restore()

        def clock_layout(self, cr, text: str, px: int, maxw: int, light: bool):
            """Textebene in absoluter Pixelgröße; zu breiter Text wird verkleinert, damit er in den Platz der Uhr passt."""
            lay = PangoCairo.create_layout(cr)
            fd = Pango.FontDescription(self.area.get_pango_context().get_font_description().to_string())
            fd.set_weight(Pango.Weight.LIGHT if light else Pango.Weight.NORMAL)
            fd.set_absolute_size(px * Pango.SCALE)
            lay.set_font_description(fd)
            try:
                attrs = Pango.AttrList()
                attrs.insert(Pango.attr_font_features_new("tnum"))     # gleich breite Ziffern: die Zeit springt nicht hin und her
                lay.set_attributes(attrs)
            except (AttributeError, TypeError):
                pass
            lay.set_text(text, -1)
            tw = lay.get_pixel_size()[0]
            if tw > maxw > 0:
                fd.set_absolute_size(max(6.0, px * maxw / tw) * Pango.SCALE)
                lay.set_font_description(fd)
            return lay

        @staticmethod
        def clock_text(cr, lay, x: float, y: float, col: tuple, shadow: float) -> None:
            cr.move_to(x + shadow, y + shadow * 1.4)
            cr.set_source_rgba(0, 0, 0, 0.55)
            PangoCairo.show_layout(cr, lay)
            cr.move_to(x, y)
            cr.set_source_rgba(col[0], col[1], col[2], 1)
            PangoCairo.show_layout(cr, lay)

        def clock_tick(self) -> bool:
            """Zeittakt: zeichnet nur den Bereich der Uhr neu und plant genau die nächste Änderung ein."""
            self.clock_src = 0
            conf = self.app.conf
            if not conf["clock_on"] or not self.primary:
                return False
            rc = self.clock_rc
            if rc:
                self.area.queue_draw_area(int(rc[0]) - 4, int(rc[1]) - 4, int(rc[2]) + 8, int(rc[3]) + 8)
            self.clock_src = GLib.timeout_add(clock_next_ms(conf, datetime.datetime.now()), self.clock_tick)
            return False

        def clock_stop(self) -> None:
            if self.clock_src:
                GLib.source_remove(self.clock_src)
                self.clock_src = 0

        def clock_restart(self) -> None:
            if getattr(self, "clock_src", 0):
                GLib.source_remove(self.clock_src)
                self.clock_src = 0
            if self.primary and self.app.conf["clock_on"]:
                self.clock_src = GLib.timeout_add(clock_next_ms(self.app.conf, datetime.datetime.now()), self.clock_tick)

        def icon_for(self, it: Item, mc: dict, px: int, scale: int):
            ic = self.app.icons
            if it.kind == "dir":
                ok = len(it.color) == 7 and it.color.startswith("#") and all(c in "0123456789abcdefABCDEF" for c in it.color[1:])
                base = it.color if ok else FI.base_color(it.name, mc["folder_color"], SKIN_COL.get(mc["skin"], SKIN_COL["petrol"])[0])
                return ic.folder(mc["folder_style"], base, px, scale)
            if it.kind == "url":
                return ic.extfile("web", "", "", px, scale)
            if it.kind == "launcher":
                return ic.program(it.icon, px, scale) or ic.extfile("desktop", "text", "", px, scale)
            grp = B.FILE_TYPES.get(it.ext, ("other", ""))[0]
            if grp == "image" or it.ext == "svg":
                t = ic.thumb(it.path, px, scale)
                if t is not None:
                    return t
            app = self.app.light.app_for_path(it.path)
            return ic.extfile(it.ext, grp, (app or {}).get("icon", ""), px, scale)

        @staticmethod
        def _rgb(h: str) -> tuple:
            return tuple(int(h[i:i + 2], 16) / 255 for i in (1, 3, 5))

        def draw_starter_neon(self, cr, s: float, hov: bool, look: str) -> None:
            """Starter-Symbol in den Looks Aurora, Neon-HUD und Obsidian-Glas: dunkle Scheibe, Leuchtrand, fünf Leuchtpunkte im Ton der Sorten."""
            two_pi = 2 * math.pi
            R = s / 2 - 1.5
            if look == "aurora":
                body = cairo.RadialGradient(s * 0.38, s * 0.3, s * 0.05, s / 2, s / 2, s * 0.62)
                body.add_color_stop_rgba(0, 0.16, 0.12, 0.36, 0.98)
                body.add_color_stop_rgba(0.6, 0.055, 0.045, 0.15, 0.98)
                body.add_color_stop_rgba(1, 0.015, 0.01, 0.05, 0.99)
            elif look == "hud":
                body = cairo.LinearGradient(0, 0, s, s)
                body.add_color_stop_rgba(0, 0.05, 0.08, 0.11, 0.98)
                body.add_color_stop_rgba(1, 0.01, 0.02, 0.03, 0.99)
            else:
                body = cairo.LinearGradient(0, 0, s, s)
                body.add_color_stop_rgba(0, 0.11, 0.12, 0.15, 0.98)
                body.add_color_stop_rgba(0.5, 0.04, 0.045, 0.06, 0.98)
                body.add_color_stop_rgba(1, 0.01, 0.01, 0.015, 0.99)
            halo = {"aurora": (0.48, 0.36, 1.0), "hud": (0.21, 0.82, 1.0), "obsidian": (0.7, 0.48, 1.0)}[look]
            for i, a in ((6, 0.07), (4, 0.11), (2, 0.16)):                      # Leuchthof
                cr.new_path()
                cr.arc(s / 2, s / 2, R + i * (1.4 if hov else 1.0), 0, two_pi)
                cr.set_source_rgba(*halo, a * (1.5 if hov else 1.0))
                cr.fill()
            cr.new_path()
            cr.arc(s / 2, s / 2, R, 0, two_pi)
            cr.set_source(body)
            cr.fill()
            if look == "obsidian":
                gl = cairo.LinearGradient(0, s * 0.05, 0, s * 0.5)
                gl.add_color_stop_rgba(0, 1, 1, 1, 0.30)
                gl.add_color_stop_rgba(0.85, 1, 1, 1, 0.03)
                gl.add_color_stop_rgba(1, 1, 1, 1, 0)
                cr.save()
                cr.new_path()
                cr.scale(1, 0.5)
                cr.arc(s / 2, s * 0.5, s * 0.40, 0, two_pi)
                cr.restore()
                cr.set_source(gl)
                cr.fill()
            if look == "hud":
                cr.set_line_width(1.0)
                y = s * 0.12
                while y < s * 0.9:                                              # Rasterlinien
                    half = math.sqrt(max(0.0, R * R - (y - s / 2) ** 2)) - 2
                    cr.move_to(s / 2 - half, y)
                    cr.line_to(s / 2 + half, y)
                    y += 3.5
                cr.set_source_rgba(0.21, 0.82, 1.0, 0.08)
                cr.stroke()
                cr.new_path()
                cr.arc(s / 2, s / 2, R - 3.5, 0, two_pi)
                cr.set_dash([R * 0.34, R * 0.12])                               # Ring aus Segmenten
                cr.set_line_width(1.8)
                cr.set_source_rgba(0.21, 0.82, 1.0, 0.85)
                cr.stroke()
                cr.set_dash([])
            rim = cairo.LinearGradient(0, 0, s, s)
            if look == "hud":
                for pos in (0.0, 1.0):
                    rim.add_color_stop_rgba(pos, 0.68, 0.92, 1.0, 1.0 if hov else 0.92)
            else:
                for pos, col_ in ((0.0, "#35d0ff"), (0.3, "#4f7bff"), (0.55, "#b37bff"), (0.78, "#ff5fd2"), (1.0, "#ffb347")):
                    rim.add_color_stop_rgba(pos, *self._rgb(col_), 1.0 if hov else 0.92)
            cr.new_path()
            cr.arc(s / 2, s / 2, R, 0, two_pi)
            cr.set_source(rim)
            cr.set_line_width(2.4 if hov else 1.9)
            cr.stroke()
            for (cx, cy, r, kind) in ((0.50, 0.52, 0.17, "app"), (0.30, 0.34, 0.10, "folder"), (0.72, 0.33, 0.095, "file"), (0.69, 0.75, 0.09, "text"),
                                      (0.27, 0.69, 0.08, "system")):
                c = self._rgb(NEON[kind])
                for k, a in ((2.4, 0.16), (1.7, 0.26), (1.25, 0.4)):            # Leuchten
                    cr.new_path()
                    cr.arc(cx * s, cy * s, r * s * k, 0, two_pi)
                    cr.set_source_rgba(*c, a * 0.6)
                    cr.fill()
                bg = cairo.RadialGradient((cx - r * 0.2) * s, (cy - r * 0.25) * s, r * s * 0.05, cx * s, cy * s, r * s)
                bg.add_color_stop_rgba(0, 1, 1, 1, 1)
                bg.add_color_stop_rgba(0.35, *c, 1)
                bg.add_color_stop_rgba(1, c[0] * 0.55, c[1] * 0.55, c[2] * 0.55, 1)
                cr.new_path()
                cr.arc(cx * s, cy * s, r * s, 0, two_pi)
                cr.set_source(bg)
                cr.fill()

        def draw_starter(self, cr, rc, acc) -> None:
            """Starter-Symbol ohne Beschriftung: anthrazitfarbene Glasscheibe mit Chromrand und fünf metallischen Kugeln im Ton der Sorten."""
            x, y, s, _ = rc
            hov = self.hover_starter
            k = 1.07 if hov else 1.0
            cr.save()
            cr.translate(x + s / 2, y + s / 2)
            cr.scale(k, k)
            cr.translate(-s / 2, -s / 2)
            for i, a in ((4, 0.10), (3, 0.14), (2, 0.2)):                  # weicher Schatten
                cr.new_path()
                cr.arc(s / 2, s / 2 + s * 0.07, s / 2 - 1 + i * 0.8, 0, 2 * math.pi)
                cr.set_source_rgba(0, 0, 0, a)
                cr.fill()
            look = self.app.mcfg.get("starter_look", "metall")
            if look in LOOKS and look != "metall":
                self.draw_starter_neon(cr, s, hov, look)
                cr.restore()
                return
            body = cairo.LinearGradient(s * 0.2, 0, s * 0.8, s)
            for pos, col_, al in ((0.0, "#7b8591", 0.97), (0.30, "#434a53", 0.97), (0.62, "#1c2024", 0.97), (1.0, "#07080a", 0.98)):
                h = col_.lstrip("#")
                body.add_color_stop_rgba(pos, int(h[0:2], 16) / 255, int(h[2:4], 16) / 255, int(h[4:6], 16) / 255, al)
            cr.new_path()
            cr.arc(s / 2, s / 2, s / 2 - 1.5, 0, 2 * math.pi)
            cr.set_source(body)
            cr.fill()
            gl = cairo.LinearGradient(0, s * 0.05, 0, s * 0.55)                 # Glanzkuppel
            gl.add_color_stop_rgba(0, 1, 1, 1, 0.34)
            gl.add_color_stop_rgba(0.85, 1, 1, 1, 0.04)
            gl.add_color_stop_rgba(1, 1, 1, 1, 0)
            cr.save()
            cr.new_path()
            cr.scale(1, 0.5)
            cr.arc(s / 2, s * 0.5, s * 0.40, 0, 2 * math.pi)
            cr.restore()
            cr.set_source(gl)
            cr.fill()
            rim = cairo.LinearGradient(0, 0, s, s)                               # Chromrand
            for pos, col_ in ((0.0, "#ffffff"), (0.18, "#c4ccd4"), (0.36, "#5c646d"), (0.52, "#e8edf2"), (0.7, "#4a525a"), (0.86, "#b7c0c9"), (1.0, "#ffffff")):
                h = col_.lstrip("#")
                rim.add_color_stop_rgba(pos, int(h[0:2], 16) / 255, int(h[2:4], 16) / 255, int(h[4:6], 16) / 255, 1.0 if hov else 0.92)
            cr.new_path()
            cr.arc(s / 2, s / 2, s / 2 - 1.5, 0, 2 * math.pi)
            cr.set_source(rim)
            cr.set_line_width(2.4 if hov else 1.9)
            cr.stroke()
            for (cx, cy, r, kind) in ((0.50, 0.52, 0.21, "app"), (0.30, 0.34, 0.125, "folder"), (0.72, 0.33, 0.115, "file"), (0.69, 0.75, 0.105, "text"),
                                      (0.27, 0.69, 0.095, "system")):
                lite, mid = METAL[kind]
                ll = [int(lite[i:i + 2], 16) / 255 for i in (1, 3, 5)]
                mm = [int(mid[i:i + 2], 16) / 255 for i in (1, 3, 5)]
                bg = cairo.RadialGradient((cx - r * 0.35) * s, (cy - r * 0.42) * s, r * s * 0.08, cx * s, cy * s, r * s)
                bg.add_color_stop_rgba(0, 1, 1, 1, 1)
                bg.add_color_stop_rgba(0.22, ll[0], ll[1], ll[2], 1)
                bg.add_color_stop_rgba(0.62, mm[0], mm[1], mm[2], 1)
                bg.add_color_stop_rgba(1, mm[0] * 0.35, mm[1] * 0.35, mm[2] * 0.35, 1)
                cr.new_path()
                cr.arc(cx * s, cy * s + r * s * 0.12, r * s, 0, 2 * math.pi)     # kleiner Schatten unter der Kugel
                cr.set_source_rgba(0, 0, 0, 0.35)
                cr.fill()
                cr.new_path()
                cr.arc(cx * s, cy * s, r * s, 0, 2 * math.pi)
                cr.set_source(bg)
                cr.fill_preserve()
                cr.set_source_rgba(0, 0, 0, 0.45)
                cr.set_line_width(0.8)
                cr.stroke()
            cr.restore()

        # ---- Maus
        def starter_hit(self, px: float, py: float) -> bool:
            sr = starter_rect(self.app.conf, self.area.get_allocated_width(), self.area.get_allocated_height()) if self.primary else None
            return bool(sr) and (px - sr[0] - sr[2] / 2) ** 2 + (py - sr[1] - sr[3] / 2) ** 2 <= (sr[2] / 2) ** 2

        def on_motion(self, _w, ev) -> bool:
            if not self.primary:
                return False
            hs = self.starter_hit(ev.x, ev.y)
            n = -1 if hs else hit_index(self.rects, ev.x, ev.y)
            if n != self.hover or hs != self.hover_starter:
                self.hover, self.hover_starter = n, hs
                self.area.queue_draw()
            return True

        def on_leave(self, _w, _ev) -> bool:
            if self.hover != -1 or self.hover_starter:
                self.hover, self.hover_starter = -1, False
                self.area.queue_draw()
            return False

        def on_press(self, _w, ev) -> bool:
            if os.environ.get("SEIFFERT_DEBUG"):
                sys.stderr.write("press %s %.0f,%.0f\n" % (ev.button, ev.x, ev.y))
            self.area.grab_focus()
            if not self.primary:
                if ev.button == 3 and ev.type == Gdk.EventType.BUTTON_PRESS:
                    self.app.context_menu(self, ev, -1)
                return True
            if ev.button == 1 and ev.type == Gdk.EventType.BUTTON_PRESS and self.starter_hit(ev.x, ev.y):
                self.pressed_starter = True
                return True
            n = hit_index(self.rects, ev.x, ev.y)
            if ev.button == 3:
                if ev.type == Gdk.EventType.BUTTON_PRESS:
                    if n >= 0:
                        self.sel = n
                        self.area.queue_draw()
                    self.app.context_menu(self, ev, n)
                return True
            if ev.button == 1:
                if n != self.sel:
                    self.sel = n
                    self.area.queue_draw()
                if n >= 0 and ev.type == Gdk.EventType.DOUBLE_BUTTON_PRESS and not self.app.conf["single_click"]:
                    self.app.open_item(self.app.items[n])
            return True

        def on_release(self, _w, ev) -> bool:
            if ev.button != 1:
                return False
            if self.pressed_starter:
                self.pressed_starter = False
                if self.starter_hit(ev.x, ev.y):
                    self.app.run_starter()
                return True
            if self.primary and self.app.conf["single_click"]:
                n = hit_index(self.rects, ev.x, ev.y)
                if n >= 0 and n == self.sel:
                    self.app.open_item(self.app.items[n])
            return True

        # ---- Tastatur
        def on_key(self, _w, ev) -> bool:
            conf = self.app.conf
            name = Gdk.keyval_name(ev.keyval) or ""
            alt = bool(ev.state & Gdk.ModifierType.MOD1_MASK)
            if os.environ.get("SEIFFERT_DEBUG"):
                sys.stderr.write("key %s alt=%s\n" % (name, alt))
            if alt and name.lower() == "x" and conf["alt_x"]:
                self.app.quit()
                return True
            if not self.primary:
                return False
            if name in ("Left", "Right", "Up", "Down"):
                dx = {"Left": -1, "Right": 1}.get(name, 0)
                dy = {"Up": -1, "Down": 1}.get(name, 0)
                self.sel = neighbor(self.rects, self.sel, dx, dy)
                self.area.queue_draw()
                return True
            if name in ("Return", "KP_Enter") and 0 <= self.sel < len(self.app.items):
                self.app.open_item(self.app.items[self.sel])
                return True
            if name == "Escape":
                self.sel = -1
                self.area.queue_draw()
                return True
            if name == "F5":
                self.app.reload()
                return True
            if name in ("Menu",):
                self.app.context_menu(self, ev, self.sel)
                return True
            return False

    class App:
        def __init__(self, opts: dict) -> None:
            self.opts = opts
            self.conf = SC.load()
            self.mcfg = main_config()
            self.light = Light(self.mcfg)
            self.icons = Icons(self.light)
            self.items: list[Item] = []
            self.desks: list[Desk] = []
            self.display = Gdk.Display.get_default()
            self.wayland = GObject.type_name(self.display.__gtype__) == "GdkWaylandDisplay"
            self.x11 = not self.wayland and "X11" in GObject.type_name(self.display.__gtype__)
            self.layer_ok = bool(LS) and self.wayland and LS.is_supported() and not opts.get("no_layer")
            self.timer = 0
            self.mons = []
            self.sock = None
            self.menu = None

        def display_monitors(self) -> list:
            return [self.display.get_monitor(i) for i in range(self.display.get_n_monitors())]

        # ---- Flächen
        def build_desks(self) -> None:
            for d in self.desks:
                d.destroy()
            self.desks = []
            mons = self.display_monitors()
            if not mons:
                return
            prim = self.display.get_primary_monitor() or mons[0]
            use = [prim] if self.conf["monitors"] == "primary" else mons
            for m in use:
                d = Desk(self, m, m == prim)
                self.desks.append(d)
                d.show_all()

        def refresh_all(self) -> None:
            self.items = list_items(self.conf, self.mcfg)
            self.icons.clear()
            for d in self.desks:
                d.invalidate()

        # ---- Einstellungen laufend beobachten
        def watch(self) -> None:
            self.mons = []
            for path, cb in ((str(SC.config_dir()), self.on_cfg_event), (xdg_desktop_dir(), self.on_desktop_event)):
                try:
                    os.makedirs(path, exist_ok=True) if path == str(SC.config_dir()) else None
                    m = Gio.File.new_for_path(path).monitor_directory(Gio.FileMonitorFlags.WATCH_MOVES, None)
                    m.connect("changed", cb)
                    self.mons.append(m)
                except GLib.Error as e:
                    sys.stderr.write("%s: Ordner nicht beobachtbar (%s): %s\n" % (NAME, path, e.message))
            try:                                               # logind meldet das Aufwachen; ohne logind bleibt es beim normalen Takt
                self.bus = Gio.bus_get_sync(Gio.BusType.SYSTEM, None)
                self.bus.signal_subscribe("org.freedesktop.login1", "org.freedesktop.login1.Manager", "PrepareForSleep",
                                          "/org/freedesktop/login1", None, Gio.DBusSignalFlags.NONE, self.on_sleep)
            except GLib.Error:
                self.bus = None
            self.display.connect("monitor-added", lambda *_: self.later(self.rebuild))
            self.display.connect("monitor-removed", lambda *_: self.later(self.rebuild))

        def on_sleep(self, _c, _s, _p, _i, _n, params, *_a) -> None:
            if not params.unpack()[0]:                         # False = der Rechner ist wieder wach
                self.clock_now()

        def clock_now(self) -> None:
            """Uhr sofort neu zeichnen und den Takt neu ausrichten (nach dem Aufwachen steht sonst bis zu einer Minute die alte Zeit da)."""
            for d in self.desks:
                if d.primary and self.conf["clock_on"]:
                    d.clock_stop()
                    d.clock_tick()

        def later(self, fn, ms: int = 250) -> None:
            if self.timer:
                GLib.source_remove(self.timer)
            def run():
                self.timer = 0
                fn()
                return False
            self.timer = GLib.timeout_add(ms, run)

        def on_cfg_event(self, _m, f, other, _ev) -> None:
            names = {f.get_basename(), other.get_basename() if other else ""}
            if names & {"surface.json", "config.json"}:
                self.later(self.reload)

        def on_desktop_event(self, *_a) -> None:
            self.later(self.reload)

        def rebuild(self) -> None:
            self.build_desks()
            self.refresh_all()

        def reload(self) -> None:
            old = self.conf
            self.conf = SC.load()
            self.mcfg = main_config()
            self.light.cfg = self.mcfg
            if any(old[k] != self.conf[k] for k in ("layer", "monitors", "extend")):
                self.rebuild()
            else:
                self.refresh_all()
            if self.conf["show_starter"] and self.conf["starter_ready"]:
                ensure_starter()

        # ---- Aktionen
        def launch_context(self):
            try:
                return self.display.get_app_launch_context()
            except Exception:  # noqa: BLE001
                return None

        def open_item(self, it: Item) -> None:
            try:
                if it.kind == "dir":
                    open_in_dateien(it.path)
                elif it.kind == "url":
                    Gio.AppInfo.launch_default_for_uri(it.path, self.launch_context())
                elif it.kind == "launcher":
                    ai = Gio.DesktopAppInfo.new_from_filename(it.path)
                    if ai is not None:
                        ai.launch([], self.launch_context())
                else:
                    uri = Gio.File.new_for_path(it.path).get_uri()
                    app = self.light.app_for_path(it.path)
                    ai = Gio.DesktopAppInfo.new(app["id"]) if app else None
                    if ai is not None:
                        ai.launch_uris([uri], self.launch_context())
                    else:
                        Gio.AppInfo.launch_default_for_uri(uri, self.launch_context())
            except GLib.Error as e:
                sys.stderr.write("%s: %s lässt sich nicht öffnen: %s\n" % (NAME, it.path, e.message))

        def run_starter(self) -> None:
            spawn(starter_cmd())

        def choose_background(self) -> None:
            dlg = Gtk.FileChooserDialog(title="Hintergrundbild wählen", action=Gtk.FileChooserAction.OPEN)
            dlg.add_buttons("Abbrechen", Gtk.ResponseType.CANCEL, "Wählen", Gtk.ResponseType.OK)
            flt = Gtk.FileFilter()
            flt.set_name("Bilder")
            flt.add_pixbuf_formats()
            dlg.add_filter(flt)
            cur = self.conf["bg_image"]
            dlg.set_current_folder(os.path.dirname(cur) if cur and os.path.isdir(os.path.dirname(cur)) else os.path.expanduser("~/Bilder")
                                   if os.path.isdir(os.path.expanduser("~/Bilder")) else os.path.expanduser("~"))
            if dlg.run() == Gtk.ResponseType.OK:
                try:
                    SC.update({"bg_image": dlg.get_filename()})
                except ValueError as e:
                    sys.stderr.write("%s: %s\n" % (NAME, e))
            dlg.destroy()
            self.reload()

        def context_menu(self, desk, ev, n: int) -> None:
            m = Gtk.Menu()
            self.menu = m

            def add(label, fn, sens=True):
                mi = Gtk.MenuItem.new_with_label(label)
                mi.set_sensitive(sens)
                mi.connect("activate", lambda *_: fn())
                m.append(mi)
                return mi

            if 0 <= n < len(self.items):
                it = self.items[n]
                add("Öffnen", lambda: self.open_item(it))
                if it.kind in ("file", "launcher") and os.path.exists(it.path):
                    add("Ordner in Seifferts Dateien zeigen", lambda: open_in_dateien(os.path.dirname(it.path), select=it.path))
                m.append(Gtk.SeparatorMenuItem())
            add("Seifferts Starter", self.run_starter)
            add("Seifferts Dateien öffnen", lambda: open_in_dateien(os.path.expanduser("~")))
            add("Schreibtisch-Ordner öffnen", lambda: open_in_dateien(xdg_desktop_dir()))
            m.append(Gtk.SeparatorMenuItem())
            add("Aktualisieren", self.reload)
            add("Hintergrundbild wählen …", self.choose_background)
            add("Einstellungen der Oberfläche …", lambda: open_dateien_settings("surface"))
            m.append(Gtk.SeparatorMenuItem())
            add("Oberfläche beenden" + ("   Alt+X" if self.conf["alt_x"] else ""), self.quit)
            m.show_all()
            m.popup_at_pointer(ev)

        # ---- Steuerung von außen
        def listen(self) -> None:
            try:
                os.unlink(SOCKET)
            except OSError:
                pass
            s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            s.bind(SOCKET)
            os.chmod(SOCKET, 0o600)
            s.listen(4)
            s.setblocking(False)
            self.sock = s
            GLib.io_add_watch(s.fileno(), GLib.IOCondition.IN, self.on_conn)

        def on_conn(self, *_a) -> bool:
            try:
                c, _ = self.sock.accept()
            except OSError:
                return True
            try:
                c.settimeout(0.3)
                cmd = c.recv(64).decode("utf-8", "replace").strip()
                if cmd == "quit":
                    self.quit()
                elif cmd == "reload":
                    self.reload()
                elif cmd == "status":
                    c.sendall(json.dumps({"pid": os.getpid(), "layer": self.layer_ok, "wayland": self.wayland, "desks": len(self.desks),
                                          "items": len(self.items)}).encode())
            except OSError:
                pass
            finally:
                c.close()
            return True

        def quit(self) -> None:
            try:
                os.unlink(SOCKET)
            except OSError:
                pass
            if Gtk.main_level():
                Gtk.main_quit()

        def run(self) -> int:
            self.listen()
            self.items = list_items(self.conf, self.mcfg)
            self.build_desks()
            self.watch()
            if self.conf["show_starter"] and self.conf["starter_ready"]:
                GLib.timeout_add(800, lambda: (ensure_starter(), False)[1])
            for sig in (2, 15):
                GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, sig, lambda *_: (self.quit(), False)[1])
            Gtk.main()
            return 0

    return App, Gtk, LS, Gdk


# ---------------------------------------------------------------------------------------------- Hauptprogramm
def wait_for_session(delay: float) -> None:
    """Beim Autostart warten, bis die Sitzung bereit ist (Wayland-Anschluss oder X11-Anzeige), dann die eingestellte Zeit."""
    t0 = time.time()
    while time.time() - t0 < 60:
        wd, rt = os.environ.get("WAYLAND_DISPLAY"), os.environ.get("XDG_RUNTIME_DIR")
        if wd and rt and os.path.exists(os.path.join(rt, wd)):
            break
        if not wd and os.environ.get("DISPLAY"):
            break
        time.sleep(0.5)
    time.sleep(max(0.0, delay))


def check() -> dict:
    """Prüft, ob GTK und Layer-Shell nutzbar sind (für die Statuszeile in Seifferts Dateien)."""
    out = {"gtk": False, "layer_shell": False, "layer_active": False, "python": sys.version.split()[0]}
    try:
        gi, Gtk, Gdk, *_rest, LS = load_gtk()
        out["gtk"] = True
        out["layer_shell"] = LS is not None
        d = Gdk.Display.get_default()
        if d is not None and LS is not None:
            out["layer_active"] = bool(LS.is_supported())
    except Exception as e:  # noqa: BLE001
        out["error"] = "%s: %s" % (type(e).__name__, e)
    return out


def main(argv: list[str]) -> int:
    args = [a for a in argv[1:]]
    if "--help" in args or "-h" in args:
        sys.stdout.write(__doc__ or "")
        return 0
    if "--check" in args:
        sys.stdout.write(json.dumps(check()) + "\n")
        return 0
    for flag, msg in (("--quit", "quit"), ("--reload", "reload")):
        if flag in args:
            return 0 if send(SOCKET, msg) or flag == "--quit" else 1
    if "--status" in args:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(1.0)
        try:
            s.connect(SOCKET)
            s.sendall(b"status")
            sys.stdout.write(s.recv(1000).decode() + "\n")
            return 0
        except OSError:
            sys.stdout.write("{}\n")
            return 1
        finally:
            s.close()
    if is_running(SOCKET):
        sys.stderr.write("%s läuft schon. Beenden: seiffert-oberflaeche --quit\n" % NAME)
        return 0
    import sessionenv
    if "--autostart" in args:
        sessionenv.log_to_file("oberflaeche.log")
        sessionenv.adopt_session(wait=60)
        time.sleep(max(0.0, SC.load()["start_delay"]))
    else:
        sessionenv.adopt_session()
    if not (os.environ.get("WAYLAND_DISPLAY") or os.environ.get("DISPLAY")):
        sys.stderr.write("%s: Keine grafische Sitzung gefunden (weder WAYLAND_DISPLAY noch DISPLAY).\n" % NAME)
        return 1
    try:
        App, Gtk, LS, Gdk = build_ui()
    except (ImportError, ValueError) as e:
        sys.stderr.write("%s: GTK 3 mit PyGObject fehlt (%s).\nArch: sudo pacman -S python-gobject gtk3 gtk-layer-shell librsvg\n" % (NAME, e))
        return 1
    if Gdk.Display.get_default() is None:
        sys.stderr.write("%s: Der Bildschirm lässt sich nicht öffnen.\n" % NAME)
        return 1
    app = App({"no_layer": "--no-layer" in args})
    if app.wayland and not app.layer_ok and "--no-layer" not in args and not os.environ.get("SEIFFERT_PRELOADED"):
        # gtk-layer-shell muss vor libwayland-client geladen sein; wenn es nicht klappt, einmal mit LD_PRELOAD neu starten
        import glob
        libs = sorted(glob.glob("/usr/lib*/libgtk-layer-shell.so*") + glob.glob("/usr/lib/*/libgtk-layer-shell.so*"))
        if libs and LS is not None:
            os.environ["LD_PRELOAD"] = (libs[0] + " " + os.environ.get("LD_PRELOAD", "")).strip()
            os.environ["SEIFFERT_PRELOADED"] = "1"
            os.execv(sys.executable, [sys.executable] + sys.argv)
    if app.wayland and not app.layer_ok:
        sys.stderr.write("%s: Layer-Shell steht nicht zur Verfügung (Paket gtk-layer-shell oder Compositor ohne Unterstützung); "
                         "die Fläche läuft als Vollbildfenster.\n" % NAME)
    return app.run()


if __name__ == "__main__":
    sys.exit(main(sys.argv))
