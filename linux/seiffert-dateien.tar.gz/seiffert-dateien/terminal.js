"use strict";
/* Seifferts Terminal: Oberfläche. Reiter mit xterm.js, Hervorhebung, Datei-Ansicht, Einstellungen. */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const E = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const S = { settings: null, resolved: null, meta: null, tabs: [], cur: null, full: false, rx: [], rxBad: [], translucent: false, args: {}, early: {}, keymap: new Map(), seq: 0, capturing: false };
let BR; let CID = 0; const PEND = new Map();

function api(method, args = {}) {
  return new Promise((res, rej) => { const id = ++CID; PEND.set(id, { res, rej }); BR.invoke(id, method, JSON.stringify(args)); });
}
const nat = (fn, ...a) => new Promise((res) => BR[fn](...a, res));

/* ---------- Farben ---------- */
const hex2rgb = (h) => { h = h.replace("#", ""); if (h.length === 3) h = h.replace(/./g, "$&$&"); return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)]; };
const rgb2hex = (r) => "#" + r.map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, "0")).join("");
const mix = (a, b, t) => { const x = hex2rgb(a), y = hex2rgb(b); return rgb2hex(x.map((v, i) => v + (y[i] - v) * t)); };
const rgba = (h, a) => { const [r, g, b] = hex2rgb(h); return `rgba(${r},${g},${b},${a})`; };
const lum = (h) => { const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }; const [r, g, b] = hex2rgb(h); return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b); };
const ink = (h) => (lum(h) > 0.4 ? "#000000" : "#ffffff");
const h6 = (h) => { const x = hex2rgb(h); return rgb2hex(x); };
const resFor = (tab) => (tab && tab.theme && S.meta.theme_resolved[tab.theme]) || S.resolved;
const synColor = (c, res) => (c && c[0] === "#" ? c : (res || S.resolved).syntax[c] || (res || S.resolved).colors.foreground);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const debounce = (fn, ms) => { let t = 0; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
const baseName = (p) => String(p || "").replace(/\/+$/, "").split("/").pop() || "/";
const shJoin = (a) => (a || []).map((x) => (/^[\w@%+=:,./-]+$/.test(x) ? x : "'" + x.replace(/'/g, "'\\''") + "'")).join(" ");

/* ---------- Meldungen ---------- */
let toastT = 0;
function toast(msg, err = false, ms = 2600) {
  const t = $("#toast"); t.textContent = msg; t.classList.toggle("err", !!err); t.hidden = false;
  clearTimeout(toastT); toastT = setTimeout(() => { t.hidden = true; }, err ? Math.max(ms, 4200) : ms);
}
function ask(message, okLabel = "Ja", cancelLabel = "Abbrechen") {
  return new Promise((res) => {
    const o = document.createElement("div"); o.id = "capture";
    o.innerHTML = `<div role="alertdialog" aria-modal="true" aria-label="${E(message)}"><p style="margin:0 0 14px">${E(message)}</p><button class="btn" data-v="0">${E(cancelLabel)}</button> <button class="btn danger" data-v="1">${E(okLabel)}</button></div>`;
    const done = (v) => { o.remove(); document.removeEventListener("keydown", onk, true); res(v); };
    const onk = (e) => { if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); done(false); } };
    o.addEventListener("click", (e) => { const b = e.target.closest("button"); if (b) done(b.dataset.v === "1"); });
    document.addEventListener("keydown", onk, true);
    document.body.appendChild(o); $("button[data-v='0']", o).focus();
  });
}

/* ---------- Einstellungen anwenden ---------- */
function compileRules() {
  S.rx = []; S.rxBad = [];
  for (const r of S.settings.rules) {
    if (!r.on) continue;
    try { S.rx.push({ re: new RegExp(r.pattern, "g" + r.flags), color: r.color, bg: r.bg, id: r.id }); } catch (e) { S.rxBad.push({ id: r.id, name: r.name, msg: e.message }); }
  }
}
function fileUrl(p) { return "file://" + encodeURI(p).replace(/[()'"#?]/g, (c) => "%" + c.charCodeAt(0).toString(16).toUpperCase()); }
let lastImg = "";
function applyBackground() {
  const b = S.settings.bg, c = S.resolved.colors, tr = S.translucent;
  const op = tr ? b.opacity / 100 : 1;
  const bg = $("#bg"), img = $("#bgimg"), dim = $("#bgdim");
  img.style.display = "none"; dim.style.background = "transparent";
  bg.style.background = b.mode === "verlauf" ? `linear-gradient(${b.angle}deg, ${rgba(c.background, op)}, ${rgba(b.color2, op)})` : rgba(c.background, op);
  if (b.mode === "bild" && b.image) {
    img.style.display = "block"; img.style.backgroundImage = `url("${fileUrl(b.image)}")`;
    const fit = { cover: ["cover", "no-repeat"], contain: ["contain", "no-repeat"], kacheln: ["auto", "repeat"], mitte: ["auto", "no-repeat"], strecken: ["100% 100%", "no-repeat"] }[b.fit];
    img.style.backgroundSize = fit[0]; img.style.backgroundRepeat = fit[1];
    img.style.opacity = String(b.image_opacity / 100);
    img.style.filter = b.blur ? `blur(${b.blur}px)` : ""; img.style.transform = b.blur ? "scale(1.08)" : "";
    dim.style.background = rgba(S.resolved.dark ? "#000000" : "#ffffff", b.dim / 100);
    if (lastImg !== b.image) { lastImg = b.image; const t = new Image(); t.onerror = () => toast("Das Hintergrundbild konnte nicht geladen werden: " + baseName(b.image), true); t.src = fileUrl(b.image); }
  } else lastImg = "";
}
function applyChrome() {
  const r = S.resolved, c = r.colors, st = document.documentElement.style, w = S.settings.window;
  const a = S.translucent ? 0.92 : 0.97;
  st.setProperty("--bg", c.background); st.setProperty("--fg", c.foreground); st.setProperty("--acc", c.cursor);
  st.setProperty("--accink", ink(c.cursor));
  st.setProperty("--panel", rgba(mix(c.background, c.foreground, 0.09), a));
  st.setProperty("--panel2", rgba(c.foreground, 0.08)); st.setProperty("--line", rgba(c.foreground, 0.22));
  st.setProperty("--muted", mix(c.foreground, c.background, 0.3));
  st.setProperty("--danger", r.syntax.err); st.setProperty("--ok", r.syntax.ok);
  st.setProperty("--pad", w.padding + "px");
  document.documentElement.style.colorScheme = r.dark ? "dark" : "light";
}
function xtermTheme(res) {
  const c = res.colors;
  const t = { background: c.background, foreground: c.foreground, cursor: c.cursor, cursorAccent: c.cursor_accent, selectionBackground: rgba(c.selection, 0.85) };
  for (const n of ["black", "red", "green", "yellow", "blue", "magenta", "cyan", "white"]) { t[n] = c[n]; t["bright" + n[0].toUpperCase() + n.slice(1)] = c["bright_" + n]; }
  return t;
}
function xtermOptions(tab) {
  const st = S.settings, f = st.font, cu = st.cursor, t = st.term;
  return {
    fontFamily: f.family, fontSize: f.size, lineHeight: f.line_height, letterSpacing: f.letter_spacing, fontWeight: f.weight, fontWeightBold: f.weight_bold,
    cursorStyle: cu.style, cursorBlink: cu.blink, cursorInactiveStyle: cu.inactive, cursorWidth: cu.width,
    scrollback: tab && tab.kind === "view" ? tab.scrollback : t.scrollback, scrollSensitivity: t.scroll_sensitivity, fastScrollSensitivity: t.fast_scroll,
    minimumContrastRatio: t.min_contrast, drawBoldTextInBrightColors: t.bright_bold, wordSeparator: t.word_separator,
    scrollOnUserInput: t.scroll_on_input, smoothScrollDuration: t.smooth_scroll, theme: xtermTheme(resFor(tab)),
  };
}
function applyTabOptions(tab) {
  if (!tab.term) return;
  const o = xtermOptions(tab);
  for (const k of Object.keys(o)) {
    if (k === "theme" || k === "scrollback" && tab.kind === "view") { if (k === "theme") tab.term.options.theme = o.theme; continue; }
    if (tab.kind === "view" && (k === "cursorBlink" || k === "cursorInactiveStyle")) continue;      // die Dateianzeige hat keinen Cursor
    if (JSON.stringify(tab.term.options[k]) !== JSON.stringify(o[k])) tab.term.options[k] = o[k];
  }
  if (tab.blinkAct) tab.blinkAct();
  setLinks(tab);
}
function buildKeymap() {
  S.keymap = new Map();
  for (const [a, list] of Object.entries(S.settings.keys)) for (const c of list) S.keymap.set(c, a);
}
function applyAll() {
  compileRules(); buildKeymap(); applyChrome(); applyBackground();
  document.documentElement.dataset.dark = S.resolved.dark ? "1" : "0";
  $("#main").classList.toggle("bottom", S.settings.window.tabbar === "unten");
  S.tabs.forEach((t) => { applyTabOptions(t); if (t.kind === "view" && t.src && t.renderedFor !== viewSig(t)) renderView(t); });
  $("#bHl").setAttribute("aria-pressed", S.settings.highlight.on ? "true" : "false");
  updateBar(); layoutSoon(); S.tabs.forEach(hlSchedule); updateTitle(); syncControls();
}

/* ---------- Tastenkürzel ---------- */
function comboOf(e) {
  let name;
  const k = e.key, code = e.code || "";
  if (/^[a-zA-Z]$/.test(k)) name = k.toUpperCase();
  else if (/^Digit\d$/.test(code)) name = code.slice(5);
  else if (/^Key[A-Z]$/.test(code)) name = code.slice(3);
  else if (k.length === 1 && k !== " ") name = k;
  else if (k === " ") name = "Space";
  else if (/^F\d+$/.test(k)) name = k;
  else if (["Tab", "Enter", "Escape", "Backspace", "Delete", "Insert", "Home", "End", "PageUp", "PageDown", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(k)) name = k;
  else return "";
  const symbol = k.length === 1 && !/[a-zA-Z0-9 ]/.test(k);         // bei Zeichen wie + oder ? steckt Umschalt schon im Zeichen
  const m = [];
  if (e.ctrlKey) m.push("Ctrl"); if (e.altKey) m.push("Alt"); if (e.shiftKey && !symbol) m.push("Shift"); if (e.metaKey) m.push("Meta");
  return [...m, name].join("+");
}
const ACTIONS = {
  tab_new: () => openTerminalTab(), tab_close: () => S.cur && closeTab(S.cur), tab_next: () => cycleTab(1), tab_prev: () => cycleTab(-1),
  window_new: () => nat("new_window", S.cur && S.cur.cwd || ""), window_close: () => BR.quit_app(), fullscreen: () => toggleFullscreen(),
  settings: () => toggleSettings(), search: () => toggleSearch(), copy: () => copySel(), paste: () => pasteClip(),
  select_all: () => S.cur && S.cur.term.selectAll(), clear: () => clearTab(), zoom_in: () => zoom(1), zoom_out: () => zoom(-1), zoom_reset: () => zoom(0),
  highlight: () => toggleHighlight(), view_file: () => pickAndView(), duplicate: () => S.cur && S.cur.kind === "term" && openTerminalTab({ profile: S.cur.profileName, cwd: S.cur.cwd }),
};
function onKey(e) {
  if (S.capturing || e.isComposing) return;
  if (e.key === "Escape" && !$("#searchbar").hidden && !e.ctrlKey && !e.altKey && !e.shiftKey) { e.preventDefault(); e.stopPropagation(); toggleSearch(false); return; }
  const c = comboOf(e);
  if (!c) return;
  let act = S.keymap.get(c);
  if (!act && e.altKey && !e.ctrlKey && !e.shiftKey && !e.metaKey && /^Digit[1-9]$/.test(e.code || "")) {
    const t = S.tabs[+e.code.slice(5) - 1]; if (t) { e.preventDefault(); e.stopPropagation(); activate(t); } return;
  }
  if (!act) return;
  e.preventDefault(); e.stopPropagation();
  if (e.repeat && !["zoom_in", "zoom_out", "tab_next", "tab_prev"].includes(act)) return;
  Promise.resolve(ACTIONS[act]()).catch((er) => toast(er.message || String(er), true));
}
window.addEventListener("keydown", onKey, true);

/* ---------- Reiter ---------- */
const byTid = (id) => S.tabs.find((t) => t.tid === id);
function newTab(kind, title) {
  const tab = { n: ++S.seq, kind, title, osctitle: "", cwd: "", idle: true, alive: kind === "term", tid: 0, inbuf: "", sending: false, decos: [], markers: [], hlT: 0, theme: "", profileName: "", dead: false, links: null };
  tab.pane = document.createElement("div"); tab.pane.className = "pane"; $("#stage").appendChild(tab.pane);
  S.tabs.push(tab);
  return tab;
}
/* Der blinkende Cursor lässt das Fenster zweimal je Sekunde neu zeichnen. Nach einer Ruhezeit hört er auf zu blinken (bleibt sichtbar)
   und blinkt bei der nächsten Eingabe oder Ausgabe wieder. cfg() liefert { blink, secs }; secs 0 = blinkt immer. */
function blinkGuard(term, cfg) {
  let timer = 0, last = 0;
  const off = () => {
    timer = 0; const c = cfg(); if (!c.blink || !c.secs) return;
    const rest = c.secs * 1000 - (performance.now() - last);
    if (rest > 50) { timer = setTimeout(off, rest); return; }
    if (term.options.cursorBlink) term.options.cursorBlink = false;
  };
  const act = () => {
    last = performance.now(); const c = cfg();
    if (c.blink && !term.options.cursorBlink) term.options.cursorBlink = true;
    if (c.blink && c.secs && !timer) timer = setTimeout(off, c.secs * 1000);
  };
  term.onData(act); term.onWriteParsed(act);
  if (term.textarea) term.textarea.addEventListener("focus", act);
  act(); return () => { clearTimeout(timer); timer = 0; act(); };      // nach geänderten Einstellungen: Frist neu beginnen
}
function mountTerm(tab, extra = {}) {
  const term = new Terminal(Object.assign(xtermOptions(tab), { allowProposedApi: true }, extra));
  tab.term = term; tab.fit = new FitAddon.FitAddon(); term.loadAddon(tab.fit);
  tab.search = new SearchAddon.SearchAddon(); term.loadAddon(tab.search);
  tab.search.onDidChangeResults((r) => { if (S.cur === tab) $("#sN").textContent = r && r.resultCount ? `${r.resultIndex + 1} von ${r.resultCount}` : (r && $("#sq").value ? "kein Treffer" : ""); });
  term.open(tab.pane);
  if (tab.kind !== "view") tab.blinkAct = blinkGuard(term, () => ({ blink: S.settings.cursor.blink, secs: S.settings.cursor.blink_timeout }));
  term.onBell(() => ringBell());
  term.onWriteParsed(() => hlSchedule(tab)); term.onScroll(() => hlSchedule(tab)); term.onResize(() => hlSchedule(tab));
  term.onTitleChange((t) => { tab.osctitle = t; updateTab(tab); });
  term.onSelectionChange(() => { if (S.settings.term.copy_on_select && term.hasSelection()) copySelDebounced(term); });
  tab.pane.addEventListener("contextmenu", (e) => onContext(e, tab));
  term.attachCustomKeyEventHandler((e) => {
    if (tab.kind === "view" && e.type === "keydown") {
      const m = { PageUp: () => term.scrollPages(-1), PageDown: () => term.scrollPages(1), Home: () => term.scrollToTop(), End: () => term.scrollToBottom(), ArrowUp: () => term.scrollLines(-1), ArrowDown: () => term.scrollLines(1) }[e.key];
      if (m && !e.ctrlKey && !e.altKey) { m(); return false; }
    }
    return true;
  });
  setLinks(tab);
  return term;
}
const copySelDebounced = debounce((term) => { if (term.hasSelection()) BR.copy_text(term.getSelection()); }, 250);
function setLinks(tab) {
  if (!tab.term) return;
  const want = S.settings.term.links;
  if (want && !tab.links) { tab.links = new WebLinksAddon.WebLinksAddon((ev, uri) => { if (ev.ctrlKey || ev.metaKey) nat("open_url", uri); }); tab.term.loadAddon(tab.links); }
  else if (!want && tab.links) { tab.links.dispose(); tab.links = null; }
}
function pickProfile(name) {
  const ps = S.settings.profiles;
  return ps.find((p) => p.name.toLowerCase() === String(name || "").toLowerCase()) || ps[0];
}
async function openTerminalTab(o = {}) {
  const st = S.settings, prof = pickProfile(o.profile);
  let cwd = o.cwd || "";
  if (!cwd && S.firstDir) { cwd = S.firstDir; S.firstDir = ""; }
  if (!cwd && st.shell.new_tab_cwd === "aktuell" && S.cur && S.cur.kind === "term" && S.cur.alive) { try { cwd = (await api("term_state", { id: S.cur.tid })).cwd; } catch { /* Standard */ } }
  if (!cwd) cwd = prof.cwd;
  const tab = newTab("term", o.command || prof.name);
  tab.theme = prof.theme; tab.profileName = prof.name; tab.title = o.title || (o.command ? baseName(o.command) : prof.name);
  activate(tab);
  mountTerm(tab);
  try { tab.fit.fit(); } catch { /* Größe kommt später */ }
  try {
    const r = await api("term_open", { cwd, cols: tab.term.cols, rows: tab.term.rows, shell: o.command !== undefined ? o.command : prof.command, args: o.args !== undefined ? o.args : prof.args, env: prof.env, login: prof.login });
    tab.tid = r.id; tab.cwd = r.cwd; tab.alive = true;
    for (const ev of S.early[r.id] || []) onTermEvent(ev);
    delete S.early[r.id];
    tab.term.onData((d) => sendInput(tab, d));
    tab.term.onBinary((d) => sendInput(tab, d));
    tab.term.onResize(({ cols, rows }) => { if (tab.tid) api("term_resize", { id: tab.tid, cols, rows }).catch(() => { }); });
    if (S.cur === tab) tab.term.focus();
  } catch (e) {
    tab.alive = false; tab.dead = true;
    tab.term.write("\r\n\x1b[31m" + (e.message || e) + "\x1b[0m\r\n");
    toast(e.message || String(e), true);
  }
  updateTab(tab);
  return tab;
}
async function flushInput(tab) {
  tab.sending = true;
  while (tab.inbuf) { const d = tab.inbuf; tab.inbuf = ""; try { await api("term_write", { id: tab.tid, data: d }); } catch { break; } }
  tab.sending = false;
}
function sendInput(tab, d) { if (!tab.alive) return; tab.inbuf += d; if (!tab.sending) flushInput(tab); }
function onTermEvent(d) {
  const tab = byTid(d.id);
  if (!tab) { (S.early[d.id] = S.early[d.id] || []).push(d); return; }
  if (d.data) { const bin = atob(d.data), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); tab.term.write(u); }
  if ("exit" in d) onExit(tab, d.exit);
}
function onExit(tab, code) {
  tab.alive = false;
  if (S.settings.shell.on_exit === "schließen") { closeTab(tab, true); return; }
  tab.dead = true;
  tab.term.write(`\r\n\x1b[2m[Beendet${code === null || code === undefined ? "" : " mit Code " + code}. Reiter mit dem Kreuz schließen oder ${S.settings.keys.tab_new[0] || "einen neuen Reiter"} öffnen.]\x1b[0m\r\n`);
  updateTab(tab);
}
function viewSig(t) { return JSON.stringify([S.resolved.syntax, S.resolved.colors.foreground, S.resolved.colors.background, S.settings.rules]); }
async function openViewTab(path) {
  const r = await api("read_file", { path });
  const tab = newTab("view", r.name);
  tab.src = { text: r.text, name: r.name, path: r.path, truncated: r.truncated };
  tab.scrollback = Math.min(200000, r.text.split("\n").length + 500);
  activate(tab);
  mountTerm(tab, { disableStdin: true, cursorBlink: false, cursorInactiveStyle: "none", scrollback: tab.scrollback });
  tab.term.options.scrollback = tab.scrollback;
  try { tab.fit.fit(); } catch { /* später */ }
  renderView(tab);
  updateTab(tab);
  return tab;
}
function renderView(tab) {
  const res = resFor(tab), t = tab.src;
  const hl = SyntaxLib.highlight(t.text, t.name, S.rx);
  if (hl.lines.length > 1 && !hl.lines[hl.lines.length - 1].length) hl.lines.pop();      // Zeilenumbruch am Dateiende ist keine eigene Zeile
  const col = Object.assign({}, res.syntax, { dim: mix(res.colors.foreground, res.colors.background, 0.45), fg: res.colors.foreground });
  const head = `\x1b[?25l\x1b[1m${t.name}\x1b[0m  \x1b[2m${hl.lang ? "Sprache: " + hl.lang : "ohne erkannte Sprache (Regeln der Hervorhebung)"} · ${hl.lines.length} Zeilen${t.truncated ? " · nur die ersten 3 MB" : ""} · ${t.path}\x1b[0m\r\n\r\n`;
  tab.renderedFor = viewSig(tab);
  tab.term.reset(); tab.term.options.scrollback = tab.scrollback;
  tab.term.write(head);
  const all = SyntaxLib.toAnsi(hl.lines, col, {}).split("\r\n");
  const CH = 1500;
  const step = (i) => { if (i >= all.length) { tab.term.scrollToTop(); return; } tab.term.write(all.slice(i, i + CH).join("\r\n") + (i + CH < all.length ? "\r\n" : ""), () => step(i + CH)); };
  step(0);
}
function updateTab(tab) {
  let title = tab.title;
  const mode = S.settings.shell.title_mode;
  if (tab.kind === "term") {
    if (mode === "programm" && tab.osctitle) title = tab.osctitle;
    else if (mode === "ordner" && tab.cwd) title = baseName(tab.cwd);
    else title = tab.title;
  }
  tab.label = title;
  renderTabs();
  if (S.cur === tab) updateTitle();
}
function renderTabs() {
  const box = $("#tabs"); box.textContent = "";
  S.tabs.forEach((t, i) => {
    const d = document.createElement("div"); d.className = "tab" + (t.dead ? " dead" : ""); d.setAttribute("role", "presentation");
    const sel = t === S.cur; d.setAttribute("aria-selected", sel ? "true" : "false");
    const b = document.createElement("button"); b.setAttribute("role", "tab"); b.setAttribute("aria-selected", sel ? "true" : "false");
    b.title = (t.kind === "view" ? "Datei: " + (t.src && t.src.path) : (t.cwd || "")) + (i < 9 ? "  (Alt+" + (i + 1) + ")" : "");
    b.textContent = (t.kind === "view" ? "▤ " : "") + (t.label || t.title);
    b.onclick = () => activate(t);
    b.onauxclick = (e) => { if (e.button === 1) { e.preventDefault(); closeTab(t); } };
    d.appendChild(b);
    if (t.kind === "term" && t.alive && !t.idle) { const dot = document.createElement("span"); dot.className = "dot"; dot.title = "Es läuft ein Programm"; d.appendChild(dot); }
    const x = document.createElement("button"); x.className = "x"; x.textContent = "✕"; x.title = "Reiter schließen"; x.setAttribute("aria-label", "Reiter schließen");
    x.onclick = () => closeTab(t); d.appendChild(x);
    box.appendChild(d);
  });
  updateBar();
}
function updateBar() {
  const w = S.settings.window;
  const hide = (S.full && w.hide_tabs_fullscreen) || (w.tabbar_autohide && S.tabs.length <= 1);
  $("#main").classList.toggle("barhide", !!hide);
  $("#bFull").textContent = S.full ? "Vollbild beenden" : "Vollbild";
  $("#bFull").setAttribute("aria-pressed", S.full ? "true" : "false");
}
function updateTitle() {
  const t = S.cur, tpl = S.settings.window.title || "{titel}";
  const s = tpl.replace(/\{titel\}/g, t ? (t.label || t.title) : "").replace(/\{profil\}/g, t ? t.profileName || "" : "").replace(/\{ordner\}/g, t && t.cwd ? baseName(t.cwd) : "").trim();
  document.title = s || "Seifferts Terminal";
}
function activate(tab) {
  S.cur = tab;
  S.tabs.forEach((t) => t.pane.classList.toggle("on", t === tab));
  renderTabs(); updateTitle();
  requestAnimationFrame(() => { fitTab(tab); if (tab.term && $("#settings").classList.contains("on") === false && $("#searchbar").hidden) tab.term.focus(); hlSchedule(tab); });
  if (!$("#searchbar").hidden) $("#sN").textContent = "";
}
function fitTab(tab) {
  if (!tab || !tab.fit || S.cur !== tab || !tab.pane.clientWidth) return;
  try { tab.fit.fit(); } catch { /* noch nicht sichtbar */ }
}
const layoutSoon = debounce(() => fitTab(S.cur), 40);
function cycleTab(d) { if (S.tabs.length < 2) return; const i = S.tabs.indexOf(S.cur); activate(S.tabs[(i + d + S.tabs.length) % S.tabs.length]); }
async function closeTab(tab, force = false) {
  if (!S.tabs.includes(tab)) return;
  if (!force && tab.kind === "term" && tab.alive && !tab.idle && !(await ask("In diesem Reiter läuft noch ein Programm. Reiter trotzdem schließen?", "Schließen"))) return;
  const i = S.tabs.indexOf(tab);
  S.tabs.splice(i, 1);
  clearTimeout(tab.hlT); hlClear(tab);
  try { tab.term.dispose(); } catch { /* egal */ }
  tab.pane.remove();
  if (tab.tid) api("term_close", { id: tab.tid }).catch(() => { });
  if (!S.tabs.length) { BR.quit_app(); return; }
  if (S.cur === tab) activate(S.tabs[Math.min(i, S.tabs.length - 1)]); else renderTabs();
}
function clearTab() {
  const t = S.cur; if (!t) return;
  t.term.clear();
  if (t.kind === "term" && t.alive && t.idle) sendInput(t, "\x0c");
}
function zoom(d) {
  const f = S.settings.font; const n = d === 0 ? 14 : Math.max(6, Math.min(72, f.size + d));
  commit({ font: { size: n } });
}
async function copySel() {
  const t = S.cur; if (!t || !t.term.hasSelection()) { toast("Nichts ausgewählt."); return; }
  await nat("copy_text", t.term.getSelection());
}
async function pasteClip() {
  const t = S.cur; if (!t || t.kind !== "term" || !t.alive) return;
  const txt = await nat("clip_text"); if (txt) t.term.paste(txt);
}
function toggleHighlight() { return commit({ highlight: { on: !S.settings.highlight.on } }); }
async function pickAndView() {
  const start = (S.cur && S.cur.cwd) || (S.cur && S.cur.src && S.cur.src.path) || S.meta.home;
  const p = await nat("pick_file", start); if (!p) return;
  await openViewTab(p);
}
function ringBell() {
  const b = S.settings.term.bell;
  if (b === "visuell" || b === "beides") { const el = $("#bell"); el.classList.remove("on"); void el.offsetWidth; el.classList.add("on"); }
  if (b === "ton" || b === "beides") BR.bell();
}

/* ---------- Hervorhebung der Ausgabe ---------- */
function hlClear(tab) { tab.decos.forEach((d) => { try { d.dispose(); } catch { /* egal */ } }); tab.markers.forEach((m) => { try { m.dispose(); } catch { /* egal */ } }); tab.decos = []; tab.markers = []; }
function hlSchedule(tab) { if (!tab || tab.hlT) return; tab.hlT = setTimeout(() => { tab.hlT = 0; hlPass(tab); }, 50); }
function hlPass(tab) {
  hlClear(tab);
  const h = S.settings.highlight;
  if (!h.on || tab.kind !== "term" || !S.rx.length || !tab.term || S.cur !== tab) return;
  const term = tab.term, buf = term.buffer.active;
  if (buf.type !== "normal") return;                              // im Vollbildprogramm (vim, less …) gibt es keine Markierungen
  const res = resFor(tab), cur = buf.baseY + buf.cursorY, cell = buf.getNullCell();
  for (let r = 0; r < term.rows; r++) {
    const y = buf.viewportY + r, line = buf.getLine(y);
    if (!line) break;
    let s = "", map = [], wid = [], plain = [];
    for (let x = 0; x < term.cols && s.length < h.max_line; x++) {
      const c = line.getCell(x, cell); if (!c) break;
      const w = c.getWidth(); if (w === 0) continue;
      const ch = c.getChars() || " "; const pf = c.isFgDefault();
      for (let k = 0; k < ch.length; k++) { map.push(x); wid.push(w); plain.push(pf); }
      s += ch;
    }
    const t = s.trimEnd(); if (!t) continue;
    const ms = SyntaxLib.matchRules(t, S.rx, h.only_plain ? plain : null);
    if (!ms.length) continue;
    const marker = term.registerMarker(y - cur); if (!marker) continue;
    tab.markers.push(marker);
    for (const m of ms) {
      const x0 = map[m.start], x1 = map[m.end - 1] + wid[m.end - 1];
      const d = term.registerDecoration({ marker, x: x0, width: x1 - x0, foregroundColor: h6(synColor(m.color, res)), backgroundColor: m.bg ? h6(m.bg) : undefined });
      if (d) tab.decos.push(d);
    }
  }
}

/* ---------- Suche ---------- */
function toggleSearch(force) {
  const bar = $("#searchbar"), open = force === undefined ? bar.hidden : force;
  bar.hidden = !open;
  if (open) { const t = S.cur; if (t && t.term.hasSelection() && !t.term.getSelection().includes("\n")) $("#sq").value = t.term.getSelection(); $("#sq").focus(); $("#sq").select(); doFind(1, true); }
  else { if (S.cur) { S.cur.search.clearDecorations(); S.cur.term.focus(); } $("#sN").textContent = ""; }
}
function doFind(dir, incremental = false) {
  const t = S.cur, q = $("#sq").value; if (!t) return;
  if (!q) { t.search.clearDecorations(); $("#sN").textContent = ""; return; }
  const c = S.resolved.colors, o = {
    caseSensitive: $("#sCase").checked, regex: $("#sRe").checked, wholeWord: $("#sWord").checked, incremental,
    decorations: { matchBackground: mix(c.background, c.cursor, 0.4), matchBorder: c.cursor, matchOverviewRuler: c.cursor, activeMatchBackground: mix(c.background, c.cursor, 0.7), activeMatchBorder: c.foreground, activeMatchColorOverviewRuler: c.foreground },
  };
  try { dir > 0 ? t.search.findNext(q, o) : t.search.findPrevious(q, o); } catch (e) { $("#sN").textContent = "Ausdruck ungültig"; }
}
$("#sq").addEventListener("input", () => doFind(1, true));
$("#sq").addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); doFind(e.shiftKey ? -1 : 1); } });
$("#sNext").onclick = () => doFind(1); $("#sPrev").onclick = () => doFind(-1); $("#sX").onclick = () => toggleSearch(false);
for (const id of ["#sCase", "#sRe", "#sWord"]) $(id).addEventListener("change", () => doFind(1, true));

/* ---------- Menüs ---------- */
function showMenu(items, x, y) {
  const m = $("#menu"); m.textContent = ""; m.hidden = false;
  for (const it of items) {
    if (it === "-") { m.appendChild(document.createElement("hr")); continue; }
    const b = document.createElement("button"); b.setAttribute("role", "menuitem"); b.disabled = !!it.off;
    b.innerHTML = `<span>${E(it.label)}</span><span class="k">${E(it.key || "")}</span>`;
    b.onclick = () => { hideMenu(); it.fn(); };
    m.appendChild(b);
  }
  const r = m.getBoundingClientRect();
  m.style.left = Math.max(4, Math.min(x, innerWidth - r.width - 4)) + "px"; m.style.top = Math.max(4, Math.min(y, innerHeight - r.height - 4)) + "px";
  const f = $("button:not([disabled])", m); if (f) f.focus();
}
function hideMenu() { const m = $("#menu"); if (!m.hidden) { m.hidden = true; if (S.cur && S.cur.term && !$("#settings").classList.contains("on")) S.cur.term.focus(); } }
document.addEventListener("mousedown", (e) => { if (!e.target.closest("#menu")) hideMenu(); }, true);
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !$("#menu").hidden) { e.preventDefault(); e.stopPropagation(); hideMenu(); } }, true);
const keyOf = (a) => (S.settings.keys[a] || [])[0] || "";
function onContext(e, tab) {
  const rc = S.settings.term.right_click;
  e.preventDefault();
  if (rc === "nichts") return;
  if (rc === "einfuegen") { pasteClip(); return; }
  const sel = tab.term.hasSelection();
  showMenu([
    { label: "Kopieren", key: keyOf("copy"), off: !sel, fn: copySel },
    { label: "Einfügen", key: keyOf("paste"), off: tab.kind !== "term", fn: pasteClip },
    { label: "Alles auswählen", key: keyOf("select_all"), fn: () => tab.term.selectAll() },
    "-",
    { label: "Suchen …", key: keyOf("search"), fn: () => toggleSearch(true) },
    { label: "Anzeige leeren", key: keyOf("clear"), fn: clearTab },
    { label: S.settings.highlight.on ? "Hervorhebung ausschalten" : "Hervorhebung einschalten", key: keyOf("highlight"), fn: toggleHighlight },
    { label: "Datei in Farben anzeigen …", key: keyOf("view_file"), fn: pickAndView },
    "-",
    { label: "Neuer Reiter", key: keyOf("tab_new"), fn: () => openTerminalTab() },
    { label: S.full ? "Vollbild beenden" : "Vollbild", key: keyOf("fullscreen"), fn: toggleFullscreen },
    { label: "Einstellungen", key: keyOf("settings"), fn: () => toggleSettings(true) },
  ], e.clientX, e.clientY);
}
$("#bProf").onclick = (e) => {
  const r = e.currentTarget.getBoundingClientRect();
  showMenu(S.settings.profiles.map((p, i) => ({ label: p.name + (i === 0 ? " (Standard)" : ""), fn: () => openTerminalTab({ profile: p.name }) })), r.left, r.bottom + 4);
};

/* ---------- Vollbild ---------- */
async function toggleFullscreen() {
  S.full = !!(await nat("toggle_fullscreen"));
  document.body.classList.toggle("full", S.full);
  updateBar(); layoutSoon();
  toast(S.full ? "Vollbild. Mit " + (keyOf("fullscreen") || "dem Knopf oben") + " zurück." : "Vollbild beendet.", false, 1600);
}

/* ---------- Werkzeugleiste ---------- */
$("#bNew").onclick = () => openTerminalTab();
$("#bSearch").onclick = () => toggleSearch();
$("#bView").onclick = () => pickAndView().catch((e) => toast(e.message, true));
$("#bHl").onclick = () => toggleHighlight();
$("#bFull").onclick = () => toggleFullscreen();
$("#bSet").onclick = () => toggleSettings();
$("#setClose").onclick = () => toggleSettings(false);
new ResizeObserver(() => layoutSoon()).observe($("#stagewrap"));

/* ======================================================================
   Einstellungen
   ====================================================================== */
const get = (o, path) => path.split(".").reduce((a, k) => (a == null ? a : a[k]), o);
const patchOf = (path, v) => { const ks = path.split("."), root = {}; let o = root; ks.forEach((k, i) => { o[k] = i === ks.length - 1 ? v : (o[k] = {}); o = o[k]; }); return root; };
let chain = Promise.resolve();
function commit(patch) {
  chain = chain.then(() => api("settings_set", { patch })).then((r) => { S.settings = r.settings; S.resolved = r.resolved; applyAll(); return r; })
    .catch((e) => { toast(e.message, true); syncControls(true); });
  return chain;
}
const CTL = [];
function syncControls(force = false) {
  for (const c of CTL) { if (!c.el.isConnected) continue; if (!force && document.activeElement === c.el) continue; try { c.sync(); } catch { /* Bereich wird gerade umgebaut */ } }
}
function h(tag, attrs = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === false || v == null) continue;
    if (k === "class") el.className = v; else if (k === "html") el.innerHTML = v; else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else if (k === "value") el.value = v; else if (k === "checked") el.checked = !!v; else el.setAttribute(k, v === true ? "" : v);
  }
  for (const kd of kids.flat()) if (kd != null && kd !== false) el.append(kd.nodeType ? kd : document.createTextNode(kd));
  return el;
}
const row = (label, ctl, hint, wide) => h("div", { class: "row" + (wide ? " wide" : "") }, label ? h("label", {}, label) : null, h("div", { class: "ctl" }, ctl), hint ? h("div", { class: "hint" }, hint) : null);
let uid = 0;
function labelled(label, ctl, hint) {
  const id = "c" + ++uid; const sel = "input,select,textarea"; const inp = ctl.matches && ctl.matches(sel) ? ctl : ctl.querySelector ? ctl.querySelector(sel) : null; if (inp) inp.id = id;
  const r = h("div", { class: "row" }, h("label", { for: id }, label), h("div", { class: "ctl" }, ctl), hint ? h("div", { class: "hint" }, hint) : null);
  return r;
}
function cText(path, o = {}) {
  const el = h("input", { type: "text", placeholder: o.placeholder || "", spellcheck: "false", list: o.list });
  const sync = () => { el.value = get(S.settings, path) ?? ""; };
  el.addEventListener("change", () => commit(patchOf(path, el.value)));
  CTL.push({ el, sync }); sync(); return el;
}
function cNum(path, o = {}) {
  const el = h("input", { type: "number", min: o.min, max: o.max, step: o.step || 1, style: "width:90px" });
  const sync = () => { el.value = get(S.settings, path); };
  el.addEventListener("change", () => { const v = parseFloat(el.value); if (Number.isNaN(v)) { sync(); return; } commit(patchOf(path, Math.min(o.max ?? v, Math.max(o.min ?? v, v)))); });
  CTL.push({ el, sync }); sync();
  return h("span", { class: "ctl" }, el, o.unit ? h("span", { class: "val" }, o.unit) : null);
}
function cRange(path, o = {}) {
  const el = h("input", { type: "range", min: o.min, max: o.max, step: o.step || 1, style: "flex:1;min-width:120px" });
  const val = h("span", { class: "val" });
  const fmt = o.fmt || ((v) => String(v) + (o.unit || ""));
  const sync = () => { el.value = get(S.settings, path); val.textContent = fmt(+el.value); };
  const send = debounce(() => commit(patchOf(path, parseFloat(el.value))), 70);
  el.addEventListener("input", () => { val.textContent = fmt(+el.value); send(); });
  CTL.push({ el, sync }); sync();
  return h("span", { class: "ctl", style: "flex:1;width:100%" }, el, val);
}
function cSel(path, opts, o = {}) {
  const el = h("select", {}, opts.map(([v, l]) => h("option", { value: v }, l)));
  const sync = () => { el.value = String(get(S.settings, path)); };
  el.addEventListener("change", () => commit(patchOf(path, o.num ? +el.value : el.value)));
  CTL.push({ el, sync }); sync(); return el;
}
function cChk(path, label) {
  const el = h("input", { type: "checkbox" });
  const sync = () => { el.checked = !!get(S.settings, path); };
  el.addEventListener("change", () => commit(patchOf(path, el.checked)));
  CTL.push({ el, sync }); sync();
  return h("label", { style: "display:inline-flex;gap:8px;align-items:center" }, el, label);
}
/* Farbfeld; leer = aus dem Farbschema. fallback() liefert die angezeigte Farbe, solange nichts eingestellt ist. */
function cColor(path, fallback, o = {}) {
  const el = h("input", { type: "color", "aria-label": o.label || "Farbe" });
  const sync = () => { const v = get(S.settings, path); el.value = v || (fallback ? fallback() : "#000000"); rs.hidden = !o.clearable || !v; };
  const rs = h("button", { class: "rs", type: "button", title: "Zurück zur Farbe des Farbschemas" }, "zurück");
  rs.addEventListener("click", () => commit(patchOf(path, "")));
  const send = debounce(() => commit(patchOf(path, el.value)), 80);
  el.addEventListener("input", send);
  CTL.push({ el, sync }); sync();
  return h("span", { class: "sw", style: "gap:4px" }, el, rs);
}
function section(id, title, build) { return { id, title, build }; }
function btn(label, fn, cls = "") { return h("button", { class: "btn " + cls, type: "button", onclick: fn }, label); }
async function resetGroup(group, what) {
  if (!(await ask(what + " auf die Vorgaben zurücksetzen?", "Zurücksetzen"))) return;
  try { const r = await api("settings_reset", { group }); S.settings = r.settings; S.resolved = r.resolved; applyAll(); renderSection(curSection); } catch (e) { toast(e.message, true); }
}

function themePreview(t) {
  const r = S.meta.theme_resolved[t.id], c = r.colors;
  const sp = (col, s) => `<span style="color:${col}">${E(s)}</span>`;
  return `<div class="pv" style="background:${c.background};color:${c.foreground}">${sp(c.green, "$ ")}ls -l\n${sp(c.blue, "drwxr-xr-x")} ${sp(c.cyan, "Dokumente")}\n${sp(r.syntax.kw, "def")} ${sp(r.syntax.fn, "gruss")}(${sp(r.syntax.str, '"Hallo"')}, ${sp(r.syntax.num, "42")})\n${sp(r.syntax.err, "Fehler")} ${sp(r.syntax.warn, "Warnung")} ${sp(r.syntax.ok, "ok")}</div>`;
}
const SAMPLE = `$ python3 skript.py --verbose /home/heiko/Dokumente/notiz.txt
def gruss(name="Welt"):  # Begrüßung
    return f"Hallo {name}", 3.14, 0xFF
Traceback (most recent call last):
ValueError: Fehler beim Lesen von https://example.org/daten.csv
Warnung: 3 Dateien veraltet (deprecated), Stand 2026-11-10 19:38:05
Server 192.168.0.12:8080 erreichbar, Test ok
export PATH="$HOME/bin:$PATH"`;

let curSection = "farben";
const SECTIONS = [
  section("farben", "Farben", () => {
    const f = [];
    f.push(h("h3", {}, "Farbschema"));
    const grid = h("div", { class: "themes", role: "group", "aria-label": "Farbschemata" });
    S.meta.themes.forEach((t) => {
      const b = h("button", { class: "themecard", type: "button", html: themePreview(t) + `<div class="nm"><span>${E(t.label)}</span><span>${t.dark ? "dunkel" : "hell"}</span></div>` });
      const sync = () => b.setAttribute("aria-pressed", S.settings.theme === t.id ? "true" : "false");
      b.addEventListener("click", () => commit({ theme: t.id })); CTL.push({ el: b, sync }); sync(); grid.appendChild(b);
    });
    f.push(grid);
    f.push(h("h3", {}, "Eigene Farben"), h("div", { class: "hint", style: "margin-bottom:6px" }, "Jede Farbe lässt sich einzeln ändern und überschreibt das Farbschema. „zurück“ macht eine einzelne Änderung rückgängig."));
    const base = { foreground: "Text", background: "Hintergrund", cursor: "Cursor", cursor_accent: "Text unter dem Cursor", selection: "Auswahl" };
    const g1 = h("div", { class: "swatches" });
    for (const [k, l] of Object.entries(base)) g1.append(h("div", { class: "sw" }, cColor("colors." + k, () => S.resolved.colors[k], { clearable: true, label: l }), h("span", {}, l)));
    f.push(g1, h("h3", {}, "Die 16 Terminalfarben (ANSI)"));
    const NAMES = { black: "Schwarz", red: "Rot", green: "Grün", yellow: "Gelb", blue: "Blau", magenta: "Magenta", cyan: "Cyan", white: "Weiß" };
    const g2 = h("div", { class: "swatches" });
    for (const pre of ["", "bright_"]) for (const [k, l] of Object.entries(NAMES)) g2.append(h("div", { class: "sw" }, cColor("colors." + pre + k, () => S.resolved.colors[pre + k], { clearable: true, label: l }), h("span", {}, (pre ? "Hell " : "") + l)));
    const pvEl = h("div", { class: "preview", id: "pvColors" });
    f.push(g2, pvEl, row("", [btn("Alle eigenen Farben entfernen", () => resetGroup("colors", "Alle eigenen Farben"), "danger")]));
    const pv = () => {
      const c = S.resolved.colors, p = pvEl;
      p.style.background = c.background; p.style.color = c.foreground;
      const names = ["black", "red", "green", "yellow", "blue", "magenta", "cyan", "white"];
      p.innerHTML = `<span style="color:${c.green}">heiko@arch</span>:<span style="color:${c.blue}">~/Dokumente</span>$ ls\n` + names.map((n) => `<span style="color:${c[n]}">${n.padEnd(8)}</span>`).join(" ") + "\n" + names.map((n) => `<span style="color:${c["bright_" + n]}">${n.padEnd(8)}</span>`).join(" ") + `\n<span style="background:${c.selection}">  ausgewählter Text  </span>  <span style="background:${c.cursor};color:${c.cursor_accent}"> </span> Cursor`;
    };
    CTL.push({ el: pvEl, sync: pv }); pv();
    return f;
  }),
  section("hervorhebung", "Code in Farben", () => {
    const f = [];
    f.push(h("h3", {}, "Ausgabe im Terminal"));
    f.push(row("", cChk("highlight.on", "Ausgabe farbig hervorheben (Fehler, Zahlen, Zeichenketten, Pfade, Code-Wörter …)"), "Die Hervorhebung färbt nur die Anzeige. Programme und Befehle merken nichts davon. In Vollbildprogrammen (vim, less, htop) ist sie aus, weil diese ihre eigenen Farben setzen.", true));
    f.push(row("", cChk("highlight.only_plain", "Nur Text einfärben, den das Programm nicht selbst gefärbt hat"), "Schützt z. B. die Farben von ls --color, git und der Eingabeaufforderung.", true));
    f.push(labelled("Längste geprüfte Zeile", cNum("highlight.max_line", { min: 80, max: 20000, unit: "Zeichen" })));
    f.push(h("h3", {}, "Farben der Hervorhebung"), h("div", { class: "hint", style: "margin-bottom:6px" }, "Sie leiten sich aus dem Farbschema ab. Eine eigene Farbe gilt für die Regeln, die darauf verweisen, und auch für „Datei in Farben anzeigen“."));
    const g = h("div", { class: "swatches" });
    S.meta.syntax_keys.forEach((k) => g.append(h("div", { class: "sw" }, cColor("syntax." + k, () => S.resolved.syntax[k], { clearable: true, label: S.meta.syntax_labels[k] }), h("span", { title: S.meta.syntax_labels[k] }, S.meta.syntax_labels[k]))));
    f.push(g, row("", btn("Alle eigenen Syntaxfarben entfernen", () => resetGroup("syntax", "Alle eigenen Syntaxfarben"), "danger")));
    f.push(h("h3", {}, "Regeln"), h("div", { class: "hint" }, "Jede Regel sucht mit einem Ausdruck (JavaScript-Schreibweise) in einer Bildschirmzeile. Die Regel weiter oben hat Vorrang, wenn sich zwei überschneiden."));
    f.push(h("div", { id: "rules" }));
    f.push(row("", [btn("Regel hinzufügen", addRule), btn("Standardregeln wiederherstellen", () => resetGroup("rules", "Alle Regeln"), "danger")]));
    f.push(h("h3", {}, "Ausprobieren"), h("textarea", { id: "ruleTest", rows: 8, spellcheck: "false", "aria-label": "Testtext für die Regeln" }, SAMPLE), h("div", { class: "preview", id: "ruleOut" }));
    setTimeout(() => { drawRules(); $("#ruleTest").addEventListener("input", drawRuleTest); drawRuleTest(); }, 0);
    return f;
  }),
  section("hintergrund", "Hintergrund", () => {
    const f = [];
    f.push(labelled("Art", cSel("bg.mode", [["farbe", "Einfarbig"], ["verlauf", "Farbverlauf"], ["bild", "Bild"]]), "Die Hintergrundfarbe selbst steht unter „Farben“ (Hintergrund)."));
    f.push(labelled("Hintergrundfarbe", cColor("colors.background", () => S.resolved.colors.background, { clearable: true, label: "Hintergrundfarbe" })));
    f.push(labelled("Zweite Farbe (Verlauf)", cColor("bg.color2", null, { label: "Zweite Farbe" })));
    f.push(labelled("Richtung (Verlauf)", cRange("bg.angle", { min: 0, max: 360, step: 5, unit: "°" })));
    const img = cText("bg.image", { placeholder: "/pfad/zum/bild.jpg" });
    f.push(labelled("Bild", h("span", { class: "ctl", style: "width:100%" }, img, btn("Wählen …", async () => { const p = await nat("pick_image", get(S.settings, "bg.image") || S.meta.home); if (p) commit({ bg: { image: p, mode: "bild" } }); }), btn("Entfernen", () => commit({ bg: { image: "", mode: S.settings.bg.mode === "bild" ? "farbe" : S.settings.bg.mode } })))));
    f.push(labelled("Bildanpassung", cSel("bg.fit", [["cover", "Füllen (zuschneiden)"], ["contain", "Einpassen"], ["strecken", "Strecken"], ["kacheln", "Kacheln"], ["mitte", "Mitte, Originalgröße"]])));
    f.push(labelled("Bildstärke", cRange("bg.image_opacity", { min: 0, max: 100, unit: " %" })));
    f.push(labelled("Abdunkeln über dem Bild", cRange("bg.dim", { min: 0, max: 100, unit: " %" }), "Macht Text auf hellen oder unruhigen Bildern lesbar."));
    f.push(labelled("Unschärfe des Bildes", cRange("bg.blur", { min: 0, max: 40, unit: " px" })));
    f.push(h("h3", {}, "Durchsichtiges Fenster"));
    f.push(labelled("Fenster insgesamt", cRange("window.opacity", { min: 35, max: 100, unit: " %" }), "Macht das ganze Fenster einschließlich Text durchsichtig. Dafür braucht der Desktop Compositing (Cinnamon und COSMIC haben es)."));
    f.push(row("", cChk("window.translucent", "Nur der Hintergrund soll durchsichtig sein (Text bleibt deckend)"), "Wirkt nach einem Neustart des Terminals.", true));
    f.push(labelled("Deckkraft des Hintergrunds", cRange("bg.opacity", { min: 0, max: 100, unit: " %" }), "Nur bei durchsichtigem Hintergrund."));
    const note = h("div", { class: "restart", id: "restartNote", hidden: true }, h("span", {}, "Die Einstellung „durchsichtiger Hintergrund“ gilt erst nach einem Neustart."), btn("Jetzt neu starten", () => BR.restart_app()));
    CTL.push({ el: note, sync: () => { note.hidden = S.settings.window.translucent === S.translucent; } }); note.hidden = S.settings.window.translucent === S.translucent;
    f.push(note, row("", btn("Hintergrund zurücksetzen", () => resetGroup("bg", "Den Hintergrund"), "danger")));
    return f;
  }),
  section("schrift", "Schrift & Cursor", () => {
    const f = [];
    const fam = cText("font.family", { list: "fontlist", placeholder: "z. B. JetBrains Mono, monospace" });
    const dl = h("datalist", { id: "fontlist" }); nat("fonts").then((j) => { JSON.parse(j).forEach((n) => dl.append(h("option", { value: n }))); });
    f.push(labelled("Schriftart", h("span", { class: "ctl", style: "width:100%" }, fam, dl, btn("Standard", () => commit({ font: { family: S.meta.default_family } }))), "Eine Schrift mit gleicher Zeichenbreite. Mehrere Namen mit Komma trennen, Namen mit Leerzeichen in Anführungszeichen."));
    f.push(labelled("Größe", cRange("font.size", { min: 6, max: 72, step: 1, unit: " pt" })));
    f.push(labelled("Zeilenabstand", cRange("font.line_height", { min: 1, max: 2.5, step: 0.05, fmt: (v) => v.toFixed(2) })));
    f.push(labelled("Buchstabenabstand", cRange("font.letter_spacing", { min: -3, max: 10, step: 0.5, unit: " px" })));
    f.push(labelled("Schriftstärke", cSel("font.weight", [["100", "Hauchdünn"], ["200", "Sehr dünn"], ["300", "Dünn"], ["normal", "Normal"], ["500", "Mittel"], ["600", "Halbfett"], ["bold", "Fett"]])));
    f.push(labelled("Stärke für Fettgedrucktes", cSel("font.weight_bold", [["normal", "Normal"], ["500", "Mittel"], ["600", "Halbfett"], ["bold", "Fett"], ["800", "Extrafett"], ["900", "Schwarz"]])));
    f.push(h("h3", {}, "Cursor"));
    f.push(labelled("Form", cSel("cursor.style", [["block", "Block"], ["bar", "Strich"], ["underline", "Unterstrich"]])));
    f.push(labelled("Breite des Striches", cNum("cursor.width", { min: 1, max: 8, unit: "px" })));
    f.push(row("", cChk("cursor.blink", "Cursor blinkt"), "", true));
    f.push(labelled("Blinken endet nach Ruhe", cNum("cursor.blink_timeout", { min: 0, max: 600, unit: "s" }), "Spart Strom: Ohne Eingabe und Ausgabe bleibt der Cursor nach dieser Zeit stehen. 0 = blinkt immer."));
    f.push(labelled("Ohne Fokus", cSel("cursor.inactive", [["outline", "Umriss"], ["block", "Block"], ["bar", "Strich"], ["underline", "Unterstrich"], ["none", "Unsichtbar"]])));
    f.push(row("", btn("Schrift und Cursor zurücksetzen", async () => { await resetGroup("font", "Die Schrift"); }, "danger")));
    return f;
  }),
  section("terminal", "Terminal", () => {
    const f = [];
    f.push(labelled("Zeilen im Verlauf", cNum("term.scrollback", { min: 0, max: 200000, step: 1000, unit: "Zeilen" }), "Gilt für neue Reiter sofort, für offene nach dem Leeren."));
    f.push(labelled("Mindestkontrast", cRange("term.min_contrast", { min: 1, max: 21, step: 0.5, fmt: (v) => (v <= 1 ? "aus" : v.toFixed(1) + ":1") }), "Hellt zu blasse Farben automatisch auf. 4,5 entspricht der Empfehlung für gut lesbaren Text, 1 schaltet es aus."));
    f.push(labelled("Signalton (Bell)", cSel("term.bell", [["aus", "Aus"], ["visuell", "Bild blitzt kurz"], ["ton", "Signalton"], ["beides", "Beides"]])));
    f.push(labelled("Rechte Maustaste", cSel("term.right_click", [["menu", "Menü zeigen"], ["einfuegen", "Einfügen"], ["nichts", "Nichts"]])));
    f.push(labelled("Mausrad: Tempo", cRange("term.scroll_sensitivity", { min: 0.1, max: 10, step: 0.1, fmt: (v) => v.toFixed(1) + "×" })));
    f.push(labelled("Mausrad mit Umschalt", cRange("term.fast_scroll", { min: 1, max: 50, step: 1, fmt: (v) => v + "×" })));
    f.push(labelled("Weiches Scrollen", cRange("term.smooth_scroll", { min: 0, max: 500, step: 10, fmt: (v) => (v ? v + " ms" : "aus") })));
    f.push(labelled("Wortgrenzen", cText("term.word_separator"), "Zeichen, die beim Doppelklick ein Wort begrenzen."));
    f.push(row("", cChk("term.copy_on_select", "Ausgewählten Text sofort kopieren"), "", true));
    f.push(row("", cChk("term.links", "Internetadressen mit Strg+Klick öffnen"), "", true));
    f.push(row("", cChk("term.bright_bold", "Fettgedruckter Text in hellen Farben"), "", true));
    f.push(row("", cChk("term.scroll_on_input", "Beim Tippen ans Ende springen"), "", true));
    f.push(row("", btn("Terminal-Einstellungen zurücksetzen", () => resetGroup("term", "Die Terminal-Einstellungen"), "danger")));
    return f;
  }),
  section("shell", "Shell & Profile", () => {
    const f = [];
    f.push(labelled("Neuer Reiter öffnet im", cSel("shell.new_tab_cwd", [["profil", "Ordner des Profils"], ["aktuell", "Ordner des aktuellen Reiters"]])));
    f.push(labelled("Wenn ein Programm endet", cSel("shell.on_exit", [["schließen", "Reiter schließen"], ["offen", "Reiter offen lassen"]])));
    f.push(labelled("Reitername", cSel("shell.title_mode", [["programm", "vom Programm gesetzter Titel"], ["ordner", "aktueller Ordner"], ["fest", "Name des Profils"]])));
    f.push(h("h3", {}, "Profile"), h("div", { class: "hint" }, "Ein Profil legt fest, welches Programm startet und wie. Das erste Profil ist der Standard. Leerer Befehl = deine Shell ($SHELL)."));
    f.push(h("div", { id: "profs" }));
    setTimeout(drawProfiles, 0);
    return f;
  }),
  section("fenster", "Fenster", () => {
    const f = [];
    f.push(labelled("Fenstertitel", cText("window.title"), "Platzhalter: {titel}, {profil}, {ordner}."));
    f.push(labelled("Rand um den Text", cRange("window.padding", { min: 0, max: 60, unit: " px" })));
    f.push(labelled("Reiterleiste", cSel("window.tabbar", [["oben", "Oben"], ["unten", "Unten"]])));
    f.push(row("", cChk("window.tabbar_autohide", "Reiterleiste verstecken, solange nur ein Reiter offen ist"), "Sie erscheint, wenn die Maus den oberen (oder unteren) Rand berührt.", true));
    f.push(row("", cChk("window.hide_tabs_fullscreen", "Im Vollbild die Reiterleiste verstecken"), "", true));
    f.push(labelled("Beim Start", cSel("window.start", [["normal", "Normales Fenster"], ["maximiert", "Maximiert"], ["vollbild", "Vollbild"]])));
    f.push(labelled("Startgröße", h("span", { class: "ctl" }, cNum("window.width", { min: 300, max: 8000, unit: "×" }), cNum("window.height", { min: 200, max: 6000, unit: "px" }))));
    f.push(row("", cChk("window.remember_geometry", "Größe und Platz des Fensters merken"), "", true));
    f.push(row("", cChk("window.on_top", "Fenster immer im Vordergrund"), "Unter Wayland (COSMIC) kann der Desktop das ablehnen.", true));
    f.push(labelled("Beim Schließen nachfragen", cSel("window.confirm_close", [["nie", "Nie"], ["laufend", "Wenn ein Programm läuft"], ["immer", "Immer, wenn Reiter offen sind"]])));
    f.push(row("", btn("Fenster-Einstellungen zurücksetzen", () => resetGroup("window", "Die Fenster-Einstellungen"), "danger")));
    return f;
  }),
  section("tasten", "Tastenkürzel", () => {
    const f = [h("div", { class: "hint", style: "margin:8px 0" }, "Jede Aktion kann bis zu vier Kürzel haben. Alt+1 bis Alt+9 springen zum Reiter mit dieser Nummer. Alles andere geht unverändert an das Programm im Terminal."), h("div", { id: "keys" })];
    f.push(row("", btn("Alle Tastenkürzel zurücksetzen", () => resetGroup("keys", "Alle Tastenkürzel"), "danger")));
    setTimeout(drawKeys, 0);
    return f;
  }),
  section("sichern", "Sichern", () => {
    const f = [];
    f.push(h("h3", {}, "Einstellungen sichern und übertragen"), h("div", { class: "hint" }, "Alle Einstellungen stehen in einer Textdatei (JSON). So lassen sie sich auf einen anderen Rechner mitnehmen."));
    f.push(row("", [btn("Exportieren …", async () => { const p = await nat("pick_save", S.meta.home, "seifferts-terminal.json"); if (!p) return; try { const r = await api("settings_export", { path: p }); toast("Gespeichert: " + r.path); } catch (e) { toast(e.message, true); } }),
      btn("Importieren …", async () => { const p = await nat("pick_file", S.meta.home); if (!p) return; try { const r = await api("settings_import", { path: p }); S.settings = r.settings; S.resolved = r.resolved; applyAll(); renderSection(curSection); toast("Eingelesen."); } catch (e) { toast(e.message, true); } })]));
    f.push(h("h3", {}, "Alles zurücksetzen"), row("", btn("Alle Einstellungen auf die Vorgaben", () => resetGroup("", "Alle Einstellungen"), "danger")));
    f.push(h("h3", {}, "Über"), h("div", { class: "hint" }, `Seifferts Terminal ${S.meta.version}. Einstellungen: ~/.config/seiffert-terminal/settings.json`));
    return f;
  }),
];

function renderSection(id) {
  curSection = id;
  CTL.length = 0;
  const sec = SECTIONS.find((s) => s.id === id) || SECTIONS[0];
  const box = $("#scontent"); box.textContent = ""; box.append(...sec.build());
  $$("#snav button").forEach((b) => b.setAttribute("aria-current", b.dataset.id === sec.id ? "true" : "false"));
  box.scrollTop = 0;
}
function buildNav() {
  const nav = $("#snav"); nav.textContent = "";
  SECTIONS.forEach((s) => { const b = h("button", { type: "button", "data-id": s.id }, s.title); b.addEventListener("click", () => renderSection(s.id)); nav.append(b); });
}
function toggleSettings(force) {
  const el = $("#settings"), open = force === undefined ? !el.classList.contains("on") : force;
  el.classList.toggle("on", open);
  if (open) { if (!$("#snav").children.length) buildNav(); renderSection(curSection); $("#snav button[aria-current=true]").focus(); }
  else if (S.cur) S.cur.term.focus();
  $("#bSet").setAttribute("aria-pressed", open ? "true" : "false");
  layoutSoon();
}

/* ---- Regeln ---- */
let rules = [];
function ruleBad(r) { try { new RegExp(r.pattern, "g" + r.flags); return ""; } catch (e) { return e.message; } }
function saveRules() { for (const r of rules) { if (!r.pattern) return; if (ruleBad(r)) return; } commit({ rules }); }
function addRule() { rules.push({ id: "eigene-" + Date.now().toString(36), name: "Neue Regel", on: true, pattern: "\\bTODO\\b", flags: "", color: "warn", bg: "" }); drawRules(true); saveRules(); }
function drawRules(keep = false) {
  const box = $("#rules"); if (!box) return;
  if (!keep) rules = JSON.parse(JSON.stringify(S.settings.rules));
  box.textContent = "";
  rules.forEach((r, i) => {
    const bad = h("div", { class: "bad", hidden: true });
    const upd = () => { const m = ruleBad(r); bad.hidden = !m; bad.textContent = m ? "Der Ausdruck ist ungültig: " + m + " (Diese Regel wird nicht gespeichert.)" : ""; };
    const on = h("input", { type: "checkbox", checked: r.on, "aria-label": "Regel an" }); on.addEventListener("change", () => { r.on = on.checked; card.classList.toggle("off", !r.on); saveRules(); drawRuleTest(); });
    const name = h("input", { type: "text", value: r.name, "aria-label": "Name der Regel" }); name.addEventListener("change", () => { r.name = name.value; saveRules(); });
    const col = h("select", { "aria-label": "Farbe der Regel" }, S.meta.syntax_keys.map((k) => h("option", { value: k }, S.meta.syntax_labels[k])), h("option", { value: "#" }, "Eigene Farbe …"));
    const cc = h("input", { type: "color", value: r.color[0] === "#" ? r.color : "#ffffff", "aria-label": "Eigene Farbe" });
    const showC = () => { col.value = r.color[0] === "#" ? "#" : r.color; cc.hidden = r.color[0] !== "#"; };
    col.addEventListener("change", () => { r.color = col.value === "#" ? cc.value : col.value; showC(); saveRules(); drawRuleTest(); });
    cc.addEventListener("input", debounce(() => { r.color = cc.value; saveRules(); drawRuleTest(); }, 80));
    const pat = h("input", { type: "text", class: "pat", value: r.pattern, spellcheck: "false", "aria-label": "Suchausdruck" });
    pat.addEventListener("input", () => { r.pattern = pat.value; upd(); drawRuleTest(); }); pat.addEventListener("change", saveRules);
    const fl = h("input", { type: "text", value: r.flags, style: "width:54px", "aria-label": "Schalter", title: "Schalter: i = Groß/klein egal, m = ^ und $ je Zeile, s = Punkt trifft Zeilenumbruch" });
    fl.addEventListener("change", () => { r.flags = fl.value.replace(/[^ims]/g, ""); fl.value = r.flags; upd(); saveRules(); drawRuleTest(); });
    const up = btn("▲", () => { if (i > 0) { [rules[i - 1], rules[i]] = [rules[i], rules[i - 1]]; saveRules(); drawRules(true); } }, "small"); up.setAttribute("aria-label", "Nach oben"); up.title = "Weiter nach oben (höherer Vorrang)";
    const dn = btn("▼", () => { if (i < rules.length - 1) { [rules[i + 1], rules[i]] = [rules[i], rules[i + 1]]; saveRules(); drawRules(true); } }, "small"); dn.setAttribute("aria-label", "Nach unten");
    const del = btn("Löschen", () => { rules.splice(i, 1); saveRules(); drawRules(true); drawRuleTest(); }, "small danger");
    const card = h("div", { class: "rule" + (r.on ? "" : " off") }, on, name, h("span", {}, up, dn),
      h("div", { class: "line2" }, h("span", {}, "Farbe:"), col, cc, h("span", {}, "Schalter:"), fl, h("span", { style: "flex:1" }), del), pat, bad);
    showC(); upd(); box.append(card);
  });
}
function drawRuleTest() {
  const out = $("#ruleOut"), src = $("#ruleTest"); if (!out || !src) return;
  const rx = []; for (const r of rules) { if (r.on && r.pattern && !ruleBad(r)) rx.push({ re: new RegExp(r.pattern, "g" + r.flags), color: r.color, bg: r.bg }); }
  const c = S.resolved.colors; out.style.background = c.background; out.style.color = c.foreground;
  out.innerHTML = src.value.split("\n").map((ln) => SyntaxLib.ruleSpans(ln, rx).map(([cl, t]) => cl ? `<span style="color:${synColor(cl)}">${E(t)}</span>` : E(t)).join("")).join("\n");
}

/* ---- Profile ---- */
let profSel = 0;
function drawProfiles() {
  const box = $("#profs"); if (!box) return;
  const ps = JSON.parse(JSON.stringify(S.settings.profiles)); profSel = Math.min(profSel, ps.length - 1);
  box.textContent = "";
  const tabs = h("div", { class: "proftabs", role: "group", "aria-label": "Profile" });
  ps.forEach((p, i) => { const b = h("button", { type: "button", "aria-pressed": i === profSel ? "true" : "false" }, p.name + (i === 0 ? " ★" : "")); b.addEventListener("click", () => { profSel = i; drawProfiles(); }); tabs.append(b); });
  tabs.append(btn("+ Profil", () => { ps.push({ name: "Profil " + (ps.length + 1), command: "", args: [], cwd: "", login: false, env: {}, theme: "" }); profSel = ps.length - 1; saveProfiles(ps); }, "small"));
  box.append(tabs);
  const p = ps[profSel];
  const f = (label, el, hint) => labelled(label, el, hint);
  const name = h("input", { type: "text", value: p.name }); name.addEventListener("change", () => { p.name = name.value; saveProfiles(ps, false); });
  const cmd = h("input", { type: "text", value: p.command, placeholder: "leer = $SHELL, z. B. /usr/bin/fish oder htop", spellcheck: "false" }); cmd.addEventListener("change", () => { p.command = cmd.value; saveProfiles(ps, false); });
  const args = h("input", { type: "text", value: shJoin(p.args), placeholder: "z. B. -l oder --login", spellcheck: "false" }); args.addEventListener("change", () => { p.args = args.value; saveProfiles(ps, false); });
  const cwd = h("input", { type: "text", value: p.cwd, placeholder: "leer = Home", spellcheck: "false" }); cwd.addEventListener("change", () => { p.cwd = cwd.value; saveProfiles(ps, false); });
  const login = h("input", { type: "checkbox", checked: p.login }); login.addEventListener("change", () => { p.login = login.checked; saveProfiles(ps, false); });
  const env = h("textarea", { rows: 3, spellcheck: "false", placeholder: "NAME=Wert, eine je Zeile" }, Object.entries(p.env).map(([k, v]) => k + "=" + v).join("\n")); env.addEventListener("change", () => { p.env = env.value; saveProfiles(ps, false); });
  const th = h("select", {}, h("option", { value: "" }, "wie in den allgemeinen Einstellungen"), S.meta.themes.map((t) => h("option", { value: t.id }, t.label))); th.value = p.theme; th.addEventListener("change", () => { p.theme = th.value; saveProfiles(ps, false); });
  box.append(f("Name", name), f("Befehl", cmd), f("Argumente", args, "Mit Anführungszeichen wie in der Shell."), f("Startordner", h("span", { class: "ctl", style: "width:100%" }, cwd, btn("Wählen …", async () => { const d = await nat("pick_dir", p.cwd || S.meta.home); if (d) { p.cwd = d; saveProfiles(ps); } }, "small"))),
    row("", h("label", { style: "display:inline-flex;gap:8px;align-items:center" }, login, "Als Anmelde-Shell starten (-l)"), "", true),
    f("Farbschema", th, "Eigene Farben aus „Farben“ gelten nur für das allgemeine Farbschema."), f("Umgebung", env));
  const acts = h("div", { class: "ctl", style: "margin-top:8px" },
    btn("Reiter mit diesem Profil öffnen", () => openTerminalTab({ profile: p.name })),
    btn("Als Standard", () => { if (profSel > 0) { const [x] = ps.splice(profSel, 1); ps.unshift(x); profSel = 0; saveProfiles(ps); } }),
    btn("Duplizieren", () => { const c = JSON.parse(JSON.stringify(p)); c.name += " Kopie"; ps.push(c); profSel = ps.length - 1; saveProfiles(ps); }),
    btn("Löschen", () => { if (ps.length < 2) { toast("Ein Profil muss bleiben.", true); return; } ps.splice(profSel, 1); profSel = Math.max(0, profSel - 1); saveProfiles(ps); }, "danger"));
  box.append(acts);
}
async function saveProfiles(ps, structural = true) {
  const r = await commit({ profiles: ps });
  if (structural || !r) drawProfiles();
  else { const b = $("#profs .proftabs button[aria-pressed=true]"); if (b) b.textContent = S.settings.profiles[profSel].name + (profSel === 0 ? " ★" : ""); }
}

/* ---- Tastenkürzel ---- */
function drawKeys() {
  const box = $("#keys"); if (!box) return;
  box.textContent = "";
  for (const [a, label] of Object.entries(S.meta.key_actions)) {
    const list = S.settings.keys[a] || [];
    const chips = h("div", { class: "keyrow" }, list.map((c, i) => h("span", { class: "chip" }, h("span", {}, c), (() => { const x = h("button", { type: "button", "aria-label": c + " entfernen", title: "Entfernen" }, "✕"); x.onclick = async () => { await commit({ keys: { [a]: list.filter((_, j) => j !== i) } }); drawKeys(); }; return x; })())),
      list.length ? null : h("span", { class: "hint", style: "grid-column:auto" }, "kein Kürzel"),
      btn("+ Taste", async () => { const c = await captureKey(label); if (!c) return; await commit({ keys: { [a]: [...list, c] } }); drawKeys(); }, "small"));
    box.append(h("div", { class: "row" }, h("label", {}, label), chips));
  }
}
function captureKey(label) {
  return new Promise((res) => {
    S.capturing = true;
    const o = h("div", { id: "capture" }, h("div", { role: "dialog", "aria-modal": "true" }, h("div", {}, "Neues Kürzel für „" + label + "“"), h("b", {}, "…"), h("div", { class: "hint", style: "margin-top:8px" }, "Taste drücken. Esc bricht ab.")));
    const out = $("b", o);
    const done = (v) => { document.removeEventListener("keydown", onk, true); S.capturing = false; o.remove(); res(v); };
    const onk = (e) => {
      e.preventDefault(); e.stopPropagation();
      if (["Control", "Shift", "Alt", "Meta", "AltGraph"].includes(e.key)) return;
      if (e.key === "Escape" && !e.ctrlKey && !e.altKey && !e.shiftKey) { done(""); return; }
      const c = comboOf(e); if (!c) { out.textContent = "Diese Taste geht nicht."; return; }
      if (!/\+/.test(c) && !/^F\d+$/.test(c)) { out.textContent = c + ": mit Strg, Alt oder Umschalt"; return; }
      done(c);
    };
    document.addEventListener("keydown", onk, true); document.body.append(o);
  });
}

/* ======================================================================
   Start
   ====================================================================== */
async function start() {
  const meta = await api("settings_get");
  S.meta = meta; S.settings = meta.settings; S.resolved = meta.resolved; S.args = meta.args || {};
  S.translucent = !!(await nat("window_translucent"));
  S.full = !!(await nat("is_fullscreen")); document.body.classList.toggle("full", S.full);
  applyAll();
  S.firstDir = S.args.dir || "";
  if (S.args.view) { try { await openViewTab(S.args.view); } catch (e) { toast(e.message, true); } }
  if (S.args.exec && S.args.exec.length) await openTerminalTab({ command: S.args.exec[0], args: S.args.exec.slice(1) });
  else if (!S.args.view || S.args.dir || S.args.profile) await openTerminalTab({ profile: S.args.profile });
  if (!S.tabs.length) await openTerminalTab({});
  setInterval(pollState, 2000);
  window.SD_READY = true;
}
async function pollState() {
  if (document.hidden) return;
  let changed = false;
  for (const t of S.tabs) {
    if (t.kind !== "term" || !t.alive || !t.tid) continue;
    try { const s = await api("term_state", { id: t.tid }); if (s.cwd !== t.cwd || s.idle !== t.idle) { t.cwd = s.cwd; t.idle = s.idle; changed = true; updateTab(t); } } catch { /* Reiter schon weg */ }
  }
  if (changed) updateTitle();
}
new QWebChannel(qt.webChannelTransport, (ch) => {
  BR = ch.objects.bridge; window.BRX = BR;
  BR.done.connect((id, json) => { const p = PEND.get(id); if (!p) return; PEND.delete(id); const r = JSON.parse(json); if (r.error) p.rej(new Error(r.error)); else p.res(r.result); });
  BR.event.connect((name, json) => { const d = JSON.parse(json); if (name === "term") onTermEvent(d); });
  start().catch((e) => { document.body.insertAdjacentHTML("afterbegin", `<pre style="color:#ff6b6b;padding:20px;position:relative;z-index:9">Startfehler: ${E(e.stack || e.message)}</pre>`); });
});
