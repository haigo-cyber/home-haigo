"""Hilfen für den Start im Autostart: auf die grafische Sitzung warten, die Wayland-Verbindung finden und Meldungen in eine
Protokolldatei schreiben (im Autostart sieht niemand die Fehlerausgabe). Nur Standardbibliothek."""
from __future__ import annotations

import glob
import os
import stat
import sys
import time


def _runtime_dir() -> str:
    return os.environ.get("XDG_RUNTIME_DIR") or "/run/user/%d" % os.getuid()


def _is_socket(path: str) -> bool:
    try:
        return stat.S_ISSOCK(os.stat(path).st_mode)
    except OSError:
        return False


def wayland_ready() -> bool:
    wd = os.environ.get("WAYLAND_DISPLAY")
    if not wd:
        return False
    return _is_socket(wd if os.path.isabs(wd) else os.path.join(_runtime_dir(), wd))


def adopt_session(wait: float = 0.0) -> bool:
    """Sorgt dafür, dass WAYLAND_DISPLAY oder DISPLAY stimmen, und wartet höchstens `wait` Sekunden auf die Sitzung.
    Fehlt WAYLAND_DISPLAY im Autostart, wird der erste vorhandene Wayland-Anschluss (wayland-0, wayland-1, ...) übernommen."""
    if os.environ.get("QT_QPA_PLATFORM") in ("offscreen", "minimal", "vnc", "linuxfb"):
        return True                                      # ausdrücklich gewählte Plattform ohne Anzeige: nicht warten
    end = time.time() + max(0.0, wait)
    while True:
        if wayland_ready():
            return True
        socks = sorted(p for p in glob.glob(os.path.join(_runtime_dir(), "wayland-*")) if not p.endswith(".lock") and _is_socket(p))
        if socks and not os.environ.get("WAYLAND_DISPLAY"):
            os.environ["WAYLAND_DISPLAY"] = os.path.basename(socks[0])
            return True
        if os.environ.get("DISPLAY") and os.environ.get("XDG_SESSION_TYPE", "") != "wayland":
            return True
        if time.time() >= end:
            return bool(os.environ.get("DISPLAY"))
        time.sleep(0.4)


def log_to_file(name: str, limit: int = 200_000) -> str:
    """Leitet Fehlerausgabe (stderr) in ~/.local/state/seiffert-dateien/<name> um und gibt den Pfad zurück ('' bei Misserfolg)."""
    base = os.environ.get("XDG_STATE_HOME") or os.path.join(os.path.expanduser("~"), ".local", "state")
    d = os.path.join(base, "seiffert-dateien")
    path = os.path.join(d, name)
    try:
        os.makedirs(d, exist_ok=True)
        if os.path.exists(path) and os.path.getsize(path) > limit:
            os.replace(path, path + ".alt")
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        os.write(fd, ("--- %s Start (WAYLAND_DISPLAY=%s DISPLAY=%s XDG_SESSION_TYPE=%s)\n" % (
            time.strftime("%Y-%m-%d %H:%M:%S"), os.environ.get("WAYLAND_DISPLAY", ""), os.environ.get("DISPLAY", ""),
            os.environ.get("XDG_SESSION_TYPE", ""))).encode())
        os.dup2(fd, 2)
        os.close(fd)
        sys.stderr = os.fdopen(2, "w", buffering=1, closefd=False)
        return path
    except OSError:
        return ""
