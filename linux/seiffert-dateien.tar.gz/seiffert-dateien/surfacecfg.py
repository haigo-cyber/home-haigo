"""Einstellungen von Seifferts Oberfläche (nur Standardbibliothek).

Die Oberfläche ist das Programm, das auf COSMIC (Wayland) oder unter X11 den Schreibtisch zeichnet: Hintergrund, Symbole und das
Starter-Symbol. Ihre Einstellungen liegen in einer eigenen Datei (surface.json im Konfigurationsordner von Seifferts Dateien), nicht
in config.json: So kann das Programm der Oberfläche etwa das Hintergrundbild ändern, ohne dass Seifferts Dateien beim nächsten Speichern
seiner eigenen Einstellungen diese Änderung überschreibt. Beide Programme lesen die Datei bei jedem Zugriff neu.
"""
from __future__ import annotations

import json
import os
import re
import tempfile
from pathlib import Path

APP_ID = "seiffert-dateien"

SURFACE_DEFAULTS: dict = {
    # Hintergrund
    "bg_image": "",           # Pfad zu einem Bild; leer = nur Farbe
    "bg_fit": "cover",        # cover (füllen) | contain (einpassen) | stretch (strecken) | center (mittig) | tile (kacheln)
    "bg_color": "#14303c",    # Farbe hinter dem Bild und ohne Bild
    "bg_dim": 0,              # Bild abdunkeln, 0 bis 80 Prozent
    # Fläche
    "layer": "bottom",        # bottom (über dem COSMIC-Hintergrund) | background (ganz unten)
    "monitors": "all",        # all | primary: Hintergrund auf allen oder nur auf dem Hauptbildschirm
    "extend": True,           # Hintergrund reicht auch unter Leisten und Docks
    "margin_top": 48, "margin_right": 24, "margin_bottom": 72, "margin_left": 24,   # freier Rand für Symbole (Leisten!)
    # Symbole
    "icons_on": True,
    "icons_source": "desktop",  # desktop (Schreibtisch-Ordner) | favorites | both
    "icon_px": 64,            # Kantenlänge der Symbole, 32 bis 160
    "labels": True,
    "label_color": "hell",    # hell | dunkel
    "flow": "down",           # down (spaltenweise von oben) | right (zeilenweise von links)
    "spacing": 14,            # zusätzlicher Abstand zwischen den Symbolen, 0 bis 80
    "hidden": False,          # versteckte Dateien zeigen
    "sort": "name",           # name | type | mtime
    "dirs_first": True,
    "single_click": False,    # ein Klick öffnet (sonst Doppelklick)
    # Starter-Symbol
    "show_starter": True,
    "starter_corner": "bl",   # tl | tr | bl | br
    "starter_px": 56,         # 32 bis 128
    "starter_ready": True,    # Starter beim Start der Oberfläche im Hintergrund bereithalten
    # Uhr (nur auf dem Hauptbildschirm)
    "clock_on": True,
    "clock_style": "digital",  # digital | analog
    "clock_corner": "tr",     # tl | tc | tr | bl | br | c (oben links, oben Mitte, oben rechts, unten links, unten rechts, Mitte)
    "clock_px": 56,           # digital: Schriftgröße der Uhrzeit; analog: Zifferblatt = dreimal so groß; 16 bis 200
    "clock_opacity": 70,      # Deckkraft in Prozent: 100 = voll sichtbar, weniger = durchsichtiger; 5 bis 100
    "clock_color": "#ffffff",
    "clock_seconds": False,   # Sekunden (digital) beziehungsweise Sekundenzeiger (analog)
    "clock_24h": True,        # 24-Stunden-Anzeige (sonst 12 Stunden mit AM/PM; nur digital)
    "clock_date": True,       # Wochentag und Datum unter der Uhr
    # Beenden und Start
    "alt_x": True,            # Alt+X beendet die Oberfläche (wenn sie den Fokus hat)
    "start_delay": 2,         # Sekunden Wartezeit beim Autostart, 0 bis 30
}

CHOICES = {
    "bg_fit": ("cover", "contain", "stretch", "center", "tile"),
    "layer": ("bottom", "background"),
    "monitors": ("all", "primary"),
    "icons_source": ("desktop", "favorites", "both"),
    "label_color": ("hell", "dunkel"),
    "flow": ("down", "right"),
    "sort": ("name", "type", "mtime"),
    "starter_corner": ("tl", "tr", "bl", "br"),
    "clock_style": ("digital", "analog"),
    "clock_corner": ("tl", "tc", "tr", "bl", "br", "c"),
}
INT_RANGES = {
    "bg_dim": (0, 80), "margin_top": (0, 600), "margin_right": (0, 600), "margin_bottom": (0, 600), "margin_left": (0, 600),
    "icon_px": (32, 160), "spacing": (0, 80), "starter_px": (32, 128), "start_delay": (0, 30),
    "clock_px": (16, 200), "clock_opacity": (5, 100),
}
BOOLS = ("extend", "icons_on", "labels", "hidden", "dirs_first", "single_click", "show_starter", "starter_ready", "alt_x",
         "clock_on", "clock_seconds", "clock_24h", "clock_date")
LABELS = {
    "bg_fit": "Bildanpassung", "layer": "Ebene", "monitors": "Bildschirme", "icons_source": "Quelle der Symbole",
    "label_color": "Beschriftungsfarbe", "flow": "Anordnung", "sort": "Sortierung", "starter_corner": "Ecke des Starter-Symbols",
    "clock_style": "Art der Uhr", "clock_corner": "Platz der Uhr", "clock_px": "Größe der Uhr", "clock_opacity": "Deckkraft der Uhr",
}


def config_dir() -> Path:
    return Path(os.environ.get("XDG_CONFIG_HOME") or (Path.home() / ".config")) / APP_ID


def surface_path() -> Path:
    return config_dir() / "surface.json"


def clean(v, base: dict | None = None) -> dict:
    """Prüft Einstellungen und ergänzt fehlende mit den bisherigen Werten (base) oder den Standardwerten.

    Unbekannte Schlüssel werden verworfen, ungültige Werte lösen ValueError mit einer deutschen Meldung aus."""
    if not isinstance(v, dict):
        raise ValueError("Die Einstellungen der Oberfläche sind ungültig.")
    out = dict(SURFACE_DEFAULTS)
    if base:
        out.update({k: base[k] for k in SURFACE_DEFAULTS if k in base})
    for k, val in v.items():
        if k not in SURFACE_DEFAULTS:
            continue
        if k in CHOICES:
            if val not in CHOICES[k]:
                raise ValueError("Ungültiger Wert für %s." % LABELS.get(k, k))
        elif k in INT_RANGES:
            lo, hi = INT_RANGES[k]
            try:
                val = int(val)
            except (TypeError, ValueError):
                raise ValueError("%s muss eine Zahl zwischen %d und %d sein." % (k, lo, hi))
            if not lo <= val <= hi:
                raise ValueError("%s muss zwischen %d und %d liegen." % (k, lo, hi))
        elif k in BOOLS:
            if not isinstance(val, bool):
                raise ValueError("%s muss an oder aus sein." % k)
        elif k in ("bg_color", "clock_color"):
            val = str(val or "").strip()
            if not re.fullmatch(r"#[0-9a-fA-F]{6}", val):
                raise ValueError("Die %s muss die Form #rrggbb haben." % ("Hintergrundfarbe" if k == "bg_color" else "Farbe der Uhr"))
            val = val.lower()
        elif k == "bg_image":
            val = str(val or "").strip()
            if len(val) > 1000 or any(ord(c) < 32 for c in val):
                raise ValueError("Der Pfad des Hintergrundbilds ist ungültig.")
            if val.startswith("~"):
                val = os.path.expanduser(val)
        out[k] = val
    return out


def load() -> dict:
    """Aktuelle Einstellungen (Standardwerte, überlagert von den gültigen gespeicherten Werten)."""
    out = dict(SURFACE_DEFAULTS)
    try:
        stored = json.loads(surface_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return out
    if isinstance(stored, dict):
        for k, val in stored.items():
            if k not in SURFACE_DEFAULTS:
                continue
            try:
                out[k] = clean({k: val}, out)[k]
            except ValueError:
                pass                                   # ungültiger gespeicherter Wert: Standardwert behalten
    return out


def save(conf: dict) -> None:
    d = config_dir()
    d.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix="surface.", suffix=".tmp", dir=str(d))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(conf, f, ensure_ascii=False, indent=1)
        os.replace(tmp, surface_path())
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def update(patch: dict) -> dict:
    """Liest die Datei neu, wendet die Änderung an und schreibt sie zurück (gilt für beide Programme)."""
    new = clean(patch, load())
    save(new)
    return new
