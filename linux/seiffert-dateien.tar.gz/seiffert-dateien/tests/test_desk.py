#!/usr/bin/env python3
"""Prüfungen für das Starter-Design Schreibtisch (Version 2.9): Farbschemata, Einstellungen, Anordnung, Bedienung, Umschalten.
Aufruf:  QT_QPA_PLATFORM=offscreen python tests/test_desk.py   (das Fenster im Vollbild prüft tests/ui_desk.sh unter Xvfb)"""
import json
import os
import re
import shutil
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HOME = tempfile.mkdtemp(prefix="sd-desk-home-")
os.environ.update(HOME=HOME, XDG_CONFIG_HOME=HOME + "/.config", XDG_DATA_HOME=HOME + "/.local/share", XDG_CACHE_HOME=HOME + "/.cache",
                  TMPDIR=HOME, SEIFFERT_STARTER_NOHIDE="1")
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, HERE)
PASS = FAIL = 0


def check(name, cond, info=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        print("FEHLER: %s %s" % (name, info))


def lum(h):
    c = [int(h[i:i + 2], 16) / 255 for i in (1, 3, 5)]
    c = [v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4 for v in c]
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]


def contrast(a, b):
    x, y = sorted((lum(a), lum(b)), reverse=True)
    return (x + 0.05) / (y + 0.05)


import backend as B  # noqa: E402
import skins  # noqa: E402
import starterextra as SX  # noqa: E402
import startersetup as SS  # noqa: E402

# ---- Farbschemata: Lesbarkeit für jedes Farbdesign und jedes Schema (mindestens 4,5:1 wie bei normaler Schrift)
bad = []
for sk in skins.SKINS:
    for sc in skins.DESK_SCHEMES:
        p = skins.desk_palette(sk, sc)
        for fg, bgs in (("ink", ("tile", "tile_hi", "tile_lo", "bar", "bg0", "bg1")), ("muted", ("tile", "tile_hi", "bar", "bg0")), ("accent", ("tile", "bar", "bg0")),
                        ("accent_ink", ("accent",)), ("warn", ("tile", "bar"))):
            for bg in bgs:
                if contrast(p[fg], p[bg]) < 4.5:
                    bad.append("%s/%s %s auf %s = %.1f" % (sk, sc, fg, bg, contrast(p[fg], p[bg])))
check("Kontrast mindestens 4,5:1 in allen 28 Paletten", not bad, "; ".join(bad[:6]))
check("vier Farbschemata, je mit Beschriftung und Beschreibung", len(skins.DESK_SCHEMES) == 4 and all(s in skins.DESK_LABELS and s in skins.DESK_NOTES for s in skins.DESK_SCHEMES))
check("Neon ist heller als der Akzent, Metall und Neon unterscheiden sich", skins.desk_palette("indigo", "neon")["accent"] != skins.palette("indigo", True)["accent"]
      and skins.desk_palette("wald", "metall")["metal"] and not skins.desk_palette("wald", "dunkel")["metal"])
check("unbekanntes Schema fällt auf dunkel", skins.desk_palette("petrol", "quatsch")["scheme"] == "dunkel")
html = open(os.path.join(HERE, "index.html"), encoding="utf-8").read()
js_ids = re.findall(r'\["([a-z]+)", "[^"]+", "[^"]+"\]', html[html.index("const DESK_SCHEMES"):html.index("async function starterDialog")])
check("Oberfläche bietet dieselben Farbschemata an wie skins.py", tuple(js_ids) == skins.DESK_SCHEMES, str(js_ids))

# ---- Einstellungen prüfen
d = B.STARTER_DEFAULTS
check("Vorgaben: Schreibtisch, dauerhaft, Vollbild an, Hintergrund aus dem Schema", (d["design"], d["desk_resident"], d["desk_full"], d["desk_bg"], d["desk_side"]) == ("desk", True, True, "schema", "left"))
ok = SS.clean_starter({"design": "desk", "desk_scheme": "neon", "desk_btn": 500, "desk_bg_dim": -5, "desk_bg_color": "#AABBCC", "desk_full": 0})
check("Werte begrenzt und bereinigt", (ok["design"], ok["desk_scheme"], ok["desk_btn"], ok["desk_bg_dim"], ok["desk_bg_color"], ok["desk_full"]) == ("desk", "neon", 128, 0, "#aabbcc", False), str(ok))
for k, v in (("design", "x"), ("desk_scheme", "x"), ("desk_bg", "x"), ("desk_bg_color", "rot"), ("desk_btn", "abc"), ("desk_side", "oben"), ("desk_bg_image", "a\nb")):
    try:
        SS.clean_starter({k: v})
        check("abgelehnt: %s=%r" % (k, v), False)
    except B.AppError:
        check("abgelehnt: %s=%r" % (k, v), True)

# ---- eingebaute Befehle
names = {c["builtin"] for c in SX.builtin_commands()}
check("Befehle zum Umschalten und für die Farbschemata", {"design:wolke", "design:desk"} <= names and {"deskscheme:" + s for s in skins.DESK_SCHEMES} <= names)

# ---- Fenster
import starter as ST  # noqa: E402
Cloud, QApp = ST.build_ui()
app = QApp(["test"])
backend = B.Backend()
finder = ST.Finder(backend)
I = ST.Item
ITEMS = [I("app", "Firefox Webbrowser", "firefox"), I("folder", "Unterricht", "/h/u"), I("file", "Wochenplan.pdf", "/h/w.pdf", extra={"ext": "pdf"}), I("app", "Terminal", "t"),
         I("system", "Herunterfahren", "poweroff"), I("command", "Text vom Bildschirm lesen", "c", extra={"builtin": "ocr"})]
desk = Cloud.Desk(finder, backend)
check("Desk erbt von der Wolke", issubclass(Cloud.Desk, Cloud) and Cloud.Desk is not Cloud)
desk.resize(1280, 760)
desk.apply_options()
desk.items = list(ITEMS)
desk._layout()
check("eine Kachel je Treffer, alle im Fenster", len(desk.rects) == 6 and all(desk.rect().contains(r.toAlignedRect()) for r in desk.rects))
check("Kacheln überlappen nicht", all(not a.intersects(b) for i, a in enumerate(desk.rects) for b in desk.rects[i + 1:]))
check("neun Seitenknöpfe, quadratisch", len(desk.dock) == 9 and all(abs(r.width() - r.height()) < 0.01 for r, _ in desk.dock))
check("Knöpfe links, Kacheln rechts davon", all(r.right() < desk.rects[0].left() for r, _ in desk.dock))
check("Knöpfe liegen untereinander ohne Überschneidung", all(a[0].bottom() <= b[0].top() for a, b in zip(desk.dock, desk.dock[1:])))

backend.api_set_config({"starter": {"desk_btn": 40}})
desk.f.refresh(); desk.apply_options()
check("Knopfgröße einstellbar", abs(desk.dock[0][0].width() - 40) < 0.01, str(desk.dock[0][0].width()))
backend.api_set_config({"starter": {"desk_btn": 64, "desk_side": "right"}})
desk.f.refresh(); desk.apply_options(); desk.items = list(ITEMS); desk._layout()
check("Knöpfe auf Wunsch rechts", desk.dock[0][0].left() > desk.rects[-1].right() and desk.dock[0][0].right() < desk.width())
check("Eingabefeld liegt in der Leiste", desk.bar.toAlignedRect().contains(desk.edit.geometry()), "%s %s" % (desk.bar, desk.edit.geometry()))
backend.api_set_config({"starter": {"desk_side": "left"}})
desk.f.refresh(); desk.apply_options(); desk.items = list(ITEMS); desk._layout()

small = Cloud.Desk(finder, backend)
small.resize(800, 520); small.apply_options(); small.items = [I("app", "Programm %d" % n, "p%d" % n) for n in range(40)]; small._layout()
check("kleines Fenster: nur so viele Kacheln, wie hineinpassen", 1 <= len(small.items) < 40 and len(small.rects) == len(small.items))
check("kleines Fenster: Knöpfe schrumpfen und passen in die Höhe", small.dock[-1][0].bottom() <= small.height() and small.dock[0][0].top() > 0)

# ---- Bedienung
from PySide6.QtCore import QPointF, Qt  # noqa: E402
from PySide6.QtGui import QMouseEvent  # noqa: E402
from PySide6.QtTest import QTest  # noqa: E402
desk.show(); app.processEvents()
desk.items = list(ITEMS); desk._layout(); desk.sel = 0
QTest.mouseMove(desk, desk.rects[2].center().toPoint()); app.processEvents()
check("Maus über einer Kachel markiert sie", desk.sel == 2)
n = {"cat": None}
desk.set_cat = lambda c: n.__setitem__("cat", c)
QTest.mouseClick(desk, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier, desk.dock[4][0].center().toPoint())
check("Klick auf Seitenknopf wählt die Sorte", n["cat"] == desk.dock[4][1] == "folder", str(n))
del desk.set_cat
desk.items = list(ITEMS); desk._layout(); desk.sel = 0
QTest.keyClick(desk.edit, Qt.Key.Key_Right); app.processEvents()
check("Pfeiltaste springt zur nächsten Kachel", desk.sel == 1, str(desk.sel))
QTest.keyClick(desk.edit, Qt.Key.Key_Down); app.processEvents()
check("Pfeil nach unten bleibt gültig", 0 <= desk.sel < len(desk.items))

# ---- Hintergründe
desk.hide()
dev = 1.0
backend.api_set_config({"starter": {"desk_bg": "bild", "desk_bg_image": HOME + "/nicht-da.png"}})
desk.f.refresh(); desk.apply_options(); desk._background(desk.width(), desk.height(), dev)
check("fehlendes Bild: Hinweis und Ersatzhintergrund", "Hintergrundbild" in desk.bg_note and not desk._bgc.isNull())
from PySide6.QtGui import QColor, QImage  # noqa: E402
img = QImage(300, 200, QImage.Format.Format_RGB32); img.fill(QColor("#ff0000")); img.save(HOME + "/rot.png")
backend.api_set_config({"starter": {"desk_bg": "bild", "desk_bg_image": HOME + "/rot.png", "desk_bg_dim": 0}})
desk.f.refresh(); desk.apply_options(); pm = desk._background(desk.width(), desk.height(), dev).toImage()
c = pm.pixelColor(640, 380)
check("Hintergrundbild füllt das Fenster", not desk.bg_note and c.red() > 240 and c.green() < 15, c.name())
backend.api_set_config({"starter": {"desk_bg_dim": 50}})
desk.f.refresh(); desk.apply_options(); c = desk._background(desk.width(), desk.height(), dev).toImage().pixelColor(640, 380)
check("Abdunkeln wirkt", 100 < c.red() < 140, c.name())
backend.api_set_config({"starter": {"desk_bg": "farbe", "desk_bg_color": "#00ff00"}})
desk.f.refresh(); desk.apply_options(); c = desk._background(desk.width(), desk.height(), dev).toImage().pixelColor(640, 380)
check("einfarbiger Hintergrund", c.green() > 200 and c.red() < 30, c.name())
backend.api_set_config({"starter": {"desk_bg": "schema"}})
for sc in skins.DESK_SCHEMES:
    backend.api_set_config({"starter": {"desk_scheme": sc}})
    desk.f.refresh(); desk.apply_options(); desk.resize(1280, 760); desk.items = list(ITEMS); desk._layout(); desk.sel = 1
    g = desk.grab().toImage()
    check("Farbschema %s wird gezeichnet" % sc, g.width() == 1280 and g.height() == 760 and g.pixelColor(100, 24) != g.pixelColor(640, 600), "%dx%d" % (g.width(), g.height()))
    top = g.pixelColor(5, 5)
    check("Farbschema %s: Hintergrund dunkel" % sc, top.value() < 80 or sc == "metall", top.name())

# ---- Ruhezustand (Hintergrund hinter allen Fenstern)
backend.api_set_config({"starter": {"desk_resident": True}})
desk.f.refresh(); desk.apply_options()
desk.show(); desk.resting = False
desk.hide(); app.processEvents()
check("Schließen: mit Dauer-Schreibtisch bleibt das Fenster sichtbar im Ruhezustand", desk.isVisible() and desk.resting and bool(desk.windowFlags() & Qt.WindowType.WindowStaysOnBottomHint))
check("Ruhezustand: kein Wegklick-Schließen, Panel bleibt frei", not desk.autohide and desk.width() <= desk.screen().geometry().width())
desk.hide(); app.processEvents()
check("Schließen im Ruhezustand blendet ganz aus", not desk.isVisible())
backend.api_set_config({"starter": {"desk_resident": False}})
desk.f.refresh(); desk.apply_options(); desk.show(); desk.resting = False; desk.hide()
check("ohne Dauer-Schreibtisch verschwindet das Fenster", not desk.isVisible())
backend.api_set_config({"starter": {"desk_resident": True}})
desk.f.refresh(); desk.apply_options()

# ---- Favoriten (Programme) und Menü Einstellungen
APPS = [{"id": "firefox", "name": "Firefox Webbrowser", "generic": "Browser", "comment": "", "keywords": [], "icon": ""},
        {"id": "t", "name": "Terminal", "generic": "", "comment": "", "keywords": [], "icon": ""},
        {"id": "gimp", "name": "Bildbearbeitung", "generic": "", "comment": "", "keywords": [], "icon": ""}]
backend.api_apps_list = lambda: {"apps": APPS}
ok = SS.clean_starter({"app_favs": ["t", "t", " firefox ", "", "x" * 300, "a\nb"]})
check("Favoriten bereinigt: doppelte, leere, zu lange und Steuerzeichen entfallen", ok["app_favs"] == ["t", "firefox"], str(ok))
try:
    SS.clean_starter({"app_favs": "t"})
    check("Favoriten müssen eine Liste sein", False)
except B.AppError:
    check("Favoriten müssen eine Liste sein", True)
check("Vorgabe: keine Favoriten", B.STARTER_DEFAULTS["app_favs"] == [])
backend.api_set_config({"starter": {"app_favs": ["t", "gimp", "weg"]}})
finder.refresh()
fa = finder.favapps("")
check("Favoriten in gewählter Reihenfolge, unbekannte entfallen", [i.key for i in fa] == ["t", "gimp"] and all(i.extra.get("favapp") for i in fa), str([i.key for i in fa]))
check("Favoriten filtern mit Eingabe", [i.key for i in finder.favapps("bild")] == ["gimp"])
check("Suche markiert Favoriten", {i.key: bool(i.extra.get("favapp")) for i in finder.apps("e")}.get("t") is True)
check("ohne Eingabe stehen die Favoriten zuerst", [i.key for i in finder.idle()][:2] == ["t", "gimp"])
mg = ST.Finder.merge({"fav": finder.favapps(""), "app": finder.apps("")}, "favapp", 60)
check("Reiter Favoriten zeigt nur Favoriten", [i.key for i in mg] == ["t", "gimp"])
desk.show(); desk.resting = False; desk.resize(1280, 760); desk.apply_options()
desk.set_cat("favapp"); app.processEvents()
check("Reiter Favoriten im Fenster", desk.cat == "favapp" and [i.key for i in desk.items] == ["t", "gimp"], str([i.key for i in desk.items]))
desk.set_cat("all")
desk.items = list(ITEMS); desk._layout(); desk.sel = 0
desk.toggle_favorite()
check("Strg+D macht das markierte Programm zum Favorit und speichert", backend.cfg["starter"]["app_favs"] == ["t", "gimp", "weg", "firefox"], str(backend.cfg["starter"]["app_favs"]))
finder.refresh()
check("gespeichert in der Datei", "firefox" in finder.fav_ids())
desk.items = list(ITEMS); desk._layout(); desk.sel = 0
desk.toggle_favorite()
check("noch einmal entfernt es wieder", "firefox" not in backend.cfg["starter"]["app_favs"])
desk.items = list(ITEMS); desk._layout(); desk.sel = 1
desk.toggle_favorite()
check("bei Ordnern keine Favoritenfunktion", "Programmen" in desk.msg and "/h/u" not in backend.cfg["starter"]["app_favs"], desk.msg)


def pick(text):
    def run(menu, pos):
        def walk(m):
            for a in m.actions():
                if a.menu():
                    r = walk(a.menu())
                    if r:
                        return r
                elif a.text() == text:
                    return a
            return None
        return walk(menu)
    return run


desk.items = list(ITEMS); desk._layout(); desk.sel = 3
desk._exec_menu = pick("Zu den Favoriten hinzufügen")
QTest.mouseClick(desk, Qt.MouseButton.RightButton, Qt.KeyboardModifier.NoModifier, desk.rects[0].center().toPoint())
check("Rechtsklick auf Programm: zu den Favoriten hinzufügen", "firefox" in backend.cfg["starter"]["app_favs"] and desk.sel == 0, str(backend.cfg["starter"]["app_favs"]))
desk.items = list(ITEMS); desk._layout()
seen = {}
desk._exec_menu = lambda m, pos: seen.setdefault("n", len(m.actions())) and None
QTest.mouseClick(desk, Qt.MouseButton.RightButton, Qt.KeyboardModifier.NoModifier, desk.rects[1].center().toPoint())
check("Rechtsklick auf Ordner: nur Öffnen", seen.get("n") == 1, str(seen))
srect = next(rc for rc, act in desk.bar_btns if act == "settings")
before = int(desk.f.opts()["desk_btn"])
desk._exec_menu = pick("Größer")
QTest.mouseClick(desk, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier, srect.center().toPoint())
check("Menü Einstellungen: Knöpfe größer", backend.cfg["starter"]["desk_btn"] == before + 8 and desk.btn == before + 8, str((backend.cfg["starter"].get("desk_btn"), desk.btn)))
desk._exec_menu = pick("Neon")
desk.settings_menu(srect)
check("Menü Einstellungen: Farbschema Neon", backend.cfg["starter"]["desk_scheme"] == "neon" and desk.pal["scheme"] == "neon")
desk._exec_menu = pick("Auf die andere Seite")
desk.settings_menu(srect)
check("Menü Einstellungen: Knöpfe rechts", backend.cfg["starter"]["desk_side"] == "right" and desk.side == "right")
desk._exec_menu = pick("Dauer-Schreibtisch (liegt hinter allen Fenstern)")
desk.settings_menu(srect)
check("Menü Einstellungen: Dauer-Schreibtisch aus", backend.cfg["starter"]["desk_resident"] is False)
opened = []
SX.send_settings = lambda what="starter": opened.append(what) or True
desk._exec_menu = pick("Alle Einstellungen …")
desk.settings_menu(srect)
check("Menü Einstellungen: Dialog von Seifferts Dateien", opened == ["starter"], str(opened))
desk.show()
backend.api_set_config({"starter": {"desk_resident": True, "desk_scheme": "dunkel", "desk_side": "left", "desk_btn": 64, "app_favs": []}})
desk.f.refresh(); desk.apply_options(); desk.resize(1280, 760)
del desk._exec_menu

# ---- Panel mit Favoriten
backend.api_set_config({"starter": {"app_favs": ["t", "gimp", "firefox"], "desk_favs": True, "desk_side": "left"}})
desk.f.refresh(); desk.apply_options(); desk.resize(1280, 760); desk._geom()
desk.items = list(ITEMS); desk._layout()
check("Panel: drei Favoriten, quadratisch", len(desk.favs) == 3 and all(abs(r.width() - r.height()) < 0.01 for r, _ in desk.favs))
check("Panel liegt gegenüber den Sortenknöpfen (Knöpfe links, Panel rechts)", desk.favbox.left() > desk.dockbox.right() and desk.favbox.right() <= desk.width())
check("Kacheln liegen zwischen Knöpfen und Panel", all(r.left() > desk.dockbox.right() and r.right() < desk.favbox.left() for r in desk.rects))
check("Knopf und Panel gleich groß", abs(desk.favs[0][0].width() - desk.dock[0][0].width()) < 0.01)
backend.api_set_config({"starter": {"desk_side": "right"}})
desk.f.refresh(); desk.apply_options(); desk._geom(); desk._layout()
check("Knöpfe rechts: Panel links, Kacheln dazwischen", desk.favbox.right() < desk.dockbox.left() and all(r.left() > desk.favbox.right() and r.right() < desk.dockbox.left() for r in desk.rects))
backend.api_set_config({"starter": {"desk_side": "left"}})
desk.f.refresh(); desk.apply_options(); desk._geom(); desk._layout()
launched = []
backend.call = lambda name, args=None: launched.append((name, args))
desk.hide = lambda: launched.append("hide")
QTest.mouseClick(desk, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier, desk.favs[1][0].center().toPoint())
check("Klick auf Favorit startet das Programm und schließt", launched[:1] == [("launch_app", {"app_id": "gimp"})] and "hide" in launched, str(launched))
del desk.hide
desk._exec_menu = pick("Aus den Favoriten entfernen")
QTest.mouseClick(desk, Qt.MouseButton.RightButton, Qt.KeyboardModifier.NoModifier, desk.favs[0][0].center().toPoint())
check("Rechtsklick im Panel: Favorit entfernen", backend.cfg["starter"]["app_favs"] == ["gimp", "firefox"] and len(desk.favs) == 2, str(backend.cfg["starter"]["app_favs"]))
mv = {}
QTest.mouseMove(desk, desk.favs[0][0].center().toPoint())
check("Name erscheint beim Darüberfahren", desk.hot == "fav:0", desk.hot)
desk._exec_menu = pick("Panel mit Favoriten")
desk.settings_menu(next(rc for rc, act in desk.bar_btns if act == "settings"))
check("Menü: Panel abschalten", backend.cfg["starter"]["desk_favs"] is False and desk.favbox.isNull() and not desk.favs)
desk._layout()
check("ohne Panel nutzen die Kacheln wieder die ganze Breite", abs(desk._grid_area().right() - (desk.width() - 16)) < 0.01)
img = None
backend.api_set_config({"starter": {"app_favs": [], "desk_favs": True}})
desk.f.refresh(); desk.apply_options(); desk._geom()
check("ohne Favoriten bleibt ein leeres Panel mit Stern", not desk.favbox.isNull() and desk.favs == [])
del desk._exec_menu
backend.call = B.Backend.call.__get__(backend)

# ---- Oberfläche: Ansicht Schreibtisch
import surfacecfg as SCFG  # noqa: E402
check("Oberfläche: Vorgabe ist die Ansicht Schreibtisch", SCFG.SURFACE_DEFAULTS["view"] == "desk")
check("Oberfläche: Ansicht klassisch erlaubt", SCFG.clean({"view": "classic"})["view"] == "classic")
try:
    SCFG.clean({"view": "quatsch"})
    check("Oberfläche: ungültige Ansicht abgelehnt", False)
except ValueError:
    check("Oberfläche: ungültige Ansicht abgelehnt", True)
check("Oberfläche: Index.html bietet beide Ansichten an", 'view: ["Ansicht der Oberfläche"' in html and '["desk", "Schreibtisch' in html and '["classic", "Klassisch' in html)
backend.api_set_config({"starter": {"desk_resident": False, "design": "wolke"}})
desk.f.refresh(); desk.apply_options()
check("ohne Fläche und ohne Dauer-Schreibtisch kein Ruhezustand", not desk._resident())
desk.surface = True
check("als Fläche der Oberfläche immer Ruhezustand, egal was eingestellt ist", desk._resident())
desk.show(); desk.resting = False
desk.hide(); app.processEvents()
check("Schließen als Fläche: bleibt sichtbar im Ruhezustand", desk.isVisible() and desk.resting)
desk.surface = False
desk._real_hide()
backend.api_set_config({"starter": {"desk_resident": True, "design": "desk"}})
desk.f.refresh(); desk.apply_options()

# ---- Tippen darf nicht hakeln: wenige Neuzeichnungen, keine Animation
from PySide6.QtTest import QTest as QT2  # noqa: E402
backend.api_set_config({"starter": {"src_files": False, "src_folders": False}})
desk.f.refresh(); desk.apply_options(); desk.resize(1280, 760); desk.show(); desk.edit.clear(); desk._run(); app.processEvents()
paints = {"n": 0}
_orig_pe = desk.paintEvent
desk.paintEvent = lambda ev: (paints.__setitem__("n", paints["n"] + 1), _orig_pe(ev))
QT2.qWait(200)
paints["n"] = 0
for ch in "firefox":
    QT2.keyClick(desk.edit, ch)
    QT2.qWait(100)
QT2.qWait(300)
check("Tippen von 7 Zeichen: höchstens 4 Neuzeichnungen je Zeichen", paints["n"] <= 28, str(paints["n"]))
check("keine Aufpoppen-Animation im Schreibtisch", desk.anim.__class__.__name__ == "_NoAnim")
before = desk.grab().toImage()
desk.update(); app.processEvents()
check("Neuzeichnen nur betroffener Bereiche lässt nichts fehlen (Suchfeld neu zeichnen)", desk.grab().toImage() == before)
del desk.paintEvent
desk.edit.clear(); desk._run()
backend.api_set_config({"starter": {"src_files": True, "src_folders": True}})
desk.f.refresh(); desk.apply_options()

# ---- Umschalten und Speichern
sw = {"to": None}
desk.on_switch = lambda to: sw.__setitem__("to", to)
desk.show(); desk.switch_design("wolke"); app.processEvents()
cfg = json.load(open(os.path.join(HOME, ".config", "seiffert-dateien", "config.json"), encoding="utf-8"))
check("Umschalten speichert das Design und meldet es", cfg["starter"]["design"] == "wolke" and sw["to"] == "wolke" and not desk.isVisible(), str(cfg["starter"].get("design")))
cl = Cloud(finder, backend)
cl.on_switch = lambda to: sw.__setitem__("to", to)
cl.switch_design(); cfg = json.load(open(os.path.join(HOME, ".config", "seiffert-dateien", "config.json"), encoding="utf-8"))
check("Wolke schaltet zum Schreibtisch", cfg["starter"]["design"] == "desk" and sw["to"] == "desk")
check("F2 ist in beiden Designs belegt", "Key_F2" in open(os.path.join(HERE, "starter.py"), encoding="utf-8").read() and "Key_F2" in open(os.path.join(HERE, "starterdesk.py"), encoding="utf-8").read())
cl.f.refresh()
it = I("command", "Schreibtisch-Farbschema: Metall", "x", extra={"builtin": "deskscheme:metall"})
cl.items = [it]; cl.sel = 0
check("Befehl stellt das Farbschema um und lässt den Starter offen", cl.run_command(it, False) is False and backend.cfg["starter"]["desk_scheme"] == "metall")

print("%d Prüfungen bestanden, %d fehlgeschlagen" % (PASS, FAIL))
backend.shutdown() if hasattr(backend, "shutdown") else None
shutil.rmtree(HOME, ignore_errors=True)
os._exit(1 if FAIL else 0)
