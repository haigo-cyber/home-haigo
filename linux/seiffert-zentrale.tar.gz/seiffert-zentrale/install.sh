#!/usr/bin/env bash
# Seifferts Zentrale: Installation ohne sudo nach ~/.local
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
APP=seiffert-zentrale
DATA="${XDG_DATA_HOME:-$HOME/.local/share}/$APP"
BIN="$HOME/.local/bin"
APPS="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
ICONS="${XDG_DATA_HOME:-$HOME/.local/share}/icons/hicolor"
CONF="${XDG_CONFIG_HOME:-$HOME/.config}"

command -v python3 >/dev/null || { echo "python3 fehlt (Arch: sudo pacman -S python)"; exit 1; }
mkdir -p "$DATA" "$BIN" "$APPS"

echo "== Python-Umgebung"
if [ ! -x "$DATA/venv/bin/python" ]; then
  if [ "${SZ_NO_PIP:-}" = "1" ]; then python3 -m venv --system-site-packages "$DATA/venv"; else python3 -m venv "$DATA/venv" || { echo "python3 -m venv fehlgeschlagen (Debian und Ubuntu: sudo apt install python3-venv)"; exit 1; }; fi
fi
if [ "${SZ_NO_PIP:-}" != "1" ]; then
  "$DATA/venv/bin/pip" install --upgrade pip -q
  "$DATA/venv/bin/pip" install -q -r "$HERE/requirements.txt"
fi
"$DATA/venv/bin/python" -c "import PySide6.QtWidgets; print('PySide6 in Ordnung')"
"$DATA/venv/bin/python" -c "import Xlib; print('python-xlib in Ordnung (Einbetten unter X11 möglich)')" 2>/dev/null || echo "Hinweis: python-xlib fehlt, die Programme laufen dann in eigenen Fenstern."

echo "== Programmdateien"
chmod -R u+w "$DATA/app" 2>/dev/null || true
rm -rf "$DATA/app"
mkdir -p "$DATA/app"
cp -r "$HERE/seiffert_zentrale" "$DATA/app/"
chmod -R u+w "$DATA/app"
find "$DATA/app" -name __pycache__ -type d -prune -exec rm -rf {} + 2>/dev/null || true
cp "$HERE/uninstall.sh" "$HERE/INSTALLATION.txt" "$DATA/" 2>/dev/null || true

cat > "$BIN/seiffert-zentrale" <<LAUNCH
#!/usr/bin/env bash
export PYTHONPATH="$DATA/app\${PYTHONPATH:+:\$PYTHONPATH}"
exec "$DATA/venv/bin/python" -m seiffert_zentrale "\$@"
LAUNCH
chmod +x "$BIN/seiffert-zentrale"

echo "== Menüeintrag, Symbol und Starter-Befehl"
for n in 16 22 24 32 48 64 128 256; do
  mkdir -p "$ICONS/${n}x${n}/apps"
  cp "$HERE/seiffert_zentrale/icons/icon-$n.png" "$ICONS/${n}x${n}/apps/seiffert-zentrale.png"
done
cat > "$APPS/seiffert-zentrale.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=Seifferts Zentrale
GenericName=Alle Seiffert-Programme
Comment=Alle Seiffert-Programme in einem Fenster
Exec=$BIN/seiffert-zentrale
Icon=seiffert-zentrale
Terminal=false
Categories=Office;Utility;
StartupWMClass=seiffert-zentrale
DESK
# Eintrag für den Seiffert-Starter (Reiter Befehle), falls Seifferts Dateien eingerichtet ist
if [ -d "$CONF/seiffert-dateien" ]; then
  mkdir -p "$CONF/seiffert-dateien/befehle.d"
  cat > "$CONF/seiffert-dateien/befehle.d/zentrale.json" <<JSON
[{"name": "Seifferts Zentrale", "line": "$BIN/seiffert-zentrale", "desc": "Alle Seiffert-Programme in einem Fenster", "words": ["zentrale", "programme", "alle"], "terminal": false, "confirm": false}]
JSON
fi
command -v update-desktop-database >/dev/null && update-desktop-database "$APPS" 2>/dev/null || true
command -v gtk-update-icon-cache >/dev/null && gtk-update-icon-cache -q -t "$ICONS" 2>/dev/null || true

echo
echo "Fertig. Start: Menü Seifferts Zentrale, oder im Terminal: seiffert-zentrale [text|todo|zeit|dateien|terminal|update]"
case ":$PATH:" in *":$BIN:"*) ;; *) echo "Hinweis: $BIN steht nicht im PATH (der Menüeintrag funktioniert trotzdem).";; esac
