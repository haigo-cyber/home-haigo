/* Seifferts Depot, Linux-App: Anpassungen nach dem Skript des Tools.
   Die Linux-App ist führend (bei Unterschieden gilt der Stand auf dem Laptop), dazu der Bereich Laptop-Sicherung im Reiter Daten.
   Alle Änderungen ersetzen nur einzelne Funktionen des Tools, der Code des Tools bleibt unverändert. */
(function () {
  'use strict';
  if (!window.__LX) return;
  var LX = window.__LX, info = null, backups = null, lastErr = '';

  function wrap(name, fn) {
    var o = window[name];
    if (typeof o !== 'function') return;
    window[name] = function () { return fn.call(this, o, arguments); };
  }
  function enc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]; }); }
  function say(m, ms) { if (typeof window.toast === 'function') window.toast(m, ms); }
  function replaceOnce(s, a, b) { return s.indexOf(a) >= 0 ? s.replace(a, b) : s; }

  /* ---- Anmeldung: nur auf Klick ---- */
  wrap('requestToken', function (o, a) {
    var self = this, args = a;
    if (!args[0]) { window.__lxInteractive = false; return o.apply(self, args); }
    return LX.ensureAddress().then(function (url) {
      if (!url) throw new Error('Anmeldung abgebrochen');
      window.__lxInteractive = true;
      try { return o.apply(self, args); } finally { window.__lxInteractive = false; }
    });
  });

  /* ---- Linux-App führend: bei einem Konflikt gewinnt der Laptop, der alte Drive-Stand wird vorher als Kopie gesichert ---- */
  window.resolveConflict = function (rs, remote) {
    LX.conflict = true;
    LX.post('log', {msg: 'Konflikt zwischen Drive und Laptop: Stand der Linux-App gilt (Drive zuletzt geändert ' + (remote && remote.modifiedTime) + ')'}).catch(function () {});
    return Promise.resolve('local');
  };
  wrap('toast', function (o, a) {
    if (LX.conflict && a[0] === 'Lokaler Stand nach Drive hochgeladen') {
      LX.conflict = false;
      return o.call(this, 'Unterschiedliche Stände: Die Linux-App gilt. Der bisherige Drive-Stand liegt als Sicherungskopie in Drive.', 9000);
    }
    return o.apply(this, a);
  });

  /* ---- Downloads: Blob-Adresse bleibt lange gültig, die App fragt dann nach dem Speicherort ---- */
  window.download = function (name, text, mime) {
    var blob = new Blob([text], {type: mime || 'text/plain'});
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(url); a.remove(); }, 120000);
  };

  /* ---- Texte, die für die Linux-App nicht stimmen ---- */
  wrap('hero', function (o, a) {
    return replaceOnce(o.apply(this, a), 'Alle Daten bleiben in diesem Browser auf diesem Gerät. Es gibt keine Verbindung ins Internet.',
      'Die Daten liegen in der Linux-App auf diesem Laptop (Hauptdatei und Sicherungskopien). Google Drive ist die zweite Sicherung, wenn du es im Reiter Daten verbindest.');
  });
  wrap('viewOverview', function (o, a) {
    return o.apply(this, a).replace(/<div class="note">Letzte Sicherung:[\s\S]*?<\/div>/, '');
  });
  wrap('driveCardInner', function (o, a) {
    var adr = info && info.handoffUrl;
    return o.apply(this, a) + '<p class="hint">Linux-App: Bei Unterschieden zwischen Laptop und Drive gilt der Stand auf dem Laptop, der bisherige Drive-Stand bleibt als Sicherungskopie in Drive. ' +
      'Die Anmeldung läuft über deinen Browser und gilt etwa eine Stunde. Ohne Anmeldung bleiben Änderungen auf dem Laptop gesichert und gehen später nach Drive.</p>' +
      '<p class="hint" style="margin-top:0">Adresse der veröffentlichten Fassung für die Anmeldung: ' + (adr ? '<code>' + enc(adr) + '</code>' : 'noch nicht eingetragen') + '</p>' +
      (adr && info && info.handoffOk === false ? '<p class="msg" role="alert">Diese Adresse ist nicht brauchbar (zum Beispiel eine Drive-Adresse). Bitte unten ändern: gebraucht wird die Adresse deiner veröffentlichten depot.html.</p>' : '') +
      '<div class="btns"><button class="btn small" type="button" data-lx="addr">Anmelde-Adresse ändern</button>' +
      '<a class="btn small" href="https://drive.google.com/drive/home" target="_blank" rel="noopener">Google Drive im Browser öffnen</a></div>';
  });

  /* ---- Bereich Laptop-Sicherung im Reiter Daten ---- */
  function fmt(iso) { return typeof window.fdt === 'function' ? window.fdt(iso) : iso; }
  function inner() {
    var i = info, h = '<h2>Laptop-Sicherung (Linux-App)</h2>' +
      '<p class="hint">Diese Linux-App ist führend: Bei Unterschieden zwischen diesem Laptop und Google Drive gilt der Stand hier. ' +
      'Die Hauptdatei wird bei jeder Änderung gespeichert, dazu entsteht täglich eine Sicherungskopie (die letzten 30 bleiben erhalten).</p>';
    if (!i) return h + '<p class="hint">Angaben werden geladen …</p>';
    h += '<p class="hint" style="margin-top:0">Ordner: <code>' + enc(i.datenordner) + '</code><br>Hauptdatei: <code>depot-daten.json</code>, zuletzt gespeichert ' +
      (i.zuletzt ? enc(fmt(i.zuletzt)) : 'noch nicht') + '<br>Sicherungskopien: ' + i.anzahl + (i.neueste ? ', neueste <code>' + enc(i.neueste) + '</code>' : '') + '</p>';
    if (i.fehler) h += '<p class="msg" role="alert">' + enc(i.fehler) + '</p>';
    h += '<div class="btns"><button class="primary" data-lx="backup">Jetzt sichern</button><button class="btn" data-lx="list">Sicherungen anzeigen</button><button class="btn" data-lx="open">Ordner öffnen</button></div>';
    if (backups) {
      h += '<h3>Sicherungen auf dem Laptop (' + backups.length + ')</h3>';
      h += backups.length ? '<div class="histlist">' + backups.map(function (f) {
        return '<div><span>' + enc(f.name.replace(/^depot-sicherung-/, '').replace(/\.json$/, '')) + '</span><button class="btn small" data-lx="restore" data-name="' + enc(f.name) + '">Einlesen</button></div>';
      }).join('') + '</div>' : '<p class="hint">Noch keine Sicherungskopien. Die erste entsteht bei der ersten Änderung nach dem ersten Speichern.</p>';
    }
    return h;
  }
  function paint() { var el = document.getElementById('lxcard'); if (el) el.innerHTML = inner(); }
  function refresh() {
    return LX.get('info').then(function (j) { info = j; paint(); }).catch(function () {});
  }
  wrap('viewDaten', function (o, a) {
    var s = o.apply(this, a), card = '<div class="card" id="lxcard">' + inner() + '</div>';
    s = replaceOnce(s, 'Deine Daten liegen nur im Speicher dieses Browsers auf diesem Gerät. Am Handy und am Rechner sind das zwei getrennte Bestände. Eine Sicherungsdatei überträgt alles von einem Gerät auf das andere.',
      'Zusätzlich zur automatischen Laptop-Sicherung kannst du hier eine Sicherungsdatei an einem Ort deiner Wahl speichern oder eine Datei einlesen, zum Beispiel vom Handy.');
    var key = '<div class="card"><h2>Google Drive</h2>';
    s = s.indexOf(key) >= 0 ? s.replace(key, card + key) : card + s;
    setTimeout(refresh, 0);
    return s;
  });

  function restore(name) {
    LX.get('backup/read?name=' + encodeURIComponent(name)).then(function (j) {
      if (j.error) { say(j.error, 6000); return; }
      var rs;
      try { rs = window.parsePayload(j.text); } catch (e) { say('Die Sicherungsdatei konnte nicht gelesen werden.', 5000); return; }
      return window.modal({title: 'Laptop-Sicherung einlesen?', danger: true, ok: 'Einlesen',
        text: name + '\n' + window.sumState(rs) + '\n\nDer aktuelle Stand (' + window.sumState(wsObj()) + ') wird ersetzt. Vorher wird er als Sicherungskopie auf dem Laptop abgelegt.'
      }).then(function (ok) {
        if (!ok) return;
        return LX.post('backup/new', {tag: 'vor-wiederherstellung'}).then(function () {
          window.replaceState(rs); window.render();
          say('Sicherung eingelesen', 4500);
          refresh();
        });
      });
    }).catch(function (e) { say('Einlesen nicht möglich: ' + (e && e.message), 6000); });
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-lx]');
    if (!b) return;
    var act = b.dataset.lx;
    if (act === 'backup') {
      LX.post('backup/new', {tag: 'manuell'}).then(function (j) {
        say(j.error ? j.error : 'Laptop-Sicherung angelegt: ' + j.name, 5000);
        return LX.get('backup/list').then(function (l) { if (backups) backups = l.liste; return refresh(); });
      });
    } else if (act === 'list') {
      LX.get('backup/list').then(function (j) { backups = j.liste; paint(); });
    } else if (act === 'open') {
      LX.post('openfolder');
    } else if (act === 'restore') {
      restore(b.dataset.name);
    } else if (act === 'kurse') {
      updateKurse(false).catch(function (e) { kBusy = false; kmsg('Abruf fehlgeschlagen: ' + (e && e.message)); });
    } else if (act === 'addr') {
      LX.changeAddress().then(function (url) {
        if (!url) return;
        if (info) info.handoffUrl = url;
        var el = document.getElementById('drivecard');
        if (el && typeof window.driveCardInner === 'function') el.innerHTML = window.driveCardInner();
      }).catch(function () {});
    }
  });


  /* ---- Kurse aus dem Internet (Yahoo Finance, ersatzweise ING; Abruf läuft über die Linux-App) ---- */
  var kBusy = false, kAuto = true, kLast = '';
  function kmsg(t) { var el = document.getElementById('lxkmsg'); if (el) el.textContent = t || ''; var b = document.getElementById('lxkbtn'); if (b) b.disabled = kBusy; }
  function kursCard() {
    return '<div class="card" id="lxkurse"><h2>Kurse aus dem Internet</h2>' +
      '<p class="hint" style="margin-top:0">Holt Tageskurse (Schluss, dazu Eröffnung, Hoch und Tief) für alle offenen Positionen. Zuerst wird Yahoo Finance gefragt; dafür steht im Feld Kürzel ein Yahoo-Kürzel, ' +
      'zum Beispiel <code>SXRV.DE</code> für den iShares Nasdaq 100 an der Börse Xetra. Klappt das nicht, fragt die App die Kursseiten der ING über die ISIN. ' +
      'Die ISIN liest die App aus dem Chart-Link der Position (zum Beispiel ein Link zu justETF) oder aus dem Feld Kürzel, falls dort eine ISIN steht. ' +
      'Kürzel und Link trägst du unter Käufe bei der Position ein (Bearbeiten). Übernommen werden nur Kurse in Euro. Neue Positionen werden ab dem ersten Kauf aufgefüllt, danach ab dem letzten vorhandenen Kurs. Ältere Kurse bleiben unverändert.</p>' +
      '<p class="hint" style="margin-top:0">Beide Quellen sind kostenlos und inoffiziell, ohne Zusage. Die Kurse (Xetra, ersatzweise Tradegate) können von den Preisen bei Smartbroker oder ING leicht abweichen. ' +
      'Der Kurs des laufenden Handelstages kann sich noch ändern und wird beim nächsten Abruf aktualisiert.</p>' +
      '<label class="chk"><input type="checkbox" id="lxkauto" data-lxk="auto"' + (kAuto ? ' checked' : '') + '><span>Beim Start der App automatisch aktualisieren (ohne Rückfrage)</span></label>' +
      '<div class="btns"><button class="primary" type="button" id="lxkbtn" data-lx="kurse">Kurse jetzt aktualisieren</button></div>' +
      '<p class="msg" id="lxkmsg" role="status"></p>' +
      (kLast ? '<details style="margin-top:8px"><summary>Letzter Abruf</summary><p class="hint" style="white-space:pre-wrap;margin-top:4px" id="lxklast">' + esc(kLast) + '</p></details>' : '') + '</div>';
  }
  document.addEventListener('change', function (ev) {
    var t = ev.target;
    if (!t || !t.dataset || t.dataset.lxk !== 'auto') return;
    kAuto = !!t.checked;
    LX.post('config', {kurseAuto: kAuto}).catch(function () {});
  });
  wrap('viewKurse', function (o, a) {
    var s = o.apply(this, a);
    return state.positions.length ? kursCard() + s : s;
  });
  function maxDate(arr) { return (arr || []).reduce(function (m, e) { return e.date > m ? e.date : m; }, ''); }
  function firstBuy(pid) { return txsOf(pid).map(function (t) { return t.date; }).sort()[0] || ''; }
  function nm(p) { return p.name + (p.sym ? ' (' + p.sym + ')' : ''); }
  var ISIN = /(?:^|[^A-Z0-9])([A-Z]{2}[A-Z0-9]{9}[0-9])(?![A-Z0-9])/;
  function isinOf(p) {
    var s = String(p.sym || '').trim().toUpperCase();
    if (/^[A-Z]{2}[A-Z0-9]{9}[0-9]$/.test(s)) return s;
    var m = ISIN.exec(String(p.url || '').toUpperCase());
    return m ? m[1] : '';
  }
  function stamp() { var d = new Date(), z = function (n) { return (n < 10 ? '0' : '') + n; }; return z(d.getDate()) + '.' + z(d.getMonth() + 1) + '.' + d.getFullYear() + ', ' + z(d.getHours()) + ':' + z(d.getMinutes()) + ' Uhr'; }

  async function updateKurse(auto) {
    if (kBusy) return;
    var open = computeRows().rows.filter(function (r) { return r.open; });
    var has = function (r) { return (r.pos.sym && String(r.pos.sym).trim()) || isinOf(r.pos); };
    var withSym = open.filter(has), noSym = open.filter(function (r) { return !has(r); });
    if (!withSym.length) {
      if (auto) return;
      await window.modal({title: 'Kein Kürzel eingetragen', ok: 'OK', cancel: '',
        text: 'Bei keiner offenen Position steht ein Yahoo-Kürzel oder eine ISIN. Trage unter Käufe bei der Position (Bearbeiten) im Feld Kürzel oder WKN zum Beispiel SXRV.DE ein, oder hinterlege einen Chart-Link, der die ISIN enthält.'});
      return;
    }
    var items = withSym.map(function (r) {
      var id = r.pos.id;
      return {id: id, sym: String(r.pos.sym || '').trim(), isin: isinOf(r.pos), from: maxDate(state.prices[id]) || firstBuy(id)};
    });
    kBusy = true; kmsg('Kurse werden abgerufen … (' + items.length + ' Position' + (items.length > 1 ? 'en' : '') + ')');
    var resp;
    try { resp = await LX.post('kurse', {items: items}); }
    catch (e) { kBusy = false; kmsg('Die Linux-App antwortet nicht: ' + (e && e.message)); return; }
    kBusy = false; kmsg('');
    if (!resp || resp.error) {
      kLast = stamp() + '\nAbruf nicht möglich: ' + ((resp && resp.error) || 'Keine Antwort');
      if (auto) say('Kurse: Abruf nicht möglich. Einzelheiten im Reiter Kurse unter Letzter Abruf.', 8000);
      else await window.modal({title: 'Abruf nicht möglich', text: (resp && resp.error) || 'Keine Antwort', ok: 'OK', cancel: ''});
      return;
    }

    var plan = [], probs = [], nNew = 0, nChg = 0, nOhl = 0, nSame = 0, lines = [], quellen = {}, nFail = 0;
    resp.results.forEach(function (res) {
      var pos = posById(res.id), it = items.filter(function (x) { return x.id === res.id; })[0];
      if (!pos) return;
      if (res.error) { nFail++; probs.push(nm(pos) + ': ' + res.error); return; }
      if (res.currency !== 'EUR') { nFail++; probs.push(nm(pos) + ': ' + (res.quelle || 'Die Quelle') + ' liefert Kurse in ' + (res.currency || 'unbekannter Währung') + ', nicht übernommen (nur Euro). Ein Euro-Handelsplatz wie Xetra mit der Endung .DE ist passend.'); return; }
      quellen[res.quelle || 'Yahoo Finance'] = 1;
      if (res.hinweis) probs.push(nm(pos) + ': Kurse kommen von ' + res.quelle + ', weil der erste Versuch scheiterte (' + res.hinweis + ')');
      var pn = 0, pc = 0, last = null;
      (res.rows || []).forEach(function (z) {
        if (it && it.from && z.date < it.from) return;
        var ex = (state.prices[pos.id] || []).find(function (e) { return e.date === z.date; }), k;
        if (!ex) { k = 'new'; nNew++; pn++; }
        else if (Math.abs(ex.price - z.c) < 1e-9) {
          if (z.o && !(ex.o === z.o && ex.h === z.h && ex.l === z.l)) { k = 'ohl'; nOhl++; } else { k = 'same'; nSame++; }
        } else { k = 'chg'; nChg++; pc++; }
        if (k !== 'same') plan.push({pos: pos, z: z, k: k});
        last = z;
      });
      lines.push(nm(pos) + ': ' + pn + ' neu' + (pc ? ', ' + pc + ' ersetzt' : '') + (last ? ', letzter Kurs ' + price(last.c) + ' vom ' + fd(last.date) : ', keine Kurse im Zeitraum') + ' [' + (res.quelle || 'Yahoo Finance') + ']');
    });
    noSym.forEach(function (r) { probs.push(r.pos.name + ': weder Kürzel noch ISIN hinterlegt, übersprungen'); });
    var tail = probs.length ? '\n\nHinweise:\n' + probs.join('\n') : '', qtxt = Object.keys(quellen).join(', ') || 'keine';
    kLast = stamp() + (auto ? ' (automatisch beim Start)' : '') + '\nQuelle: ' + qtxt + '\nNeu: ' + nNew + ', ersetzt: ' + nChg + (lines.length ? '\n\n' + lines.join('\n') : '') + tail;
    if (!plan.length) {
      if (auto) { if (nFail) say('Kurse: Abruf für ' + nFail + ' Position' + (nFail > 1 ? 'en' : '') + ' nicht möglich. Einzelheiten im Reiter Kurse unter Letzter Abruf.', 8000); if (ui.tab === 'kurse') render(); return; }
      await window.modal({title: 'Nichts zu aktualisieren', ok: 'OK', cancel: '',
        text: (nSame ? 'Alle abgerufenen Kurse sind schon vorhanden.' : 'Es wurde kein passender Kurs gefunden.') + (lines.length ? '\n\n' + lines.join('\n') : '') + tail});
      if (ui.tab === 'kurse') render();
      return;
    }
    if (!auto) {
      var ok = await window.modal({title: 'Kurse übernehmen?', ok: 'Übernehmen',
        text: 'Quelle: ' + qtxt + '\nNeu: ' + nNew + '\nErsetzt (anderer Kurs am selben Tag): ' + nChg + (nOhl ? '\nNur um Kerzenwerte ergänzt: ' + nOhl : '') + '\n\n' + lines.join('\n') + tail});
      if (!ok) return;
    }
    plan.forEach(function (p) {
      var arr = (state.prices[p.pos.id] = state.prices[p.pos.id] || []);
      var e = arr.find(function (x) { return x.date === p.z.date; });
      if (e) e.price = p.z.c; else { e = {date: p.z.date, price: p.z.c}; arr.push(e); }
      if (p.z.o) { e.o = p.z.o; e.h = p.z.h; e.l = p.z.l; } else if (p.k === 'chg') { delete e.o; delete e.h; delete e.l; }
      arr.sort(function (a, b) { return a.date < b.date ? -1 : 1; });
    });
    saveState();
    /* beim automatischen Abruf keine laufende Eingabe stören: nur neu zeichnen, wenn gerade nichts bearbeitet wird */
    var ae = document.activeElement, tippt = auto && ae && /^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName) || (auto && document.querySelector('#modal-root form'));
    if (!tippt) render();
    say((auto ? 'Kurse automatisch aktualisiert: ' : '') + (nNew + nChg) + ' Kurse übernommen (' + nNew + ' neu, ' + nChg + ' ersetzt)' + (nOhl ? ', ' + nOhl + ' um Kerzenwerte ergänzt' : '') + (auto && nFail ? '. Bei ' + nFail + ' Position' + (nFail > 1 ? 'en' : '') + ' nicht möglich, siehe Reiter Kurse.' : ''), 6000);
  }
  /* einmal je Programmstart, kurz nach dem Laden */
  var autoDone = false;
  function autoKurse() {
    if (autoDone) return; autoDone = true;
    LX.get('info').then(function (j) {
      kAuto = j.kurseAuto !== false;
      var c = document.getElementById('lxkauto'); if (c) c.checked = kAuto;
      if (kAuto && !window.__lxNoAuto) return updateKurse(true);
    }).catch(function () { kBusy = false; });
  }
  setTimeout(autoKurse, 2500);

  /* ---- Fehlermeldungen der Linux-App sichtbar machen ---- */
  function poll() {
    LX.get('info').then(function (j) {
      info = j;
      var err = j.fehler || LX.fail || '';
      if (err && err !== lastErr) say('Achtung: ' + err, 12000);
      lastErr = err;
      paint();
    }).catch(function () {
      if (lastErr !== 'weg') say('Achtung: Die Verbindung zur Linux-App ist unterbrochen. Änderungen werden nicht mehr auf dem Laptop gesichert.', 12000);
      lastErr = 'weg';
    });
  }
  setInterval(poll, 15000);
})();
