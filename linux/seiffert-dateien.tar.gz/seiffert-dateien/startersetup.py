"""Verwaltung des Seifferts Starters aus Seifferts Dateien heraus: Tastenkürzel (Cinnamon), Autostart, Dienst starten und
beenden, Nutzungsdaten zurücksetzen. Die Einstellungen selbst (Quellen, Blasenzahl, ...) liegen in der Konfiguration
unter "starter" und werden vom Starter bei jedem Erscheinen neu gelesen. Wird als Mischklasse in Backend eingebunden."""
from __future__ import annotations

import ast
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
from pathlib import Path

import backend as B
import skins

AppError = B.AppError
HK_SCHEMA = "org.cinnamon.desktop.keybindings"
HK_ID = "seiffert-starter"
HK_PATH = "/org/cinnamon/desktop/keybindings/custom-keybindings/%s/" % HK_ID
MATE_SCHEMA = "org.mate.control-center.keybinding"          # MATE: jedes eigene Kürzel liegt in /org/mate/desktop/keybindings/customN/
MATE_DIR = "/org/mate/desktop/keybindings/custom%d/"
HK_NAME = "Seifferts Starter"
HK_RE = re.compile(r"^(<(Super|Control|Alt|Shift)>){0,4}[A-Za-z0-9_]{1,24}$")
SOCKET_NAME = "seiffert-starter-%s" % (os.getuid() if hasattr(os, "getuid") else "user")

STARTER_DEFAULTS = B.STARTER_DEFAULTS


# Systembefehle: (Kennung, Bezeichnung, Beschreibung, Suchwörter, fragt nach, Kandidaten). Der erste Kandidat, dessen Programm
# vorhanden ist, gilt als Standard (Cinnamon, sonst systemd). {sid} wird durch die Sitzungsnummer ersetzt.
SYSTEM_CMDS = [
    ("shutdown", "Herunterfahren", "Fährt den Rechner herunter und schaltet ihn aus",
     ["ausschalten", "shutdown", "poweroff", "runterfahren", "rechner aus"], True,
     [["systemctl", "poweroff"], ["loginctl", "poweroff"], ["shutdown", "-h", "now"]]),
    ("reboot", "Neu starten", "Startet den Rechner neu",
     ["neustart", "reboot", "restart", "rechner neu starten"], True,
     [["systemctl", "reboot"], ["loginctl", "reboot"], ["shutdown", "-r", "now"]]),
    ("logout", "Abmelden", "Beendet die Sitzung und kehrt zur Anmeldung zurück",
     ["logout", "ausloggen", "sitzung beenden", "abmeldung"], True,
     [["cinnamon-session-quit", "--logout", "--no-prompt"], ["gnome-session-quit", "--logout", "--no-prompt"],
      ["loginctl", "terminate-session", "{sid}"]]),
    ("lock", "Bildschirm sperren", "Sperrt den Bildschirm, die Sitzung bleibt offen",
     ["sperren", "lock", "sperrbildschirm"], False,
     [["cinnamon-screensaver-command", "--lock"], ["loginctl", "lock-session"], ["xdg-screensaver", "lock"]]),
    ("suspend", "Ruhezustand", "Versetzt den Rechner in den Ruhezustand (Bereitschaft)",
     ["bereitschaft", "standby", "suspend", "schlafen", "schlafmodus"], False,
     [["systemctl", "suspend"], ["loginctl", "suspend"]]),
]
SYSTEM_IDS = [c[0] for c in SYSTEM_CMDS]


def default_command(sid: str) -> list[str]:
    """Standardbefehl für einen Systembefehl auf diesem Rechner (leer, wenn nichts passt)."""
    for c in SYSTEM_CMDS:
        if c[0] != sid:
            continue
        for cand in c[5]:
            if "{sid}" in cand and not os.environ.get("XDG_SESSION_ID"):
                continue
            if shutil.which(cand[0]):
                return [os.environ.get("XDG_SESSION_ID", "") if a == "{sid}" else a for a in cand]
    return []


def effective_command(sid: str, conf: dict | None) -> list[str]:
    """Eigener Befehl aus den Einstellungen, sonst der Standard. Wird ohne Shell gestartet (kein Pipe, kein ;)."""
    import shlex
    own = str(((conf or {}).get(sid) or {}).get("cmd", "")).strip()
    if own:
        try:
            return shlex.split(own)
        except ValueError:
            return []
    return default_command(sid)


def system_enabled(sid: str, conf: dict | None) -> bool:
    return bool(((conf or {}).get(sid) or {}).get("on", True))


def clean_starter(v) -> dict:
    """Prüft und ergänzt die Starter-Einstellungen; ungültige Werte werden abgelehnt."""
    if not isinstance(v, dict):
        raise AppError("Starter-Einstellungen ungültig.")
    out = dict(STARTER_DEFAULTS)
    for k, val in v.items():
        if k not in STARTER_DEFAULTS:
            continue
        if k == "hotkey":
            val = str(val or "").strip()
            if val and not valid_hotkey(val):
                raise AppError("Das Tastenkürzel ist ungültig. Beispiel: <Super>space oder <Control><Alt>s.")
        elif k == "look":
            val = str(val or "").strip()
            if val not in B.STARTER_LOOKS:
                raise AppError("Das Aussehen \"%s\" gibt es nicht. Erlaubt: %s." % (val, ", ".join(B.STARTER_LOOKS)))
        elif k == "depth":
            val = str(val or "").strip()
            if val not in ("off", "soft", "strong"):
                raise AppError("Die Tiefe muss off, soft oder strong sein.")
        elif k == "sys":
            if not isinstance(val, dict):
                raise AppError("Systembefehle ungültig.")
            clean = {}
            for sid, e in val.items():
                if sid not in SYSTEM_IDS or not isinstance(e, dict):
                    continue
                cmd = str(e.get("cmd", "")).strip()
                if len(cmd) > 300 or any(ord(ch) < 32 for ch in cmd):
                    raise AppError("Der Befehl für %s ist ungültig (zu lang oder mit Steuerzeichen)." % sid)
                clean[sid] = {"on": bool(e.get("on", True)), "cmd": cmd}
            val = clean
        elif k == "design":
            val = str(val or "").strip()
            if val not in ("wolke", "desk"):
                raise AppError("Das Starter-Design muss wolke oder desk sein.")
        elif k == "desk_scheme":
            val = str(val or "").strip()
            if val not in skins.DESK_SCHEMES:
                raise AppError("Das Farbschema \"%s\" gibt es nicht. Erlaubt: %s." % (val, ", ".join(skins.DESK_SCHEMES)))
        elif k == "desk_bg":
            val = str(val or "").strip()
            if val not in ("schema", "bild", "farbe"):
                raise AppError("Der Hintergrund muss schema, bild oder farbe sein.")
        elif k == "desk_bg_image":
            val = str(val or "").strip()
            if len(val) > 600 or any(ord(ch) < 32 for ch in val):
                raise AppError("Der Pfad des Hintergrundbildes ist ungültig.")
        elif k == "desk_bg_color":
            val = str(val or "").strip().lower()
            if not re.fullmatch(r"#[0-9a-f]{6}", val):
                raise AppError("Die Hintergrundfarbe muss die Form #rrggbb haben.")
        elif k in ("desk_bg_dim", "desk_btn"):
            lo, hi = (0, 80) if k == "desk_bg_dim" else (32, 128)
            try:
                val = max(lo, min(hi, int(val)))
            except (TypeError, ValueError):
                raise AppError("%s muss eine Zahl zwischen %d und %d sein." % ("Das Abdunkeln" if k == "desk_bg_dim" else "Die Knopfgröße", lo, hi))
        elif k == "desk_side":
            val = str(val or "").strip()
            if val not in ("left", "right"):
                raise AppError("Die Seite der Knöpfe muss left oder right sein.")
        elif k == "app_favs":
            if not isinstance(val, list):
                raise AppError("Die Favoriten müssen eine Liste sein.")
            seen = []
            for x in val:
                x = str(x or "").strip()
                if x and len(x) <= 200 and not any(ord(ch) < 32 for ch in x) and x not in seen:
                    seen.append(x)
            val = seen[:60]
        elif k == "bubbles":
            try:
                val = max(6, min(24, int(val)))
            except (TypeError, ValueError):
                raise AppError("Die Blasenzahl muss eine Zahl zwischen 6 und 24 sein.")
        else:
            val = bool(val)
        out[k] = val
    return out


def valid_hotkey(s: str) -> bool:
    if not HK_RE.match(s):
        return False
    return bool(re.sub(r"<[A-Za-z]+>", "", s))


def hotkey_label(s: str) -> str:
    names = {"Super": "Super", "Control": "Strg", "Alt": "Alt", "Shift": "Umschalt"}
    keys = {"space": "Leertaste", "Return": "Enter", "Escape": "Esc", "Tab": "Tab"}
    parts = [names.get(m, m) for m in re.findall(r"<([A-Za-z]+)>", s)]
    k = re.sub(r"<[A-Za-z]+>", "", s)
    parts.append(keys.get(k, k.upper() if len(k) == 1 else k))
    return "+".join(parts)


class StarterSetup:
    # ------------------------------------------------------------ Hilfen
    @staticmethod
    def _starter_cmd() -> list[str]:
        """Befehl, der den Starter aufruft: installierter Befehl, sonst dieses Python mit starter.py."""
        for p in (Path.home() / ".local" / "bin" / "seiffert-starter", shutil.which("seiffert-starter")):
            if p and os.access(str(p), os.X_OK):
                return [str(p)]
        return [sys.executable, str(Path(__file__).resolve().parent / "starter.py")]

    @staticmethod
    def _autostart_file() -> Path:
        return Path(os.environ.get("XDG_CONFIG_HOME") or (Path.home() / ".config")) / "autostart" / "seiffert-starter.desktop"

    @staticmethod
    def _gs(*args: str) -> subprocess.CompletedProcess | None:
        if not shutil.which("gsettings"):
            return None
        try:
            return subprocess.run(["gsettings", *args], capture_output=True, text=True, timeout=6)
        except (OSError, subprocess.SubprocessError):
            return None

    def _schemas(self) -> list[str]:
        r = self._gs("list-schemas")
        return r.stdout.split() if r and r.returncode == 0 else []

    def _hk_backend(self) -> str:
        """Welcher Desktop die Kürzel verwaltet: "mate", "cinnamon" oder "" (nicht unterstützt).
        Sind beide installiert, gilt der Desktop der laufenden Sitzung; ein Eintrag für den anderen würde nie gelesen."""
        sch = self._schemas()
        has = {"mate": MATE_SCHEMA in sch, "cinnamon": HK_SCHEMA in sch}
        cur = (os.environ.get("XDG_CURRENT_DESKTOP", "") + ":" + os.environ.get("DESKTOP_SESSION", "")).lower()
        for name in ("mate", "cinnamon"):
            if name in cur and has[name]:
                return name
        for name in ("cinnamon", "mate"):
            if has[name]:
                return name
        return ""

    def _hk_supported(self) -> bool:
        return bool(self._hk_backend())

    def _mate_slot(self) -> tuple[int | None, int | None]:
        """(unser Platz, erster freier Platz) unter den eigenen MATE-Kürzeln."""
        mine = free = None
        for i in range(40):
            r = self._gs("get", "%s:%s" % (MATE_SCHEMA, MATE_DIR % i), "name")
            nm = r.stdout.strip().strip("'") if r and r.returncode == 0 else ""
            if nm == HK_NAME and mine is None:
                mine = i
            elif not nm and free is None:
                free = i
            if mine is not None and free is not None:
                break
        return mine, free

    @staticmethod
    def _mate_binding(hotkey: str) -> str:
        return hotkey.replace("<Super>", "<Mod4>")

    def _hk_list(self) -> list[str]:
        r = self._gs("get", HK_SCHEMA, "custom-list")
        if not r or r.returncode != 0:
            return []
        raw = re.sub(r"^@as\s*", "", r.stdout.strip())
        try:
            return [str(x) for x in ast.literal_eval(raw)] if raw else []
        except (ValueError, SyntaxError):
            return []

    def _hk_bound(self) -> str:
        if self._hk_backend() == "mate":
            mine, _ = self._mate_slot()
            if mine is None:
                return ""
            r = self._gs("get", "%s:%s" % (MATE_SCHEMA, MATE_DIR % mine), "binding")
            v = r.stdout.strip().strip("'") if r and r.returncode == 0 else ""
            return v.replace("<Mod4>", "<Super>")
        if HK_ID not in self._hk_list():
            return ""
        r = self._gs("get", "%s.custom-keybinding:%s" % (HK_SCHEMA, HK_PATH), "binding")
        if not r or r.returncode != 0:
            return ""
        raw = re.sub(r"^@as\s*", "", r.stdout.strip())
        try:
            lst = ast.literal_eval(raw)
        except (ValueError, SyntaxError):
            return ""
        return str(lst[0]) if lst else ""

    def _running(self) -> bool:
        path = os.path.join(tempfile.gettempdir(), SOCKET_NAME)
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(0.4)
        try:
            s.connect(path)
            return True
        except OSError:
            return False
        finally:
            s.close()

    # ------------------------------------------------------------ Schnittstelle
    def api_starter_status(self) -> dict:
        cmd = self._starter_cmd()
        backend = self._hk_backend()
        bound = self._hk_bound()
        return {
            "running": self._running(),
            "autostart": self._autostart_file().exists(),
            "hotkey_supported": bool(backend),
            "hotkey_desktop": backend,
            "hotkey_bound": bound,
            "hotkey_label": hotkey_label(bound) if bound else "",
            "installed": len(cmd) == 1,
            "command": " ".join(cmd),
        }

    def api_starter_system(self) -> list[dict]:
        """Die Systembefehle mit ihrem Standardbefehl auf diesem Rechner (für den Einstellungsdialog)."""
        conf = (self.cfg.get("starter") or {}).get("sys") or {}
        return [{"id": c[0], "label": c[1], "desc": c[2], "confirm": c[4], "default": " ".join(default_command(c[0])),
                 "on": system_enabled(c[0], conf), "cmd": str((conf.get(c[0]) or {}).get("cmd", ""))} for c in SYSTEM_CMDS]

    def api_starter_apply(self, autostart: bool | None = None, hotkey: str | None = None) -> dict:
        """Autostart ein- oder ausschalten und das Tastenkürzel setzen (hotkey) oder entfernen (hotkey = "")."""
        notes: list[str] = []
        cmd = self._starter_cmd()
        if autostart is not None:
            f = self._autostart_file()
            if autostart:
                f.parent.mkdir(parents=True, exist_ok=True)
                f.write_text("[Desktop Entry]\nType=Application\nName=Seifferts Starter\nComment=Hält den Starter bereit, damit er sofort erscheint\n"
                             "Exec=%s --daemon\nIcon=seiffert-dateien\nTerminal=false\nX-GNOME-Autostart-enabled=true\n" % " ".join(cmd), encoding="utf-8")
                notes.append("Der Starter wird künftig beim Anmelden im Hintergrund bereitgehalten.")
            else:
                try:
                    f.unlink()
                except FileNotFoundError:
                    pass
                notes.append("Der Starter startet nicht mehr automatisch beim Anmelden.")
        if hotkey is not None:
            hotkey = str(hotkey).strip()
            if hotkey and not valid_hotkey(hotkey):
                raise AppError("Das Tastenkürzel ist ungültig. Beispiel: <Super>space oder <Control><Alt>s.")
            backend = self._hk_backend()
            if not backend:
                raise AppError("Das Tastenkürzel lässt sich hier nicht setzen (gsettings oder die Einstellungen von Cinnamon oder MATE fehlen). "
                               "Lege in deiner Tastaturkonfiguration ein Kürzel für den Befehl %s an." % " ".join(cmd))
            if backend == "mate":
                mine, free = self._mate_slot()
                if hotkey:
                    slot = mine if mine is not None else free
                    if slot is None:
                        raise AppError("In den MATE-Einstellungen ist kein Platz für ein weiteres eigenes Kürzel frei.")
                    base = "%s:%s" % (MATE_SCHEMA, MATE_DIR % slot)
                    for key, val in (("name", HK_NAME), ("action", " ".join(cmd)), ("binding", self._mate_binding(hotkey))):
                        r = self._gs("set", base, key, val)
                        if not r or r.returncode != 0:
                            raise AppError("Das Tastenkürzel konnte nicht gesetzt werden.")
                    notes.append("Tastenkürzel %s ist eingetragen. Ist die Kombination schon belegt, ändere sie in den MATE-Einstellungen unter Tastatur, Tastenkürzel. Bei Super-Kürzeln kann der Panel-Menü-Schalter dazwischenfunken." % hotkey_label(hotkey))
                else:
                    if mine is not None:
                        self._gs("reset-recursively", "%s:%s" % (MATE_SCHEMA, MATE_DIR % mine))
                    notes.append("Das Tastenkürzel für den Starter ist entfernt.")
                st = self.api_starter_status()
                st["notes"] = notes
                return st
            lst = [x for x in self._hk_list() if x != HK_ID]
            if hotkey:
                base = "%s.custom-keybinding:%s" % (HK_SCHEMA, HK_PATH)
                for key, val in (("name", HK_NAME), ("command", " ".join(cmd)), ("binding", "['%s']" % hotkey)):
                    r = self._gs("set", base, key, val)
                    if not r or r.returncode != 0:
                        raise AppError("Das Tastenkürzel konnte nicht gesetzt werden.")
                lst.append(HK_ID)
                self._gs("set", HK_SCHEMA, "custom-list", repr(lst))
                notes.append("Tastenkürzel %s ist eingetragen. Ist die Kombination schon belegt, ändere sie in den Cinnamon-Einstellungen unter Tastatur, Tastenkürzel." % hotkey_label(hotkey))
            else:
                self._gs("set", HK_SCHEMA, "custom-list", repr(lst))
                self._gs("reset-recursively", "%s.custom-keybinding:%s" % (HK_SCHEMA, HK_PATH))
                notes.append("Das Tastenkürzel für den Starter ist entfernt.")
        st = self.api_starter_status()
        st["notes"] = notes
        return st

    def api_starter_control(self, action: str) -> dict:
        if action not in ("start", "stop", "show", "restart"):
            raise AppError("Unbekannte Aktion.")
        cmd = self._starter_cmd()

        def spawn(*extra: str) -> None:
            subprocess.Popen(cmd + list(extra), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)

        if action in ("stop", "restart"):
            try:
                subprocess.run(cmd + ["--quit"], stdin=subprocess.DEVNULL, capture_output=True, timeout=5)
            except (OSError, subprocess.SubprocessError):
                pass
        if action in ("start", "restart"):
            spawn("--daemon")
        elif action == "show":
            spawn("--show")
        return {"ok": True}

    def api_starter_reset_usage(self) -> dict:
        """Vergisst, welche Programme, Ordner und Dateien oft gestartet wurden."""
        try:
            (B.data_dir() / "starter.json").unlink()
        except FileNotFoundError:
            pass
        except OSError as e:
            raise AppError("Konnte die Nutzungsdaten nicht löschen: %s" % e)
        return {"ok": True}
