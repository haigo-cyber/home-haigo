#!/usr/bin/env python3
"""Prüfungen für seiffert-panel (panelsetup.py): Modell, Dateien, LXPanel, LXQt (Anlegen, Aktualisieren, Entfernen), Auswahl der Software.
Aufruf:  python3 tests/test_panel.py   (MATE und die echten Panels prüfen die Xvfb-Skripte, siehe README)"""
import json
import os
import shutil
import sys
import tempfile
from pathlib import Path

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HOME = tempfile.mkdtemp(prefix="sd-panel-home-")
os.environ.update(HOME=HOME, XDG_CONFIG_HOME=HOME + "/.config", XDG_DATA_HOME=HOME + "/.local/share", XDG_DATA_DIRS=HOME + "/usr/share")
sys.path.insert(0, HERE)
import panelsetup as P  # noqa: E402

PASS = FAIL = 0


def check(name, cond, info=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        print("FEHLER: %s %s" % (name, info))


def desktop(app_id, name):
    d = Path(HOME) / ".local/share/applications"
    d.mkdir(parents=True, exist_ok=True)
    (d / app_id).write_text("[Desktop Entry]\nType=Application\nName=%s\nExec=true\nIcon=x\n" % name, encoding="utf-8")


cfgdir = Path(HOME) / ".config" / "seiffert-dateien"
cfgdir.mkdir(parents=True)


def setcfg(**st):
    (cfgdir / "config.json").write_text(json.dumps({"starter": st}), encoding="utf-8")


# Sorten stimmen mit dem Starter überein (die Reihenfolge der Knöpfe ist dieselbe)
src = (Path(HERE) / "starter.py").read_text(encoding="utf-8")
for cat, label in P.SORTS:
    check("Sorte im Starter: " + cat, '("%s", "%s")' % (cat, label) in src)
check("Symbol je Sorte", all(c in P.GLYPHS and c in P.COLORS for c, _ in P.SORTS))
check("Symbole sind gültiges XML", all(__import__("xml.dom.minidom", fromlist=["x"]).parseString(P.svg_icon(c)) for c, _ in P.SORTS))

desktop("a.desktop", "Programm A")
desktop("b.desktop", "Programm B")
setcfg(app_favs=["b.desktop", "a.desktop", "weg.desktop", "../x.desktop"], desk_side="right", desk_btn=40)
m = P.Model()
check("Seite der Sortenknöpfe", m.side == "right" and m.other == "left")
check("Favoriten in Reihenfolge", [a for a, _, _ in m.favs] == ["b.desktop", "a.desktop"])
check("Fehlende und ungültige Favoriten ausgelassen", m.missing == ["weg.desktop", "../x.desktop"])
check("Knopfgröße", m.size == 40 and m.icon == 28)
check("Sorte Favoriten nur mit Favoriten", any(c == "favapp" for c, _, _ in m.sorts))
setcfg(desk_btn=500, desk_side="oben")
m = P.Model()
check("Größe begrenzt, Seite ungültig -> links", m.size == 128 and m.side == "left" and not any(c == "favapp" for c, _, _ in m.sorts))
check("Seite per Option", P.Model(side="right").side == "right")

setcfg(app_favs=["a.desktop"], desk_side="left", desk_btn=48)
m = P.Model()
m.write_files()
own = Path(HOME) / ".local/share/seiffert-panel"
check("Sortenstarter geschrieben", len(list(own.glob("sorte-*.desktop"))) == 9 and len(list((own / "icons").glob("*.svg"))) == 9)
txt = (own / "sorte-folder.desktop").read_text(encoding="utf-8")
check("Exec mit --cat", "--cat=folder" in txt and "Exec=" in txt and "seiffert-starter" in txt)
setcfg(desk_side="left")
P.Model().write_files()
check("Überzählige Dateien entfernt", len(list(own.glob("sorte-*.desktop"))) == 8)

# ---- LXPanel
lx = Path(HOME) / ".config/lxpanel/LXDE/panels"
lx.mkdir(parents=True)
(lx / "panel").write_text("Global {\n edge=bottom\n}\n", encoding="utf-8")
orig = (lx / "panel").read_text(encoding="utf-8")
setcfg(app_favs=["a.desktop", "b.desktop"], desk_side="left", desk_btn=48)
os.environ["PATH"] = os.path.dirname(shutil.which("true")) + ":" + os.environ["PATH"]
A = P.LXPanel()
m = P.Model()
m.write_files()
A.create(m)
s = (lx / "seiffert-sorten").read_text(encoding="utf-8")
f = (lx / "seiffert-favoriten").read_text(encoding="utf-8")
check("LXPanel: Sortenleiste links", "edge=left" in s and "id=seiffert-panel-sorte-all.desktop" in s and "widthtype=pixel" in s)
check("LXPanel: Favoritenleiste rechts in Reihenfolge", "edge=right" in f and f.index("a.desktop") < f.index("b.desktop"))
check("LXPanel: Sortenstarter im Programmordner ohne Menüeintrag", "NoDisplay=true" in (Path(HOME) / ".local/share/applications/seiffert-panel-sorte-app.desktop").read_text(encoding="utf-8"))
check("LXPanel: vorhandenes Panel unberührt", (lx / "panel").read_text(encoding="utf-8") == orig)
setcfg(app_favs=[], desk_side="left")
m = P.Model()
m.write_files()
A.create(m)
check("LXPanel: ohne Favoriten keine Favoritenleiste", not (lx / "seiffert-favoriten").exists())
A.remove()
check("LXPanel: Entfernen räumt auf", not (lx / "seiffert-sorten").exists() and not list((Path(HOME) / ".local/share/applications").glob("seiffert-panel-*")))
check("LXPanel: vorhandenes Panel nach Entfernen unberührt", (lx / "panel").read_text(encoding="utf-8") == orig)

# ---- LXQt
qt = Path(HOME) / ".config/lxqt/panel.conf"
qt.parent.mkdir(parents=True)
vorlage = "panels=panel1\n\n[panel1]\nplugins=mainmenu,quicklaunch\nposition=Bottom\n\n[quicklaunch]\ntype=quicklaunch\nalignment=Left\n"
qt.write_text(vorlage, encoding="utf-8")
Q = P.LXQt()
setcfg(app_favs=["a.desktop"], desk_side="right", desk_btn=48)
Q.create(P.Model())
t = qt.read_text(encoding="utf-8")
check("LXQt: Leistenliste", t.startswith("panels=panel1, seiffert-sorten, seiffert-favoriten"))
check("LXQt: Sortenleiste rechts, Favoriten links", "[seiffert-sorten]" in t and "position=Right" in t and "position=Left" in t)
check("LXQt: Schnellstarter", "apps\\1\\desktop=" in t and "apps\\size=9" in t and "apps\\size=1" in t)
check("LXQt: erste Leiste unberührt", "[panel1]\nplugins=mainmenu,quicklaunch\nposition=Bottom" in t)
Q.create(P.Model())
check("LXQt: zweites Anlegen verdoppelt nichts", qt.read_text(encoding="utf-8").count("[seiffert-sorten]") == 1 and qt.read_text(encoding="utf-8").count("seiffert-sorten") >= 2)
check("LXQt: Sicherung", (cfgdir / "panel-sicherung" / "lxqt-panel.conf").read_text(encoding="utf-8") == vorlage)
Q.remove()
check("LXQt: Entfernen stellt den Zustand her", qt.read_text(encoding="utf-8").strip() == vorlage.strip(), repr(qt.read_text(encoding="utf-8")))
qt.write_text("[General]\n__userfile__=true\npanels=panel1\n\n[panel1]\nposition=Top\n", encoding="utf-8")
Q.create(P.Model())
check("LXQt: panels= unter [General]", "panels=panel1, seiffert-sorten" in qt.read_text(encoding="utf-8"))
qt.write_text("[panel1]\nposition=Top\n", encoding="utf-8")
try:
    Q.create(P.Model())
    check("LXQt: Datei ohne panels= wird abgelehnt", False)
except P.PanelError:
    check("LXQt: Datei ohne panels= wird abgelehnt", qt.read_text(encoding="utf-8") == "[panel1]\nposition=Top\n")

# ---- Auswahl
try:
    P.pick("gibtsnicht")
    check("Unbekannte Software gemeldet", False)
except P.PanelError as e:
    check("Unbekannte Software gemeldet", "Möglich" in str(e))
check("Cinnamon wird nie von selbst gewählt", all(a.name != "cinnamon" for a in P.detect()))
check("Hilfe bei falschem Befehl", P.main(["x", "quatsch"]) == 2)

shutil.rmtree(HOME, ignore_errors=True)
print("%d Prüfungen bestanden, %d fehlgeschlagen" % (PASS, FAIL))
sys.exit(1 if FAIL else 0)
