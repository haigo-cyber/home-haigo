import json, os, secrets, subprocess, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit, parse_qs
from .config import log
from .sync import Sync

HERE = Path(__file__).resolve().parent
OK_PAGE = ("<!doctype html><meta charset=utf-8><title>Angemeldet</title><body style='font:16px system-ui;text-align:center;margin-top:20vh'>"
           "<h2>Angemeldet</h2><p>Seifferts Zeit ist mit Google Drive verbunden. Dieses Fenster kann geschlossen werden.</p>"
           "<script>history.replaceState(null,'','/fertig')</script>")
BAD_PAGE = ("<!doctype html><meta charset=utf-8><title>Fehler</title><body style='font:16px system-ui;text-align:center;margin-top:20vh'>"
            "<h2>Anmeldung nicht angenommen</h2><p>Bitte in der App erneut auf Mit Google Drive verbinden klicken.</p>")


class App:
    """Zustand, den Server und Fenster gemeinsam nutzen."""

    def __init__(self, settings, store, on_pdf):
        self.s, self.store, self.on_pdf = settings, store, on_pdf
        self.secret = secrets.token_urlsafe(24)
        self.port = 0
        self.sync = Sync(settings, store, lambda: self.port)
        self.httpd = None

    def html_path(self):
        p = self.s.get("html_datei")
        if p and Path(p).is_file():
            return Path(p)
        return HERE / "zeit.html"

    def page(self):
        html = self.html_path().read_text("utf-8")
        init = self.store.state if self.store.state is not None else {}
        boot = "<script>window.SZ_LINUX=%s;</script>" % json.dumps(
            {"base": "/" + self.secret, "seq": self.store.seq, "init": init}, ensure_ascii=False).replace("</", "<\\/")
        if "<!--SZ-LINUX-->" in html:
            return html.replace("<!--SZ-LINUX-->", boot, 1)
        return html.replace("<head>", "<head>" + boot, 1)

    def status(self):
        self.store.check_external()
        return {"seq": self.store.seq, "drive": self.sync.status(),
                "backup": {"dir": str(self.store.dir), "last": self.store.last_backup}}

    def start(self):
        app = self

        class H(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.0"

            def log_message(self, *a):
                pass

            def _send(self, code, body, ctype="application/json; charset=utf-8"):
                b = body if isinstance(body, bytes) else (body if isinstance(body, str) else json.dumps(body, ensure_ascii=False)).encode("utf-8")
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(b)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(b)

            def _host_ok(self):
                return self.headers.get("Host", "") in ("127.0.0.1:%d" % app.port, "localhost:%d" % app.port)

            def _route(self, method):
                if not self._host_ok():
                    return self._send(403, {"error": "Host"})
                u = urlsplit(self.path)
                if u.path == "/auth/token" and method == "GET":
                    q = parse_qs(u.query)
                    ok = app.sync.accept_token((q.get("state") or [""])[0], (q.get("token") or [""])[0], (q.get("expires") or ["3300"])[0])
                    return self._send(200 if ok else 400, OK_PAGE if ok else BAD_PAGE, "text/html; charset=utf-8")
                pre = "/" + app.secret
                if not (u.path == pre or u.path.startswith(pre + "/")):
                    return self._send(404, {"error": "nicht gefunden"})
                rest = u.path[len(pre):]
                if rest in ("", "/", "/zeit.html") and method == "GET":
                    return self._send(200, app.page(), "text/html; charset=utf-8")
                if not rest.startswith("/api/"):
                    return self._send(404, {"error": "nicht gefunden"})
                org = self.headers.get("Origin")
                if org and org not in ("http://127.0.0.1:%d" % app.port, "http://localhost:%d" % app.port):
                    return self._send(403, {"error": "Origin"})
                api = rest[5:]
                n = int(self.headers.get("Content-Length") or 0)
                body = self.rfile.read(n) if n else b""
                if api == "status" and method == "GET":
                    return self._send(200, app.status())
                if api == "state" and method == "PUT":
                    try:
                        obj = json.loads(body.decode("utf-8"))
                        assert isinstance(obj, dict) and isinstance(obj.get("entries"), list)
                    except Exception:
                        return self._send(400, {"error": "ungueltige Daten"})
                    app.store.put(obj)
                    app.sync.on_change()
                    return self._send(200, {"ok": True})
                if method != "POST":
                    return self._send(405, {"error": "Methode"})
                if api == "settings":
                    try:
                        j = json.loads(body.decode("utf-8") or "{}")
                    except Exception:
                        j = {}
                    upd = {k: str(j[k]).strip() for k in ("handoff_url", "client_id") if k in j}
                    if "handoff_url" in upd and upd["handoff_url"] and not upd["handoff_url"].startswith("https://"):
                        return self._send(400, {"error": "Die Adresse muss mit https:// beginnen."})
                    app.s.set(**upd)
                    return self._send(200, {"ok": True})
                if api == "drive/login":
                    return self._send(200, {"ok": app.sync.begin_login()})
                if api == "drive/sync":
                    if not app.sync.drive.valid():
                        return self._send(200, {"need_login": True})
                    app.sync.sync_async()
                    return self._send(200, {"ok": True})
                if api == "backup":
                    return self._send(200, {"name": app.store.backup("manuell")})
                if api == "open_data":
                    subprocess.Popen(["xdg-open", str(app.store.dir)])
                    return self._send(200, {"ok": True})
                if api == "pdf":
                    app.on_pdf()
                    return self._send(200, {"ok": True})
                return self._send(404, {"error": "unbekannt"})

            def do_GET(self):
                self._guard("GET")

            def do_PUT(self):
                self._guard("PUT")

            def do_POST(self):
                self._guard("POST")

            def _guard(self, m):
                try:
                    self._route(m)
                except Exception as e:
                    log("Serverfehler: %r" % e)
                    try:
                        self._send(500, {"error": "Serverfehler"})
                    except Exception:
                        pass

        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.httpd.daemon_threads = True
        self.port = self.httpd.server_address[1]
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()
        log("Server auf Port %d" % self.port)

    def url(self):
        return "http://127.0.0.1:%d/%s/" % (self.port, self.secret)
