"""Tabelleneditor für xlsx, xlsm und ods: Zellen ändern, formaterhaltend speichern (sheet_io.py)."""
import os
import shutil
import tempfile

from PySide6.QtCore import Qt, QAbstractTableModel, QModelIndex
from PySide6.QtGui import QAction, QColor, QFont, QKeySequence, QPalette
from PySide6.QtWidgets import (QApplication, QFileDialog, QHBoxLayout, QLabel, QLineEdit, QMainWindow,
                               QMessageBox, QTableView, QTabWidget, QVBoxLayout, QWidget, QAbstractItemView)

from . import APP_NAME, VERSION
from .common import fullscreen_action
from .readers import find_soffice, lo_convert
from .sheet_io import SheetError, col_name, open_sheet_file, parse_input


class SheetModel(QAbstractTableModel):
    def __init__(self, win, si):
        super().__init__(win)
        self.win, self.si = win, si
        self.resize_to_sheet()

    def resize_to_sheet(self):
        sh = self.win.file.sheets[self.si]
        ed = self.win.edits.get(self.si, {})
        nr = max([sh.nrows] + [r + 1 for r, _ in ed])
        nc = max([sh.ncols] + [c + 1 for _, c in ed])
        self.rows = max(nr + 60, 100)
        self.cols = max(nc + 6, 26)

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else self.rows

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else self.cols

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if role == Qt.ItemDataRole.DisplayRole:
            return col_name(section) if orientation == Qt.Orientation.Horizontal else str(section + 1)
        return None

    def flags(self, index):
        return Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable | Qt.ItemFlag.ItemIsEditable

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        key = (index.row(), index.column())
        ed = self.win.edits.get(self.si, {})
        cell = self.win.file.sheets[self.si].cells.get(key)
        if role == Qt.ItemDataRole.EditRole:
            return self.win.input_of(self.si, key)
        if role == Qt.ItemDataRole.DisplayRole:
            if key in ed:
                s = ed[key]
                k = parse_input(s)
                return k[1] if k[0] == "text" else s.strip()
            if cell is None:
                return None
            if cell.formula:
                calc = self.win.calc.get(self.si, {}).get(key)
                if calc is not None:
                    return calc
                return cell.text if (cell.text and not self.win.stale) else cell.input
            return cell.text
        if role == Qt.ItemDataRole.TextAlignmentRole:
            if key in ed:
                right = parse_input(ed[key])[0] in ("num", "date")
            else:
                right = bool(cell and cell.right)
            return int((Qt.AlignmentFlag.AlignRight if right else Qt.AlignmentFlag.AlignLeft)
                       | Qt.AlignmentFlag.AlignVCenter)
        if role == Qt.ItemDataRole.FontRole:
            f = None
            if cell is not None and cell.bold:
                f = QFont()
                f.setBold(True)
            if key in ed or (cell is not None and cell.formula and self.win.stale
                             and self.win.calc.get(self.si, {}).get(key) is None):
                f = f or QFont()
                f.setItalic(True)
            return f
        if role == Qt.ItemDataRole.BackgroundRole and key in ed:
            return QColor(255, 236, 160) if self.win.light else QColor(92, 78, 20)
        if role == Qt.ItemDataRole.ToolTipRole and cell is not None and cell.formula and key not in ed:
            return cell.input
        return None

    def setData(self, index, value, role=Qt.ItemDataRole.EditRole):
        if role != Qt.ItemDataRole.EditRole:
            return False
        self.win.set_cell(self.si, index.row(), index.column(), str(value if value is not None else ""))
        return True

    def touched(self, r, c):
        if r >= self.rows - 5 or c >= self.cols - 2:
            self.beginResetModel()
            self.rows = max(self.rows, r + 60)
            self.cols = max(self.cols, c + 6)
            self.endResetModel()
        else:
            i = self.index(r, c)
            self.dataChanged.emit(i, i)

    def refresh(self):
        self.beginResetModel()
        self.resize_to_sheet()
        self.endResetModel()


class SheetWindow(QMainWindow):
    def __init__(self, path, main=None):
        super().__init__()
        self.main = main
        self.light = bool(main.settings.get("paper_light", False)) if main is not None else False
        self.file = open_sheet_file(path)
        self.path = self.file.path
        self.edits = {}
        self.calc = {}
        self.stale = False
        self.undo = []
        self.models = []
        self.views = []
        self._tmp = None
        self.resize(1100, 700)
        if main is not None:
            self.setWindowIcon(main.windowIcon())
        self._build()
        self.statusBar().addPermanentWidget(QLabel("Version %s " % VERSION))
        self.update_title()
        self.status("Zellen ändern und speichern: Formate der Datei bleiben erhalten. " + self.file.formula_hint + ".")

    # ---- Aufbau
    def _build(self):
        central = QWidget()
        lay = QVBoxLayout(central)
        lay.setContentsMargins(4, 4, 4, 0)
        bar = QHBoxLayout()
        self.lbl = QLabel("A1")
        self.lbl.setMinimumWidth(70)
        self.edit = QLineEdit()
        self.edit.setPlaceholderText("Inhalt der Zelle: Text, Zahl (12,5), Datum (14.11.2026) oder Formel (=...)")
        self.edit.returnPressed.connect(self.commit_bar)
        bar.addWidget(self.lbl)
        bar.addWidget(self.edit, 1)
        lay.addLayout(bar)
        self.tabs = QTabWidget()
        self.tabs.setTabPosition(QTabWidget.TabPosition.South)
        self.tabs.currentChanged.connect(lambda _: self.on_current())
        lay.addWidget(self.tabs, 1)
        self.setCentralWidget(central)
        self._fill_tabs()

        def A(text, slot, key=None):
            a = QAction(text, self)
            a.triggered.connect(slot)
            if key:
                a.setShortcut(QKeySequence(key))
            return a
        mb = self.menuBar()
        m = mb.addMenu("&Datei")
        m.addAction(A("Speichern", self.save, "Ctrl+S"))
        m.addAction(A("Speichern unter …", self.save_as, "Ctrl+Shift+S"))
        m.addSeparator()
        m.addAction(A("Als LaTeX-Tabelle im Textfenster öffnen", self.to_latex))
        m.addSeparator()
        m.addAction(A("Schließen", self.close, "Ctrl+W"))
        m = mb.addMenu("&Bearbeiten")
        m.addAction(A("Rückgängig", self.undo_last, "Ctrl+Z"))
        m.addSeparator()
        m.addAction(A("Kopieren", self.copy, "Ctrl+C"))
        m.addAction(A("Einfügen", self.paste, "Ctrl+V"))
        m.addAction(A("Inhalt löschen", self.clear_cells, "Delete"))
        m = mb.addMenu("&Ansicht")
        m.addAction(fullscreen_action(self))
        m = mb.addMenu("&Hilfe")
        m.addAction(A("Hinweise zum Tabelleneditor", self.help))
        tb = self.addToolBar("Tabelle")
        tb.setMovable(False)
        for a in mb.actions()[0].menu().actions()[:2]:
            tb.addAction(a)
        self.apply_light()

    def _fill_tabs(self):
        self.tabs.blockSignals(True)
        while self.tabs.count():
            self.tabs.removeTab(0)
        self.models, self.views = [], []
        for si, sh in enumerate(self.file.sheets):
            model = SheetModel(self, si)
            view = QTableView()
            view.setModel(model)
            view.setSelectionMode(QAbstractItemView.SelectionMode.ContiguousSelection)
            view.verticalHeader().setDefaultSectionSize(24)
            view.horizontalHeader().setDefaultSectionSize(110)
            for (r, c, rs, cs) in sh.merges[:3000]:
                if r < model.rows and c < model.cols:
                    view.setSpan(r, c, rs, cs)
            view.selectionModel().currentChanged.connect(lambda *_: self.on_current())
            self.models.append(model)
            self.views.append(view)
            self.tabs.addTab(view, sh.name)
        self.tabs.blockSignals(False)
        self.apply_light()
        self.on_current()

    def apply_light(self):
        css = ("QTableView { background-color: #ffffff; color: #000000; gridline-color: #c8c8c8; "
               "selection-background-color: #3584e4; selection-color: #ffffff; } "
               "QLineEdit { background-color: #ffffff; color: #000000; }") if self.light else ""
        for v in self.views:
            v.setStyleSheet(css)
        self.edit.setStyleSheet(css)

    # ---- Zustand
    def status(self, text, ms=0):
        self.statusBar().showMessage(text, ms)

    def modified(self):
        return any(self.edits.get(k) for k in self.edits)

    def update_title(self):
        self.setWindowTitle("%s%s – %s %s Tabelle" % ("* " if self.modified() else "", os.path.basename(self.path), APP_NAME, VERSION))

    def current(self):
        si = self.tabs.currentIndex()
        if si < 0:
            return None
        idx = self.views[si].currentIndex()
        if not idx.isValid():
            return si, 0, 0
        return si, idx.row(), idx.column()

    def input_of(self, si, key):
        ed = self.edits.get(si, {})
        if key in ed:
            return ed[key]
        cell = self.file.sheets[si].cells.get(key)
        return cell.input if cell is not None else ""

    def on_current(self):
        cur = self.current()
        if cur is None:
            return
        si, r, c = cur
        self.lbl.setText("%s%d" % (col_name(c), r + 1))
        self.edit.setText(self.input_of(si, (r, c)))

    def set_cell(self, si, r, c, text, record=True):
        key = (r, c)
        old = self.input_of(si, key)
        if text == old:
            return
        cell = self.file.sheets[si].cells.get(key)
        orig = cell.input if cell is not None else ""
        ed = self.edits.setdefault(si, {})
        if record:
            self.undo.append((si, r, c, ed.get(key)))
        if text == orig:
            ed.pop(key, None)
        else:
            ed[key] = text
        if self.file.has_formulas or parse_input(text)[0] == "formula":
            if not self.stale:
                self.stale = True
                self.calc = {}
                for m in self.models:
                    m.refresh()
        self.models[si].touched(r, c)
        self.update_title()
        cur = self.current()
        if cur == (si, r, c):
            self.edit.setText(self.input_of(si, key))

    def commit_bar(self):
        cur = self.current()
        if cur is None:
            return
        si, r, c = cur
        self.set_cell(si, r, c, self.edit.text())
        v = self.views[si]
        v.setCurrentIndex(self.models[si].index(min(r + 1, self.models[si].rows - 1), c))
        v.setFocus()

    def undo_last(self):
        if not self.undo:
            return
        si, r, c, prev = self.undo.pop()
        ed = self.edits.setdefault(si, {})
        if prev is None:
            ed.pop((r, c), None)
        else:
            ed[(r, c)] = prev
        self.models[si].touched(r, c)
        self.update_title()
        self.on_current()

    def _selection(self):
        si = self.tabs.currentIndex()
        idxs = self.views[si].selectionModel().selectedIndexes()
        if not idxs:
            cur = self.current()
            return si, cur[1], cur[2], cur[1], cur[2]
        rows = [i.row() for i in idxs]
        cols = [i.column() for i in idxs]
        return si, min(rows), min(cols), max(rows), max(cols)

    def copy(self):
        if self.edit.hasFocus():
            self.edit.copy()
            return
        si, r0, c0, r1, c1 = self._selection()
        m = self.models[si]
        lines = []
        for r in range(r0, r1 + 1):
            lines.append("\t".join(str(m.data(m.index(r, c), Qt.ItemDataRole.EditRole) or "")
                                   for c in range(c0, c1 + 1)))
        QApplication.clipboard().setText("\n".join(lines))

    def paste(self):
        if self.edit.hasFocus():
            self.edit.paste()
            return
        text = QApplication.clipboard().text()
        if not text:
            return
        si, r0, c0, _, _ = self._selection()
        rows = text.rstrip("\n").split("\n")
        if len(rows) * max(len(x.split("\t")) for x in rows) > 200000:
            QMessageBox.information(self, APP_NAME, "Die Zwischenablage ist zu groß zum Einfügen.")
            return
        for dr, line in enumerate(rows):
            for dc, val in enumerate(line.rstrip("\r").split("\t")):
                self.set_cell(si, r0 + dr, c0 + dc, val)

    def clear_cells(self):
        if self.edit.hasFocus():
            self.edit.del_()
            return
        si, r0, c0, r1, c1 = self._selection()
        sh = self.file.sheets[si]
        ed = self.edits.get(si, {})
        for (r, c) in [k for k in list(sh.cells) + list(ed) if r0 <= k[0] <= r1 and c0 <= k[1] <= c1]:
            self.set_cell(si, r, c, "")

    # ---- Speichern
    def save(self):
        return self._save_to(self.path)

    def save_as(self):
        ext = os.path.splitext(self.path)[1]
        p, _ = QFileDialog.getSaveFileName(self, "Tabelle speichern unter", self.path,
                                           "Tabelle (*%s)" % ext)
        if not p:
            return False
        if not p.lower().endswith(ext.lower()):
            p += ext
        return self._save_to(p)

    def _save_to(self, dest):
        edits = {si: dict(v) for si, v in self.edits.items() if v}
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            if edits or os.path.abspath(dest) != self.path:
                self.file.save(dest, edits)
            pos = self.current()
            self.file = open_sheet_file(dest)
            self.path = self.file.path
            self.edits, self.undo, self.calc, self.stale = {}, [], {}, False
            note = "Gespeichert."
            if self.file.has_formulas and edits:
                note = self._recalc()
            self._fill_tabs()
            if pos:
                self.tabs.setCurrentIndex(pos[0])
                self.views[pos[0]].setCurrentIndex(self.models[pos[0]].index(pos[1], pos[2]))
        except SheetError as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.warning(self, APP_NAME, "Nicht gespeichert.\n\n%s\n\nDie Datei wurde nicht verändert." % e)
            return False
        except Exception as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.warning(self, APP_NAME, "Die Datei konnte nicht gespeichert werden:\n%s: %s"
                                % (type(e).__name__, e))
            return False
        QApplication.restoreOverrideCursor()
        self.update_title()
        self.status(note, 10000)
        return True

    def _recalc(self):
        """Formelergebnisse nach dem Speichern von LibreOffice berechnen lassen (nur für die Anzeige)."""
        self.stale = True
        if not find_soffice():
            return ("Gespeichert. Formelergebnisse werden erst in LibreOffice oder Excel berechnet "
                    "(LibreOffice wurde hier nicht gefunden).")
        tmp = tempfile.mkdtemp(prefix="seiffert-tab-")
        try:
            ext = os.path.splitext(self.path)[1].lower()
            src = os.path.join(tmp, "quelle" + ext)
            shutil.copy2(self.path, src)
            out = os.path.join(tmp, "aus")
            os.mkdir(out)
            res = lo_convert(src, "ods" if ext == ".ods" else "xlsx", out)
            other = open_sheet_file(res)
            for si, sh in enumerate(self.file.sheets):
                if si >= len(other.sheets):
                    break
                oc = other.sheets[si].cells
                self.calc[si] = {k: oc[k].text for k, c in sh.cells.items() if c.formula and k in oc}
            return "Gespeichert, Formeln neu berechnet."
        except Exception:
            return "Gespeichert. Die Formelergebnisse konnten hier nicht neu berechnet werden."
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def to_latex(self):
        if self.main is not None:
            if self.modified():
                QMessageBox.information(self, APP_NAME, "Umgewandelt wird der zuletzt gespeicherte Stand der Datei.")
            self.main.open_file(self.path, convert=True)
            self.main.raise_()
            self.main.activateWindow()

    def help(self):
        QMessageBox.information(self, APP_NAME, (
            "Der Tabelleneditor ändert Zellinhalte und lässt alles andere in der Datei, wie es ist "
            "(Formate, Spaltenbreiten, Diagramme, weitere Blätter).\n\n"
            "Eingaben: Text, Zahl mit Komma (12,5), Prozent (12,5%%), Datum (14.11.2026), Formel mit = am Anfang. "
            "Ein Hochkomma am Anfang erzwingt Text.\n\n%s.\n\n"
            "Formelergebnisse werden nach dem Speichern von LibreOffice neu berechnet, wenn es installiert ist. "
            "Geänderte Zellen sind bis zum Speichern farbig hinterlegt.\n\n"
            "Nicht möglich: Zeilen oder Spalten einfügen und löschen, Formate ändern, Blätter anlegen. "
            "Beim ersten Speichern entsteht eine Sicherung mit der Endung .bak.") % self.file.formula_hint)

    def closeEvent(self, e):
        if self.modified():
            r = QMessageBox.question(self, APP_NAME, "Änderungen an %s speichern?" % os.path.basename(self.path),
                                     QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard
                                     | QMessageBox.StandardButton.Cancel)
            if r == QMessageBox.StandardButton.Cancel or (r == QMessageBox.StandardButton.Save and not self.save()):
                e.ignore()
                return
        if self.main is not None and self in self.main.children_windows:
            self.main.children_windows.remove(self)
        e.accept()
