import json, sys
import os; sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
from seiffert_text import quick as q
scen = json.load(open("scen.json"))
def norm(doc):
    return {"eol": doc["eol"], "head": doc["head"], "tail": doc["tail"],
            "units": [{"raw": u["raw"], "fixed": bool(u.get("fixed")), "img": u.get("img"),
                       "segs": [[s["k"], s["v"], bool(s.get("raw")), bool(s.get("edited"))] for s in u["segs"]]} for u in doc["units"]]}
def run(text):
    out = {}
    d = q.parse_tex(text)
    out["parse"] = norm(d)
    out["ser"] = [q.serialize(d, {"autoEscape": bool(m & 1), "autoBreak": bool(m & 2)}) for m in range(4)]
    theme = q.theme_macro(d); out["theme"] = theme
    out["macros"] = sorted(q.defined_macros(d["head"]))
    out["blocks"] = [[b["start"], b["end"], b["next"]] for b in q.blocks_of(d, theme)]
    out["types"] = [[t["macro"], t["fields"]] for t in q.line_types(d)]
    out["head"] = [[f["name"], f["start"], f["end"], f["value"]] for f in q.head_fields(d["head"])]
    out["images"] = q.find_images(d, {"autoEscape": True, "autoBreak": True})
    out["check"] = [x["msg"] for x in q.check_doc(d, {"autoEscape": True})]
    ns = q.find_name_size(d["head"])
    out["ns"] = ns
    import copy
    d2 = copy.deepcopy(d)
    r = q.set_name_size(d2, 18); out["setns"] = [r, d2["head"]]
    d3 = copy.deepcopy(d)
    out["shf"] = [q.set_head_field(d3, "Titel", "Neu & anders 50%", {"autoEscape": True}), d3["head"]]
    steps = []
    vis = lambda u: not u.get("fixed") and (q.has_fields(u) or bool(u.get("img")))
    for o in scen["ops"]:
        n = len(d["units"]); I = lambda x: x % n
        op = o["op"]
        try:
            if op == "insertBelow": q.op_insert_below(d, I(o["i"]))
            elif op == "duplicate": q.op_duplicate(d, I(o["i"]))
            elif op == "remove": q.op_remove(d, I(o["i"]))
            elif op == "move": q.op_move(d, I(o["a"]), I(o["b"]))
            elif op == "moveRel": q.op_move_relative(d, I(o["i"]), o["d"], vis)
            elif op == "bulk": q.op_bulk(d, I(o["i"]), o["text"])
            elif op in ("blockMove", "blockDuplicate", "blockRemove", "insertTypeAfterBlock"):
                bl = q.blocks_of(d, theme)
                if not bl: steps.append("noblocks"); continue
                b = bl[o["k"] % len(bl)]
                if op == "blockMove": q.op_block_move(d, theme, b["id"], o["d"])
                elif op == "blockDuplicate": q.op_block_duplicate(d, theme, b["id"])
                elif op == "blockRemove": q.op_block_remove(d, theme, b["id"])
                else:
                    ty = q.line_types(d)
                    if not ty: steps.append("notypes"); continue
                    q.op_insert_type_after_block(d, theme, b["id"], ty[o["t"] % len(ty)]["unit"])
            elif op == "insertType":
                ty = q.line_types(d)
                if not ty: steps.append("notypes"); continue
                q.op_insert_type(d, I(o["i"]), ty[o["t"] % len(ty)]["unit"])
            elif op == "insertImage": q.op_insert_image(d, I(o["i"]), o["file"], o["w"], o["a"])
            elif op == "setImg":
                im = [u for u in d["units"] if u.get("img")]
                if not im: steps.append("noimg"); continue
                q.op_set_img(im[-1], w=o["w"], a=o["a"])
            elif op == "setRaw": q.op_set_raw(d, I(o["i"]), o["raw"])
            elif op == "edit":
                for i, u in enumerate(d["units"]):
                    if i % o["every"] == 0:
                        for s in u["segs"]:
                            if s["k"] == "x": s["v"] = o["val"]; s["edited"] = True
        except Exception as e:
            steps.append("ERR %s %s" % (op, e)); continue
        steps.append([op, len(norm(d)["units"]), q.serialize(d, {"autoEscape": True, "autoBreak": True}),
                      q.serialize_file(d, {"autoEscape": False, "autoBreak": False})])
    out["steps"] = steps
    return out
res = {f: run(open(f, encoding="utf-8", newline="").read()) for f in sys.argv[1:]}
print(json.dumps(res))
