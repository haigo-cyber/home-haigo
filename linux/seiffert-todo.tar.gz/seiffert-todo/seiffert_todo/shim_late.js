/* Seifferts ToDo (Linux): wird nach der Seite geladen.
   Sync-Anzeige, Abgleich beim Start, regelmäßiges Holen, Nachholen nach Fehlern, Sichern beim Schließen. */
(function () {
  "use strict";
  var L = window.__LINUX || {};
  var S = window.__linuxSync;
  if (!S) return;
  var plog = window.__linuxLog || function () {};
  var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  var tryG = function (f, d) { try { return f(); } catch (e) { return d; } };

  /* ---------- Schnellstart: feste lokale Datendatei (daten.json) ----------
     Mit Datendatei startet die Seite sofort mit dem letzten Stand. Google wird erst nach der Anmelde-Abfrage
     (oder auf Klick) verbunden; dann werden lokale Änderungen und der Serverstand zusammengeführt. */
  var SN = (L.snap && L.snap.v === 1) ? L.snap : null;
  var hydrated = false, merged = false, merging = false, askTimer = null, distrBaseJson = null;
  var localMode = function () { return hydrated && !merged; };
  S.localMode = localMode;

  /* gleichzeitige Token-Anfragen teilen sich einen Anmeldevorgang
     (die Seite kennt nur einen Platz für den Rückruf, sonst bliebe ein Aufruf ewig hängen) */
  (function () {
    var orig = window.requestToken, shared = null;
    if (typeof orig !== "function") return;
    window.requestToken = function (interactive) {
      if (shared) return shared;
      shared = Promise.resolve(orig(interactive)).then(function (r) { shared = null; return r; }, function (e) { shared = null; throw e; });
      return shared;
    };
  })();

  /* ---------- Anzeige ---------- */
  var pill = document.createElement("button");
  pill.id = "linuxSyncPill";
  pill.type = "button";
  pill.style.cssText = "border:1px solid rgba(128,128,128,.4);background:transparent;color:inherit;border-radius:12px;padding:2px 9px;font-size:12px;line-height:18px;margin-right:6px;cursor:pointer;white-space:nowrap;max-width:46vw;overflow:hidden;text-overflow:ellipsis";
  var dot = document.getElementById("syncDot");
  if (dot && dot.parentNode) dot.parentNode.insertBefore(pill, dot);
  else { pill.style.cssText += ";position:fixed;right:8px;top:8px;z-index:9999;background:#fff;color:#000"; document.body.appendChild(pill); }

  function hhmm(t) { return new Date(t).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" }); }
  function booted() { if (merging || localMode()) return false; var n = document.getElementById("nav"); return !!(n && n.style.display === "flex" && tryG(function () { return !!accessToken && !!spreadsheetId; }, false)); }
  function tokenLeftMs() { return S.expiresAt - Date.now(); }
  function render() {
    var left = tokenLeftMs(), txt, col;
    if (merging) { txt = "Gleiche mit Google ab …"; col = "#d98a00"; }
    else if (localMode()) { txt = S.loginPending ? "Warte auf Anmeldung im Browser …" : "Lokal · Stand " + hhmm(SN.at) + " – bei Google anmelden"; col = "#d98a00"; }
    else if (S.loginPending) { txt = "Warte auf Anmeldung im Browser …"; col = "#d98a00"; }
    else if (!S.expiresAt || left <= 0) { txt = booted() ? "Anmeldung abgelaufen – erneuern" : "Nicht angemeldet"; col = "#c0392b"; }
    else if (S.needResync) { txt = "Nicht synchron – wird nachgeholt"; col = "#c0392b"; }
    else if (S.inflight > 0) { txt = "Gleiche ab …"; col = "#d98a00"; }
    else if (left < 5 * 60000) { txt = "Anmeldung endet in " + Math.max(1, Math.ceil(left / 60000)) + " Min – erneuern"; col = "#d98a00"; }
    else if (S.lastOk) { txt = "Synchron · " + hhmm(S.lastOk); col = "#2e9e5b"; }
    else { txt = "Verbunden"; col = "#2e9e5b"; }
    pill.textContent = "● " + txt;
    pill.style.color = col;
    pill.title = (S.lastError ? S.lastError + "\n" : "") + (S.expiresAt && left > 0 ? "Anmeldung gültig bis " + hhmm(S.expiresAt) : "Klicken: Anmeldung erneuern oder jetzt abgleichen");
  }
  S.listeners.push(render);
  setInterval(render, 15000);
  render();

  pill.addEventListener("click", function () {
    if (localMode()) { if (!merging) { clearTimeout(askTimer); tryG(function () { signIn(); }); } return; }
    var left = tokenLeftMs();
    if (S.loginPending) { window.__linuxForceLogin(); return; }
    if (!S.expiresAt || left < 5 * 60000) { renewLogin(); return; }
    window.__linuxSyncNow(true);
  });

  async function renewLogin() {
    await window.__linuxForceLogin();
    if (booted()) window.__linuxSyncNow(false);
    else if (typeof signIn === "function") signIn();
  }

  /* ---------- Abgleich ---------- */
  function tasksDirty() {
    return tryG(function () {
      if (tasks.length !== tasksBase.size) return true;
      return tasks.some(function (t) { return tasksBase.get(t.id) !== taskRowKey(t); });
    }, false);
  }
  function logsDirty() {
    return tryG(function () {
      var key = function (l) { return l.itemId + "|" + l.date; };
      var snap = new Set(logsSnapshotAtLoad.map(key));
      return logs.length !== logsSnapshotAtLoad.length || logs.some(function (l) { return !snap.has(key(l)); });
    }, false);
  }
  function listDirty(kind) {
    return tryG(function () {
      var c = LISTCFG[kind], base = listBase[kind], local = c.get() || [];
      if (listLoadErr[kind]) return false;
      if (local.length !== base.size) return true;
      return local.some(function (x) { return x && x.id && base.get(x.id) !== JSON.stringify(x); });
    }, false);
  }
  function planDirty() { return tryG(function () { return !!(tp.pending || tm.pending); }, false); }
  function wsDirtyNow() { return tryG(function () { return !!(wsDirty.size || wsDeleted.size); }, false); }
  function busy() { return tryG(function () { return _busyCount > 0; }, false) || S.inflight > 0; }

  function pendingKinds(all) {
    var f = S.failedKinds, k = [];
    if (tasksDirty() || (!all && f.Tasks)) k.push("Tasks");
    if (logsDirty() || (!all && f.Log)) k.push("Log");
    if (listDirty("projects") || (!all && f.Projects)) k.push("Projects");
    if (listDirty("notes") || (!all && f.Notes)) k.push("Notes");
    if (listDirty("links") || (!all && f.Links)) k.push("Links");
    if (planDirty() || wsDirtyNow() || (!all && (f.Drive || f.Sonst))) k.push("Plan");
    return k;
  }
  var resyncRunning = false, resyncTimer = null;
  async function resync(all) {
    if (resyncRunning) return false;
    if (!booted() || tokenLeftMs() <= 0) return false;
    resyncRunning = true;
    var ok = true, kinds = pendingKinds(all);
    try {
      if (kinds.length) plog("Abgleich (" + (all ? "alles" : "Nachholen") + "): " + kinds.join(", "));
      for (var i = 0; i < kinds.length; i++) {
        try {
          var k = kinds[i];
          if (k === "Tasks") await saveTasks();
          else if (k === "Log") await saveLogs();
          else if (k === "Projects") await saveProjects();
          else if (k === "Notes") await saveNotes();
          else if (k === "Links") await saveLinks();
          else if (k === "Plan") {
            if (tryG(function () { return tm.pending; }, false)) await tmSave();
            if (tryG(function () { return tp.pending; }, false)) await tpSave();
            if (wsDirtyNow()) await wsFlush();
          }
          delete S.failedKinds[k === "Plan" ? "Drive" : k];
          if (k === "Plan") delete S.failedKinds.Sonst;
        } catch (e) { ok = false; plog("Abgleich " + kinds[i] + " fehlgeschlagen: " + String((e && e.message) || e).slice(0, 120)); }
      }
      if (ok && !busy()) { S.failedKinds = {}; S.needResync = false; }
    } finally { resyncRunning = false; S.emit(); }
    return ok;
  }
  window.__linuxResyncSoon = function () {
    if (resyncTimer || resyncRunning) return;
    resyncTimer = setTimeout(function () { resyncTimer = null; resync(false); }, 3000);
  };

  /* Jetzt abgleichen: lokale Änderungen schreiben, dann Serverstand holen */
  window.__linuxSyncNow = async function (verbose) {
    if (localMode()) { if (!merging) { clearTimeout(askTimer); tryG(function () { signIn(); }); } return false; }
    if (!booted()) { if (verbose) tryG(function () { toast("Noch nicht angemeldet"); }); return false; }
    if (tokenLeftMs() <= 0) { renewLogin(); return false; }
    var ok = await resync(true);
    var ch = false;
    try { ch = await refreshFromServer(true); } catch (e) { ok = false; }
    if (ok) S.lastOk = Date.now();
    S.emit();
    if (verbose) tryG(function () { toast(ok ? (ch ? "Abgeglichen – Änderungen von anderen Geräten übernommen" : "Abgeglichen – alles aktuell") : "Abgleich nicht vollständig – siehe Anzeige oben"); });
    return ok;
  };

  /* ---------- regelmäßig holen ---------- */
  function visibleNow() { return document.visibilityState === "visible"; }
  setInterval(function () {
    if (!booted() || !visibleNow() || tokenLeftMs() <= 0) return;
    if (S.needResync) { resync(false); return; }
    tryG(function () { return refreshFromServer(true); });   // die Seite selbst holt sonst frühestens nach 90 Sekunden
  }, 60000);
  setInterval(function () {      // nach Fehlern nachholen, auch wenn das Fenster nicht sichtbar ist
    if (S.needResync && booted() && tokenLeftMs() > 0) resync(false);
  }, 15000);
  window.addEventListener("focus", function () { if (booted() && tokenLeftMs() > 0) { tryG(function () { refreshFromServer(false); }); if (S.needResync) resync(false); } });
  window.addEventListener("online", function () { if (S.needResync) resync(false); });

  /* ---------- Beenden ---------- */
  window.__linuxPending = function () {
    if (localMode()) return JSON.stringify({ pending: false, booted: false, local: true });
    if (!booted()) return JSON.stringify({ pending: false, booted: false });
    var k = pendingKinds(true);
    return JSON.stringify({ pending: k.length > 0 || busy() || S.needResync, kinds: k, busy: busy(), needResync: S.needResync, tokenOk: tokenLeftMs() > 0 });
  };
  var flushState = "idle";
  window.__linuxFlushStart = function () {
    flushState = "running";
    (async function () {
      try {
        if (tokenLeftMs() <= 0) { flushState = "fail:Anmeldung abgelaufen"; return; }
        var ok = await resync(true);
        for (var i = 0; i < 40 && busy(); i++) await sleep(250);
        if (typeof window.__linuxLsFlush === "function") window.__linuxLsFlush();
        flushState = (ok && !busy()) ? "ok" : "fail:Nicht alles konnte geschrieben werden";
      } catch (e) { flushState = "fail:" + String((e && e.message) || e).slice(0, 100); }
    })();
    return "started";
  };
  window.__linuxFlushState = function () { return flushState; };

  /* ---------- Schnellstart: sichern, laden, abgleichen ---------- */
  function snapCollect() {
    return tryG(function () {
      if (!localMode()) distrBaseJson = JSON.stringify(distractions);
      return {
        v: 1, at: 0, ssid: spreadsheetId || null,
        tasks: tasks, logs: logs, projects: projects, notes: notes, links: links, distractions: distractions, distrBase: distrBaseJson,
        tasksBase: Array.from(tasksBase.entries()), logsBase: logsSnapshotAtLoad,
        listBase: { projects: Array.from(listBase.projects.entries()), notes: Array.from(listBase.notes.entries()), links: Array.from(listBase.links.entries()) },
        ws: { docs: wsDocs, trash: wsTrash, dirty: Array.from(wsDirty.entries()), deleted: Array.from(wsDeleted.entries()), trashAdd: Array.from(wsTrashAdd), trashGone: Array.from(wsTrashGone), rev: wsRev },
        g: { gtasks: gtasks, goalTasks: goalTasks, allOpenGoals: allOpenGoals, allGTasks: allGTasks, listId: defaultGTaskListId },
        cal: { calendars: calendars, allCalendars: allCalendars, events: todayCalendarEvents, day: todayKey() }
      };
    }, null);
  }
  var lastSnapJson = "", snapBusy = false, snapAgain = false;
  window.__linuxSnapState = "idle";
  function snapReady() {
    if (merging) return false;
    if (!(hydrated || booted())) return false;                       // vor dem ersten vollständigen Laden wird nichts geschrieben
    return tryG(function () {
      return !!spreadsheetId && wsLoaded && !wsLoadError && !listLoadErr.projects && !listLoadErr.notes && !listLoadErr.links && !distrLoadErr;
    }, false);
  }
  async function snapSave() {
    if (!snapReady()) return;
    if (snapBusy) { snapAgain = true; return; }
    var o = snapCollect(); if (!o) return;
    if (SN && SN.tasks && SN.tasks.length > 5 && o.tasks.length === 0) return;       // nie eine leere Liste über volle Daten schreiben
    var j = JSON.stringify(o);
    if (j === lastSnapJson) return;
    snapBusy = true; window.__linuxSnapState = "busy";
    try {
      var r = await fetch((L.base || "/") + "api/snap", { method: "POST", body: j.replace('"at":0', '"at":' + Date.now()) });
      if (r.ok) lastSnapJson = j; else plog("Datendatei nicht gesichert (Status " + r.status + ")");
    } catch (e) { plog("Datendatei nicht gesichert: " + String((e && e.message) || e).slice(0, 100)); }
    snapBusy = false; window.__linuxSnapState = "idle";
    if (snapAgain) { snapAgain = false; setTimeout(snapSave, 200); }
  }
  window.__linuxSnapFlush = function () { snapSave(); return "started"; };
  if (L.schnell !== false) setInterval(snapSave, Math.max(1, +L.snapEvery || 20) * 1000);
  window.addEventListener("pagehide", function () { snapSave(); });

  function hydrate(d) {
    var ssLs = tryG(function () { return localStorage.getItem("ssid"); }, null);
    if (d.ssid && ssLs && d.ssid !== ssLs) return false;
    tasks = d.tasks || []; logs = d.logs || []; projects = d.projects || []; notes = d.notes || []; links = d.links || []; distractions = d.distractions || [];
    if (d.ssid) spreadsheetId = d.ssid;
    tasksBase = new Map(d.tasksBase || []); logsSnapshotAtLoad = d.logsBase || [];
    ["projects", "notes", "links"].forEach(function (k) { listBase[k] = new Map((d.listBase || {})[k] || []); listLoadErr[k] = ""; });
    distrLoadErr = ""; distrBaseJson = (typeof d.distrBase === "string") ? d.distrBase : null;
    var w = d.ws || {};
    wsDocs = w.docs || []; wsTrash = w.trash || [];
    wsDirty.clear(); (w.dirty || []).forEach(function (e) { wsDirty.set(e[0], e[1]); });
    wsDeleted.clear(); (w.deleted || []).forEach(function (e) { wsDeleted.set(e[0], e[1]); });
    wsTrashAdd.clear(); (w.trashAdd || []).forEach(function (x) { wsTrashAdd.add(x); });
    wsTrashGone.clear(); (w.trashGone || []).forEach(function (x) { wsTrashGone.add(x); });
    wsRev = w.rev || 0; wsLoaded = true; wsLoadError = ""; wsLastLoad = Date.now();
    var g = d.g || {};
    gtasks = g.gtasks || []; goalTasks = g.goalTasks || []; allOpenGoals = g.allOpenGoals || []; allGTasks = g.allGTasks || []; defaultGTaskListId = g.listId || "";
    var c = d.cal || {};
    calendars = c.calendars || []; allCalendars = c.allCalendars || [];
    todayCalendarEvents = (c.day === todayKey() && Array.isArray(c.events)) ? c.events : [];
    _lastRefresh = Date.now();
    return true;
  }

  /* Wirkung der Hydrierung: Oberfläche zeigen. Alles, was Google bräuchte, schlägt bis zur Anmeldung still fehl. */
  var origApi = window.api, origToast = window.toast, origShowSignin = window.showSignin, origBootData = window.bootData, lastOffToast = 0;
  if (typeof origApi === "function") window.api = function () {
    if (localMode() && !tryG(function () { return accessToken; }, null)) { var e = new Error("Offline: noch nicht bei Google angemeldet"); e.offline = true; return Promise.reject(e); }
    return origApi.apply(this, arguments);
  };
  if (typeof origToast === "function") window.toast = function (msg, ms) {
    if (localMode() && /fehlgeschlagen|nicht gespeichert|Offline|Keine Verbindung|nicht geladen/i.test(String(msg))) {
      if (Date.now() - lastOffToast > 60000) { lastOffToast = Date.now(); return origToast("Lokal gespeichert – der Abgleich mit Google folgt nach der Anmeldung", ms); }
      return;
    }
    return origToast.apply(this, arguments);
  };
  if (typeof origShowSignin === "function") window.showSignin = function () { if (localMode()) { tryG(function () { render_(); }); return; } return origShowSignin.apply(this, arguments); };
  function render_() { if (typeof window.render === "function") window.render(); }

  async function bootMerge() {
    if (merging) return;
    merging = true; S.emit(); tryG(function () { setSync("busy"); });
    try {
      plog("Schnellstart: Abgleich mit Google beginnt");
      await ensureSheet();
      await api(SHEETS + "/" + spreadsheetId + "/values/Tasks!A1?valueInputOption=RAW", { method: "PUT", body: JSON.stringify({ values: [TASK_COLS] }) });
      // Aufgaben und Protokoll: Serverstand und lokale Änderungen zusammenführen
      var ok = false;
      for (var i = 0; i < 8 && !ok; i++) {
        _lastRefresh = 0; await refreshFromServer(true); ok = _lastRefresh > 0;
        if (!ok) await sleep(1000);
      }
      if (!ok) throw new Error("Aufgaben konnten nicht abgeglichen werden");
      // Projekte, Notizen, Links: nur laden, wenn lokal nichts geändert wurde; sonst mit dem Serverstand zusammenführen
      var kinds = ["projects", "notes", "links"];
      for (var q = 0; q < kinds.length; q++) {
        var k = kinds[q];
        if (listDirty(k)) { await listPreSave(k); continue; }
        if (k === "notes") await loadNotes();
        else if (k === "links") await loadLinks();
        else {
          try {
            var p = await api(SHEETS + "/" + spreadsheetId + "/values/Projects!A1");
            var js = p && p.values && p.values[0] && p.values[0][0];
            projects = js ? JSON.parse(js) : []; listLoadErr.projects = ""; listBaseReset("projects");
          } catch (e) { listLoadFailed("projects", e); }
        }
      }
      var dj = JSON.stringify(distractions);
      if (distrBaseJson !== null && dj !== distrBaseJson) { await saveDistractions(); distrBaseJson = dj; } else await loadDistractions();
      await loadWorkspace();
      await purgeStaleGoals();
      await loadCalendars();
      await loadGTasks();
      await recurringGoalsRun();
      await loadTodayCalendarEvents();
      checkGoalsPenalty();
      await wsReconcileLinks();
      merged = true; merging = false;
      tryG(function () { setSync("on"); $("acctBtn").textContent = "Verbunden"; $("nav").style.display = "flex"; });
      S.lastOk = Date.now();
      render_(); S.emit();
      tryG(function () { autoBackupTodo(); });
      plog("Schnellstart: Abgleich fertig");
      resync(true).then(function () { S.emit(); });          // lokale Änderungen aus der Offline-Zeit nach Google schreiben
    } catch (e) {
      merging = false;
      plog("Schnellstart: Abgleich fehlgeschlagen: " + String((e && e.message) || e).slice(0, 160));
      tryG(function () { setSync("off"); toast("Abgleich mit Google nicht möglich: " + String((e && e.message) || e).slice(0, 80) + ". Du arbeitest weiter lokal; oben auf die Anzeige tippen, um es neu zu versuchen."); });
      S.emit();
    }
  }
  if (typeof origBootData === "function") window.bootData = function () {
    if (localMode()) return bootMerge();
    return origBootData.apply(this, arguments);
  };

  /* Abfrage: Mit Google verbinden? */
  function askLogin() {
    if (!localMode() || merging || S.loginPending) return;
    if (document.getElementById("modalBg")) { askTimer = setTimeout(askLogin, 30000); return; }
    document.body.insertAdjacentHTML("beforeend", '<div class="modal-bg" id="modalBg"><div class="modal"><h2>Mit Google verbinden?</h2>' +
      '<p style="margin:8px 0 14px">Die App läuft mit deinen lokalen Daten (Stand ' + hhmm(SN.at) + ' Uhr). Mit der Anmeldung werden sie mit Google abgeglichen und gesichert, Änderungen anderer Geräte kommen dazu.</p>' +
      '<div class="modal-actions"><button id="lgLater">In 10 Minuten</button><button id="lgNever">Heute nicht mehr fragen</button><button class="btn-primary" id="lgNow">Jetzt anmelden</button></div></div></div>');
    var close = function () { var m = document.getElementById("modalBg"); if (m) m.remove(); };
    document.getElementById("lgNow").onclick = function () { close(); tryG(function () { signIn(); }); };
    document.getElementById("lgLater").onclick = function () { close(); askTimer = setTimeout(askLogin, 600000); };
    document.getElementById("lgNever").onclick = function () { close(); };
  }

  /* ---------- Start ---------- */
  if (SN && L.schnell !== false && hydrate(SN)) {
    hydrated = true;
    tryG(function () { $("nav").style.display = "flex"; $("acctBtn").textContent = "Lokal"; setSync(""); });
    render_(); S.emit();
    plog("Start: lokale Datendatei vom " + new Date(SN.at).toLocaleString("de-DE") + " (" + tasks.length + " Aufgaben)");
    var delay = Math.max(3, +L.loginNach || 90) * 1000;
    if (L.auth && L.auth.valid) setTimeout(function () { if (localMode() && !merging) { plog("Start: gemerkte Anmeldung gilt, verbinde mit Google"); tryG(function () { signIn(); }); } }, delay);
    else askTimer = setTimeout(askLogin, delay);
  } else {
    /* ---------- ohne Datendatei: sofort anmelden und Daten holen (erster Start) ---------- */
    setTimeout(function () {
      if (!L.autoLogin) return;
      if (typeof signIn !== "function") return;
      plog("Start: Anmeldung und Abgleich");
      signIn();
    }, 300);
  }
})();
