"""Markdown-Ausgabe mit ausgelagerten Bildern."""
import hashlib
import os
import re

from PySide6.QtCore import QBuffer, QIODevice, QUrl
from PySide6.QtGui import QImage, QTextDocument

IMG_RE = re.compile(r"!\[([^\]]*)\]\(([^)\s]+)((?:\s+\"[^\"]*\")?)\)")


def markdown_with_images(doc, base_dir=None):
    """Liefert (text, {dateiname: bytes}). Eingebettete Bilder werden als bilder/bildN.png referenziert."""
    md = doc.toMarkdown()
    images = {}
    seen = {}

    def repl(m):
        alt, name, title = m.group(1), m.group(2), m.group(3)
        if name.startswith(("http:", "https:", "bilder/")):
            return m.group(0)
        res = doc.resource(QTextDocument.ResourceType.ImageResource, QUrl(name))
        img = res if isinstance(res, QImage) else None
        if img is None or img.isNull():
            return m.group(0)       # Bild liegt als Datei neben dem Dokument
        buf = QBuffer()
        buf.open(QIODevice.OpenModeFlag.WriteOnly)
        img.save(buf, "PNG")
        data = bytes(buf.data())
        h = hashlib.sha1(data).hexdigest()
        fn = seen.get(h)
        if fn is None:
            fn = "bild%d.png" % (len(seen) + 1)
            seen[h] = fn
            images[fn] = data
        return "![%s](bilder/%s%s)" % (alt if alt != "image" else "", fn, title)
    return IMG_RE.sub(repl, md), images
