#!/usr/bin/env python3
"""Seifferts Terminal - eigenständiges Terminalprogramm (Qt WebEngine + xterm.js) mit Python-Backend.

Start:  python3 terminal_app.py [-d Ordner] [-e Programm Argumente …] [--view Datei] [--profile Name] [--fullscreen]
Die Shell-Sitzungen kommen aus terminal.py (wie im Terminal von Seifferts Dateien), die Einstellungen aus termsettings.py.
"""
from __future__ import annotations

import base64
import json
import os
import shutil
import sys
import threading
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import termsettings as T  # noqa: E402

APP_NAME = "Seifferts Terminal"
INDEX_HTML = os.path.join(HERE, "terminal.html")
MAX_VIEW_BYTES = 3 * 1024 * 1024

HELP = """Seifferts Terminal %s

Aufruf:  seiffert-terminal [Optionen]
  -d, --dir ORDNER      im Ordner starten
  -e, --exec PROGRAMM [ARGUMENTE …]   statt der Shell ein Programm ausführen (alles danach gehört zum Programm)
  --view DATEI          Datei in Farben anzeigen (Syntaxhervorhebung)
  --profile NAME        Profil aus den Einstellungen verwenden
  --fullscreen          im Vollbild starten
  -h, --help            diese Hilfe
""" % T.VERSION


def parse_args(argv: list) -> dict:
    """Zerlegt die Kommandozeile. Gibt ein Dictionary zurück; Fehler als {'error': Text}."""
    out: dict = {"dir": "", "exec": [], "view": "", "profile": "", "fullscreen": False, "help": False}
    i = 0
    while i < len(argv):
        a = argv[i]
        val = None
        if a.startswith("--") and "=" in a:
            a, _, val = a.partition("=")
        if a in ("-h", "--help"):
            out["help"] = True
        elif a == "--fullscreen":
            out["fullscreen"] = True
        elif a in ("-e", "--exec"):
            if val is not None:
                out["exec"] = [val] + list(argv[i + 1:])
            else:
                out["exec"] = list(argv[i + 1:])
            if not out["exec"]:
                return {"error": "Nach -e muss ein Programm stehen."}
            break
        elif a in ("-d", "--dir", "--view", "--profile"):
            if val is None:
                i += 1
                if i >= len(argv):
                    return {"error": "Nach %s fehlt ein Wert." % a}
                val = argv[i]
            out[{"-d": "dir", "--dir": "dir", "--view": "view", "--profile": "profile"}[a]] = val
        elif a.startswith("-"):
            return {"error": "Unbekannte Option %s. Hilfe: seiffert-terminal --help" % a}
        elif not out["dir"] and os.path.isdir(os.path.expanduser(a)):
            out["dir"] = a                      # ein bloßer Ordner als Argument
        else:
            return {"error": "Unbekanntes Argument %s. Hilfe: seiffert-terminal --help" % a}
        i += 1
    if out["dir"]:
        out["dir"] = os.path.abspath(os.path.expanduser(out["dir"]))
    if out["view"]:
        out["view"] = os.path.abspath(os.path.expanduser(out["view"]))
    return out


if __name__ == "__main__" and any(a in ("-h", "--help") for a in sys.argv[1:]):
    sys.stdout.write(HELP)
    sys.exit(0)

try:
    from PySide6.QtCore import QByteArray, QObject, QProcess, QTimer, QUrl, Qt, Signal, Slot
    from PySide6.QtGui import QColor, QDesktopServices, QFontDatabase, QGuiApplication, QIcon
    from PySide6.QtWebChannel import QWebChannel
    from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineProfile, QWebEngineSettings
    from PySide6.QtWebEngineWidgets import QWebEngineView
    from PySide6.QtWidgets import QApplication, QFileDialog, QMainWindow, QMessageBox
except ImportError as exc:  # pragma: no cover
    sys.stderr.write(
        "PySide6 mit QtWebEngine fehlt (%s).\n"
        "Auf Arch zum Beispiel:  sudo pacman -S pyside6 qt6-webengine\n"
        "oder in einer virtuellen Umgebung:  pip install PySide6 PySide6-WebEngine\n" % exc)
    sys.exit(1)

from terminal import Terminals  # noqa: E402

AppError = T.AppError


class Host(Terminals):
    """Backend ohne Qt: Einstellungen, Dateien lesen und die Shell-Sitzungen aus terminal.py."""
    TERM_PROGRAM = "seiffert-terminal"
    MAX_TERMS = 30

    def __init__(self, emit=None) -> None:
        self.emit = emit or (lambda name, data: None)
        self.settings = T.load()
        self.args: dict = {}
        self.on_settings = None              # wird vom Fenster gesetzt: Deckkraft, immer im Vordergrund …
        self._set_lock = threading.RLock()

    def call(self, method: str, args: dict | None, cid: int = 0):
        fn = getattr(self, "api_" + method, None)
        if fn is None or method.startswith("_"):
            raise AppError("Unbekannte Funktion: " + method)
        return fn(**(args or {}))

    def shutdown(self) -> None:
        self._term_close_all()

    # ---- Einstellungen
    def _payload(self) -> dict:
        return {"settings": self.settings, "resolved": T.resolve(self.settings)}

    def api_settings_get(self) -> dict:
        out = self._payload()
        out.update(themes=T.theme_list(), syntax_labels=T.SYNTAX_LABELS, ansi_names=list(T.ANSI_NAMES), syntax_keys=list(T.SYNTAX_KEYS),
                   key_actions={a: v[0] for a, v in T.KEY_ACTIONS.items()}, version=T.VERSION, args=self.args,
                   theme_resolved={k: T.resolve(self.settings, k) for k in T.THEMES},
                   default_family=T.FONT_DEFAULT, home=os.path.expanduser("~"))
        return out

    def _apply(self, new: dict) -> dict:
        old = self.settings
        self.settings = new
        T.save(new)
        if self.on_settings:
            self.on_settings(old, new)
        return self._payload()

    def api_settings_set(self, patch: dict) -> dict:
        with self._set_lock:
            return self._apply(T.clean(patch, self.settings))

    def api_settings_reset(self, group: str = "") -> dict:
        with self._set_lock:
            return self._settings_reset(group)

    def _settings_reset(self, group: str) -> dict:
        if not group:
            return self._apply(T.clean({}, None))
        if group not in T.DEFAULTS or group == "theme":
            raise AppError("Diese Gruppe gibt es nicht: %s" % group)
        if group in ("colors", "syntax", "rules", "profiles", "keys") or isinstance(T.DEFAULTS[group], dict):
            fresh = json.loads(json.dumps(T.DEFAULTS[group]))
            return self._apply(T.clean({group: fresh}, self.settings))
        raise AppError("Diese Gruppe lässt sich nicht einzeln zurücksetzen: %s" % group)

    def api_settings_export(self, path: str) -> dict:
        if not path:
            raise AppError("Kein Dateiname angegeben.")
        p = os.path.abspath(os.path.expanduser(path))
        try:
            with open(p, "w", encoding="utf-8") as f:
                f.write(T.export_text(self.settings) + "\n")
        except OSError as e:
            raise AppError("Die Datei konnte nicht geschrieben werden: %s" % (e.strerror or e))
        return {"path": p}

    def api_settings_import(self, path: str) -> dict:
        p = os.path.abspath(os.path.expanduser(path or ""))
        try:
            with open(p, encoding="utf-8") as f:
                text = f.read(2_000_000)
        except (OSError, UnicodeDecodeError) as e:
            raise AppError("Die Datei konnte nicht gelesen werden: %s" % (getattr(e, "strerror", None) or e))
        with self._set_lock:
            return self._apply(T.import_text(text, self.settings))

    # ---- Dateien
    def api_read_file(self, path: str) -> dict:
        """Text einer Datei für die farbige Ansicht (höchstens 3 MB; Binärdateien werden abgelehnt)."""
        p = os.path.abspath(os.path.expanduser(path or ""))
        if not os.path.isfile(p):
            raise AppError("Die Datei gibt es nicht: %s" % p)
        try:
            with open(p, "rb") as f:
                data = f.read(MAX_VIEW_BYTES + 1)
        except OSError as e:
            raise AppError("Die Datei konnte nicht gelesen werden: %s" % (e.strerror or e))
        truncated = len(data) > MAX_VIEW_BYTES
        data = data[:MAX_VIEW_BYTES]
        if b"\x00" in data[:8192]:
            raise AppError("%s sieht nach einer Binärdatei aus, nicht nach Text." % os.path.basename(p))
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError:
            text = data.decode("cp1252", "replace")
        return {"path": p, "name": os.path.basename(p), "text": text, "truncated": truncated}

    def api_which(self, command: str) -> bool:
        c = (command or "").strip()
        return bool(c) and bool(os.path.isabs(c) and os.access(c, os.X_OK) or shutil.which(os.path.expanduser(c)))


class Bridge(QObject):
    """Verbindung zwischen der Oberfläche (JavaScript) und dem Python-Backend."""

    done = Signal(int, str)
    event = Signal(str, str)

    def __init__(self, host: Host, window: "TermWindow") -> None:
        super().__init__(window)
        self.host = host
        self.window = window
        self.pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="st")
        host.emit = lambda name, data: self.event.emit(name, json.dumps(data, default=str))

    def _run(self, cid: int, method: str, args: dict) -> None:
        try:
            res = {"result": self.host.call(method, args, cid)}
        except AppError as e:
            res = {"error": str(e)}
        except Exception as e:  # noqa: BLE001 - die Oberfläche bekommt immer eine Antwort
            res = {"error": "Interner Fehler: %s: %s" % (type(e).__name__, e)}
        self.done.emit(cid, json.dumps(res, default=str))

    @Slot(int, str, str)
    def invoke(self, cid: int, method: str, args_json: str) -> None:
        try:
            args = json.loads(args_json) if args_json else {}
        except ValueError:
            args = {}
        try:
            self.pool.submit(self._run, cid, method, args)
        except RuntimeError:
            pass

    @Slot(int)
    def cancel(self, cid: int) -> None:
        pass

    @Slot(result=str)
    def startup(self) -> str:
        return json.dumps(self.host.args)

    @Slot(str, result=str)
    def pick_image(self, start: str) -> str:
        start = start if os.path.isdir(start or "") else os.path.dirname(start or "") or os.path.expanduser("~")
        return QFileDialog.getOpenFileName(self.window, "Bild wählen", start,
                                           "Bilder (*.png *.jpg *.jpeg *.gif *.webp *.bmp *.avif *.svg);;Alle Dateien (*)")[0] or ""

    @Slot(str, result=str)
    def pick_file(self, start: str) -> str:
        start = start if os.path.isdir(start or "") else os.path.dirname(start or "") or os.path.expanduser("~")
        return QFileDialog.getOpenFileName(self.window, "Datei wählen", start)[0] or ""

    @Slot(str, str, result=str)
    def pick_save(self, start: str, name: str) -> str:
        d = start if os.path.isdir(start or "") else os.path.expanduser("~")
        return QFileDialog.getSaveFileName(self.window, "Speichern unter", os.path.join(d, name or "datei.json"))[0] or ""

    @Slot(str, result=str)
    def pick_dir(self, start: str) -> str:
        return QFileDialog.getExistingDirectory(self.window, "Ordner wählen", start or os.path.expanduser("~")) or ""

    @Slot(str, result=bool)
    def copy_text(self, text: str) -> bool:
        QGuiApplication.clipboard().setText(text)
        return True

    @Slot(result=str)
    def clip_text(self) -> str:
        return QGuiApplication.clipboard().text() or ""

    @Slot(result=bool)
    def toggle_fullscreen(self) -> bool:
        return self.window.toggle_fullscreen()

    @Slot(result=bool)
    def is_fullscreen(self) -> bool:
        return self.window.isFullScreen()

    @Slot(result=bool)
    def window_translucent(self) -> bool:
        return self.window.translucent

    @Slot(result=bool)
    def quit_app(self) -> bool:
        QTimer.singleShot(0, self.window.close)
        return True

    @Slot(result=bool)
    def restart_app(self) -> bool:
        QTimer.singleShot(50, self.window.restart)
        return True

    @Slot(str, result=bool)
    def new_window(self, cwd: str) -> bool:
        args = [os.path.abspath(__file__)]
        if cwd and os.path.isdir(cwd):
            args += ["-d", cwd]
        return QProcess.startDetached(sys.executable, args)

    @Slot(str, result=bool)
    def open_url(self, url: str) -> bool:
        u = QUrl(url)
        if u.scheme() not in ("http", "https", "mailto", "ftp"):
            return False
        return QDesktopServices.openUrl(u)

    @Slot()
    def bell(self) -> None:
        QApplication.beep()

    @Slot(result=str)
    def fonts(self) -> str:
        try:
            fams = [f for f in QFontDatabase.families() if QFontDatabase.isFixedPitch(f)]
        except Exception:  # noqa: BLE001
            fams = []
        return json.dumps(sorted(set(fams), key=str.lower))


class Page(QWebEnginePage):
    def __init__(self, profile: QWebEngineProfile, parent) -> None:
        super().__init__(profile, parent)
        self.debug = bool(os.environ.get("ST_DEBUG"))

    def acceptNavigationRequest(self, url: QUrl, nav_type, is_main_frame: bool) -> bool:
        if url.isLocalFile() and os.path.abspath(url.toLocalFile()) == INDEX_HTML:
            return True
        if url.scheme() in ("http", "https", "mailto"):
            QDesktopServices.openUrl(url)
        return False

    def createWindow(self, _type):
        return None

    def javaScriptConsoleMessage(self, level, message, line, source):
        if self.debug or "Error" in message:
            sys.stderr.write("[js] %s (%s:%s)\n" % (message, os.path.basename(source or ""), line))


class TermWindow(QMainWindow):
    settings_changed = Signal(object, object)           # kommt aus einem Arbeitsthread, wird im Oberflächenthread bearbeitet

    def __init__(self, host: Host) -> None:
        super().__init__()
        self.host = host
        self._restarting = False
        st = host.settings
        w = st["window"]
        self.setWindowTitle(APP_NAME)
        icon = QIcon()
        for n in (16, 22, 24, 32, 48, 64, 128, 256):
            f = os.path.join(HERE, "icons", "seiffert-terminal-%d.png" % n)
            if os.path.exists(f):
                icon.addFile(f)
        if not icon.isNull():
            self.setWindowIcon(icon)
        self.resize(w["width"], w["height"])
        self._state = T.load_state()
        if w["remember_geometry"] and self._state.get("geometry"):
            try:
                self.restoreGeometry(QByteArray(base64.b64decode(self._state["geometry"])))
            except Exception:  # noqa: BLE001
                pass
        if w["on_top"]:
            self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, True)
        self.translucent = bool(w["translucent"])
        if self.translucent:
            self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setWindowOpacity(max(0.35, min(1.0, w["opacity"] / 100)))
        self.profile = QWebEngineProfile(self)           # ohne Namen: nichts wird auf der Platte zwischengespeichert
        self.view = QWebEngineView(self)
        self.page = Page(self.profile, self.view)
        self.view.setPage(self.page)
        res = T.resolve(st)
        if self.translucent:
            self.page.setBackgroundColor(QColor(0, 0, 0, 0))
            self.view.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
            self.view.setStyleSheet("background: transparent")
        else:
            self.page.setBackgroundColor(QColor(res["colors"]["background"]))
        s = self.page.settings()
        s.setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessRemoteUrls, False)
        s.setAttribute(QWebEngineSettings.WebAttribute.PluginsEnabled, False)
        self.bridge = Bridge(host, self)
        self.channel = QWebChannel(self.page)
        self.channel.registerObject("bridge", self.bridge)
        self.page.setWebChannel(self.channel)
        self.view.titleChanged.connect(lambda t: self.setWindowTitle(t or APP_NAME))
        self.setCentralWidget(self.view)
        self.view.load(QUrl.fromLocalFile(INDEX_HTML))
        self.settings_changed.connect(self._settings_changed)
        host.on_settings = lambda old, new: self.settings_changed.emit(old, new)

    def _settings_changed(self, old: dict, new: dict) -> None:
        self._apply_window(new["window"], old["window"])

    def _apply_window(self, w: dict, old: dict) -> None:
        self.setWindowOpacity(max(0.35, min(1.0, w["opacity"] / 100)))
        if w["on_top"] != old["on_top"]:
            fs = self.isFullScreen()
            self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, bool(w["on_top"]))
            self.showFullScreen() if fs else self.show()

    def toggle_fullscreen(self) -> bool:
        if self.isFullScreen():
            self.showMaximized() if getattr(self, "_max_before_full", False) else self.showNormal()
        else:
            self._max_before_full = self.isMaximized()
            self.showFullScreen()
        return self.isFullScreen()

    def restart(self) -> None:
        """Neustart (nötig, damit sich das durchscheinende Fenster umschalten lässt)."""
        self._save_geometry()
        self.host.shutdown()
        QProcess.startDetached(sys.executable, [os.path.abspath(__file__)])
        self._restarting = True
        QApplication.instance().quit()

    def _save_geometry(self) -> None:
        if self.host.settings["window"]["remember_geometry"] and not self.isFullScreen():
            try:
                self._state["geometry"] = base64.b64encode(bytes(self.saveGeometry())).decode()
                T.save_state(self._state)
            except Exception:  # noqa: BLE001
                pass

    def running_programs(self) -> list:
        """Sitzungen, in denen gerade ein anderes Programm als die Shell läuft."""
        out = []
        for tid in list(getattr(self.host, "_terms", {})):
            try:
                s = self.host.api_term_state(tid)
            except Exception:  # noqa: BLE001
                continue
            if s["alive"] and not s["idle"]:
                out.append(tid)
        return out

    def alive_terminals(self) -> int:
        n = 0
        for tid in list(getattr(self.host, "_terms", {})):
            try:
                n += 1 if self.host.api_term_state(tid)["alive"] else 0
            except Exception:  # noqa: BLE001
                pass
        return n

    def closeEvent(self, ev) -> None:  # noqa: N802
        mode = self.host.settings["window"]["confirm_close"]
        if not self._restarting and mode != "nie":
            n = len(self.running_programs()) if mode == "laufend" else self.alive_terminals()
            if n:
                box = QMessageBox(QMessageBox.Icon.Question, APP_NAME,
                                  ("In %d Reiter läuft noch ein Programm." % n) if n == 1 and mode == "laufend" else
                                  ("In %d Reitern laufen noch Programme." % n) if mode == "laufend" else
                                  ("%d Reiter sind noch geöffnet." % n),
                                  QMessageBox.StandardButton.NoButton, self)
                box.setInformativeText("Beim Schließen werden sie beendet.")
                close = box.addButton("Schließen", QMessageBox.ButtonRole.DestructiveRole)
                box.addButton("Abbrechen", QMessageBox.ButtonRole.RejectRole)
                box.exec()
                if box.clickedButton() is not close:
                    ev.ignore()
                    return
        self._save_geometry()
        self.host.shutdown()
        super().closeEvent(ev)


def main(argv: list) -> int:
    args = parse_args(argv[1:])
    if "error" in args:
        sys.stderr.write("seiffert-terminal: %s\n" % args["error"])
        return 2
    if args["help"]:
        sys.stdout.write(HELP)
        return 0
    app = QApplication([argv[0]])
    app.setApplicationName(APP_NAME)
    app.setDesktopFileName("seiffert-terminal")
    app.setWindowIcon(QIcon(os.path.join(HERE, "icons", "seiffert-terminal-256.png")))
    host = Host()
    host.args = args
    win = TermWindow(host)
    start = host.settings["window"]["start"]
    if args["fullscreen"] or start == "vollbild":
        win.showFullScreen()
    elif start == "maximiert":
        win.showMaximized()
    else:
        win.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main(sys.argv))
