"""Dateiverwaltung für Seifferts Dateien: Kopieren, Verschieben, Papierkorb, Archive,
Eigenschaften, Massenumbenennung und Rückgängig. Wird als Mischklasse in Backend eingebunden."""
from __future__ import annotations

import errno
import grp
import json
import mimetypes
import os
import pwd
import re
import shlex
import shutil
import stat
import subprocess
import tarfile
import threading
import time
import unicodedata
import urllib.parse
import zipfile
from pathlib import Path

import backend as B

AppError = B.AppError
TAR_EXTS = (".tar.gz", ".tar.xz", ".tar.bz2", ".tar.zst", ".tar.lz", ".tar")
CHUNK = 1024 * 1024
UNDO_MAX = 50


def split_ext(name: str) -> tuple[str, str]:
    """'a.tar.gz' -> ('a', '.tar.gz'), '.bashrc' -> ('.bashrc', '')."""
    low = name.lower()
    for t in TAR_EXTS:
        if low.endswith(t) and len(name) > len(t):
            return name[: -len(t)], name[-len(t):]
    stem, ext = os.path.splitext(name)
    if not stem:
        return name, ""
    return stem, ext


def natural_key(s: str):
    return [int(t) if t.isdigit() else B.fold(t) for t in re.split(r"(\d+)", s)]


def _forbidden(p: str) -> bool:
    home = str(Path.home())
    return p == "/" or p == home or home.startswith(p.rstrip("/") + "/")


class FileOps:
    # ------------------------------------------------------------ Grundlagen
    def _fo_init(self) -> None:
        if getattr(self, "_fo_ready", False):
            return
        self._fo_ready = True
        self._undo: list[dict] = []
        self._undo_lock = threading.Lock()

    def _push_undo(self, rec: dict) -> None:
        self._fo_init()
        with self._undo_lock:
            self._undo.append(rec)
            del self._undo[:-UNDO_MAX]

    def api_undo_info(self) -> dict:
        self._fo_init()
        with self._undo_lock:
            return {"desc": self._undo[-1]["desc"] if self._undo else None, "count": len(self._undo)}

    def _job(self, jid: int, **kw) -> None:
        if jid:
            self.emit("job", {"id": jid, **kw})

    @staticmethod
    def _need_dir(p: str) -> str:
        p = B.norm_path(p)
        if not os.path.isdir(p):
            raise AppError("Der Zielordner existiert nicht: " + p)
        if not os.access(p, os.W_OK | os.X_OK):
            raise AppError("Im Zielordner darf nichts geändert werden: " + p)
        return p

    def _sources(self, sources: list[str]) -> list[str]:
        if not isinstance(sources, list) or not sources:
            raise AppError("Nichts ausgewählt.")
        out = []
        for s in sources:
            p = B.norm_path(s)
            if not os.path.lexists(p):
                raise AppError("Existiert nicht mehr: " + os.path.basename(p))
            out.append(p)
        return list(dict.fromkeys(out))

    @staticmethod
    def _inside(dest: str, src: str) -> bool:
        a, b = os.path.realpath(dest), os.path.realpath(src)
        return a == b or a.startswith(b.rstrip("/") + "/")

    # ------------------------------------------------------------ Kopieren und Verschieben
    def api_paste_check(self, sources: list[str], dest: str, op: str = "copy") -> dict:
        dest = self._need_dir(dest)
        srcs = self._sources(sources)
        conflicts, same = [], []
        for s in srcs:
            name = os.path.basename(s)
            tgt = os.path.join(dest, name)
            if os.path.isdir(s) and not os.path.islink(s) and self._inside(dest, s):
                raise AppError("Ein Ordner kann nicht in sich selbst verschoben oder kopiert werden: " + name)
            if op == "move" and os.path.dirname(s) == dest:
                same.append(name)
            elif op == "copy" and os.path.dirname(s) == dest:
                same.append(name)       # wird als Kopie mit neuem Namen angelegt
            elif os.path.lexists(tgt):
                conflicts.append({"name": name, "dir": os.path.isdir(s), "target_dir": os.path.isdir(tgt)})
        return {"conflicts": conflicts, "same": same, "count": len(srcs)}

    def _total_size(self, srcs: list[str]) -> int:
        total = 0
        for s in srcs:
            if os.path.isdir(s) and not os.path.islink(s):
                for root, dirs, files in os.walk(s):
                    if self._cancelled():
                        return total
                    for f in files:
                        try:
                            total += os.lstat(os.path.join(root, f)).st_size
                        except OSError:
                            pass
            else:
                try:
                    total += os.lstat(s).st_size
                except OSError:
                    pass
        return total

    class _Prog:
        def __init__(self, fo, jid: int, total: int, count: int):
            self.fo, self.jid, self.total, self.count = fo, jid, total, count
            self.done, self.n, self.name, self.t = 0, 0, "", 0.0

        def add(self, n: int) -> None:
            self.done += n
            now = time.monotonic()
            if now - self.t > 0.1:
                self.t = now
                self.fo._job(self.jid, state="run", done=self.done, total=self.total, name=self.name, n=self.n, count=self.count)

    def _copy_file(self, src: str, dst: str, prog, replace: bool) -> None:
        tmp = dst + ".sd-teil"
        try:
            with open(src, "rb") as fi, open(tmp, "wb") as fo:
                while True:
                    if self._cancelled():
                        raise InterruptedError
                    buf = fi.read(CHUNK)
                    if not buf:
                        break
                    fo.write(buf)
                    prog.add(len(buf))
            try:
                shutil.copystat(src, tmp)
            except OSError:
                pass
            os.replace(tmp, dst)
        except BaseException:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise

    def _copy_tree(self, src: str, dst: str, prog, policy: str, errors: list, replaced: list) -> None:
        if os.path.islink(src):
            if os.path.lexists(dst):
                if policy == "skip":
                    return
                if os.path.isdir(dst) and not os.path.islink(dst):
                    shutil.rmtree(dst)
                else:
                    os.unlink(dst)
                replaced.append(dst)
            os.symlink(os.readlink(src), dst)
            return
        if os.path.isdir(src):
            if os.path.lexists(dst) and not os.path.isdir(dst):
                if policy == "skip":
                    return
                os.unlink(dst)
                replaced.append(dst)
            os.makedirs(dst, exist_ok=True)
            for de in sorted(os.scandir(src), key=lambda d: d.name):
                if self._cancelled():
                    raise InterruptedError
                try:
                    self._copy_tree(de.path, os.path.join(dst, de.name), prog, policy, errors, replaced)
                except InterruptedError:
                    raise
                except OSError as e:
                    errors.append({"name": de.name, "error": e.strerror or str(e)})
            try:
                shutil.copystat(src, dst)
            except OSError:
                pass
            return
        st = os.lstat(src)
        if not stat.S_ISREG(st.st_mode):
            errors.append({"name": os.path.basename(src), "error": "Sonderdatei (Gerät, Pipe oder Socket) wird übersprungen."})
            return
        if os.path.lexists(dst):
            if policy == "skip":
                return
            replaced.append(dst)
            if os.path.isdir(dst) and not os.path.islink(dst):
                shutil.rmtree(dst)
        prog.name = os.path.basename(src)
        self._copy_file(src, dst, prog, True)

    def _remove_any(self, p: str) -> None:
        if os.path.isdir(p) and not os.path.islink(p):
            shutil.rmtree(p)
        else:
            os.unlink(p)

    def api_file_op(self, op: str, sources: list[str], dest: str, policy: str = "rename", jid: int = 0) -> dict:
        if op not in ("copy", "move"):
            raise AppError("Unbekannte Operation.")
        if policy not in ("rename", "replace", "skip"):
            raise AppError("Unbekannte Konfliktregel.")
        self._fo_init()
        dest = self._need_dir(dest)
        srcs = self._sources(sources)
        if op == "move":
            for s in srcs:
                if _forbidden(s):
                    raise AppError("Dieser Ordner darf nicht verschoben werden: " + s)
        total = self._total_size(srcs)
        prog = self._Prog(self, jid, total, len(srcs))
        done, skipped, errors, replaced = [], [], [], []
        cancelled = False
        for i, s in enumerate(srcs):
            if self._cancelled():
                cancelled = True
                break
            name = os.path.basename(s)
            prog.n, prog.name = i + 1, name
            tgt = os.path.join(dest, name)
            same_dir = os.path.dirname(s) == dest
            if os.path.isdir(s) and not os.path.islink(s) and self._inside(dest, s):
                errors.append({"name": name, "error": "Ein Ordner kann nicht in sich selbst liegen."})
                continue
            if same_dir and op == "move":
                skipped.append(name)
                continue
            pol = policy
            if same_dir or (os.path.lexists(tgt) and policy == "rename"):
                stem, ext = split_ext(name)
                if os.path.isdir(s) and not os.path.islink(s):
                    stem, ext = name, ""
                tgt = B.unique_path(dest, stem, ext)
                pol = "replace"                        # Ziel ist neu, es gibt nichts zu ersetzen
            elif os.path.lexists(tgt) and policy == "skip":
                skipped.append(name)
                continue
            existed = os.path.lexists(tgt)
            try:
                if op == "move":
                    self._move_one(s, tgt, prog, pol, errors, replaced)
                else:
                    self._copy_tree(s, tgt, prog, pol, errors, replaced)
                done.append({"src": s, "dst": tgt, "existed": existed})
            except InterruptedError:
                cancelled = True
                if op == "copy" and not existed:
                    try:
                        self._remove_any(tgt)
                    except OSError:
                        pass
                break
            except OSError as e:
                errors.append({"name": name, "error": e.strerror or str(e)})
        self._job(jid, state="done", done=prog.done, total=prog.total)
        replaced_any = bool(replaced) or any(d["existed"] for d in done)
        if done:
            if op == "copy":
                if not replaced_any:
                    self._push_undo({"kind": "copy", "created": [d["dst"] for d in done],
                                     "desc": "Kopieren (%d)" % len(done) if len(done) > 1 else "Kopieren: " + os.path.basename(done[0]["dst"])})
            else:
                if not replaced_any:
                    self._push_undo({"kind": "move", "pairs": [(d["dst"], d["src"]) for d in done],
                                     "desc": "Verschieben (%d)" % len(done) if len(done) > 1 else "Verschieben: " + os.path.basename(done[0]["dst"])})
        return {"done": done, "skipped": skipped, "errors": errors, "cancelled": cancelled, "undo": bool(done) and not replaced_any}

    def _move_one(self, src: str, dst: str, prog, policy: str, errors: list, replaced: list) -> None:
        if os.path.lexists(dst):
            if policy == "skip":
                return
            if os.path.isdir(src) and not os.path.islink(src) and os.path.isdir(dst) and not os.path.islink(dst):
                # Ordner zusammenführen
                self._copy_tree(src, dst, prog, "replace", errors, replaced)
                if not errors:
                    shutil.rmtree(src)
                return
            replaced.append(dst)
        try:
            if os.path.lexists(dst) and not os.path.isdir(dst):
                os.replace(src, dst)
            else:
                os.rename(src, dst)
            prog.add(self._size_quick(dst))
            return
        except OSError as e:
            if e.errno != errno.EXDEV:
                raise
        # anderes Laufwerk: kopieren, dann Original löschen
        errs: list = []
        self._copy_tree(src, dst, prog, "replace", errs, replaced)
        if errs:
            errors.extend(errs)
            return
        self._remove_any(src)

    @staticmethod
    def _size_quick(p: str) -> int:
        try:
            return os.lstat(p).st_size if not os.path.isdir(p) else 0
        except OSError:
            return 0

    # ------------------------------------------------------------ Neu anlegen
    def api_new_file(self, parent: str, name: str, content: str = "") -> str:
        self._fo_init()
        parent = self._need_dir(parent)
        name = B.check_name(name)
        p = os.path.join(parent, name)
        if os.path.lexists(p):
            raise AppError("Es gibt hier schon etwas mit diesem Namen.")
        try:
            with open(p, "x", encoding="utf-8") as f:
                f.write(content or "")
        except OSError as e:
            raise AppError("Datei konnte nicht angelegt werden: " + (e.strerror or str(e)))
        self._push_undo({"kind": "created", "created": [p], "desc": "Neue Datei: " + name})
        return p

    def api_make_symlink(self, target: str, parent: str, name: str = "") -> str:
        self._fo_init()
        target = B.norm_path(target)
        parent = self._need_dir(parent)
        base = B.check_name(name) if name else "Verweis auf " + os.path.basename(target.rstrip("/"))
        p = B.unique_path(parent, base)
        try:
            os.symlink(target, p)
        except OSError as e:
            raise AppError("Verweis konnte nicht angelegt werden: " + (e.strerror or str(e)))
        self._push_undo({"kind": "created", "created": [p], "desc": "Verweis: " + os.path.basename(p)})
        return p

    # ------------------------------------------------------------ Löschen und Papierkorb
    def api_delete(self, paths: list[str]) -> dict:
        srcs = self._sources(paths)
        for s in srcs:
            if _forbidden(s):
                raise AppError("Dieser Ordner darf nicht gelöscht werden: " + s)
        errors = []
        n = 0
        for s in srcs:
            try:
                self._remove_any(s)
                n += 1
            except OSError as e:
                errors.append({"name": os.path.basename(s), "error": e.strerror or str(e)})
        return {"deleted": n, "errors": errors}

    @staticmethod
    def _trash_base() -> Path:
        return Path(os.environ.get("XDG_DATA_HOME") or (Path.home() / ".local" / "share")) / "Trash"

    def _trash_items(self) -> list[dict]:
        base = self._trash_base()
        out = []
        info_dir = base / "info"
        if not info_dir.is_dir():
            return out
        for f in info_dir.iterdir():
            if f.suffix != ".trashinfo":
                continue
            stem = f.name[: -len(".trashinfo")]
            orig, date = "", ""
            try:
                for line in f.read_text(encoding="utf-8", errors="replace").splitlines():
                    if line.startswith("Path="):
                        orig = urllib.parse.unquote(line[5:].strip())
                    elif line.startswith("DeletionDate="):
                        date = line[13:].strip()
            except OSError:
                continue
            tf = base / "files" / stem
            if not os.path.lexists(tf):
                continue
            try:
                st = os.lstat(tf)
            except OSError:
                continue
            out.append({"id": stem, "name": os.path.basename(orig) or stem, "orig": orig, "date": date,
                        "dir": os.path.isdir(tf) and not os.path.islink(tf), "size": 0 if stat.S_ISDIR(st.st_mode) else st.st_size})
        out.sort(key=lambda x: x["date"], reverse=True)
        return out

    def api_trash_many(self, paths: list[str]) -> dict:
        self._fo_init()
        srcs = self._sources(paths)
        for s in srcs:
            if _forbidden(s):
                raise AppError("Dieser Ordner darf nicht gelöscht werden: " + s)
        done, errors = [], []
        for s in srcs:
            try:
                self._trash_path(s)
                done.append(s)
            except AppError as e:
                errors.append({"name": os.path.basename(s), "error": str(e)})
        if done:
            self._push_undo({"kind": "trash", "paths": done, "desc": "Papierkorb: " + os.path.basename(done[0]) if len(done) == 1 else "Papierkorb (%d)" % len(done)})
        return {"trashed": len(done), "errors": errors}

    def api_trash_list(self) -> dict:
        return {"items": self._trash_items()}

    def _trash_restore_id(self, tid: str) -> str:
        base = self._trash_base()
        info = base / "info" / (tid + ".trashinfo")
        src = base / "files" / tid
        orig = ""
        try:
            for line in info.read_text(encoding="utf-8", errors="replace").splitlines():
                if line.startswith("Path="):
                    orig = urllib.parse.unquote(line[5:].strip())
        except OSError:
            raise AppError("Eintrag nicht mehr im Papierkorb.")
        if not orig or not os.path.lexists(src):
            raise AppError("Eintrag nicht mehr im Papierkorb.")
        orig = os.path.abspath(orig)
        os.makedirs(os.path.dirname(orig), exist_ok=True)
        tgt = orig
        if os.path.lexists(tgt):
            stem, ext = split_ext(os.path.basename(orig))
            if os.path.isdir(src):
                stem, ext = os.path.basename(orig), ""
            tgt = B.unique_path(os.path.dirname(orig), stem, ext)
        shutil.move(str(src), tgt)
        try:
            info.unlink()
        except OSError:
            pass
        return tgt

    def api_trash_restore(self, ids: list[str]) -> dict:
        res, errs = [], []
        for t in ids:
            try:
                res.append(self._trash_restore_id(os.path.basename(t)))
            except (AppError, OSError) as e:
                errs.append(str(e))
        return {"restored": res, "errors": errs}

    def api_trash_delete(self, ids: list[str]) -> dict:
        base = self._trash_base()
        n = 0
        for t in ids:
            t = os.path.basename(t)
            try:
                f = base / "files" / t
                if os.path.lexists(f):
                    self._remove_any(str(f))
                (base / "info" / (t + ".trashinfo")).unlink(missing_ok=True)
                n += 1
            except OSError:
                pass
        return {"deleted": n}

    def api_trash_empty(self) -> dict:
        return self.api_trash_delete([i["id"] for i in self._trash_items()])

    def _trash_find_latest(self, orig: str) -> str | None:
        for it in self._trash_items():            # nach Datum absteigend sortiert
            if os.path.abspath(it["orig"]) == orig:
                return it["id"]
        return None

    # ------------------------------------------------------------ Rückgängig
    def api_undo(self) -> dict:
        self._fo_init()
        with self._undo_lock:
            if not self._undo:
                raise AppError("Es gibt nichts zum Rückgängigmachen.")
            rec = self._undo.pop()
        kind = rec["kind"]
        touched: list[str] = []
        try:
            if kind in ("copy", "created"):
                for p in rec["created"]:
                    if os.path.lexists(p):
                        self._trash_path(p)
                        touched.append(os.path.dirname(p))
            elif kind in ("move", "rename"):
                for cur, old in rec["pairs"]:
                    if not os.path.lexists(cur):
                        raise AppError("Nicht möglich: „%s“ ist nicht mehr da." % os.path.basename(cur))
                    if os.path.lexists(old):
                        raise AppError("Nicht möglich: am alten Ort gibt es schon „%s“." % os.path.basename(old))
                for cur, old in rec["pairs"]:
                    os.makedirs(os.path.dirname(old), exist_ok=True)
                    try:
                        os.rename(cur, old)
                    except OSError as e:
                        if e.errno != errno.EXDEV:
                            raise
                        errs: list = []
                        self._copy_tree(cur, old, self._Prog(self, 0, 0, 1), "replace", errs, [])
                        if errs:
                            raise AppError("Zurückkopieren fehlgeschlagen.")
                        self._remove_any(cur)
                    touched += [os.path.dirname(cur), os.path.dirname(old)]
            elif kind == "trash":
                for orig in rec["paths"]:
                    tid = self._trash_find_latest(orig)
                    if not tid:
                        raise AppError("„%s“ ist nicht mehr im Papierkorb." % os.path.basename(orig))
                    self._trash_restore_id(tid)
                    touched.append(os.path.dirname(orig))
            else:
                raise AppError("Unbekannter Eintrag.")
        except (AppError, OSError) as e:
            with self._undo_lock:
                self._undo.append(rec)            # bleibt erhalten, falls es später doch geht
            raise AppError(str(e) if isinstance(e, AppError) else "Rückgängig nicht möglich: " + (e.strerror or str(e)))
        return {"desc": rec["desc"], "touched": sorted(set(touched))}

    # ------------------------------------------------------------ Archive
    def api_archive(self, sources: list[str], dest: str, name: str, fmt: str = "zip", jid: int = 0) -> dict:
        self._fo_init()
        dest = self._need_dir(dest)
        srcs = self._sources(sources)
        if fmt not in ("zip", "tar", "tar.gz", "tar.xz", "tar.bz2"):
            raise AppError("Unbekanntes Archivformat.")
        name = B.check_name(name)
        ext = "." + fmt
        if not name.lower().endswith(ext):
            name += ext
        out = B.unique_path(dest, name[: -len(ext)], ext) if os.path.lexists(os.path.join(dest, name)) else os.path.join(dest, name)
        total = self._total_size(srcs)
        prog = self._Prog(self, jid, total, len(srcs))
        tmp = out + ".sd-teil"
        files: list[tuple[str, str]] = []
        for s in srcs:
            base = os.path.dirname(s)
            if os.path.isdir(s) and not os.path.islink(s):
                files.append((s, os.path.relpath(s, base)))
                for root, dirs, fs in os.walk(s):
                    dirs.sort()
                    for d in dirs:
                        files.append((os.path.join(root, d), os.path.relpath(os.path.join(root, d), base)))
                    for f in sorted(fs):
                        files.append((os.path.join(root, f), os.path.relpath(os.path.join(root, f), base)))
            else:
                files.append((s, os.path.basename(s)))
        try:
            if fmt == "zip":
                with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
                    for p, arc in files:
                        if self._cancelled():
                            raise InterruptedError
                        prog.name = os.path.basename(p)
                        try:
                            if os.path.isdir(p) and not os.path.islink(p):
                                zf.write(p, arc + "/")
                            else:
                                zf.write(p, arc)
                                prog.add(os.lstat(p).st_size)
                        except OSError:
                            continue
            else:
                mode = {"tar": "w", "tar.gz": "w:gz", "tar.xz": "w:xz", "tar.bz2": "w:bz2"}[fmt]
                with tarfile.open(tmp, mode) as tf:
                    for p, arc in files:
                        if self._cancelled():
                            raise InterruptedError
                        prog.name = os.path.basename(p)
                        try:
                            tf.add(p, arc, recursive=False)
                            if not os.path.isdir(p):
                                prog.add(os.lstat(p).st_size)
                        except OSError:
                            continue
            os.replace(tmp, out)
        except InterruptedError:
            self._job(jid, state="done")
            try:
                os.unlink(tmp)
            except OSError:
                pass
            return {"path": None, "cancelled": True}
        except BaseException:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise
        self._job(jid, state="done")
        self._push_undo({"kind": "created", "created": [out], "desc": "Archiv: " + os.path.basename(out)})
        return {"path": out, "cancelled": False}

    def api_extract(self, path: str, dest: str = "", subfolder: bool = True, jid: int = 0) -> dict:
        self._fo_init()
        p = B.norm_path(path)
        if not os.path.isfile(p):
            raise AppError("Das Archiv existiert nicht mehr.")
        d = self._need_dir(dest or os.path.dirname(p))
        stem, ext = split_ext(os.path.basename(p))
        target = d
        if subfolder:
            target = B.unique_path(d, stem)
            os.makedirs(target)
        created = [target] if subfolder else []
        low = p.lower()
        try:
            if low.endswith(".zip") or (zipfile.is_zipfile(p) and not low.endswith(TAR_EXTS)):
                self._extract_zip(p, target, jid)
            elif tarfile.is_tarfile(p) and not low.endswith((".zst", ".lz")):
                self._extract_tar(p, target, jid)
            else:
                tool = shutil.which("bsdtar")
                if not tool:
                    raise AppError("Dieses Format kann ohne das Programm bsdtar (Paket libarchive) nicht entpackt werden.")
                r = subprocess.run([tool, "-xf", p, "-C", target], capture_output=True, text=True, timeout=3600)
                if r.returncode != 0:
                    raise AppError("Entpacken fehlgeschlagen: " + (r.stderr.strip().splitlines() or ["unbekannter Fehler"])[-1])
        except InterruptedError:
            self._job(jid, state="done")
            if subfolder:
                shutil.rmtree(target, ignore_errors=True)
            return {"path": None, "cancelled": True}
        except BaseException:
            if subfolder:
                shutil.rmtree(target, ignore_errors=True)
            raise
        self._job(jid, state="done")
        if not subfolder:
            created = []                                # nicht eindeutig zu bestimmen, daher nicht rückgängig machbar
        else:
            self._push_undo({"kind": "created", "created": created, "desc": "Entpacken: " + stem})
        return {"path": target, "cancelled": False}

    def _extract_zip(self, p: str, target: str, jid: int) -> None:
        root = os.path.realpath(target)
        try:
            zf = zipfile.ZipFile(p)
        except zipfile.BadZipFile:
            raise AppError("Das ist kein gültiges ZIP-Archiv.")
        with zf:
            infos = zf.infolist()
            prog = self._Prog(self, jid, sum(i.file_size for i in infos), len(infos))
            for n, info in enumerate(infos):
                if self._cancelled():
                    raise InterruptedError
                dst = os.path.realpath(os.path.join(root, info.filename))
                if dst != root and not dst.startswith(root + os.sep):
                    raise AppError("Das Archiv enthält unzulässige Pfade und wird nicht entpackt.")
                prog.n, prog.name = n + 1, os.path.basename(info.filename.rstrip("/"))
                if info.is_dir():
                    os.makedirs(dst, exist_ok=True)
                    continue
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                with zf.open(info) as fi, open(dst, "wb") as fo:
                    while True:
                        if self._cancelled():
                            raise InterruptedError
                        buf = fi.read(CHUNK)
                        if not buf:
                            break
                        fo.write(buf)
                        prog.add(len(buf))
                mode = (info.external_attr >> 16) & 0o777
                if mode:
                    try:
                        os.chmod(dst, mode | 0o400)
                    except OSError:
                        pass

    def _extract_tar(self, p: str, target: str, jid: int) -> None:
        try:
            tf = tarfile.open(p)
        except (tarfile.TarError, OSError) as e:
            raise AppError("Archiv nicht lesbar: " + str(e))
        with tf:
            members = tf.getmembers()
            prog = self._Prog(self, jid, sum(m.size for m in members), len(members))
            for n, m in enumerate(members):
                if self._cancelled():
                    raise InterruptedError
                prog.n, prog.name = n + 1, os.path.basename(m.name)
                try:
                    tf.extract(m, target, filter="data")
                except (tarfile.FilterError, tarfile.TarError) as e:
                    raise AppError("Das Archiv enthält unzulässige Einträge und wird nicht entpackt: " + str(e))
                prog.add(m.size)

    # ------------------------------------------------------------ Eigenschaften
    @staticmethod
    def _perm_str(mode: int) -> dict:
        def tri(r, w, x):
            return ("r" if mode & r else "-") + ("w" if mode & w else "-") + ("x" if mode & x else "-")
        return {"user": tri(stat.S_IRUSR, stat.S_IWUSR, stat.S_IXUSR), "group": tri(stat.S_IRGRP, stat.S_IWGRP, stat.S_IXGRP),
                "other": tri(stat.S_IROTH, stat.S_IWOTH, stat.S_IXOTH)}

    def _mime_of(self, path: str) -> str:
        if os.path.isdir(path):
            return "inode/directory"
        ext = os.path.splitext(path)[1].lower()
        extra = {".md": "text/markdown", ".tex": "text/x-tex", ".bib": "text/x-bibtex", ".ged": "text/plain", ".log": "text/plain",
                 ".py": "text/x-python", ".sh": "application/x-shellscript", ".json": "application/json", ".csv": "text/csv",
                 ".yml": "application/yaml", ".yaml": "application/yaml", ".toml": "application/toml", ".desktop": "application/x-desktop"}
        if ext in extra:
            return extra[ext]
        m = mimetypes.guess_type(path)[0]
        if m:
            return m
        xm = shutil.which("xdg-mime")
        if xm:
            try:
                r = subprocess.run([xm, "query", "filetype", path], capture_output=True, text=True, timeout=5)
                if r.returncode == 0 and "/" in r.stdout:
                    return r.stdout.strip()
            except (OSError, subprocess.TimeoutExpired):
                pass
        try:
            with open(path, "rb") as f:
                head = f.read(2048)
            if head and b"\x00" not in head:
                head.decode("utf-8")
                return "text/plain"
        except (OSError, UnicodeDecodeError):
            pass
        return "application/octet-stream"

    def api_properties(self, paths: list[str]) -> dict:
        srcs = self._sources(paths)
        deadline = time.monotonic() + 20
        files = dirs = size = disk = 0
        partial = False

        def walk(p: str) -> None:
            nonlocal files, dirs, size, disk, partial
            try:
                st = os.lstat(p)
            except OSError:
                return
            disk += st.st_blocks * 512
            if stat.S_ISDIR(st.st_mode):
                dirs += 1
                try:
                    with os.scandir(p) as it:
                        for de in it:
                            if time.monotonic() > deadline or self._cancelled():
                                partial = True
                                return
                            walk(de.path)
                except OSError:
                    pass
            else:
                files += 1
                size += st.st_size

        for s in srcs:
            walk(s)
        top_dirs = sum(1 for s in srcs if os.path.isdir(s) and not os.path.islink(s))
        info = {"count": len(srcs), "files": files, "dirs": max(0, dirs - top_dirs), "size": size, "disk": disk, "partial": partial,
                "single": len(srcs) == 1}
        try:
            du = shutil.disk_usage(os.path.dirname(srcs[0]) if len(srcs) else "/")
            info["free"], info["fstotal"] = du.free, du.total
        except OSError:
            pass
        if len(srcs) == 1:
            p = srcs[0]
            st = os.lstat(p)
            name = os.path.basename(p)
            islink = stat.S_ISLNK(st.st_mode)
            isdir = os.path.isdir(p)
            ext = os.path.splitext(name)[1][1:].lower()
            try:
                owner = pwd.getpwuid(st.st_uid).pw_name
            except KeyError:
                owner = str(st.st_uid)
            try:
                group = grp.getgrgid(st.st_gid).gr_name
            except KeyError:
                group = str(st.st_gid)
            ft = B.FILE_TYPES.get(ext)
            info.update({
                "name": name, "path": p, "dir": isdir, "symlink": islink, "target": os.readlink(p) if islink else None,
                "broken": islink and not os.path.exists(p),
                "label": "Ordner" if isdir else (ft[1] if ft else ("Datei" if not ext else ext.upper() + "-Datei")),
                "mime": self._mime_of(p) if os.path.exists(p) else "",
                "mode": "%03o" % stat.S_IMODE(st.st_mode), "perms": self._perm_str(st.st_mode),
                "owner": owner, "group": group, "mtime": st.st_mtime, "atime": st.st_atime, "ctime": st.st_ctime,
                "can_chmod": st.st_uid == os.getuid() and not islink,
            })
        return info

    def api_chmod(self, paths: list[str], mode: str, recursive: bool = False) -> dict:
        srcs = self._sources(paths)
        if not re.fullmatch(r"[0-7]{3,4}", mode or ""):
            raise AppError("Ungültige Rechte.")
        m = int(mode, 8)
        n, errs = 0, []

        def one(p: str) -> None:
            nonlocal n
            if os.path.islink(p):
                return
            try:
                os.chmod(p, m)
                n += 1
            except OSError as e:
                errs.append({"name": os.path.basename(p), "error": e.strerror or str(e)})

        for s in srcs:
            one(s)
            if recursive and os.path.isdir(s) and not os.path.islink(s):
                for root, dirs, files in os.walk(s):
                    for x in dirs + files:
                        one(os.path.join(root, x))
        return {"changed": n, "errors": errs}

    # ------------------------------------------------------------ Öffnen mit
    @staticmethod
    def _data_dirs() -> list[Path]:
        home = Path(os.environ.get("XDG_DATA_HOME") or (Path.home() / ".local" / "share"))
        others = [Path(x) for x in (os.environ.get("XDG_DATA_DIRS") or "/usr/local/share:/usr/share").split(":") if x]
        return [home] + others

    def _find_desktop(self, app_id: str) -> Path | None:
        if not re.fullmatch(r"[A-Za-z0-9_.+-]+\.desktop", app_id or ""):
            return None
        for d in self._data_dirs():
            f = d / "applications" / app_id
            if f.is_file():
                return f
        return None

    @staticmethod
    def _read_desktop_app(f: Path) -> dict | None:
        d: dict = {}
        try:
            in_entry = False
            for line in f.read_text(encoding="utf-8", errors="replace").splitlines():
                s = line.strip()
                if s.startswith("["):
                    in_entry = s == "[Desktop Entry]"
                    continue
                if in_entry and "=" in s and not s.startswith("#"):
                    k, v = s.split("=", 1)
                    if k not in d:
                        d[k] = v
                    if k == "Name[de]":
                        d["Name[de]"] = v
        except OSError:
            return None
        if d.get("NoDisplay", "").lower() == "true" or d.get("Hidden", "").lower() == "true" or d.get("Type") != "Application":
            return None
        if not d.get("Exec"):
            return None
        return {"id": f.name, "name": d.get("Name[de]") or d.get("Name") or f.stem, "exec": d["Exec"], "terminal": d.get("Terminal", "").lower() == "true",
                "try": d.get("TryExec", "")}

    def api_open_with_list(self, path: str) -> dict:
        p = B.norm_path(path)
        mime = self._mime_of(p) if os.path.exists(p) else "application/octet-stream"
        want = [mime]
        if mime.startswith("text/") and mime != "text/plain":
            want.append("text/plain")
        ids: list[str] = []
        defaults: list[str] = []
        for d in self._data_dirs():
            cache = d / "applications" / "mimeinfo.cache"
            try:
                for line in cache.read_text(encoding="utf-8", errors="replace").splitlines():
                    if "=" in line:
                        m, v = line.split("=", 1)
                        if m in want:
                            ids += [x for x in v.split(";") if x]
            except OSError:
                pass
        for cfg in (Path(os.environ.get("XDG_CONFIG_HOME") or (Path.home() / ".config")) / "mimeapps.list", self._data_dirs()[0] / "applications" / "mimeapps.list"):
            try:
                sec = ""
                for line in cfg.read_text(encoding="utf-8", errors="replace").splitlines():
                    line = line.strip()
                    if line.startswith("["):
                        sec = line
                    elif "=" in line and sec in ("[Default Applications]", "[Added Associations]"):
                        m, v = line.split("=", 1)
                        if m in want:
                            (defaults if sec == "[Default Applications]" else ids).extend(x for x in v.split(";") if x)
            except OSError:
                pass
        order = list(dict.fromkeys(defaults + ids))
        apps = []
        for i in order:
            f = self._find_desktop(i)
            a = self._read_desktop_app(f) if f else None
            if a and (not a["try"] or shutil.which(a["try"])):
                a["default"] = i in defaults[:1]
                apps.append(a)
        return {"mime": mime, "apps": [{"id": a["id"], "name": a["name"], "default": a["default"]} for a in apps]}

    def api_open_with(self, paths: list[str], app_id: str) -> dict:
        srcs = self._sources(paths)
        f = self._find_desktop(app_id)
        a = self._read_desktop_app(f) if f else None
        if not a:
            raise AppError("Das Programm wurde nicht gefunden.")
        try:
            parts = shlex.split(a["exec"])
        except ValueError:
            raise AppError("Der Startbefehl des Programms ist ungültig.")
        argv: list[str] = []
        used = False
        for t in parts:
            if t in ("%F", "%U"):
                argv += srcs
                used = True
            elif t in ("%f", "%u"):
                argv.append(srcs[0])
                used = True
            elif t in ("%i", "%c", "%k"):
                continue
            else:
                t2 = t.replace("%%", "\0").replace("%f", srcs[0]).replace("%u", srcs[0]).replace("%F", srcs[0]).replace("%U", srcs[0]).replace("\0", "%")
                argv.append(t2)
                used = used or (t2 != t)
        if not used:
            argv += srcs[:1]
        if a["terminal"]:
            term = self._find_terminal()
            if not term:
                raise AppError("Dieses Programm braucht ein Terminal, es wurde aber keines gefunden.")
            argv = term[0] + term[2] + argv
        try:
            subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True,
                             cwd=os.path.dirname(srcs[0]))
        except OSError as e:
            raise AppError("Start nicht möglich: " + (e.strerror or str(e)))
        return {"ok": True}

    # ------------------------------------------------------------ Externes Terminal
    TERMINALS = (
        ("kgx", ["--working-directory={d}"], ["--"]), ("gnome-terminal", ["--working-directory={d}"], ["--"]),
        ("konsole", ["--workdir", "{d}"], ["-e"]), ("xfce4-terminal", ["--working-directory={d}"], ["-x"]),
        ("alacritty", ["--working-directory", "{d}"], ["-e"]), ("kitty", ["--directory", "{d}"], []),
        ("foot", ["--working-directory={d}"], []), ("wezterm", ["start", "--cwd", "{d}"], ["--"]),
        ("tilix", ["--working-directory={d}"], ["-e"]), ("mate-terminal", ["--working-directory={d}"], ["-x"]),
        ("lxterminal", ["--working-directory={d}"], ["-e"]), ("urxvt", [], ["-e"]), ("xterm", [], ["-e"]),
    )

    def _find_terminal(self, d: str = "") -> tuple[list[str], list[str], list[str]] | None:
        """Gibt (Programm samt Argumenten, Argumente für den Startordner, Ausführ-Schalter) zurück."""
        cands: list[tuple[str, list[str], list[str]]] = []
        env = os.environ.get("TERMINAL", "").strip()
        if env:
            cands.append((env, [], ["-e"]))
        cands += [(n, a, e) for n, a, e in self.TERMINALS]
        cands.append(("x-terminal-emulator", [], ["-e"]))
        for name, args, execflag in cands:
            try:
                parts = shlex.split(name)
            except ValueError:
                continue
            exe = shutil.which(parts[0]) if parts else None
            if exe:
                cwd_args = [x.replace("{d}", d) for x in args] if d else []
                return [exe] + parts[1:], cwd_args, execflag
        return None

    def api_open_terminal(self, path: str) -> dict:
        d = B.norm_path(path)
        if not os.path.isdir(d):
            d = os.path.dirname(d)
        found = self._find_terminal(d)
        if not found:
            raise AppError("Es wurde kein Terminal-Programm gefunden. Das eingebaute Terminal funktioniert trotzdem (F4).")
        argv = found[0] + found[1]
        try:
            subprocess.Popen(argv, cwd=d, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        except OSError as e:
            raise AppError("Terminal konnte nicht gestartet werden: " + (e.strerror or str(e)))
        return {"ok": True, "terminal": os.path.basename(found[0][0])}

    # ------------------------------------------------------------ Ordnerüberwachung
    def api_dir_stamp(self, path: str) -> dict:
        p = B.norm_path(path)
        try:
            st = os.stat(p)
        except OSError:
            return {"m": 0, "gone": True}
        out = {"m": st.st_mtime_ns, "gone": False}
        try:
            du = shutil.disk_usage(p)
            out["free"] = du.free
        except OSError:
            pass
        return out

    # ------------------------------------------------------------ Massenumbenennung
    UMLAUTS = {"ä": "ae", "ö": "oe", "ü": "ue", "Ä": "Ae", "Ö": "Oe", "Ü": "Ue", "ß": "ss"}

    def _mr_transform(self, name: str, mtime: float, idx: int, rules: dict, flags: dict) -> str:
        stem, ext = split_ext(name) if not os.path.isdir(flags.get("path", "")) else (name, "")
        whole = bool(rules.get("ext_too"))
        text = name if whole else stem
        find = rules.get("find") or ""
        if find:
            try:
                if rules.get("regex"):
                    text = re.sub(find, rules.get("repl") or "", text, flags=0 if rules.get("case") else re.I)
                else:
                    text = re.sub(re.escape(find), (rules.get("repl") or "").replace("\\", "\\\\"), text, flags=0 if rules.get("case") else re.I)
            except re.error as e:
                raise AppError("Ungültiger regulärer Ausdruck: %s" % e)
        rf = int(rules.get("remove_from") or 0)
        rc = int(rules.get("remove_count") or 0)
        if rf > 0 and rc > 0:
            text = text[: rf - 1] + text[rf - 1 + rc:]
        it = rules.get("insert_text") or ""
        ip = int(rules.get("insert_pos") or 0)
        if it and ip > 0:
            text = text[: ip - 1] + it + text[ip - 1:]
        sp = rules.get("spaces") or "keep"
        if sp != "keep":
            text = re.sub(r"\s+", "" if sp == "remove" else sp, text)
        if rules.get("umlauts"):
            text = "".join(self.UMLAUTS.get(c, c) for c in text)
            text = "".join(c for c in unicodedata.normalize("NFKD", text) if not unicodedata.combining(c))
        if rules.get("strip_special"):
            text = re.sub(r"[^\w .\-]", "", text, flags=re.UNICODE)
        cm = rules.get("case_mode") or ""
        if cm == "lower":
            text = text.lower()
        elif cm == "upper":
            text = text.upper()
        elif cm == "title":
            text = re.sub(r"([^\W\d_])([^\W\d_]*)", lambda m: m.group(1).upper() + m.group(2).lower(), text)
        elif cm == "sentence":
            text = text[:1].upper() + text[1:].lower()
        text = (rules.get("prefix") or "") + text + (rules.get("suffix") or "")
        nr = rules.get("number") or {}
        if nr.get("on"):
            n = int(nr.get("start", 1)) + idx * int(nr.get("step", 1))
            num = str(n).zfill(max(1, min(10, int(nr.get("digits", 2)))))
            sep = nr.get("sep", "_")
            pos = nr.get("pos", "suffix")
            text = num if pos == "replace" else (num + sep + text if pos == "prefix" else text + sep + num)
        dt = rules.get("date") or {}
        if dt.get("on"):
            t = time.localtime(mtime if dt.get("src", "mtime") == "mtime" else time.time())
            try:
                ds = time.strftime(dt.get("fmt") or "%Y-%m-%d", t)
            except ValueError:
                ds = time.strftime("%Y-%m-%d", t)
            sep = dt.get("sep", "_")
            text = ds + sep + text if dt.get("pos", "prefix") == "prefix" else text + sep + ds
        if whole:
            return text.strip()
        em = (rules.get("ext") or {}).get("mode", "keep")
        ev = ((rules.get("ext") or {}).get("value") or "").lstrip(".")
        if em == "lower":
            ext = ext.lower()
        elif em == "upper":
            ext = ext.upper()
        elif em == "remove":
            ext = ""
        elif em == "set":
            ext = ("." + ev) if ev else ""
        return text.strip() + ext

    def _mr_plan(self, paths: list[str], rules: dict) -> list[dict]:
        if not isinstance(rules, dict):
            raise AppError("Ungültige Regeln.")
        srcs = self._sources(paths)
        order = rules.get("order") or "given"
        meta = {}
        for s in srcs:
            try:
                st = os.lstat(s)
                meta[s] = (st.st_mtime, st.st_size)
            except OSError:
                meta[s] = (0, 0)
        seq = list(srcs)
        if order == "name":
            seq.sort(key=lambda s: natural_key(os.path.basename(s)))
        elif order == "mtime":
            seq.sort(key=lambda s: meta[s][0])
        elif order == "size":
            seq.sort(key=lambda s: meta[s][1])
        per_folder = bool((rules.get("number") or {}).get("per_folder"))
        counters: dict = {}
        res: dict[str, dict] = {}
        for s in seq:
            d = os.path.dirname(s)
            key = d if per_folder else ""
            i = counters.get(key, 0)
            counters[key] = i + 1
            old = os.path.basename(s)
            new = self._mr_transform(old, meta[s][0], i, rules, {"path": s})
            res[s] = {"path": s, "old": old, "new": new, "dir": d}
        out = [res[s] for s in srcs]
        srcset = set(srcs)
        finals: dict[str, int] = {}
        for r in out:
            k = os.path.join(r["dir"], r["new"])
            finals[k] = finals.get(k, 0) + 1
        for r in out:
            if r["new"] == r["old"]:
                r["status"], r["note"] = "same", ""
                continue
            try:
                B.check_name(r["new"])
                if r["new"] != r["new"].strip():
                    raise AppError("Name beginnt oder endet mit Leerzeichen.")
            except AppError as e:
                r["status"], r["note"] = "invalid", str(e)
                continue
            tgt = os.path.join(r["dir"], r["new"])
            if finals.get(tgt, 0) > 1:
                r["status"], r["note"] = "conflict", "Mehrere Einträge bekämen diesen Namen."
            elif os.path.lexists(tgt) and tgt not in srcset:
                r["status"], r["note"] = "conflict", "Es gibt schon etwas mit diesem Namen."
            else:
                r["status"], r["note"] = "ok", ""
        return out

    def api_rename_preview(self, paths: list[str], rules: dict) -> dict:
        plan = self._mr_plan(paths, rules)
        return {"items": plan, "changed": sum(1 for r in plan if r["status"] == "ok"),
                "problems": sum(1 for r in plan if r["status"] in ("conflict", "invalid"))}

    def api_rename_apply(self, paths: list[str], rules: dict) -> dict:
        self._fo_init()
        plan = self._mr_plan(paths, rules)
        if any(r["status"] in ("conflict", "invalid") for r in plan):
            raise AppError("Es gibt Namenskonflikte. Bitte zuerst in der Vorschau beheben.")
        todo = [r for r in plan if r["status"] == "ok"]
        if not todo:
            return {"renamed": 0, "pairs": []}
        done: list[tuple[str, str, str]] = []      # (ursprünglich, temporär, endgültig)
        tag = ".sd-%d-" % os.getpid()
        try:
            for i, r in enumerate(todo):
                tmp = os.path.join(r["dir"], tag + str(i))
                os.rename(r["path"], tmp)
                done.append((r["path"], tmp, os.path.join(r["dir"], r["new"])))
            fin = []
            for orig, tmp, final in done:
                os.rename(tmp, final)
                fin.append((orig, final))
        except OSError as e:
            for orig, tmp, final in reversed(done):          # alles zurück
                for cur in (final, tmp):
                    if os.path.lexists(cur) and not os.path.lexists(orig):
                        try:
                            os.rename(cur, orig)
                        except OSError:
                            pass
            raise AppError("Umbenennen abgebrochen, alles wurde zurückgesetzt: " + (e.strerror or str(e)))
        pairs = [(final, orig) for orig, final in fin]
        self._push_undo({"kind": "rename", "pairs": pairs, "desc": "Umbenennen (%d)" % len(pairs)})
        return {"renamed": len(pairs), "pairs": [{"old": o, "new": n} for o, n in fin]}
