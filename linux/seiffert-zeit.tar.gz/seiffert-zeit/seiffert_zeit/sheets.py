import json, os, urllib.error, urllib.parse, urllib.request
from .config import log

API = os.environ.get("SZ_SHEETS_API", "https://sheets.googleapis.com/v4/spreadsheets")


class SheetsError(Exception):
    pass


def _req(token, method, url, body=None):
    h = {"Authorization": "Bearer " + token}
    if body is not None:
        h["Content-Type"] = "application/json"
    req = urllib.request.Request(url, method=method, headers=h, data=json.dumps(body).encode() if body is not None else None)
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            d = r.read()
        return json.loads(d) if d else {}
    except urllib.error.HTTPError as e:
        log("Sheets %s -> %s" % (method, e.code))
        raise SheetsError("Google Tabellen antwortet mit Fehler %s" % e.code)
    except (urllib.error.URLError, OSError):
        raise SheetsError("Keine Verbindung zu Google")


def row(x):
    """Zeile im Format des Blatts Fokus im ToDo (id, ref, title, meta, tags, next, start, end, ms)."""
    return [str(x["id"]), x.get("ref", ""), x.get("title", ""), x.get("meta", ""), ",".join(x.get("tags") or []),
            "1" if x.get("next") else "0", x["start"], x.get("end", ""), str(int(round(float(x.get("ms") or 0))))]


def push_fokus(token, sheet_id, sessions):
    """Haengt nur Sitzungen an, deren id im Blatt fehlt. Bestehende Zeilen werden nie veraendert.
    Fehlt das Blatt Fokus, wird es nicht angelegt (das ToDo legt es mit Kopfzeile an)."""
    base = "%s/%s" % (API, urllib.parse.quote(sheet_id, safe=""))
    try:
        r = _req(token, "GET", base + "/values/" + urllib.parse.quote("Fokus!A2:A"))
    except SheetsError as e:
        if "400" in str(e):
            raise SheetsError("Das Blatt Fokus fehlt in der ToDo-Tabelle (bitte einmal das ToDo öffnen)")
        raise
    have = {c[0] for c in (r.get("values") or []) if c}
    new = [row(x) for x in sessions if str(x.get("id")) not in have and x.get("start") and x.get("end")]
    if not new:
        return 0
    _req(token, "POST", base + "/values/" + urllib.parse.quote("Fokus!A1") + ":append?valueInputOption=RAW&insertDataOption=INSERT_ROWS", {"values": new})
    log("Fokus: %d Sitzungen in die ToDo-Tabelle geschrieben" % len(new))
    return len(new)


def pull_fokus(token, sheet_id):
    """Liest alle Sitzungen aus dem Blatt Fokus (nur lesen)."""
    base = "%s/%s" % (API, urllib.parse.quote(sheet_id, safe=""))
    r = _req(token, "GET", base + "/values/" + urllib.parse.quote("Fokus!A2:I"))
    out = []
    for c in r.get("values") or []:
        c = list(c) + [""] * (9 - len(c))
        if not c[0] or not c[6] or not c[7]:
            continue
        try:
            ms = int(float(c[8] or 0))
        except ValueError:
            continue
        out.append({"id": c[0], "ref": c[1], "title": c[2], "meta": c[3], "tags": [t.strip() for t in str(c[4]).split(",") if t.strip()],
                    "next": c[5] == "1", "start": c[6], "end": c[7], "ms": ms})
    return out[-900:]


def todo_local_file():
    base = os.environ.get("XDG_DATA_HOME") or os.path.join(os.path.expanduser("~"), ".local", "share")
    return os.path.join(base, "seiffert-todo", "daten.json")


def effective_id(settings):
    """Tabellen-ID der ToDo-Tabelle: erst der eingetragene Wert, sonst die ID, die das Linux-ToDo lokal gemerkt hat (nur gelesen)."""
    v = (settings.get("todo_sheet_id") or "").strip()
    if v:
        return v, "eingetragen"
    try:
        with open(todo_local_file(), encoding="utf-8") as f:
            d = json.load(f)
        v = str(d.get("ssid") or "").strip() if isinstance(d, dict) else ""
        if v and all(c.isalnum() or c in "-_" for c in v):
            return v, "vom Linux-ToDo"
    except (OSError, ValueError):
        pass
    return "", ""
