"""Oberfläche von Seifferts Gitarre (PySide6)."""
import json
import math
import os
import sys
from pathlib import Path

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QKeySequence, QShortcut
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QGridLayout, QGroupBox,
                               QHBoxLayout, QLabel, QLineEdit, QMainWindow, QMessageBox,
                               QProgressBar, QPushButton, QScrollArea, QSlider, QSpinBox,
                               QTabWidget, QVBoxLayout, QWidget)

from . import engine as eng
from .fxdefs import (CHORD_PRESETS, DRUM_PRESETS, DRUM_ROWS, FX_GROUPS, INPUT_GAIN, KEYS_SOUNDS,
                     KEYS_STYLES, PRESETS, VOLUMES)

SETTINGS_PATH = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "seiffert-gitarre" / "settings.json"

STYLE = """
QWidget { font-size: 13px; }
QGroupBox { border: 1px solid #555; border-radius: 6px; margin-top: 10px; padding: 8px 6px 6px 6px; font-weight: bold; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }
QPushButton#play { font-size: 16px; font-weight: bold; padding: 8px 18px; }
QPushButton#play:checked { background: #2e7d32; color: white; }
QPushButton#audio:checked { background: #1565c0; color: white; }
"""


class ParamSlider(QWidget):
    changed = Signal(float)

    def __init__(self, label, vmin, vmax, default, unit="", decimals=1, parent=None):
        super().__init__(parent)
        self.vmin, self.vmax, self.unit, self.decimals = vmin, vmax, unit, decimals
        self.default = default
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.label = QLabel(label)
        self.label.setMinimumWidth(100)
        self.slider = QSlider(Qt.Horizontal)
        self.slider.setRange(0, 1000)
        self.slider.setMinimumWidth(110)
        self.value_label = QLabel()
        self.value_label.setMinimumWidth(62)
        self.value_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        lay.addWidget(self.label)
        lay.addWidget(self.slider, 1)
        lay.addWidget(self.value_label)
        self.slider.valueChanged.connect(self._on_change)
        self.setValue(default)

    def value(self):
        return self.vmin + (self.vmax - self.vmin) * self.slider.value() / 1000.0

    def setValue(self, v):
        v = max(self.vmin, min(self.vmax, float(v)))
        self.slider.setValue(int(round((v - self.vmin) / (self.vmax - self.vmin) * 1000)))
        self._update_label()

    def _update_label(self):
        text = ("%.*f" % (self.decimals, self.value())).replace(".", ",")
        self.value_label.setText((text + " " + self.unit).strip())

    def _on_change(self, _):
        self._update_label()
        self.changed.emit(self.value())


class StepButton(QPushButton):
    COLORS = {0: "#3a3a3a", 1: "#e65100", 2: "#a1887f"}

    def __init__(self, beat_start, parent=None):
        super().__init__(parent)
        self.state = 0
        self.beat_start = beat_start
        self.setFixedSize(34, 30)
        self.clicked.connect(self._cycle)
        self._paint()

    changed = Signal()

    def _cycle(self):
        self.setState((self.state + 1) % 3)
        self.changed.emit()

    def setState(self, s):
        self.state = s
        self._paint()

    def _paint(self):
        border = "#bbb" if self.beat_start else "#666"
        self.setStyleSheet("background:%s; border:1px solid %s; border-radius:3px;" % (self.COLORS[self.state], border))


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Seifferts Gitarre")
        self.engine = eng.AudioEngine()
        self.backing = self.engine.backing
        self.fx_groups = {}
        self.fx_sliders = {}
        self.step_buttons = {}
        self.loading = True

        self.rebuild_timer = QTimer(self)
        self.rebuild_timer.setSingleShot(True)
        self.rebuild_timer.setInterval(150)
        self.rebuild_timer.timeout.connect(self.backing.request_rebuild)

        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.addWidget(self._build_audio_box())
        root.addWidget(self._build_mixer_box())
        tabs = QTabWidget()
        tabs.addTab(self._build_guitar_tab(), "Gitarre")
        tabs.addTab(self._build_backing_tab(), "Begleitung")
        root.addWidget(tabs, 1)
        self.status = QLabel("")
        root.addWidget(self.status)

        QShortcut(QKeySequence(Qt.Key_Space), self, activated=self.play_btn.click)

        self.meter_timer = QTimer(self)
        self.meter_timer.timeout.connect(self._update_meter)
        self.meter_timer.start(60)

        self._refresh_devices()
        self._load_settings()
        self.loading = False
        self._push_all_to_engine()
        self._on_drum_changed()
        self.backing.rebuild_now()
        self.backing.request_rebuild()
        self.resize(1000, 760)

    # ------------------------------------------------------------------ Aufbau
    def _build_audio_box(self):
        box = QGroupBox("Audio-Interface")
        g = QGridLayout(box)
        self.in_combo = QComboBox()
        self.out_combo = QComboBox()
        self.ch_combo = QComboBox()
        self.ch_combo.addItems(["Eingang 1", "Eingang 2", "Eingang 3", "Eingang 4"])
        self.block_combo = QComboBox()
        for b in (64, 128, 256, 512, 1024):
            self.block_combo.addItem(str(b), b)
        self.block_combo.setCurrentIndex(2)
        self.sr_combo = QComboBox()
        for s in (44100, 48000, 96000):
            self.sr_combo.addItem("%d Hz" % s, s)
        self.sr_combo.setCurrentIndex(1)
        self.audio_btn = QPushButton("Audio starten")
        self.audio_btn.setObjectName("audio")
        self.audio_btn.setCheckable(True)
        self.audio_btn.clicked.connect(self._toggle_audio)
        refresh = QPushButton("Geräte neu suchen")
        refresh.clicked.connect(self._refresh_devices)

        g.addWidget(QLabel("Eingang"), 0, 0)
        g.addWidget(self.in_combo, 0, 1)
        g.addWidget(self.ch_combo, 0, 2)
        g.addWidget(QLabel("Ausgang"), 1, 0)
        g.addWidget(self.out_combo, 1, 1)
        g.addWidget(QLabel("Puffer"), 0, 3)
        g.addWidget(self.block_combo, 0, 4)
        g.addWidget(QLabel("Abtastrate"), 1, 3)
        g.addWidget(self.sr_combo, 1, 4)
        g.addWidget(self.audio_btn, 0, 5)
        g.addWidget(refresh, 1, 5)
        g.setColumnStretch(1, 1)

        self.meter = QProgressBar()
        self.meter.setRange(0, 100)
        self.meter.setTextVisible(False)
        self.meter.setFixedHeight(10)
        self.info_label = QLabel("Audio ist aus.")
        g.addWidget(QLabel("Eingangspegel"), 2, 0)
        g.addWidget(self.meter, 2, 1, 1, 2)
        g.addWidget(self.info_label, 2, 3, 1, 3)
        return box

    def _build_mixer_box(self):
        box = QGroupBox("Spielen")
        lay = QGridLayout(box)
        self.play_btn = QPushButton("Begleitung  (Leertaste)")
        self.play_btn.setObjectName("play")
        self.play_btn.setCheckable(True)
        self.play_btn.toggled.connect(self._on_play)
        self.tempo = QSpinBox()
        self.tempo.setRange(40, 220)
        self.tempo.setValue(100)
        self.tempo.setSuffix(" BPM")
        self.tempo.valueChanged.connect(self._on_tempo)
        lay.addWidget(self.play_btn, 0, 0, 2, 1)
        lay.addWidget(QLabel("Tempo"), 0, 1)
        lay.addWidget(self.tempo, 1, 1)

        self.input_slider = ParamSlider(INPUT_GAIN[1], *INPUT_GAIN[2:])
        self.input_slider.changed.connect(lambda v: self.engine.set_global("input_db", v))
        lay.addWidget(self.input_slider, 0, 2)
        self.vol_sliders = {}
        order = ["guitar", "drums", "keys", "master"]
        specs = {v[0]: v for v in VOLUMES}
        # Spalte 2: Gitarre, Spalte 3: Begleitung, Spalte 4: Gesamt
        grid_pos = {"guitar": (1, 2), "drums": (0, 3), "keys": (1, 3), "master": (0, 4)}
        for key in order:
            s = specs[key]
            sl = ParamSlider(s[1], *s[2:])
            sl.changed.connect(lambda v, k=key: self.engine.set_global(k, v))
            self.vol_sliders[key] = sl
            r, c = grid_pos[key]
            lay.addWidget(sl, r, c)
        lay.setColumnStretch(2, 1)
        lay.setColumnStretch(3, 1)
        lay.setColumnStretch(4, 1)
        return box

    def _build_guitar_tab(self):
        page = QWidget()
        v = QVBoxLayout(page)
        top = QHBoxLayout()
        top.addWidget(QLabel("Klang wählen:"))
        self.preset_combo = QComboBox()
        self.preset_combo.addItems(list(PRESETS.keys()))
        self.preset_combo.activated.connect(lambda _: self._apply_preset(self.preset_combo.currentText()))
        top.addWidget(self.preset_combo)
        top.addStretch(1)
        v.addLayout(top)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        inner = QWidget()
        grid = QGridLayout(inner)
        for i, grp in enumerate(FX_GROUPS):
            box = QGroupBox(grp["title"])
            box.setCheckable(True)
            box.setChecked(False)
            lay = QVBoxLayout(box)
            key = grp["key"]
            box.toggled.connect(lambda on, k=key: self.engine.set_enabled(k, on))
            sliders = {}
            for p in grp["params"]:
                sl = ParamSlider(p[1], p[2], p[3], p[4], p[5], p[6])
                sl.changed.connect(lambda val, k=key, n=p[0]: self.engine.set_param(k, n, val))
                lay.addWidget(sl)
                sliders[p[0]] = sl
            self.fx_groups[key] = box
            self.fx_sliders[key] = sliders
            grid.addWidget(box, i // 2, i % 2)
        grid.setRowStretch(len(FX_GROUPS) // 2 + 1, 1)
        scroll.setWidget(inner)
        v.addWidget(scroll, 1)
        return page

    def _build_backing_tab(self):
        page = QWidget()
        v = QVBoxLayout(page)

        drums = QGroupBox("Schlagzeug")
        dl = QVBoxLayout(drums)
        top = QHBoxLayout()
        top.addWidget(QLabel("Muster"))
        self.drum_preset = QComboBox()
        self.drum_preset.addItems(list(DRUM_PRESETS.keys()))
        self.drum_preset.activated.connect(lambda _: self._load_drum_preset(self.drum_preset.currentText()))
        top.addWidget(self.drum_preset)
        top.addSpacing(16)
        self.swing = ParamSlider("Swing", 0.0, 1.0, 0.0, "", 2)
        self.swing.changed.connect(self._on_swing)
        top.addWidget(self.swing, 1)
        dl.addLayout(top)
        self.grid_widget = QWidget()
        self.grid_layout = QGridLayout(self.grid_widget)
        self.grid_layout.setHorizontalSpacing(3)
        self.grid_layout.setVerticalSpacing(3)
        dl.addWidget(self.grid_widget)
        hint = QLabel("Klick auf ein Feld: laut, leise, aus.")
        dl.addWidget(hint)
        v.addWidget(drums)
        self.steps = 16
        self.swing_value = 0.0
        self._build_grid(16)

        keys = QGroupBox("Keyboard")
        kl = QGridLayout(keys)
        kl.addWidget(QLabel("Akkorde (ein Akkord pro Takt)"), 0, 0)
        self.chord_edit = QLineEdit(self.backing.chords_text)
        self.chord_edit.editingFinished.connect(self._on_chords)
        kl.addWidget(self.chord_edit, 0, 1, 1, 3)
        self.chord_preset = QComboBox()
        self.chord_preset.addItem("Vorlage ...")
        self.chord_preset.addItems(list(CHORD_PRESETS.keys()))
        self.chord_preset.activated.connect(self._on_chord_preset)
        kl.addWidget(self.chord_preset, 0, 4)
        self.chord_status = QLabel("Erlaubt: C, Am, G7, Dm7, Fmaj7, Asus4, Bdim, E5, Bb, F#m")
        kl.addWidget(self.chord_status, 1, 0, 1, 5)
        kl.addWidget(QLabel("Spielweise"), 2, 0)
        self.style_combo = QComboBox()
        for k, label in KEYS_STYLES:
            self.style_combo.addItem(label, k)
        self.style_combo.activated.connect(lambda _: self._on_keys_change())
        kl.addWidget(self.style_combo, 2, 1)
        kl.addWidget(QLabel("Klang"), 2, 2)
        self.sound_combo = QComboBox()
        for k, label in KEYS_SOUNDS:
            self.sound_combo.addItem(label, k)
        self.sound_combo.activated.connect(lambda _: self._on_keys_change())
        kl.addWidget(self.sound_combo, 2, 3)
        self.bass_check = QCheckBox("Bass dazu")
        self.bass_check.setChecked(True)
        self.bass_check.toggled.connect(lambda _: self._on_keys_change())
        kl.addWidget(self.bass_check, 2, 4)
        kl.setColumnStretch(1, 1)
        kl.setColumnStretch(3, 1)
        v.addWidget(keys)
        v.addStretch(1)
        return page

    def _build_grid(self, steps):
        for row_buttons in self.step_buttons.values():
            for b in row_buttons:
                b.setParent(None)
                b.deleteLater()
        while self.grid_layout.count():
            item = self.grid_layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.setParent(None)
                w.deleteLater()
        self.step_buttons = {}
        self.steps = steps
        per_beat = steps // 4
        for r, (key, label) in enumerate(DRUM_ROWS):
            self.grid_layout.addWidget(QLabel(label), r, 0)
            row = []
            for i in range(steps):
                b = StepButton(i % per_beat == 0)
                b.changed.connect(self._on_drum_changed)
                self.grid_layout.addWidget(b, r, i + 1)
                row.append(b)
            self.step_buttons[key] = row
        self.grid_layout.setColumnStretch(steps + 1, 1)

    # ------------------------------------------------------------------ Geräte, Audio
    def _refresh_devices(self):
        ins, outs = eng.list_devices()
        self._ins, self._outs = ins, outs
        cur_in, cur_out = self.in_combo.currentData(), self.out_combo.currentData()
        self.in_combo.clear()
        self.out_combo.clear()
        for idx, label, name, _n in ins:
            self.in_combo.addItem(label, name)
        for idx, label, name, _n in outs:
            self.out_combo.addItem(label, name)
        for combo, cur in ((self.in_combo, cur_in), (self.out_combo, cur_out)):
            i = combo.findData(cur) if cur else -1
            if i >= 0:
                combo.setCurrentIndex(i)
        if eng.sd is None:
            self.info_label.setText("PortAudio fehlt, siehe INSTALLATION.txt")
        elif not ins:
            self.info_label.setText("Kein Audio-Gerät gefunden.")

    def _selected_index(self, devs, combo):
        i = combo.currentIndex()
        return devs[i][0] if 0 <= i < len(devs) else None

    def _toggle_audio(self, checked):
        if not checked:
            self.engine.stop()
            self.audio_btn.setText("Audio starten")
            self.info_label.setText("Audio ist aus.")
            return
        in_idx = self._selected_index(self._ins, self.in_combo)
        out_idx = self._selected_index(self._outs, self.out_combo)
        try:
            if in_idx is None or out_idx is None:
                raise RuntimeError("Bitte Eingang und Ausgang wählen." if eng.sd is not None
                                   else "PortAudio nicht gefunden: " + str(eng.SD_ERROR))
            self.engine.start(in_idx, out_idx, self.ch_combo.currentIndex(),
                              self.sr_combo.currentData(), self.block_combo.currentData())
            self.audio_btn.setText("Audio beenden")
        except Exception as exc:
            self.audio_btn.setChecked(False)
            self.audio_btn.setText("Audio starten")
            QMessageBox.warning(self, "Audio konnte nicht gestartet werden", str(exc))

    def _update_meter(self):
        peak = self.engine.in_peak
        db = 20 * math.log10(peak) if peak > 1e-6 else -90.0
        self.meter.setValue(int(max(0.0, min(100.0, (db + 60.0) / 60.0 * 100.0))))
        hot = peak > 0.97
        self.meter.setStyleSheet("QProgressBar::chunk { background: %s; }" % ("#c62828" if hot else "#43a047"))
        if self.engine.running:
            txt = "Läuft. Latenz etwa %.1f ms, Aussetzer: %d" % (self.engine.latency_ms, self.engine.xruns)
            if hot:
                txt += "  Eingang übersteuert, Pegel senken!"
            if self.engine.errors:
                txt += "  Fehler: " + self.engine.last_error
            self.info_label.setText(txt)

    # ------------------------------------------------------------------ Gitarre
    def _apply_preset(self, name):
        preset = PRESETS.get(name, {})
        for grp in FX_GROUPS:
            key = grp["key"]
            on, vals = preset.get(key, (False, {}))
            # Erst Werte, dann Schalter, damit beim Einschalten schon die richtigen Werte gelten
            for p in grp["params"]:
                self.fx_sliders[key][p[0]].setValue(vals.get(p[0], p[4]))
            self.fx_groups[key].setChecked(on)

    # ------------------------------------------------------------------ Begleitung
    def _on_play(self, on):
        if on:
            self.backing.play()
        else:
            self.backing.stop()

    def _on_tempo(self, v):
        self.backing.tempo = v
        self.rebuild_timer.start()

    def _on_swing(self, v):
        self.backing.swing = v
        self.swing_value = v
        self.rebuild_timer.start()

    def get_pattern(self):
        return {k: [b.state for b in row] for k, row in self.step_buttons.items()}

    def _on_drum_changed(self):
        self.backing.steps = self.steps
        self.backing.pattern = self.get_pattern()
        self.backing.swing = self.swing_value if self.steps == 16 else 0.0
        self.swing.setEnabled(self.steps == 16)
        self.rebuild_timer.start()

    def _load_drum_preset(self, name):
        steps, swing, rows = DRUM_PRESETS[name]
        if steps != self.steps:
            self._build_grid(steps)
        for key, text in rows.items():
            for i, ch in enumerate(text[:steps]):
                self.step_buttons[key][i].setState({"X": 1, "x": 2}.get(ch, 0))
        self.swing.setValue(swing)
        self.swing_value = swing
        self._on_drum_changed()

    def _on_chords(self):
        text = self.chord_edit.text()
        try:
            self.backing.set_chords(text)
            self.chord_status.setStyleSheet("")
            self.chord_status.setText("%d Takte" % len(self.backing.chords))
            self.rebuild_timer.start()
        except ValueError as exc:
            self.chord_status.setStyleSheet("color:#e53935;")
            self.chord_status.setText(str(exc) + " (bisherige Akkorde bleiben)")

    def _on_chord_preset(self, idx):
        if idx <= 0:
            return
        self.chord_edit.setText(CHORD_PRESETS[self.chord_preset.itemText(idx)])
        self.chord_preset.setCurrentIndex(0)
        self._on_chords()

    def _on_keys_change(self):
        self.backing.keys_style = self.style_combo.currentData()
        self.backing.keys_sound = self.sound_combo.currentData()
        self.backing.bass = self.bass_check.isChecked()
        self.rebuild_timer.start()

    # ------------------------------------------------------------------ Einstellungen
    def _push_all_to_engine(self):
        e = self.engine
        for key, grp in self.fx_groups.items():
            e.set_enabled(key, grp.isChecked())
            for name, sl in self.fx_sliders[key].items():
                e.set_param(key, name, sl.value())
        e.set_global("input_db", self.input_slider.value())
        for k, sl in self.vol_sliders.items():
            e.set_global(k, sl.value())
        self._on_keys_change()
        self.backing.tempo = self.tempo.value()

    def _collect_settings(self):
        return {
            "in_dev": self.in_combo.currentData(), "out_dev": self.out_combo.currentData(),
            "in_ch": self.ch_combo.currentIndex(), "block": self.block_combo.currentData(),
            "sr": self.sr_combo.currentData(),
            "preset": self.preset_combo.currentText(),
            "fx": {k: {"on": g.isChecked(), "params": {n: s.value() for n, s in self.fx_sliders[k].items()}}
                   for k, g in self.fx_groups.items()},
            "input_db": self.input_slider.value(),
            "vol": {k: s.value() for k, s in self.vol_sliders.items()},
            "tempo": self.tempo.value(), "steps": self.steps, "swing": self.swing_value,
            "pattern": self.get_pattern(), "drum_preset": self.drum_preset.currentText(),
            "chords": self.backing.chords_text,
            "keys_style": self.style_combo.currentData(), "keys_sound": self.sound_combo.currentData(),
            "bass": self.bass_check.isChecked(),
        }

    def _load_settings(self):
        try:
            d = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
        except Exception:
            self._apply_preset("Crunch")
            self.preset_combo.setCurrentText("Crunch")
            self._load_drum_preset("Rock (Achtel)")
            return
        try:
            for combo, key in ((self.in_combo, "in_dev"), (self.out_combo, "out_dev")):
                i = combo.findData(d.get(key))
                if i >= 0:
                    combo.setCurrentIndex(i)
            self.ch_combo.setCurrentIndex(int(d.get("in_ch", 0)))
            for combo, key in ((self.block_combo, "block"), (self.sr_combo, "sr")):
                i = combo.findData(d.get(key))
                if i >= 0:
                    combo.setCurrentIndex(i)
            for k, v in d.get("fx", {}).items():
                if k in self.fx_groups:
                    for n, val in v.get("params", {}).items():
                        if n in self.fx_sliders[k]:
                            self.fx_sliders[k][n].setValue(val)
                    self.fx_groups[k].setChecked(bool(v.get("on")))
            self.preset_combo.setCurrentText(d.get("preset", "Crunch"))
            self.input_slider.setValue(d.get("input_db", 0.0))
            for k, val in d.get("vol", {}).items():
                if k in self.vol_sliders:
                    self.vol_sliders[k].setValue(val)
            self.tempo.setValue(int(d.get("tempo", 100)))
            steps = int(d.get("steps", 16))
            if steps in (12, 16):
                if steps != self.steps:
                    self._build_grid(steps)
                for key, cells in d.get("pattern", {}).items():
                    if key in self.step_buttons:
                        for i, s in enumerate(cells[:steps]):
                            self.step_buttons[key][i].setState(int(s) % 3)
            self.swing.setValue(d.get("swing", 0.0))
            self.swing_value = float(d.get("swing", 0.0))
            self.drum_preset.setCurrentText(d.get("drum_preset", "Rock (Achtel)"))
            self.chord_edit.setText(d.get("chords", "Am F C G"))
            self._on_chords()
            i = self.style_combo.findData(d.get("keys_style"))
            if i >= 0:
                self.style_combo.setCurrentIndex(i)
            i = self.sound_combo.findData(d.get("keys_sound"))
            if i >= 0:
                self.sound_combo.setCurrentIndex(i)
            self.bass_check.setChecked(bool(d.get("bass", True)))
        except Exception:
            pass  # kaputte Einstellungsdatei darf den Start nicht verhindern

    def closeEvent(self, ev):
        try:
            SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
            SETTINGS_PATH.write_text(json.dumps(self._collect_settings(), indent=1), encoding="utf-8")
        except Exception:
            pass
        self.engine.stop()
        super().closeEvent(ev)


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Seifferts Gitarre")
    app.setStyleSheet(STYLE)
    win = MainWindow()
    win.show()
    sys.exit(app.exec())
