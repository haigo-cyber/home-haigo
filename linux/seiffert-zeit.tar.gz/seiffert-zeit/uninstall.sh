#!/usr/bin/env bash
# Entfernt das Programm. Daten (Dokumente/Seifferts Zeit) und Einstellungen bleiben erhalten.
set -u
DATA="${XDG_DATA_HOME:-$HOME/.local/share}"
chmod -R u+w "$DATA/seiffert-zeit/app" 2>/dev/null
rm -rf "$DATA/seiffert-zeit/app" "$DATA/seiffert-zeit/venv" "$HOME/.local/bin/seiffert-zeit" "$DATA/applications/seiffert-zeit.desktop"
for n in 16 22 24 32 48 64 128 256; do rm -f "$DATA/icons/hicolor/${n}x${n}/apps/seiffert-zeit.png"; done
echo "Seifferts Zeit entfernt. Daten in Dokumente/Seifferts Zeit und ~/.config/seiffert-zeit wurden nicht angefasst."
