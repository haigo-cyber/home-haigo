import os, subprocess, sys, time
from pathlib import Path
from .config import Settings, log, LOG_FILE, CONF_DIR
from .store import Store
from .server import App, HERE


def main():
    s = Settings()
    if s.get("software_rendering"):
        os.environ.setdefault("QTWEBENGINE_CHROMIUM_FLAGS", "--disable-gpu")
    from PySide6.QtCore import QObject, Qt, QTimer, QUrl, Signal, QMarginsF, QSharedMemory
    from PySide6.QtGui import QAction, QIcon, QKeySequence, QPageLayout, QPageSize, QDesktopServices
    from PySide6.QtNetwork import QLocalServer, QLocalSocket
    from PySide6.QtWidgets import QApplication, QFileDialog, QInputDialog, QMainWindow, QMessageBox
    from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineProfile
    from PySide6.QtWebEngineWidgets import QWebEngineView

    qapp = QApplication(sys.argv)
    qapp.setApplicationName("Seifferts Zeit")
    qapp.setDesktopFileName("seiffert-zeit")
    sock_name = "seiffert-zeit-%d" % os.getuid()

    # nur eine Instanz je Benutzer
    c = QLocalSocket()
    c.connectToServer(sock_name)
    if c.waitForConnected(300):
        c.write(b"raise")
        c.flush()
        c.waitForBytesWritten(500)
        return 0
    QLocalServer.removeServer(sock_name)

    store = Store(s)

    class Bridge(QObject):
        pdf = Signal()

    bridge = Bridge()
    app = App(s, store, lambda: bridge.pdf.emit())
    app.start()

    icon_dir = HERE / "icons"
    icon = QIcon()
    for n in (16, 22, 24, 32, 48, 64, 128, 256):
        p = icon_dir / ("icon-%d.png" % n)
        if p.exists():
            icon.addFile(str(p))
    qapp.setWindowIcon(icon)

    class Page(QWebEnginePage):
        def acceptNavigationRequest(self, url, typ, main):
            if url.host() not in ("127.0.0.1", "localhost") and url.scheme() in ("http", "https"):
                QDesktopServices.openUrl(url)
                return False
            return super().acceptNavigationRequest(url, typ, main)

        def javaScriptConsoleMessage(self, level, msg, line, src):
            if level == QWebEnginePage.JavaScriptConsoleMessageLevel.ErrorMessageLevel:
                log("JS-Fehler: %s (Zeile %d)" % (msg[:200], line))

    class Win(QMainWindow):
        def __init__(self):
            super().__init__()
            self.setWindowTitle("Seifferts Zeit")
            self.resize(1100, 850)
            self.profile = QWebEngineProfile(self)  # ohne Namen: nichts auf der Platte
            self.page = Page(self.profile, self)
            self.view = QWebEngineView(self)
            self.view.setPage(self.page)
            self.setCentralWidget(self.view)
            self.view.setZoomFactor(float(s.get("zoom") or 1.0))
            self.profile.downloadRequested.connect(self.on_download)
            self.page.pdfPrintingFinished.connect(self.on_pdf_done)
            bridge.pdf.connect(self.print_pdf)
            self.menus()
            self.view.load(QUrl(app.url()))
            self.srv = QLocalServer(self)
            self.srv.newConnection.connect(self.on_other)
            self.srv.listen(sock_name)

        def on_other(self):
            sk = self.srv.nextPendingConnection()
            if sk:
                sk.readAll()
                sk.close()
            self.showNormal()
            self.raise_()
            self.activateWindow()

        def act(self, menu, text, fn, key=None):
            a = QAction(text, self)
            if key:
                a.setShortcut(QKeySequence(key))
            a.triggered.connect(fn)
            menu.addAction(a)
            return a

        def menus(self):
            m = self.menuBar().addMenu("&Datei")
            self.act(m, "Mit Google Drive verbinden", self.login)
            self.act(m, "Mit Drive abgleichen", self.drive_sync)
            self.act(m, "Laptop-Sicherung jetzt anlegen", lambda: self.msg("Sicherung angelegt: %s" % store.backup("manuell")))
            m.addSeparator()
            self.act(m, "Anmelde-Adresse ändern ...", self.set_url)
            self.act(m, "Google Client-ID ändern ...", self.set_cid)
            self.act(m, "Andere HTML-Fassung laden ...", self.other_html)
            self.act(m, "Datenordner öffnen", lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(store.dir))))
            self.act(m, "Seite als PDF speichern ...", self.print_pdf, "Ctrl+P")
            m.addSeparator()
            self.act(m, "Beenden", self.close, "Ctrl+Q")
            v = self.menuBar().addMenu("&Ansicht")
            self.act(v, "Vergrößern", lambda: self.zoom(0.1), "Ctrl++")
            self.act(v, "Vergrößern ", lambda: self.zoom(0.1), "Ctrl+=")
            self.act(v, "Verkleinern", lambda: self.zoom(-0.1), "Ctrl+-")
            self.act(v, "Normale Größe", lambda: self.zoom(0), "Ctrl+0")
            self.act(v, "Vollbild", self.fullscreen, "F11")
            self.act(v, "Neu laden", self.view.reload, "F5")
            h = self.menuBar().addMenu("&Hilfe")
            self.act(h, "Protokoll öffnen", lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(LOG_FILE))))
            self.act(h, "Einstellungsordner öffnen", lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(CONF_DIR))))

        def msg(self, t):
            QMessageBox.information(self, "Seifferts Zeit", t)

        def zoom(self, d):
            z = 1.0 if d == 0 else min(3.0, max(0.5, self.view.zoomFactor() + d))
            self.view.setZoomFactor(z)
            s.set(zoom=round(z, 2))

        def fullscreen(self):
            self.showNormal() if self.isFullScreen() else self.showFullScreen()

        def ensure(self):
            if not s.get("handoff_url"):
                u, ok = QInputDialog.getText(self, "Anmelde-Adresse", "Internetadresse der veröffentlichten Seifferts Zeit (GitHub Pages, ohne Anhang):")
                if not ok or not u.strip().startswith("https://"):
                    return False
                s.set(handoff_url=u.strip())
            if not s.get("client_id"):
                u, ok = QInputDialog.getText(self, "Google Client-ID", "Client-ID (dieselbe wie beim Depot):")
                if not ok or not u.strip():
                    return False
                s.set(client_id=u.strip())
            return True

        def login(self):
            if self.ensure():
                app.sync.begin_login()

        def drive_sync(self):
            if not app.sync.drive.valid():
                self.login()
            else:
                app.sync.sync_async()

        def set_url(self):
            u, ok = QInputDialog.getText(self, "Anmelde-Adresse", "Adresse:", text=s.get("handoff_url"))
            if ok and u.strip().startswith("https://"):
                s.set(handoff_url=u.strip())

        def set_cid(self):
            u, ok = QInputDialog.getText(self, "Google Client-ID", "Client-ID:", text=s.get("client_id"))
            if ok and u.strip():
                s.set(client_id=u.strip())

        def other_html(self):
            p, _ = QFileDialog.getOpenFileName(self, "HTML-Fassung wählen", str(Path.home()), "HTML (*.html)")
            if p:
                s.set(html_datei=p)
                self.view.reload()

        def on_download(self, dl):
            name = dl.downloadFileName() or "datei"
            start = str(store.dir / name)
            p, _ = QFileDialog.getSaveFileName(self, "Speichern unter", start)
            if not p:
                dl.cancel()
                return
            dl.setDownloadDirectory(str(Path(p).parent))
            dl.setDownloadFileName(Path(p).name)
            dl.accept()

        def print_pdf(self):
            p, _ = QFileDialog.getSaveFileName(self, "Als PDF speichern", str(store.dir / "arbeitszeit.pdf"), "PDF (*.pdf)")
            if p:
                self._pdf_target = p
                lay = QPageLayout(QPageSize(QPageSize.A4), QPageLayout.Portrait, QMarginsF(15, 15, 15, 15), QPageLayout.Millimeter)
                self.page.printToPdf(p, lay)

        def on_pdf_done(self, path, ok):
            self.msg("PDF gespeichert: %s" % path if ok else "Das PDF konnte nicht gespeichert werden.")

        def closeEvent(self, e):
            try:
                self.view.page().runJavaScript("1")  # noch ausstehende Speicherung der Seite anstossen
                if app.sync.drive.valid() and s.get("drive_dirty"):
                    t0 = time.time()
                    app.sync.run()
                    log("Abschlussabgleich in %.1f s" % (time.time() - t0))
            except Exception as ex:
                log("Beim Beenden: %r" % ex)
            super().closeEvent(e)

    w = Win()
    w.show()
    return qapp.exec()


if __name__ == "__main__":
    sys.exit(main())
