#!/usr/bin/env bash
# Installiert Seifferts Konten (Linux-App) ohne sudo nach ~/.local
set -euo pipefail

HIER="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DATA="${XDG_DATA_HOME:-$HOME/.local/share}/seiffert-konten"
BIN="$HOME/.local/bin"
APPS="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
ICONS="${XDG_DATA_HOME:-$HOME/.local/share}/icons/hicolor/256x256/apps"
VENV="$DATA/venv"
PY="$VENV/bin/python"

echo "Seifferts Konten wird installiert ..."

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 fehlt. Auf Arch: sudo pacman -S python"; exit 1
fi
if ! python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)'; then
  echo "Python 3.9 oder neuer wird gebraucht."; exit 1
fi

mkdir -p "$DATA" "$BIN" "$APPS" "$ICONS"

# Eigene Python-Umgebung mit PySide6 (enthaelt QtWebEngine)
if [ ! -x "$PY" ]; then
  python3 -m venv "$VENV"
fi
if ! "$PY" -c 'from PySide6.QtWebEngineWidgets import QWebEngineView' >/dev/null 2>&1; then
  echo "PySide6 wird installiert (einmalig, braucht Internet und etwas Zeit) ..."
  "$PY" -m pip install --quiet --upgrade pip || true
  "$PY" -m pip install --quiet -r "$HIER/requirements.txt"
fi
if ! "$PY" -c 'from PySide6.QtWebEngineWidgets import QWebEngineView' 2>/tmp/seiffert-konten-fehler.txt; then
  echo "QtWebEngine konnte nicht geladen werden:"; cat /tmp/seiffert-konten-fehler.txt
  echo "Oft fehlt eine Systembibliothek. Auf Arch hilft meist: sudo pacman -S nss xcb-util-cursor libxkbcommon-x11"
  exit 1
fi

# Programmdateien (alte Fassung wird ersetzt, auch bei Schreibschutz)
chmod -R u+w "$DATA/app" 2>/dev/null || true
rm -rf "$DATA/app"
mkdir -p "$DATA/app"
cp -r "$HIER/seiffert_konten" "$DATA/app/"
chmod -R u+w "$DATA/app"
find "$DATA/app" -name '__pycache__' -type d -prune -exec rm -rf {} + 2>/dev/null || true

# Startbefehl
cat > "$BIN/seiffert-konten" <<LAUNCH
#!/bin/sh
exec "$PY" -c "import sys; sys.path.insert(0, '$DATA/app'); from seiffert_konten.app import main; sys.exit(main())" "\$@"
LAUNCH
chmod +x "$BIN/seiffert-konten"

# Menueeintrag und Symbol
cp "$HIER/seiffert_konten/icon.png" "$ICONS/seiffert-konten.png"
cat > "$APPS/seiffert-konten.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=Seifferts Konten
GenericName=Kontostände
Comment=Wöchentliche Kontostände mit Sicherung auf dem Laptop und in Google Drive
Exec=$BIN/seiffert-konten
Icon=seiffert-konten
Terminal=false
Categories=Office;Finance;
StartupWMClass=seiffert-konten
DESK
update-desktop-database "$APPS" >/dev/null 2>&1 || true
gtk-update-icon-cache -q -t "${XDG_DATA_HOME:-$HOME/.local/share}/icons/hicolor" >/dev/null 2>&1 || true

echo
echo "Fertig. Start: Menue Seifferts Konten oder im Terminal: seiffert-konten"
case ":$PATH:" in *":$BIN:"*) ;; *) echo "Hinweis: $BIN steht nicht im PATH. Das Menue funktioniert trotzdem.";; esac
echo "Daten und Sicherungen liegen im Ordner Dokumente/Seifferts Konten."
echo "Weiteres steht in INSTALLATION.txt."
