"""Referenzfenster (Zwei-Fenster-Ansicht): rechts neben dem Text eine andere Datei nur ansehen.

PDF und Markdown werden direkt angezeigt, Textdateien als Text, alle anderen Formate (Word, ODT, RTF, Präsentationen,
Tabellen) über LibreOffice als PDF. Die Datei wird nie verändert; es gibt weder Bearbeiten noch Speichern.
"""
import os
import shutil
import tempfile

from PySide6.QtCore import QThread, Qt, Signal
from PySide6.QtGui import QFontDatabase
from PySide6.QtWidgets import (QFileDialog, QHBoxLayout, QLabel, QPlainTextEdit, QPushButton, QStackedWidget,
                               QTextBrowser, QVBoxLayout, QWidget)

try:
    from PySide6.QtPdf import QPdfDocument
    from PySide6.QtPdfWidgets import QPdfView
    HAVE_PDF = True
except Exception:
    HAVE_PDF = False

from .builder import base_font
from .readers import ReaderError, find_soffice, lo_convert

MD_EXT = {"md", "markdown", "mdown"}
TEXT_EXT = {"txt", "tex", "latex", "ltx", "sty", "cls", "bib", "log", "csv", "json", "py", "js", "html", "htm", "xml",
            "css", "c", "h", "cpp", "java", "sh", "yml", "yaml", "toml", "ini", "cfg", "conf", "sql"}
FILTER = ("Alle Dateien (*);;PDF (*.pdf);;Markdown (*.md *.markdown);;Word und LibreOffice (*.docx *.doc *.odt *.rtf);;"
          "Präsentationen und Tabellen (*.odp *.pptx *.ppt *.ods *.xlsx *.xls);;Text und LaTeX (*.txt *.tex)")

P_EMPTY, P_PDF, P_MD, P_TEXT = 0, 1, 2, 3


def read_text(path):
    data = open(path, "rb").read()
    if data[:3] == b"\xef\xbb\xbf":
        data = data[3:]
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("windows-1252", "replace")


class _Convert(QThread):
    """LibreOffice im Hintergrund: Datei in PDF umwandeln (damit das Fenster nicht einfriert)."""
    done = Signal(str, str, str)        # Quelle, PDF-Pfad, Fehlertext

    def __init__(self, path, outdir):
        super().__init__()
        self.path, self.outdir = path, outdir

    def run(self):
        try:
            out = lo_convert(self.path, "pdf", self.outdir, profile="seiffert-text-lo-ref")
            self.done.emit(self.path, out, "")
        except ReaderError as e:
            self.done.emit(self.path, "", str(e))
        except Exception as e:                      # unerwartet: nicht das Programm beenden
            self.done.emit(self.path, "", "%s" % e)


class RefPane(QWidget):
    closed = Signal()

    def __init__(self, main=None):
        super().__init__()
        self.main = main
        self.path = None
        self.kind = None
        self.zoom = 1.0
        self.tmp = None
        self.job = None
        self.setAcceptDrops(True)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        head = QWidget()
        hl = QHBoxLayout(head)
        hl.setContentsMargins(6, 3, 6, 3)
        t = QLabel("Referenz:")
        f = t.font()
        f.setBold(True)
        t.setFont(f)
        self.name = QLabel("keine Datei")
        self.name.setMinimumWidth(40)
        hl.addWidget(t)
        hl.addWidget(self.name, 1)
        self.btn_open = QPushButton("Öffnen …")
        self.btn_open.setToolTip("Eine Datei zum Nachschlagen öffnen (Strg+Umschalt+R); sie wird nur angezeigt")
        self.btn_open.clicked.connect(self.choose)
        self.btn_reload = QPushButton("Neu laden")
        self.btn_reload.setToolTip("Datei erneut einlesen (zum Beispiel nach einer Änderung in einem anderen Programm)")
        self.btn_reload.clicked.connect(self.reload)
        self.btn_out = QPushButton("−")
        self.btn_in = QPushButton("+")
        self.btn_fit = QPushButton("Breite")
        self.btn_out.setToolTip("Verkleinern")
        self.btn_in.setToolTip("Vergrößern")
        self.btn_fit.setToolTip("An die Breite des Fensters anpassen")
        self.btn_out.clicked.connect(lambda: self.zoom_by(1 / 1.2))
        self.btn_in.clicked.connect(lambda: self.zoom_by(1.2))
        self.btn_fit.clicked.connect(self.fit)
        self.btn_close = QPushButton("✕")
        self.btn_close.setToolTip("Referenzfenster schließen (F9)")
        self.btn_close.clicked.connect(self.closed.emit)
        for b in (self.btn_open, self.btn_reload, self.btn_out, self.btn_in, self.btn_fit, self.btn_close):
            if b in (self.btn_out, self.btn_in, self.btn_close):
                b.setMaximumWidth(32)
            hl.addWidget(b)
        lay.addWidget(head)

        self.stack = QStackedWidget()
        self.empty = QWidget()
        el = QVBoxLayout(self.empty)
        self.empty_label = QLabel("Hier steht eine Datei zum Nachschlagen, zum Beispiel ein PDF, eine Markdown-Datei "
                                  "oder ein Word-Dokument mit Stichworten.\nSie wird nur angezeigt und nie verändert.\n\n"
                                  "Datei hierher ziehen oder öffnen.")
        self.empty_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.empty_label.setWordWrap(True)
        el.addStretch(1)
        el.addWidget(self.empty_label)
        big = QPushButton("Datei öffnen …")
        big.clicked.connect(self.choose)
        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(big)
        row.addStretch(1)
        el.addLayout(row)
        el.addStretch(1)
        self.stack.addWidget(self.empty)

        self.pdf_doc = self.pdf_view = None
        if HAVE_PDF:
            self.pdf_doc = QPdfDocument(self)
            self.pdf_view = QPdfView()
            self.pdf_view.setDocument(self.pdf_doc)
            self.pdf_view.setPageMode(QPdfView.PageMode.MultiPage)
            self.pdf_view.setZoomMode(QPdfView.ZoomMode.FitToWidth)
            self.stack.addWidget(self.pdf_view)
        else:
            self.stack.addWidget(QLabel("Die PDF-Anzeige (QtPdf) ist in dieser Installation nicht vorhanden."))
        self.md_view = QTextBrowser()
        self.md_view.setOpenLinks(False)
        self.md_view.anchorClicked.connect(self._link)
        self.md_view.document().setDefaultFont(base_font())
        self.md_view.document().setDocumentMargin(14)
        self.stack.addWidget(self.md_view)
        self.text_view = QPlainTextEdit()
        self.text_view.setReadOnly(True)
        self.text_view.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        self.text_view.setFont(QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont))
        self.stack.addWidget(self.text_view)
        lay.addWidget(self.stack, 1)
        self.status = QLabel("")
        self.status.setWordWrap(True)
        self.status.setContentsMargins(6, 2, 6, 2)
        lay.addWidget(self.status)
        self._buttons()

    # ---- Hilfen
    def _buttons(self):
        has = self.path is not None and self.kind is not None
        self.btn_reload.setEnabled(self.path is not None)
        for b in (self.btn_out, self.btn_in):
            b.setEnabled(has)
        self.btn_fit.setEnabled(has and self.kind == P_PDF)

    def _link(self, url):
        if url.scheme() in ("http", "https", "mailto"):
            import webbrowser
            webbrowser.open(url.toString())

    def _cleanup(self):
        if self.tmp:
            shutil.rmtree(self.tmp, ignore_errors=True)
            self.tmp = None

    def shutdown(self):
        """Beim Beenden: laufende Umwandlung abwarten und temporäre Dateien entfernen."""
        if self.job is not None:
            try:
                self.job.done.disconnect()
            except Exception:
                pass
            self.job.wait(5000)
            self.job = None
        self._cleanup()

    # ---- Öffnen
    def choose(self):
        start = os.path.dirname(self.path) if self.path else (
            self.main.settings.get("ref_dir", "") if self.main is not None else "")
        p, _ = QFileDialog.getOpenFileName(self, "Referenzdatei öffnen (wird nur angezeigt)", start, FILTER)
        if p:
            self.open_file(p)

    def reload(self):
        if self.path:
            self.open_file(self.path)

    def open_file(self, path):
        path = os.path.abspath(path)
        if not os.path.isfile(path):
            self.status.setText("Die Datei gibt es nicht: %s" % path)
            return False
        if self.main is not None:
            self.main.settings["ref_dir"] = os.path.dirname(path)
        ext = os.path.splitext(path)[1].lower().lstrip(".")
        if self.job is not None:                         # laufende Umwandlung verwerfen
            try:
                self.job.done.disconnect()
            except Exception:
                pass
            self.job = None
        try:
            if ext == "pdf":
                return self._show_pdf(path, path)
            if ext in MD_EXT:
                self.md_view.setMarkdown(read_text(path))
                return self._shown(path, P_MD, "Markdown-Ansicht (Formeln werden nicht dargestellt)")
            if ext in TEXT_EXT:
                self.text_view.setPlainText(read_text(path))
                return self._shown(path, P_TEXT, "Text")
        except Exception as e:
            self.status.setText("Die Datei lässt sich nicht öffnen: %s" % e)
            return False
        # alles andere über LibreOffice als PDF
        if not find_soffice():
            self.status.setText("Für dieses Format wird LibreOffice gebraucht; es wurde nicht gefunden.")
            return False
        self._cleanup()
        self.tmp = tempfile.mkdtemp(prefix="st-ref-")
        self.path, self.kind = path, None
        self.name.setText(os.path.basename(path))
        self.empty_label.setText("%s wird mit LibreOffice umgewandelt …" % os.path.basename(path))
        self.stack.setCurrentIndex(P_EMPTY)
        self.status.setText("Umwandlung läuft; das kann einen Moment dauern.")
        self.job = _Convert(path, self.tmp)
        self.job.done.connect(self._converted)
        self.job.start()
        self._buttons()
        return True

    def _converted(self, src, out, err):
        self.job = None
        if src != self.path:
            return
        if err or not out:
            self.empty_label.setText("Die Datei lässt sich nicht anzeigen.")
            self.status.setText(err or "Umwandlung fehlgeschlagen.")
            return
        self._show_pdf(out, src, via_lo=True)

    def _show_pdf(self, pdf_path, shown_path, via_lo=False):
        if not HAVE_PDF:
            self.status.setText("Die PDF-Anzeige (QtPdf) ist in dieser Installation nicht vorhanden.")
            return False
        self.pdf_doc.load(pdf_path)
        if self.pdf_doc.pageCount() <= 0:
            self.status.setText("Das PDF konnte nicht gelesen werden (kennwortgeschützt oder beschädigt?).")
            return False
        self.pdf_view.setZoomMode(QPdfView.ZoomMode.FitToWidth)
        return self._shown(shown_path, P_PDF, ("Über LibreOffice als PDF angezeigt (Seitenumbrüche wie beim Drucken)"
                                               if via_lo else "PDF, %d Seite(n)" % self.pdf_doc.pageCount()))

    def _shown(self, path, page, note):
        self.path, self.kind = path, page
        self.name.setText(os.path.basename(path))
        self.name.setToolTip(path)
        self.stack.setCurrentIndex(page)
        self.status.setText(note + ". Nur Ansicht, die Datei wird nicht verändert.")
        self._buttons()
        return True

    # ---- Zoom
    def zoom_by(self, f):
        if self.kind == P_PDF and self.pdf_view is not None:
            self.zoom = max(0.2, min(6.0, self.zoom * f))
            self.pdf_view.setZoomMode(QPdfView.ZoomMode.Custom)
            self.pdf_view.setZoomFactor(self.zoom)
        elif self.kind == P_MD:
            (self.md_view.zoomIn if f > 1 else self.md_view.zoomOut)(1)
        elif self.kind == P_TEXT:
            (self.text_view.zoomIn if f > 1 else self.text_view.zoomOut)(1)

    def fit(self):
        if self.kind == P_PDF and self.pdf_view is not None:
            self.pdf_view.setZoomMode(QPdfView.ZoomMode.FitToWidth)
            self.zoom = 1.0

    # ---- Ziehen
    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        for u in e.mimeData().urls():
            if u.isLocalFile():
                self.open_file(u.toLocalFile())
                break
