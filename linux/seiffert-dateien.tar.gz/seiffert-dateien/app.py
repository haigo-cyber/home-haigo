#!/usr/bin/env python3
"""Seifferts Dateien - Programmfenster (Qt WebEngine) mit Python-Backend.

Start:  python3 app.py [Ordner]
Benötigt: PySide6 mit QtWebEngine. Optional: poppler (pdftotext) für PDF im Volltext.
"""
from __future__ import annotations

import base64
import json
import os
import sys
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

try:
    from PySide6.QtCore import QBuffer, QByteArray, QIODevice, QMimeData, QObject, QProcess, QSize, QTimer, QUrl, Qt, Signal, Slot
    from PySide6.QtGui import QColor, QGuiApplication, QIcon, QImageReader, QKeySequence, QShortcut
    from PySide6.QtNetwork import QLocalServer, QLocalSocket
    from PySide6.QtWebChannel import QWebChannel
    from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineProfile, QWebEngineSettings
    from PySide6.QtWebEngineWidgets import QWebEngineView
    from PySide6.QtWidgets import QApplication, QFileDialog, QMainWindow
except ImportError as exc:  # pragma: no cover
    sys.stderr.write(
        "PySide6 mit QtWebEngine fehlt (%s).\n"
        "Auf Arch zum Beispiel:  sudo pacman -S pyside6 qt6-webengine\n"
        "oder in einer virtuellen Umgebung:  pip install PySide6 PySide6-WebEngine\n" % exc)
    sys.exit(1)

import backend as B

APP_NAME = "Seifferts Dateien"
INDEX_HTML = os.path.join(HERE, "index.html")


def qt_thumbnailer(path: str, edge: int):
    """Verkleinert ein Bild mit Qt (auch in Arbeitsthreads erlaubt). Gibt (Bytes, MIME, Breite, Höhe) oder None zurück."""
    r = QImageReader(path)
    r.setAutoTransform(True)
    if not r.canRead():
        return None
    sz = r.size()
    w0, h0 = sz.width(), sz.height()
    if w0 > 0 and h0 > 0 and max(w0, h0) > edge:
        k = edge / max(w0, h0)
        r.setScaledSize(QSize(max(1, round(w0 * k)), max(1, round(h0 * k))))
    img = r.read()
    if img.isNull():
        return None
    if max(img.width(), img.height()) > edge:
        img = img.scaled(edge, edge, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
    if w0 <= 0 or h0 <= 0:
        w0, h0 = img.width(), img.height()
    elif w0 != h0 and (w0 > h0) != (img.width() > img.height()):   # Drehung durch EXIF
        w0, h0 = h0, w0
    buf = QBuffer()
    buf.open(QIODevice.OpenModeFlag.WriteOnly)
    alpha = img.hasAlphaChannel()
    if not img.save(buf, "PNG" if alpha else "JPEG", -1 if alpha else 85):
        return None
    return bytes(buf.data()), "image/png" if alpha else "image/jpeg", w0, h0


WINDOWS: list = []          # alle offenen Programmfenster; Ereignisse des Backends gehen an alle


def broadcast(name: str, data) -> None:
    txt = json.dumps(data, default=str)
    for w in list(WINDOWS):
        try:
            w.bridge.event.emit(name, txt)
        except Exception:  # noqa: BLE001 - ein Fenster in der Schließphase darf die anderen nicht stören
            pass


class Bridge(QObject):
    """Verbindung zwischen der Oberfläche (JavaScript) und dem Python-Backend."""

    done = Signal(int, str)
    event = Signal(str, str)

    def __init__(self, backend: B.Backend, window: "MainWindow") -> None:
        super().__init__(window)
        self.backend = backend
        self.window = window
        self.pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="sd")
        backend.emit = broadcast

    def _run(self, cid: int, method: str, args: dict) -> None:
        try:
            res = {"result": self.backend.call(method, args, cid)}
        except B.AppError as e:
            res = {"error": str(e)}
        except Exception as e:  # noqa: BLE001 - Oberfläche bekommt immer eine Antwort
            res = {"error": "Interner Fehler: %s: %s" % (type(e).__name__, e)}
        self.done.emit(cid, json.dumps(res, default=str))

    @Slot(int, str, str)
    def invoke(self, cid: int, method: str, args_json: str) -> None:
        try:
            args = json.loads(args_json) if args_json else {}
        except ValueError:
            args = {}
        try:
            self.pool.submit(self._run, cid, method, args)
        except RuntimeError:
            pass  # Fenster wird gerade geschlossen, Antwort wird nicht mehr gebraucht

    @Slot(int)
    def cancel(self, cid: int) -> None:
        self.backend.cancel(cid)

    @Slot(str, result=str)
    def pick_dir(self, start: str) -> str:
        return QFileDialog.getExistingDirectory(self.window, "Ordner wählen", start or os.path.expanduser("~")) or ""

    @Slot(str, result=str)
    def pick_file(self, start: str) -> str:
        start = start if os.path.isdir(start or "") else os.path.dirname(start or "") or os.path.expanduser("~")
        return QFileDialog.getOpenFileName(self.window, "Datei wählen", start)[0] or ""

    @Slot(str, result=str)
    def pick_image(self, start: str) -> str:
        start = start if os.path.isdir(start or "") else os.path.dirname(start or "") or os.path.expanduser("~")
        return QFileDialog.getOpenFileName(self.window, "Bild wählen", start,
                                           "Bilder (*.png *.jpg *.jpeg *.gif *.webp *.bmp *.tif *.tiff *.avif);;Alle Dateien (*)")[0] or ""

    @Slot(float, result=bool)
    def set_window_opacity(self, value: float) -> bool:
        """Deckkraft des ganzen Fensters (braucht einen Fenstermanager mit Compositing, bei Cinnamon der Fall)."""
        self.window.setWindowOpacity(max(0.35, min(1.0, float(value))))
        return True

    @Slot(result=bool)
    def restart_app(self) -> bool:
        QTimer.singleShot(50, self.window.restart)
        return True

    @Slot(result=bool)
    def quit_app(self) -> bool:
        """Kreuz oben rechts und Alt+X: schließt alle Fenster von Seifferts Dateien und beendet das Programm."""
        QTimer.singleShot(0, self.window.quit_all)
        return True

    @Slot(result=bool)
    def toggle_fullscreen(self) -> bool:
        """F11: Vollbild ein oder aus. Gibt den neuen Zustand zurück (True = Vollbild)."""
        return self.window.toggle_fullscreen()

    @Slot(str, result=bool)
    def new_window(self, path: str) -> bool:
        """Strg+N: weiteres Programmfenster, optional in einem bestimmten Ordner."""
        return self.window.open_new_window(path)

    @Slot(result=bool)
    def is_fullscreen(self) -> bool:
        return self.window.isFullScreen()

    @Slot(result=bool)
    def window_translucent(self) -> bool:
        return self.window.translucent

    @Slot(str, result=bool)
    def copy_text(self, text: str) -> bool:
        QGuiApplication.clipboard().setText(text)
        return True

    @Slot(str, str, result=bool)
    def clip_set(self, op: str, paths_json: str) -> bool:
        """Dateien in die Zwischenablage legen, lesbar für Nemo, Dolphin und andere (gnome-copied-files, uri-list)."""
        try:
            paths = [p for p in json.loads(paths_json) if isinstance(p, str)]
        except ValueError:
            return False
        if not paths:
            return False
        urls = [QUrl.fromLocalFile(p) for p in paths]
        cut = op == "cut"
        md = QMimeData()
        md.setUrls(urls)
        md.setText("\n".join(paths))
        md.setData("x-special/gnome-copied-files", QByteArray(("cut" if cut else "copy") + "\n" + "\n".join(u.toString() for u in urls)))
        md.setData("application/x-kde-cutselection", QByteArray(b"1" if cut else b"0"))
        QGuiApplication.clipboard().setMimeData(md)
        return True

    @Slot(result=str)
    def clip_get(self) -> str:
        md = QGuiApplication.clipboard().mimeData()
        op, paths = "copy", []
        if md is not None:
            if md.hasFormat("x-special/gnome-copied-files"):
                lines = bytes(md.data("x-special/gnome-copied-files")).decode("utf-8", "replace").splitlines()
                if lines:
                    op = "cut" if lines[0].strip() == "cut" else "copy"
                    paths = [QUrl(u).toLocalFile() for u in lines[1:] if u.strip().startswith("file:")]
            elif md.hasUrls():
                paths = [u.toLocalFile() for u in md.urls() if u.isLocalFile()]
                if md.hasFormat("application/x-kde-cutselection") and bytes(md.data("application/x-kde-cutselection")).strip() == b"1":
                    op = "cut"
            elif md.hasText():
                cand = [t.strip() for t in md.text().splitlines() if t.strip()]
                if cand and len(cand) <= 500 and all(os.path.isabs(t) and os.path.lexists(t) for t in cand):
                    paths = cand
        return json.dumps({"op": op, "paths": [p for p in paths if p]})

    @Slot(result=str)
    def clip_text(self) -> str:
        return QGuiApplication.clipboard().text() or ""

    @Slot(result=bool)
    def clip_clear(self) -> bool:
        QGuiApplication.clipboard().clear()
        return True

    @Slot(result=int)
    def system_dark(self) -> int:
        try:
            cs = QGuiApplication.styleHints().colorScheme()
            return 1 if cs == Qt.ColorScheme.Dark else 0 if cs == Qt.ColorScheme.Light else -1
        except Exception:  # noqa: BLE001
            return -1


class Page(QWebEnginePage):
    def __init__(self, profile: QWebEngineProfile, parent, backend: B.Backend) -> None:
        super().__init__(profile, parent)
        self.backend = backend
        self.debug = bool(os.environ.get("SD_DEBUG"))

    def acceptNavigationRequest(self, url: QUrl, nav_type, is_main_frame: bool) -> bool:
        if url.isLocalFile() and os.path.abspath(url.toLocalFile()) == INDEX_HTML:
            return True
        if url.scheme() in ("http", "https", "mailto"):
            try:
                self.backend.api_open_url(url.toString())
            except B.AppError:
                pass
        return False

    def createWindow(self, _type):  # keine Zusatzfenster
        return None

    def javaScriptConsoleMessage(self, level, message, line, source):
        if self.debug or "Error" in message:
            sys.stderr.write("[js] %s (%s:%s)\n" % (message, os.path.basename(source or ""), line))


class MainWindow(QMainWindow):
    def __init__(self, backend: B.Backend, secondary: bool = False) -> None:
        super().__init__()
        self.backend = backend
        self.secondary = secondary
        backend.thumbnailer = qt_thumbnailer
        self.setWindowTitle(APP_NAME)
        icon = os.path.join(HERE, "seiffert-dateien.svg")
        if os.path.exists(icon):
            self.setWindowIcon(QIcon(icon))
        self.resize(1240, 800)
        geo = backend.cfg.get("geometry")
        if geo and not secondary:
            try:
                self.restoreGeometry(QByteArray(base64.b64decode(geo)))
            except Exception:  # noqa: BLE001
                pass
        # Durchscheinendes Fenster: muss vor dem ersten Anzeigen festgelegt werden, daher nur beim Start wählbar
        self.translucent = bool(backend.cfg.get("translucent"))
        if self.translucent:
            self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        else:
            self.setWindowOpacity(max(0.35, min(1.0, int(backend.cfg.get("opacity", 100)) / 100)))
        self.profile = QWebEngineProfile(self)          # ohne Namen: nichts wird auf der Platte zwischengespeichert
        self.view = QWebEngineView(self)
        self.page = Page(self.profile, self.view, backend)
        self.view.setPage(self.page)
        if self.translucent:
            self.page.setBackgroundColor(QColor(0, 0, 0, 0))
            self.view.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
            self.view.setStyleSheet("background: transparent")
        s = self.page.settings()
        s.setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessRemoteUrls, False)
        s.setAttribute(QWebEngineSettings.WebAttribute.PluginsEnabled, False)
        self.bridge = Bridge(backend, self)
        WINDOWS.append(self)
        self.channel = QWebChannel(self.page)
        self.channel.registerObject("bridge", self.bridge)
        self.page.setWebChannel(self.channel)
        self.view.titleChanged.connect(lambda t: self.setWindowTitle(t or APP_NAME))
        self.setCentralWidget(self.view)
        self.view.load(QUrl.fromLocalFile(INDEX_HTML))
        # Alt+X beendet das Programm, auch wenn die Seite die Taste nicht bekommt (Zweitweg neben dem Tastendruck in der Seite)
        self.quit_key = QShortcut(QKeySequence("Alt+X"), self)
        self.quit_key.setContext(Qt.ShortcutContext.WindowShortcut)
        self.quit_key.activated.connect(lambda: self.quit_all() if self.backend.surface_alt_x() else None)

    def open_new_window(self, path: str = "") -> bool:
        w = MainWindow(self.backend, secondary=True)
        g = self.geometry()
        w.resize(g.width(), g.height())
        w.move(g.x() + 36, g.y() + 36)
        w.show()
        w.raise_()
        w.activateWindow()
        if path and os.path.isdir(path):
            w.open_in_app(path)
        return True

    def quit_all(self) -> None:
        """Beendet das ganze Programm: alle Fenster schließen; das letzte sichert die Einstellungen und stoppt Terminals und Index."""
        if getattr(QApplication.instance(), "sd_quitting", False):
            return
        QApplication.instance().sd_quitting = True
        for w in list(WINDOWS):
            w.close()
        if not WINDOWS:
            QApplication.instance().quit()

    def run_when_ready(self, js_call: str, tries: int = 40) -> None:
        """Führt JavaScript aus, sobald die Seite geladen ist (window.SD_READY)."""
        def cb(ok):
            if not ok and tries > 0:
                QTimer.singleShot(250, lambda: self.run_when_ready(js_call, tries - 1))
        self.page.runJavaScript("(window.SD_READY && window.sdCommand) ? (%s, true) : false" % js_call, cb)

    def toggle_fullscreen(self) -> bool:
        if self.isFullScreen():
            self.showMaximized() if getattr(self, "_max_before_full", False) else self.showNormal()
        else:
            self._max_before_full = self.isMaximized()
            self.showFullScreen()
        return self.isFullScreen()

    def open_in_app(self, path: str, tries: int = 40, select: str = "") -> None:
        js = "(window.SD_READY && window.openPath) ? (window.openPath(%s, %s), true) : false" % (json.dumps(path), json.dumps(select))
        def cb(ok):
            if not ok and tries > 0:
                QTimer.singleShot(250, lambda: self.open_in_app(path, tries - 1, select))
        self.page.runJavaScript(js, cb)

    def restart(self) -> None:
        """Startet das Programm neu (nötig, damit das durchscheinende Fenster umgeschaltet werden kann)."""
        app = QApplication.instance()
        server = getattr(app, "sd_server", None)
        if server is not None:                       # sonst meldet sich die neue Instanz bei der alten
            server.close()
            QLocalServer.removeServer(server.fullServerName())
        try:
            self.backend.api_set_config({"geometry": base64.b64encode(bytes(self.saveGeometry())).decode()})
        except Exception:  # noqa: BLE001
            pass
        self.backend.shutdown()
        QProcess.startDetached(sys.executable, [os.path.abspath(__file__)])
        self._restarting = True
        app.quit()

    def closeEvent(self, ev) -> None:  # noqa: N802
        if self in WINDOWS:
            WINDOWS.remove(self)
        if WINDOWS:                                   # andere Fenster laufen weiter, Backend und Terminals bleiben
            super().closeEvent(ev)
            return
        try:
            self.backend.api_set_config({"geometry": base64.b64encode(bytes(self.saveGeometry())).decode()})
        except Exception:  # noqa: BLE001
            pass
        self.backend.shutdown()
        super().closeEvent(ev)


NEW_WINDOW = "\x1dnew"          # Anfang einer Nachricht an die laufende Instanz: ein neues Fenster öffnen
SETTINGS_MSG = "\x1dsettings"   # Nachricht: Einstellungsdialog öffnen (Rest nach \x1f: "surface", "starter", "" = allgemein)


def handle_message(raw: str, target: "MainWindow | None") -> bool:
    """Nachricht einer weiteren Start-Anfrage oder des Starters: neues Fenster oder Ordner im Fenster öffnen."""
    if target is None:
        return False
    if raw.startswith(NEW_WINDOW):
        target.open_new_window(raw[len(NEW_WINDOW):].lstrip("\x1f").strip())
        return True
    if raw.startswith(SETTINGS_MSG):
        what = raw[len(SETTINGS_MSG):].lstrip("\x1f").strip()
        target.setWindowState(target.windowState() & ~Qt.WindowState.WindowMinimized)
        target.show(); target.raise_(); target.activateWindow()
        target.run_when_ready("window.sdCommand(%s)" % json.dumps("settings:" + what if what in ("surface", "starter") else "settings"))
        return True
    p, _, sel = raw.partition("\x1f")
    target.setWindowState(target.windowState() & ~Qt.WindowState.WindowMinimized)
    target.show(); target.raise_(); target.activateWindow()
    if p and p != "-":
        target.open_in_app(p, select=sel)
    return True


def main(argv: list[str]) -> int:
    """Start: Läuft das Programm schon, öffnet ein weiterer Start ein neues Fenster (mit Ordner, falls angegeben).
    Mit --reuse wird stattdessen das zuletzt benutzte Fenster verwendet. Alle Fenster teilen sich Einstellungen,
    Index und Terminals in einem Prozess."""
    start_path = ""
    reuse = "--reuse" in argv[1:]
    settings = next((a.split("=", 1)[1] for a in argv[1:] if a.startswith("--settings=")), None)
    argv = [argv[0]] + [a for a in argv[1:] if not a.startswith("--settings")]
    args = [a for a in argv[1:] if not a.startswith("-")]
    if args:
        start_path = os.path.abspath(os.path.expanduser(args[0]))
    app = QApplication([argv[0]] + [a for a in argv[1:] if a.startswith("-") and a not in ("--reuse", "--new-window")])
    app.setApplicationName(APP_NAME)
    app.setDesktopFileName("seiffert-dateien")

    name = "%s-%s" % (B.APP_ID, os.getuid() if hasattr(os, "getuid") else "user")
    sock = QLocalSocket()
    sock.connectToServer(name)
    if sock.waitForConnected(300):
        msg = (SETTINGS_MSG + "\x1f" + settings) if settings is not None else (start_path or "-") if reuse else NEW_WINDOW + "\x1f" + start_path
        sock.write(msg.encode("utf-8"))
        sock.flush()
        sock.waitForBytesWritten(500)
        return 0
    QLocalServer.removeServer(name)
    server = QLocalServer()
    server.listen(name)
    app.sd_server = server

    backend = B.Backend()
    win = MainWindow(backend)
    win.show()

    def current() -> "MainWindow | None":
        a = QApplication.activeWindow()
        if isinstance(a, MainWindow) and a in WINDOWS:
            return a
        return WINDOWS[-1] if WINDOWS else None

    def on_connection() -> None:
        c = server.nextPendingConnection()
        if not c:
            return
        def read() -> None:
            handle_message(bytes(c.readAll()).decode("utf-8", "replace").strip(), current())
            c.disconnectFromServer()
        c.readyRead.connect(read)
    server.newConnection.connect(on_connection)
    if start_path:
        win.open_in_app(start_path)
    if settings is not None:
        win.run_when_ready("window.sdCommand(%s)" % json.dumps("settings:" + settings if settings in ("surface", "starter") else "settings"))
    code = app.exec()
    server.close()
    return code


if __name__ == "__main__":
    sys.exit(main(sys.argv))
