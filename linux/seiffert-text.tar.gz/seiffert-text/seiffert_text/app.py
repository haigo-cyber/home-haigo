"""Seifferts Text: Hauptfenster mit drei Ansichten (Formatiert, Markdown, LaTeX)."""
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

from PySide6.QtCore import QFileSystemWatcher, QProcess, QProcessEnvironment, QSize, Qt, QTimer, QUrl
from PySide6.QtGui import (QAction, QActionGroup, QFont, QIcon, QImage, QKeySequence, QPixmap,
                           QTextBlockFormat, QTextCharFormat, QTextCursor, QTextDocument, QTextFormat,
                           QTextListFormat, QTextTableFormat, QTextLength, QPageSize, QPageLayout,
                           QBrush, QColor)
from PySide6.QtWidgets import (QApplication, QColorDialog, QComboBox, QDialog, QDialogButtonBox, QFileDialog,
                               QFormLayout, QHBoxLayout, QInputDialog, QLabel, QMainWindow, QMenu, QMessageBox,
                               QPlainTextEdit, QPushButton, QSpinBox, QSplitter, QStackedWidget,
                               QTextBrowser, QToolBar, QToolButton, QVBoxLayout, QWidget, QCheckBox)

from . import APP_NAME, VERSION
from .odt_patch import OdtSource, PatchError, is_own_file, norm
from .builder import (apply_heading, base_font, build_document, code_block_formats, heading_formats,
                      raw_block_formats, raw_inline_format, char_format)
from .common import BOX_CHECK, BOX_CROSS, BOX_EMPTY, DEFAULT_PREAMBLE, LS, PROP_RAW_BLOCK
from .highlight import LatexHighlighter, MarkdownHighlighter
from .latex_in import parse_latex
from .latex_out import export_latex
from .md_io import markdown_with_images
from .odt_out import write_odt
from .readers import ReaderError, find_soffice, read_any, lo_convert
from .widgets import FindBar, RichEdit, SourceEdit, insert_image_into
from . import quick as Q
from .quick_view import QuickPage
from .tabs import (TAB_COLORS, ColorTabBar, Tab, file_sig, find_texstudio, launch_texstudio,
                   next_free_color)

try:
    from PySide6.QtPdf import QPdfDocument
    from PySide6.QtPdfWidgets import QPdfView
    HAVE_PDF = True
except Exception:   # pragma: no cover
    HAVE_PDF = False

CONF_DIR = os.path.join(os.path.expanduser("~"), ".config", "seiffert-text")
CONF_FILE = os.path.join(CONF_DIR, "settings.json")
MD_EXT = (".md", ".markdown", ".mdown", ".txt.md")
OPEN_FILTER = ("Alle unterstützten Dateien (*.odt *.ott *.md *.markdown *.tex *.docx *.docm *.dotx *.doc *.rtf "
               "*.xlsx *.xlsm *.xls *.ods *.csv *.tsv *.odp *.pptx *.ppt *.sxw *.txt *.pdf);;"
               "Texte (*.odt *.ott *.md *.markdown *.tex *.txt);;"
               "Word (*.docx *.docm *.dotx *.doc *.rtf);;"
               "Excel und Tabellen (*.xlsx *.xlsm *.xls *.ods *.csv *.tsv);;"
               "Präsentationen (*.odp *.pptx *.ppt);;"
               "PDF (*.pdf);;"
               "OpenOffice 1.x (*.sxw *.sxc *.sxi);;Alle Dateien (*)")
SAVE_FILTERS = {
    "OpenDocument-Text (*.odt)": ".odt",
    "Markdown (*.md)": ".md",
    "LaTeX (*.tex)": ".tex",
    "PDF über LaTeX (*.pdf)": ".pdf",
    "Word (*.docx) über LibreOffice": ".docx",
    "HTML (*.html)": ".html",
}


def load_settings():
    d = {"engine": "pdflatex", "recent": [], "foreign_to_latex": True, "zoom": 0, "auto_compile": False}
    try:
        with open(CONF_FILE, encoding="utf-8") as f:
            d.update(json.load(f))
    except Exception:
        pass
    return d


def save_settings(d):
    try:
        os.makedirs(CONF_DIR, exist_ok=True)
        with open(CONF_FILE + ".tmp", "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=1)
        os.replace(CONF_FILE + ".tmp", CONF_FILE)
    except Exception:
        pass


def app_icon():
    here = os.path.dirname(__file__)
    ic = QIcon()
    for sz in (32, 48, 64, 128, 256):
        p = os.path.join(here, "icons", "icon-%d.png" % sz)
        if os.path.exists(p):
            ic.addFile(p, QSize(sz, sz))
    return ic


VIEW_RICH, VIEW_MD, VIEW_TEX, VIEW_QUICK = 0, 1, 2, 3

# Alles, was zu einem Dokument gehört und beim Wechsel des Tabs weggelegt und wieder geholt wird.
STATE_ATTRS = ("odt_src", "odt_lock", "path", "kind", "source_note", "preamble", "rev", "md_synced",
               "tex_synced", "md_dirty", "tex_dirty", "modified", "view", "last_images", "md_images", "work",
               "pdf_after", "last_pdf", "pdf_loaded", "prev_loaded", "prev_rev", "disk_sig", "ext_changed",
               "compile_pass", "tex_eol", "q_doc", "q_undo", "q_redo", "q_last", "q_collapsed", "q_text_sig",
               "q_original", "q_headnames", "q_tpl", "q_tpl_key", "q_name", "q_name_auto", "q_dir", "q_wrote")
Q_DEFAULTS = dict(tex_eol="\n", q_doc=None, q_undo=[], q_redo=[], q_last="", q_collapsed=set(), q_text_sig=None,
                  q_original="", q_headnames=[], q_tpl="", q_tpl_key="", q_name="", q_name_auto=True, q_dir=None,
                  q_wrote=None)
TEXT_EXT = (".tex", ".md", ".markdown", ".mdown")


class MainWindow(QMainWindow):
    def __init__(self, files=None):
        super().__init__()
        self.settings = load_settings()
        self.setWindowIcon(app_icon())
        self.setAcceptDrops(True)
        self.odt_src = None         # Quelle für formaterhaltendes Speichern fremder ODT-Dateien
        self.odt_lock = ""
        self.path = None            # Datei, in die „Speichern“ schreibt
        self.kind = "odt"           # odt, md, tex
        self.source_note = ""       # z. B. „aus Rechnung.docx“
        self.preamble = DEFAULT_PREAMBLE
        self.rev = 0
        self.md_synced = -1
        self.tex_synced = -1
        self.md_dirty = False
        self.tex_dirty = False
        self.modified = False
        self._loading = False
        self.view = VIEW_RICH
        for k, v in Q_DEFAULTS.items():
            setattr(self, k, type(v)() if isinstance(v, (list, set)) else v)
        self.last_images = {}
        self.md_images = {}
        self.work = tempfile.mkdtemp(prefix="seiffert-text-")
        self.proc = None
        self.pdf_after = None
        self.compile_rev = -2
        self.compile_text = None
        self.compile_pass = 0
        self.last_pdf = None
        self.pdf_loaded = None          # zuletzt in der LaTeX-Ansicht geladene PDF-Kopie
        self.prev_loaded = None         # zuletzt in der Vorschau geladene PDF-Kopie
        self.prev_rev = -1              # Stand des Dokuments, zu dem die Vorschau gehört
        self.prev_rev_next = -1
        self.disk_sig = None            # (Zeit, Größe) der Datei nach dem letzten Lesen oder Speichern
        self.ext_changed = False        # Datei wurde von einem anderen Programm geändert
        self.tabs = {}
        self.cur = None                 # Tab, dessen Textzustand in den Editoren geladen ist (immer ein Text-Tab)
        self.cur_pdf = None             # gerade angezeigter PDF-Tab, sonst None
        self._chrome = []               # beim PDF-Tab ausgeblendete Leisten
        self._suspended = {}            # beim PDF-Tab abgeschaltete Tastenkürzel des Hauptfensters
        self._bar_lock = 0
        self._switching = False

        self.rich = RichEdit()
        self.doc = self.rich.document()
        self.doc.setDefaultFont(base_font())
        self.doc.setDocumentMargin(24)
        self.md_edit = SourceEdit()
        self.tex_edit = SourceEdit()
        dark = self.palette().window().color().lightness() < 128
        self.md_hl = MarkdownHighlighter(self.md_edit.document(), dark)
        self.tex_hl = LatexHighlighter(self.tex_edit.document(), dark)
        self.md_view = QTextBrowser()
        self.md_view.setOpenExternalLinks(False)
        self.md_view.setOpenLinks(False)
        self.md_view.anchorClicked.connect(lambda u: __import__("webbrowser").open(u.toString())
                                           if u.scheme() in ("http", "https", "mailto") else None)
        self.md_view.document().setDefaultFont(base_font())

        self.children_windows = []      # Tabellen- und PDF-Fenster
        self.rich_split = QSplitter()
        self.rich_split.addWidget(self.rich)
        self.prev_panel = QWidget()
        pl = QVBoxLayout(self.prev_panel)
        pl.setContentsMargins(0, 0, 0, 0)
        pl.setSpacing(2)
        row = QHBoxLayout()
        self.prev_btn = QPushButton("Aktualisieren")
        self.prev_btn.clicked.connect(lambda: self.refresh_preview(True))
        self.prev_note = QLabel("")
        self.prev_note.setWordWrap(True)
        row.addWidget(self.prev_btn)
        row.addWidget(self.prev_note, 1)
        pl.addLayout(row)
        self.prev_doc = self.prev_view = None
        if HAVE_PDF:
            self.prev_doc = QPdfDocument(self)
            self.prev_view = QPdfView()
            self.prev_view.setDocument(self.prev_doc)
            self.prev_view.setPageMode(QPdfView.PageMode.MultiPage)
            self.prev_view.setZoomMode(QPdfView.ZoomMode.FitToWidth)
            pl.addWidget(self.prev_view, 1)
        self.rich_split.addWidget(self.prev_panel)
        self.rich_split.setStretchFactor(0, 1)
        self.rich_split.setStretchFactor(1, 1)
        self.prev_panel.hide()
        self.prev_proc = None
        self.prev_pending = False
        self.prev_n = 0
        self.prev_timer = QTimer(self)
        self.prev_timer.setSingleShot(True)
        self.prev_timer.setInterval(1800)
        self.prev_timer.timeout.connect(self.refresh_preview)
        self.stack = QStackedWidget()
        self.stack.addWidget(self.rich_split)
        self.md_split = QSplitter()
        self.md_split.addWidget(self.md_edit)
        self.md_split.addWidget(self.md_view)
        self.md_split.setSizes([500, 500])
        self.stack.addWidget(self.md_split)
        self.stack.addWidget(self._build_tex_page())
        self.quick = QuickPage(self)
        self.stack.addWidget(self.quick)

        self.find_bar = FindBar()
        self.find_bar.target = self.active_text
        central = QWidget()
        lay = QVBoxLayout(central)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        self.tabbar = ColorTabBar()
        self.tabbar.color_of = self._tab_color_at
        self.tabbar.currentChanged.connect(self._on_bar_changed)
        self.tabbar.tabCloseRequested.connect(self.close_tab)
        self.tabbar.contextRequested.connect(self._tab_menu)
        self.tabbar.emptyDoubleClicked.connect(self.cmd_new)
        self.tabbar.tabMoved.connect(lambda *_: self.tabbar.update())
        self.btn_newtab = QToolButton()
        self.btn_newtab.setText("+")
        self.btn_newtab.setAutoRaise(True)
        self.btn_newtab.setToolTip("Neues Dokument in einem neuen Tab (Strg+N)")
        self.btn_newtab.clicked.connect(self.cmd_new)
        tabrow = QHBoxLayout()
        tabrow.setContentsMargins(0, 0, 0, 0)
        tabrow.setSpacing(0)
        tabrow.addWidget(self.tabbar, 1)
        tabrow.addWidget(self.btn_newtab)
        lay.addLayout(tabrow)
        lay.addWidget(self.stack, 1)
        lay.addWidget(self.find_bar)
        self.setCentralWidget(central)
        self.watcher = QFileSystemWatcher(self)
        self.watcher.fileChanged.connect(self._file_changed)
        self._watch_timer = QTimer(self)
        self._watch_timer.setSingleShot(True)
        self._watch_timer.setInterval(350)
        self._watch_timer.timeout.connect(self._check_external)
        self._watch_paths = set()

        self._build_actions()
        self._build_menus()
        self._build_toolbars()
        self.status = self.statusBar()
        self.lbl_info = QLabel("")
        self.lbl_view = QLabel("")
        self.status.addPermanentWidget(self.lbl_info)
        self.status.addPermanentWidget(self.lbl_view)

        self.doc.contentsChanged.connect(self.on_doc_changed)
        self.md_edit.textChanged.connect(self.on_md_changed)
        self.tex_edit.textChanged.connect(self.on_tex_changed)
        self.rich.cursorPositionChanged.connect(self.sync_format_state)
        self.rich.currentCharFormatChanged.connect(lambda *_: self.sync_format_state())
        self.md_edit.cursorPositionChanged.connect(self.update_info)
        self.tex_edit.cursorPositionChanged.connect(self.update_info)

        self.md_timer = QTimer(self)
        self.md_timer.setSingleShot(True)
        self.md_timer.setInterval(300)
        self.md_timer.timeout.connect(self.update_md_preview)
        self.auto_timer = QTimer(self)
        self.auto_timer.setSingleShot(True)
        self.auto_timer.setInterval(2500)
        self.auto_timer.timeout.connect(lambda: self.compile(silent=True))

        self.new_document(first=True)
        self.set_view(VIEW_RICH)
        first = Tab(next_free_color([]))
        first.doc = self.doc
        self.tabs[first.id] = first
        self.cur = first
        self._bar_lock += 1
        self.tabbar.addTab("Unbenannt")
        self.tabbar.setTabData(0, first.id)
        self._bar_lock -= 1
        self.update_title()
        self.resize(1200, 800)
        self.apply_zoom()
        self.apply_paper()
        self.statusBar().addPermanentWidget(QLabel("Version %s " % VERSION))
        if files:
            QTimer.singleShot(0, lambda: [self.open_file(f) for f in files])

    # ------------------------------------------------------------- Aufbau
    def _build_tex_page(self):
        page = QWidget()
        outer = QHBoxLayout(page)
        outer.setContentsMargins(0, 0, 0, 0)
        split = QSplitter()
        split.addWidget(self.tex_edit)
        right = QWidget()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(0, 0, 0, 0)
        bar = QHBoxLayout()
        bar.setContentsMargins(6, 4, 6, 4)
        self.btn_compile = QPushButton("Übersetzen (F5)")
        self.btn_compile.clicked.connect(lambda: self.compile())
        self.cmb_engine = QComboBox()
        self.cmb_engine.addItems(["pdflatex", "xelatex", "lualatex"])
        self.cmb_engine.setCurrentText(self.settings.get("engine", "pdflatex"))
        self.cmb_engine.currentTextChanged.connect(self.on_engine)
        self.chk_auto = QCheckBox("Automatisch")
        self.chk_auto.setToolTip("Nach einer Schreibpause automatisch übersetzen")
        self.chk_auto.setChecked(bool(self.settings.get("auto_compile")))
        self.chk_auto.toggled.connect(lambda v: self.settings.update(auto_compile=v))
        self.lbl_compile = QLabel("")
        bar.addWidget(self.btn_compile)
        bar.addWidget(self.cmb_engine)
        bar.addWidget(self.chk_auto)
        bar.addWidget(self.lbl_compile, 1)
        rl.addLayout(bar)
        vs = QSplitter(Qt.Orientation.Vertical)
        if HAVE_PDF:
            self.pdf_doc = QPdfDocument(self)
            self.pdf_view = QPdfView()
            self.pdf_view.setDocument(self.pdf_doc)
            self.pdf_view.setPageMode(QPdfView.PageMode.MultiPage)
            self.pdf_view.setZoomMode(QPdfView.ZoomMode.FitToWidth)
            vs.addWidget(self.pdf_view)
        else:
            self.pdf_view = None
            lab = QLabel("Die PDF-Vorschau (QtPdf) ist nicht verfügbar.\nDie PDF-Datei wird nach dem Übersetzen extern geöffnet.")
            lab.setAlignment(Qt.AlignmentFlag.AlignCenter)
            vs.addWidget(lab)
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setPlaceholderText("Meldungen des Übersetzers")
        vs.addWidget(self.log)
        vs.setSizes([600, 120])
        rl.addWidget(vs, 1)
        split.addWidget(right)
        split.setSizes([560, 640])
        outer.addWidget(split)
        self.log.mouseDoubleClickEvent = self._log_dbl
        return page

    def _act(self, text, slot=None, shortcut=None, checkable=False, tip=None):
        a = QAction(text, self)
        if slot:
            a.triggered.connect(slot)
        if shortcut:
            a.setShortcut(QKeySequence(shortcut))
        a.setCheckable(checkable)
        if tip:
            a.setToolTip(tip)
            a.setStatusTip(tip)
        return a

    def _build_actions(self):
        A = self._act
        self.a_new = A("Neu (neuer Tab)", self.cmd_new, "Ctrl+N")
        self.a_new.setIconText("Neu")
        self.a_close_tab = A("Tab schließen", lambda: self.close_tab(self.tabbar.currentIndex()), "Ctrl+W")
        self.a_next_tab = A("Nächster Tab", lambda: self.next_tab(1), "Ctrl+PgDown")
        self.a_prev_tab = A("Vorheriger Tab", lambda: self.next_tab(-1), "Ctrl+PgUp")
        self.a_texstudio = A("In TeXstudio bearbeiten", self.cmd_texstudio, "F7",
                             tip="Öffnet die .tex-Datei in TeXstudio; Änderungen von dort werden hier übernommen")
        self.a_texstudio.setIconText("TeXstudio")
        self.a_texstudio_path = A("TeXstudio-Programm wählen …", self.choose_texstudio)
        self.a_open = A("Öffnen …", self.cmd_open, "Ctrl+O")
        self.a_save = A("Speichern", self.cmd_save, "Ctrl+S")
        self.a_saveas = A("Speichern unter …", self.cmd_saveas, "Ctrl+Shift+S")
        self.a_quit = A("Beenden", self.close, "Ctrl+Q")
        self.a_exp_pdf_tex = A("PDF über LaTeX …", self.cmd_export_pdf_tex)
        self.a_exp_pdf_view = A("PDF aus der formatierten Ansicht …", self.cmd_export_pdf_view)
        self.a_exp_docx = A("Word (.docx) über LibreOffice …", self.cmd_export_docx)
        self.a_exp_html = A("HTML …", self.cmd_export_html)
        self.a_pdfsrc = A("PDF-Quelltext öffnen …", lambda: self.open_pdf_source())
        self.a_preview = A("Seitenvorschau", self.cmd_preview, "Ctrl+Shift+P")
        self.a_pdfprev = A("PDF-Vorschau neben dem Text", self.toggle_preview, "F6", True)
        self.a_pdfprev.setIconText("PDF-Vorschau")
        self.a_undo = A("Rückgängig", lambda: self.active_text().undo(), "Ctrl+Z")
        self.a_redo = A("Wiederholen", lambda: self.active_text().redo(), "Ctrl+Shift+Z")
        self.a_cut = A("Ausschneiden", lambda: self.active_text().cut(), "Ctrl+X")
        self.a_copy = A("Kopieren", lambda: self.active_text().copy(), "Ctrl+C")
        self.a_paste = A("Einfügen", lambda: self.active_text().paste(), "Ctrl+V")
        self.a_selall = A("Alles auswählen", lambda: self.active_text().selectAll(), "Ctrl+A")
        self.a_find = A("Suchen …", self.cmd_find, "Ctrl+F")
        self.a_replace = A("Ersetzen …", self.cmd_find, "Ctrl+H")
        grp = QActionGroup(self)
        self.a_v_rich = A("Formatiert", lambda: self.set_view(VIEW_RICH), "Ctrl+1", True)
        self.a_v_md = A("Markdown", lambda: self.set_view(VIEW_MD), "Ctrl+2", True)
        self.a_v_tex = A("LaTeX", lambda: self.set_view(VIEW_TEX), "Ctrl+3", True)
        self.a_v_quick = A("Schnellbearbeitung", lambda: self.set_view(VIEW_QUICK), "Ctrl+4", True)
        self.a_v_quick.setToolTip("LaTeX-Vorlage zeilenweise bearbeiten: nur die Textfelder, alles andere bleibt geschützt")
        for a in (self.a_v_rich, self.a_v_md, self.a_v_tex, self.a_v_quick):
            grp.addAction(a)
        self.a_zoom_in = A("Vergrößern", lambda: self.zoom(1), "Ctrl++")
        self.a_zoom_out = A("Verkleinern", lambda: self.zoom(-1), "Ctrl+-")
        self.a_zoom_0 = A("Normale Größe", lambda: self.zoom(0), "Ctrl+0")
        self.a_mode_dark = A("Dunkelmodus (Farben des Systems)", lambda: self.set_mode(False), None, True)
        self.a_mode_light = A("Hellmodus (weißes Blatt, schwarze Schrift)", lambda: self.set_mode(True), None, True)
        grp = QActionGroup(self)
        grp.addAction(self.a_mode_dark)
        grp.addAction(self.a_mode_light)
        self.a_paper = A("Hell/Dunkel umschalten", self.toggle_paper, "Ctrl+Shift+H")
        # Format
        self.a_bold = A("Fett", lambda: self.toggle_char("b"), "Ctrl+B", True)
        self.a_italic = A("Kursiv", lambda: self.toggle_char("i"), "Ctrl+I", True)
        self.a_under = A("Unterstrichen", lambda: self.toggle_char("u"), "Ctrl+U", True)
        self.a_strike = A("Durchgestrichen", lambda: self.toggle_char("st"), None, True)
        self.a_mono = A("Schreibmaschine (Code)", lambda: self.toggle_char("tt"), "Ctrl+Shift+M", True)
        self.a_sup = A("Hochgestellt", lambda: self.toggle_char("sup"), "Ctrl+Shift+Up", True)
        self.a_sub = A("Tiefgestellt", lambda: self.toggle_char("sub"), "Ctrl+Shift+Down", True)
        self.a_ul = A("Aufzählung", lambda: self.toggle_list(QTextListFormat.Style.ListDisc), None, True)
        self.a_ol = A("Nummerierung", lambda: self.toggle_list(QTextListFormat.Style.ListDecimal), None, True)
        self.a_left = A("Linksbündig", lambda: self.set_align(Qt.AlignmentFlag.AlignLeft), None, True)
        self.a_center = A("Zentriert", lambda: self.set_align(Qt.AlignmentFlag.AlignHCenter), None, True)
        self.a_right = A("Rechtsbündig", lambda: self.set_align(Qt.AlignmentFlag.AlignRight), None, True)
        self.a_just = A("Blocksatz", lambda: self.set_align(Qt.AlignmentFlag.AlignJustify), None, True)
        ag = QActionGroup(self)
        for a in (self.a_left, self.a_center, self.a_right, self.a_just):
            ag.addAction(a)
        self.a_link = A("Link …", self.ins_link, "Ctrl+K")
        self.a_image = A("Bild …", self.ins_image)
        self.a_table = A("Tabelle …", self.ins_table)
        self.a_hr = A("Waagerechte Linie", self.ins_hr)
        self.a_box = A("Kontrollkästchen ☐", lambda: self.ins_checkbox(False), "Ctrl+Shift+K")
        self.a_box.setToolTip("Kontrollkästchen einfügen (Strg+Umschalt+K). Sind mehrere Zeilen markiert, bekommt jede eines. "
                              "Doppelklick auf ein Kästchen in der formatierten Ansicht kreuzt es an oder leert es.")
        self.a_box_x = A("Kontrollkästchen angekreuzt ☒", lambda: self.ins_checkbox(True))
        self.a_math = A("Formel im Text  $ … $", self.ins_math_inline)
        self.a_mathb = A("Formel abgesetzt  \\[ … \\]", self.ins_math_block)
        self.a_foot = A("Fußnote …", self.ins_footnote)
        self.a_toc = A("Inhaltsverzeichnis", lambda: self.ins_raw_block("\\tableofcontents"))
        self.a_newpage = A("Seitenumbruch", lambda: self.ins_raw_block("\\newpage"))
        self.a_raw = A("LaTeX-Rohtext einfügen …", self.ins_raw_free)
        self.a_t_row = A("Zeile darunter einfügen", lambda: self.tbl_op("row+"))
        self.a_t_col = A("Spalte rechts einfügen", lambda: self.tbl_op("col+"))
        self.a_t_delrow = A("Zeile löschen", lambda: self.tbl_op("row-"))
        self.a_t_delcol = A("Spalte löschen", lambda: self.tbl_op("col-"))
        self.a_t_merge = A("Zellen verbinden", lambda: self.tbl_op("merge"))
        self.a_t_split = A("Zelle teilen", lambda: self.tbl_op("split"))
        self.a_compile = A("Übersetzen", lambda: self.compile(), "F5")
        self.a_preamble = A("Dokumentkopf (Präambel) bearbeiten …", self.edit_preamble)
        self.a_open_pdf = A("PDF extern öffnen", self.open_pdf_external)
        self.a_foreign = A("Fremde Formate beim Öffnen als LaTeX zeigen", self.toggle_foreign, None, True)
        self.a_foreign.setChecked(bool(self.settings.get("foreign_to_latex", True)))
        self.a_help = A("Kurzanleitung", self.show_help, "F1")
        self.a_about = A("Über Seifferts Text", self.show_about)

    def _build_menus(self):
        mb = self.menuBar()
        m = mb.addMenu("&Datei")
        for a in (self.a_new, self.a_open):
            m.addAction(a)
        self.recent_menu = m.addMenu("Zuletzt geöffnet")
        m.addAction(self.a_pdfsrc)
        m.addSeparator()
        m.addAction(self.a_close_tab)
        m.addAction(self.a_next_tab)
        m.addAction(self.a_prev_tab)
        m.addSeparator()
        m.addAction(self.a_save)
        m.addAction(self.a_saveas)
        ex = m.addMenu("Exportieren")
        for a in (self.a_exp_pdf_tex, self.a_exp_pdf_view, self.a_exp_docx, self.a_exp_html):
            ex.addAction(a)
        m.addAction(self.a_preview)
        m.addSeparator()
        m.addAction(self.a_quit)
        m = mb.addMenu("&Bearbeiten")
        for a in (self.a_undo, self.a_redo, None, self.a_cut, self.a_copy, self.a_paste, self.a_selall, None,
                  self.a_find, self.a_replace):
            m.addSeparator() if a is None else m.addAction(a)
        m = mb.addMenu("&Ansicht")
        for a in (self.a_v_rich, self.a_v_md, self.a_v_tex, self.a_v_quick, None, self.a_zoom_in, self.a_zoom_out, self.a_zoom_0, None, self.a_pdfprev, None, self.a_mode_dark, self.a_mode_light):
            m.addSeparator() if a is None else m.addAction(a)
        m = mb.addMenu("&Format")
        self.format_menu = m
        for a in (self.a_bold, self.a_italic, self.a_under, self.a_strike, self.a_mono, self.a_sup, self.a_sub,
                  None, self.a_ul, self.a_ol, None, self.a_left, self.a_center, self.a_right, self.a_just):
            m.addSeparator() if a is None else m.addAction(a)
        hm = m.addMenu("Absatzart")
        self.para_actions = []
        for label, code in (("Text", 0), ("Überschrift 1", 1), ("Überschrift 2", 2), ("Überschrift 3", 3),
                            ("Überschrift 4", 4), ("Zitat", "quote"), ("Code", "code")):
            a = hm.addAction(label)
            a.triggered.connect(lambda _=False, c=code: self.set_para(c))
        m = mb.addMenu("&Einfügen")
        self.insert_menu = m
        for a in (self.a_link, self.a_image, self.a_table, self.a_hr, None, self.a_box, self.a_box_x, None,
                  self.a_math, self.a_mathb, self.a_foot, self.a_toc, self.a_newpage, self.a_raw):
            m.addSeparator() if a is None else m.addAction(a)
        m = mb.addMenu("&Tabelle")
        self.table_menu = m
        for a in (self.a_t_row, self.a_t_col, self.a_t_delrow, self.a_t_delcol, None, self.a_t_merge, self.a_t_split):
            m.addSeparator() if a is None else m.addAction(a)
        m = mb.addMenu("&LaTeX")
        for a in (self.a_compile, self.a_open_pdf, None, self.a_texstudio, None, self.a_preamble, None,
                  self.a_foreign):
            m.addSeparator() if a is None else m.addAction(a)
        m = mb.addMenu("Ein&stellungen")
        m.addSection("Darstellung")
        m.addAction(self.a_mode_dark)
        m.addAction(self.a_mode_light)
        m.addSeparator()
        m.addAction(self.a_paper)
        m.addSection("LaTeX")
        m.addAction(self.a_texstudio_path)
        m = mb.addMenu("&Hilfe")
        m.addAction(self.a_help)
        m.addAction(self.a_about)
        self.refresh_recent()

    def _build_toolbars(self):
        tb = QToolBar("Ansicht")
        tb.setMovable(False)
        tb.addAction(self.a_new)
        tb.addAction(self.a_open)
        tb.addAction(self.a_save)
        tb.addSeparator()
        tb.addAction(self.a_v_rich)
        tb.addAction(self.a_v_md)
        tb.addAction(self.a_v_tex)
        tb.addAction(self.a_v_quick)
        tb.addSeparator()
        self.a_box.setIconText("Kästchen ☐")
        tb.addAction(self.a_box)
        tb.addSeparator()
        tb.addAction(self.a_preview)
        tb.addAction(self.a_pdfprev)
        tb.addAction(self.a_compile)
        tb.addAction(self.a_texstudio)
        self.addToolBar(tb)
        self.addToolBarBreak()
        self.fmt_bar = QToolBar("Format")
        self.fmt_bar.setMovable(False)
        self.cmb_para = QComboBox()
        self.cmb_para.addItems(["Text", "Überschrift 1", "Überschrift 2", "Überschrift 3", "Überschrift 4",
                                "Zitat", "Code"])
        self.cmb_para.activated.connect(self.on_para_combo)
        self.fmt_bar.addWidget(self.cmb_para)
        self.fmt_bar.addSeparator()
        for txt, act in (("F", self.a_bold), ("K", self.a_italic), ("U", self.a_under), ("S̶", self.a_strike),
                         ("‹/›", self.a_mono), ("x²", self.a_sup), ("x₂", self.a_sub)):
            act.setIconText(txt)
            self.fmt_bar.addAction(act)
        self.fmt_bar.addSeparator()
        for txt, act in (("• Liste", self.a_ul), ("1. Liste", self.a_ol)):
            act.setIconText(txt)
            self.fmt_bar.addAction(act)
        self.fmt_bar.addSeparator()
        for txt, act in (("⇤", self.a_left), ("↔", self.a_center), ("⇥", self.a_right), ("≡", self.a_just)):
            act.setIconText(txt)
            self.fmt_bar.addAction(act)
        self.fmt_bar.addSeparator()
        for txt, act in (("Link", self.a_link), ("Bild", self.a_image), ("Tabelle", self.a_table),
                         ("Formel", self.a_math)):
            act.setIconText(txt)
            self.fmt_bar.addAction(act)
        for a in self.fmt_bar.actions():
            w = self.fmt_bar.widgetForAction(a)
            if w is not None and hasattr(w, "setToolButtonStyle"):
                w.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)
        fb = self.a_bold.font()
        self.addToolBar(self.fmt_bar)

    # ------------------------------------------------------------- Zustand
    def active_text(self):
        return [self.rich, self.md_edit, self.tex_edit, self.tex_edit][self.view]

    def on_doc_changed(self):
        if self._loading:
            return
        self.rev += 1
        self.set_modified(True)
        self.update_info()
        if self.prev_panel.isVisible():
            self.prev_timer.start()

    def on_md_changed(self):
        if self._loading:
            return
        self.md_dirty = True
        self.set_modified(True)
        self.md_timer.start()
        self.update_info()

    def on_tex_changed(self):
        if self._loading:
            return
        self.tex_dirty = True
        self.set_modified(True)
        self.update_info()
        if self.chk_auto.isChecked():
            self.auto_timer.start()

    def set_modified(self, v):
        self.modified = v
        self.update_title()

    def update_title(self):
        name = os.path.basename(self.path) if self.path else ("Unbenannt" + (" (%s)" % self.source_note if self.source_note else ""))
        self.setWindowTitle("%s%s – %s %s" % ("* " if self.modified else "", name, APP_NAME, VERSION))
        if self.cur is not None and not self._switching:
            i = self._index_of(self.cur)
            if i >= 0:
                self.tabbar.setTabText(i, ("* " if self.modified else "") + name.replace("&", "&&"))
                self.tabbar.setTabToolTip(i, self.path or name)
            self._apply_remembered_color()
            self._sync_watch()
        if self.cur_pdf is not None:
            self.setWindowTitle(self.cur_pdf.widget.windowTitle())

    # ------------------------------------------------------------- Tabs
    def _tab_at(self, i):
        if i < 0 or i >= self.tabbar.count():
            return None
        return self.tabs.get(self.tabbar.tabData(i))

    def _index_of(self, tab):
        for i in range(self.tabbar.count()):
            if self.tabbar.tabData(i) == tab.id:
                return i
        return -1

    def _tab_color_at(self, i):
        t = self._tab_at(i)
        return t.color if t is not None else None

    def _tab_path(self, tab):
        return self.path if tab is self.cur else tab.s.get("path")

    def _tab_modified(self, tab):
        return self.modified if tab is self.cur else tab.modified

    def _on_bar_changed(self, i):
        if self._bar_lock or self._switching:
            return
        t = self._tab_at(i)
        if t is None:
            return
        if t.is_pdf:
            self._show_pdf(t)
        elif t is not self.cur or self.cur_pdf is not None:
            self._activate(t)

    # ------------------------------------------------------------- PDF in Tabs
    def _text_tabs(self):
        return [t for t in self.tabs.values() if not t.is_pdf]

    def _show_pdf(self, tab):
        """Zeigt einen PDF-Tab. Der Textzustand des zuletzt aktiven Text-Tabs bleibt unverändert geladen."""
        if self.cur_pdf is tab:
            return
        was_pdf = self.cur_pdf is not None
        if not was_pdf:
            self._enter_pdf_mode()
        self.cur_pdf = tab
        self.stack.setCurrentWidget(tab.widget)
        self._bar_lock += 1
        self.tabbar.setCurrentIndex(self._index_of(tab))
        self._bar_lock -= 1
        self.setWindowTitle(tab.widget.windowTitle())
        self.tabbar.update()

    def _enter_pdf_mode(self):
        """Hauptmenü, Werkzeugleisten und Statuszeile weichen denen des PDF-Fensters; die Tastenkürzel des Hauptfensters
        werden abgeschaltet, damit sie nicht mit denen des PDF-Fensters kollidieren (sonst löst keines aus)."""
        self.commit()
        self._chrome = []
        for w in [self.menuBar(), self.statusBar(), self.find_bar] + self.findChildren(QToolBar):
            if w.isVisible():
                self._chrome.append(w)
                w.hide()
        pdf_widgets = [t.widget for t in self.tabs.values() if t.is_pdf]
        for a in self.findChildren(QAction):
            o = a.parent()
            while o is not None and o not in pdf_widgets:
                o = o.parent()
            if o is not None:
                continue                # Aktionen der eingebetteten PDF-Fenster bleiben
            sc = a.shortcut()
            if not sc.isEmpty():
                self._suspended[a] = sc
                a.setShortcut(QKeySequence())

    def _leave_pdf(self, select_cur=True):
        if self.cur_pdf is None:
            return
        self.cur_pdf = None
        for a, sc in self._suspended.items():
            a.setShortcut(sc)
        self._suspended = {}
        for w in self._chrome:
            w.show()
        self._chrome = []
        self.stack.setCurrentIndex(self.view)
        if select_cur and self.cur is not None:
            self._bar_lock += 1
            self.tabbar.setCurrentIndex(self._index_of(self.cur))
            self._bar_lock -= 1
        self.update_title()
        self.update_info()
        self.tabbar.update()

    def pdf_title_changed(self, w):
        """Das eingebettete PDF-Fenster meldet einen neuen Titel (Änderung, Speichern unter neuem Namen)."""
        for t in self.tabs.values():
            if t.widget is w:
                t.s["path"] = w.ed.path
                t.s["modified"] = bool(w.ed.modified)
                i = self._index_of(t)
                if i >= 0:
                    name = os.path.basename(w.ed.path)
                    self.tabbar.setTabText(i, ("* " if w.ed.modified else "") + name.replace("&", "&&"))
                    self.tabbar.setTabToolTip(i, w.ed.path)
                if t is self.cur_pdf:
                    self.setWindowTitle(w.windowTitle())
                return

    def open_pdf_tab(self, path):
        """PDF in einem eigenen Tab öffnen (schon offen: zu seinem Tab wechseln)."""
        for t in self.tabs.values():
            if t.is_pdf and t.s.get("path") == path:
                self._show_pdf(t)
                return t
        from .pdf_window import PdfWindow
        w = PdfWindow(path, self, embedded=True)
        mem = self.settings.get("tab_colors", {})
        tab = Tab(mem.get(path) or next_free_color(t.color for t in self.tabs.values()))
        tab.widget = w
        tab.s = {"path": path, "modified": False}
        self.tabs[tab.id] = tab
        self.stack.addWidget(w)
        self._bar_lock += 1
        i = self.tabbar.addTab(os.path.basename(path).replace("&", "&&"))
        self.tabbar.setTabData(i, tab.id)
        self.tabbar.setTabToolTip(i, path)
        self._bar_lock -= 1
        self._show_pdf(tab)
        mem = self.settings.setdefault("tab_colors", {})
        mem.setdefault(path, tab.color)
        return tab

    def close_pdf_tab(self, w):
        for t in self.tabs.values():
            if t.widget is w:
                return self.close_tab(self._index_of(t))
        return False

    def _remove_pdf_tab(self, tab):
        i = self._index_of(tab)
        was_cur = tab is self.cur_pdf
        self._bar_lock += 1
        self.tabbar.removeTab(i)
        self._bar_lock -= 1
        del self.tabs[tab.id]
        self.stack.removeWidget(tab.widget)
        tab.widget.deleteLater()
        if was_cur:
            nxt = self._tab_at(min(i, self.tabbar.count() - 1))
            self.cur_pdf = tab           # damit _leave_pdf unten aufräumt
            self._leave_pdf(select_cur=False)
            if nxt is not None and nxt.is_pdf:
                self._show_pdf(nxt)
            elif nxt is not None and nxt is not self.cur:
                self._activate(nxt)
            else:
                self._bar_lock += 1
                self.tabbar.setCurrentIndex(self._index_of(self.cur))
                self._bar_lock -= 1

    def _fresh_state(self):
        return dict(odt_src=None, odt_lock="", path=None, kind="odt", source_note="", preamble=DEFAULT_PREAMBLE,
                    rev=1, md_synced=-1, tex_synced=-1, md_dirty=False, tex_dirty=False, modified=False,
                    view=VIEW_RICH, last_images={}, md_images={},
                    work=tempfile.mkdtemp(prefix="seiffert-text-"), pdf_after=None, last_pdf=None,
                    pdf_loaded=None, prev_loaded=None, prev_rev=-1, disk_sig=None, ext_changed=False,
                    compile_pass=0, **{k: (type(v)() if isinstance(v, (list, set)) else v) for k, v in Q_DEFAULTS.items()})

    def new_tab(self):
        tab = Tab(next_free_color(t.color for t in self.tabs.values()))
        d = QTextDocument()
        d.setDefaultFont(base_font())
        d.setDocumentMargin(24)
        d.setParent(self)
        tab.doc = d
        tab.s = self._fresh_state()
        tab.zoom = None             # Schrift beim ersten Anzeigen an die Vergrößerung anpassen
        self.tabs[tab.id] = tab
        self._bar_lock += 1
        i = self.tabbar.addTab("Unbenannt")
        self.tabbar.setTabData(i, tab.id)
        self._bar_lock -= 1
        self._activate(tab)
        return tab

    def _stop_procs(self):
        """Läuft gerade eine Übersetzung oder Vorschau, wird sie beendet (sie gehört zum Dokument im Tab)."""
        for t in (self.auto_timer, self.prev_timer, self.md_timer):
            t.stop()
        if self.proc is not None:
            p, self.proc = self.proc, None
            for sig in (p.finished, p.errorOccurred):
                try:
                    sig.disconnect()
                except (RuntimeError, TypeError):
                    pass
            p.kill()
            p.deleteLater()
            self.btn_compile.setEnabled(True)
            self.lbl_compile.setText("Übersetzung abgebrochen")
            self.pdf_after = None
        if self.prev_proc is not None:
            p, self.prev_proc = self.prev_proc, None
            for sig in (p.finished, p.errorOccurred):
                try:
                    sig.disconnect()
                except (RuntimeError, TypeError):
                    pass
            p.kill()
            p.deleteLater()
        self.prev_btn.setEnabled(True)
        self.prev_pending = False

    def _save_state(self, tab):
        self.commit()
        self._stop_procs()
        for a in STATE_ATTRS:
            tab.s[a] = getattr(self, a)
        tab.doc = self.doc
        tab.md_text = self.md_edit.toPlainText() if self.md_synced == self.rev else None
        tab.tex_text = self.tex_edit.toPlainText() if self.tex_synced == self.rev else None
        tab.log_text = self.log.toPlainText()
        tab.lbl_compile = self.lbl_compile.text()
        w = self.active_text()
        tab.cursor = w.textCursor().position()
        tab.scroll = w.verticalScrollBar().value()
        tab.zoom = self.settings.get("zoom", 0)

    def _load_state(self, tab, keep_old=True):
        self._loading = True
        try:
            if tab.doc is not self.doc:
                old = self.doc
                try:
                    old.contentsChanged.disconnect(self.on_doc_changed)
                except (RuntimeError, TypeError):
                    pass
                if keep_old:
                    old.setParent(self)         # sonst würde der Editor es beim Ersetzen löschen
                self.rich.setDocument(tab.doc)
                tab.doc.setParent(self.rich)    # von hier an gehört es dem Editor (wie in build_detached)
                self.doc = tab.doc
                self.doc.contentsChanged.connect(self.on_doc_changed)
            for a, v in tab.s.items():
                setattr(self, a, v)
            self.md_edit.setPlainText(tab.md_text or "")
            self.tex_edit.setPlainText(tab.tex_text or "")
            self.log.setPlainText(tab.log_text)
            self.lbl_compile.setText(tab.lbl_compile)
        finally:
            self._loading = False
        if tab.zoom != self.settings.get("zoom", 0):
            self.apply_zoom()
        if HAVE_PDF:
            for d, p in ((self.pdf_doc, self.pdf_loaded), (self.prev_doc, self.prev_loaded)):
                if d is None:
                    continue
                if p and os.path.exists(p):
                    d.load(p)
                else:
                    d.close()
        self.set_view(self.view)
        w = self.active_text()
        c = w.textCursor()
        c.setPosition(max(0, min(tab.cursor, w.document().characterCount() - 1)))
        w.setTextCursor(c)
        QTimer.singleShot(0, lambda w=w, v=tab.scroll: w.verticalScrollBar().setValue(v))
        if self.ext_changed:
            QTimer.singleShot(0, self._handle_external)

    def _activate(self, tab, old_dead=False):
        if tab is self.cur and not old_dead:
            if self.cur_pdf is not None:
                self._leave_pdf()
            return
        if self.cur_pdf is not None:
            self._leave_pdf(select_cur=False)
        self._switching = True
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            if not old_dead:
                self._save_state(self.cur)
            self.cur = tab
            self._load_state(tab, keep_old=not old_dead)
        finally:
            QApplication.restoreOverrideCursor()
            self._switching = False
        self._bar_lock += 1
        self.tabbar.setCurrentIndex(self._index_of(tab))
        self._bar_lock -= 1
        self.update_title()
        self.update_info()
        self.tabbar.update()

    def _discard_tab(self, tab):
        """Tab ohne Rückfrage entfernen (z. B. wenn das Öffnen der Datei misslang)."""
        if len(self._text_tabs()) <= 1:
            self.new_document()
            return
        i = self._index_of(tab)
        nxt = self._tab_at(i + 1) or self._tab_at(i - 1)
        work = self.work if tab is self.cur else tab.s.get("work")
        self._bar_lock += 1
        self.tabbar.removeTab(i)
        self._bar_lock -= 1
        del self.tabs[tab.id]
        if tab is self.cur:
            self._stop_procs()
            nt = nxt if not nxt.is_pdf else next(iter(self._text_tabs()))
            self._activate(nt, old_dead=True)
            if nxt.is_pdf:
                self._show_pdf(nxt)
        elif tab.doc is not None:
            tab.doc.deleteLater()
        if work:
            shutil.rmtree(work, ignore_errors=True)
        self._sync_watch()

    def close_tab(self, i):
        tab = self._tab_at(i)
        if tab is None:
            return False
        if tab.is_pdf:
            if tab is not self.cur_pdf:
                self._show_pdf(tab)
            if not tab.widget.close():          # fragt bei Änderungen nach dem Speichern
                return False
            self._remove_pdf_tab(tab)
            return True
        if tab is not self.cur or self.cur_pdf is not None:
            self._activate(tab)
        if not self.maybe_save():
            return False
        if len(self._text_tabs()) == 1:
            self.new_document()         # der letzte Tab bleibt als leeres Dokument stehen
            self.update_title()
            return True
        self._discard_tab(tab)
        return True

    def close_other_tabs(self, keep):
        for t in [t for t in self.tabs.values() if t is not keep]:
            if t.id in self.tabs and not self.close_tab(self._index_of(t)):
                return False
        return True

    def next_tab(self, d):
        n = self.tabbar.count()
        if n > 1:
            self.tabbar.setCurrentIndex((self.tabbar.currentIndex() + d) % n)

    def _set_tab_color(self, tab, color):
        tab.color = color
        p = self._tab_path(tab)
        if p:
            self.settings.setdefault("tab_colors", {})[p] = color
            save_settings(self.settings)
        self.tabbar.update()

    def _apply_remembered_color(self):
        """Dieselbe Datei bekommt beim nächsten Öffnen wieder dieselbe Tab-Farbe."""
        t = self.cur
        if not self.path or t.colored_for == self.path:
            return
        t.colored_for = self.path
        mem = self.settings.setdefault("tab_colors", {})
        if self.path in mem:
            t.color = mem[self.path]
        else:
            mem[self.path] = t.color
            while len(mem) > 300:
                mem.pop(next(iter(mem)))
        self.tabbar.update()

    def _tab_menu(self, i, pos):
        tab = self._tab_at(i)
        if tab is None:
            return
        m = QMenu(self)
        cm = m.addMenu("Farbe")
        for name, col in TAB_COLORS:
            pm = QPixmap(14, 14)
            pm.fill(QColor(col))
            a = cm.addAction(QIcon(pm), name)
            a.setCheckable(True)
            a.setChecked(col.lower() == tab.color.lower())
            a.triggered.connect(lambda _=False, t=tab, c=col: self._set_tab_color(t, c))
        cm.addSeparator()

        def custom():
            c = QColorDialog.getColor(QColor(tab.color), self, "Tab-Farbe wählen")
            if c.isValid():
                self._set_tab_color(tab, c.name())
        cm.addAction("Andere Farbe …").triggered.connect(custom)
        m.addSeparator()
        m.addAction("Tab schließen").triggered.connect(lambda: self.close_tab(self._index_of(tab)))
        a = m.addAction("Andere Tabs schließen")
        a.setEnabled(len(self.tabs) > 1)
        a.triggered.connect(lambda: self.close_other_tabs(tab))
        p = self._tab_path(tab)
        if p:
            m.addSeparator()
            m.addAction("Pfad kopieren").triggered.connect(lambda: QApplication.clipboard().setText(p))
        m.exec(pos)

    # ------------------------------------------------------------- Änderungen von außen (z. B. TeXstudio)
    def _sync_watch(self):
        paths = set()
        for t in self.tabs.values():
            p = self._tab_path(t)
            if p and p.lower().endswith(TEXT_EXT):
                paths.add(p)
        if paths != self._watch_paths:
            gone = self._watch_paths - paths
            new = paths - self._watch_paths
            if gone:
                self.watcher.removePaths(list(gone))
            if new:
                self.watcher.addPaths([p for p in new if os.path.exists(p)])
            self._watch_paths = paths

    def _file_changed(self, path):
        self._watch_timer.start()

    def _check_external(self):
        have = set(self.watcher.files())
        for p in self._watch_paths:
            if os.path.exists(p) and p not in have:
                self.watcher.addPath(p)         # nach dem Ersetzen der Datei neu anmelden
        for t in self.tabs.values():
            p = self._tab_path(t)
            if not p or p not in self._watch_paths:
                continue
            sig = file_sig(p)
            known = self.disk_sig if t is self.cur else t.s.get("disk_sig")
            if sig is None or sig == known:
                continue
            if known is None:
                if t is self.cur:
                    self.disk_sig = sig
                else:
                    t.s["disk_sig"] = sig
                continue
            if t is self.cur:
                self.ext_changed = True
            else:
                t.s["ext_changed"] = True
        if self.ext_changed:
            self._handle_external()

    def _handle_external(self):
        if not self.ext_changed or not self.path:
            return
        self.ext_changed = False
        sig = file_sig(self.path)
        if sig is None or sig == self.disk_sig:
            return
        if self.modified:
            r = QMessageBox.question(
                self, APP_NAME,
                "Die Datei „%s“ wurde in einem anderen Programm geändert, und hier gibt es ungespeicherte "
                "Änderungen.\n\nDie Fassung von der Festplatte laden und die Änderungen hier verwerfen?"
                % os.path.basename(self.path),
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
            if r != QMessageBox.StandardButton.Yes:
                self.disk_sig = sig
                return
        self.reload_from_disk()
        self.status.showMessage("„%s“ wurde in einem anderen Programm geändert und neu geladen."
                                % os.path.basename(self.path), 8000)

    def reload_from_disk(self):
        path = self.path
        ext = os.path.splitext(path)[1].lower()
        try:
            with open(path, encoding="utf-8-sig", errors="replace") as f:
                text = f.read()
        except OSError as e:
            QMessageBox.warning(self, APP_NAME, "Die Datei konnte nicht neu gelesen werden:\n%s" % e)
            return False
        line = self.active_text().textCursor().blockNumber()
        self._loading = True
        try:
            if ext == ".tex":
                self.md_edit.setPlainText("")
                self.tex_edit.setPlainText(text)
            else:
                self.tex_edit.setPlainText("")
                self.md_edit.setPlainText(text)
        finally:
            self._loading = False
        if ext == ".tex":
            self.load_from_latex(text)
            self.tex_dirty = False
        else:
            self.load_from_markdown(text)
            self.md_dirty = False
        self.disk_sig = file_sig(path)
        self.set_modified(False)
        self.set_view(self.view)
        if self.view != VIEW_RICH:
            self.active_text().goto_line(line + 1)
        return True

    # ------------------------------------------------------------- TeXstudio
    def choose_texstudio(self):
        start = self.settings.get("texstudio_path") or "/usr/bin"
        p, _ = QFileDialog.getOpenFileName(self, "TeXstudio-Programm wählen", start, "Alle Dateien (*)")
        if p:
            self.settings["texstudio_path"] = p
            save_settings(self.settings)
            return True
        return False

    def _save_as_tex(self):
        stem = os.path.splitext(self.path)[0] if self.path else os.path.join(os.path.expanduser("~"), "Unbenannt")
        p, _ = QFileDialog.getSaveFileName(self, "Als LaTeX-Datei speichern", stem + ".tex", "LaTeX (*.tex)")
        if not p:
            return False
        if not p.lower().endswith(".tex"):
            p += ".tex"
        return self.save_to(p)

    def cmd_texstudio(self):
        cmd = find_texstudio(self.settings.get("texstudio_path", ""))
        if cmd is None:
            box = QMessageBox(self)
            box.setIcon(QMessageBox.Icon.Information)
            box.setWindowTitle(APP_NAME)
            box.setText("TeXstudio wurde nicht gefunden.")
            box.setInformativeText("Ist es installiert, kann das Programm von Hand gewählt werden.")
            b = box.addButton("Programm wählen …", QMessageBox.ButtonRole.AcceptRole)
            box.addButton("Abbrechen", QMessageBox.ButtonRole.RejectRole)
            box.exec()
            if box.clickedButton() is b and self.choose_texstudio():
                self.cmd_texstudio()
            return
        if not (self.path and self.path.lower().endswith(".tex")):
            box = QMessageBox(self)
            box.setIcon(QMessageBox.Icon.Question)
            box.setWindowTitle(APP_NAME)
            box.setText("TeXstudio bearbeitet .tex-Dateien.")
            box.setInformativeText("Das Dokument wird dafür als LaTeX-Datei gespeichert und unter diesem Namen "
                                   "hier weitergeführt. Änderungen aus TeXstudio werden danach automatisch "
                                   "übernommen.")
            b = box.addButton("Als .tex speichern …", QMessageBox.ButtonRole.AcceptRole)
            box.addButton("Abbrechen", QMessageBox.ButtonRole.RejectRole)
            box.exec()
            if box.clickedButton() is not b or not self._save_as_tex():
                return
        elif self.modified or self.md_dirty or self.tex_dirty:
            if not self.save_to(self.path):
                return
        line = self.tex_edit.textCursor().blockNumber() + 1 if self.view == VIEW_TEX else 1
        try:
            args = launch_texstudio(cmd, self.path, line)
        except OSError as e:
            QMessageBox.warning(self, APP_NAME, "TeXstudio konnte nicht gestartet werden:\n%s" % e)
            return
        self.last_texstudio_args = args
        self.status.showMessage("In TeXstudio geöffnet: %s (Zeile %d)" % (os.path.basename(self.path), line), 8000)

    def update_info(self):
        w = self.active_text()
        txt = w.toPlainText()
        words = len(re.findall(r"\w+", txt))
        if self.view == VIEW_RICH:
            self.lbl_info.setText("%d Wörter" % words)
        else:
            c = w.textCursor()
            self.lbl_info.setText("Zeile %d, Spalte %d   %d Wörter" % (c.blockNumber() + 1, c.positionInBlock() + 1, words))
        self.lbl_view.setText("  " + ["Formatiert", "Markdown", "LaTeX", "Schnellbearbeitung"][self.view])

    # ------------------------------------------------------------- Ansichten
    def commit(self):
        """Übernimmt Änderungen der aktuellen Quelltext-Ansicht in das Dokument."""
        if self.view == VIEW_MD and self.md_dirty:
            self.load_from_markdown(self.md_edit.toPlainText())
        elif self.view in (VIEW_TEX, VIEW_QUICK) and self.tex_dirty:
            if self.view == VIEW_QUICK:
                self.quick.flush_typing()
            self.load_from_latex(self.tex_edit.toPlainText())

    def load_from_markdown(self, text):
        self._loading = True
        try:
            self.doc.setMarkdown(text)
            self.doc.setDefaultFont(base_font())
            self.doc.setDocumentMargin(24)
            self.doc.clearUndoRedoStacks()
        finally:
            self._loading = False
        self.rev += 1
        self.md_synced = self.rev
        self.tex_synced = -1
        self.md_dirty = False

    def base_dir(self):
        return os.path.dirname(self.path) if self.path else None

    def apply_base(self):
        d = self.base_dir()
        if d:
            self.doc.setBaseUrl(QUrl.fromLocalFile(d + "/"))

    def load_from_latex(self, text):
        pre, blocks = parse_latex(text, self.base_dir())
        self.preamble = pre
        self._loading = True
        try:
            self.build_detached(blocks)
        finally:
            self._loading = False
        self.rev += 1
        self.tex_synced = self.rev
        self.md_synced = -1
        self.tex_dirty = False

    def current_markdown(self):
        self.commit()
        if self.md_synced != self.rev:
            md, self.md_images = markdown_with_images(self.doc, self.base_dir())
            self._loading = True
            try:
                self.md_edit.setPlainText(md)
            finally:
                self._loading = False
            self.md_synced = self.rev
            self.md_dirty = False
        return self.md_edit.toPlainText()

    def current_latex(self):
        if self.view == VIEW_QUICK and self.q_doc is not None:
            self.quick.flush_typing()
            return self.tex_edit.toPlainText()
        self.commit()
        if self.tex_synced != self.rev:
            text, imgs = export_latex(self.doc, self.preamble, self.base_dir())
            self.last_images = imgs
            self._loading = True
            try:
                self.tex_edit.setPlainText(text)
            finally:
                self._loading = False
            self.tex_synced = self.rev
            self.tex_dirty = False
        return self.tex_edit.toPlainText()

    def set_view(self, v):
        if self.cur_pdf is not None:
            self._leave_pdf()
        if v == VIEW_QUICK and self.view != VIEW_QUICK:
            text = self.current_latex()
            if not self.quick.prepare():
                (self.a_v_rich, self.a_v_md, self.a_v_tex, self.a_v_quick)[self.view].setChecked(True)
                return
        self.commit()
        self.md_dirty = self.tex_dirty = False     # übernommen oder nicht von dieser Ansicht
        self.view = v
        if v == VIEW_MD:
            self.current_markdown()
            self.update_md_preview()
        elif v == VIEW_TEX:
            self.current_latex()
        self.stack.setCurrentIndex(v)
        if v == VIEW_QUICK:
            self.quick.show_view()
        if v == VIEW_RICH and self.a_pdfprev.isChecked() and self.prev_rev != self.rev:
            self.prev_timer.start()
        (self.a_v_rich, self.a_v_md, self.a_v_tex, self.a_v_quick)[v].setChecked(True)
        self.fmt_bar.setEnabled(v == VIEW_RICH)
        for m in (self.format_menu, self.table_menu):
            m.setEnabled(v == VIEW_RICH)
        for a in self.insert_menu.actions():
            a.setEnabled(v == VIEW_RICH or a in (self.a_box, self.a_box_x))
        self.a_compile.setEnabled(v in (VIEW_TEX, VIEW_QUICK))
        if v != VIEW_QUICK:
            self.active_text().setFocus()
        self.sync_format_state()
        self.update_info()

    def update_md_preview(self):
        if self.view != VIEW_MD:
            return
        base = self.base_dir()
        if base:
            self.md_view.setSearchPaths([base])
        bar = self.md_view.verticalScrollBar().value()
        self.md_view.setMarkdown(self.md_edit.toPlainText())
        self.md_view.verticalScrollBar().setValue(bar)

    # ------------------------------------------------------------- Dokument
    def build_detached(self, blocks):
        """Dokument in einem frischen QTextDocument ohne Layout aufbauen und erst danach in den Editor
        setzen (im angezeigten Editor wäre der Aufbau großer Tabellen quadratisch langsam)."""
        from PySide6.QtGui import QTextDocument
        new = QTextDocument()
        build_document(blocks, new)
        old = self.doc
        try:
            old.contentsChanged.disconnect(self.on_doc_changed)
        except (RuntimeError, TypeError):
            pass
        new.setParent(self.rich)         # der Editor besitzt das Dokument
        self.rich.setDocument(new)       # löscht das alte Dokument
        self.doc = new
        self.doc.setUndoRedoEnabled(True)
        self.doc.contentsChanged.connect(self.on_doc_changed)

    # ---- fremde ODT-Dateien: formaterhaltend speichern (odt_patch.py)
    def attach_odt_source(self, path):
        self.odt_src, self.odt_lock = None, ""
        try:
            self.odt_src = OdtSource(path, self.doc)
        except Exception as e:
            self.odt_lock = "Der Aufbau dieser Datei wird nicht unterstützt (%s)." % e

    def _check_odt(self, tmp):
        res = read_any(tmp)
        return norm(build_document(res.blocks).toPlainText()) == norm(self.doc.toPlainText())

    def save_odt_preserving(self, path):
        try:
            if self.odt_src is None:
                raise PatchError(self.odt_lock)
            self.odt_src.save(self.doc, path, self._check_odt)
        except PatchError as e:
            box = QMessageBox(self)
            box.setIcon(QMessageBox.Icon.Warning)
            box.setWindowTitle(APP_NAME)
            box.setText("Diese Änderung lässt sich nicht speichern, ohne die Formatierung der Datei zu beschädigen.")
            box.setInformativeText("%s\n\nDie Originaldatei wurde nicht verändert. Sie können die Änderung "
                                   "zurücknehmen oder das Dokument als Kopie mit vereinfachter Formatierung "
                                   "unter einem neuen Namen speichern." % e)
            b_copy = box.addButton("Als Kopie speichern …", QMessageBox.ButtonRole.AcceptRole)
            box.addButton("Abbrechen", QMessageBox.ButtonRole.RejectRole)
            box.exec()
            if box.clickedButton() is b_copy:
                orig = self.odt_src.path if self.odt_src is not None else (self.path or path)
                start = os.path.splitext(orig)[0] + " (Kopie).odt"
                p, _ = QFileDialog.getSaveFileName(self, "Kopie speichern", start, "OpenDocument-Text (*.odt)")
                if p:
                    if not p.lower().endswith(".odt"):
                        p += ".odt"
                    if os.path.abspath(p) == os.path.abspath(orig):
                        QMessageBox.warning(self, APP_NAME, "Die Kopie braucht einen anderen Namen als das Original.")
                    else:
                        write_odt(self.doc, p, os.path.dirname(orig))
                        self.status.showMessage("Kopie gespeichert: " + p, 8000)
            return False
        # neu einlesen, damit Editor und Datei wieder genau zusammenpassen
        pos = self.rich.textCursor().position()
        bar = self.rich.verticalScrollBar().value()
        res = read_any(path)
        self._loading = True
        try:
            self.build_detached(res.blocks)
        finally:
            self._loading = False
        self.rev += 1
        self.attach_odt_source(path)
        self.apply_zoom()
        c = self.rich.textCursor()
        c.setPosition(max(0, min(pos, self.doc.characterCount() - 1)))
        self.rich.setTextCursor(c)
        self.rich.verticalScrollBar().setValue(bar)
        return True

    def new_document(self, first=False):
        self._loading = True
        try:
            self.doc.clear()
            self.doc.setDefaultFont(base_font())
            self.md_edit.setPlainText("")
            self.tex_edit.setPlainText("")
            self.doc.clearUndoRedoStacks()
        finally:
            self._loading = False
        self.preamble = DEFAULT_PREAMBLE
        self.odt_src = None
        self.odt_lock = ""
        self.path = None
        self.kind = "odt"
        self.source_note = ""
        self.rev += 1
        self.md_synced = self.tex_synced = -1
        self.md_dirty = self.tex_dirty = False
        self.last_images = {}
        self.md_images = {}
        for k, v in Q_DEFAULTS.items():
            setattr(self, k, type(v)() if isinstance(v, (list, set)) else v)
        self.disk_sig = None
        self.ext_changed = False
        self.last_pdf = self.pdf_loaded = self.prev_loaded = None
        self.prev_rev = -1
        if not first:
            for d in (self.pdf_doc if HAVE_PDF else None, self.prev_doc):
                if d is not None:
                    d.close()
            self.log.clear()
            self.lbl_compile.setText("")
        self.set_modified(False)
        if not first:
            self.set_view(VIEW_RICH)

    def maybe_save(self):
        if not self.modified:
            return True
        r = QMessageBox.question(self, APP_NAME, "Das Dokument wurde geändert. Speichern?",
                                 QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard |
                                 QMessageBox.StandardButton.Cancel)
        if r == QMessageBox.StandardButton.Save:
            return self.cmd_save()
        return r == QMessageBox.StandardButton.Discard

    def cmd_new(self):
        self.new_tab()

    def cmd_open(self):
        start = os.path.dirname(self.path) if self.path else os.path.expanduser("~")
        files, _ = QFileDialog.getOpenFileNames(self, "Dateien öffnen", start, OPEN_FILTER)
        for p in files:
            self.open_file(p)

    def open_pdf_source(self, path=None):
        """PDF im Quelltext öffnen (eigenes Fenster, gespeichert wird unter neuem Namen)."""
        if not path:
            start = os.path.dirname(self.path) if self.path else os.path.expanduser("~")
            path, _ = QFileDialog.getOpenFileName(self, "PDF-Quelltext öffnen", start, "PDF (*.pdf)")
            if not path:
                return None
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            from .pdf_source import PdfSourceWindow
            w = PdfSourceWindow(path, self)
        except Exception as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.warning(self, APP_NAME, "Der PDF-Quelltext konnte nicht geöffnet werden:\n%s" % e)
            return None
        QApplication.restoreOverrideCursor()
        self.children_windows.append(w)
        w.show()
        return w

    def open_child(self, path, ext):
        """Tabellen öffnen in einem eigenen Fenster, PDFs in einem Tab. Liefert False, wenn stattdessen umgewandelt werden soll."""
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            if ext == ".pdf":
                from .pdf_tools import available
                if not available():
                    self.status.showMessage("PyMuPDF fehlt: Das PDF wird nur als Text geöffnet. "
                                            "Zum Bearbeiten ./install.sh erneut ausführen.", 12000)
                    return False
                self.open_pdf_tab(path)
                QApplication.restoreOverrideCursor()
                self.add_recent(path)
                return True
            else:
                from .sheet_window import SheetWindow
                w = SheetWindow(path, self)
        except Exception as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.warning(self, APP_NAME, "Die Datei konnte nicht geöffnet werden:\n%s" % e)
            return True
        QApplication.restoreOverrideCursor()
        self.children_windows.append(w)
        w.show()
        self.add_recent(path)
        return True

    def is_pristine(self):
        """Leeres, unverändertes, unbenanntes Dokument: wird beim Öffnen einer Datei wiederverwendet."""
        return (not self.modified and self.path is None and not self.source_note and self.doc.isEmpty()
                and not self.md_dirty and not self.tex_dirty)

    def open_file(self, path, convert=False):
        """Öffnet eine Datei in einem eigenen Tab (PDFs als PDF-Tab, Tabellen in eigenen Fenstern).
        Ist die Datei schon offen, wird zu ihrem Tab gewechselt."""
        path = os.path.abspath(path)
        ext = os.path.splitext(path)[1].lower()
        if not convert and ext in (".xlsx", ".xlsm", ".ods", ".pdf"):
            if self.open_child(path, ext):
                return
        if not convert:
            for t in list(self.tabs.values()):
                if self._tab_path(t) == path:
                    self._activate(t)
                    return
        fresh = None
        if not self.is_pristine():
            fresh = self.new_tab()
        if not self._load_file(path, ext, convert) and fresh is not None:
            self._discard_tab(fresh)

    def _load_file(self, path, ext, convert):
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            self._loading = True
            if ext in (".md", ".markdown", ".mdown"):
                with open(path, encoding="utf-8-sig", errors="replace") as f:
                    text = f.read()
                self.new_document(first=True)
                self.path = path
                self.kind = "md"
                self.md_edit.setPlainText(text)
                self._loading = False
                self.load_from_markdown(text)
                self.md_dirty = False
                target = VIEW_MD
            elif ext == ".tex":
                with open(path, "rb") as f:
                    raw = f.read()
                text = raw.decode("utf-8", errors="replace").replace("\r\n", "\n")
                self.new_document(first=True)
                self.tex_eol = "\r\n" if b"\r\n" in raw else "\n"
                self.path = path
                self.kind = "tex"
                self.tex_edit.setPlainText(text)
                self._loading = False
                self.load_from_latex(text)
                self.tex_dirty = False
                target = VIEW_TEX
            else:
                self._loading = False
                res = read_any(path)
                self.new_document(first=True)
                self._loading = True
                try:
                    self.build_detached(res.blocks)
                finally:
                    self._loading = False
                self.rev += 1
                if res.kind == "odt":
                    self.path = path if ext in (".odt",) else None
                    self.kind = "odt"
                    self.source_note = "" if self.path else "aus " + os.path.basename(path)
                    if self.path and not is_own_file(path):
                        self.attach_odt_source(path)
                    target = VIEW_RICH
                else:
                    self.path = None
                    self.kind = "tex"
                    self.source_note = "aus " + os.path.basename(path)
                    target = VIEW_TEX if self.settings.get("foreign_to_latex", True) else VIEW_RICH
            self._loading = False
        except ReaderError as e:
            self._loading = False
            QApplication.restoreOverrideCursor()
            QMessageBox.warning(self, APP_NAME, str(e))
            return False
        except Exception as e:   # Datei defekt o. ä.
            self._loading = False
            QApplication.restoreOverrideCursor()
            import traceback
            QMessageBox.warning(self, APP_NAME, "Die Datei konnte nicht geöffnet werden:\n%s: %s\n\n%s"
                                % (type(e).__name__, e, traceback.format_exc()[-900:]))
            return False
        QApplication.restoreOverrideCursor()
        self.set_modified(self.path is None)
        self.disk_sig = file_sig(self.path) if self.path else None
        self.add_recent(path)
        self.apply_base()
        self.set_view(target)
        self.update_title()
        if self.prev_panel.isVisible():
            self.refresh_preview(True)
        if self.path is None:
            self.status.showMessage("Geöffnet: %s – zum Speichern „Speichern unter“ wählen." % os.path.basename(path), 8000)
        return True

    # ------------------------------------------------------------- Vorlagen der Schnellbearbeitung
    def builtin_templates(self):
        d = os.path.join(os.path.dirname(os.path.abspath(__file__)), "vorlagen")
        out = []
        try:
            for n in sorted(os.listdir(d)):
                if n.lower().endswith(".tex"):
                    with open(os.path.join(d, n), encoding="utf-8", newline="") as f:
                        out.append((n[:-4], f.read()))
        except OSError:
            pass
        return out

    def template_store_dir(self):
        return os.path.join(CONF_DIR, "vorlagen")

    def stored_templates(self):
        try:
            return sorted(n[:-4] for n in os.listdir(self.template_store_dir()) if n.lower().endswith(".tex"))
        except OSError:
            return []

    def read_stored_template(self, name):
        try:
            with open(os.path.join(self.template_store_dir(), name + ".tex"), encoding="utf-8", newline="") as f:
                return f.read()
        except OSError:
            return None

    def open_template(self, text, name, key, folder):
        """Lädt eine Vorlage in die Schnellbearbeitung (in einem neuen Tab, wenn dieser schon belegt ist).
        Die Vorlage selbst wird nie überschrieben: das Dokument hat keinen Dateipfad."""
        try:
            Q.parse_tex(text.replace("\r\n", "\n"))
        except Q.TexError as e:
            QMessageBox.information(self, "Vorlage laden", str(e))
            return False
        fresh = None
        if not self.is_pristine():
            fresh = self.new_tab()
        eol = "\r\n" if "\r\n" in text else "\n"
        text = text.replace("\r\n", "\n")
        self.new_document(first=True)
        self.tex_eol = eol
        self._loading = True
        try:
            self.tex_edit.setPlainText(text)
        finally:
            self._loading = False
        self.kind = "tex"
        self.source_note = "Vorlage " + name
        self.load_from_latex(text)
        self.tex_dirty = False
        self.q_tpl, self.q_tpl_key, self.q_dir = name, key, folder
        self.q_name, self.q_name_auto = "", False
        self.view = VIEW_RICH
        self.set_view(VIEW_QUICK)
        if self.view != VIEW_QUICK:
            if fresh is not None:
                self._discard_tab(fresh)
            return False
        self.q_original = text
        self.set_modified(False)
        self.update_title()
        return True

    def add_recent(self, path):
        r = [p for p in self.settings.get("recent", []) if p != path]
        r.insert(0, path)
        self.settings["recent"] = r[:10]
        save_settings(self.settings)
        self.refresh_recent()

    def refresh_recent(self):
        self.recent_menu.clear()
        for p in self.settings.get("recent", []):
            if os.path.exists(p):
                a = self.recent_menu.addAction(os.path.basename(p))
                a.setToolTip(p)
                a.triggered.connect(lambda _=False, p=p: self.open_file(p))

    # ------------------------------------------------------------- Speichern
    def cmd_save(self):
        if self.view == VIEW_QUICK and self.q_doc is not None:
            return self.quick.save_tex()
        if self.path:
            return self.save_to(self.path)
        return self.cmd_saveas()

    def cmd_saveas(self):
        if self.path:
            start = self.path
        else:
            stem = "Unbenannt"
            m = re.match(r"aus (.+?)(\.[^.]+)?$", self.source_note or "")
            if m:
                stem = m.group(1)
            ext = ".tex" if (self.kind == "tex" or self.view == VIEW_TEX) else (".md" if self.kind == "md" else ".odt")
            start = os.path.join(os.path.expanduser("~"), stem + ext)
        filters = ";;".join(SAVE_FILTERS)
        default = {"tex": "LaTeX (*.tex)", "md": "Markdown (*.md)"}.get(self.kind, "OpenDocument-Text (*.odt)")
        p, sel = QFileDialog.getSaveFileName(self, "Speichern unter", start, filters, default)
        if not p:
            return False
        ext = os.path.splitext(p)[1].lower()
        if ext not in (".odt", ".md", ".tex", ".pdf", ".docx", ".html"):
            p += SAVE_FILTERS.get(sel, ".odt")
        return self.save_to(p)

    def save_to(self, path):
        ext = os.path.splitext(path)[1].lower()
        try:
            if ext == ".odt":
                self.commit()
                if self.odt_src is not None or self.odt_lock:
                    if not self.save_odt_preserving(path):
                        return False
                else:
                    write_odt(self.doc, path, os.path.dirname(self.path) if self.path else None)
                self.kind = "odt"
            elif ext in (".md", ".markdown"):
                with open(path, "w", encoding="utf-8") as f:
                    f.write(self.current_markdown())
                if getattr(self, "md_images", None):
                    d = os.path.join(os.path.dirname(path), "bilder")
                    os.makedirs(d, exist_ok=True)
                    for n, data in self.md_images.items():
                        with open(os.path.join(d, n), "wb") as f:
                            f.write(data)
                self.kind = "md"
            elif ext == ".tex":
                text = self.current_latex()
                if self.tex_eol == "\r\n":
                    text = text.replace("\n", "\r\n")
                with open(path, "w", encoding="utf-8", newline="") as f:
                    f.write(text)
                if self.last_images:
                    d = os.path.join(os.path.dirname(path), "bilder")
                    os.makedirs(d, exist_ok=True)
                    for n, data in self.last_images.items():
                        with open(os.path.join(d, n), "wb") as f:
                            f.write(data)
                self.kind = "tex"
            elif ext == ".pdf":
                return self.export_pdf_tex(path)
            elif ext == ".docx":
                return self.export_docx(path)
            elif ext in (".html", ".htm"):
                return self.export_html(path)
            else:
                QMessageBox.warning(self, APP_NAME, "Unbekannte Endung: %s" % ext)
                return False
        except OSError as e:
            QMessageBox.warning(self, APP_NAME, "Speichern fehlgeschlagen:\n%s" % e)
            return False
        self.path = path
        self.source_note = ""
        self.disk_sig = file_sig(path)
        self.ext_changed = False
        self.set_modified(False)
        self.add_recent(path)
        self.status.showMessage("Gespeichert: " + path, 5000)
        return True

    # ------------------------------------------------------------- Export
    def ask_export(self, title, ext, filt):
        base = os.path.splitext(self.path)[0] + ext if self.path else os.path.join(os.path.expanduser("~"), "Unbenannt" + ext)
        p, _ = QFileDialog.getSaveFileName(self, title, base, filt)
        return p

    def cmd_export_pdf_tex(self):
        p = self.ask_export("PDF speichern", ".pdf", "PDF (*.pdf)")
        if p:
            self.export_pdf_tex(p)

    def export_pdf_tex(self, path):
        self.pdf_after = path
        self.set_view(VIEW_TEX)
        self.compile()
        return True

    def cmd_preview(self):
        """Seitenvorschau: im LaTeX-Modus das gesetzte PDF, sonst Druckvorschau der formatierten Ansicht."""
        if self.view == VIEW_TEX:
            self.compile()
            return
        from PySide6.QtPrintSupport import QPrinter, QPrintPreviewDialog
        from PySide6.QtCore import QMarginsF
        self.commit()
        d = self.doc.clone()
        pr = QPrinter(QPrinter.PrinterMode.HighResolution)
        pr.setPageSize(QPageSize(QPageSize.PageSizeId.A4))
        pr.setPageMargins(QMarginsF(25, 25, 25, 25), QPageLayout.Unit.Millimeter)
        dlg = QPrintPreviewDialog(pr, self)
        dlg.setWindowTitle("Seitenvorschau")
        dlg.resize(900, 750)
        dlg.paintRequested.connect(lambda p: d.print_(p))
        dlg.exec()

    # ---- PDF-Vorschau neben dem Text (echte Darstellung über LibreOffice)
    def toggle_preview(self):
        on = self.a_pdfprev.isChecked()
        if on and self.prev_view is None:
            self.a_pdfprev.setChecked(False)
            QMessageBox.information(self, APP_NAME, "Die PDF-Anzeige (QtPdf) ist in dieser Installation nicht vorhanden.")
            return
        if on and self.view != VIEW_RICH:
            self.set_view(VIEW_RICH)
        self.prev_panel.setVisible(on)
        if on:
            w = self.rich_split.width()
            self.rich_split.setSizes([w // 2, w // 2])
            self.refresh_preview(True)

    def _print_pdf(self, out):
        from PySide6.QtPrintSupport import QPrinter
        from PySide6.QtCore import QMarginsF
        pr = QPrinter(QPrinter.PrinterMode.HighResolution)
        pr.setOutputFormat(QPrinter.OutputFormat.PdfFormat)
        pr.setOutputFileName(out)
        pr.setPageSize(QPageSize(QPageSize.PageSizeId.A4))
        pr.setPageMargins(QMarginsF(25, 25, 25, 25), QPageLayout.Unit.Millimeter)
        self.doc.clone().print_(pr)

    def refresh_preview(self, force=False):
        if not self.prev_panel.isVisible() or self.prev_view is None:
            return
        if self.prev_proc is not None:
            self.prev_pending = True
            return
        if self.view != VIEW_RICH:
            return
        self.prev_rev_next = self.rev
        work = os.path.join(self.work, "vorschau")
        shutil.rmtree(work, ignore_errors=True)
        os.makedirs(work, exist_ok=True)
        src = os.path.join(work, "dokument.odt")
        note = ""
        try:
            base = os.path.dirname(self.path) if self.path else None
            if self.odt_src is not None:
                try:
                    self.odt_src.save(self.doc, src, lambda p: True)
                except PatchError:
                    write_odt(self.doc, src, base)
                    note = "Vereinfachte Darstellung: Die letzte Änderung lässt sich nicht formaterhaltend speichern."
            else:
                write_odt(self.doc, src, base)
        except Exception as e:
            self.prev_note.setText("Vorschau nicht möglich: %s" % e)
            return
        so = find_soffice()
        if not so:
            out = os.path.join(work, "dokument.pdf")
            self._print_pdf(out)
            self._preview_done(out, "Einfache Darstellung (LibreOffice nicht gefunden).")
            return
        self.prev_note.setText("Vorschau wird erzeugt …")
        self.prev_btn.setEnabled(False)
        prof = os.path.join(tempfile.gettempdir(), "seiffert-text-lo-profil")
        self.prev_proc = QProcess(self)
        self.prev_proc.setWorkingDirectory(work)
        self.prev_proc.finished.connect(lambda *_: self._preview_finished(work, note))
        self.prev_proc.errorOccurred.connect(lambda *_: self._preview_finished(work, note))
        self.prev_proc.start(so, ["-env:UserInstallation=file://" + prof, "--headless", "--convert-to", "pdf",
                                  "--outdir", work, src])

    def _preview_finished(self, work, note):
        proc, self.prev_proc = self.prev_proc, None
        if proc is None:
            return
        proc.deleteLater()
        self.prev_btn.setEnabled(True)
        out = os.path.join(work, "dokument.pdf")
        if os.path.exists(out):
            self._preview_done(out, note)
        else:
            self.prev_note.setText("LibreOffice konnte keine Vorschau erzeugen.")
        if self.prev_pending:
            self.prev_pending = False
            self.prev_timer.start()

    def _preview_done(self, pdf, note):
        self.prev_n += 1
        copy = os.path.join(self.work, "seitenbild-%d.pdf" % self.prev_n)
        shutil.copyfile(pdf, copy)
        bar = self.prev_view.verticalScrollBar().value()
        self.prev_doc.load(copy)
        QTimer.singleShot(200, lambda: self.prev_view.verticalScrollBar().setValue(bar))
        old, self.prev_loaded = self.prev_loaded, copy
        self.prev_rev = self.prev_rev_next
        if old and old != copy and os.path.exists(old):
            try:
                os.remove(old)
            except OSError:
                pass
        self.prev_note.setText(note or "%d Seite(n), Darstellung wie in LibreOffice." % self.prev_doc.pageCount())

    def cmd_export_pdf_view(self):
        from PySide6.QtPrintSupport import QPrinter
        p = self.ask_export("PDF aus formatierter Ansicht", ".pdf", "PDF (*.pdf)")
        if not p:
            return
        self.commit()
        pr = QPrinter(QPrinter.PrinterMode.HighResolution)
        pr.setOutputFormat(QPrinter.OutputFormat.PdfFormat)
        pr.setOutputFileName(p)
        pr.setPageSize(QPageSize(QPageSize.PageSizeId.A4))
        pr.setPageMargins(__import__("PySide6.QtCore", fromlist=["QMarginsF"]).QMarginsF(25, 25, 25, 25), QPageLayout.Unit.Millimeter)
        d = self.doc.clone()
        d.print_(pr)
        self.status.showMessage("PDF gespeichert: " + p, 5000)

    def cmd_export_docx(self):
        p = self.ask_export("Als Word-Datei speichern", ".docx", "Word (*.docx)")
        if p:
            self.export_docx(p)

    def export_docx(self, path):
        if not find_soffice():
            QMessageBox.warning(self, APP_NAME, "Für Word-Dateien wird LibreOffice benötigt. Es wurde nicht gefunden.")
            return False
        self.commit()
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            with tempfile.TemporaryDirectory(prefix="seiffert-text-") as td:
                src = os.path.join(td, os.path.splitext(os.path.basename(path))[0] + ".odt")
                write_odt(self.doc, src)
                out = lo_convert(src, "docx", td)
                shutil.copyfile(out, path)
        except Exception as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.warning(self, APP_NAME, "Word-Export fehlgeschlagen:\n%s" % e)
            return False
        QApplication.restoreOverrideCursor()
        self.status.showMessage("Word-Datei gespeichert: " + path, 5000)
        return True

    def cmd_export_html(self):
        p = self.ask_export("Als HTML speichern", ".html", "HTML (*.html)")
        if p:
            self.export_html(p)

    def export_html(self, path):
        self.commit()
        with open(path, "w", encoding="utf-8") as f:
            f.write(self.doc.toHtml())
        self.status.showMessage("HTML gespeichert: " + path, 5000)
        return True

    # ------------------------------------------------------------- LaTeX übersetzen
    def on_engine(self, name):
        self.settings["engine"] = name
        save_settings(self.settings)

    def find_engine(self):
        eng = self.cmb_engine.currentText()
        return shutil.which(eng)

    def compile(self, silent=False):
        if self.proc is not None:
            return
        if self.view not in (VIEW_TEX, VIEW_QUICK):
            self.set_view(VIEW_TEX)
        text = self.current_latex()
        self.compile_job = "main"
        if self.view == VIEW_QUICK:
            self.compile_job = Q.clean_name(self.q_name) or "Vorschau"
        exe = self.find_engine()
        if not exe:
            msg = ("Der Übersetzer „%s“ wurde nicht gefunden. Bitte eine TeX-Live-Installation einrichten "
                   "(unter Arch zum Beispiel texlive-basic, texlive-latex, texlive-latexrecommended, "
                   "texlive-fontsrecommended und texlive-langgerman)." % self.cmb_engine.currentText())
            self.log.setPlainText(msg)
            if not silent:
                self.lbl_compile.setText("Kein LaTeX gefunden")
            return
        os.makedirs(os.path.join(self.work, "bilder"), exist_ok=True)
        for n, data in self.last_images.items():
            with open(os.path.join(self.work, "bilder", n), "wb") as f:
                f.write(data)
        with open(os.path.join(self.work, "main.tex"), "w", encoding="utf-8") as f:
            f.write(text)
        if self.view == VIEW_QUICK:
            self.stage_assets(text)
        self.compile_pass = 0
        self.compile_exe = exe
        self.lbl_compile.setText("Übersetze …")
        self.btn_compile.setEnabled(False)
        self.quick.sync_compile()
        self.run_pass()

    def stage_assets(self, text):
        """Bilder, die die Vorlage braucht (Logo, content/…), in den Arbeitsordner legen."""
        try:
            doc = self.q_doc or Q.parse_tex(text)
            names = Q.find_images(doc, {"autoEscape": False, "autoBreak": False})
        except Q.TexError:
            return
        for n in names:
            rel = n[2:] if n.startswith("./") else n
            if os.path.isabs(rel) or ".." in rel.split("/"):
                continue
            src = self.quick.find_asset(n)
            if not src:
                continue
            dst = os.path.join(self.work, rel)
            try:
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copyfile(src, dst)
            except OSError:
                pass

    def run_pass(self):
        self.proc = QProcess(self)
        env = QProcessEnvironment.systemEnvironment()
        sep = os.pathsep
        extra = (self.quick.target_dir() if self.view == VIEW_QUICK else self.base_dir()) or ""
        env.insert("TEXINPUTS", ".%s%s%s" % (sep, (extra + sep) if extra else "", env.value("TEXINPUTS", "")) + (sep if not env.value("TEXINPUTS", "").endswith(sep) else ""))
        self.proc.setProcessEnvironment(env)
        self.proc.setWorkingDirectory(self.work)
        self.proc.finished.connect(self.on_pass_done)
        self.proc.errorOccurred.connect(lambda e: None)
        self.proc.start(self.compile_exe, ["-interaction=nonstopmode", "-file-line-error",
                                          "-jobname", getattr(self, "compile_job", "main"), "main.tex"])

    def read_log(self):
        try:
            with open(os.path.join(self.work, getattr(self, "compile_job", "main") + ".log"), encoding="utf-8", errors="replace") as f:
                return f.read()
        except OSError:
            return ""

    def on_pass_done(self, code, status):
        self.proc = None
        log = self.read_log()
        self.compile_pass += 1
        if self.compile_pass < 3 and re.search(r"Rerun to get|Label\(s\) may have changed|undefined references", log) \
                and code == 0:
            self.run_pass()
            return
        errs = re.findall(r"^(?:\./)?main\.tex:(\d+): (.*)$", log, re.M)
        bang = [x for x in re.findall(r"^! (.*)$", log, re.M)]
        pdf = os.path.join(self.work, getattr(self, "compile_job", "main") + ".pdf")
        self.btn_compile.setEnabled(True)
        if errs and not any(e[1].startswith("Emergency") for e in errs[:1]) or (errs and not bang):
            self.log.setPlainText("\n".join("Zeile %s: %s" % e for e in errs[:30]) +
                                  "\n\n(Doppelklick auf eine Zeile springt im Quelltext dorthin.)\n\n" + log[-3000:])
            self.lbl_compile.setText("%d Fehler" % len(errs))
        elif code != 0 or errs:
            self.log.setPlainText("\n".join(bang[:10]) + "\n\n" + log[-3500:])
            self.lbl_compile.setText("Fehler beim Übersetzen")
        else:
            warn = len(re.findall(r"Warning", log))
            self.log.setPlainText("Übersetzt." + (" %d Warnungen." % warn if warn else "") + "\n\n" + log[-1500:])
            self.lbl_compile.setText("Fertig")
        if os.path.exists(pdf) and (code == 0 or not errs):
            self.show_pdf(pdf)
            if self.pdf_after:
                try:
                    shutil.copyfile(pdf, self.pdf_after)
                    self.status.showMessage("PDF gespeichert: " + self.pdf_after, 6000)
                except OSError as e:
                    QMessageBox.warning(self, APP_NAME, str(e))
                self.pdf_after = None
        elif self.pdf_after:
            QMessageBox.warning(self, APP_NAME, "Das PDF konnte nicht erzeugt werden. Siehe Meldungen im LaTeX-Bereich.")
            self.pdf_after = None
        self.quick.sync_compile()

    def show_pdf(self, pdf):
        self.last_pdf = pdf
        if self.pdf_view is not None:
            bar = self.pdf_view.verticalScrollBar().value()
            copy = os.path.join(self.work, "vorschau-%d.pdf" % self.compile_pass_id())
            shutil.copyfile(pdf, copy)
            self.pdf_doc.load(copy)
            self.pdf_loaded = copy
            QTimer.singleShot(200, lambda: self.pdf_view.verticalScrollBar().setValue(bar))
        else:
            self.open_pdf_external()

    def compile_pass_id(self):
        self._pid = getattr(self, "_pid", 0) + 1
        return self._pid

    def open_pdf_external(self):
        pdf = self.last_pdf or os.path.join(self.work, "main.pdf")
        if os.path.exists(pdf):
            subprocess.Popen(["xdg-open", pdf])
        else:
            self.status.showMessage("Noch kein PDF vorhanden – bitte zuerst übersetzen (F5).", 5000)

    def _log_dbl(self, ev):
        cur = self.log.cursorForPosition(ev.position().toPoint())
        m = re.match(r"Zeile (\d+):", cur.block().text())
        if m:
            self.tex_edit.goto_line(int(m.group(1)))
            self.tex_edit.setFocus()
        else:
            QPlainTextEdit.mouseDoubleClickEvent(self.log, ev)

    # ------------------------------------------------------------- Formatieren
    def toggle_char(self, key):
        if self.view != VIEW_RICH:
            return
        cur = self.rich.textCursor()
        cf = cur.charFormat()
        on = self._has_char(cf, key)
        new = QTextCharFormat()
        if key == "b":
            new.setFontWeight(QFont.Weight.Normal if on else QFont.Weight.Bold)
        elif key == "i":
            new.setFontItalic(not on)
        elif key == "u":
            new.setFontUnderline(not on)
        elif key == "st":
            new.setFontStrikeOut(not on)
        elif key == "tt":
            if on:
                new.setFontFixedPitch(False)
                new.setFontFamilies([base_font().family()])
            else:
                new.setFontFixedPitch(True)
                new.setFontFamilies(["monospace", "DejaVu Sans Mono"])
        elif key in ("sup", "sub"):
            va = QTextCharFormat.VerticalAlignment
            want = va.AlignSuperScript if key == "sup" else va.AlignSubScript
            new.setVerticalAlignment(va.AlignNormal if on else want)
        cur.mergeCharFormat(new)
        self.rich.mergeCurrentCharFormat(new)
        self.sync_format_state()

    @staticmethod
    def _has_char(cf, key):
        va = QTextCharFormat.VerticalAlignment
        if key == "b":
            return cf.fontWeight() >= 700
        if key == "i":
            return cf.fontItalic()
        if key == "u":
            return cf.fontUnderline() and not cf.isAnchor()
        if key == "st":
            return cf.fontStrikeOut()
        if key == "tt":
            return cf.fontFixedPitch()
        if key == "sup":
            return cf.verticalAlignment() == va.AlignSuperScript
        if key == "sub":
            return cf.verticalAlignment() == va.AlignSubScript
        return False

    def sync_format_state(self):
        if self.view != VIEW_RICH:
            return
        cf = self.rich.currentCharFormat()
        for key, a in (("b", self.a_bold), ("i", self.a_italic), ("u", self.a_under), ("st", self.a_strike),
                       ("tt", self.a_mono), ("sup", self.a_sup), ("sub", self.a_sub)):
            a.blockSignals(True)
            a.setChecked(bool(self._has_char(cf, key)))
            a.blockSignals(False)
        cur = self.rich.textCursor()
        lst = cur.currentList()
        st = lst.format().style() if lst else None
        for a, s in ((self.a_ul, QTextListFormat.Style.ListDisc), (self.a_ol, QTextListFormat.Style.ListDecimal)):
            a.blockSignals(True)
            a.setChecked(st == s)
            a.blockSignals(False)
        al = cur.blockFormat().alignment()
        for a, f in ((self.a_center, Qt.AlignmentFlag.AlignHCenter), (self.a_right, Qt.AlignmentFlag.AlignRight),
                     (self.a_just, Qt.AlignmentFlag.AlignJustify)):
            a.blockSignals(True)
            a.setChecked(bool(al & f))
            a.blockSignals(False)
        if not (al & (Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignJustify)):
            self.a_left.blockSignals(True)
            self.a_left.setChecked(True)
            self.a_left.blockSignals(False)
        bf = cur.blockFormat()
        idx = 0
        if bf.headingLevel():
            idx = min(4, bf.headingLevel())
        elif bf.hasProperty(QTextFormat.Property.BlockQuoteLevel):
            idx = 5
        elif bf.hasProperty(QTextFormat.Property.BlockCodeFence):
            idx = 6
        self.cmb_para.blockSignals(True)
        self.cmb_para.setCurrentIndex(idx)
        self.cmb_para.blockSignals(False)

    def toggle_list(self, style):
        cur = self.rich.textCursor()
        lst = cur.currentList()
        cur.beginEditBlock()
        if lst is not None and lst.format().style() == style:
            blk = cur.block()
            lst.remove(blk)
            bf = cur.blockFormat()
            bf.setIndent(0)
            cur.setBlockFormat(bf)
        else:
            fmt = QTextListFormat()
            fmt.setStyle(style)
            fmt.setIndent(lst.format().indent() if lst else 1)
            cur.createList(fmt)
        cur.endEditBlock()
        self.sync_format_state()

    def set_align(self, a):
        self.rich.setAlignment(a)
        self.sync_format_state()

    def on_para_combo(self, idx):
        self.set_para(idx if idx <= 4 else ("quote" if idx == 5 else "code"))

    def set_para(self, what):
        if self.view != VIEW_RICH:
            return
        cur = self.rich.textCursor()
        cur.beginEditBlock()
        blocks = []
        if cur.hasSelection():
            doc = self.doc
            b = doc.findBlock(cur.selectionStart())
            end = cur.selectionEnd()
            while b.isValid() and b.position() <= end:
                blocks.append(b)
                b = b.next()
        else:
            blocks = [cur.block()]
        for b in blocks:
            c = QTextCursor(b)
            bf = c.blockFormat()
            # alte Absatzart entfernen
            for prop in (QTextFormat.Property.BlockQuoteLevel, QTextFormat.Property.BlockCodeFence,
                         QTextFormat.Property.BlockCodeLanguage):
                bf.clearProperty(prop)
            bf.setLeftMargin(0)
            bf.setRightMargin(0)
            bf.setBackground(QBrush(Qt.GlobalColor.transparent))
            bf.clearBackground()
            bf.setNonBreakableLines(False)
            c.setBlockFormat(bf)
            if isinstance(what, int):
                apply_heading(c, what)
            elif what == "quote":
                apply_heading(c, 0)
                bf = c.blockFormat()
                bf.setProperty(QTextFormat.Property.BlockQuoteLevel, 1)
                bf.setLeftMargin(32)
                bf.setRightMargin(16)
                c.setBlockFormat(bf)
            elif what == "code":
                apply_heading(c, 0)
                cb, cc = code_block_formats()
                bf = c.blockFormat()
                for prop in (QTextFormat.Property.BlockCodeFence, QTextFormat.Property.BlockCodeLanguage):
                    bf.setProperty(prop, cb.property(prop))
                bf.setNonBreakableLines(True)
                bf.setBackground(cb.background())
                c.setBlockFormat(bf)
                c.select(QTextCursor.SelectionType.BlockUnderCursor)
                c.movePosition(QTextCursor.MoveOperation.StartOfBlock)
                c.movePosition(QTextCursor.MoveOperation.EndOfBlock, QTextCursor.MoveMode.KeepAnchor)
                c.mergeCharFormat(cc)
        cur.endEditBlock()
        self.sync_format_state()

    # ------------------------------------------------------------- Einfügen
    def ins_link(self):
        if self.view != VIEW_RICH:
            return
        cur = self.rich.textCursor()
        url, ok = QInputDialog.getText(self, "Link", "Adresse (zum Beispiel https://…):",
                                       text=cur.charFormat().anchorHref() if cur.charFormat().isAnchor() else "")
        if not ok:
            return
        if not url.strip():
            f = QTextCharFormat()
            f.setAnchor(False)
            f.setAnchorHref("")
            f.setFontUnderline(False)
            f.setForeground(self.rich.palette().text())
            cur.mergeCharFormat(f)
            return
        if not cur.hasSelection():
            cur.insertText(url, char_format(href=url))
        else:
            cur.mergeCharFormat(char_format(href=url))

    def ins_image(self):
        p, _ = QFileDialog.getOpenFileName(self, "Bild einfügen", os.path.expanduser("~"),
                                           "Bilder (*.png *.jpg *.jpeg *.gif *.bmp *.webp);;Alle Dateien (*)")
        if not p:
            return
        img = QImage(p)
        if img.isNull():
            QMessageBox.warning(self, APP_NAME, "Das Bild konnte nicht gelesen werden.")
            return
        insert_image_into(self.rich, img, os.path.splitext(os.path.basename(p))[0])

    def ins_table(self):
        d = QDialog(self)
        d.setWindowTitle("Tabelle einfügen")
        fl = QFormLayout(d)
        sr = QSpinBox()
        sr.setRange(1, 200)
        sr.setValue(3)
        sc = QSpinBox()
        sc.setRange(1, 30)
        sc.setValue(3)
        hd = QCheckBox("Erste Zeile ist Kopfzeile")
        hd.setChecked(True)
        fl.addRow("Zeilen", sr)
        fl.addRow("Spalten", sc)
        fl.addRow(hd)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(d.accept)
        bb.rejected.connect(d.reject)
        fl.addRow(bb)
        if d.exec() != QDialog.DialogCode.Accepted:
            return
        tf = QTextTableFormat()
        tf.setBorder(1)
        tf.setBorderStyle(QTextTableFormat.BorderStyle.BorderStyle_Solid)
        tf.setCellPadding(4)
        tf.setCellSpacing(0)
        tf.setWidth(QTextLength(QTextLength.Type.PercentageLength, 100))
        if hd.isChecked():
            tf.setHeaderRowCount(1)
        cur = self.rich.textCursor()
        if cur.block().length() > 1:
            cur.insertBlock(QTextBlockFormat(), QTextCharFormat())
        tbl = cur.insertTable(sr.value(), sc.value(), tf)
        if hd.isChecked():
            for c in range(sc.value()):
                cc = tbl.cellAt(0, c).firstCursorPosition()
                cc.setBlockCharFormat(char_format(b=True))

    def ins_checkbox(self, checked=False):
        """Kontrollkästchen einfügen: am Anfang jeder markierten Zeile, sonst an der Cursorstelle.
        Formatiert und Markdown: das Zeichen ☐ (angekreuzt ☒); LaTeX: $\\square$; Schnellbearbeitung: im Textfeld."""
        if self.view == VIEW_QUICK:
            self.quick.insert_box(checked)
            return
        if self.view == VIEW_TEX:
            mark = r"$\boxtimes$" if checked else r"$\square$"
        else:
            mark = BOX_CROSS if checked else BOX_EMPTY
        w = self.active_text()
        cur = w.textCursor()
        doc = w.document()
        cur.beginEditBlock()
        try:
            if cur.hasSelection() and doc.findBlock(cur.selectionStart()) != doc.findBlock(cur.selectionEnd()):
                b = doc.findBlock(cur.selectionStart())
                last = doc.findBlock(cur.selectionEnd()).blockNumber()
                if cur.selectionEnd() == doc.findBlock(cur.selectionEnd()).position():
                    last -= 1          # die Zeile, in der die Markierung nur beginnt, zählt nicht mit
                while b.isValid() and b.blockNumber() <= last:
                    t = b.text()
                    if t.strip() and not t.lstrip().startswith((BOX_EMPTY, BOX_CHECK, BOX_CROSS, r"$\square$", r"$\boxtimes$")):
                        c = QTextCursor(b)
                        c.insertText(mark + " ")
                    b = b.next()
            else:
                if cur.hasSelection():
                    cur.setPosition(cur.selectionStart())
                cur.insertText(mark + " ")
                w.setTextCursor(cur)
        finally:
            cur.endEditBlock()
        if self.view == VIEW_TEX:
            self.ensure_amssymb()
        w.setFocus()

    def ensure_amssymb(self):
        """Fügt \\usepackage{amssymb} ein, wenn der LaTeX-Text es für \\square braucht und es fehlt."""
        t = self.tex_edit.toPlainText()
        m = re.search(r"\\begin\{document\}", t)
        head = t[:m.start()] if m else t
        if re.search(r"^[^%\n]*\\usepackage(?:\[[^\]]*\])?\{[^}]*\bams(?:symb|fonts)\b[^}]*\}", head, re.M):
            return
        d = re.search(r"\\documentclass(?:\[[^\]]*\])?\{[^}]*\}[^\n]*\n", t)
        if not d:
            return
        c = QTextCursor(self.tex_edit.document())
        c.setPosition(d.end())
        c.insertText("\\usepackage{amssymb}\n")

    def ins_hr(self):
        cur = self.rich.textCursor()
        bf = QTextBlockFormat()
        bf.setProperty(QTextFormat.Property.BlockTrailingHorizontalRulerWidth,
                       QTextLength(QTextLength.Type.PercentageLength, 100))
        cur.insertBlock(bf, QTextCharFormat())
        cur.insertBlock(QTextBlockFormat(), QTextCharFormat())

    def ins_math_inline(self):
        cur = self.rich.textCursor()
        sel = cur.selectedText()
        cur.insertText("$%s$" % (sel if sel else "x"), raw_inline_format())
        cur.setCharFormat(QTextCharFormat())

    def ins_math_block(self):
        self.ins_raw_block("\\[\n  E = mc^2\n\\]")

    def ins_footnote(self):
        t, ok = QInputDialog.getMultiLineText(self, "Fußnote", "Text der Fußnote (LaTeX-Zeichen wie % und & bitte mit \\ davor):")
        if ok and t.strip():
            cur = self.rich.textCursor()
            cur.insertText("\\footnote{%s}" % t.strip().replace("\n", " "), raw_inline_format())
            cur.setCharFormat(QTextCharFormat())

    def ins_raw_block(self, text):
        cur = self.rich.textCursor()
        rb, rc = raw_block_formats()
        if cur.block().length() > 1:
            cur.insertBlock(QTextBlockFormat(), QTextCharFormat())
        cur.insertBlock(rb, rc)
        cur.insertText(text.replace("\n", LS), rc)
        cur.insertBlock(QTextBlockFormat(), QTextCharFormat())

    def ins_raw_free(self):
        t, ok = QInputDialog.getMultiLineText(self, "LaTeX-Rohtext", "Dieser Text wird unverändert in das LaTeX-Dokument übernommen:")
        if ok and t.strip():
            self.ins_raw_block(t.strip())

    def tbl_op(self, op):
        cur = self.rich.textCursor()
        tbl = cur.currentTable()
        if tbl is None:
            self.status.showMessage("Der Cursor steht nicht in einer Tabelle.", 4000)
            return
        cell = tbl.cellAt(cur)
        if op == "row+":
            tbl.insertRows(cell.row() + cell.rowSpan(), 1)
        elif op == "col+":
            tbl.insertColumns(cell.column() + cell.columnSpan(), 1)
        elif op == "row-":
            if tbl.rows() > 1:
                tbl.removeRows(cell.row(), 1)
        elif op == "col-":
            if tbl.columns() > 1:
                tbl.removeColumns(cell.column(), 1)
        elif op == "merge":
            tbl.mergeCells(cur)
        elif op == "split":
            tbl.splitCell(cell.row(), cell.column(), 1, 1)

    # ------------------------------------------------------------- Sonstiges
    def cmd_find(self):
        w = self.active_text()
        sel = w.textCursor().selectedText()
        self.find_bar.open(sel if sel and LS not in sel and "\u2029" not in sel else "")

    def zoom(self, d):
        if d == 0:
            self.settings["zoom"] = 0
        else:
            self.settings["zoom"] = max(-6, min(20, self.settings.get("zoom", 0) + d))
        self.apply_zoom()
        save_settings(self.settings)

    def set_mode(self, light):
        self.settings["paper_light"] = bool(light)
        save_settings(self.settings)
        self.apply_paper()

    def toggle_paper(self):
        self.set_mode(not self.settings.get("paper_light", False))

    def apply_paper(self):
        """Hellmodus: weißes Blatt mit schwarzer Schrift in allen Dokument- und Quelltextansichten,
        unabhängig vom Systemthema. Dunkelmodus: Farben des Systems."""
        from PySide6.QtGui import QPalette, QColor
        light = bool(self.settings.get("paper_light", False))
        (self.a_mode_light if light else self.a_mode_dark).setChecked(True)
        css = ("QTextEdit, QPlainTextEdit, QTextBrowser { background-color: #ffffff; color: #000000; "
               "selection-background-color: #3584e4; selection-color: #ffffff; }")
        for w in (self.rich, self.md_view, self.md_edit, self.tex_edit):
            if light:
                p = QPalette(QApplication.palette())
                for role, col in ((QPalette.ColorRole.Base, "#ffffff"), (QPalette.ColorRole.Text, "#000000"),
                                  (QPalette.ColorRole.AlternateBase, "#eeeeee"),
                                  (QPalette.ColorRole.WindowText, "#000000"), (QPalette.ColorRole.Window, "#f4f4f4"),
                                  (QPalette.ColorRole.Link, "#1a5fb4"), (QPalette.ColorRole.Highlight, "#3584e4"),
                                  (QPalette.ColorRole.HighlightedText, "#ffffff"),
                                  (QPalette.ColorRole.PlaceholderText, "#777777")):
                    for grp in (QPalette.ColorGroup.Active, QPalette.ColorGroup.Inactive):
                        p.setColor(grp, role, QColor(col))
                w.setPalette(p)
                w.setStyleSheet(css)
            else:
                w.setStyleSheet("")
                w.setPalette(QApplication.palette())
            w.viewport().setPalette(w.palette())
            w.viewport().update()
            w.update()
        dark = (not light) and QApplication.palette().window().color().lightness() < 128
        was = self._loading
        self._loading = True        # Umfärben ist keine Textänderung
        try:
            self.md_hl.set_dark(dark)
            self.tex_hl.set_dark(dark)
        finally:
            self._loading = was

    def apply_zoom(self):
        z = self.settings.get("zoom", 0)
        f = base_font()
        f.setPointSize(max(6, 12 + z))
        self.doc.setDefaultFont(f)
        self.md_view.document().setDefaultFont(f)
        for e in (self.md_edit, self.tex_edit):
            ef = e.font()
            ef.setPointSize(max(6, 11 + z))
            e.setFont(ef)
            e.setTabStopDistance(e.fontMetrics().horizontalAdvance(" ") * 4)

    def edit_preamble(self):
        self.commit()
        d = QDialog(self)
        d.setWindowTitle("Dokumentkopf (Präambel)")
        lay = QVBoxLayout(d)
        lay.addWidget(QLabel("Alles vor \\begin{document}: Dokumentklasse, Pakete, Einstellungen."))
        ed = SourceEdit()
        LatexHighlighter(ed.document(), self.palette().window().color().lightness() < 128)
        ed.setPlainText(self.preamble)
        lay.addWidget(ed)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(d.accept)
        bb.rejected.connect(d.reject)
        lay.addWidget(bb)
        d.resize(700, 500)
        if d.exec() == QDialog.DialogCode.Accepted:
            self.preamble = ed.toPlainText().rstrip() + "\n"
            self.tex_synced = -1
            if self.view == VIEW_TEX:
                # Quelltext neu erzeugen, wenn dort nichts Eigenes steht
                if not self.tex_dirty:
                    self.current_latex()
                else:
                    t = self.tex_edit.toPlainText()
                    m = re.search(r"\\begin\{document\}", t)
                    if m:
                        self.tex_edit.setPlainText(self.preamble + "\n" + t[m.start():])
            self.set_modified(True)

    def toggle_foreign(self, v):
        self.settings["foreign_to_latex"] = bool(v)
        save_settings(self.settings)

    def show_help(self):
        QMessageBox.information(self, "Kurzanleitung", HELP_TEXT)

    def show_about(self):
        QMessageBox.about(self, "Über " + APP_NAME, "%s %s\n\nTextverarbeitung für ODT, Markdown und LaTeX.\n"
                          "Öffnet auch Word-, Excel- und OpenOffice-Dateien." % (APP_NAME, VERSION))

    # ------------------------------------------------------------- Ereignisse
    def closeEvent(self, e):
        # alle Tabs mit ungespeicherten Änderungen der Reihe nach vorlegen
        for i in range(self.tabbar.count()):
            t = self._tab_at(i)
            if t is not None and t.is_pdf:
                if t.s.get("modified"):
                    self._show_pdf(t)
                    if not t.widget.close():
                        e.ignore()
                        return
                continue
            if t is not None and self._tab_modified(t):
                self._activate(t)
                if not self.maybe_save():
                    e.ignore()
                    return
        for w in list(self.children_windows):
            if not w.close():
                e.ignore()
                return
        self._stop_procs()
        save_settings(self.settings)
        for t in self.tabs.values():
            shutil.rmtree(self.work if t is self.cur else t.s.get("work", ""), ignore_errors=True)
        e.accept()

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        for u in e.mimeData().urls():
            if u.isLocalFile():
                self.open_file(u.toLocalFile())


HELP_TEXT = """Vier Ansichten desselben Dokuments (Strg+1, 2, 3, 4):

Formatiert – wie in einer Textverarbeitung. Gespeichert wird als ODT.
Markdown – Quelltext links, Vorschau rechts.
LaTeX – Quelltext links, PDF-Vorschau rechts (F5 übersetzt).
Schnellbearbeitung – eine LaTeX-Vorlage zeilenweise bearbeiten, siehe unten.

Beim Wechsel der Ansicht wird das Dokument umgewandelt. Was LaTeX-Texte enthalten, das die formatierte Ansicht nicht kennt (eigene Befehle, Formeln, Gleitobjekte), bleibt als grauer Rohtext erhalten und wird unverändert zurückgeschrieben.

Word-, Excel-, OpenOffice- und andere Dateien werden geöffnet und als LaTeX gezeigt. Tabellenblätter werden zu LaTeX-Tabellen.

Alte Formate (doc, xls, rtf, sxw, ppt) werden über LibreOffice umgewandelt, wenn es installiert ist.

Kontrollkästchen (Strg+Umschalt+K, Menü Einfügen, Knopf Kästchen ☐ in der Werkzeugleiste): setzt ein ☐ an die Cursorstelle, bei mehreren markierten Zeilen eines an den Anfang jeder Zeile. Doppelklick auf ein Kästchen in der formatierten Ansicht kreuzt es an (☒) oder leert es. In LaTeX wird daraus $\\square$ beziehungsweise $\\boxtimes$ (das Paket amssymb wird bei Bedarf ergänzt), beim Lesen von LaTeX werden diese Zeichen wieder zu Kästchen. In der Schnellbearbeitung setzt der Knopf ☐ einer Zeile \\(\\square\\) in das Textfeld.

Mehrere Dokumente: Jede Datei öffnet in einem eigenen Tab. Die Farbe eines Tabs ändert man mit der rechten Maustaste auf den Tab; dieselbe Datei bekommt beim nächsten Öffnen wieder ihre Farbe. Strg+N neuer Tab, Strg+W Tab schließen, Strg+Bild auf und Bild ab wechseln, Doppelklick auf die freie Leiste öffnet einen neuen Tab. Beim Wechsel eines Tabs wird eine laufende LaTeX-Übersetzung abgebrochen. PDFs öffnen ebenfalls in einem Tab (auch neben Textdokumenten); dann zeigt das Fenster das Menü und die Leiste des PDF-Bearbeitens, Strg+W schließt den Tab, Strg+N und Strg+O gibt es im Menü Datei des PDFs. Tabellen (xlsx, ods) öffnen weiter in einem eigenen Fenster.

TeXstudio (F7, Menü LaTeX): Öffnet die .tex-Datei des Tabs in TeXstudio an der Zeile des Cursors. Ist das Dokument noch keine .tex-Datei, wird es dafür gespeichert. Speichert man in TeXstudio, lädt der Tab die Datei neu (gibt es hier ungespeicherte Änderungen, wird gefragt). Das Programm findet sich im Suchpfad oder als Flatpak, sonst unter Einstellungen, TeXstudio-Programm wählen.

Schnellbearbeitung (Strg+4): Für LaTeX-Vorlagen mit festem Aufbau, zum Beispiel Lernpläne. Die Vorlage wird als Liste von Zeilen gezeigt, bearbeitbar sind nur die Textfelder, Befehle bleiben geschützt. Eingebaute Vorlagen stehen oben in der Liste, mit „Datei laden“ kommt eine eigene .tex-Datei dazu, „Vorlage merken“ behält sie in der Liste. Enter in einem Feld legt darunter eine neue Zeile an, Umschalt+Enter setzt einen Zeilenumbruch. Themen lassen sich mit allen Zeilen verschieben, duplizieren und löschen, mit ≡＋ fügt man viele Zeilen auf einmal ein (auch aus Excel), mit ▣ Bilder aus dem Ordner content. Alles ist mit Rückgängig zurückzuholen. Der Dateiname oben ist zugleich der Name im Seitenkopf. Strg+S und „Als .tex speichern“ schreiben unter diesem Namen in den Zielordner, die geladene Vorlage bleibt unverändert. „Vorlage aktualisieren“ speichert als Name01.tex, Name02.tex und so weiter. F5 übersetzt mit dem Dateinamen als Jobname. Umlaute im Dateinamen erscheinen im Seitenkopf verstümmelt, das ist eine Eigenschaft von pdfLaTeX.

Die Bilder eines LaTeX-Dokuments liegen beim Speichern im Ordner „bilder“ neben der .tex-Datei."""
