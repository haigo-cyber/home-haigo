"""LaTeX (Teilmenge) -> Zwischenmodell. Unbekanntes bleibt als Rohtext erhalten."""
import os
import re
import unicodedata

from .common import DEFAULT_PREAMBLE, heading_cmds

ENV_RE = re.compile(r"\\begin\{([A-Za-z*@]+)\}")
HEAD_RE = re.compile(r"\\([A-Za-z]+)(\*?)\s*(\[[^\]]*\])?\s*\{")
ACCENTS = {'"': "\u0308", "'": "\u0301", "`": "\u0300", "^": "\u0302", "~": "\u0303",
           "=": "\u0304", ".": "\u0307"}
DECL = {"bfseries": "b", "bf": "b", "itshape": "i", "it": "i", "em": "i", "slshape": "i",
        "ttfamily": "tt", "tt": "tt"}
FMT_CMDS = {"textbf": "b", "textit": "i", "emph": "i", "textsl": "i", "underline": "u", "uline": "u",
            "sout": "st", "st": "st", "texttt": "tt", "textsuperscript": "sup", "textsubscript": "sub"}
SIMPLE = {"ldots": "\u2026", "dots": "\u2026", "textellipsis": "\u2026", "glqq": "\u201e",
          "grqq": "\u201c", "glq": "\u201a", "grq": "\u2018", "ss": "\u00df", "textbackslash": "\\",
          "textasciitilde": "~", "textasciicircum": "^", "euro": "\u20ac", "texteuro": "\u20ac",
          "textendash": "\u2013", "textemdash": "\u2014", "textless": "<", "textgreater": ">",
          "textbar": "|", "textquotedblleft": "\u201c", "textquotedblright": "\u201d",
          "textquoteleft": "\u2018", "textquoteright": "\u2019", "O": "\u00d8", "o": "\u00f8",
          "AE": "\u00c6", "ae": "\u00e6", "i": "i", "j": "j", "S": "\u00a7", "P": "\u00b6",
          "copyright": "\u00a9", "textcopyright": "\u00a9", "textregistered": "\u00ae",
          "textdegree": "\u00b0", "textbullet": "\u2022", "LaTeX": "LaTeX", "TeX": "TeX"}
LIST_ENVS = ("itemize", "enumerate")
RAW_ENVS_DISPLAY = ("equation", "equation*", "align", "align*", "gather", "gather*", "multline",
                    "multline*", "eqnarray", "eqnarray*", "displaymath", "flalign", "flalign*")


def skip_comment(s, i):
    j = s.find("\n", i)
    return len(s) if j < 0 else j


def match_brace(s, i):
    """s[i]=='{' -> Index der passenden '}' oder -1."""
    depth = 0
    j = i
    n = len(s)
    while j < n:
        c = s[j]
        if c == "\\":
            j += 2
            continue
        if c == "%":
            j = skip_comment(s, j)
            continue
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return j
        j += 1
    return -1


def match_bracket(s, i):
    j = i + 1
    n = len(s)
    depth = 0
    while j < n:
        c = s[j]
        if c == "\\":
            j += 2
            continue
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
        elif c == "]" and depth == 0:
            return j
        j += 1
    return -1


def find_env_end(s, start, name):
    """start = Index hinter \\begin{name}. Liefert (ende_inhalt, nach_end) oder None."""
    pat = re.compile(r"\\(begin|end)\{" + re.escape(name) + r"\}")
    depth = 1
    pos = start
    while True:
        m = pat.search(s, pos)
        if not m:
            return None
        if m.group(1) == "begin":
            depth += 1
        else:
            depth -= 1
            if depth == 0:
                return m.start(), m.end()
        pos = m.end()


def split_top(s, sep):
    """Teilt s an sep (str) auf oberster Ebene (Klammern, Umgebungen)."""
    parts = []
    last = 0
    i = 0
    n = len(s)
    depth = 0
    while i < n:
        c = s[i]
        if c == "\\":
            if s.startswith(sep, i) and depth == 0 and sep.startswith("\\"):
                parts.append(s[last:i])
                i += len(sep)
                last = i
                continue
            m = ENV_RE.match(s, i)
            if m:
                e = find_env_end(s, m.end(), m.group(1))
                if e:
                    i = e[1]
                    continue
            i += 2
            continue
        if c == "%":
            i = skip_comment(s, i)
            continue
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
        elif depth == 0 and sep == "&" and c == "&":
            parts.append(s[last:i])
            last = i + 1
        i += 1
    parts.append(s[last:])
    return parts


class Parser:
    def __init__(self, preamble, base_dir=None):
        self.pre = preamble
        self.base = base_dir
        cmds = heading_cmds(preamble)
        self.levels = {}
        for idx, c in enumerate(cmds):
            self.levels.setdefault(c, idx + 1)
        self.german = bool(re.search(r"\\usepackage(?:\[[^\]]*\])?\{[^}]*(?:babel|ngerman|german)", preamble) and
                           re.search(r"n?german", preamble))

    # ---------- Blöcke ----------
    def blocks(self, s):
        blocks = []
        buf_start = 0
        i = 0
        n = len(s)

        def flush(upto):
            txt = s[buf_start:upto]
            for par in re.split(r"\n[ \t]*\n\s*", txt):
                if par.strip():
                    blocks.append({"t": "p", "inl": self.inlines(par.strip())})

        while i < n:
            c = s[i]
            if c == "\\":
                m = ENV_RE.match(s, i)
                if m:
                    flush(i)
                    res, i = self.env(s, i, m)
                    blocks.extend(res)
                    buf_start = i
                    continue
                if s.startswith("\\[", i):
                    j = s.find("\\]", i + 2)
                    if j >= 0:
                        flush(i)
                        blocks.append({"t": "raw", "text": s[i:j + 2]})
                        i = j + 2
                        buf_start = i
                        continue
                hm = HEAD_RE.match(s, i)
                if hm and hm.group(1) in self.levels:
                    close = match_brace(s, hm.end() - 1)
                    if close > 0:
                        flush(i)
                        title = s[hm.end():close]
                        inl = self.inlines(title.strip())
                        j = close + 1
                        lm = re.compile(r"[ \t]*\\label\{[^}]*\}").match(s, j)
                        if lm:
                            inl.append({"t": "raw", "s": lm.group(0).strip()})
                            j = lm.end()
                        blocks.append({"t": "p", "inl": inl, "h": self.levels[hm.group(1)],
                                       "unnum": bool(hm.group(2))})
                        i = j
                        buf_start = i
                        continue
                i += 2 if i + 1 < n and not s[i + 1].isalpha() else 1
                continue
            if c == "%":
                i = skip_comment(s, i)
                continue
            if c == "$":
                if s.startswith("$$", i):
                    j = s.find("$$", i + 2)
                    if j >= 0:
                        flush(i)
                        blocks.append({"t": "raw", "text": s[i:j + 2]})
                        i = j + 2
                        buf_start = i
                        continue
                else:
                    j = i + 1
                    while j < n and s[j] != "$":
                        j += 2 if s[j] == "\\" else 1
                    i = j + 1
                    continue
            i += 1
        flush(n)
        return blocks

    def env(self, s, i, m):
        name = m.group(1)
        start = m.end()
        e = find_env_end(s, start, name)
        if not e:
            return [{"t": "raw", "text": s[i:]}], len(s)
        content = s[start:e[0]]
        after = e[1]
        whole = s[i:after]
        if name in LIST_ENVS:
            if content.lstrip().startswith("["):
                return [{"t": "raw", "text": whole}], after
            items = self.items(content)
            if items is None:
                return [{"t": "raw", "text": whole}], after
            return [{"t": "list", "ord": name == "enumerate", "items": items}], after
        if name in ("center", "flushright", "flushleft"):
            al = {"center": "center", "flushright": "right", "flushleft": "left"}[name]
            inner = self.blocks(content)
            for b in inner:
                if b["t"] == "p" and not b.get("h"):
                    b["al"] = al
            return inner, after
        if name in ("quote", "quotation"):
            inner = self.blocks(content)
            for b in inner:
                if b["t"] == "p":
                    b["quote"] = True
            return inner, after
        if name == "verbatim":
            txt = content.strip("\n")
            return [{"t": "p", "code": True, "inl": [{"t": "txt", "s": txt}]}], after
        if name in ("tabular", "longtable"):
            tb = self.tabular(content, name)
            if tb is None:
                return [{"t": "raw", "text": whole}], after
            return [tb], after
        return [{"t": "raw", "text": whole}], after

    def items(self, content):
        pos = []
        i = 0
        n = len(content)
        while i < n:
            c = content[i]
            if c == "\\":
                m = ENV_RE.match(content, i)
                if m:
                    e = find_env_end(content, m.end(), m.group(1))
                    if e:
                        i = e[1]
                        continue
                if content.startswith("\\item", i) and not (i + 5 < n and content[i + 5].isalpha()):
                    pos.append(i)
                    i += 5
                    continue
                i += 2
                continue
            if c == "%":
                i = skip_comment(content, i)
                continue
            i += 1
        if not pos:
            return None
        items = []
        for k, p in enumerate(pos):
            end = pos[k + 1] if k + 1 < len(pos) else n
            txt = content[p + 5:end]
            if txt.lstrip().startswith("["):
                return None
            bl = self.blocks(txt.strip())
            if not bl:
                bl = [{"t": "p", "inl": []}]
            items.append(bl)
        return items

    def tabular(self, content, name):
        s = content.lstrip()
        if s.startswith("["):
            j = match_bracket(s, 0)
            if j < 0:
                return None
            s = s[j + 1:].lstrip()
        if name == "longtable" and s.startswith("["):
            j = match_bracket(s, 0)
            s = s[j + 1:].lstrip()
        if not s.startswith("{"):
            return None
        j = match_brace(s, 0)
        if j < 0:
            return None
        body = s[j + 1:]
        header_rows = 0
        if name == "longtable":
            if "\\endfirsthead" in body:
                first, rest = body.split("\\endfirsthead", 1)
                if "\\endhead" in rest:
                    rest = rest.split("\\endhead", 1)[1]
                body = first + "\\endhead" + rest
            if "\\endhead" in body:
                hdr, rest = body.split("\\endhead", 1)
                header_rows = 1
                body = hdr + "\\\\" + rest if hdr.strip() else rest
            body = re.sub(r"\\end(?:foot|lastfoot)", "", body)
        body = re.sub(r"\\(?:hline|toprule|midrule|bottomrule)\b", "", body)
        body = re.sub(r"\\cline\{[^}]*\}", "", body)
        body = re.sub(r"\\(?:cmidrule)(?:\([^)]*\))?\{[^}]*\}", "", body)
        rows_raw = split_top(body, "\\\\")
        rows = []
        for rr in rows_raw:
            rr = re.sub(r"^\s*\[[^\]]*\]", "", rr) if False else rr
            if not rr.strip():
                continue
            cells = []
            for cc in split_top(rr, "&"):
                cc = cc.strip()
                cs = 1
                mm = re.match(r"\\multicolumn\{(\d+)\}\{[^}]*\}\s*\{", cc)
                if mm:
                    close = match_brace(cc, mm.end() - 1)
                    if close < 0:
                        return None
                    cs = int(mm.group(1))
                    cc = cc[mm.end():close]
                if "\\multirow" in cc or "\\begin{" in cc or "\\parbox" in cc or "\\makecell" in cc:
                    return None
                cells.append({"blocks": [{"t": "p", "inl": self.inlines(cc)}], "cs": cs, "rs": 1,
                              "hd": False})
            rows.append(cells)
        if not rows:
            return None
        if header_rows:
            for c in rows[0]:
                c["hd"] = True
        return {"t": "table", "rows": rows}

    # ---------- Zeilenelemente ----------
    def read_arg(self, s, i):
        """Liest ein Argument ab Index i. Liefert (inhalt, nach)."""
        n = len(s)
        j = i
        while j < n and s[j] in " \t":
            j += 1
        if j < n and s[j] == "{":
            close = match_brace(s, j)
            if close < 0:
                return None, i
            return s[j + 1:close], close + 1
        if j < n:
            return s[j], j + 1
        return None, i

    def raw_cmd(self, s, i, name_end):
        """Befehl samt direkt anschließenden [..]- und {..}-Argumenten als Rohtext."""
        j = name_end
        n = len(s)
        while j < n:
            if s[j] == "[":
                k = match_bracket(s, j)
                if k < 0:
                    break
                j = k + 1
            elif s[j] == "{":
                k = match_brace(s, j)
                if k < 0:
                    break
                j = k + 1
            else:
                break
        return s[i:j], j

    def inlines(self, s, fmt=None):
        fmt = dict(fmt or {})
        out = []
        buf = []

        def flush():
            if not buf:
                return
            t = "".join(buf)
            buf.clear()
            t = re.sub(r"\s+", " ", t)
            if t:
                d = {"t": "txt", "s": t}
                d.update({k: v for k, v in fmt.items() if v})
                if (out and out[-1]["t"] == "txt" and
                        {k: v for k, v in out[-1].items() if k not in ("t", "s")} ==
                        {k: v for k, v in d.items() if k not in ("t", "s")}):
                    out[-1]["s"] += t
                else:
                    out.append(d)

        def add_inner(inner, extra):
            flush()
            f2 = dict(fmt)
            f2.update(extra)
            out.extend(self.inlines(inner, f2))

        def add_raw(r):
            flush()
            out.append({"t": "raw", "s": r})

        i = 0
        n = len(s)
        while i < n:
            c = s[i]
            if c == "\\":
                if i + 1 >= n:
                    buf.append("\\")
                    i += 1
                    continue
                nx = s[i + 1]
                if nx.isalpha():
                    j = i + 1
                    while j < n and (s[j].isalpha() or s[j] == "@"):
                        j += 1
                    name = s[i + 1:j]
                    if name in FMT_CMDS:
                        arg, k = self.read_arg(s, j)
                        if arg is None:
                            add_raw(s[i:j])
                            i = j
                        else:
                            add_inner(arg, {FMT_CMDS[name]: True})
                            i = k
                        continue
                    if name == "href":
                        url, k = self.read_arg(s, j)
                        if url is not None:
                            txt, k2 = self.read_arg(s, k)
                            if txt is not None:
                                add_inner(txt, {"href": url.replace("\\%", "%").replace("\\#", "#")})
                                i = k2
                                continue
                        add_raw(s[i:j])
                        i = j
                        continue
                    if name == "url":
                        url, k = self.read_arg(s, j)
                        if url is not None:
                            flush()
                            d = {"t": "txt", "s": url, "href": url}
                            d.update({k2: v for k2, v in fmt.items() if v and k2 != "href"})
                            out.append(d)
                            i = k
                            continue
                    if name in SIMPLE:
                        buf.append(SIMPLE[name])
                        i = j
                        if i < n and s[i] == "{" and s[i + 1:i + 2] == "}":
                            i += 2
                        continue
                    if name == "newline":
                        flush()
                        out.append({"t": "br"})
                        i = j
                        continue
                    if name == "verb":
                        if j < n:
                            d = s[j]
                            k = s.find(d, j + 1)
                            if k > 0:
                                add_raw(s[i:k + 1])
                                i = k + 1
                                continue
                    if name == "includegraphics":
                        k = j
                        opts = ""
                        if k < n and s[k] == "[":
                            e = match_bracket(s, k)
                            if e > 0:
                                opts = s[k + 1:e]
                                k = e + 1
                        path, k2 = self.read_arg(s, k)
                        if path is not None:
                            img = self.image(path.strip(), opts)
                            if img:
                                flush()
                                out.append(img)
                                i = k2
                                continue
                        r, i = self.raw_cmd(s, i, j)
                        add_raw(r)
                        continue
                    if name == "begin":
                        m = ENV_RE.match(s, i)
                        if m:
                            e = find_env_end(s, m.end(), m.group(1))
                            if e:
                                add_raw(s[i:e[1]])
                                i = e[1]
                                continue
                    r, i = self.raw_cmd(s, i, j)
                    add_raw(r)
                    continue
                if nx in "&%$#_{}":
                    buf.append(nx)
                    i += 2
                    continue
                if nx == "\\":
                    flush()
                    out.append({"t": "br"})
                    i += 2
                    if i < n and s[i] == "*":
                        i += 1
                    if i < n and s[i] == "[":
                        e = match_bracket(s, i)
                        if e > 0:
                            i = e + 1
                    while i < n and s[i] in " \t\n":
                        i += 1
                    continue
                if nx in " \n":
                    buf.append(" ")
                    i += 2
                    continue
                if nx == "(":
                    k = s.find("\\)", i + 2)
                    if k > 0:
                        add_raw(s[i:k + 2])
                        i = k + 2
                        continue
                if nx in ACCENTS:
                    arg, k = self.read_arg(s, i + 2)
                    if arg is not None and len(arg) == 1 or arg in ("\\i", "\\j"):
                        base = {"\\i": "i", "\\j": "j"}.get(arg, arg)
                        buf.append(unicodedata.normalize("NFC", base + ACCENTS[nx]))
                        i = k
                        continue
                add_raw(s[i:i + 2])
                i += 2
                continue
            if c == "$":
                if s.startswith("$$", i):
                    k = s.find("$$", i + 2)
                    if k > 0:
                        add_raw(s[i:k + 2])
                        i = k + 2
                        continue
                k = i + 1
                while k < n and s[k] != "$":
                    k += 2 if s[k] == "\\" else 1
                if k < n:
                    add_raw(s[i:k + 1])
                    i = k + 1
                    continue
                buf.append("$")
                i += 1
                continue
            if c == "%":
                k = skip_comment(s, i)
                add_raw(s[i:k])
                i = k
                continue
            if c == "{":
                close = match_brace(s, i)
                if close < 0:
                    buf.append(c)
                    i += 1
                    continue
                inner = s[i + 1:close]
                dm = re.match(r"\s*\\([A-Za-z]+)\s*", inner)
                if dm and dm.group(1) in DECL:
                    add_inner(inner[dm.end():], {DECL[dm.group(1)]: True})
                else:
                    trial = self.inlines(inner, fmt)
                    if any(x["t"] == "raw" for x in trial):
                        add_raw(s[i:close + 1])
                    else:
                        flush()
                        out.extend(trial)
                i = close + 1
                continue
            if c == "~":
                buf.append("\u00a0")
                i += 1
                continue
            if c == "-" and s.startswith("---", i):
                buf.append("\u2014")
                i += 3
                continue
            if c == "-" and s.startswith("--", i):
                buf.append("\u2013")
                i += 2
                continue
            if c == "`":
                if s.startswith("``", i):
                    buf.append("\u201c")
                    i += 2
                else:
                    buf.append("\u2018")
                    i += 1
                continue
            if c == "'" and s.startswith("''", i):
                buf.append("\u201d")
                i += 2
                continue
            if c == '"' and self.german and i + 1 < n:
                d = s[i + 1]
                m2 = {"a": "ä", "o": "ö", "u": "ü", "A": "Ä", "O": "Ö", "U": "Ü", "s": "ß",
                      "`": "\u201e", "'": "\u201c", "-": ""}
                if d in m2:
                    buf.append(m2[d])
                    i += 2
                    continue
            buf.append(c)
            i += 1
        flush()
        # Leerzeichen am Rand der Textstücke bereinigen
        while out and out[0]["t"] == "txt" and out[0]["s"].startswith(" "):
            out[0]["s"] = out[0]["s"].lstrip(" ")
            if not out[0]["s"]:
                out.pop(0)
        return out

    def image(self, path, opts):
        w = None
        m = re.search(r"width\s*=\s*([\d.]+)\s*(cm|mm|in|pt)?", opts)
        if m:
            v = float(m.group(1))
            unit = m.group(2)
            if unit == "cm":
                w = v
            elif unit == "mm":
                w = v / 10
            elif unit == "in":
                w = v * 2.54
            elif unit == "pt":
                w = v * 0.03515
        else:
            m = re.search(r"width\s*=\s*([\d.]*)\s*\\(?:line|text)width", opts)
            if m:
                w = (float(m.group(1)) if m.group(1) else 1.0) * 16
        cand = []
        for ext in ("", ".png", ".jpg", ".jpeg", ".gif", ".bmp"):
            cand.append(path + ext)
        found = None
        for cpath in cand:
            full = cpath if os.path.isabs(cpath) or not self.base else os.path.join(self.base, cpath)
            if os.path.isfile(full) and not full.lower().endswith(".pdf"):
                found = full
                break
        if not found:
            return None
        return {"t": "img", "path": found, "w": w, "orig": path}


def split_document(text):
    """Trennt Präambel und Rumpf. Liefert (preamble, body)."""
    m = re.search(r"\\begin\{document\}", text)
    if not m:
        return DEFAULT_PREAMBLE, text.strip("\n")
    pre = text[:m.start()].rstrip() + "\n"
    rest = text[m.end():]
    e = rest.rfind("\\end{document}")
    body = rest[:e] if e >= 0 else rest
    return pre, body.strip("\n")


def parse_latex(text, base_dir=None):
    pre, body = split_document(text)
    p = Parser(pre, base_dir)
    return pre, p.blocks(body)
