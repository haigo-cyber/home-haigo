Seifferts Dateien (Version 1.5)
===============================

Ein Dateiprogramm für Linux. Favoriten erscheinen als 3D-Karussell im Design des Stammbaums. Dazu kommen die üblichen Dateimanager-Funktionen (kopieren, verschieben, umbenennen, Papierkorb, Archive, Eigenschaften, Massenumbenennung), ein eingebautes Terminal, Listen-, Symbol-, Vorschau- und Kugelansicht, eine 3D-Mindmap der Ordnerstruktur, eine Dateinamensuche, eine Volltextsuche, Verknüpfungen zu Webseiten und Dateien sowie ein durchsichtiges Fenster und Hintergrundbilder.

Voraussetzungen
---------------

Python 3 und PySide6 mit QtWebEngine. Unter Arch/EndeavourOS:

    sudo pacman -S pyside6 qt6-webengine

Alternativ in einer eigenen Umgebung:

    python3 -m venv --system-site-packages ~/.local/share/seiffert-dateien-app/venv
    ~/.local/share/seiffert-dateien-app/venv/bin/pip install PySide6 PySide6-WebEngine

Optional für den Volltext in PDFs und für die PDF-Vorschau: poppler (Programme pdftotext, pdftoppm, pdfinfo)

    sudo pacman -S poppler

Optional für den Volltext in alten Word-, Excel- und PowerPoint-Dateien (doc, xls, ppt): LibreOffice (Programm soffice). Das Lesen dauert pro Datei ein paar Sekunden und ist nur aktiv, wenn du die Endungen in den Einstellungen einträgst.

Installation (ohne sudo)
------------------------

Die drei Befehle zum Auspacken und Installieren stehen auch einzeln in der Datei INSTALLATION.txt im Archiv.

    ./install.sh

Das Programm erscheint danach im Menü als "Seifferts Dateien". Start im Terminal: ~/.local/bin/seiffert-dateien [Ordner]. Entfernen mit ./install.sh --remove (Einstellungen und Index bleiben erhalten).

Ohne Installation geht auch: python3 app.py

Bedienung
---------

Fünf Reiter (Strg+1 bis Strg+5): Favoriten (Karussell), Ordner, Dateinamen, Volltext, Mindmap. Der Knopf für das Farbschema schaltet zwischen Auto, Hell und Dunkel um. F11 oder der Knopf "Vollbild" in der Kopfleiste schaltet das Fenster in den Vollbildmodus und wieder zurück, auch wenn gerade das Terminal oder ein Eingabefeld den Fokus hat.

Ordner-Reiter, vier Ansichten: Liste, Symbole, Vorschau und Kugel. Symbole zeigt Kacheln mit Dateiart-Symbol, bei Bildern mit Miniatur, die Größe ist wählbar. Vorschau zeigt links die Liste und rechts den Inhalt der gewählten Datei: Text und Quelltext, Bilder, die erste Seite eines PDFs (mit poppler), bei Ordnern eine Übersicht. Die Wahl wird gemerkt. Mit den Pfeiltasten wählst du, Enter öffnet.

Kugel: Alle Einträge des Ordners liegen auf einer drehbaren Kugel mit leuchtendem Gitternetz in der Farbe des Farbdesigns. Ordner erscheinen als gezeichnete Ordner im gewählten Stil, Dateien als Kacheln mit Verlauf. Ziehen dreht, das Mausrad zoomt, ein Klick wählt, Doppelklick oder Enter öffnet. Die Pfeiltasten springen zum Nachbarn auf der Kugel und drehen ihn nach vorn, R setzt Ansicht und Zoom zurück, Strg+A wählt alles. Bilder erscheinen als Miniatur. Bei mehr als 400 Einträgen zeigt die Kugel die ersten 400, mit dem Filter oben lässt sich eingrenzen.

Mindmap: Der Ordner aus dem Ordner-Reiter steht in der Mitte, die Unterordner sind als Knoten im Raum angeordnet, unter den Knoten liegt ein Raster als Boden mit gestrichelten Linien von jedem Knoten nach unten. Ziehen dreht die Ansicht, Umschalt+Ziehen verschiebt, das Mausrad zoomt, R setzt zurück. Die Knöpfe Plus und Minus im Bild zoomen ebenfalls, "Neu ordnen" ordnet alle Knoten neu an und setzt die Drehung zurück, "Groß anzeigen" legt die Mindmap über das ganze Fenster (Esc beendet das). Mit den Häkchen "Beschriftung" und "Boden" blendest du die Namen bzw. das Raster aus, die Wahl wird gemerkt. Klick wählt einen Knoten. Doppelklick auf einen Ordner macht ihn zum neuen Mittelpunkt der Mindmap; mit dem Knopf "Eine Ebene höher" oder der Rücktaste gehst du wieder zurück, und "Aktueller Ordner" holt den Ordner aus dem Ordner-Reiter zurück. Der Ordner-Reiter selbst bleibt dabei, wo er ist. Die Leertaste oder der Knopf "Aufklappen" klappt einen Knoten auf oder zu, Enter öffnet den Ordner im Ordner-Reiter. Ordnerknoten tragen das gewählte Ordnersymbol. Pfeiltasten: links zuklappen bzw. zum übergeordneten Knoten, rechts aufklappen bzw. zum ersten Kind, hoch und runter wechseln innerhalb einer Ebene. Oben stellst du Tiefe, Dateien und versteckte Ordner ein. Eine Zusammenfassung wie "+36 weitere Ordner" lässt sich mit Doppelklick ganz aufklappen. Verweise auf Ordner (Symlinks) werden nicht aufgeklappt, damit es keine Endlosschleifen gibt.

Farbdesigns und Ordnerstile: Im Dialog "Darstellung" (Knopf oben rechts) wählst du ein Farbdesign aus sieben Möglichkeiten (Petrol, Wald, Bernstein, Beere, Indigo, Graphit, Terrakotta; jedes gibt es hell und dunkel, die Schrift hat überall mindestens 4,5:1 Kontrast), einen von sechs Ordnerstilen (Flach, Konturen, Mappe mit Blatt, Geöffnet, Glas, Aktenordner mit Etikett) und die Ordnerfarbe: passend zum Farbdesign, bunt nach Ordnername (derselbe Name hat immer dieselbe Farbe) oder klassisch gelb. Das gilt gleichzeitig in der Liste, bei den Symbolen, auf der Kugel, im Karussell und in der Mindmap, und es wird zwischen mehreren offenen Fenstern abgeglichen.

Durchsichtiges Fenster: Der Regler "Deckkraft" in der Kopfleiste macht das ganze Fenster durchsichtiger. Das setzt eine Fensterverwaltung mit Compositing voraus (bei Cinnamon normalerweise der Fall). Unter "Darstellung" gibt es zusätzlich die Option "Durchscheinendes Fenster mit scharfer Schrift", die einen Neustart braucht: Dann bleibt die Schrift scharf und nur die Flächen werden durchsichtig.

Hintergrundbild: Unter "Darstellung" ein Bild wählen, die Anpassung (ausfüllen, ganz zeigen, mittig, Kacheln) und die Bildstärke einstellen. Mit dem Regler "Durchscheinen der Flächen" bestimmst du, wie viel vom Bild hinter den Flächen zu sehen ist. Das Programm begrenzt das Durchscheinen automatisch so, dass die Schrift lesbar bleibt (Kontrast mindestens 4,5:1 für Text). Das Bild wird als verkleinerte Kopie im Datenordner des Programms abgelegt, das Original bleibt unberührt.

Favoriten: Mit den Pfeiltasten oder dem Mausrad drehen, Enter oder Doppelklick öffnet den Ordner. Die Karten sind dunkle Glaskarten in der Farbe des Favoriten, mit Nummer, Art, Ordnersymbol, Titel und Pfad, die vordere Karte leuchtet. Favoriten werden über das Sternsymbol im Ordner oder im Favoriten-Dialog verwaltet.

Dateinamensuche: durchsucht live die Ordner, ohne Index. Unterstützt Platzhalter (* und ?), Groß-/Kleinschreibung und Umlaute werden ignoriert, mit ext:pdf lässt sich nach Dateityp filtern.

Volltextsuche: nutzt einen Index, der für die gewählten Ordner und Dateitypen aufgebaut wird (Knopf "Ordner und Dateitypen …" in der Leiste des Volltext-Reiters oder in den Einstellungen). Er hält sich selbst aktuell: beim Start und danach alle zehn Minuten werden nur geänderte, neue und gelöschte Dateien nachgezogen; in den Einstellungen lässt sich das auf "nur auf Knopfdruck" umstellen.

Ab Version 1.3 wird jeder Text vor dem Speichern und Suchen vereinheitlicht: Groß- und Kleinschreibung, Akzente und Umlaute spielen keine Rolle, ß und ss gelten als gleich, ebenso ä/ae, ö/oe, ü/ue. Straße findet also Strasse und Hauptstrasse, Müller findet Mueller, Köln findet Koeln, Rechenschwäche findet Rechenschwaeche. Ligaturen aus PDFs (fi, fl) werden aufgelöst, Trennstriche am Zeilenende in PDFs zusammengezogen. Standardmäßig wird auch mitten im Wort gefunden: "schule" findet Grundschulleitung, "pädagoge" findet Sonderpädagogen. Das Häkchen "Nur Wortanfänge" schränkt auf Treffer am Wortbeginn ein.

Suchsyntax: Wörter (alle müssen vorkommen), "genaue Wendung", ODER bzw. OR, -ausschluss. Begriffe mit weniger als drei Zeichen werden nur gegen die Treffer der übrigen Begriffe geprüft; eine Suche nur aus solchen Begriffen oder nur aus Ausschlüssen wird mit einem Hinweis abgelehnt. Treffer, bei denen alle Begriffe am Wortanfang stehen, stehen oben. Zu jedem Treffer gibt es bis zu drei Ausschnitte mit der Fundstelle. Findet die Suche nichts, nennt das Programm mögliche Gründe, etwa dass der Ordner nicht im Index liegt, und bietet an, ihn hinzuzufügen.

Lesbare Dateitypen: Text und Quelltext (u. a. txt, md, csv, json, jsonl, html, xml, tex, adoc, ipynb, Skripte), Visitenkarten (vcf), Kalender (ics), docx (samt Kopf- und Fußzeilen und Kommentaren), xlsx, pptx, odt, ods, odp, odg, rtf, epub, E-Mails (eml) und PDF mit Textebene. Textdateien in UTF-8, UTF-16 und Windows-Kodierung (mit oder ohne BOM) werden erkannt, auch Dateien ohne Endung, sofern sie Text enthalten. Die alten Formate doc, xls und ppt werden nur gelesen, wenn LibreOffice installiert ist und die Endungen in den Einstellungen eingetragen sind.

Nach dem Update auf 1.3 wird der Index einmal automatisch neu aufgebaut, weil sich sein Aufbau geändert hat. Er braucht etwa das Zweieinhalb- bis Dreifache des Textumfangs der indizierten Dateien an Platz im Datenordner des Programms.

Zwei Ordnerfelder: F3 (oder der Knopf "Zwei Ordnerfelder" in der Werkzeugleiste und im Menü Darstellung) teilt den Ordner-Reiter in zwei unabhängige Felder, die nebeneinander oder, über "Felder untereinander", übereinander stehen. Das zweite Feld startet im Ordner des ersten, hat eigene Pfadleiste und Ansicht und ändert den gemerkten letzten Ordner nicht. Mit F9 wechselst du zwischen den Feldern. F5 kopiert die Auswahl in den Ordner des anderen Feldes, F6 verschiebt sie; dasselbe gibt es im Rechtsklick-Menü ("In das andere Feld kopieren/verschieben") und als Knöpfe in der Werkzeugleiste. Einträge lassen sich auch zwischen den Feldern ziehen (verschieben, mit Strg kopieren). Damit die Dateien genug Platz haben, zeigt jedes Feld bei zwei Feldern nur zwei schlanke Leisten (siehe Werkzeugleiste und Menüs unten); die weggefallenen Befehle stehen im Menü "Mehr", die Tastenkürzel und das Rechtsklick-Menü gelten unverändert. Ist das zweite Feld geschlossen, lädt F5 wie bisher nur neu. Die Wahl, ob zwei Felder offen sind, wird gemerkt.

Ordner-Tabs: Der Knopf "＋ Tab" in der oberen Leiste (oder Strg+T, oder "Neuer Tab" im Menü "Mehr") öffnet einen weiteren Tab im aktuellen Ordner. Ab dem zweiten Tab erscheint über der Werkzeugleiste eine Tab-Leiste. Jeder Tab merkt sich seinen Ordner und seinen eigenen Verlauf (Zurück und Vor). Mit einem Klick wechselst du den Tab, mit dem Kreuz am Tab, mit der mittleren Maustaste oder mit Strg+W schließt du ihn, mit Strg+Bild hoch und Strg+Bild runter blätterst du durch die Tabs. Rechtsklick auf einen Ordner bietet "In neuem Tab öffnen". Bei zwei Ordnerfeldern fehlt der Knopf in der Leiste (er steht dann im Menü "Mehr"), und das zweite Feld hat keine eigenen Tabs. Die Tabs gelten nur für die laufende Sitzung und werden nicht gespeichert.

Werkzeugleiste und Menüs: In allen Ordneransichten (Liste, Symbole, Vorschau, Kugel) gibt es nur noch zwei schlanke Leisten. Oben stehen Zurück, Vor, Hoch, Orte, der Pfad, "Pfad kopieren" und "Zwei Felder"; darunter Neuer Ordner, Ausschneiden, Kopieren, Einfügen, Umbenennen, In den Papierkorb, die Ansichtswahl, Größe, Filter und das Menü "Mehr". Bei zwei Feldern wandern die Bearbeiten-Knöpfe ins Menü "Mehr", damit jedes Feld genug Platz behält. Das Menü "Mehr" enthält nur, was in der Leiste fehlt (Neue Datei, Neue Verknüpfung, Rückgängig, Komprimieren, Eigenschaften, Papierkorb öffnen, Im Dateimanager öffnen, Ordner als Favorit) und die wichtigsten Darstellungsoptionen (Ansicht, Symbolgröße, Sortieren, Versteckte Dateien); alles Weitere steht unter "Weitere Darstellung". Das Rechtsklick-Menü auf einem Eintrag ist in Gruppen geordnet: Öffnen, Ausschneiden/Kopieren/Einfügen, Umbenennen/Duplizieren/Komprimieren/Favorit, dann "Weitere Aktionen" (Verschieben nach, Kopieren nach, symbolischer Verweis, Pfad kopieren, Im Dateimanager zeigen, Verknüpfungsziel, Endgültig löschen), In den Papierkorb, Eigenschaften und "Darstellung". Das Rechtsklick-Menü im leeren Bereich zeigt Neu, Einfügen, Auswählen, Terminal und die Kernoptionen der Darstellung direkt, den Rest unter "Weitere Darstellung".

Zusätzliches Fenster: Strg+N oder "Neues Fenster" im Menü Darstellung öffnet ein weiteres Programmfenster im selben Ordner, das unabhängig bedient wird. Geänderte Einstellungen, zum Beispiel das Design, werden an die anderen Fenster weitergegeben. Das Programm läuft, bis das letzte Fenster geschlossen ist; das Terminal gehört dem ganzen Programm, nicht einem Fenster.

Verknüpfungen: Im Ordner über Rechtsklick oder den Knopf "Neue Verknüpfung" anlegen, wahlweise zu einer Webadresse oder zu einer Datei bzw. einem Ordner auf der Platte. Gespeichert werden sie als normale .desktop-Dateien (Type=Link) im jeweiligen Ordner.

Dateien verwalten
-----------------

Auswahl: Klick wählt einen Eintrag, Strg+Klick fügt hinzu oder nimmt weg, Umschalt+Klick wählt einen Bereich, Strg+A alles, Escape reduziert auf einen Eintrag. Die Statuszeile zeigt Anzahl und Größe der Auswahl und den freien Platz.

Tastaturkürzel im Ordner-Reiter: Strg+C kopieren, Strg+X ausschneiden, Strg+V einfügen, F2 umbenennen (bei mehreren Einträgen Massenumbenennung), Entf in den Papierkorb, Umschalt+Entf endgültig löschen, Strg+Z rückgängig, Strg+Umschalt+D duplizieren, Strg+Umschalt+N neuer Ordner, Alt+Enter Eigenschaften, Strg+H versteckte Dateien, Strg+D Favorit, F5 aktualisieren (bei zwei Feldern: kopieren ins andere Feld, siehe oben), F4 Terminal, F3 zwei Ordnerfelder, F9 anderes Feld, F11 Vollbild, Strg+N neues Fenster, Rücktaste eine Ebene hoch.

Die Zwischenablage ist mit Nemo und anderen Dateimanagern kompatibel: Was du hier kopierst oder ausschneidest, lässt sich dort einfügen und umgekehrt. Ausgeschnittene Einträge erscheinen abgeblendet.

Im Rechtsklick-Menü (auf einem Eintrag und im leeren Bereich) stehen alle Funktionen: Öffnen, Öffnen mit, Ausschneiden, Kopieren, Einfügen, Duplizieren, Umbenennen, Verschieben nach, Kopieren nach, Komprimieren (ZIP, TAR.GZ, TAR.XZ, TAR.BZ2, TAR), Entpacken, symbolischen Verweis anlegen, Papierkorb, Eigenschaften und der Eintrag Darstellung mit allen Anzeigeoptionen: Ansicht (Liste, Symbole, Vorschau, Kugel), Symbolgröße, Sortieren (Name, Größe, Datum, Typ, auf- oder absteigend, Ordner zuerst), Spalten, versteckte Dateien, Vorschaubilder, Design, Deckkraft und Terminal. Im leeren Bereich stehen diese Optionen direkt im Menü. Die Sortierung und die Spalten werden gemerkt.

Konflikte: Gibt es im Zielordner schon einen Eintrag mit gleichem Namen, fragt das Programm: Überspringen, Beide behalten (neuer Name mit "(2)") oder Ersetzen (Ordner werden zusammengeführt). Kopiert wird zuerst in eine Teildatei, die erst am Ende den richtigen Namen bekommt; ein Abbruch hinterlässt keine halben Dateien. Längere Aufgaben zeigen unten rechts einen Fortschrittsbalken mit Abbrechen-Knopf.

Rückgängig (Strg+Z, bis zu 50 Schritte) gilt für Kopieren, Verschieben, Umbenennen (auch Massenumbenennung), neue Ordner und Dateien sowie für das Verschieben in den Papierkorb. Endgültiges Löschen und Ersetzen lassen sich nicht zurücknehmen, davor wird gewarnt.

Papierkorb: "Papierkorb öffnen" zeigt den Inhalt des Papierkorbs im Persönlichen Ordner (freedesktop.org-Standard, derselbe wie bei Nemo) zum Wiederherstellen oder endgültigen Löschen.

Massenumbenennung: Mehrere Einträge auswählen und F2 drücken. Die Regeln werden in fester Reihenfolge angewendet: Suchen und Ersetzen (auch mit regulären Ausdrücken), Teile entfernen oder einfügen, Leerzeichen, Umlaute, Sonderzeichen, Groß- und Kleinschreibung, Vor- und Nachsatz, Nummerierung, Datum, Dateiendung. Rechts steht live die Vorschau. Doppelte oder ungültige Namen sind rot markiert, dann ist der Knopf gesperrt. Beim Umbenennen läuft alles über Zwischennamen, damit auch Tauschen (a und b) klappt; geht etwas schief, wird zurückgerollt.

Ziehen und Ablegen: Einträge auf einen Ordner in der Liste oder in den Symbolen oder auf ein Element der Pfadleiste ziehen verschiebt, mit gedrückter Strg-Taste kopiert.

Der Ordner wird beobachtet: Dateien, die von außen dazukommen oder verschwinden, erscheinen nach höchstens drei Sekunden.

Terminal: F4 oder der Knopf "Terminal" blendet unten ein eingebautes Terminal ein. Es startet deine Shell ($SHELL) im aktuellen Ordner und läuft mit allen Programmen weiter, auch wenn du es ausblendest. Mehrere Reiter sind möglich (bis 8), die Höhe ziehst du an der Kante oder mit den Pfeiltasten. "Ordnerwechsel mitmachen" lässt das Terminal mit dem Ordner-Reiter wechseln, aber nur, wenn die Shell wartet und du in den letzten Sekunden nichts getippt hast; eine angefangene Eingabezeile wird dabei verworfen. Kopieren und Einfügen im Terminal mit Strg+Umschalt+C und Strg+Umschalt+V oder per Rechtsklick, Schriftgröße mit Strg+Plus, Strg+Minus und Strg+0. "Externes Terminal" startet ein Terminalprogramm des Systems im Ordner (erkannt werden u. a. kitty, alacritty, gnome-terminal, konsole, xfce4-terminal, tilix, foot, xterm). Der Terminal-Baustein xterm.js liegt im Ordner vendor (MIT-Lizenz).

Grenzen
-------

Kein Wiederholen (Strg+Umschalt+Z) nach dem Rückgängigmachen. Kein Ziehen von Dateien aus oder in andere Programme. Die Papierkorbansicht deckt nur den Papierkorb des Persönlichen Ordners ab, nicht die von anderen Laufwerken. Kein Aufziehen eines Auswahlrahmens mit der Maus. Die Vorschau zeigt Text bis etwa 5000 Zeichen und PDFs nur die erste Seite. Gescannte PDFs ohne Textebene werden nicht indiziert. Alte Formate (doc, xls, ppt) werden nur mit LibreOffice gelesen. Im Volltext findet die Suche keine Wörter in Bildern. Das zweite Ordnerfeld zeigt nur die Ordneransicht, ohne Kopfleiste, Reiter und Terminal. Terminals gehören dem ganzen Programm: Schließt du ein zusätzliches Fenster, laufen sie weiter, bis das letzte Fenster zu ist.
