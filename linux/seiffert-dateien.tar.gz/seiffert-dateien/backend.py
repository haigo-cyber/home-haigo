#!/usr/bin/env python3
"""Seifferts Dateien - Backend ohne Qt.

Dateisystem, Dateinamensuche, Volltextindex (SQLite FTS5), Verknüpfungen als
.desktop-Dateien (Type=Link), Favoriten und Einstellungen. Nur Standardbibliothek.
Externe Programme (optional): pdftotext (poppler), gio, xdg-open.
"""
from __future__ import annotations

import base64
import configparser  # noqa: F401  (bewusst nicht benutzt, Parser unten ist eigen)
import fnmatch
import html
import json
import os
import re
import shutil
import sqlite3
import subprocess
import tempfile
import threading
import time
import unicodedata
import urllib.parse
import zlib
import uuid
import zipfile
from collections import OrderedDict
from html.parser import HTMLParser
from pathlib import Path
from xml.etree import ElementTree as ET

APP_ID = "seiffert-dateien"
VERSION = "2.5"

TEXT_EXTS = (
    "txt md markdown rst org tex ltx bib sty cls dtx csv tsv json jsonl ndjson yaml yml toml ini cfg conf log "
    "xml html htm xhtml css scss less js mjs ts jsx tsx vue py sh bash zsh fish c h cpp hpp cc rs go java kt kts sql r "
    "lua php rb pl srt vtt ass lrc ged gedcom svg tikz pgf desktop vcf ics adoc ipynb opml gpx kml nfo diff patch "
    "properties bat ps1 cs swift dart scala hs ex exs clj tex mbox"
).split()
OFFICE_EXTS = "docx xlsx pptx odt ods odp odg".split()
MAIL_EXTS = ["eml"]
EXTRA_EXTS = ["rtf", "epub"]
PDF_EXTS = ["pdf"]
LEGACY_EXTS = ["doc", "xls", "ppt"]          # alte Office-Formate, nur mit LibreOffice und nur auf Wunsch
DEFAULT_EXTS = sorted(set(TEXT_EXTS + OFFICE_EXTS + MAIL_EXTS + EXTRA_EXTS + PDF_EXTS))
NEW_IN_13 = sorted(set(DEFAULT_EXTS) - set(
    ("txt md markdown rst org tex ltx bib sty cls dtx csv tsv json yaml yml toml ini cfg conf log xml html htm xhtml css js mjs ts py sh "
     "bash zsh fish c h cpp hpp cc rs go java kt kts sql r lua php rb pl srt vtt ged gedcom svg tikz pgf desktop "
     "docx xlsx pptx odt ods odp pdf").split()))

COLORS = [
    "#a24a2a", "#6a5a9a", "#2b7075", "#3f7a3a", "#8a6b17", "#7c3a4d", "#365f8c",
    "#b05a30", "#2f6f9a", "#4f6f2c", "#8a4a7c", "#33607c", "#7a5738", "#3f7a68",
]
SKIP_DIRS = {"node_modules", "__pycache__", ".git", ".svn", ".hg", ".cache", ".venv", "venv", ".Trash"}
URL_SCHEMES = {"http", "https", "ftp", "ftps", "mailto", "file"}
MAX_CONTENT_CHARS = 10_000_000

SKINS = ("petrol", "wald", "bernstein", "beere", "indigo", "graphit", "terrakotta")
FOLDER_STYLES = ("klassisch", "flach", "mappe", "offen", "glas", "etikett")
FOLDER_COLORS = ("design", "bunt", "gelb")

STARTER_LOOKS = ("metall", "aurora", "hud", "obsidian")   # Aussehen der Wolke: Metall (Anthrazit), Aurora, Neon-HUD, Obsidian-Glas

STARTER_DEFAULTS = {
    "look": "metall",           # Aussehen der Wolke, siehe STARTER_LOOKS
    "hotkey": "<Super>space",   # gewünschtes Tastenkürzel (wirksam erst nach "Kürzel setzen", siehe startersetup.py)
    "src_apps": True,           # Starter durchsucht Programme
    "src_favs": True,           # ... Favoriten
    "src_folders": True,        # ... Ordnernamen
    "src_files": True,          # ... Dateinamen und Volltext
    "bubbles": 16,              # Höchstzahl der Blasen (6 bis 24)
    "learn": True,              # oft Gestartetes nach vorn
    "autohide": True,           # Wolke schließt sich beim Wegklicken
    "icons": True,              # Programm-Symbole in den Blasen zeigen (wo vorhanden)
    "src_system": True,         # Systembefehle (Herunterfahren, Abmelden, ...) als Blasen anbieten
    "sys_confirm": True,        # vor Herunterfahren, Neustart und Abmelden nachfragen
    "sys": {},                  # je Befehl: {"on": bool, "cmd": "eigener Befehl"}; leer = Standard
}

DEFAULT_CONFIG = {
    "theme": "auto",            # auto | light | dark
    "start_view": "fav",        # fav | dir
    "favorites": [],
    "roots": [],
    "index_exts": DEFAULT_EXTS,
    "index_hidden": False,
    "index_auto": True,         # Index beim Start und alle paar Minuten still aktualisieren
    "index_ver": 2,
    "max_file_mb": 20,
    "show_hidden": False,
    "last_path": "",
    "geometry": "",
    "dir_view": "list",         # list | icons | preview | sphere
    "icon_size": "m",           # s | m | l
    "opacity": 100,             # Deckkraft des Fensters in Prozent (35 bis 100)
    "translucent": False,       # durchscheinendes Fenster mit scharfer Schrift (wirkt nach Neustart)
    "bg_strength": 55,          # Stärke des Hintergrundbilds in Prozent
    "bg_see": 50,               # wie weit Flächen das Bild durchscheinen lassen (0 bis 100)
    "bg_fit": "cover",          # cover | contain | center | tile
    "sort_key": "name",         # name | size | mtime | type
    "sort_dir": 1,              # 1 aufsteigend, -1 absteigend
    "dirs_first": True,         # Ordner vor Dateien
    "col_size": True,           # Spalte Größe in der Liste
    "col_date": True,           # Spalte Geändert in der Liste
    "thumbs": True,             # Vorschaubilder in Symbol- und Kugelansicht
    "dual": False,              # zwei Ordnerfelder
    "dual_vertical": False,     # Felder untereinander statt nebeneinander
    "skin": "petrol",           # Farbdesign (siehe SKINS)
    "folder_style": "flach",    # Ordnerstil (siehe FOLDER_STYLES)
    "folder_color": "design",   # Ordnerfarbe: design | bunt | gelb
    "ft_dirs": True,           # Volltextsuche findet auch Ordnernamen
    "assoc": {},                # Dateiendung -> Programm (.desktop-Name), siehe apps.py
    "starter": dict(STARTER_DEFAULTS),   # Einstellungen des Seifferts Starters, siehe startersetup.py
    "new_workspace": True,      # neue Fenster von Dateien und Programmen auf eine eigene Arbeitsfläche, wenn der Desktop es erlaubt (workspace.py)
    "ext_tab": True,            # Ordner, die der Starter öffnet, in einem neuen Tab statt im aktuellen
    "term_open": False,         # Terminalleiste unten sichtbar
    "term_height": 260,         # Höhe der Terminalleiste in Pixeln
    "term_follow": True,        # Terminal wechselt mit dem Ordner (nur wenn die Shell wartet)
}

# Dateiarten für Symbole, Beschriftung und Vorschau: Endung -> (Gruppe, Bezeichnung)
FILE_TYPES: dict[str, tuple[str, str]] = {}
for _grp, _label, _exts in (
    ("pdf", "PDF-Dokument", "pdf"),
    ("doc", "Textdokument", "docx odt rtf doc"),
    ("sheet", "Tabelle", "xlsx ods xls"),
    ("sheet", "Tabelle (Text)", "csv tsv"),
    ("slides", "Präsentation", "pptx odp ppt"),
    ("tex", "LaTeX-Datei", "tex ltx sty cls dtx bib tikz pgf"),
    ("code", "Quelltext", "py js mjs ts sh bash zsh fish c h cpp hpp cc rs go java kt kts sql r lua php rb pl css"),
    ("code", "Markup oder Daten", "html htm xhtml xml json yaml yml toml svg"),
    ("text", "Textdatei", "txt md markdown rst org log ini cfg conf srt vtt ged gedcom desktop"),
    ("image", "Bild", "png jpg jpeg gif webp bmp tif tiff ico avif"),
    ("audio", "Audio", "mp3 flac ogg oga opus wav m4a aac wma mid midi"),
    ("video", "Video", "mp4 mkv webm avi mov wmv flv m4v mpg mpeg"),
    ("archive", "Archiv", "zip tar gz tgz xz bz2 zst 7z rar iso"),
):
    for _e in _exts.split():
        FILE_TYPES[_e] = (_grp, _label)
IMAGE_EXTS = {"png", "jpg", "jpeg", "gif", "webp", "bmp", "tif", "tiff", "ico", "avif"}
MONO_GROUPS = {"tex", "code"}


class AppError(Exception):
    """Fehler mit Text, der dem Nutzer angezeigt werden darf."""


# ---------------------------------------------------------------- Hilfen

def config_dir() -> Path:
    return Path(os.environ.get("XDG_CONFIG_HOME") or (Path.home() / ".config")) / APP_ID


def data_dir() -> Path:
    return Path(os.environ.get("XDG_DATA_HOME") or (Path.home() / ".local" / "share")) / APP_ID


def fold(s: str) -> str:
    """Kleinschreibung ohne Akzente, damit 'Müller' auch 'muller' findet."""
    s = unicodedata.normalize("NFKD", s.casefold())
    return "".join(c for c in s if not unicodedata.combining(c))


def norm_path(p: str) -> str:
    if not isinstance(p, str) or not p.strip():
        raise AppError("Kein Pfad angegeben.")
    if "\x00" in p:
        raise AppError("Ungültiger Pfad.")
    return os.path.abspath(os.path.expanduser(p.strip()))


def check_name(name: str) -> str:
    name = (name or "").strip()
    if not name or name in (".", ".."):
        raise AppError("Der Name darf nicht leer sein.")
    if "/" in name or "\x00" in name:
        raise AppError("Der Name darf kein '/' enthalten.")
    if len(name.encode("utf-8")) > 255:
        raise AppError("Der Name ist zu lang.")
    return name


def safe_filename(name: str) -> str:
    n = re.sub(r"[\x00-\x1f/\\]", " ", name or "").strip().lstrip(".").strip()
    n = re.sub(r"\s+", " ", n)
    n = n[:120].strip()
    return n or "Verknüpfung"


def unique_path(directory: str, base: str, suffix: str = "") -> str:
    p = os.path.join(directory, base + suffix)
    i = 2
    while os.path.lexists(p):
        p = os.path.join(directory, f"{base} ({i}){suffix}")
        i += 1
    return p


def path_prefix_sql(prefix: str) -> tuple[str, list]:
    esc = prefix.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    base = esc.rstrip("/")
    return "(m.path = ? OR m.path LIKE ? ESCAPE '\\')", [prefix.rstrip("/") or "/", base + "/%"]


# ---------------------------------------------------------------- .desktop-Verknüpfungen

_DESK_UNESC = {"s": " ", "n": "\n", "t": "\t", "r": "\r", "\\": "\\"}


def _desk_unescape(v: str) -> str:
    return re.sub(r"\\(.)", lambda m: _DESK_UNESC.get(m.group(1), m.group(0)), v)


def _desk_escape(v: str) -> str:
    return v.replace("\\", "\\\\").replace("\n", " ").replace("\r", " ").replace("\t", " ")


def parse_desktop(path: str) -> dict | None:
    """Liest eine .desktop-Datei. Gibt nur dann etwas zurück, wenn sie Type=Link ist."""
    try:
        if os.path.getsize(path) > 65536:
            return None
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
    except OSError:
        return None
    group = None
    vals: dict[str, str] = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            group = line[1:-1]
            continue
        if group != "Desktop Entry" or "=" not in line:
            continue
        k, v = line.split("=", 1)
        vals.setdefault(k.strip(), _desk_unescape(v.strip()))
    if vals.get("Type") != "Link" or not vals.get("URL"):
        return None
    url = vals["URL"]
    name = vals.get("Name") or os.path.splitext(os.path.basename(path))[0]
    if url.startswith("file://"):
        target = urllib.parse.unquote(urllib.parse.urlparse(url).path)
        return {"name": name, "type": "path", "target": target, "url": url, "exists": os.path.exists(target)}
    return {"name": name, "type": "url", "target": url, "url": url, "exists": True}


def normalize_link_target(kind: str, target: str) -> tuple[str, str]:
    """Gibt (URL für die .desktop-Datei, Typ) zurück."""
    target = (target or "").strip()
    if not target:
        raise AppError("Bitte ein Ziel angeben.")
    if kind == "url":
        if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*:", target) or re.match(r"^[^/]+:\d+(/|$)", target):
            target = "https://" + target
        u = urllib.parse.urlparse(target)
        if u.scheme.lower() not in URL_SCHEMES - {"file"}:
            raise AppError("Erlaubt sind Adressen mit http, https, ftp oder mailto.")
        if u.scheme.lower() != "mailto" and not u.netloc:
            raise AppError("Die Internetadresse ist unvollständig.")
        return target, "url"
    if kind == "path":
        p = norm_path(target)
        return "file://" + urllib.parse.quote(p, safe="/"), "path"
    raise AppError("Unbekannter Verknüpfungstyp.")


def write_desktop_link(path: str, name: str, url: str, is_dir: bool | None, is_web: bool) -> None:
    icon = "text-html" if is_web else ("inode-directory" if is_dir else "text-x-generic")
    content = "[Desktop Entry]\nType=Link\nName=%s\nURL=%s\nIcon=%s\n" % (
        _desk_escape(name), _desk_escape(url), icon)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(content)
    os.chmod(tmp, 0o755)
    os.replace(tmp, path)


# ---------------------------------------------------------------- Textgewinnung für den Index

class _HTMLText(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self.skip += 1
        elif tag in ("p", "br", "div", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6"):
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag in ("script", "style") and self.skip:
            self.skip -= 1

    def handle_data(self, data):
        if not self.skip:
            self.parts.append(data)


def _decode(data: bytes) -> str:
    """UTF-8 (auch mit BOM), UTF-16 (Windows-Editor) oder, wenn beides nicht passt, Windows-1252."""
    if data.startswith(b"\xef\xbb\xbf"):
        return data[3:].decode("utf-8", errors="replace")
    if data.startswith((b"\xff\xfe", b"\xfe\xff")):
        try:
            return data.decode("utf-16")
        except UnicodeDecodeError:
            return data.decode("utf-16", errors="replace")
    head = data[:4096]
    if len(head) >= 8 and b"\x00" in head:
        even = head[0::2].count(0)
        odd = head[1::2].count(0)
        half = len(head) // 2
        for nul, enc in ((odd, "utf-16-le"), (even, "utf-16-be")):
            if nul > half * 0.3:
                try:
                    return data.decode(enc)
                except UnicodeDecodeError:
                    return data.decode(enc, errors="replace")
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("cp1252", errors="replace")


_RTF_SKIP = {"fonttbl", "colortbl", "stylesheet", "info", "pict", "header", "footer", "headerl", "headerr", "footerl",
             "footerr", "generator", "themedata", "colorschememapping", "latentstyles", "datastore", "listtable",
             "listoverridetable", "rsidtbl", "xmlnstbl", "fldinst", "object", "private", "revtbl", "filetbl"}


def rtf_text(data: str) -> str:
    """Einfacher RTF-Leser: Steuerwörter, Umlaute (\\'fc), Unicode (\\u252) und Zielgruppen wie Schriftlisten."""
    out: list[str] = []
    stack: list[bool] = []
    skip = False
    i, n = 0, len(data)
    uc = 1
    while i < n:
        ch = data[i]
        if ch == "{":
            stack.append(skip)
            i += 1
            if data.startswith("\\*", i):
                skip = True
            continue
        if ch == "}":
            skip = stack.pop() if stack else False
            i += 1
            continue
        if ch == "\\":
            i += 1
            if i >= n:
                break
            c = data[i]
            if c in "\\{}":
                if not skip:
                    out.append(c)
                i += 1
            elif c == "'":
                h = data[i + 1:i + 3]
                i += 3
                if not skip:
                    try:
                        out.append(bytes([int(h, 16)]).decode("cp1252", errors="replace"))
                    except ValueError:
                        pass
            elif c == "~":
                out.append(" ")
                i += 1
            elif c == "*":
                i += 1
            elif c.isalpha():
                m = re.match(r"([a-zA-Z]+)(-?\d+)? ?", data[i:])
                word, num = m.group(1), m.group(2)
                i += m.end()
                if word in _RTF_SKIP:
                    skip = True
                elif word in ("par", "line", "row", "sect", "page"):
                    if not skip:
                        out.append("\n")
                elif word in ("tab", "cell"):
                    if not skip:
                        out.append("\t")
                elif word == "uc" and num:
                    uc = max(0, int(num))
                elif word == "u" and num:
                    cp = int(num)
                    if cp < 0:
                        cp += 65536
                    if not skip:
                        out.append(chr(cp))
                    k = uc
                    while k > 0 and i < n:
                        if data.startswith("\\'", i):
                            i += 4
                        elif data[i] not in "\\{}":
                            i += 1
                        k -= 1
                elif word == "bin" and num:
                    i += int(num)
            else:
                i += 1
            continue
        if ch in "\r\n":
            i += 1
            continue
        if not skip:
            out.append(ch)
        i += 1
    return "".join(out)


def eml_text(data: bytes) -> str:
    import email
    import email.policy
    msg = email.message_from_bytes(data, policy=email.policy.default)
    parts = [str(msg.get(h, "")) for h in ("Subject", "From", "To", "Cc", "Date")]
    body = None
    try:
        body = msg.get_body(preferencelist=("plain", "html"))
    except Exception:  # noqa: BLE001
        body = None
    if body is not None:
        try:
            t = body.get_content()
        except Exception:  # noqa: BLE001
            t = ""
        if body.get_content_type() == "text/html":
            p = _HTMLText()
            p.feed(t)
            t = "".join(p.parts)
        parts.append(t)
    for att in msg.iter_attachments():
        fn = att.get_filename()
        if fn:
            parts.append(str(fn))
    return "\n".join(parts)


def html_text(txt: str) -> str:
    p = _HTMLText()
    try:
        p.feed(txt)
        return "".join(p.parts)
    except Exception:  # noqa: BLE001
        return txt


def legacy_text(path: str, ext: str, soffice: str | None, max_bytes: int, timeout: int = 90) -> tuple[str | None, str]:
    """Alte Office-Dateien (doc, xls, ppt) über LibreOffice in ein neueres Format umwandeln und dann lesen."""
    if not soffice:
        return None, "nolo"
    target = {"doc": "txt:Text (encoded):UTF8", "xls": "xlsx", "ppt": "pptx"}.get(ext)
    if not target:
        return None, "error"
    tmp = tempfile.mkdtemp(prefix="sd_lo_")
    try:
        r = subprocess.run([soffice, "--headless", "--norestore", "-env:UserInstallation=file://" + tmp + "/profile",
                            "--convert-to", target, "--outdir", tmp + "/out", path],
                           capture_output=True, timeout=timeout, cwd=tmp)
        outs = os.listdir(tmp + "/out") if os.path.isdir(tmp + "/out") else []
        if r.returncode != 0 or not outs:
            return None, "error"
        res = os.path.join(tmp + "/out", outs[0])
        if ext == "doc":
            with open(res, "rb") as f:
                return _decode(f.read(max_bytes + 1))[:MAX_CONTENT_CHARS], "ok"
        return extract_text(res, "xlsx" if ext == "xls" else "pptx", max_bytes, None)
    except (subprocess.TimeoutExpired, OSError):
        return None, "error"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _strip_xml(xml: str, para_tags: tuple[str, ...]) -> str:
    for t in para_tags:
        xml = xml.replace(t, "\n")
    xml = re.sub(r"<[^>]+>", "", xml)
    return html.unescape(xml)


def _zip_read(zf: zipfile.ZipFile, name: str, limit: int = 64_000_000) -> str:
    with zf.open(name) as f:
        return _decode(f.read(limit))


def _extract_xlsx(zf: zipfile.ZipFile) -> str:
    names = set(zf.namelist())
    shared: list[str] = []
    if "xl/sharedStrings.xml" in names:
        with zf.open("xl/sharedStrings.xml") as f:
            for _ev, el in ET.iterparse(f):
                if el.tag.endswith("}si"):
                    shared.append("".join(t.text or "" for t in el.iter() if t.tag.endswith("}t")))
                    el.clear()
    out: list[str] = []
    if "xl/workbook.xml" in names:
        wb = _zip_read(zf, "xl/workbook.xml")
        out.extend(html.unescape(m) for m in re.findall(r'<sheet [^>]*name="([^"]*)"', wb))
    for n in sorted(x for x in names if re.match(r"xl/worksheets/sheet\d+\.xml$", x)):
        row: list[str] = []
        with zf.open(n) as f:
            for ev, el in ET.iterparse(f, events=("end",)):
                tag = el.tag.rsplit("}", 1)[-1]
                if tag == "c":
                    t = el.get("t")
                    v = el.find("{*}v")
                    txt = ""
                    if t == "s" and v is not None and v.text and v.text.isdigit():
                        i = int(v.text)
                        txt = shared[i] if i < len(shared) else ""
                    elif t == "inlineStr":
                        txt = "".join(x.text or "" for x in el.iter() if x.tag.endswith("}t"))
                    elif v is not None and v.text:
                        txt = v.text
                    if txt:
                        row.append(txt)
                    el.clear()
                elif tag == "row":
                    if row:
                        out.append("\t".join(row))
                    row = []
                    el.clear()
    return "\n".join(out)


def extract_text(path: str, ext: str, max_bytes: int, pdftotext: str | None) -> tuple[str | None, str]:
    """Gibt (Text, Status) zurück. Text None bedeutet: nicht indizierbar, Status nennt den Grund."""
    try:
        size = os.path.getsize(path)
    except OSError:
        return None, "error"
    if ext == "pdf":
        if not pdftotext:
            return None, "nopdf"
        if size > max_bytes * 10:
            return None, "big"
        try:
            r = subprocess.run([pdftotext, "-enc", "UTF-8", "-q", path, "-"], capture_output=True, timeout=120)
        except (subprocess.TimeoutExpired, OSError):
            return None, "error"
        if r.returncode != 0:
            return None, "error"
        txt = r.stdout.decode("utf-8", errors="replace").replace("\x0c", "\n")
        if size > 50_000 and len(txt.strip()) < 20:
            return None, "scan"
        return txt[:MAX_CONTENT_CHARS], "ok"
    if size > max_bytes:
        return None, "big"
    try:
        if ext == "epub":
            with zipfile.ZipFile(path) as zf:
                txt = "\n".join(html_text(_zip_read(zf, n)) for n in sorted(zf.namelist())
                                if n.lower().endswith((".xhtml", ".html", ".htm", ".xml")) and not n.startswith("META-INF"))
            return txt[:MAX_CONTENT_CHARS], "ok"
        if ext in ("docx", "pptx", "xlsx", "odt", "ods", "odp", "odg"):
            with zipfile.ZipFile(path) as zf:
                names = zf.namelist()
                if ext == "docx":
                    parts = sorted(n for n in names if re.match(r"word/(document|footnotes|endnotes|comments|header\d*|footer\d*)\.xml$", n))
                    txt = "\n".join(_strip_xml(_zip_read(zf, n), ("</w:p>", "<w:br/>", "<w:tab/>")) for n in parts)
                elif ext == "pptx":
                    parts = sorted(n for n in names if re.match(r"ppt/(slides|notesSlides)/[^/]+\.xml$", n))
                    txt = "\n".join(_strip_xml(_zip_read(zf, n), ("</a:p>",)) for n in parts)
                elif ext == "xlsx":
                    txt = _extract_xlsx(zf)
                else:
                    if "content.xml" not in names:
                        return None, "error"
                    txt = _strip_xml(_zip_read(zf, "content.xml"),
                                     ("</text:p>", "</text:h>", "<text:line-break/>", "</table:table-cell>"))
            return txt[:MAX_CONTENT_CHARS], "ok"
        with open(path, "rb") as f:
            data = f.read(max_bytes + 1)
        if ext == "":
            if b"\x00" in data[:8192] and not data.startswith((b"\xff\xfe", b"\xfe\xff")):
                return None, "binary"
        if ext == "eml":
            return eml_text(data)[:MAX_CONTENT_CHARS], "ok"
        txt = _decode(data)
        if ext == "rtf":
            txt = rtf_text(txt)
        elif ext in ("html", "htm", "xhtml"):
            p = _HTMLText()
            try:
                p.feed(txt)
                txt = "".join(p.parts)
            except Exception:
                pass
        elif ext == "desktop":
            d = parse_desktop(path)
            if not d:
                return None, "binary"
            txt = f"{d['name']}\n{d['target']}"
        return txt[:MAX_CONTENT_CHARS], "ok"
    except (zipfile.BadZipFile, ET.ParseError, OSError, KeyError, RuntimeError, ValueError, LookupError, AttributeError):
        return None, "error"


# ---------------------------------------------------------------- Normalisierung für die Suche

def _build_canon_table() -> dict[int, str]:
    """Zeichen für Zeichen auf eine Suchform abbilden, ohne die Länge zu ändern:
    klein, ohne Akzente, ß wird zu s. So bleiben Treffer-Positionen im Originaltext gültig."""
    m: dict[int, str] = {}
    for cp in list(range(0x41, 0x2200)) + list(range(0xFF21, 0xFF3B)):
        if 0xD800 <= cp <= 0xDFFF:
            continue
        ch = chr(cp)
        lo = ch.lower()
        if len(lo) != 1:
            lo = ch
        d = unicodedata.normalize("NFD", lo)
        if len(d) > 1 and d[0].isascii() and all(unicodedata.combining(c) for c in d[1:]):
            lo = d[0]
        if lo != ch:
            m[cp] = lo
    m[0xDF] = "s"
    m[0x1E9E] = "s"
    for c in "\u2018\u2019\u201a\u201b\u02bc":
        m[ord(c)] = "'"
    for c in "\u201c\u201d\u201e\u201f":
        m[ord(c)] = '"'
    for c in "\u2010\u2011\u2012\u2013\u2014\u2212":
        m[ord(c)] = "-"
    m[0xA0] = " "
    for k, v in list(m.items()):               # Ketten auflösen (İ wurde zu I statt zu i): das Ergebnis ist immer schon Suchform
        while ord(v) in m:
            v = m[ord(v)]
        m[k] = v
    return m


CANON = _build_canon_table()


# str.translate mit einem Wörterbuch ist bei Text mit Umlauten langsam (jedes Zeichen einzeln nachgeschlagen).
# Schneller und gleichwertig: erst die wenigen Nicht-ASCII-Zeichen ersetzen, dann A bis Z auf Byte-Ebene klein schreiben.
_CANON_HI = re.compile("[" + "".join(re.escape(chr(k)) for k in sorted(CANON) if k >= 128) + "]")
_CANON_LO = bytes.maketrans(bytes(range(65, 91)), bytes(range(97, 123)))


def canon(s: str) -> str:
    if not s.isascii():
        for ch in set(_CANON_HI.findall(s)):    # meist nur eine Handvoll verschiedener Zeichen (ä, ö, ü, ß ...)
            s = s.replace(ch, CANON[ord(ch)])
    try:
        return s.encode("utf-8").translate(_CANON_LO).decode("utf-8")
    except UnicodeEncodeError:                 # einzelne Ersatzzeichen (kaputte Dateinamen): sicherer, langsamer Weg
        return s.translate(CANON)


def prep_text(text: str, dehyphen: bool = False) -> str:
    """Anzeigetext für den Index: Ligaturen auflösen (ﬁ wird fi), Silbentrennung am Zeilenende aufheben, Leerraum bündeln."""
    text = unicodedata.normalize("NFKC", text)
    text = text.replace("\x00", "")
    if dehyphen:
        text = re.sub(r"(?<=[a-zäöüß])-\s*\n\s*(?=[a-zäöüß])", "", text)
    return " ".join(text.split())               # gleichwertig zu re.sub(r"\s+", " ", text).strip(), aber viermal so schnell


def spelling_variants(term: str) -> list[str]:
    """Schreibweisen eines Suchworts in Suchform: Straße und Strasse, Müller und Mueller, Köln und Koeln."""
    low = unicodedata.normalize("NFKC", term).lower()
    base = canon(low)
    vs = {base}
    if "ß" in low:
        vs.add(canon(low.replace("ß", "ss")))
    if any(c in low for c in "äöü"):
        vs.add(canon(low.replace("ä", "ae").replace("ö", "oe").replace("ü", "ue").replace("ß", "ss")))
    if re.search("ae|oe|ue", base):
        c = base.replace("ae", "a").replace("oe", "o").replace("ue", "u")
        vs.add(c)
        vs.add(c.replace("ss", "s"))
    if "ss" in base:
        vs.add(base.replace("ss", "s"))
    return sorted((v for v in vs if v), key=lambda v: (-len(v), v))


# ---------------------------------------------------------------- Backend

from fileops import FileOps  # noqa: E402  (nutzt Hilfen von oben)
from terminal import Terminals  # noqa: E402
from apps import Apps  # noqa: E402
from startersetup import StarterSetup  # noqa: E402
from surfacesetup import SurfaceSetup  # noqa: E402


class Backend(FileOps, Terminals, Apps, StarterSetup, SurfaceSetup):
    def __init__(self, emit=None) -> None:
        self.emit = emit or (lambda name, data: None)
        self._cfg_lock = threading.RLock()
        self._tl = threading.local()
        self._cancel: set[int] = set()
        self._idx_lock = threading.Lock()
        self._idx_thread: threading.Thread | None = None
        self._idx_stop = threading.Event()
        self.idx: dict = self._idx_blank()
        self.pdftotext = shutil.which("pdftotext")
        self.pdftoppm = shutil.which("pdftoppm")
        self.soffice = shutil.which("soffice") or shutil.which("libreoffice")
        self.thumbnailer = None             # wird von der Oberfläche gesetzt: (Pfad, Kantenlänge) -> (Bytes, MIME, Breite, Höhe) | None
        self._thumbs: OrderedDict = OrderedDict()
        self._thumb_lock = threading.Lock()
        self.first_run = not (config_dir() / "config.json").exists()
        self.cfg = self._load_config()
        data_dir().mkdir(parents=True, exist_ok=True)
        self._db_init()

    # ---- Aufruf von außen
    def call(self, method: str, args: dict | None, cid: int = 0):
        fn = getattr(self, "api_" + method, None)
        if fn is None or method.startswith("_"):
            raise AppError("Unbekannte Funktion: " + method)
        self._tl.cid = cid
        try:
            return fn(**(args or {}))
        finally:
            self._tl.cid = 0
            self._cancel.discard(cid)

    def cancel(self, cid: int) -> None:
        if len(self._cancel) > 1000:
            self._cancel.clear()
        self._cancel.add(cid)

    def _cancelled(self) -> bool:
        return getattr(self._tl, "cid", 0) in self._cancel

    # ---- Einstellungen
    def _load_config(self) -> dict:
        cfg = json.loads(json.dumps(DEFAULT_CONFIG))
        p = config_dir() / "config.json"
        try:
            with open(p, "r", encoding="utf-8") as f:
                stored = json.load(f)
            if isinstance(stored, dict):
                cfg.update({k: v for k, v in stored.items() if k in DEFAULT_CONFIG})
                if int(stored.get("index_ver", 1) or 1) < 2:
                    # Version 1.3 kennt mehr Dateitypen; bestehende Listen werden ergänzt, nichts wird entfernt.
                    cfg["index_exts"] = sorted(set(cfg.get("index_exts") or []) | set(NEW_IN_13))
                    cfg["index_ver"] = 2
        except (OSError, ValueError):
            pass
        if self.first_run:
            cfg["favorites"] = self._seed_favorites()
            cfg["roots"] = [d for d in (self._xdg("DOCUMENTS"),) if d and os.path.isdir(d)]
        return cfg

    def _save_config(self) -> None:
        d = config_dir()
        d.mkdir(parents=True, exist_ok=True)
        tmp = d / "config.json.tmp"
        with self._cfg_lock:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.cfg, f, ensure_ascii=False, indent=1)
            os.replace(tmp, d / "config.json")

    def _xdg(self, key: str) -> str | None:
        home = str(Path.home())
        f = Path(os.environ.get("XDG_CONFIG_HOME") or (Path.home() / ".config")) / "user-dirs.dirs"
        try:
            for line in f.read_text(encoding="utf-8").splitlines():
                m = re.match(r'XDG_%s_DIR="?([^"]*)"?' % key, line.strip())
                if m:
                    return m.group(1).replace("$HOME", home)
        except OSError:
            pass
        names = {"DOCUMENTS": ("Documents", "Dokumente"), "DOWNLOAD": ("Downloads", "Download"),
                 "PICTURES": ("Pictures", "Bilder"), "DESKTOP": ("Desktop", "Schreibtisch"),
                 "MUSIC": ("Music", "Musik"), "VIDEOS": ("Videos", "Video")}.get(key, (key.title(),))
        for n in names:
            if os.path.isdir(os.path.join(home, n)):
                return os.path.join(home, n)
        return os.path.join(home, names[0])

    def _seed_favorites(self) -> list[dict]:
        home = str(Path.home())
        items = [("Persönlicher Ordner", home)]
        for key, title in (("DOCUMENTS", "Dokumente"), ("DOWNLOAD", "Downloads"),
                           ("PICTURES", "Bilder"), ("DESKTOP", "Schreibtisch")):
            p = self._xdg(key)
            if p and os.path.isdir(p) and p != home:
                items.append((title, p))
        return [{"id": uuid.uuid4().hex[:10], "kind": "path", "target": p, "title": t,
                 "color": COLORS[i % len(COLORS)]} for i, (t, p) in enumerate(items)]

    @staticmethod
    def _clean_favorites(favs) -> list[dict]:
        out = []
        if not isinstance(favs, list):
            raise AppError("Favoriten müssen eine Liste sein.")
        for i, f in enumerate(favs[:200]):
            if not isinstance(f, dict):
                continue
            kind = f.get("kind")
            target = str(f.get("target", "")).strip()
            if kind not in ("path", "url") or not target:
                continue
            if kind == "url":
                target, _ = normalize_link_target("url", target)
            else:
                target = norm_path(target)
            color = str(f.get("color", ""))
            if not re.fullmatch(r"#[0-9a-fA-F]{6}", color):
                color = COLORS[i % len(COLORS)]
            title = str(f.get("title", "")).strip()[:200] or (
                urllib.parse.urlparse(target).netloc if kind == "url" else (os.path.basename(target) or target))
            fid = str(f.get("id") or uuid.uuid4().hex[:10])[:20]
            out.append({"id": fid, "kind": kind, "target": target, "title": title, "color": color.lower()})
        return out

    def api_set_config(self, patch: dict) -> dict:
        if not isinstance(patch, dict):
            raise AppError("Ungültige Einstellungen.")
        with self._cfg_lock:
            for k, v in patch.items():
                if k not in DEFAULT_CONFIG:
                    continue
                if k == "theme" and v not in ("auto", "light", "dark"):
                    raise AppError("Ungültiges Design.")
                if k == "skin" and v not in SKINS:
                    raise AppError("Ungültiges Farbdesign.")
                if k == "folder_style" and v not in FOLDER_STYLES:
                    raise AppError("Ungültiger Ordnerstil.")
                if k == "folder_color" and v not in FOLDER_COLORS:
                    raise AppError("Ungültige Ordnerfarbe.")
                if k == "start_view" and v not in ("fav", "dir"):
                    raise AppError("Ungültige Startansicht.")
                if k == "favorites":
                    v = self._clean_favorites(v)
                elif k == "roots":
                    if not isinstance(v, list):
                        raise AppError("Ordnerliste ungültig.")
                    v = [norm_path(x) for x in v if isinstance(x, str) and x.strip()]
                    v = list(dict.fromkeys(v))
                elif k == "index_exts":
                    if not isinstance(v, list):
                        raise AppError("Dateitypen ungültig.")
                    v = sorted({re.sub(r"[^a-z0-9_+-]", "", str(x).lower().lstrip(".")) for x in v} - {""})
                elif k in ("index_hidden", "show_hidden", "index_auto"):
                    v = bool(v)
                elif k == "max_file_mb":
                    v = max(1, min(2000, int(v)))
                elif k in ("last_path", "geometry"):
                    v = str(v)
                elif k == "dir_view":
                    if v not in ("list", "icons", "preview", "sphere"):
                        raise AppError("Ungültige Ordneransicht.")
                elif k in ("dual", "dual_vertical"):
                    v = bool(v)
                elif k == "icon_size":
                    if v not in ("s", "m", "l"):
                        raise AppError("Ungültige Symbolgröße.")
                elif k == "opacity":
                    v = max(35, min(100, int(v)))
                elif k == "translucent":
                    v = bool(v)
                elif k in ("bg_strength", "bg_see"):
                    v = max(0, min(100, int(v)))
                elif k == "sort_key":
                    if v not in ("name", "size", "mtime", "type"):
                        raise AppError("Ungültige Sortierung.")
                elif k == "sort_dir":
                    v = -1 if int(v) < 0 else 1
                elif k in ("dirs_first", "col_size", "col_date", "thumbs", "term_open", "term_follow", "new_workspace", "ext_tab"):
                    v = bool(v)
                elif k == "term_height":
                    v = max(120, min(900, int(v)))
                elif k == "ft_dirs":
                    v = bool(v)
                elif k == "starter":
                    from startersetup import clean_starter
                    v = clean_starter({**self.cfg.get("starter", {}), **v} if isinstance(v, dict) else v)
                elif k == "assoc":
                    if not isinstance(v, dict):
                        raise AppError("Zuordnung ungültig.")
                    v = {str(e).lower().lstrip("."): a for e, a in v.items()
                         if re.fullmatch(r"[a-z0-9_+-]{1,16}", str(e).lower().lstrip(".")) and isinstance(a, str) and re.fullmatch(r"[A-Za-z0-9_.+-]+\.desktop", a)}
                elif k == "bg_fit":
                    if v not in ("cover", "contain", "center", "tile"):
                        raise AppError("Ungültige Bildanpassung.")
                self.cfg[k] = v
            self._save_config()
            out = json.loads(json.dumps(self.cfg))
        try:
            self.emit("cfg", out)                      # weitere Fenster übernehmen die Einstellungen
        except Exception:  # noqa: BLE001
            pass
        return out

    def api_get_state(self) -> dict:
        home = str(Path.home())
        places = [{"name": "Persönlicher Ordner", "path": home}]
        for key, title in (("DESKTOP", "Schreibtisch"), ("DOCUMENTS", "Dokumente"), ("DOWNLOAD", "Downloads"),
                           ("PICTURES", "Bilder"), ("MUSIC", "Musik"), ("VIDEOS", "Videos")):
            p = self._xdg(key)
            if p and os.path.isdir(p) and p != home:
                places.append({"name": title, "path": p})
        user = os.environ.get("USER") or ""
        for base in (f"/run/media/{user}", f"/media/{user}", "/mnt"):
            try:
                for n in sorted(os.listdir(base)):
                    p = os.path.join(base, n)
                    if os.path.isdir(p):
                        places.append({"name": n + " (Laufwerk)", "path": p})
            except OSError:
                pass
        places.append({"name": "Dateisystem (/)", "path": "/"})
        return {
            "cfg": json.loads(json.dumps(self.cfg)),
            "home": home,
            "places": places,
            "index": self.api_index_status(),
            "version": VERSION,
            "colors": COLORS,
            "default_exts": DEFAULT_EXTS,
            "has_pdftotext": bool(self.pdftotext),
            "has_soffice": bool(self.soffice),
            "has_pdftoppm": bool(self.pdftoppm),
            "ftypes": {k: list(v) for k, v in FILE_TYPES.items()},
            "alt_x": self.surface_alt_x(),
        }

    # ---- Dateisystem
    def api_check_paths(self, paths: list[str]) -> dict:
        out = {}
        for p in paths[:500]:
            try:
                ap = norm_path(p)
                out[p] = "dir" if os.path.isdir(ap) else ("file" if os.path.exists(ap) else "missing")
            except AppError:
                out[p] = "missing"
        return out

    def _entry(self, path: str, name: str, de: os.DirEntry | None = None, links: bool = True) -> dict | None:
        symlink = False
        broken = False
        try:
            st = de.stat() if de else os.stat(path)
            is_dir = stat_isdir(st)
            symlink = de.is_symlink() if de else os.path.islink(path)
        except OSError:
            try:
                st = os.lstat(path)
            except OSError:
                return None
            is_dir = False
            symlink = True
            broken = True
        ext = os.path.splitext(name)[1][1:].lower()
        e = {"name": name, "path": path, "kind": "dir" if is_dir else "file", "size": 0 if is_dir else st.st_size,
             "mtime": st.st_mtime, "hidden": name.startswith("."), "symlink": symlink, "broken": broken, "ext": ext}
        if links and not is_dir and ext == "desktop":
            d = parse_desktop(path)
            if d:
                e["kind"] = "link"
                e["link"] = d
        return e

    def api_list_dir(self, path: str, show_hidden: bool = False) -> dict:
        p = norm_path(path)
        if not os.path.isdir(p):
            raise AppError("Der Ordner existiert nicht: " + p)
        entries = []
        try:
            with os.scandir(p) as it:
                for de in it:
                    if not show_hidden and de.name.startswith("."):
                        continue
                    e = self._entry(de.path, de.name, de)
                    if e:
                        entries.append(e)
        except PermissionError:
            raise AppError("Keine Berechtigung für diesen Ordner: " + p)
        parent = os.path.dirname(p) if p != "/" else None
        out = {"path": p, "parent": parent, "entries": entries, "writable": os.access(p, os.W_OK)}
        try:
            out["stamp"] = os.stat(p).st_mtime_ns
        except OSError:
            out["stamp"] = 0
        try:
            out["free"] = shutil.disk_usage(p).free
        except OSError:
            out["free"] = None
        return out

    # ---- Hintergrundbild (verkleinerte Kopie im Datenordner, unabhängig von der Originaldatei)
    def _bg_file(self) -> Path | None:
        for n in ("background.jpg", "background.png"):
            f = data_dir() / n
            if f.exists():
                return f
        return None

    def api_get_background(self) -> dict:
        f = self._bg_file()
        if not f:
            return {"url": None}
        try:
            mime = "image/png" if f.suffix == ".png" else "image/jpeg"
            return {"url": "data:%s;base64,%s" % (mime, base64.b64encode(f.read_bytes()).decode("ascii"))}
        except OSError:
            return {"url": None}

    def api_set_background(self, path: str) -> dict:
        p = norm_path(path)
        ext = os.path.splitext(p)[1][1:].lower()
        if not os.path.isfile(p):
            raise AppError("Die Datei existiert nicht: " + p)
        if ext not in IMAGE_EXTS:
            raise AppError("Das ist keine unterstützte Bilddatei (png, jpg, gif, webp, bmp, tif, avif).")
        if os.path.getsize(p) > 120_000_000:
            raise AppError("Die Bilddatei ist zu groß (über 120 MB).")
        blob = None
        for edge in (2560, 1920, 1280):
            out = None
            if self.thumbnailer:
                try:
                    out = self.thumbnailer(p, edge)
                except Exception:  # noqa: BLE001
                    out = None
            if out and len(out[0]) <= 6_000_000:
                blob = (out[0], ".png" if out[1] == "image/png" else ".jpg")
                break
        if blob is None and not self.thumbnailer and ext in ("jpg", "jpeg", "png") and os.path.getsize(p) <= 8_000_000:
            with open(p, "rb") as f:
                blob = (f.read(), ".png" if ext == "png" else ".jpg")
        if blob is None:
            raise AppError("Dieses Bild kann nicht verwendet werden (Format nicht lesbar oder zu groß).")
        d = data_dir()
        d.mkdir(parents=True, exist_ok=True)
        for n in ("background.jpg", "background.png"):
            try:
                (d / n).unlink()
            except OSError:
                pass
        tmp = d / ("background.tmp")
        tmp.write_bytes(blob[0])
        os.replace(tmp, d / ("background" + blob[1]))
        return self.api_get_background()

    def api_clear_background(self) -> dict:
        for n in ("background.jpg", "background.png"):
            try:
                (data_dir() / n).unlink()
            except OSError:
                pass
        return {"url": None}

    # ---- Vorschau und Ordnerbaum
    def _thumb_url(self, path: str, st: os.stat_result, edge: int) -> dict | None:
        """Bild als data-URL (verkleinert). Gibt {"url", "w", "h"} oder None zurück."""
        key = (path, st.st_mtime_ns, st.st_size, edge)
        with self._thumb_lock:
            hit = self._thumbs.get(key)
            if hit is not None:
                self._thumbs.move_to_end(key)
                return hit
        ext = os.path.splitext(path)[1][1:].lower()
        res = None
        if st.st_size > 80_000_000:
            return None
        if self.thumbnailer:
            try:
                out = self.thumbnailer(path, edge)
            except Exception:  # noqa: BLE001 - kaputte Bilddatei darf nichts zerstören
                out = None
            if out:
                data, mime, w, h = out
                res = {"url": "data:%s;base64,%s" % (mime, base64.b64encode(data).decode("ascii")), "w": w, "h": h}
        # Rohdaten nur, wenn kein Verkleinerer da ist (oder bei SVG, das Qt eventuell nicht liest); ein vom Verkleinerer abgelehntes Bild ist kaputt
        if res is None and (not self.thumbnailer or ext == "svg") and ext in IMAGE_EXTS | {"svg"} and st.st_size <= (400_000 if ext == "svg" else 1_500_000):
            mime = {"jpg": "image/jpeg", "jpeg": "image/jpeg", "svg": "image/svg+xml", "tif": "image/tiff",
                    "tiff": "image/tiff", "ico": "image/x-icon"}.get(ext, "image/" + ext)
            try:
                with open(path, "rb") as f:
                    res = {"url": "data:%s;base64,%s" % (mime, base64.b64encode(f.read()).decode("ascii")), "w": 0, "h": 0}
            except OSError:
                return None
        if res is None:
            return None
        with self._thumb_lock:
            self._thumbs[key] = res
            while len(self._thumbs) > 400 or sum(len(v["url"]) for v in self._thumbs.values()) > 60_000_000:
                self._thumbs.popitem(last=False)
        return res

    def api_thumb(self, path: str, edge: int = 160) -> dict:
        p = norm_path(path)
        edge = max(48, min(1400, int(edge)))
        try:
            st = os.stat(p)
        except OSError:
            return {"url": None}
        ext = os.path.splitext(p)[1][1:].lower()
        if not os.path.isfile(p) or (ext not in IMAGE_EXTS and ext != "svg"):
            return {"url": None}
        t = self._thumb_url(p, st, edge)
        return {"url": t["url"] if t else None}

    @staticmethod
    def _decode_prefix(data: bytes, cut: bool) -> str:
        """Dekodiert den Anfang einer Datei. Ein mitten im Zeichen abgeschnittenes Ende wird nicht als Fehler gewertet."""
        if cut:
            for k in range(4):
                try:
                    return data[:len(data) - k].decode("utf-8")
                except UnicodeDecodeError:
                    continue
            return data.decode("cp1252", errors="replace")
        return _decode(data)

    def _read_text_head(self, path: str, limit: int = 65536) -> tuple[str | None, bool]:
        """Textanfang oder None, wenn die Datei binär aussieht. Zweiter Wert: wurde abgeschnitten."""
        try:
            with open(path, "rb") as f:
                data = f.read(limit + 1)
        except OSError:
            return None, False
        cut = len(data) > limit
        data = data[:limit]
        if b"\x00" in data[:8192]:
            return None, cut
        txt = self._decode_prefix(data, cut)
        bad = sum(1 for ch in txt[:4000] if (ord(ch) < 32 and ch not in "\n\r\t\f") or ch == "�")
        if bad > 8:
            return None, cut
        return txt.replace("\r\n", "\n").replace("\r", "\n"), cut

    def _pdf_preview(self, path: str, size: int) -> dict:
        out: dict = {"kind": "pdf", "pages": None, "text": "", "img": None}
        pdfinfo = shutil.which("pdfinfo")
        if pdfinfo:
            try:
                r = subprocess.run([pdfinfo, path], capture_output=True, timeout=15)
                m = re.search(rb"^Pages:\s+(\d+)", r.stdout, re.M)
                if m:
                    out["pages"] = int(m.group(1))
            except (subprocess.TimeoutExpired, OSError):
                pass
        if size > 300_000_000:
            out["note"] = "Die Datei ist für eine Vorschau zu groß."
            return out
        if self.pdftoppm:
            try:
                with tempfile.TemporaryDirectory(prefix="sd_pdf_") as td:
                    base = os.path.join(td, "p")
                    r = subprocess.run([self.pdftoppm, "-png", "-f", "1", "-l", "1", "-singlefile", "-scale-to", "1000", path, base],
                                       capture_output=True, timeout=40)
                    png = base + ".png"
                    if r.returncode == 0 and os.path.exists(png) and os.path.getsize(png) < 12_000_000:
                        with open(png, "rb") as f:
                            out["img"] = "data:image/png;base64," + base64.b64encode(f.read()).decode("ascii")
            except (subprocess.TimeoutExpired, OSError):
                pass
        if self.pdftotext and not out["img"]:
            try:
                r = subprocess.run([self.pdftotext, "-l", "1", "-enc", "UTF-8", "-q", path, "-"], capture_output=True, timeout=30)
                if r.returncode == 0:
                    out["text"] = r.stdout.decode("utf-8", errors="replace").replace("\x0c", "\n").strip()[:4000]
            except (subprocess.TimeoutExpired, OSError):
                pass
        if not out["img"] and not out["text"]:
            out["note"] = ("Für die Seitenvorschau fehlt pdftoppm (Paket poppler)." if not self.pdftoppm
                           else "Aus dieser PDF-Datei lässt sich keine Vorschau erzeugen (vielleicht gescannt oder beschädigt).")
        return out

    def api_preview(self, path: str, max_chars: int = 5000, show_hidden: bool = False) -> dict:
        p = norm_path(path)
        try:
            st = os.stat(p)
        except OSError:
            if os.path.islink(p):
                nm = os.path.basename(p)
                return {"name": nm, "path": p, "size": 0, "mtime": os.lstat(p).st_mtime, "ext": "", "group": "other",
                        "label": "Defekter Verweis", "kind": "other", "note": "Das Ziel dieses Verweises existiert nicht mehr."}
            raise AppError("Nicht gefunden: " + p)
        name = os.path.basename(p) or p
        ext = os.path.splitext(name)[1][1:].lower()
        grp, label = FILE_TYPES.get(ext, ("other", "Datei" if not ext else "%s-Datei" % ext.upper()))
        base = {"name": name, "path": p, "size": st.st_size, "mtime": st.st_mtime, "ext": ext, "group": grp, "label": label}
        max_chars = max(500, min(20000, int(max_chars)))
        if os.path.isdir(p):
            nd = nf = 0
            items = []
            try:
                with os.scandir(p) as it:
                    for de in it:
                        if de.name.startswith(".") and not show_hidden:
                            continue
                        isd = de.is_dir()
                        nd += isd
                        nf += not isd
                        if len(items) < 400:
                            items.append((not isd, fold(de.name), de.name, isd))
            except PermissionError:
                return {**base, "kind": "dir", "label": "Ordner", "denied": True, "nd": 0, "nf": 0, "items": [], "more": 0}
            items.sort()
            shown = [{"name": n, "dir": d} for _, _, n, d in items[:40]]
            return {**base, "kind": "dir", "label": "Ordner", "nd": nd, "nf": nf, "items": shown, "more": max(0, nd + nf - len(shown))}
        if ext == "desktop":
            d = parse_desktop(p)
            if d:
                return {**base, "kind": "link", "label": "Verknüpfung", "link": d}
        if ext in IMAGE_EXTS or ext == "svg":
            t = self._thumb_url(p, st, 1100)
            if t:
                return {**base, "kind": "image", "url": t["url"], "w": t["w"], "h": t["h"]}
            if ext != "svg":
                return {**base, "kind": "other", "note": "Dieses Bild kann nicht dargestellt werden (Format nicht unterstützt oder Datei beschädigt)."}
        if ext == "pdf":
            return {**base, **self._pdf_preview(p, st.st_size)}
        if ext in ("docx", "xlsx", "pptx", "odt", "ods", "odp"):
            if st.st_size > 40_000_000:
                return {**base, "kind": "other", "note": "Die Datei ist für eine Vorschau zu groß."}
            txt, status = extract_text(p, ext, 40_000_000, None)
            if txt is None:
                return {**base, "kind": "other", "note": "Der Inhalt lässt sich nicht lesen (beschädigt oder verschlüsselt)."}
            txt = re.sub(r"\n{3,}", "\n\n", txt).strip()
            return {**base, "kind": "text", "text": txt[:max_chars], "truncated": len(txt) > max_chars, "mono": False, "office": True}
        if ext in ("doc", "xls", "ppt", "rtf") or grp in ("audio", "video", "archive"):
            return {**base, "kind": "other", "note": "Für diesen Dateityp gibt es keine Vorschau. Mit „Öffnen“ startet das zugehörige Programm."}
        txt, cut = self._read_text_head(p)
        if txt is None:
            return {**base, "kind": "other", "note": "Binärdatei: keine Textvorschau möglich."}
        if ext in ("html", "htm", "xhtml"):
            hp = _HTMLText()
            try:
                hp.feed(txt)
                txt = re.sub(r"\n{3,}", "\n\n", "".join(hp.parts)).strip()
            except Exception:  # noqa: BLE001
                pass
        lines = txt.split("\n")
        truncated = cut or len(txt) > max_chars or len(lines) > 160
        txt = "\n".join(lines[:160])[:max_chars]
        return {**base, "kind": "text", "text": txt, "truncated": truncated, "mono": grp in MONO_GROUPS or ext in ("csv", "tsv", "log", "ini", "cfg", "conf")}

    def api_complete(self, prefix: str) -> list[dict]:
        pre = os.path.expanduser(prefix or "")
        if not pre.startswith("/"):
            return []
        d, base = os.path.split(pre)
        d = d or "/"
        out = []
        try:
            fb = fold(base)
            with os.scandir(d) as it:
                for de in it:
                    if de.name.startswith(".") and not base.startswith("."):
                        continue
                    if fold(de.name).startswith(fb):
                        isdir = de.is_dir()
                        out.append({"path": de.path + ("/" if isdir else ""), "dir": isdir})
        except OSError:
            return []
        out.sort(key=lambda x: (not x["dir"], x["path"].lower()))
        return out[:40]

    def api_mkdir(self, parent: str, name: str) -> str:
        parent = norm_path(parent)
        name = check_name(name)
        p = os.path.join(parent, name)
        if os.path.lexists(p):
            raise AppError("Es gibt hier schon etwas mit diesem Namen.")
        try:
            os.mkdir(p)
        except OSError as e:
            raise AppError("Ordner konnte nicht angelegt werden: " + e.strerror)
        self._push_undo({"kind": "created", "created": [p], "desc": "Neuer Ordner: " + name})
        return p

    def api_rename(self, path: str, name: str) -> str:
        p = norm_path(path)
        name = check_name(name)
        new = os.path.join(os.path.dirname(p), name)
        if new == p:
            return p
        if os.path.lexists(new):
            raise AppError("Es gibt hier schon etwas mit diesem Namen.")
        try:
            os.rename(p, new)
        except OSError as e:
            raise AppError("Umbenennen nicht möglich: " + e.strerror)
        self._push_undo({"kind": "rename", "pairs": [(new, p)], "desc": "Umbenennen: " + os.path.basename(p)})
        return new

    def api_trash(self, path: str, prefer_gio: bool = True) -> dict:
        p = norm_path(path)
        res = self._trash_path(p, prefer_gio)
        self._push_undo({"kind": "trash", "paths": [p], "desc": "Papierkorb: " + os.path.basename(p)})
        return res

    def _trash_path(self, path: str, prefer_gio: bool = True) -> dict:
        p = norm_path(path)
        if not os.path.lexists(p):
            raise AppError("Die Datei existiert nicht mehr.")
        if p == "/" or p == str(Path.home()):
            raise AppError("Dieser Ordner darf nicht gelöscht werden.")
        gio = shutil.which("gio")
        if gio and prefer_gio:
            r = subprocess.run([gio, "trash", "--", p], capture_output=True, text=True, timeout=120)
            if r.returncode == 0:
                return {"ok": True}
        # Rückfall: Papierkorb nach freedesktop-Standard im Home-Verzeichnis
        base = Path(os.environ.get("XDG_DATA_HOME") or (Path.home() / ".local" / "share")) / "Trash"
        (base / "files").mkdir(parents=True, exist_ok=True)
        (base / "info").mkdir(parents=True, exist_ok=True)
        name = os.path.basename(p)
        target = unique_path(str(base / "files"), name)
        tname = os.path.basename(target)
        info = (f"[Trash Info]\nPath={urllib.parse.quote(p, safe='/')}\n"
                f"DeletionDate={time.strftime('%Y-%m-%dT%H:%M:%S')}\n")
        try:
            (base / "info" / (tname + ".trashinfo")).write_text(info, encoding="utf-8")
            shutil.move(p, target)
        except OSError as e:
            raise AppError("Papierkorb nicht möglich: " + (e.strerror or str(e)))
        return {"ok": True, "fallback": True}

    def _spawn(self, argv: list[str], **kw):
        """Startet ein externes Programm; mit der Einstellung "new_workspace" erscheint sein Fenster auf einer eigenen Arbeitsfläche."""
        import workspace
        return workspace.launch(argv, bool(self.cfg.get("new_workspace", True)), **kw)

    def api_workspace_status(self) -> dict:
        import workspace
        return workspace.status()

    def _launch(self, target: str) -> dict:
        opener = shutil.which("xdg-open")
        if not opener:
            raise AppError("xdg-open wurde nicht gefunden.")
        try:
            pr = self._spawn([opener, target], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, start_new_session=True)
        except OSError as e:
            raise AppError("Öffnen nicht möglich: " + (e.strerror or str(e)))
        try:
            rc = pr.wait(timeout=0.6)
        except subprocess.TimeoutExpired:
            rc = 0
        if rc not in (0, None):
            raise AppError("Kein Programm zum Öffnen gefunden (xdg-open Fehlercode %s)." % rc)
        return {"ok": True}

    def api_open_path(self, path: str) -> dict:
        p = norm_path(path)
        if not os.path.exists(p):
            raise AppError("Die Datei existiert nicht mehr.")
        if p.lower().endswith(".desktop") and not parse_desktop(p):
            raise AppError("Startdateien (.desktop) werden hier aus Sicherheitsgründen nicht gestartet.")
        app = self._assoc_app_for(p) if os.path.isfile(p) else ""
        if app:
            try:
                return self.api_open_with([p], app)
            except AppError:
                pass                                   # Programm nicht mehr startbar: Systemstandard nehmen
        return self._launch(p)

    def api_open_url(self, url: str) -> dict:
        u = urllib.parse.urlparse(url or "")
        if u.scheme.lower() not in URL_SCHEMES:
            raise AppError("Diese Adresse darf nicht geöffnet werden.")
        return self._launch(url)

    def api_show_in_fm(self, path: str) -> dict:
        p = norm_path(path)
        d = p if os.path.isdir(p) else os.path.dirname(p)
        return self._launch(d)

    # ---- Verknüpfungen
    def api_open_link(self, path: str) -> dict:
        p = norm_path(path)
        d = parse_desktop(p)
        if not d:
            raise AppError("Das ist keine gültige Verknüpfung.")
        if d["type"] == "path":
            if not os.path.exists(d["target"]):
                raise AppError("Das Ziel der Verknüpfung fehlt: " + d["target"])
            if os.path.isdir(d["target"]):
                return {"navigate": d["target"]}
            return self._launch(d["target"])
        return self.api_open_url(d["url"])

    def api_create_link(self, dir: str, kind: str, name: str, target: str) -> dict:
        d = norm_path(dir)
        if not os.path.isdir(d):
            raise AppError("Der Ordner existiert nicht.")
        name = (name or "").strip()
        url, typ = normalize_link_target(kind, target)
        if not name:
            name = (urllib.parse.urlparse(url).netloc if typ == "url" else os.path.basename(norm_path(target))) or "Verknüpfung"
        if not os.access(d, os.W_OK):
            raise AppError("In diesem Ordner darf nicht geschrieben werden.")
        path = unique_path(d, safe_filename(name), ".desktop")
        is_dir = os.path.isdir(norm_path(target)) if typ == "path" else None
        try:
            write_desktop_link(path, name, url, is_dir, typ == "url")
        except OSError as e:
            raise AppError("Verknüpfung konnte nicht gespeichert werden: " + (e.strerror or str(e)))
        return {"path": path, "exists": True if typ == "url" else os.path.exists(norm_path(target))}

    def api_update_link(self, path: str, kind: str, name: str, target: str) -> dict:
        p = norm_path(path)
        if not parse_desktop(p):
            raise AppError("Das ist keine gültige Verknüpfung.")
        name = (name or "").strip()
        url, typ = normalize_link_target(kind, target)
        if not name:
            raise AppError("Bitte einen Namen angeben.")
        is_dir = os.path.isdir(norm_path(target)) if typ == "path" else None
        try:
            write_desktop_link(p, name, url, is_dir, typ == "url")
            newp = p
            want = safe_filename(name) + ".desktop"
            if os.path.basename(p) != want:
                cand = os.path.join(os.path.dirname(p), want)
                if not os.path.lexists(cand):
                    os.rename(p, cand)
                    newp = cand
        except OSError as e:
            raise AppError("Verknüpfung konnte nicht gespeichert werden: " + (e.strerror or str(e)))
        return {"path": newp}

    # ---- Dateinamensuche (live, ohne Index)
    def api_search_names(self, query: str, root: str, kind: str = "all", show_hidden: bool = False,
                         limit: int = 2000, max_seconds: float = 25.0) -> dict:
        root = norm_path(root)
        if not os.path.isdir(root):
            raise AppError("Der Suchordner existiert nicht.")
        toks, exts = [], set()
        for m in re.finditer(r'"([^"]+)"|(\S+)', query or ""):
            t = m.group(1) or m.group(2)
            if t.lower().startswith("ext:"):
                exts |= {x.strip(".").lower() for x in t[4:].split(",") if x.strip(".")}
            else:
                toks.append(fold(t))
        if not toks and not exts:
            return {"results": [], "truncated": False, "seconds": 0, "scanned": 0}
        t0 = time.time()
        results, scanned, truncated, cancelled = [], 0, False, False
        stack = [root]
        while stack:
            if self._cancelled():
                cancelled = True
                break
            if time.time() - t0 > max_seconds:
                truncated = True
                break
            d = stack.pop()
            try:
                it = os.scandir(d)
            except OSError:
                continue
            with it:
                for de in it:
                    name = de.name
                    if not show_hidden and name.startswith("."):
                        continue
                    scanned += 1
                    try:
                        isdir = de.is_dir(follow_symlinks=False)
                        shown_dir = isdir or de.is_dir()
                    except OSError:
                        isdir = shown_dir = False
                    if isdir and name not in SKIP_DIRS:
                        stack.append(de.path)
                    fname = fold(name)
                    ok = True
                    for t in toks:
                        if ("*" in t or "?" in t):
                            if not fnmatch.fnmatchcase(fname, t):
                                ok = False
                                break
                        elif t not in fname:
                            ok = False
                            break
                    if not ok:
                        continue
                    if exts and (shown_dir or os.path.splitext(name)[1][1:].lower() not in exts):
                        continue
                    if kind == "dir" and not shown_dir:
                        continue
                    if kind in ("file", "link") and shown_dir:
                        continue
                    e = self._entry(de.path, name, de, links=(kind in ("all", "link")) or name.endswith(".desktop"))
                    if not e:
                        continue
                    if kind == "link" and e["kind"] != "link":
                        continue
                    if kind == "file" and e["kind"] == "link":
                        continue
                    e["dir"] = d
                    results.append(e)
                    if len(results) >= limit:
                        truncated = True
                        stack.clear()
                        break
        first = toks[0] if toks else ""
        results.sort(key=lambda e: (not fold(e["name"]).startswith(first), e["path"].count("/"), fold(e["name"])))
        return {"results": results, "truncated": truncated, "cancelled": cancelled,
                "seconds": round(time.time() - t0, 2), "scanned": scanned}

    # ---- Volltextindex
    def _db_path(self) -> str:
        return str(data_dir() / "index.sqlite")

    def _connect(self) -> sqlite3.Connection:
        """Öffnet den Index. Läuft gerade ein anderer Prozess (Starter, Dateien, Oberfläche) mit Schreibzugriff, meldet SQLite
        beim Umschalten des Journals sofort 'database is locked' (die Wartezeit gilt dort nicht). Darum: Umschalten nur,
        wenn nötig, und bei gesperrter Datenbank bis zu 30 Sekunden lang erneut versuchen, statt das Programm zu beenden."""
        deadline = time.monotonic() + 30
        delay = 0.05
        while True:
            con = sqlite3.connect(self._db_path(), timeout=30, check_same_thread=False)
            try:
                con.execute("PRAGMA busy_timeout=30000")
                if str(con.execute("PRAGMA journal_mode").fetchone()[0]).lower() != "wal":
                    con.execute("PRAGMA journal_mode=WAL")
                con.execute("PRAGMA synchronous=NORMAL")
                return con
            except sqlite3.OperationalError as e:
                con.close()
                if "locked" not in str(e).lower() and "busy" not in str(e).lower() or time.monotonic() > deadline:
                    raise
                time.sleep(delay)
                delay = min(delay * 2, 1.0)

    def _db_init(self) -> None:
        con = self._connect()
        with con:
            con.execute("CREATE TABLE IF NOT EXISTS meta(id INTEGER PRIMARY KEY, path TEXT UNIQUE NOT NULL, "
                        "mtime REAL, size INTEGER, ext TEXT, status TEXT)")
            if con.execute("PRAGMA user_version").fetchone()[0] < 2:
                # Index der Version 1.2 (Wortindex) verwerfen; die Dateien werden neu erfasst.
                con.execute("DROP TABLE IF EXISTS fts")
                con.execute("DELETE FROM meta")
                con.execute("PRAGMA user_version=2")
            contentless = "content='', contentless_delete=1, " if sqlite3.sqlite_version_info >= (3, 43, 0) else ""
            # Trigramm-Index auf der Suchform: findet jeden Wortteil, Schreibweisen sind vereinheitlicht.
            con.execute("CREATE VIRTUAL TABLE IF NOT EXISTS fts2 USING fts5(name, content, "
                        + contentless + "tokenize='trigram')")
            con.execute("CREATE TABLE IF NOT EXISTS txt(id INTEGER PRIMARY KEY, z BLOB)")
        con.close()

    @staticmethod
    def _idx_blank() -> dict:
        return {"running": False, "phase": "", "total": 0, "changed": 0, "done": 0, "current": "",
                "removed": 0, "skipped": {}, "started": 0, "finished": 0, "error": ""}

    def api_index_status(self) -> dict:
        s = dict(self.idx)
        try:
            con = self._connect()
            s["files"] = con.execute("SELECT count(*) FROM meta WHERE status='ok'").fetchone()[0]
            s["skipped_db"] = dict(con.execute(
                "SELECT status, count(*) FROM meta WHERE status!='ok' GROUP BY status").fetchall())
            con.close()
            s["db_bytes"] = os.path.getsize(self._db_path())
        except (sqlite3.Error, OSError):
            s["files"] = 0
            s["skipped_db"] = {}
            s["db_bytes"] = 0
        s["roots"] = list(self.cfg.get("roots", []))
        s["has_pdftotext"] = bool(self.pdftotext)
        s["has_soffice"] = bool(self.soffice)
        return s

    def api_index_start(self, full: bool = False) -> dict:
        with self._idx_lock:
            if self._idx_thread and self._idx_thread.is_alive():
                return {"started": False, "reason": "läuft bereits"}
            roots = [r for r in self.cfg.get("roots", []) if os.path.isdir(r)]
            self._idx_stop.clear()
            self.idx = self._idx_blank()
            self.idx.update(running=True, phase="scan", started=time.time())
            self._idx_thread = threading.Thread(target=self._index_run, args=(roots, bool(full)), daemon=True)
            self._idx_thread.start()
        return {"started": True}

    def api_index_stop(self) -> dict:
        self._idx_stop.set()
        return {"ok": True}

    def api_index_clear(self) -> dict:
        self._idx_stop.set()
        t = self._idx_thread
        if t and t.is_alive():
            t.join(timeout=30)
        con = self._connect()
        with con:
            con.execute("DELETE FROM fts2")
            con.execute("DELETE FROM txt")
            con.execute("DELETE FROM meta")
        con.execute("VACUUM")
        con.close()
        self.idx = self._idx_blank()
        return self.api_index_status()

    def _emit_idx(self, force: bool = False) -> None:
        now = time.time()
        if force or now - getattr(self, "_last_emit", 0) > 0.25:
            self._last_emit = now
            self.emit("index", dict(self.idx))

    def shutdown(self) -> None:
        try:
            self._term_close_all()
        except Exception:  # noqa: BLE001
            pass
        self._idx_stop.set()
        t = self._idx_thread
        if t and t.is_alive():
            t.join(timeout=10)

    def _index_run(self, roots: list[str], full: bool) -> None:
        try:
            exts = set(self.cfg.get("index_exts") or DEFAULT_EXTS)
            hidden = bool(self.cfg.get("index_hidden"))
            max_bytes = int(self.cfg.get("max_file_mb", 20)) * 1024 * 1024
            con = self._connect()
            known = {p: (i, m, s) for i, p, m, s in con.execute("SELECT id, path, mtime, size FROM meta")}
            seen: set[str] = set()
            cand: list[tuple[str, float, int, str]] = []
            for root in roots:
                for dirpath, dirnames, files in os.walk(root, followlinks=False):
                    if self._idx_stop.is_set():
                        break
                    dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and (hidden or not d.startswith("."))]
                    for fn in files:
                        if not hidden and fn.startswith("."):
                            continue
                        ext = os.path.splitext(fn)[1][1:].lower()
                        if ext not in exts and not (ext == "" and "" in exts):
                            if not (ext == "" and "txt" in exts):
                                continue
                        fp = os.path.join(dirpath, fn)
                        try:
                            st = os.stat(fp)
                        except OSError:
                            continue
                        if not stat_isreg(st):
                            continue
                        seen.add(fp)
                        cand.append((fp, st.st_mtime, st.st_size, ext))
                    self.idx["total"] = len(cand)
                    self.idx["current"] = dirpath
                    self._emit_idx()
            todo = [c for c in cand if full or c[0] not in known or known[c[0]][1] != c[1] or known[c[0]][2] != c[2]]
            self.idx.update(phase="index", total=len(cand), changed=len(todo), done=0)
            self._emit_idx(True)
            # Gelöschte oder nicht mehr erfasste Dateien entfernen
            gone = [p for p in known if p not in seen]
            with con:
                for p in gone:
                    con.execute("DELETE FROM fts2 WHERE rowid=?", (known[p][0],))
                    con.execute("DELETE FROM txt WHERE id=?", (known[p][0],))
                    con.execute("DELETE FROM meta WHERE id=?", (known[p][0],))
            self.idx["removed"] = len(gone)
            pending = 0
            skipped: dict[str, int] = {}
            for fp, mtime, size, ext in todo:
                if self._idx_stop.is_set():
                    break
                self.idx["current"] = fp
                if ext in LEGACY_EXTS:
                    text, status = legacy_text(fp, ext, self.soffice, max_bytes)
                else:
                    text, status = extract_text(fp, ext, max_bytes, self.pdftotext)
                name = os.path.basename(fp)
                if fp in known:
                    rid = known[fp][0]
                    con.execute("DELETE FROM fts2 WHERE rowid=?", (rid,))
                    con.execute("DELETE FROM txt WHERE id=?", (rid,))
                    con.execute("UPDATE meta SET mtime=?, size=?, ext=?, status=? WHERE id=?",
                                (mtime, size, ext, status, rid))
                else:
                    cur = con.execute("INSERT INTO meta(path, mtime, size, ext, status) VALUES (?,?,?,?,?)",
                                      (fp, mtime, size, ext, status))
                    rid = cur.lastrowid
                if text is not None:
                    shown = prep_text(text, dehyphen=(ext == "pdf"))
                    con.execute("INSERT INTO fts2(rowid, name, content) VALUES (?,?,?)",
                                (rid, canon(unicodedata.normalize("NFKC", name)), canon(shown)))
                    con.execute("INSERT INTO txt(id, z) VALUES (?,?)", (rid, zlib.compress(shown.encode("utf-8", "replace"), 3)))
                else:
                    skipped[status] = skipped.get(status, 0) + 1
                pending += 1
                self.idx["done"] += 1
                self.idx["skipped"] = skipped
                if pending >= 100:
                    con.commit()
                    pending = 0
                self._emit_idx()
            con.commit()
            con.execute("PRAGMA wal_checkpoint(PASSIVE)")
            con.close()
            self.idx["phase"] = "stopped" if self._idx_stop.is_set() else "done"
        except Exception as e:  # noqa: BLE001 - Indexfehler dürfen die Oberfläche nie lahmlegen
            self.idx["error"] = f"{type(e).__name__}: {e}"
            self.idx["phase"] = "error"
        finally:
            self.idx["running"] = False
            self.idx["finished"] = time.time()
            self._emit_idx(True)

    # ---- Volltextsuche
    @staticmethod
    def _parse_query(q: str) -> tuple[list[dict], list[dict]]:
        """Zerlegt die Eingabe in Suchbegriffe. Gibt (positiv, negativ) zurück; jeder Begriff trägt seine Schreibweisen.
        Anführungszeichen bilden Wortfolgen, OR trennt Alternativen, ein Minus davor schließt aus."""
        pos: list[dict] = []
        neg: list[dict] = []
        pending_or = False
        for m in re.finditer(r'(-?)"([^"]+)"|(-?)(\S+)', q or ""):
            neg_flag = bool(m.group(1) or m.group(3))
            raw = m.group(2) if m.group(2) is not None else m.group(4)
            phrase = m.group(2) is not None
            if not phrase and raw in ("OR", "AND"):
                pending_or = raw == "OR" and bool(pos)
                continue
            clean = re.sub(r'["*^(){}\[\]]', " ", raw).strip()
            clean = re.sub(r"\s+", " ", clean)
            if not re.search(r"\w", clean):
                continue
            t = {"text": clean, "vars": spelling_variants(clean), "or": False}
            if neg_flag:
                neg.append(t)
            else:
                t["or"] = pending_or and bool(pos)
                pos.append(t)
                pending_or = False
        if not pos:
            raise AppError("Bitte mindestens einen Suchbegriff eingeben (ein Minuszeichen oder ein Operator allein reicht nicht).")
        return pos, neg

    @staticmethod
    def _fts_expr(t: dict) -> str | None:
        vs = [v for v in t["vars"] if len(v) >= 3]
        if not vs:
            return None
        return "(" + " OR ".join('"%s"' % v.replace('"', '""') for v in vs) + ")"

    def _doc_text(self, con: sqlite3.Connection, rid: int) -> str:
        row = con.execute("SELECT z FROM txt WHERE id=?", (rid,)).fetchone()
        if not row:
            return ""
        try:
            return zlib.decompress(row[0]).decode("utf-8", "replace")
        except (zlib.error, TypeError):
            return ""

    @staticmethod
    def _snippets(shown: str, cn: str, terms: list[dict], width: int = 110, maxn: int = 3) -> str:
        """Bis zu drei Ausschnitte mit Markierung (\\x01 ... \\x02) aus dem Originaltext."""
        spans: list[tuple[int, int]] = []
        for t in terms:
            for v in t["vars"]:
                j = 0
                for _ in range(40):
                    k = cn.find(v, j)
                    if k < 0:
                        break
                    spans.append((k, k + len(v)))
                    j = k + len(v)
        if not spans:
            return ""
        spans.sort()
        merged: list[list[int]] = []
        for a, b in spans:
            if merged and a < merged[-1][1]:
                merged[-1][1] = max(merged[-1][1], b)
            else:
                merged.append([a, b])
        wins: list[tuple[int, int]] = []
        for a, b in merged:
            if not wins or a - wins[-1][1] > width * 2:
                if len(wins) >= maxn:
                    break
                wins.append((a, b))
            else:
                wins[-1] = (wins[-1][0], b)
        out = []
        for a, b in wins:
            lo, hi = max(0, a - width), min(len(shown), b + width)
            seg, last = [], lo
            for x, y in merged:
                if y <= lo or x >= hi:
                    continue
                x, y = max(x, lo), min(y, hi)
                seg.append(shown[last:x] + "\x01" + shown[x:y] + "\x02")
                last = y
            seg.append(shown[last:hi])
            out.append(("… " if lo else "") + "".join(seg) + (" …" if hi < len(shown) else ""))
        return "\n".join(out)

    def api_search_folders(self, query: str, scopes: list[str] | None = None, limit: int = 60, max_seconds: float = 2.5) -> dict:
        """Ordnernamen, die zur Suchanfrage passen (gleiche Schreibweise der Anfrage wie bei der Volltextsuche:
        mehrere Wörter müssen alle im Ordnernamen vorkommen, OR trennt Alternativen, ein Minus schließt aus)."""
        t0 = time.time()
        pos, neg = self._parse_query(query)
        roots = [norm_path(x) for x in (scopes or []) if x] or [r for r in self.cfg.get("roots", [])]
        roots = [r for r in dict.fromkeys(roots) if os.path.isdir(r)]
        if not roots:
            return {"results": [], "truncated": False, "seconds": 0.0}
        groups: list[list[str]] = []           # jede Gruppe: alle Wörter müssen passen; Gruppen sind Alternativen
        for t in pos:
            if t["or"] and groups:
                groups.append([t["text"]])
            elif groups:
                groups[-1].append(t["text"])
            else:
                groups.append([t["text"]])
        nvars = [[fold(v) for v in t["vars"]] + [fold(t["text"])] for t in neg]
        results: dict[str, dict] = {}
        truncated = False
        per = max(0.4, max_seconds / max(1, len(roots) * len(groups)))
        for root in roots[:8]:
            for g in groups:
                if time.time() - t0 > max_seconds or self._cancelled():
                    truncated = True
                    break
                q = " ".join('"%s"' % w.replace('"', "") if " " in w else w for w in g)
                try:
                    r = self.api_search_names(q, root, kind="dir", limit=limit, max_seconds=per)
                except AppError:
                    continue
                truncated = truncated or r.get("truncated", False)
                for e in r["results"]:
                    nm = fold(e["name"])
                    if any(any(v and v in nm for v in vs) for vs in nvars):
                        continue
                    results.setdefault(e["path"], {"path": e["path"], "name": e["name"], "dir": os.path.dirname(e["path"]), "mtime": e.get("mtime", 0)})
        first = fold(pos[0]["text"])
        out = sorted(results.values(), key=lambda e: (not fold(e["name"]).startswith(first), e["path"].count("/"), fold(e["name"])))
        more = len(out) > limit
        return {"results": out[:limit], "truncated": more or truncated, "seconds": round(time.time() - t0, 2)}

    def api_search_text(self, query: str, scopes: list[str] | None = None, part: bool | None = None,
                        exts: list[str] | None = None, limit: int = 200, words: bool = False) -> dict:
        """Volltextsuche. Findet jeden Wortteil (Grundschulleitung über 'schule'), gleicht Schreibweisen ab
        (Straße/Strasse, Müller/Mueller, Köln/Koeln) und ordnet Treffer an Wortanfängen vor. words=True zeigt nur diese."""
        t0 = time.time()
        if part is False:
            words = True
        limit = max(1, min(2000, int(limit)))
        scopes = [norm_path(s) for s in (scopes or []) if s]
        exts = [e.lower().lstrip(".") for e in (exts or [])]
        pos, neg = self._parse_query(query)
        long_pos = [(t, self._fts_expr(t)) for t in pos]
        short_pos = [t for t, e in long_pos if e is None]
        long_pos = [(t, e) for t, e in long_pos if e is not None]
        match = ""
        if long_pos:
            match = long_pos[0][1]
            for t, e in long_pos[1:]:
                match += (" OR " if t["or"] else " AND ") + e
            negs = [e for e in (self._fts_expr(t) for t in neg) if e]
            if negs:
                match = "(" + match + ") NOT (" + " OR ".join(negs) + ")"
        short_neg = [t for t in neg if self._fts_expr(t) is None]
        where, params = [], []
        if scopes:
            ors = []
            for sc in scopes:
                w, pr = path_prefix_sql(sc)
                ors.append(w)
                params += pr
            where.append("(" + " OR ".join(ors) + ")")
        if exts:
            where.append("m.ext IN (%s)" % ",".join("?" * len(exts)))
            params += exts
        wsql = (" AND " + " AND ".join(where)) if where else ""
        con = self._connect()
        cancelled = False
        con.set_progress_handler(lambda: 1 if self._cancelled() else 0, 20000)
        hits: list[dict] = []
        more = False
        try:
            if match:
                sql = ("SELECT m.id, m.path, m.size, m.mtime, m.ext, bm25(fts2, 4.0, 1.0) AS r "
                       "FROM fts2 JOIN meta m ON m.id = fts2.rowid WHERE fts2 MATCH ?" + wsql +
                       " ORDER BY r LIMIT ?")
                args = [match] + params + [min(8000, limit * 4 + 40)]
            else:
                if not short_pos:
                    raise AppError("Bitte mindestens einen Suchbegriff eingeben.")
                sql = ("SELECT m.id, m.path, m.size, m.mtime, m.ext, 0.0 AS r FROM meta m "
                       "WHERE m.status='ok'" + wsql + " LIMIT ?")
                args = params + [20000]
            try:
                rows = con.execute(sql, args).fetchall()
            except sqlite3.OperationalError as e:
                if "interrupt" in str(e).lower():
                    return {"results": [], "truncated": False, "cancelled": True, "seconds": round(time.time() - t0, 2)}
                raise AppError("Suchausdruck nicht verständlich: " + str(e))
            ok_terms = pos
            for i, (rid, path, size, mtime, ext, r) in enumerate(rows):
                if i % 25 == 0 and self._cancelled():
                    cancelled = True
                    break
                name = os.path.basename(path)
                shown = self._doc_text(con, rid)
                cn, cname = canon(shown), canon(unicodedata.normalize("NFKC", name))
                hay = cname + " " + cn

                def has(t):
                    return any(v in hay for v in t["vars"])

                def has_word(t):
                    return any(re.search(r"(?<!\w)" + re.escape(v), hay) for v in t["vars"])
                if short_pos and not all(has(t) for t in short_pos):
                    continue
                if short_neg and any(has(t) for t in short_neg):
                    continue
                if match and not all(has(t) for t, e in long_pos if not t["or"]) and not any(has(t) for t, e in long_pos):
                    continue
                tier = 1 if all(has_word(t) for t in ok_terms if not t["or"]) and any(has_word(t) for t in ok_terms) else 0
                if words and not tier:
                    continue
                hits.append({"path": path, "size": size, "mtime": mtime, "ext": ext, "r": r, "tier": tier,
                             "snippet": self._snippets(shown, cn, ok_terms)})
                if len(hits) >= limit * 2 + 20:
                    more = True
                    break
        finally:
            con.set_progress_handler(None, 0)
            con.close()
        hits.sort(key=lambda h: (-h["tier"], h["r"]))
        more = more or len(hits) > limit
        hits = hits[:limit]
        out = []
        for h in hits:
            if not os.path.exists(h["path"]):
                continue
            h["name"] = os.path.basename(h["path"])
            h["dir"] = os.path.dirname(h["path"])
            h["snippet"] = re.sub(r"[\x00\x03-\x08\x0b-\x1f]", "", h["snippet"] or "")
            h.pop("r", None)
            out.append(h)
        return {"results": out, "truncated": more, "cancelled": cancelled, "seconds": round(time.time() - t0, 2)}


def stat_isdir(st: os.stat_result) -> bool:
    import stat as _s
    return _s.S_ISDIR(st.st_mode)


def stat_isreg(st: os.stat_result) -> bool:
    import stat as _s
    return _s.S_ISREG(st.st_mode)
