"""Farbdesign umstellen: dieselbe Wirkung wie "seiffert design" (Nachricht an Seifferts Dateien, config.json, Oberfläche)."""
from __future__ import annotations

import json
import os
import socket
import tempfile

from . import skins

CONFIG_MSG = "\x1dconfig"


def _uid() -> str:
    return str(os.getuid()) if hasattr(os, "getuid") else "user"


def _send(sock_name: str, payload: str, timeout: float = 0.4) -> bool:
    path = os.path.join(os.environ.get("TMPDIR") or tempfile.gettempdir(), sock_name)
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as c:
            c.settimeout(timeout)
            c.connect(path)
            c.sendall(payload.encode("utf-8"))
            c.shutdown(socket.SHUT_WR)
            try:
                c.recv(16)
            except OSError:
                pass
        return True
    except OSError:
        return False


def _patch_file(patch: dict) -> None:
    d = skins.config_dir()
    f = d / "config.json"
    try:
        cfg = json.loads(f.read_text(encoding="utf-8"))
        if not isinstance(cfg, dict):
            cfg = {}
    except (OSError, ValueError):
        cfg = {}
    cfg.update(patch)
    d.mkdir(parents=True, exist_ok=True)
    tmp = f.with_name(f.name + ".tmp-zentrale")
    tmp.write_text(json.dumps(cfg, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, f)


def set_design(skin: str | None = None, theme: str | None = None) -> None:
    patch = {}
    if skin is not None:
        if skin not in skins.SKINS:
            raise ValueError("Unbekanntes Farbdesign: %s" % skin)
        patch["skin"] = skin
    if theme is not None:
        if theme not in skins.THEMES:
            raise ValueError("Unbekannte Darstellung: %s" % theme)
        patch["theme"] = theme
    if not patch:
        return
    _send("seiffert-dateien-%s" % _uid(), CONFIG_MSG + "\x1f" + json.dumps(patch))   # läuft Seifferts Dateien, übernimmt es sofort
    _patch_file(patch)                                                                # und die Datei gilt für alle anderen
    _send("seiffert-oberflaeche-%s" % _uid(), "reload")
