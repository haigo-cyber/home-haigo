#!/usr/bin/env python3
"""Prüft den Abschnitt Theme im Einstellungsdialog mit der echten Oberfläche (QtWebEngine): Klicks stellen sofort um und speichern.
Aufruf (braucht einen Bildschirm, zum Beispiel xvfb-run):  python tests/test_theme_dialog.py [BILDDATEI]"""
import json
import os
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HOME = tempfile.mkdtemp(prefix="sd-theme-home-")
os.environ.update(HOME=HOME, XDG_CONFIG_HOME=HOME + "/.config", XDG_DATA_HOME=HOME + "/.local/share", XDG_CACHE_HOME=HOME + "/.cache",
                  TMPDIR=HOME, QTWEBENGINE_CHROMIUM_FLAGS="--no-sandbox --disable-gpu", QTWEBENGINE_DISABLE_SANDBOX="1")
sys.path.insert(0, HERE)
import app as A  # noqa: E402
import backend as B  # noqa: E402
from PySide6.QtWidgets import QApplication  # noqa: E402

qapp = QApplication(["test"])
backend = B.Backend()
win = A.MainWindow(backend)
win.resize(1200, 780)
win.show()
PASS = FAIL = 0


def check(name, cond, info=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        print("FEHLER: %s %s" % (name, info))


def js(code, secs=10.0):
    box = []
    win.page.runJavaScript(code, lambda v: box.append(v))
    end = time.time() + secs
    while not box and time.time() < end:
        qapp.processEvents()
        time.sleep(0.01)
    return box[0] if box else None


def pump(secs):
    end = time.time() + secs
    while time.time() < end:
        qapp.processEvents()
        time.sleep(0.01)


def until(code, secs=8.0):
    end = time.time() + secs
    while time.time() < end:
        if js(code):
            return True
        pump(0.1)
    return False


def cfg():
    return json.load(open(os.path.join(HOME, ".config", "seiffert-dateien", "config.json"), encoding="utf-8"))


check("Seite geladen", until("!!(window.SD_READY && window.sdCommand)", 40))
js("window.sdCommand('settings'); true")
check("Dialog mit Theme-Abschnitt", until("!!document.querySelector('#stskins [data-skin]')"))
check("Theme steht ganz oben", js("document.querySelector('.ovl .sect').textContent") == "Theme")
pump(0.5)
check("Dialog öffnet oben, Theme ist sichtbar", js("(() => { const r = document.querySelector('#stlook').getBoundingClientRect(); const o = document.querySelector('#stskins').closest('.ovl'); "
      "return r.top > 0 && r.bottom < innerHeight && document.activeElement.closest('#stskins') !== null; })()") is True)
if len(sys.argv) > 2:
    win.grab().save(sys.argv[2])
check("sieben Farbdesigns, drei Darstellungen, vier Starter-Looks",
      js("[document.querySelectorAll('#stskins [data-skin]').length, document.querySelectorAll('#stmode [data-th]').length, document.querySelectorAll('#stlook [data-look]').length].join()") == "7,3,4")
check("altes Auswahlfeld Design entfernt", js("document.querySelector('#sth') === null") is True)
check("Anfang: Petrol gewählt", js("document.querySelector('#stskins [aria-checked=true]').dataset.skin") == "petrol")

js("document.querySelector('#stskins [data-skin=beere]').click(); true")
check("Farbdesign sofort angewendet", until("document.documentElement.dataset.skin === 'beere'"))
check("Farbdesign gespeichert", cfg()["skin"] == "beere", str(cfg().get("skin")))
check("Markierung folgt", js("document.querySelector('#stskins [aria-checked=true]').dataset.skin") == "beere")
check("Meldung", js("document.querySelector('#stmsg').textContent") == "Farbdesign: Beere.")
check("Fokus bleibt auf dem gewählten Farbdesign", js("document.activeElement.dataset.skin") == "beere")

js("document.querySelector('#stmode [data-th=dark]').click(); true")
check("Dunkel sofort angewendet", until("document.documentElement.dataset.theme === 'dark'"))
check("Akzentfarbe ist die dunkle von Beere", js("getComputedStyle(document.documentElement).getPropertyValue('--accent').trim()") == "#e69ac3")
js("document.querySelector('#stmode [data-th=light]').click(); true")
check("Hell sofort angewendet", until("document.documentElement.dataset.theme === 'light'") and cfg()["theme"] == "light")

js("document.querySelector('#stlook [data-look=aurora]').click(); true")
check("Starter-Look gespeichert", until("document.querySelector('#stlook [aria-checked=true]').dataset.look === 'aurora'") and cfg()["starter"]["look"] == "aurora", str(cfg().get("starter")))
check("übrige Starter-Einstellungen bleiben", cfg()["starter"]["src_cmds"] is True and cfg()["starter"]["bubbles"] == 16)

if len(sys.argv) > 1:
    pump(0.6)
    win.grab().save(sys.argv[1])
# Abbrechen nimmt die Wahl nicht zurück
js("[...document.querySelectorAll('.ovl button')].find(b => b.textContent.trim() === 'Abbrechen').click(); true")
pump(0.4)
check("nach Abbrechen bleibt das Theme", js("document.documentElement.dataset.skin + '|' + document.documentElement.dataset.theme") == "beere|light" and cfg()["skin"] == "beere")
# Speichern im Dialog darf die Darstellung nicht mehr überschreiben
js("window.sdCommand('settings'); true")
until("!!document.querySelector('#stmode [data-th]')")
js("document.querySelector('#stmode [data-th=dark]').click(); true")
until("document.documentElement.dataset.theme === 'dark'")
js("document.querySelector('#smax').value = 25; [...document.querySelectorAll('.ovl button')].find(b => b.textContent.trim().startsWith('Speichern')).click(); true")
pump(1.5)
c = cfg()
check("Speichern behält Theme und übernimmt den Rest", c["theme"] == "dark" and c["skin"] == "beere" and c["max_file_mb"] == 25, "%s %s %s" % (c["theme"], c["skin"], c["max_file_mb"]))

# ---- Starter-Design Schreibtisch: Schnellwahl im Theme-Abschnitt
js("window.sdCommand('settings'); true")
until("!!document.querySelector('#stdesign [data-sdesign]')")
check("Starter-Design (2) und Farbschemata (4) angeboten", js("[document.querySelectorAll('#stdesign [data-sdesign]').length, document.querySelectorAll('#stdsch [data-dsch]').length].join()") == "2,4")
check("Anfang: Schreibtisch und Dunkel", js("document.querySelector('#stdesign [aria-checked=true]').dataset.sdesign + document.querySelector('#stdsch [aria-checked=true]').dataset.dsch") == "deskdunkel")
js("document.querySelector('#stdesign [data-sdesign=wolke]').click(); true")
until("document.querySelector('#stdesign [aria-checked=true]').dataset.sdesign === 'wolke'")
js("document.querySelector('#stdesign [data-sdesign=desk]').click(); true")
check("Schreibtisch gespeichert", until("document.querySelector('#stdesign [aria-checked=true]').dataset.sdesign === 'desk'") and cfg()["starter"]["design"] == "desk", str(cfg().get("starter")))
js("document.querySelector('#stdsch [data-dsch=neon]').click(); true")
check("Neon gespeichert", until("document.querySelector('#stdsch [aria-checked=true]').dataset.dsch === 'neon'") and cfg()["starter"]["desk_scheme"] == "neon")
check("Wolke-Look blieb", cfg()["starter"]["look"] == "aurora")
js("[...document.querySelectorAll('.ovl button')].find(b => b.textContent.trim() === 'Abbrechen').click(); true")
pump(0.4)

# ---- Dialog Starter einrichten: Abschnitt Schreibtisch
js("window.sdCommand('settings:starter'); true")
check("Dialog Starter mit Schreibtisch-Feldern", until("!!document.querySelector('#sdbtn') && !!document.querySelector('#sdbg')", 20))
check("Felder zeigen die gespeicherten Werte", js("[document.querySelector('#sdesign').value, document.querySelector('#sdsch').value, document.querySelector('#sdfull').checked, document.querySelector('#sdbtn').value, document.querySelector('#sdside').value].join()") == "desk,neon,true,64,left")
js("document.querySelector('#sdbtn').value = 10; [...document.querySelectorAll('.ovl button')].find(b => b.textContent.trim() === 'Speichern').click(); true")
pump(1.0)
check("zu kleine Knopfgröße wird abgelehnt, nichts gespeichert", cfg()["starter"]["desk_btn"] == 64 and js("!!document.querySelector('#sdbtn')") is True, str(cfg()["starter"].get("desk_btn")))
js("document.querySelector('#sdbtn').value = 80; document.querySelector('#sdsch').value = 'metall'; document.querySelector('#sdfull').checked = false; document.querySelector('#sdbg').value = 'farbe'; "
   "document.querySelector('#sdcol').value = '#203040'; document.querySelector('#sddim').value = 50; document.querySelector('#sdside').value = 'right'; true")
if len(sys.argv) > 3:
    js("document.querySelector('#sdbtn').scrollIntoView(); true")
    pump(0.5)
    win.grab().save(sys.argv[3])
js("[...document.querySelectorAll('.ovl button')].find(b => b.textContent.trim() === 'Speichern').click(); true")
pump(1.5)
st = cfg()["starter"]
check("Schreibtisch-Einstellungen gespeichert", (st["desk_btn"], st["desk_scheme"], st["desk_full"], st["desk_bg"], st["desk_bg_color"], st["desk_bg_dim"], st["desk_side"]) == (80, "metall", False, "farbe", "#203040", 50, "right"), str(st))
check("Starter-Design blieb Schreibtisch", st["design"] == "desk")
js("window.sdCommand('settings:starter'); true")
until("!!document.querySelector('#sdbtn')", 20)
js("document.querySelector('#sdbg').value = 'bild'; document.querySelector('#sdimg').value = ''; [...document.querySelectorAll('.ovl button')].find(b => b.textContent.trim() === 'Speichern').click(); true")
pump(1.0)
check("Bild ohne Datei wird abgelehnt", cfg()["starter"]["desk_bg"] == "farbe")
print("%d Prüfungen bestanden, %d fehlgeschlagen" % (PASS, FAIL))
backend.shutdown()
os._exit(1 if FAIL else 0)
