"""Feldebene für das PDF-Fenster: Formularfelder markieren, verschieben, in der Größe ändern, ausrichten.

Die Ebene liegt über der Seitenanzeige. Alle Maße sind PDF-Punkte der angezeigten (ggf. gedrehten) Seite.
Die reine Geometrie (Einrasten, Ausrichten, Größe ändern) steht in Funktionen ohne Oberfläche, damit sie sich testen lässt.
"""
from PySide6.QtCore import Qt, QPointF, QRectF, Signal
from PySide6.QtGui import QColor, QPainter, QPen, QBrush, QFont
from PySide6.QtWidgets import QWidget, QMenu

MIN_SIZE = 3.0
HANDLES = ((-1, -1), (0, -1), (1, -1), (1, 0), (1, 1), (0, 1), (-1, 1), (-1, 0))
CURSORS = {(-1, -1): Qt.CursorShape.SizeFDiagCursor, (1, 1): Qt.CursorShape.SizeFDiagCursor,
           (1, -1): Qt.CursorShape.SizeBDiagCursor, (-1, 1): Qt.CursorShape.SizeBDiagCursor,
           (0, -1): Qt.CursorShape.SizeVerCursor, (0, 1): Qt.CursorShape.SizeVerCursor,
           (-1, 0): Qt.CursorShape.SizeHorCursor, (1, 0): Qt.CursorShape.SizeHorCursor}
KIND_COLORS = {"text": (91, 141, 217), "check": (90, 170, 90), "radio": (170, 110, 200), "combo": (225, 150, 50),
               "list": (225, 150, 50), "button": (150, 150, 150), "signature": (150, 150, 150), "other": (150, 150, 150)}
DEFAULT_SIZE = {"text": (150.0, 20.0), "multiline": (200.0, 60.0), "check": (14.0, 14.0), "combo": (150.0, 20.0)}


# ---------------------------------------------------------------- Geometrie ohne Oberfläche
def bbox(rects):
    return (min(r[0] for r in rects), min(r[1] for r in rects), max(r[2] for r in rects), max(r[3] for r in rects))


def best_snap(values, targets, thr):
    """Kleinste Verschiebung (Ziel minus Wert) von höchstens thr, sonst None."""
    best = None
    for v in values:
        for t in targets:
            d = t - v
            if abs(d) <= thr and (best is None or abs(d) < abs(best)):
                best = d
    return best


def lines_of(rects):
    xs, ys = [], []
    for r in rects:
        xs += [r[0], (r[0] + r[2]) / 2.0, r[2]]
        ys += [r[1], (r[1] + r[3]) / 2.0, r[3]]
    return xs, ys


def move_rects(rects, dx, dy, others, thr, page_size=None, snap=True, axis_lock=False):
    """Alle rects um (dx, dy) verschieben. Die Umrisse rasten an Kanten und Mitten der übrigen Felder ein.
    Liefert (neue Rechtecke, senkrechte Hilfslinien x, waagerechte Hilfslinien y)."""
    if axis_lock:
        if abs(dx) >= abs(dy):
            dy = 0.0
        else:
            dx = 0.0
    bx0, by0, bx1, by1 = bbox(rects)
    gx, gy = [], []
    if snap and others:
        tx, ty = lines_of(others)
        sx = best_snap([bx0 + dx, (bx0 + bx1) / 2.0 + dx, bx1 + dx], tx, thr) if dx or not axis_lock else None
        sy = best_snap([by0 + dy, (by0 + by1) / 2.0 + dy, by1 + dy], ty, thr) if dy or not axis_lock else None
        if sx is not None and not (axis_lock and dx == 0):
            dx += sx
            gx = [x for x in tx if min(abs(x - (bx0 + dx)), abs(x - (bx1 + dx)),
                                        abs(x - (bx0 + bx1) / 2.0 - dx)) < 0.01]
        if sy is not None and not (axis_lock and dy == 0):
            dy += sy
            gy = [y for y in ty if min(abs(y - (by0 + dy)), abs(y - (by1 + dy)),
                                        abs(y - (by0 + by1) / 2.0 - dy)) < 0.01]
    if page_size:
        pw, ph = page_size
        dx = max(-bx0, min(pw - bx1, dx))
        dy = max(-by0, min(ph - by1, dy))
    return [(r[0] + dx, r[1] + dy, r[2] + dx, r[3] + dy) for r in rects], gx, gy


def resize_rect(r, handle, dx, dy, others=(), thr=0.0, page_size=None, snap=True, keep_ratio=False):
    """Rechteck r am Griff handle (hx, hy) um (dx, dy) ziehen. Die bewegten Kanten rasten an den übrigen Feldern ein."""
    hx, hy = handle
    x0, y0, x1, y1 = r
    gx, gy = [], []
    if snap and others:
        tx, ty = lines_of(others)
        if hx:
            s = best_snap([(x1 if hx > 0 else x0) + dx], tx, thr)
            if s is not None:
                dx += s
                gx = [(x1 if hx > 0 else x0) + dx]
        if hy:
            s = best_snap([(y1 if hy > 0 else y0) + dy], ty, thr)
            if s is not None:
                dy += s
                gy = [(y1 if hy > 0 else y0) + dy]
    if keep_ratio and hx and hy and (x1 - x0) > 0 and (y1 - y0) > 0:
        ratio = (x1 - x0) / (y1 - y0)
        w = (x1 - x0) + hx * dx
        h = (y1 - y0) + hy * dy
        if w / ratio >= h:
            h = w / ratio
        else:
            w = h * ratio
        dx, dy = hx * (w - (x1 - x0)), hy * (h - (y1 - y0))
    if hx < 0:
        x0 = min(x0 + dx, x1 - MIN_SIZE)
    elif hx > 0:
        x1 = max(x1 + dx, x0 + MIN_SIZE)
    if hy < 0:
        y0 = min(y0 + dy, y1 - MIN_SIZE)
    elif hy > 0:
        y1 = max(y1 + dy, y0 + MIN_SIZE)
    if page_size:
        pw, ph = page_size
        x0, x1 = max(0.0, x0), min(pw, x1)
        y0, y1 = max(0.0, y0), min(ph, y1)
    return (x0, y0, x1, y1), gx, gy


def align_rects(rects, op):
    """rects: Liste in Auswahlreihenfolge (das zuerst markierte Feld gibt bei 'gleich' das Maß vor).
    Liefert die neuen Rechtecke in derselben Reihenfolge."""
    n = len(rects)
    if n < 2:
        return list(rects)
    bx0, by0, bx1, by1 = bbox(rects)
    out = []
    ref = rects[0]
    rw, rh = ref[2] - ref[0], ref[3] - ref[1]
    for r in rects:
        w, h = r[2] - r[0], r[3] - r[1]
        if op == "left":
            out.append((bx0, r[1], bx0 + w, r[3]))
        elif op == "right":
            out.append((bx1 - w, r[1], bx1, r[3]))
        elif op == "top":
            out.append((r[0], by0, r[2], by0 + h))
        elif op == "bottom":
            out.append((r[0], by1 - h, r[2], by1))
        elif op == "hcenter":
            c = (bx0 + bx1) / 2.0
            out.append((c - w / 2.0, r[1], c + w / 2.0, r[3]))
        elif op == "vcenter":
            c = (by0 + by1) / 2.0
            out.append((r[0], c - h / 2.0, r[2], c + h / 2.0))
        elif op == "same_w":
            out.append((r[0], r[1], r[0] + rw, r[3]))
        elif op == "same_h":
            out.append((r[0], r[1], r[2], r[1] + rh))
        elif op == "same_size":
            out.append((r[0], r[1], r[0] + rw, r[1] + rh))
        else:
            out.append(tuple(r))
    if op in ("dist_h", "dist_v") and n >= 3:
        out = [tuple(r) for r in rects]
        k = 0 if op == "dist_h" else 1
        order = sorted(range(n), key=lambda i: rects[i][k])
        first, last = rects[order[0]], rects[order[-1]]
        total = (last[k + 2] - first[k]) - sum(rects[i][k + 2] - rects[i][k] for i in order)
        gap = total / (n - 1)
        pos = first[k]
        for i in order:
            r = rects[i]
            size = r[k + 2] - r[k]
            nr = list(r)
            nr[k], nr[k + 2] = pos, pos + size
            out[i] = tuple(nr)
            pos += size + gap
    return out


# ---------------------------------------------------------------- Oberfläche
class FieldLayer(QWidget):
    """Liegt über der Seite. Zeichnet die Felder als Rahmen und verarbeitet Maus und Tastatur."""
    selection_changed = Signal()

    def __init__(self, page, win, fields, zoom, page_size):
        super().__init__(page)
        self.win = win
        self.z = zoom
        self.page_size = page_size
        self.fields = {f["xref"]: f for f in fields}
        self.rects = {f["xref"]: tuple(f["rect"]) for f in fields}
        self.order = [f["xref"] for f in fields]
        self.sel = []                 # Auswahlreihenfolge
        self.tool = None              # "text" | "multiline" | "check" | "combo" | None
        self.drag = None
        self.guides = ([], [])
        self.setGeometry(0, 0, page.width(), page.height())
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent, False)
        self.setCursor(Qt.CursorShape.ArrowCursor)

    # ---- Hilfen
    def px(self, v):
        return v * self.z

    def pt(self, v):
        return v / self.z

    def qrect(self, r):
        return QRectF(r[0] * self.z, r[1] * self.z, (r[2] - r[0]) * self.z, (r[3] - r[1]) * self.z)

    def set_selection(self, xrefs):
        self.sel = [x for x in xrefs if x in self.rects]
        self.update()
        self.selection_changed.emit()

    def current_rects(self):
        """Rechtecke einschließlich laufender Ziehbewegung."""
        if self.drag and self.drag.get("preview"):
            r = dict(self.rects)
            r.update(self.drag["preview"])
            return r
        return self.rects

    def field_at(self, x, y):
        """Oberstes Feld an der Stelle (kleinste Fläche zuerst, damit kleine Felder in großen erreichbar bleiben)."""
        hit = [(xr, r) for xr, r in self.rects.items() if r[0] <= x <= r[2] and r[1] <= y <= r[3]]
        if not hit:
            return None
        hit.sort(key=lambda t: (t[1][2] - t[1][0]) * (t[1][3] - t[1][1]))
        return hit[0][0]

    def handle_at(self, px_x, px_y):
        if len(self.sel) != 1:
            return None
        r = self.rects[self.sel[0]]
        q = self.qrect(r)
        pts = {(-1, -1): q.topLeft(), (0, -1): QPointF(q.center().x(), q.top()), (1, -1): q.topRight(),
               (1, 0): QPointF(q.right(), q.center().y()), (1, 1): q.bottomRight(),
               (0, 1): QPointF(q.center().x(), q.bottom()), (-1, 1): q.bottomLeft(),
               (-1, 0): QPointF(q.left(), q.center().y())}
        for h, p in pts.items():
            if abs(p.x() - px_x) <= 6 and abs(p.y() - px_y) <= 6:
                return h
        return None

    # ---- Zeichnen
    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, False)
        rects = self.current_rects()
        f = QFont()
        f.setPixelSize(10)
        p.setFont(f)
        for xr in self.order:
            r = rects[xr]
            kind = self.fields[xr]["kind"]
            c = KIND_COLORS.get(kind, (150, 150, 150))
            selected = xr in self.sel
            q = self.qrect(r)
            p.setBrush(QBrush(QColor(c[0], c[1], c[2], 70 if not selected else 110)))
            p.setPen(QPen(QColor(*c), 1))
            p.drawRect(q)
            if selected:
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.setPen(QPen(QColor(255, 120, 0), 2))
                p.drawRect(q)
            if q.width() > 24:                          # Name über dem Rahmen, damit er den Feldtext nicht verdeckt
                p.setPen(QColor(60, 60, 110))
                p.drawText(QRectF(q.left(), q.top() - 12, max(q.width(), 60), 11),
                           Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignBottom,
                           self.fields[xr]["name"].split(".")[-1])
        if len(self.sel) == 1:
            q = self.qrect(rects[self.sel[0]])
            pts = [q.topLeft(), QPointF(q.center().x(), q.top()), q.topRight(), QPointF(q.right(), q.center().y()),
                   q.bottomRight(), QPointF(q.center().x(), q.bottom()), q.bottomLeft(),
                   QPointF(q.left(), q.center().y())]
            p.setBrush(QBrush(QColor(255, 255, 255)))
            p.setPen(QPen(QColor(255, 120, 0), 1))
            for pt in pts:
                p.drawRect(QRectF(pt.x() - 4, pt.y() - 4, 8, 8))
        gx, gy = self.guides
        p.setPen(QPen(QColor(230, 0, 120), 1, Qt.PenStyle.DashLine))
        for x in gx:
            p.drawLine(int(x * self.z), 0, int(x * self.z), self.height())
        for y in gy:
            p.drawLine(0, int(y * self.z), self.width(), int(y * self.z))
        d = self.drag
        if d and d.get("band") is not None:
            b = d["band"]
            p.setBrush(QBrush(QColor(255, 120, 0, 30)))
            p.setPen(QPen(QColor(255, 120, 0), 1, Qt.PenStyle.DashLine))
            p.drawRect(QRectF(min(b[0], b[2]), min(b[1], b[3]), abs(b[2] - b[0]), abs(b[3] - b[1])))
        p.end()

    # ---- Maus
    def mousePressEvent(self, e):
        self.setFocus()
        pos = e.position()
        x, y = self.pt(pos.x()), self.pt(pos.y())
        if e.button() == Qt.MouseButton.RightButton:
            xr = self.field_at(x, y)
            if xr is not None and xr not in self.sel:
                self.set_selection([xr])
            self.context_menu(e.globalPosition().toPoint())
            return
        if e.button() != Qt.MouseButton.LeftButton:
            return
        shift = bool(e.modifiers() & Qt.KeyboardModifier.ShiftModifier)
        if self.tool:
            self.drag = {"mode": "new", "start": (pos.x(), pos.y()), "band": (pos.x(), pos.y(), pos.x(), pos.y())}
            return
        h = self.handle_at(pos.x(), pos.y())
        if h is not None:
            xr = self.sel[0]
            self.drag = {"mode": "resize", "h": h, "start": (x, y), "orig": self.rects[xr], "moved": False}
            return
        xr = self.field_at(x, y)
        if xr is None:
            if not shift:
                self.set_selection([])
            self.drag = {"mode": "band", "start": (pos.x(), pos.y()), "band": (pos.x(), pos.y(), pos.x(), pos.y()),
                         "base": list(self.sel) if shift else []}
            return
        if shift:
            if xr in self.sel:
                self.set_selection([s for s in self.sel if s != xr])
            else:
                self.set_selection(self.sel + [xr])
        elif xr not in self.sel:
            self.set_selection([xr])
        if xr in self.sel:
            self.drag = {"mode": "move", "start": (x, y), "orig": {s: self.rects[s] for s in self.sel}, "moved": False}

    def mouseMoveEvent(self, e):
        pos = e.position()
        x, y = self.pt(pos.x()), self.pt(pos.y())
        d = self.drag
        if d is None:
            if self.tool:
                self.setCursor(Qt.CursorShape.CrossCursor)
                return
            h = self.handle_at(pos.x(), pos.y())
            if h is not None:
                self.setCursor(CURSORS[h])
            elif self.field_at(x, y) is not None:
                self.setCursor(Qt.CursorShape.SizeAllCursor)
            else:
                self.setCursor(Qt.CursorShape.ArrowCursor)
            return
        alt = bool(e.modifiers() & Qt.KeyboardModifier.AltModifier)
        shift = bool(e.modifiers() & Qt.KeyboardModifier.ShiftModifier)
        thr = 6.0 / self.z
        if d["mode"] in ("band", "new"):
            d["band"] = (d["start"][0], d["start"][1], pos.x(), pos.y())
            if d["mode"] == "band":
                b = d["band"]
                bx = (min(b[0], b[2]) / self.z, min(b[1], b[3]) / self.z, max(b[0], b[2]) / self.z, max(b[1], b[3]) / self.z)
                hit = [xr for xr, r in self.rects.items() if not (r[2] < bx[0] or r[0] > bx[2] or r[3] < bx[1] or r[1] > bx[3])]
                self.sel = list(d["base"]) + [h for h in hit if h not in d["base"]]
            self.update()
            return
        dx, dy = x - d["start"][0], y - d["start"][1]
        if not d["moved"] and abs(dx) * self.z < 3 and abs(dy) * self.z < 3:
            return
        d["moved"] = True
        if d["mode"] == "move":
            origs = [d["orig"][s] for s in self.sel]
            others = [r for xr, r in self.rects.items() if xr not in self.sel]
            new, gx, gy = move_rects(origs, dx, dy, others, thr, self.page_size, snap=not alt, axis_lock=shift)
            d["preview"] = {s: r for s, r in zip(self.sel, new)}
            self.guides = (gx, gy)
        else:
            xr = self.sel[0]
            others = [r for k, r in self.rects.items() if k != xr]
            nr, gx, gy = resize_rect(d["orig"], d["h"], dx, dy, others, thr, self.page_size, snap=not alt,
                                     keep_ratio=shift)
            d["preview"] = {xr: nr}
            self.guides = (gx, gy)
        self.update()

    def mouseReleaseEvent(self, e):
        d, self.drag = self.drag, None
        self.guides = ([], [])
        if d is None or e.button() != Qt.MouseButton.LeftButton:
            return
        if d["mode"] == "band":
            self.update()
            self.selection_changed.emit()
            return
        if d["mode"] == "new":
            kind, self.tool = self.tool, None
            self.setCursor(Qt.CursorShape.ArrowCursor)
            b = d["band"]
            x0, y0, x1, y1 = (min(b[0], b[2]) / self.z, min(b[1], b[3]) / self.z,
                              max(b[0], b[2]) / self.z, max(b[1], b[3]) / self.z)
            if x1 - x0 < 6 and y1 - y0 < 6:                 # nur geklickt: Standardgröße
                w, h = DEFAULT_SIZE.get(kind, (150.0, 20.0))
                x1, y1 = x0 + w, y0 + h
            self.update()
            self.win.fields_create(kind, (x0, y0, x1, y1))
            return
        if d.get("moved") and d.get("preview"):
            changes = [(xr, r) for xr, r in d["preview"].items()]
            self.win.fields_place(changes)
        else:
            self.update()
            self.selection_changed.emit()

    def mouseDoubleClickEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            pos = e.position()
            xr = self.field_at(self.pt(pos.x()), self.pt(pos.y()))
            if xr is not None:
                self.set_selection([xr])
                self.win.fields_properties()

    # ---- Tastatur
    def keyPressEvent(self, e):
        k = e.key()
        mods = e.modifiers()
        step = 10.0 if mods & Qt.KeyboardModifier.ShiftModifier else 1.0
        arrows = {Qt.Key.Key_Left: (-1, 0), Qt.Key.Key_Right: (1, 0), Qt.Key.Key_Up: (0, -1), Qt.Key.Key_Down: (0, 1)}
        if k in arrows and self.sel:
            ax, ay = arrows[k]
            rects = [self.rects[s] for s in self.sel]
            if mods & Qt.KeyboardModifier.ControlModifier:       # Strg+Pfeil: Größe ändern (rechte untere Ecke)
                changes = []
                for s in self.sel:
                    x0, y0, x1, y1 = self.rects[s]
                    changes.append((s, (x0, y0, max(x0 + MIN_SIZE, x1 + ax * step), max(y0 + MIN_SIZE, y1 + ay * step))))
            else:
                new, _, _ = move_rects(rects, ax * step, ay * step, [], 0, self.page_size, snap=False)
                changes = list(zip(self.sel, new))
            self.win.fields_place(changes)
            return
        if k in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace) and self.sel:
            self.win.fields_delete()
        elif k == Qt.Key.Key_A and mods & Qt.KeyboardModifier.ControlModifier:
            self.set_selection(list(self.order))
        elif k == Qt.Key.Key_D and mods & Qt.KeyboardModifier.ControlModifier:
            self.win.fields_copy()
        elif k in (Qt.Key.Key_F2, Qt.Key.Key_Return, Qt.Key.Key_Enter) and self.sel:
            self.win.fields_properties()
        elif k == Qt.Key.Key_Escape:
            if self.tool:
                self.tool = None
                self.setCursor(Qt.CursorShape.ArrowCursor)
            else:
                self.set_selection([])
        else:
            super().keyPressEvent(e)

    # ---- Kontextmenü
    def context_menu(self, gpos):
        m = QMenu(self)
        n = len(self.sel)
        a = m.addAction("Eigenschaften … (F2)")
        a.setEnabled(n >= 1)
        a.triggered.connect(self.win.fields_properties)
        a = m.addAction("Kopieren (Strg+D)")
        a.setEnabled(n >= 1)
        a.triggered.connect(self.win.fields_copy)
        a = m.addAction("Löschen (Entf)")
        a.setEnabled(n >= 1)
        a.triggered.connect(self.win.fields_delete)
        if n >= 2:
            m.addSeparator()
            for label, op in (("Links bündig", "left"), ("Rechts bündig", "right"), ("Oben bündig", "top"),
                              ("Unten bündig", "bottom"), ("Gleiche Breite", "same_w"), ("Gleiche Höhe", "same_h"),
                              ("Gleiche Größe", "same_size")):
                m.addAction(label).triggered.connect(lambda _=False, op=op: self.win.fields_align(op))
        m.exec(gpos)
