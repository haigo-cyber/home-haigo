#!/bin/sh
# Installiert Seifferts Stammbaum fuer den aktuellen Benutzer (ohne sudo).
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
DATA=${XDG_DATA_HOME:-$HOME/.local/share}
APP="$DATA/seiffert-stammbaum-app"
BIN="$HOME/.local/bin"
DESK="$DATA/applications"
ICON="$DATA/icons/hicolor/scalable/apps"

if [ "$1" = "--remove" ]; then
  rm -rf "$APP" "$BIN/seiffert-stammbaum" "$DESK/seiffert-stammbaum.desktop" "$ICON/seiffert-stammbaum.svg"
  command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$DESK" 2>/dev/null || true
  echo "Entfernt. Einstellungen und Daten bleiben erhalten:"
  echo "  ${XDG_CONFIG_HOME:-$HOME/.config}/seiffert-stammbaum  (Einstellungen, Google-Zugang)"
  echo "  $DATA/seiffert-stammbaum  (gespeicherte Datei- und Ordnerverbindungen, Vorversionen)"
  exit 0
fi

PY=python3
if ! $PY -c "from PySide6 import QtWebEngineWidgets, QtWebChannel" 2>/dev/null; then
  echo "Hinweis: PySide6 mit QtWebEngine wurde nicht gefunden." >&2
  echo "  Arch:  sudo pacman -S pyside6 qt6-webengine" >&2
  echo "  oder:  python3 -m venv --system-site-packages $APP/venv && $APP/venv/bin/pip install PySide6 PySide6-WebEngine" >&2
  echo "Die Dateien werden trotzdem installiert." >&2
fi

mkdir -p "$APP" "$BIN" "$DESK" "$ICON"
rm -rf "$APP/vendor"
cp "$HERE/app.py" "$HERE/shim.js" "$HERE/stammbaum.html" "$HERE/seiffert-stammbaum.svg" "$APP/"
cp -r "$HERE/vendor" "$APP/vendor"
cp "$HERE/seiffert-stammbaum.svg" "$ICON/seiffert-stammbaum.svg"
cat > "$BIN/seiffert-stammbaum" <<LAUNCH
#!/bin/sh
PY=python3
[ -x "$APP/venv/bin/python" ] && PY="$APP/venv/bin/python"
exec "\$PY" "$APP/app.py" "\$@"
LAUNCH
chmod +x "$BIN/seiffert-stammbaum"
cat > "$DESK/seiffert-stammbaum.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=Seifferts Stammbaum
GenericName=Stammbaum
Comment=Stammbaum mit GEDCOM-Datei, Medienordner und Google-Drive-Sicherung
Exec=$BIN/seiffert-stammbaum
Icon=seiffert-stammbaum
Terminal=false
Categories=Office;Education;
StartupWMClass=seiffert-stammbaum
DESKTOP
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$DESK" 2>/dev/null || true
echo "Fertig. Start über das Menü (Seifferts Stammbaum) oder mit:  $BIN/seiffert-stammbaum"
case ":$PATH:" in *":$BIN:"*) ;; *) echo "Hinweis: $BIN steht nicht in PATH. Das Menü funktioniert trotzdem." ;; esac
