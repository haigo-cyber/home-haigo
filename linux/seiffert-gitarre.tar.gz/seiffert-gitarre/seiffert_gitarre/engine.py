"""Audio-Engine: Gitarre vom Interface durch die Effektkette, dazu Schlagzeug und Keyboard."""
import queue

import numpy as np
from pedalboard import (Chorus, Compressor, Delay, Distortion, Gain, HighpassFilter,
                        HighShelfFilter, Limiter, LowpassFilter, LowShelfFilter,
                        NoiseGate, Pedalboard, PeakFilter, Reverb)

from .backing import Backing
from .fxdefs import CHAIN_ORDER, FX_GROUPS, INPUT_GAIN, VOLUMES, vol_to_gain

try:
    import sounddevice as sd
    SD_ERROR = None
except Exception as exc:  # meist: PortAudio fehlt
    sd = None
    SD_ERROR = str(exc)


def list_devices():
    """Gibt (Eingänge, Ausgänge) zurück, jeweils Liste von (Index, Anzeigename, Name)."""
    if sd is None:
        return [], []
    ins, outs = [], []
    try:
        apis = sd.query_hostapis()
        for idx, dev in enumerate(sd.query_devices()):
            api = apis[dev["hostapi"]]["name"]
            label = "%s (%s)" % (dev["name"], api)
            if dev["max_input_channels"] > 0:
                ins.append((idx, label, dev["name"], dev["max_input_channels"]))
            if dev["max_output_channels"] > 0:
                outs.append((idx, label, dev["name"], dev["max_output_channels"]))
    except Exception:
        pass
    return ins, outs


class AudioEngine:
    def __init__(self):
        self.sr = 48000
        self.backing = Backing(self.sr)
        self.stream = None
        self.in_ch = 0
        self.xruns = 0
        self.errors = 0
        self.last_error = ""
        self.in_peak = 0.0
        self.out_peak = 0.0
        self.latency_ms = 0.0

        self._queue = queue.SimpleQueue()
        self.enabled = {g["key"]: False for g in FX_GROUPS}
        self.params = {g["key"]: {p[0]: p[4] for p in g["params"]} for g in FX_GROUPS}
        self.globals = {INPUT_GAIN[0]: INPUT_GAIN[4]}
        for v in VOLUMES:
            self.globals[v[0]] = v[4]

        self.plugins = self._make_plugins()
        self._limiter = Limiter(threshold_db=-1.0, release_ms=100.0)
        self.board = Pedalboard([self._limiter])
        self._cur = {}  # aktuelle (geglättete) lineare Verstärkungen
        self._dirty = True
        for key, ps in self.params.items():
            for name, val in ps.items():
                self._apply_param(key, name, val)
        self._rebuild_board()

    # ---- Effekt-Bausteine ----
    @staticmethod
    def _make_plugins():
        return {
            "gate": [NoiseGate(threshold_db=-60.0, ratio=10.0, attack_ms=1.0, release_ms=120.0)],
            "comp": [Compressor(threshold_db=-20.0, ratio=3.0, attack_ms=5.0, release_ms=100.0)],
            "drive": [Gain(gain_db=0.0), Distortion(drive_db=10.0), Gain(gain_db=-6.0)],
            "cab": [HighpassFilter(cutoff_frequency_hz=90.0), LowpassFilter(cutoff_frequency_hz=5500.0)],
            "eq": [LowShelfFilter(cutoff_frequency_hz=200.0, gain_db=0.0, q=0.7),
                   PeakFilter(cutoff_frequency_hz=1000.0, gain_db=0.0, q=0.8),
                   HighShelfFilter(cutoff_frequency_hz=3500.0, gain_db=0.0, q=0.7)],
            "chorus": [Chorus(rate_hz=0.8, depth=0.25, centre_delay_ms=7.0, feedback=0.0, mix=0.4)],
            "delay": [Delay(delay_seconds=0.35, feedback=0.3, mix=0.25)],
            "reverb": [Reverb(room_size=0.4, damping=0.5, wet_level=0.1, dry_level=1.0, width=1.0)],
        }

    def _apply_param(self, group, name, v):
        pl = self.plugins[group]
        v = float(v)
        if group == "gate":
            pl[0].threshold_db = v
        elif group == "comp":
            if name == "thresh":
                pl[0].threshold_db = v
            else:
                pl[0].ratio = v
        elif group == "drive":
            if name == "gain":
                pl[0].gain_db = v
            elif name == "drive":
                pl[1].drive_db = v
            else:
                pl[2].gain_db = v
        elif group == "cab":
            pl[1].cutoff_frequency_hz = v
        elif group == "eq":
            idx = {"bass": 0, "mid": 1, "treble": 2}[name]
            pl[idx].gain_db = v
        elif group == "chorus":
            if name == "rate":
                pl[0].rate_hz = v
            elif name == "depth":
                pl[0].depth = v
            else:
                pl[0].mix = v
        elif group == "delay":
            if name == "time":
                pl[0].delay_seconds = v
            elif name == "feedback":
                pl[0].feedback = min(v, 0.95)
            else:
                pl[0].mix = v
        elif group == "reverb":
            if name == "room":
                pl[0].room_size = v
            else:
                pl[0].wet_level = v * 0.5

    def _rebuild_board(self):
        chain = []
        for key in CHAIN_ORDER:
            if self.enabled.get(key):
                chain.extend(self.plugins[key])
        chain.append(self._limiter)
        self.board = Pedalboard(chain)

    # ---- Steuerung aus der Oberfläche (thread-sicher über Warteschlange) ----
    def set_enabled(self, group, on):
        self._queue.put(("enabled", group, bool(on)))

    def set_param(self, group, name, value):
        self._queue.put(("param", group, name, float(value)))

    def set_global(self, name, value):
        self._queue.put(("global", name, float(value)))

    def _drain(self):
        changed = False
        while True:
            try:
                msg = self._queue.get_nowait()
            except queue.Empty:
                break
            kind = msg[0]
            if kind == "enabled":
                self.enabled[msg[1]] = msg[2]
                changed = True
            elif kind == "param":
                self.params[msg[1]][msg[2]] = msg[3]
                self._apply_param(msg[1], msg[2], msg[3])
            elif kind == "global":
                self.globals[msg[1]] = msg[2]
        if changed:
            self._rebuild_board()

    # ---- Verstärkungen mit weichem Übergang ----
    def _gain(self, name, target):
        prev = self._cur.get(name, target)
        self._cur[name] = target
        return prev

    def _ramped(self, name, target, n):
        prev = self._gain(name, target)
        if prev == target:
            return target
        return np.linspace(prev, target, n, endpoint=False, dtype=np.float32)

    # ---- Audio-Rückruf ----
    def process_block(self, indata, frames):
        """Verarbeitet einen Block. indata: (frames, Kanäle). Rückgabe: (frames,) Ausgabe."""
        self._drain()
        g = self.globals
        ch = min(self.in_ch, indata.shape[1] - 1)
        x = np.nan_to_num(indata[:, ch].astype(np.float32), nan=0.0, posinf=0.0, neginf=0.0)
        peak = float(np.max(np.abs(x))) if frames else 0.0
        self.in_peak = max(peak, self.in_peak * 0.9)

        x = x * self._ramped("in", 10 ** (g["input_db"] / 20.0), frames)
        y = self.board(x.reshape(1, -1), self.sr, reset=False)[0]
        y = y * self._ramped("guitar", vol_to_gain(g["guitar"]), frames)

        drums, keys = self.backing.render(frames)
        y = y + drums * self._ramped("drums", vol_to_gain(g["drums"]), frames)
        y = y + keys * self._ramped("keys", vol_to_gain(g["keys"]), frames)
        y = y * self._ramped("master", vol_to_gain(g["master"]) * 1.4, frames)
        y = np.clip(y, -1.0, 1.0)
        self.out_peak = max(float(np.max(np.abs(y))) if frames else 0.0, self.out_peak * 0.9)
        return y

    def _callback(self, indata, outdata, frames, time_info, status):
        try:
            if status:
                self.xruns += 1
            y = self.process_block(indata, frames)
            outdata[:, 0] = y
            outdata[:, 1] = y
        except Exception as exc:  # Ton darf nie wegen eines Fehlers hängen bleiben
            self.errors += 1
            self.last_error = repr(exc)
            outdata.fill(0)

    # ---- Stream starten und beenden ----
    def start(self, in_idx, out_idx, in_channel, sr, blocksize):
        if sd is None:
            raise RuntimeError("PortAudio nicht gefunden: " + str(SD_ERROR))
        self.stop()
        self.in_ch = int(in_channel)
        self.sr = int(sr)
        self.backing.set_samplerate(self.sr)
        self.backing.request_rebuild()
        self.xruns = self.errors = 0
        self._cur.clear()
        self._drain()
        n_in = max(1, self.in_ch + 1)
        info = sd.query_devices(in_idx)
        n_in = min(n_in, info["max_input_channels"])
        self.in_ch = min(self.in_ch, n_in - 1)
        stream = sd.Stream(samplerate=self.sr, blocksize=int(blocksize), device=(in_idx, out_idx),
                           channels=(n_in, 2), dtype="float32", latency="low",
                           callback=self._callback)
        stream.start()
        self.stream = stream
        try:
            self.latency_ms = (stream.latency[0] + stream.latency[1]) * 1000.0
        except Exception:
            self.latency_ms = 0.0

    def stop(self):
        if self.stream is not None:
            try:
                self.stream.stop()
                self.stream.close()
            finally:
                self.stream = None

    @property
    def running(self):
        return self.stream is not None and self.stream.active
