"""Programme und Dateizuordnung für Seifferts Dateien (und den Starter): installierte Programme erkennen,
pro Dateiendung ein Programm festlegen, Programme starten. Wird als Mischklasse in Backend eingebunden."""
from __future__ import annotations

import os
import re
import shlex
import shutil
import subprocess
from pathlib import Path

import backend as B
import icongen as IG

AppError = B.AppError
EXT_RE = re.compile(r"[a-z0-9_+-]{1,16}")
APP_ID_RE = re.compile(r"[A-Za-z0-9_.+-]+\.desktop")
COMMON_EXTS = ["pdf", "docx", "doc", "odt", "rtf", "txt", "md", "tex", "xlsx", "ods", "csv", "pptx", "odp", "html", "png", "jpg",
               "jpeg", "gif", "svg", "mp3", "mp4", "mkv", "zip"]


class Apps:
    _apps_cache: tuple | None = None

    # ------------------------------------------------------------ Programme erkennen
    @staticmethod
    def _app_dirs() -> list[Path]:
        home = Path(os.environ.get("XDG_DATA_HOME") or (Path.home() / ".local" / "share"))
        others = [Path(x) for x in (os.environ.get("XDG_DATA_DIRS") or "/usr/local/share:/usr/share").split(":") if x]
        return [d / "applications" for d in [home] + others]

    @staticmethod
    def _parse_app(f: Path) -> dict | None:
        d: dict = {}
        try:
            in_entry = False
            for line in f.read_text(encoding="utf-8", errors="replace").splitlines():
                s = line.strip()
                if s.startswith("["):
                    in_entry = s == "[Desktop Entry]"
                    continue
                if in_entry and "=" in s and not s.startswith("#"):
                    k, v = s.split("=", 1)
                    d.setdefault(k.strip(), v.strip())
        except OSError:
            return None
        if d.get("Type") != "Application" or not d.get("Exec"):
            return None
        if d.get("NoDisplay", "").lower() == "true" or d.get("Hidden", "").lower() == "true":
            return None
        try_exec = d.get("TryExec", "")
        if try_exec and not (shutil.which(try_exec) if "/" not in try_exec else os.access(try_exec, os.X_OK)):
            return None
        split = lambda v: [x for x in v.split(";") if x]
        return {"id": f.name, "name": d.get("Name[de]") or d.get("Name") or f.stem, "generic": d.get("GenericName[de]") or d.get("GenericName", ""),
                "comment": d.get("Comment[de]") or d.get("Comment", ""), "keywords": split(d.get("Keywords[de]") or d.get("Keywords", "")),
                "mimes": split(d.get("MimeType", "")), "exec": d["Exec"], "terminal": d.get("Terminal", "").lower() == "true",
                "icon": d.get("Icon", ""), "categories": split(d.get("Categories", ""))}

    def _all_apps(self) -> list[dict]:
        dirs = self._app_dirs()
        stamp = []
        for d in dirs:
            try:
                stamp.append(d.stat().st_mtime_ns)
            except OSError:
                stamp.append(0)
        c = Apps._apps_cache
        if c and c[0] == stamp:
            return c[1]
        seen: dict[str, dict] = {}
        for d in dirs:
            try:
                names = sorted(os.listdir(d))
            except OSError:
                continue
            for n in names:
                if n.endswith(".desktop") and n not in seen and APP_ID_RE.fullmatch(n):
                    a = self._parse_app(d / n)
                    if a:
                        seen[n] = a
        apps = sorted(seen.values(), key=lambda a: B.fold(a["name"]))
        Apps._apps_cache = (stamp, apps)
        return apps

    def api_apps_list(self) -> dict:
        return {"apps": [{k: a[k] for k in ("id", "name", "generic", "comment", "keywords", "mimes", "terminal", "icon", "categories")} for a in self._all_apps()]}

    def api_app_icons(self, ids: list) -> dict:
        """Symbole von Programmen als data:-Adressen für die Oberfläche (Programmliste); nicht Auffindbares fehlt im Ergebnis."""
        if not isinstance(ids, list):
            raise AppError("Programmliste ungültig.")
        out = {}
        for i in ids[:80]:
            a = self._app_by_id(str(i)) if APP_ID_RE.fullmatch(str(i)) else None
            if a and a.get("icon"):
                uri = IG.data_uri(IG.find_icon_file(a["icon"]))
                if uri:
                    out[a["id"]] = uri
        return {"icons": out}

    def api_file_icons(self, exts: list) -> dict:
        """Ein Symbol je Dateiendung: Blatt mit Endung in der Farbe der Dateiart, dazu das Original-Symbol des zugeordneten Programms
        (eigene Zuordnung vor Systemstandard) aus dem Symbolthema des Desktops. Ohne Programm bleibt das Blatt mit Textzeilen."""
        if not isinstance(exts, list):
            raise AppError("Endungsliste ungültig.")
        out = {}
        for e in exts[:80]:
            e = str(e).lower().lstrip(".")
            if not EXT_RE.fullmatch(e):
                continue
            grp = B.FILE_TYPES.get(e, ("other", ""))[0]
            app = self.app_for_path("x." + e)
            uri = IG.data_uri(IG.find_icon_file(app["icon"])) if app and app.get("icon") else ""
            out[e] = {"svg": IG.ext_svg(e, grp, bool(uri)), "prog": uri, "app": app["name"] if app else "", "box": list(IG.PROG_BOX)}
        return {"icons": out}

    def _app_by_id(self, app_id: str) -> dict | None:
        return next((a for a in self._all_apps() if a["id"] == app_id), None)

    # ------------------------------------------------------------ Programm ohne Datei starten
    def api_launch_app(self, app_id: str) -> dict:
        a = self._app_by_id(app_id)
        if not a:
            raise AppError("Das Programm wurde nicht gefunden.")
        try:
            parts = shlex.split(a["exec"])
        except ValueError:
            raise AppError("Der Startbefehl des Programms ist ungültig.")
        argv = []
        for t in parts:
            if re.fullmatch(r"%[fFuUdDnNickvm]", t):
                continue
            argv.append(t.replace("%%", "%"))
        if not argv:
            raise AppError("Der Startbefehl des Programms ist leer.")
        if a["terminal"]:
            term = self._find_terminal()
            if not term:
                raise AppError("Dieses Programm braucht ein Terminal, es wurde aber keines gefunden.")
            argv = term[0] + term[2] + argv
        try:
            self._spawn(argv, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True,
                        cwd=str(Path.home()))
        except OSError as e:
            raise AppError("Start nicht möglich: " + (e.strerror or str(e)))
        return {"ok": True, "name": a["name"]}

    # ------------------------------------------------------------ Zuordnung Dateiendung -> Programm
    def _own_assoc(self) -> dict:
        v = self.cfg.get("assoc") or {}
        return v if isinstance(v, dict) else {}

    def _system_default(self, mime: str) -> str:
        """Standardprogramm des Systems für einen Dateityp (mimeapps.list, sonst erster Eintrag der Zuordnungsliste)."""
        cfgdir = Path(os.environ.get("XDG_CONFIG_HOME") or (Path.home() / ".config"))
        files = [cfgdir / "mimeapps.list"] + [d / "mimeapps.list" for d in self._app_dirs()]
        for f in files:
            try:
                sec = ""
                for line in f.read_text(encoding="utf-8", errors="replace").splitlines():
                    line = line.strip()
                    if line.startswith("["):
                        sec = line
                    elif sec == "[Default Applications]" and "=" in line:
                        m, v = line.split("=", 1)
                        if m == mime:
                            for x in v.split(";"):
                                if x and self._app_by_id(x):
                                    return x
            except OSError:
                pass
        for d in self._app_dirs():
            try:
                for line in (d / "mimeinfo.cache").read_text(encoding="utf-8", errors="replace").splitlines():
                    if "=" in line:
                        m, v = line.split("=", 1)
                        if m == mime:
                            for x in v.split(";"):
                                if x and self._app_by_id(x):
                                    return x
            except OSError:
                pass
        return ""

    def _index_ext_counts(self, limit: int = 40) -> list[tuple[str, int]]:
        try:
            con = self._connect()
            try:
                return [(e, n) for e, n in con.execute("SELECT ext, COUNT(*) FROM meta WHERE status='ok' AND ext<>'' GROUP BY ext ORDER BY 2 DESC LIMIT ?", (limit,))]
            finally:
                con.close()
        except Exception:  # noqa: BLE001
            return []

    def api_assoc_overview(self) -> dict:
        own = {k: v for k, v in self._own_assoc().items() if isinstance(k, str)}
        counts = dict(self._index_ext_counts())
        exts = list(dict.fromkeys(list(own) + [e for e, _ in sorted(counts.items(), key=lambda x: -x[1])] + COMMON_EXTS))
        rows = []
        for e in exts:
            if not EXT_RE.fullmatch(e):
                continue
            mime = self._mime_of("x." + e)
            sysid = self._system_default(mime)
            sa = self._app_by_id(sysid) if sysid else None
            oa = self._app_by_id(own[e]) if e in own else None
            rows.append({"ext": e, "mime": mime, "count": counts.get(e, 0), "own": own.get(e, ""), "own_ok": bool(oa) if e in own else True,
                         "own_name": oa["name"] if oa else "", "system": sysid, "system_name": sa["name"] if sa else ""})
        return {"rows": rows, "apps": self.api_apps_list()["apps"], "xdg_mime": bool(shutil.which("xdg-mime"))}

    def api_assoc_set(self, ext: str, app_id: str = "", system: bool = False) -> dict:
        ext = (ext or "").lower().lstrip(".")
        if not EXT_RE.fullmatch(ext):
            raise AppError("Die Dateiendung ist ungültig (erlaubt sind Buchstaben, Ziffern, Plus, Minus und Unterstrich).")
        cur = dict(self._own_assoc())
        if not app_id:
            cur.pop(ext, None)
            self.api_set_config({"assoc": cur})
            return {"ok": True, "ext": ext, "app": ""}
        a = self._app_by_id(app_id)
        if not a:
            raise AppError("Das Programm wurde nicht gefunden.")
        cur[ext] = app_id
        self.api_set_config({"assoc": cur})
        if system:
            xm = shutil.which("xdg-mime")
            if not xm:
                raise AppError("Gemerkt für Seifferts Dateien. Für das ganze System fehlt das Programm xdg-mime (Paket xdg-utils).")
            mime = self._mime_of("x." + ext)
            try:
                r = subprocess.run([xm, "default", app_id, mime], capture_output=True, text=True, timeout=10)
            except (OSError, subprocess.TimeoutExpired) as e:
                raise AppError("Systemweit nicht möglich: " + str(e))
            if r.returncode != 0:
                raise AppError("Systemweit nicht möglich: " + (r.stderr.strip() or "xdg-mime meldet einen Fehler"))
        return {"ok": True, "ext": ext, "app": app_id, "name": a["name"]}

    def app_for_path(self, path: str) -> dict | None:
        """Programm, mit dem Seifferts Dateien die Datei öffnet: erst die eigene Zuordnung (Einstellungen, Dateitypen), sonst der Systemstandard."""
        own = self._assoc_app_for(path)
        if own:
            return self._app_by_id(own)
        sysid = self._system_default(self._mime_of(path))
        return self._app_by_id(sysid) if sysid else None

    def _assoc_app_for(self, path: str) -> str:
        ext = os.path.splitext(path)[1].lower().lstrip(".")
        app = self._own_assoc().get(ext) if ext else ""
        return app if app and self._app_by_id(app) else ""
