#!/bin/sh
# Installiert Seifferts Dateien für den aktuellen Benutzer (ohne sudo).
# Aufruf im entpackten Ordner:  ./install.sh      Entfernen:  ./install.sh --remove
# Seifferts Oberfläche (Schreibtisch für COSMIC) beim Anmelden automatisch starten:  ./install.sh --surface
# Tastenkürzel für den Starter unter Cinnamon eintragen:  ./install.sh --hotkey   (oder --hotkey='<Super>space' mit eigener Taste)
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
APP="${XDG_DATA_HOME:-$HOME/.local/share}/seiffert-dateien-app"
BIN="$HOME/.local/bin"
DESK="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
ICON="${XDG_DATA_HOME:-$HOME/.local/share}/icons/hicolor/scalable/apps"
AUTO="${XDG_CONFIG_HOME:-$HOME/.config}/autostart"
HK_SCHEMA="org.cinnamon.desktop.keybindings"
HK_ID="seiffert-starter"
HK_PATH="/org/cinnamon/desktop/keybindings/custom-keybindings/$HK_ID/"

# Tastenkürzel (Cinnamon) eintragen oder entfernen. Der Befehl bleibt derselbe: seiffert-starter schaltet die Wolke um.
hotkey() {
  mode="$1"; key="$2"
  command -v gsettings >/dev/null 2>&1 || { echo "Hinweis: gsettings fehlt, das Tastenkürzel muss von Hand gesetzt werden." >&2; return 1; }
  gsettings list-schemas 2>/dev/null | grep -qx "$HK_SCHEMA" || { echo "Hinweis: Cinnamon-Einstellungen nicht gefunden. Lege in deiner Tastaturkonfiguration ein Kürzel für den Befehl $BIN/seiffert-starter an." >&2; return 1; }
  cur="$(gsettings get "$HK_SCHEMA" custom-list 2>/dev/null)"
  new="$(CUR="$cur" MODE="$mode" ID="$HK_ID" python3 - <<'PYEOF'
import ast, os, re
raw = os.environ.get("CUR", "").strip()
raw = re.sub(r"^@as\s*", "", raw)
try:
    lst = list(ast.literal_eval(raw)) if raw else []
except Exception:
    lst = []
i = os.environ["ID"]
if os.environ["MODE"] == "add":
    if i not in lst:
        lst.append(i)
else:
    lst = [x for x in lst if x != i]
print(repr(lst))
PYEOF
)"
  if [ "$mode" = "add" ]; then
    gsettings set "$HK_SCHEMA.custom-keybinding:$HK_PATH" name "Seifferts Starter"
    gsettings set "$HK_SCHEMA.custom-keybinding:$HK_PATH" command "$BIN/seiffert-starter"
    gsettings set "$HK_SCHEMA.custom-keybinding:$HK_PATH" binding "['$key']"
    gsettings set "$HK_SCHEMA" custom-list "$new"
    echo "Tastenkürzel $key ist für den Starter eingetragen. Ist die Kombination schon belegt, ändere sie in den Cinnamon-Einstellungen unter Tastatur, Tastenkürzel."
  else
    gsettings set "$HK_SCHEMA" custom-list "$new" 2>/dev/null || true
    gsettings reset-recursively "$HK_SCHEMA.custom-keybinding:$HK_PATH" 2>/dev/null || true
  fi
}

if [ "$1" = "--remove" ]; then
  "$BIN/seiffert-starter" --quit >/dev/null 2>&1 || true
  "$BIN/seiffert-oberflaeche" --quit >/dev/null 2>&1 || true
  hotkey remove >/dev/null 2>&1 || true
  rm -rf "$APP" "$BIN/seiffert-dateien" "$BIN/seiffert-starter" "$BIN/seiffert-oberflaeche" "$DESK/seiffert-dateien.desktop" "$DESK/seiffert-starter.desktop" "$DESK/seiffert-oberflaeche.desktop" "$AUTO/seiffert-starter.desktop" "$AUTO/seiffert-oberflaeche.desktop" "$ICON/seiffert-dateien.svg"
  command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$DESK" 2>/dev/null || true
  echo "Entfernt. Einstellungen und Index bleiben in ~/.config/seiffert-dateien und ~/.local/share/seiffert-dateien."
  exit 0
fi

HOTKEY=""
SURFACE=""
for arg in "$@"; do
  case "$arg" in
    --hotkey) HOTKEY="<Super>space" ;;
    --hotkey=*) HOTKEY="${arg#--hotkey=}" ;;
    --surface) SURFACE=1 ;;
  esac
done

PY=python3
if ! $PY -c "from PySide6 import QtWebEngineWidgets, QtWebChannel" 2>/dev/null; then
  echo "Hinweis: PySide6 mit QtWebEngine wurde nicht gefunden." >&2
  echo "  Arch:  sudo pacman -S pyside6 qt6-webengine" >&2
  echo "  oder:  python3 -m venv --system-site-packages $APP/venv && $APP/venv/bin/pip install PySide6 PySide6-WebEngine" >&2
  echo "Die Dateien werden trotzdem installiert." >&2
fi
if ! /usr/bin/python3 -c "import gi; gi.require_version('Gtk','3.0'); from gi.repository import Gtk" 2>/dev/null && ! python3 -c "import gi; gi.require_version('Gtk','3.0'); from gi.repository import Gtk" 2>/dev/null; then
  echo "Hinweis: Für Seifferts Oberfläche (Schreibtisch) fehlt GTK 3 mit PyGObject. Arch: sudo pacman -S python-gobject gtk3 gtk-layer-shell librsvg" >&2
fi
command -v soffice >/dev/null 2>&1 || echo "Hinweis: LibreOffice fehlt, alte Dateien (doc, xls, ppt) lassen sich im Volltext nicht lesen (optional)." >&2
command -v pdftotext >/dev/null 2>&1 || echo "Hinweis: pdftotext fehlt, PDFs bleiben im Volltext und in der Vorschau unberücksichtigt (Arch: sudo pacman -S poppler)." >&2

mkdir -p "$APP" "$BIN" "$DESK" "$ICON"
cp "$HERE/app.py" "$HERE/backend.py" "$HERE/fileops.py" "$HERE/terminal.py" "$HERE/apps.py" "$HERE/startersetup.py" "$HERE/sessionenv.py" "$HERE/surfacesetup.py" "$HERE/surfacecfg.py" "$HERE/oberflaeche.py" "$HERE/foldericons.py" "$HERE/icongen.py" "$HERE/workspace.py" "$HERE/starter.py" "$HERE/index.html" "$HERE/seiffert-dateien.svg" "$APP/"
rm -rf "$APP/vendor" && cp -r "$HERE/vendor" "$APP/vendor"
cp "$HERE/seiffert-dateien.svg" "$ICON/seiffert-dateien.svg"
cat > "$BIN/seiffert-dateien" <<LAUNCH
#!/bin/sh
PY=python3
[ -x "$APP/venv/bin/python" ] && PY="$APP/venv/bin/python"
exec "\$PY" "$APP/app.py" "\$@"
LAUNCH
chmod +x "$BIN/seiffert-dateien"
cat > "$BIN/seiffert-starter" <<LAUNCH
#!/bin/sh
PY=python3
[ -x "$APP/venv/bin/python" ] && PY="$APP/venv/bin/python"
exec "\$PY" "$APP/starter.py" "\$@"
LAUNCH
chmod +x "$BIN/seiffert-starter"
cat > "$BIN/seiffert-oberflaeche" <<LAUNCH
#!/bin/sh
# Seifferts Oberfläche braucht GTK 3 über PyGObject; das System-Python hat es, ein venv meist nicht.
for PY in /usr/bin/python3 python3; do
  if "\$PY" -c "import gi" 2>/dev/null; then exec "\$PY" "$APP/oberflaeche.py" "\$@"; fi
done
echo "Seifferts Oberfläche: GTK 3 mit PyGObject fehlt. Arch: sudo pacman -S python-gobject gtk3 gtk-layer-shell librsvg" >&2
exit 1
LAUNCH
chmod +x "$BIN/seiffert-oberflaeche"
mkdir -p "$AUTO"
cat > "$AUTO/seiffert-starter.desktop" <<AUTOSTART
[Desktop Entry]
Type=Application
Name=Seifferts Starter
Comment=Hält den Starter bereit, damit er sofort erscheint
Exec=$BIN/seiffert-starter --daemon
Icon=seiffert-dateien
Terminal=false
X-GNOME-Autostart-enabled=true
AUTOSTART
cat > "$DESK/seiffert-starter.desktop" <<STARTERDESK
[Desktop Entry]
Type=Application
Name=Seifferts Starter
GenericName=Programme, Dateien und Ordner starten
Comment=Wolke mit Eingabezeile: Programme starten, Dateien und Ordner finden
Exec=$BIN/seiffert-starter
Icon=seiffert-dateien
Terminal=false
Categories=Utility;
STARTERDESK
cat > "$DESK/seiffert-oberflaeche.desktop" <<SURFDESK
[Desktop Entry]
Type=Application
Name=Seifferts Oberfläche
GenericName=Schreibtisch mit Starter-Symbol
Comment=Hintergrund, Symbole und Starter-Symbol (COSMIC, Wayland)
Exec=$BIN/seiffert-oberflaeche
Icon=seiffert-dateien
Terminal=false
Categories=Utility;
SURFDESK
if [ -n "$SURFACE" ]; then
cat > "$AUTO/seiffert-oberflaeche.desktop" <<SURFAUTO
[Desktop Entry]
Type=Application
Name=Seifferts Oberfläche
Comment=Hintergrund, Symbole und Starter-Symbol
Exec=$BIN/seiffert-oberflaeche --autostart
Icon=seiffert-dateien
Terminal=false
X-GNOME-Autostart-enabled=true
SURFAUTO
echo "Seifferts Oberfläche startet künftig beim Anmelden. Jetzt starten: $BIN/seiffert-oberflaeche"
fi
cat > "$DESK/seiffert-dateien.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=Seifferts Dateien
GenericName=Dateien und Favoriten
Comment=Dateiverwaltung mit Terminal, Favoriten als Karussell, Dateinamen- und Volltextsuche
Exec=$BIN/seiffert-dateien %f
Icon=seiffert-dateien
Terminal=false
Categories=Utility;FileTools;
StartupWMClass=seiffert-dateien
Actions=NewWindow;

[Desktop Action NewWindow]
Name=Neues Fenster
Exec=$BIN/seiffert-dateien --new-window
DESKTOP
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$DESK" 2>/dev/null || true
echo "Fertig. Start über das Menü (Seifferts Dateien) oder mit:  $BIN/seiffert-dateien"
echo "Seifferts Oberfläche (Schreibtisch für COSMIC): $BIN/seiffert-oberflaeche. Autostart: ./install.sh --surface oder in Seifferts Dateien unter Einstellungen, Oberfläche einrichten."
echo "Der Starter heißt Seifferts Starter (Befehl: $BIN/seiffert-starter). Er wird beim Anmelden im Hintergrund bereitgehalten."
if [ -n "$HOTKEY" ]; then hotkey add "$HOTKEY" || true
else echo "Tastenkürzel für den Starter eintragen (Cinnamon):  ./install.sh --hotkey   oder von Hand den Befehl $BIN/seiffert-starter belegen."; fi
"$BIN/seiffert-starter" --quit >/dev/null 2>&1 || true
nohup "$BIN/seiffert-starter" --daemon >/dev/null 2>&1 &
case ":$PATH:" in *":$BIN:"*) ;; *) echo "Hinweis: $BIN steht nicht in PATH. Das Menü funktioniert trotzdem." ;; esac
