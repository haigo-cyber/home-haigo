#!/usr/bin/env python3
"""Tests der Zentrale. Aufruf im Paketordner:  python3 tests/run_tests.py
Ohne Anzeige (offscreen) laufen die Prüfungen von Farben, Design-Umschaltung, Programmsuche und Fenstersuche.
Mit xvfb-run und python-xlib folgt ein Test mit echten Fenstern: ein Prüfprogramm wird gestartet und eingebettet."""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
TMP = tempfile.mkdtemp(prefix="zentrale-test-")
os.environ["HOME"] = TMP
os.environ["XDG_CONFIG_HOME"] = os.path.join(TMP, ".config")
os.environ["XDG_DATA_HOME"] = os.path.join(TMP, ".local", "share")

N = {"ok": 0, "bad": 0}


def check(name, cond, extra=""):
    N["ok" if cond else "bad"] += 1
    print(("ok   " if cond else "FEHLT"), name, extra if not cond else "")


def lum(h):
    h = h.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))
    f = lambda v: v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)


def contrast(a, b):
    x, y = sorted((lum(a), lum(b)), reverse=True)
    return (x + 0.05) / (y + 0.05)


from seiffert_zentrale import designctl, embed, skins
from seiffert_zentrale import seiffert_design as design
from seiffert_zentrale.programs import BY_ID, PROGRAMS, Program

# ---- Farben
for s in skins.SKINS:
    for dark in (False, True):
        c = skins.palette(s, dark)
        check("Kontrast Schrift %s %s" % (s, "dunkel" if dark else "hell"),
              contrast(c["ink"], c["bg"]) >= 4.5 and contrast(c["ink"], c["panel"]) >= 4.5 and contrast(c["accent_ink"], c["accent"]) >= 4.5,
              "%.1f" % min(contrast(c["ink"], c["bg"]), contrast(c["accent_ink"], c["accent"])))

# ---- Design-Umschaltung und Datei
cfgdir = skins.config_dir()
check("config.json noch nicht da", not (cfgdir / "config.json").exists())
designctl.set_design("wald", "dark")
d = json.loads((cfgdir / "config.json").read_text())
check("set_design schreibt skin und theme", d.get("skin") == "wald" and d.get("theme") == "dark", d)
(cfgdir / "config.json").write_text(json.dumps({"skin": "wald", "theme": "dark", "andere": {"x": 1}}))
designctl.set_design(theme="light")
d = json.loads((cfgdir / "config.json").read_text())
check("set_design behält fremde Schlüssel", d.get("andere") == {"x": 1} and d["theme"] == "light" and d["skin"] == "wald", d)
for bad in (("gibtsnicht", None), (None, "grün")):
    try:
        designctl.set_design(*bad)
        check("ungültige Wahl wird abgelehnt %s" % (bad,), False)
    except ValueError:
        check("ungültige Wahl wird abgelehnt %s" % (bad,), True)
check("kein Rest der temporären Datei", not list(cfgdir.glob("*.tmp-zentrale")))

# ---- Qt: Palette, Stylesheet, Beobachtung der Datei
from PySide6.QtCore import QEventLoop, QTimer
from PySide6.QtGui import QPalette
from PySide6.QtWidgets import QApplication

app = QApplication([])
cur = design.install(app)
check("install übernimmt Wald hell", cur["skin"] == "wald" and not cur["dark"])
pal = app.palette()
check("Palette Fenster = bg", pal.color(QPalette.ColorRole.Window).name() == skins.palette("wald", False)["bg"])
check("Palette Auswahl = accent", pal.color(QPalette.ColorRole.Highlight).name() == skins.palette("wald", False)["accent"])
seen = []
design.on_change(lambda c: seen.append(c["skin"] + str(c["dark"])))
(cfgdir / "config.json").write_text(json.dumps({"skin": "beere", "theme": "dark"}))
loop = QEventLoop()
QTimer.singleShot(900, loop.quit)
loop.exec()
check("Datei wird beobachtet, Wechsel kommt an", app.palette().color(QPalette.ColorRole.Highlight).name() == skins.palette("beere", True)["accent"], seen)
check("Rückruf bei Wechsel", seen and seen[-1] == "beereTrue", seen)
# config.json wird oft durch Ersetzen gespeichert: danach muss die Beobachtung weiterlaufen
designctl.set_design("graphit", "light")
loop = QEventLoop()
QTimer.singleShot(900, loop.quit)
loop.exec()
check("Beobachtung überlebt Ersetzen der Datei", app.palette().color(QPalette.ColorRole.Highlight).name() == skins.palette("graphit", False)["accent"])
css = design.web_css(design.current(app), {"--acc": "accent", "--bg": "bg"})
check("web_css", css.startswith("html:root{--acc:#") and "color-scheme:light" in css, css)

# ---- Programme
os.makedirs(os.path.join(TMP, ".local", "bin"))
import seiffert_zentrale.programs as P
P.BIN = os.path.join(TMP, ".local", "bin")
check("ohne Startbefehl nicht installiert", not BY_ID["text"].installed)
f = os.path.join(P.BIN, "seiffert-text")
open(f, "w").write("#!/bin/sh\n")
os.chmod(f, 0o755)
check("mit Startbefehl installiert", BY_ID["text"].installed and BY_ID["text"].path() == f)
check("Update ist eine Seite der Zentrale", BY_ID["update"].panel and BY_ID["update"].installed)
check("ToDo ist eingetragen (Gruppe Büro, Startbefehl seiffert-todo)", BY_ID["todo"].command == "seiffert-todo" and BY_ID["todo"].group == "Büro" and not BY_ID["todo"].installed)
_d = os.path.join(P.BIN, "seiffert-dateien"); open(_d, "w").write("#!/bin/sh\n"); os.chmod(_d, 0o755)
check("Autostart: Standard ist Dateien (wenn installiert)", P.autostart_ids({}) == ["dateien"])
check("Autostart: eigene Liste, Update-Seite und Unbekanntes werden ignoriert", P.autostart_ids({"autostart": ["text", "update", "gibtsnicht", 5]}) == ["text"])
check("Autostart abschaltbar", P.autostart_ids({"autostart": []}) == [] and P.autostart_ids({"autostart": "x"}) == ["dateien"])
os.remove(_d)
check("Autostart: nicht installiert wird nicht gestartet", P.autostart_ids({}) == [])
check("Kennungen eindeutig", len({p.id for p in PROGRAMS}) == len(PROGRAMS) and len({p.token for p in PROGRAMS}) == len(PROGRAMS))

# ---- Fenstersuche (reine Logik)
cands = {1: {"id": 1, "pid": 10, "name": "x", "cls": "a b", "w": 1, "h": 1}, 2: {"id": 2, "pid": 99, "name": "Seifferts Text", "cls": "t T", "w": 1, "h": 1},
         3: {"id": 3, "pid": 77, "name": "Zentrale", "cls": "z Z", "w": 1, "h": 1}}
check("pick nach Prozessnummer", embed.pick(cands, set(), 10, "dateien", 77) == 1)
check("pick nach Namen", embed.pick(cands, {1}, 555, "text", 77) == 2)
check("pick ignoriert alte Fenster", embed.pick(cands, {1, 2}, 10, "text", 77) is None)
check("pick ignoriert eigene Fenster", embed.pick(cands, set(), 77, "zentrale", 77) is None)

# ---- echte Fenster: Prüfprogramm einbetten (nur mit xvfb-run und python-xlib)
if shutil.which("xvfb-run") and embed.HAVE_XLIB:
    script = os.path.join(TMP, "echt.py")
    open(script, "w").write(r'''
import os, subprocess, sys, time
sys.path.insert(0, %r)
home = os.environ["HOME"]
fake = os.path.join(home, ".local", "bin", "seiffert-text")
prog = os.path.join(home, "fakeapp.py")
open(prog, "w").write("import sys\nfrom PySide6.QtWidgets import QApplication, QLabel\na = QApplication(sys.argv)\nw = QLabel('Pruefprogramm')\nw.setWindowTitle('Seifferts Text Pruefung')\nw.resize(400, 300)\nw.show()\nsys.exit(a.exec())\n")
open(fake, "w").write("#!/bin/sh\nexec " + sys.executable + " " + prog + "\n")
os.chmod(fake, 0o755)
env = dict(os.environ, QT_QPA_PLATFORM="xcb")
hub = subprocess.Popen([sys.executable, "-m", "seiffert_zentrale", "text"], env=env, cwd=%r, stderr=subprocess.DEVNULL)
from Xlib import display, X
d = display.Display()
def walk(w, depth=0):
    yield w, depth
    try:
        kids = w.query_tree().children
    except Exception:
        return
    for c in kids:
        yield from walk(c, depth + 1)
def find(title):
    for w, depth in walk(d.screen().root):
        try:
            n = w.get_wm_name()
            if not n:
                pr = w.get_full_property(d.intern_atom("_NET_WM_NAME"), X.AnyPropertyType)
                n = bytes(pr.value).decode("utf-8", "replace") if pr else None
        except Exception:
            n = None
        if n and title in str(n):
            yield w
def parent_title(w):
    try:
        p = w.query_tree().parent
        return p.get_wm_name() if p else None
    except Exception:
        return None
ok = False
for _ in range(60):
    time.sleep(0.5)
    for w in find("Seifferts Text Pruefung"):
        chain = []
        p = w
        for _i in range(6):
            try:
                p = p.query_tree().parent
            except Exception:
                break
            if p is None or p.id == d.screen().root.id:
                break
            nm = p.get_wm_name()
            if not nm:
                pr = p.get_full_property(d.intern_atom("_NET_WM_NAME"), X.AnyPropertyType)
                nm = bytes(pr.value).decode("utf-8", "replace") if pr else ""
            chain.append(str(nm))
        if any("Seifferts Zentrale" in c for c in chain):
            ok = True
    if ok:
        break
print("EINGEBETTET" if ok else "NICHT-EINGEBETTET")
if not ok:
    import traceback
    for w, dp in walk(d.screen().root):
        print("  " * dp, w.id, w.get_wm_name())
# geordnetes Schließen: Anfrage an das Fenster der Zentrale, die Zentrale soll sich mit dem Prüfprogramm beenden
for w in find("Seifferts Zentrale"):
    from Xlib.protocol import event
    ev = event.ClientMessage(window=w, client_type=d.intern_atom("WM_PROTOCOLS"), data=(32, [d.intern_atom("WM_DELETE_WINDOW"), X.CurrentTime, 0, 0, 0]))
    w.send_event(ev, event_mask=X.NoEventMask)
    d.flush()
    break
t0 = time.time()
while hub.poll() is None and time.time() - t0 < 15:
    time.sleep(0.3)
print("ZENTRALE-BEENDET" if hub.poll() is not None else "ZENTRALE-LAEUFT")
if hub.poll() is None:
    hub.kill()
''' % (ROOT, ROOT))
    r = subprocess.run(["xvfb-run", "-a", "-s", "-screen 0 1280x800x24", sys.executable, script], capture_output=True, text=True, timeout=120,
                       env=dict(os.environ, QT_QPA_PLATFORM="xcb"))
    out = r.stdout
    check("Prüfprogramm wird in die Zentrale eingebettet", "EINGEBETTET" in out and "NICHT" not in out, (out + r.stderr)[-400:])
    check("Zentrale beendet sich nach Schließanfrage samt Programm", "ZENTRALE-BEENDET" in out, out[-200:])
else:
    print("übersprungen: Test mit echten Fenstern (xvfb-run oder python-xlib fehlt)")

shutil.rmtree(TMP, ignore_errors=True)
print("\n%d bestanden, %d fehlgeschlagen" % (N["ok"], N["bad"]))
sys.exit(1 if N["bad"] else 0)
