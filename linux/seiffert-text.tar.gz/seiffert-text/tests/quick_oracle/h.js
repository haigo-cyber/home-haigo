const c = require('./core.js'); const fs = require('fs');
const scen = JSON.parse(fs.readFileSync('scen.json','utf8'));
function norm(doc){ return {eol:doc.eol, head:doc.head, tail:doc.tail, units: doc.units.map(u=>({raw:u.raw, fixed:!!u.fixed, img:u.img||null, segs:u.segs.map(s=>[s.k,s.v,!!s.raw,!!s.edited])}))}; }
function run(text){
  const out = {};
  let d = c.parseTex(text);
  out.parse = norm(d);
  out.ser = [0,1,2,3].map(m => c.serialize(d, {autoEscape: !!(m&1), autoBreak: !!(m&2)}));
  out.theme = c.themeMacro(d);
  out.macros = Array.from(c.definedMacros(d.head)).sort();
  out.blocks = c.blocksOf(d, out.theme).map(b=>[b.start,b.end,b.next]);
  out.types = c.lineTypes(d).map(t=>[t.macro,t.fields]);
  out.head = c.headFields(d.head).map(f=>[f.name,f.start,f.end,f.value]);
  out.images = c.findImages(d, {autoEscape:true,autoBreak:true});
  out.check = c.checkDoc(d, {autoEscape:true}).map(x=>x.msg);
  out.ns = c.findNameSize(d.head);
  const d2 = JSON.parse(JSON.stringify(d));
  const r = c.setNameSize(d2, 18); out.setns = [r, d2.head];
  const d3 = JSON.parse(JSON.stringify(d));
  out.shf = [c.setHeadField(d3, 'Titel', 'Neu & anders 50%', {autoEscape:true}), d3.head];
  // Ops
  const steps = [];
  const theme = out.theme;
  const vis = u => !u.fixed && (c.hasFields(u) || !!u.img);
  for (const o of scen.ops) {
    const n = d.units.length; const I = (x)=> ((x % n) + n) % n;
    try {
      if (o.op==='insertBelow') c.opInsertBelow(d, I(o.i));
      else if (o.op==='duplicate') c.opDuplicate(d, I(o.i));
      else if (o.op==='remove') c.opRemove(d, I(o.i));
      else if (o.op==='move') c.opMove(d, I(o.a), I(o.b));
      else if (o.op==='moveRel') c.opMoveRelative(d, I(o.i), o.d, vis);
      else if (o.op==='bulk') c.opBulk(d, I(o.i), o.text);
      else if (o.op==='blockMove'||o.op==='blockDuplicate'||o.op==='blockRemove'||o.op==='insertTypeAfterBlock'){
        const bl = c.blocksOf(d, theme); if (!bl.length) { steps.push('noblocks'); continue; }
        const b = bl[o.k % bl.length];
        if (o.op==='blockMove') c.opBlockMove(d, theme, b.id, o.d);
        else if (o.op==='blockDuplicate') c.opBlockDuplicate(d, theme, b.id);
        else if (o.op==='blockRemove') c.opBlockRemove(d, theme, b.id);
        else { const ty=c.lineTypes(d); if(!ty.length){steps.push('notypes');continue;} c.opInsertTypeAfterBlock(d, theme, b.id, ty[o.t % ty.length].unit); }
      }
      else if (o.op==='insertType'){ const ty=c.lineTypes(d); if(!ty.length){steps.push('notypes');continue;} c.opInsertType(d, I(o.i), ty[o.t % ty.length].unit); }
      else if (o.op==='insertImage') c.opInsertImage(d, I(o.i), o.file, o.w, o.a);
      else if (o.op==='setImg'){ const im = d.units.filter(u=>u.img); if(!im.length){steps.push('noimg');continue;} c.opSetImg(im[im.length-1], {w:o.w,a:o.a}); }
      else if (o.op==='setRaw') c.opSetRaw(d, I(o.i), o.raw);
      else if (o.op==='edit'){ d.units.forEach((u,i)=>{ if(i%o.every===0) u.segs.forEach(s=>{ if(s.k==='x'){ s.v=o.val; s.edited=true; }}); }); }
    } catch(e){ steps.push('ERR '+o.op+' '+e.message); continue; }
    steps.push([o.op, norm(d).units.length, c.serialize(d,{autoEscape:true,autoBreak:true}), c.serializeFile(d,{autoEscape:false,autoBreak:false})]);
  }
  out.steps = steps;
  return out;
}
const res = {};
for (const f of process.argv.slice(2)) res[f] = run(fs.readFileSync(f,'utf8'));
console.log(JSON.stringify(res));
