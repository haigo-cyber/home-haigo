"""Gemeinsame Definitionen: Effektgruppen, Regler, Voreinstellungen, Schlagzeugmuster."""

# Parameter: (Schlüssel, Beschriftung, Minimum, Maximum, Standard, Einheit, Nachkommastellen)
FX_GROUPS = [
    {"key": "gate", "title": "Rauschfilter", "params": [
        ("thresh", "Schwelle", -80.0, -30.0, -60.0, "dB", 0),
    ]},
    {"key": "comp", "title": "Kompressor", "params": [
        ("thresh", "Schwelle", -40.0, 0.0, -20.0, "dB", 0),
        ("ratio", "Verhältnis", 1.0, 10.0, 3.0, ":1", 1),
    ]},
    {"key": "drive", "title": "Verzerrung", "params": [
        ("gain", "Vorstufe", 0.0, 30.0, 8.0, "dB", 0),
        ("drive", "Verzerrung", 0.0, 50.0, 14.0, "dB", 0),
        ("level", "Ausgangspegel", -30.0, 6.0, -8.0, "dB", 0),
    ]},
    {"key": "cab", "title": "Lautsprecher-Filter", "params": [
        ("lp", "Höhenbegrenzung", 3000.0, 9000.0, 5500.0, "Hz", 0),
    ]},
    {"key": "eq", "title": "Klang", "params": [
        ("bass", "Bass", -12.0, 12.0, 0.0, "dB", 1),
        ("mid", "Mitten", -12.0, 12.0, 0.0, "dB", 1),
        ("treble", "Höhen", -12.0, 12.0, 0.0, "dB", 1),
    ]},
    {"key": "chorus", "title": "Chorus", "params": [
        ("rate", "Tempo", 0.1, 5.0, 0.8, "Hz", 1),
        ("depth", "Tiefe", 0.0, 1.0, 0.25, "", 2),
        ("mix", "Anteil", 0.0, 1.0, 0.4, "", 2),
    ]},
    {"key": "delay", "title": "Echo", "params": [
        ("time", "Zeit", 0.05, 1.0, 0.35, "s", 2),
        ("feedback", "Wiederholungen", 0.0, 0.9, 0.3, "", 2),
        ("mix", "Anteil", 0.0, 1.0, 0.25, "", 2),
    ]},
    {"key": "reverb", "title": "Hall", "params": [
        ("room", "Raumgröße", 0.0, 1.0, 0.4, "", 2),
        ("mix", "Anteil", 0.0, 1.0, 0.2, "", 2),
    ]},
]

CHAIN_ORDER = ["gate", "comp", "drive", "cab", "eq", "chorus", "delay", "reverb"]

# Allgemeine Regler
INPUT_GAIN = ("input_db", "Eingangspegel", -20.0, 30.0, 0.0, "dB", 0)
VOLUMES = [
    ("guitar", "Gitarre", 0.0, 100.0, 80.0, "%", 0),
    ("drums", "Schlagzeug", 0.0, 100.0, 60.0, "%", 0),
    ("keys", "Keyboard", 0.0, 100.0, 50.0, "%", 0),
    ("master", "Gesamt", 0.0, 100.0, 85.0, "%", 0),
]


def vol_to_gain(percent):
    return (percent / 100.0) ** 2


# Voreinstellungen für die Gitarre: Gruppe -> (an, {Parameter: Wert})
PRESETS = {
    "Sauber": {
        "gate": (True, {"thresh": -62}),
        "eq": (True, {}),
        "reverb": (True, {"room": 0.3, "mix": 0.15}),
    },
    "Crunch": {
        "gate": (True, {"thresh": -55}),
        "drive": (True, {"gain": 8, "drive": 14, "level": -8}),
        "cab": (True, {"lp": 6000}),
        "eq": (True, {"bass": 1, "mid": 2, "treble": 0}),
        "reverb": (True, {"room": 0.3, "mix": 0.12}),
    },
    "Lead": {
        "gate": (True, {"thresh": -55}),
        "comp": (True, {"thresh": -22, "ratio": 3}),
        "drive": (True, {"gain": 12, "drive": 24, "level": -10}),
        "cab": (True, {"lp": 5500}),
        "eq": (True, {"bass": 0, "mid": 3, "treble": -1}),
        "delay": (True, {"time": 0.38, "feedback": 0.3, "mix": 0.22}),
        "reverb": (True, {"room": 0.4, "mix": 0.2}),
    },
    "Hard Rock": {
        "gate": (True, {"thresh": -50}),
        "drive": (True, {"gain": 18, "drive": 34, "level": -12}),
        "cab": (True, {"lp": 5000}),
        "eq": (True, {"bass": 2, "mid": -2, "treble": 1}),
        "reverb": (True, {"room": 0.25, "mix": 0.1}),
    },
    "Ambient": {
        "gate": (True, {"thresh": -62}),
        "comp": (True, {"thresh": -24, "ratio": 3}),
        "eq": (True, {}),
        "chorus": (True, {"rate": 0.5, "depth": 0.35, "mix": 0.5}),
        "delay": (True, {"time": 0.5, "feedback": 0.5, "mix": 0.4}),
        "reverb": (True, {"room": 0.8, "mix": 0.4}),
    },
}

# Schlagzeug: Reihen und Muster. X = laut, x = leise, . = aus
DRUM_ROWS = [
    ("kick", "Bass Drum"),
    ("snare", "Snare"),
    ("hat", "Hi-Hat"),
    ("ohat", "Hi-Hat offen"),
    ("crash", "Crash"),
]

# Muster: Name -> (Schritte pro Takt, Swing 0..1, {Reihe: Zeichenkette})
DRUM_PRESETS = {
    "Rock (Achtel)": (16, 0.0, {
        "kick": "X.......X.X.....", "snare": "....X.......X...",
        "hat": "X.x.X.x.X.x.X.x.", "ohat": "................", "crash": "X..............."}),
    "Rock (Sechzehntel)": (16, 0.0, {
        "kick": "X.....x.X.X.....", "snare": "....X.......X...",
        "hat": "XxxxXxxxXxxxXxxx", "ohat": "................", "crash": "X..............."}),
    "Pop (Vierviertel)": (16, 0.0, {
        "kick": "X...X...X...X...", "snare": "....X.......X...",
        "hat": "................", "ohat": "..X...X...X...X.", "crash": "X..............."}),
    "Funk": (16, 0.35, {
        "kick": "X..X..X...X..X..", "snare": "....X..x.x..X..x",
        "hat": "XxXxXxXxXxXxXxXx", "ohat": "................", "crash": "................"}),
    "Halftime": (16, 0.0, {
        "kick": "X.....x.........", "snare": "........X.......",
        "hat": "X.x.X.x.X.x.X.x.", "ohat": "................", "crash": "X..............."}),
    "Metal (Doppelfuß)": (16, 0.0, {
        "kick": "XxXxXxXxXxXxXxXx", "snare": "....X.......X...",
        "hat": "X...X...X...X...", "ohat": "................", "crash": "X..............."}),
    "Blues Shuffle": (12, 0.0, {
        "kick": "X.....X.....", "snare": "...X.....X..",
        "hat": "X.xX.xX.xX.x", "ohat": "............", "crash": "X..........."}),
    "Slow Blues (12/8)": (12, 0.0, {
        "kick": "X.....X.....", "snare": "...X.....X..",
        "hat": "XxxXxxXxxXxx", "ohat": "............", "crash": "X..........."}),
}

CHORD_PRESETS = {
    "Am F C G": "Am F C G",
    "Blues in A": "A7 A7 A7 A7 D7 D7 A7 A7 E7 D7 A7 E7",
    "Em C G D": "Em C G D",
    "Rock (D C G)": "D C G G",
    "Am G F E": "Am G F E",
}

KEYS_STYLES = [
    ("pad", "Flächen"),
    ("quarter", "Viertel"),
    ("eighth", "Achtel"),
    ("offbeat", "Gegenschlag"),
    ("arp", "Arpeggio"),
]
KEYS_SOUNDS = [
    ("epiano", "E-Piano"),
    ("organ", "Orgel"),
    ("pad", "Pad"),
]
