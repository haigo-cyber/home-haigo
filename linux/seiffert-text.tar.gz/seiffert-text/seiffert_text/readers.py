"""Leser für ODT/ODS/ODP, DOCX, XLSX, PPTX, CSV, TXT sowie Umwandlung alter Formate über LibreOffice."""
import csv
import datetime
import os
import re
import shutil
import subprocess
import tempfile
import zipfile
import xml.etree.ElementTree as ET

from .latex_out import esc

MAX_ROWS = 3000


class ReaderError(Exception):
    pass


class Result:
    def __init__(self, blocks, kind="foreign", note=""):
        self.blocks = blocks
        self.kind = kind      # 'odt' = natives Format, 'foreign' = wird als LaTeX angezeigt
        self.note = note


# ---------------------------------------------------------------- LibreOffice
def find_soffice():
    for n in ("soffice", "libreoffice"):
        p = shutil.which(n)
        if p:
            return p
    for p in ("/usr/lib/libreoffice/program/soffice", "/opt/libreoffice/program/soffice",
              "/usr/bin/soffice"):
        if os.path.exists(p):
            return p
    return None


def lo_convert(path, ext, outdir):
    so = find_soffice()
    if not so:
        raise ReaderError("Für dieses Format wird LibreOffice benötigt, es wurde aber nicht gefunden.")
    prof = os.path.join(tempfile.gettempdir(), "seiffert-text-lo-profil")
    cmd = [so, "-env:UserInstallation=file://" + prof, "--headless", "--convert-to", ext,
           "--outdir", outdir, path]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=240)
    except subprocess.TimeoutExpired:
        raise ReaderError("LibreOffice hat die Umwandlung nicht rechtzeitig beendet.")
    out = os.path.join(outdir, os.path.splitext(os.path.basename(path))[0] + "." + ext.split(":")[0])
    if not os.path.exists(out):
        raise ReaderError("LibreOffice konnte die Datei nicht umwandeln.\n" + (r.stderr or r.stdout or "")[:400])
    return out


# ---------------------------------------------------------------- Hilfen
def txt(s, **fmt):
    d = {"t": "txt", "s": s}
    d.update({k: v for k, v in fmt.items() if v})
    return d


def para(inl, **kw):
    d = {"t": "p", "inl": inl}
    d.update(kw)
    return d


def merge_inl(out):
    res = []
    for x in out:
        if (res and x["t"] == "txt" and res[-1]["t"] == "txt" and
                {k: v for k, v in x.items() if k != "s"} == {k: v for k, v in res[-1].items() if k != "s"}):
            res[-1]["s"] += x["s"]
        else:
            res.append(x)
    return res


def length_cm(v):
    if not v:
        return None
    m = re.match(r"([\d.,]+)\s*(cm|mm|in|pt|px)?", v)
    if not m:
        return None
    x = float(m.group(1).replace(",", "."))
    u = m.group(2) or "cm"
    return {"cm": x, "mm": x / 10, "in": x * 2.54, "pt": x * 0.03528, "px": x / 96 * 2.54}[u]


def fmt_de(v, decimals=None, group=False):
    if decimals is None:
        s = ("%.10g" % v)
        if "e" in s:
            s = repr(v)
    else:
        s = ("{:,.%df}" % decimals).format(v) if group else ("{:.%df}" % decimals).format(v)
    if group or "," in s:
        s = s.replace(",", "\x00").replace(".", ",").replace("\x00", ".")
    else:
        s = s.replace(".", ",")
    return s


def fmt_cell(v, nf="General"):
    if v is None:
        return ""
    if isinstance(v, bool):
        return "WAHR" if v else "FALSCH"
    if isinstance(v, datetime.datetime):
        if v.hour or v.minute or v.second:
            return v.strftime("%d.%m.%Y %H:%M")
        return v.strftime("%d.%m.%Y")
    if isinstance(v, datetime.date):
        return v.strftime("%d.%m.%Y")
    if isinstance(v, datetime.time):
        return v.strftime("%H:%M")
    if isinstance(v, (int, float)):
        nf = nf or "General"
        sec = re.sub(r'"[^"]*"|\[[^\]]*\]', "", nf.split(";")[0])
        dec = None
        m = re.search(r"\.([0#?]+)", sec)
        if m:
            dec = len(m.group(1))
        elif sec.strip() not in ("General", "@") and re.search(r"0", sec):
            dec = 0
        group = "#,#" in sec or "#,0" in sec or "0,0" in sec
        if "%" in sec:
            return fmt_de(v * 100, dec if dec is not None else 0) + " %"
        out = fmt_de(float(v), dec, group) if dec is not None else fmt_de(float(v))
        if "€" in nf or "EUR" in nf:
            return fmt_de(float(v), 2, True) + " €"
        return out
    return str(v)


def sheet_blocks(name, grid):
    """grid: Liste von Zeilen, Zelle = (text, cs, rs) oder None (verdeckt)."""
    # leere Ränder entfernen
    last_row = -1
    last_col = -1
    for r, row in enumerate(grid):
        for c, cell in enumerate(row):
            if cell and cell[0] != "":
                last_row = max(last_row, r)
                last_col = max(last_col, c)
    blocks = [para([txt(name)], h=2)]
    if last_row < 0:
        blocks.append(para([txt("(leeres Blatt)", i=True)]))
        return blocks
    rows = []
    cut = False
    for r in range(last_row + 1):
        if r >= MAX_ROWS:
            cut = True
            break
        cells = []
        for c in range(last_col + 1):
            cell = grid[r][c] if c < len(grid[r]) else ("", 1, 1)
            if cell is None:
                continue
            s, cs, rs = cell
            cs = min(cs, last_col + 1 - c)
            cells.append({"blocks": [para([txt(s)])], "cs": cs, "rs": rs, "hd": False})
        rows.append(cells)
    if rows:
        first = [x for x in rows[0] if x["blocks"][0]["inl"][0]["s"]]
        if first and all(not re.match(r"^[-+\d.,\s%€]+$", x["blocks"][0]["inl"][0]["s"]) for x in first):
            for x in rows[0]:
                x["hd"] = True
    blocks.append({"t": "table", "rows": rows})
    if cut:
        blocks.append({"t": "raw", "text": "% Hinweis: Das Blatt wurde nach %d Zeilen gekürzt." % MAX_ROWS})
    return blocks


# ---------------------------------------------------------------- ODF
NS_ODF = {
    "office": "urn:oasis:names:tc:opendocument:xmlns:office:1.0",
    "text": "urn:oasis:names:tc:opendocument:xmlns:text:1.0",
    "table": "urn:oasis:names:tc:opendocument:xmlns:table:1.0",
    "style": "urn:oasis:names:tc:opendocument:xmlns:style:1.0",
    "fo": "urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0",
    "draw": "urn:oasis:names:tc:opendocument:xmlns:drawing:1.0",
    "svg": "urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0",
    "xlink": "http://www.w3.org/1999/xlink",
}


def q(prefix, tag):
    return "{%s}%s" % (NS_ODF[prefix], tag)


def local(tag):
    return tag.rsplit("}", 1)[-1]


WS = re.compile(r"[ \t\r\n]+")


class OdfText:
    def __init__(self, zf):
        self.zf = zf
        self.styles = {}
        self.liststyles = {}
        self.content = ET.fromstring(zf.read("content.xml"))
        self.srcidx = {id(e): i for i, e in enumerate(
            e for e in self.content.iter() if e.tag in (q("text", "p"), q("text", "h")))}
        roots = [self.content]
        if "styles.xml" in zf.namelist():
            try:
                roots.append(ET.fromstring(zf.read("styles.xml")))
            except ET.ParseError:
                pass
        for root in roots:
            for st in root.iter(q("style", "style")):
                name = st.get(q("style", "name"))
                if not name:
                    continue
                props = {"parent": st.get(q("style", "parent-style-name")),
                         "family": st.get(q("style", "family"))}
                tp = st.find(q("style", "text-properties"))
                if tp is not None:
                    if tp.get(q("fo", "font-weight")) in ("bold", "700", "800", "900"):
                        props["b"] = True
                    if tp.get(q("fo", "font-style")) in ("italic", "oblique"):
                        props["i"] = True
                    us = tp.get(q("style", "text-underline-style"))
                    if us and us != "none":
                        props["u"] = True
                    ls = tp.get(q("style", "text-line-through-style"))
                    if ls and ls != "none":
                        props["st"] = True
                    pos = tp.get(q("style", "text-position"))
                    if pos:
                        if pos.startswith("super") or (pos[0].isdigit() and not pos.startswith("0")):
                            props["sup"] = True
                        elif pos.startswith("sub") or pos.startswith("-"):
                            props["sub"] = True
                    fn = (tp.get(q("style", "font-name")) or tp.get(q("fo", "font-family")) or "").lower()
                    if any(k in fn for k in ("mono", "courier", "consolas")):
                        props["tt"] = True
                pp = st.find(q("style", "paragraph-properties"))
                if pp is not None:
                    ta = pp.get(q("fo", "text-align"))
                    if ta in ("center", "end", "right", "justify"):
                        props["al"] = {"center": "center", "end": "right", "right": "right",
                                       "justify": "justify"}[ta]
                self.styles[(name, props["family"])] = props
            for ls in root.iter(q("text", "list-style")):
                name = ls.get(q("style", "name"))
                lv = {}
                for lvl in ls:
                    try:
                        n = int(lvl.get(q("text", "level"), "1"))
                    except ValueError:
                        continue
                    lv[n] = "num" if local(lvl.tag) == "list-level-style-number" else "bullet"
                self.liststyles[name] = lv

    def resolve(self, name, family):
        chain = []
        seen = set()
        while name and (name, family) in self.styles and name not in seen:
            seen.add(name)
            chain.append(name)
            name = self.styles[(name, family)]["parent"]
        props = {}
        for n in reversed(chain):
            p = self.styles[(n, family)]
            for k, v in p.items():
                if k not in ("parent", "family"):
                    props[k] = v
        return props, chain

    # ---- Absatzinhalt
    def inl(self, el, fmt, out):
        if el.text:
            out.append(txt(WS.sub(" ", el.text), **fmt))
        for ch in el:
            tag = local(ch.tag)
            if tag == "span" and ch.get(q("text", "style-name")) == "Raw_20_Text":
                out.append({"t": "raw", "s": self.plain(ch)})
            elif tag == "span":
                p, _ = self.resolve(ch.get(q("text", "style-name")), "text")
                f2 = dict(fmt)
                for k in ("b", "i", "u", "st", "sup", "sub", "tt"):
                    if p.get(k):
                        f2[k] = True
                self.inl(ch, f2, out)
            elif tag == "a":
                f2 = dict(fmt)
                href = ch.get(q("xlink", "href"))
                if href and not href.startswith("#"):
                    f2["href"] = href
                self.inl(ch, f2, out)
            elif tag == "s":
                out.append(txt(" " * int(ch.get(q("text", "c"), "1")), **fmt))
            elif tag == "tab":
                out.append(txt("    ", **fmt))
            elif tag == "line-break":
                out.append({"t": "br"})
            elif tag == "note":
                body = ch.find(q("text", "note-body"))
                parts = []
                if body is not None:
                    for p in body.iter(q("text", "p")):
                        parts.append("".join(p.itertext()).strip())
                out.append({"t": "raw", "s": "\\footnote{%s}" % esc(" ".join(x for x in parts if x))})
            elif tag == "frame":
                img = ch.find(q("draw", "image"))
                if img is not None:
                    href = img.get(q("xlink", "href"))
                    try:
                        data = self.zf.read(href) if href and not href.startswith("http") else None
                    except KeyError:
                        data = None
                    if data:
                        out.append({"t": "img", "data": data, "w": length_cm(ch.get(q("svg", "width")))})
            elif tag in ("annotation", "bookmark", "bookmark-start", "bookmark-end", "soft-page-break",
                         "tracked-changes", "change", "change-start", "change-end"):
                pass
            else:
                self.inl(ch, fmt, out)
            if ch.tail:
                out.append(txt(WS.sub(" ", ch.tail), **fmt))

    def plain(self, el):
        """Text eines Elements mit Zeilenumbrüchen und Leerzeichen (für Rohtext)."""
        parts = [el.text or ""]
        for ch in el:
            t = local(ch.tag)
            if t == "line-break":
                parts.append("\n")
            elif t == "s":
                parts.append(" " * int(ch.get(q("text", "c"), "1")))
            elif t == "tab":
                parts.append("\t")
            else:
                parts.append(self.plain(ch))
            parts.append(ch.tail or "")
        return "".join(parts)

    def paragraph(self, el):
        sname = el.get(q("text", "style-name"))
        props, chain = self.resolve(sname, "paragraph")
        if sname == "Raw_20_Block" or "Raw_20_Block" in chain:
            return {"t": "raw", "text": self.plain(el)}
        out = []
        base = {}
        if props.get("b") and not local(el.tag) == "h":
            base["b"] = True
        for k in ("i", "tt"):
            if props.get(k):
                base[k] = True
        self.inl(el, base, out)
        out = merge_inl(out)
        if out and out[0]["t"] == "txt":
            out[0]["s"] = out[0]["s"].lstrip(" ")
        if out and out[-1]["t"] == "txt":
            out[-1]["s"] = out[-1]["s"].rstrip(" ")
        out = [x for x in out if not (x["t"] == "txt" and x["s"] == "")]
        d = para(out)
        if id(el) in self.srcidx:
            d["src"] = self.srcidx[id(el)]
        if local(el.tag) == "h":
            d["h"] = max(1, min(6, int(el.get(q("text", "outline-level"), "1"))))
            if sname and sname.endswith("_Unnum"):
                d["unnum"] = True
        if props.get("al") and not d.get("h"):
            d["al"] = props["al"]
        low = " ".join(chain).lower()
        if "quotations" in low:
            d["quote"] = True
        if "preformatted" in low:
            d["code"] = True
            d["inl"] = [txt("".join(x.get("s", "") for x in out if x["t"] == "txt"))]
        if "title" in low and not d.get("h") and sname and sname.lower().startswith("title"):
            d["al"] = "center"
            for x in d["inl"]:
                if x["t"] == "txt":
                    x["b"] = True
        return d

    def blocks(self, parent, list_style=None, depth=0):
        res = []
        for el in parent:
            tag = local(el.tag)
            try:
                self._block(el, tag, res, list_style, depth)
            except ReaderError:
                raise
            except Exception:
                t = " ".join("".join(el.itertext()).split())
                if t:
                    res.append(para([txt(t)]))
        return res

    def _block(self, el, tag, res, list_style, depth):
        if True:
            if tag in ("p", "h"):
                res.append(self.paragraph(el))
            elif tag == "list":
                ls = el.get(q("text", "style-name")) or list_style
                lv = self.liststyles.get(ls, {})
                res.append(self.list_block(el, ls, depth + 1, lv))
            elif tag == "table" and el.tag == q("table", "table"):
                res.append(self.table(el))
            elif tag in ("section", "index-body", "table-of-content", "alphabetical-index"):
                if tag == "table-of-content":
                    body = el.find(q("text", "index-body"))
                    res.append({"t": "raw", "text": "\\tableofcontents"})
                else:
                    res.extend(self.blocks(el, list_style, depth))

    def list_block(self, el, ls, depth, lv):
        items = []
        for it in el:
            if local(it.tag) != "list-item" and local(it.tag) != "list-header":
                continue
            blocks = []
            for ch in it:
                t = local(ch.tag)
                if t in ("p", "h"):
                    blocks.append(self.paragraph(ch))
                elif t == "list":
                    ls2 = ch.get(q("text", "style-name")) or ls
                    blocks.append(self.list_block(ch, ls2, depth + 1, self.liststyles.get(ls2, lv)))
            items.append(blocks or [para([])])
        return {"t": "list", "ord": lv.get(depth, "bullet") == "num", "items": items}

    def table(self, el):
        rows = []

        def do_rows(parent):
            for r in parent:
                t = local(r.tag)
                if t in ("table-header-rows", "table-row-group", "table-rows"):
                    do_rows(r)
                elif t == "table-row":
                    rep = min(int(r.get(q("table", "number-rows-repeated"), "1")), 50)
                    cells = []
                    for c in r:
                        if local(c.tag) != "table-cell":
                            continue
                        crep = min(int(c.get(q("table", "number-columns-repeated"), "1")), 40)
                        cs = int(c.get(q("table", "number-columns-spanned"), "1"))
                        rs = int(c.get(q("table", "number-rows-spanned"), "1"))
                        blocks = self.blocks(c)
                        empty = not any(b["t"] != "p" or b["inl"] for b in blocks)
                        for _ in range(crep if not empty else min(crep, 1)):
                            cells.append({"blocks": blocks or [para([])], "cs": cs, "rs": rs, "hd": False})
                    for _ in range(rep if any(True for _c in cells) else 1):
                        rows.append(cells)
        do_rows(el)
        return {"t": "table", "rows": [list(r) for r in rows]}


def read_odt(zf):
    od = OdfText(zf)
    body = od.content.find(q("office", "body"))
    text = body.find(q("office", "text")) if body is not None else None
    if text is None:
        raise ReaderError("Die ODT-Datei enthält keinen Text.")
    return od.blocks(text)


def read_ods(zf):
    od = OdfText(zf)
    body = od.content.find(q("office", "body"))
    ss = body.find(q("office", "spreadsheet"))
    blocks = []
    for tb in ss.findall(q("table", "table")):
        name = tb.get(q("table", "name"), "Blatt")
        grid = []

        def rows_of(parent):
            for r in parent:
                t = local(r.tag)
                if t in ("table-header-rows", "table-row-group", "table-rows"):
                    yield from rows_of(r)
                elif t == "table-row":
                    yield r
        for r in rows_of(tb):
            rep = int(r.get(q("table", "number-rows-repeated"), "1"))
            row = []
            for c in r:
                tg = local(c.tag)
                if tg == "covered-table-cell":
                    for _ in range(min(int(c.get(q("table", "number-columns-repeated"), "1")), 40)):
                        row.append(None)
                    continue
                if tg != "table-cell":
                    continue
                crep = int(c.get(q("table", "number-columns-repeated"), "1"))
                vt = c.get(q("office", "value-type"))
                if vt in ("float", "percentage", "currency"):
                    v = float(c.get(q("office", "value"), "0"))
                    s = fmt_de(v * 100, 0) + " %" if vt == "percentage" else fmt_de(v)
                    if vt == "currency":
                        s = fmt_de(v, 2, True) + " " + {"EUR": "€"}.get(c.get(q("office", "currency"), ""), c.get(q("office", "currency"), ""))
                    # sichtbaren Text bevorzugen, wenn vorhanden
                    shown = "\n".join("".join(p.itertext()) for p in c.findall(q("text", "p"))).strip()
                    if shown:
                        s = shown
                elif vt == "date":
                    d = c.get(q("office", "date-value"), "")
                    try:
                        s = fmt_cell(datetime.datetime.fromisoformat(d))
                    except ValueError:
                        s = d
                elif vt == "boolean":
                    s = "WAHR" if c.get(q("office", "boolean-value")) == "true" else "FALSCH"
                else:
                    s = "\n".join("".join(p.itertext()) for p in c.findall(q("text", "p"))).strip()
                cs = int(c.get(q("table", "number-columns-spanned"), "1"))
                rs = int(c.get(q("table", "number-rows-spanned"), "1"))
                for _ in range(min(crep, 40 if s == "" else 200)):
                    row.append((s, cs, rs))
            if all((x is None or x[0] == "") for x in row):
                rep = min(rep, 1)
            for _ in range(min(rep, MAX_ROWS + 5)):
                grid.append(list(row))
        blocks += sheet_blocks(name, grid)
    return blocks


def read_odp(zf):
    od = OdfText(zf)
    body = od.content.find(q("office", "body"))
    pres = body.find(q("office", "presentation"))
    blocks = []
    n = 0
    for pg in pres.findall(q("draw", "page")):
        n += 1
        title = pg.get(q("draw", "name"), "Folie %d" % n)
        blocks.append(para([txt("Folie %d" % n)], h=2))
        for p in pg.iter():
            if local(p.tag) in ("p", "h") and p.tag.startswith("{%s}" % NS_ODF["text"]):
                t = "".join(p.itertext()).strip()
                if t:
                    blocks.append(para([txt(t)]))
    return blocks


# ---------------------------------------------------------------- DOCX
W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
A = "http://schemas.openxmlformats.org/drawingml/2006/main"
WP = "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
REL = "http://schemas.openxmlformats.org/package/2006/relationships"


def w(tag):
    return "{%s}%s" % (W, tag)


class Docx:
    def __init__(self, zf):
        self.zf = zf
        self.doc = ET.fromstring(zf.read("word/document.xml"))
        self.styles = {}
        if "word/styles.xml" in zf.namelist():
            for st in ET.fromstring(zf.read("word/styles.xml")).iter(w("style")):
                sid = st.get(w("styleId"))
                nm = st.find(w("name"))
                bo = st.find(w("basedOn"))
                rpr = st.find(w("rPr"))
                ppr = st.find(w("pPr"))
                d = {"name": (nm.get(w("val")) if nm is not None else sid or "").lower(),
                     "based": bo.get(w("val")) if bo is not None else None}
                if rpr is not None:
                    d.update(self.run_props(rpr))
                if ppr is not None:
                    jc = ppr.find(w("jc"))
                    if jc is not None:
                        d["al"] = {"center": "center", "right": "right", "end": "right",
                                   "both": "justify"}.get(jc.get(w("val")))
                    ol = ppr.find(w("outlineLvl"))
                    if ol is not None:
                        d["outline"] = int(ol.get(w("val"), "0")) + 1
                self.styles[sid] = d
        self.rels = {}
        rp = "word/_rels/document.xml.rels"
        if rp in zf.namelist():
            for r in ET.fromstring(zf.read(rp)):
                self.rels[r.get("Id")] = (r.get("Target"), r.get("TargetMode"))
        self.numfmt = {}
        if "word/numbering.xml" in zf.namelist():
            nroot = ET.fromstring(zf.read("word/numbering.xml"))
            absn = {}
            for an in nroot.findall(w("abstractNum")):
                lv = {}
                for l in an.findall(w("lvl")):
                    nf = l.find(w("numFmt"))
                    lv[int(l.get(w("ilvl"), "0"))] = nf.get(w("val")) if nf is not None else "bullet"
                absn[an.get(w("abstractNumId"))] = lv
            for nm in nroot.findall(w("num")):
                a = nm.find(w("abstractNumId"))
                if a is not None:
                    self.numfmt[nm.get(w("numId"))] = absn.get(a.get(w("val")), {})
        self.footnotes = {}
        if "word/footnotes.xml" in zf.namelist():
            for fn in ET.fromstring(zf.read("word/footnotes.xml")).findall(w("footnote")):
                t = " ".join("".join(x.text or "" for x in p.iter(w("t"))) for p in fn.iter(w("p"))).strip()
                self.footnotes[fn.get(w("id"))] = t

    def run_props(self, rpr):
        d = {}
        for tag, key in (("b", "b"), ("i", "i"), ("strike", "st")):
            e = rpr.find(w(tag))
            if e is not None and e.get(w("val")) not in ("0", "false"):
                d[key] = True
        u = rpr.find(w("u"))
        if u is not None and u.get(w("val")) not in (None, "none"):
            d["u"] = True
        va = rpr.find(w("vertAlign"))
        if va is not None:
            if va.get(w("val")) == "superscript":
                d["sup"] = True
            elif va.get(w("val")) == "subscript":
                d["sub"] = True
        rf = rpr.find(w("rFonts"))
        if rf is not None:
            fn = (rf.get(w("ascii")) or "").lower()
            if any(k in fn for k in ("mono", "courier", "consolas")):
                d["tt"] = True
        return d

    def style_chain(self, sid):
        chain = []
        seen = set()
        while sid and sid in self.styles and sid not in seen:
            seen.add(sid)
            chain.append(self.styles[sid])
            sid = self.styles[sid]["based"]
        return chain

    def runs(self, el, fmt, out, href=None):
        for ch in el:
            tag = local(ch.tag)
            if tag == "r":
                rpr = ch.find(w("rPr"))
                f = dict(fmt)
                if rpr is not None:
                    rs = rpr.find(w("rStyle"))
                    if rs is not None:
                        for st in self.style_chain(rs.get(w("val"))):
                            for k in ("b", "i", "u", "st", "sup", "sub", "tt"):
                                if st.get(k):
                                    f[k] = True
                    f.update(self.run_props(rpr))
                if href:
                    f["href"] = href
                for x in ch:
                    t = local(x.tag)
                    if t == "t":
                        out.append(txt(x.text or "", **f))
                    elif t == "tab":
                        out.append(txt("    ", **f))
                    elif t == "br":
                        if x.get(w("type")) not in ("page", "column"):
                            out.append({"t": "br"})
                    elif t == "noBreakHyphen":
                        out.append(txt("-", **f))
                    elif t == "footnoteReference":
                        ft = self.footnotes.get(x.get(w("id")), "")
                        out.append({"t": "raw", "s": "\\footnote{%s}" % esc(ft)})
                    elif t in ("drawing", "pict"):
                        img = self.image(x)
                        if img:
                            out.append(img)
            elif tag == "hyperlink":
                rid = ch.get("{%s}id" % R)
                h = None
                if rid and rid in self.rels and self.rels[rid][1] == "External":
                    h = self.rels[rid][0]
                self.runs(ch, fmt, out, h or href)
            elif tag in ("ins", "smartTag", "fldSimple", "sdt", "sdtContent", "customXml"):
                self.runs(ch, fmt, out, href)

    def image(self, el):
        rid = None
        for b in el.iter("{%s}blip" % A):
            rid = b.get("{%s}embed" % R)
        if rid is None:
            for b in el.iter():
                if local(b.tag) == "imagedata":
                    rid = b.get("{%s}id" % R)
        if not rid or rid not in self.rels:
            return None
        target = self.rels[rid][0]
        path = target.lstrip("/") if target.startswith("/") else "word/" + target
        path = os.path.normpath(path).replace("\\", "/")
        try:
            data = self.zf.read(path)
        except KeyError:
            return None
        cm = None
        ext = next(el.iter("{%s}extent" % WP), None)
        if ext is not None:
            try:
                cm = int(ext.get("cx")) / 360000.0
            except (TypeError, ValueError):
                pass
        return {"t": "img", "data": data, "w": cm}

    def paragraph(self, p):
        ppr = p.find(w("pPr"))
        sid = None
        d = {}
        num = None
        if ppr is not None:
            ps = ppr.find(w("pStyle"))
            sid = ps.get(w("val")) if ps is not None else None
            np_ = ppr.find(w("numPr"))
            if np_ is not None:
                ni = np_.find(w("numId"))
                il = np_.find(w("ilvl"))
                if ni is not None and ni.get(w("val")) != "0":
                    num = (ni.get(w("val")), int(il.get(w("val"), "0")) if il is not None else 0)
            jc = ppr.find(w("jc"))
            if jc is not None:
                d["al"] = {"center": "center", "right": "right", "end": "right", "both": "justify"}.get(jc.get(w("val")))
            ol = ppr.find(w("outlineLvl"))
            if ol is not None and int(ol.get(w("val"), "9")) < 6:
                d["h"] = int(ol.get(w("val"))) + 1
        chain = self.style_chain(sid)
        names = [c["name"] for c in chain]
        base = {}
        for c in reversed(chain):
            if c.get("al") and "al" not in d:
                d["al"] = c["al"]
            for k in ("b", "i", "tt"):
                if c.get(k):
                    base[k] = True
        for nm in names:
            m = re.match(r"^(?:heading|überschrift)\s*(\d)$", nm)
            if m:
                d["h"] = min(6, int(m.group(1)))
                break
        if "h" not in d:
            for c in chain:
                if c.get("outline") and c["outline"] <= 6:
                    d["h"] = c["outline"]
                    break
        if "title" in names or "subtitle" in names:
            d.setdefault("al", "center")
            base["b"] = True
        if any(n in ("quote", "intense quote", "block text", "quotations") for n in names):
            d["quote"] = True
        if any(n in ("source code", "code", "preformatted text", "html preformatted") for n in names):
            d["code"] = True
        if d.get("h"):
            base.pop("b", None)
        out = []
        self.runs(p, base, out)
        out = merge_inl(out)
        if d.get("code"):
            out = [txt("".join(x.get("s", "") for x in out if x["t"] == "txt"))]
        blk = para(out)
        blk.update({k: v for k, v in d.items() if v})
        return blk, num

    def blocks(self, parent):
        res = []
        stack = []     # (listblock, ilvl, numId)

        def close():
            stack.clear()
        for el in parent:
            tag = local(el.tag)
            if tag == "p":
                blk, num = self.paragraph(el)
                if num:
                    numid, lvl = num
                    fmts = self.numfmt.get(numid, {})
                    ordered = fmts.get(lvl, "bullet") not in ("bullet", "none")
                    while stack and stack[-1][1] > lvl:
                        stack.pop()
                    if stack and stack[-1][1] == lvl and (stack[-1][2] != numid):
                        stack.pop()
                    if not stack or stack[-1][1] < lvl:
                        lb = {"t": "list", "ord": ordered, "items": []}
                        if stack:
                            parent_item = stack[-1][0]["items"][-1]
                            parent_item.append(lb)
                        else:
                            res.append(lb)
                        stack.append((lb, lvl, numid))
                    stack[-1][0]["items"].append([blk])
                    continue
                close()
                if blk["inl"] or blk.get("h") or blk.get("code"):
                    res.append(blk)
                elif res and res[-1]["t"] != "raw":
                    pass
            elif tag == "tbl":
                close()
                res.append(self.table(el))
            elif tag in ("sdt",):
                c = el.find(w("sdtContent"))
                if c is not None:
                    res.extend(self.blocks(c))
        return res

    def table(self, tbl):
        rows = []
        vm = {}
        for tr in tbl.findall(w("tr")):
            cells = []
            col = 0
            for tc in tr.findall(w("tc")):
                pr = tc.find(w("tcPr"))
                cs = 1
                vmerge = None
                if pr is not None:
                    gs = pr.find(w("gridSpan"))
                    if gs is not None:
                        cs = int(gs.get(w("val"), "1"))
                    v = pr.find(w("vMerge"))
                    if v is not None:
                        vmerge = v.get(w("val"), "continue")
                if vmerge == "continue" and col in vm:
                    vm[col]["rs"] += 1
                    col += cs
                    continue
                cell = {"blocks": self.blocks(tc) or [para([])], "cs": cs, "rs": 1, "hd": False}
                if vmerge == "restart":
                    vm[col] = cell
                else:
                    vm.pop(col, None)
                cells.append(cell)
                col += cs
            rows.append(cells)
        if rows and tbl.find(w("tr")) is not None:
            trp = tbl.find(w("tr")).find(w("trPr"))
            if trp is not None and trp.find(w("tblHeader")) is not None:
                for c in rows[0]:
                    c["hd"] = True
        return {"t": "table", "rows": rows}


def read_docx(zf):
    d = Docx(zf)
    body = d.doc.find(w("body"))
    return d.blocks(body)


def read_xlsx(path):
    try:
        import openpyxl
    except ImportError:
        raise ReaderError("Das Python-Paket openpyxl fehlt (für Excel-Dateien).")
    wb = openpyxl.load_workbook(path, data_only=True)
    blocks = [para([txt(os.path.splitext(os.path.basename(path))[0])], h=1)]
    for ws in wb.worksheets:
        grid = []
        mr = ws.max_row or 0
        mc = ws.max_column or 0
        cover = {}
        for rng in ws.merged_cells.ranges:
            for r in range(rng.min_row, rng.max_row + 1):
                for c in range(rng.min_col, rng.max_col + 1):
                    cover[(r, c)] = (rng.min_row, rng.min_col, rng.max_row, rng.max_col)
        for r in range(1, min(mr, MAX_ROWS + 50) + 1):
            row = []
            for c in range(1, mc + 1):
                cell = ws.cell(row=r, column=c)
                m = cover.get((r, c))
                if m and (m[0], m[1]) != (r, c):
                    row.append(None)
                    continue
                s = fmt_cell(cell.value, cell.number_format)
                if m:
                    row.append((s, m[3] - m[1] + 1, m[2] - m[0] + 1))
                else:
                    row.append((s, 1, 1))
            grid.append(row)
        blocks += sheet_blocks(ws.title, grid)
    return blocks


def read_pptx(zf):
    names = sorted((n for n in zf.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)),
                   key=lambda n: int(re.search(r"(\d+)\.xml", n).group(1)))
    blocks = []
    for k, n in enumerate(names, 1):
        blocks.append(para([txt("Folie %d" % k)], h=2))
        root = ET.fromstring(zf.read(n))
        for p in root.iter("{%s}p" % A):
            t = "".join(x.text or "" for x in p.iter("{%s}t" % A)).strip()
            if t:
                blocks.append(para([txt(t)]))
    return blocks


def read_csv(path):
    with open(path, "rb") as f:
        raw = f.read()
    for enc in ("utf-8-sig", "cp1252"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    try:
        dialect = csv.Sniffer().sniff(text[:4096], delimiters=";,\t|")
    except csv.Error:
        dialect = csv.excel
    rows = list(csv.reader(text.splitlines(), dialect))
    grid = [[(c, 1, 1) for c in r] for r in rows]
    return [para([txt(os.path.splitext(os.path.basename(path))[0])], h=1)] + sheet_blocks("Tabelle", grid)[1:]


def read_text(path):
    with open(path, "rb") as f:
        raw = f.read()
    for enc in ("utf-8-sig", "cp1252"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    blocks = []
    for par in re.split(r"\n\s*\n", text):
        if par.strip():
            inl = []
            for k, line in enumerate(par.strip("\n").split("\n")):
                if k:
                    inl.append({"t": "br"})
                inl.append(txt(line))
            blocks.append(para(inl))
    return blocks


# ---------------------------------------------------------------- Einstieg
def read_any(path):
    ext = os.path.splitext(path)[1].lower()
    if ext in (".txt", ".text"):
        return Result(read_text(path), "foreign")
    if ext in (".csv", ".tsv"):
        return Result(read_csv(path), "foreign")
    if zipfile.is_zipfile(path):
        zf = zipfile.ZipFile(path)
        names = zf.namelist()
        if "word/document.xml" in names:
            return Result(read_docx(zf), "foreign")
        if "xl/workbook.xml" in names:
            return Result(read_xlsx(path), "foreign")
        if "ppt/presentation.xml" in names:
            return Result(read_pptx(zf), "foreign")
        if "content.xml" in names:
            head = zf.read("content.xml")[:200000].decode("utf-8", "ignore")
            mt = zf.read("mimetype").decode("utf-8", "ignore") if "mimetype" in names else ""
            if NS_ODF["office"] in head or "opendocument" in mt or ext in (".odt", ".ott", ".ods", ".odp"):
                if "spreadsheet" in mt or ext in (".ods", ".ots"):
                    return Result(read_ods(zf), "foreign")
                if "presentation" in mt or ext in (".odp", ".otp"):
                    return Result(read_odp(zf), "foreign")
                if "text" in mt or ext in (".odt", ".ott", ".fodt"):
                    return Result(read_odt(zf), "odt" if ext in (".odt", ".ott") else "foreign")
            # alte OpenOffice-Formate (sxw usw.)
            return _via_lo(path, ext)
    return _via_lo(path, ext)


def _via_lo(path, ext):
    target = "xlsx" if ext in (".xls", ".xlsb", ".xlsm", ".sxc", ".dif", ".wk1") else \
             ("odp" if ext in (".ppt", ".pps", ".sxi") else "odt")
    with tempfile.TemporaryDirectory(prefix="seiffert-text-") as td:
        out = lo_convert(path, target, td)
        if target == "xlsx":
            return Result(read_xlsx(out), "foreign")
        zf = zipfile.ZipFile(out)
        return Result(read_odp(zf) if target == "odp" else read_odt(zf), "foreign")
