#!/bin/sh
# Echter Starter-Dienst unter Xvfb + openbox: Schreibtisch im Vollbild, Umschalten mit F2, Klick auf Seitenknopf, Einstellung bleibt gespeichert
export LANG=C.UTF-8 LC_ALL=C.UTF-8
export HOME=/tmp/sd-ui-desk-home; rm -rf $HOME; mkdir -p $HOME/.config/seiffert-dateien; export TMPDIR=$HOME XDG_CONFIG_HOME=$HOME/.config XDG_DATA_HOME=$HOME/.local/share
export SEIFFERT_STARTER_NOHIDE=1
PY=${PYTHON:-python3}; SRC=$(cd "$(dirname "$0")/.." && pwd); OUT=${OUT:-/tmp}
echo '{"skin":"petrol","starter":{"design":"desk","desk_scheme":"neon"}}' > $HOME/.config/seiffert-dateien/config.json
openbox >/dev/null 2>&1 &
sleep 1
$PY $SRC/starter.py --daemon > $HOME/st.log 2>&1 &
sleep 4
timeout 10 $PY $SRC/starter.py --show >/dev/null 2>&1
sleep 2
vis() { timeout 5 xdotool search --onlyvisible --name "Seifferts Starter" | head -1; }
W=$(vis); echo "Fenster sichtbar: ${W:-nein}"
eval $(timeout 5 xdotool getwindowgeometry --shell $W); echo "Schreibtisch: ${WIDTH}x${HEIGHT} bei $X,$Y (Bildschirm 1280x800)"
import -window root $OUT/real_desk.png
# Klick auf den dritten Seitenknopf (Dateien): Knopfgröße 64, Dock links, y ab 66+16+...; Mitte grob aus der Geometrie
xdotool mousemove 56 330 click 1; sleep 1
import -window root $OUT/real_desk_click.png
# Tippen
xdotool type --delay 60 "zzzz"; sleep 1.2
import -window root $OUT/real_desk_type.png
xdotool key F2; sleep 2.5
W=$(vis); eval $(timeout 5 xdotool getwindowgeometry --shell $W); echo "nach F2: ${WIDTH}x${HEIGHT} (Wolke ist 1000x660)"
grep -o '"design": *"[a-z]*"' $HOME/.config/seiffert-dateien/config.json
import -window root $OUT/real_cloud.png
xdotool key Escape; sleep 0.5; xdotool key Escape; sleep 1
echo "nach Esc sichtbar: $(vis)"
timeout 10 $PY $SRC/starter.py --show >/dev/null 2>&1; sleep 2
W=$(vis); eval $(timeout 5 xdotool getwindowgeometry --shell $W); echo "erneut gezeigt: ${WIDTH}x${HEIGHT}"
xdotool key F2; sleep 2.5
W=$(vis); eval $(timeout 5 xdotool getwindowgeometry --shell $W); echo "nach zweitem F2: ${WIDTH}x${HEIGHT}"
grep -o '"design": *"[a-z]*"' $HOME/.config/seiffert-dateien/config.json
cat $HOME/st.log | head -5
$PY $SRC/starter.py --quit >/dev/null 2>&1
