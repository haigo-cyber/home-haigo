"""Seifferts Depot als Linux-App: das HTML-Tool läuft eingebettet, die Linux-App führt die Daten."""
