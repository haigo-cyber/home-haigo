"""Fremde Fenster in die Zentrale einbetten (nur X11).

Die Programme laufen als eigene Prozesse mit eigener Python-Umgebung; die Zentrale startet sie, findet ihr Fenster über X11
(_NET_WM_PID, Name, Klasse) und setzt es mit QWindow.fromWinId in einen Container im eigenen Fenster. Unter Wayland oder ohne
python-xlib geht das nicht: available() sagt dann nein, und die Programme laufen in eigenen Fenstern."""
from __future__ import annotations

import os

try:
    from Xlib import X, display as xdisplay, error as xerror, protocol as xprotocol
    HAVE_XLIB = True
except ImportError:                       # pragma: no cover
    HAVE_XLIB = False


def available() -> bool:
    from PySide6.QtGui import QGuiApplication
    return HAVE_XLIB and QGuiApplication.platformName() == "xcb" and bool(os.environ.get("DISPLAY"))


class XWins:
    """Dünner Zugriff auf die obersten Fenster des X-Servers."""

    def __init__(self):
        self.d = xdisplay.Display()
        self.root = self.d.screen().root
        self.a_pid = self.d.intern_atom("_NET_WM_PID")
        self.a_list = self.d.intern_atom("_NET_CLIENT_LIST")
        self.a_name = self.d.intern_atom("_NET_WM_NAME")
        self.a_proto = self.d.intern_atom("WM_PROTOCOLS")
        self.a_delete = self.d.intern_atom("WM_DELETE_WINDOW")

    def _prop(self, win, atom, typ=X.AnyPropertyType):
        try:
            return win.get_full_property(atom, typ)
        except (xerror.BadWindow, xerror.XError):
            return None

    def toplevels(self) -> list[int]:
        ids: list[int] = []
        p = self._prop(self.root, self.a_list)
        if p is not None:
            ids += [int(v) for v in p.value]
        try:
            ids += [w.id for w in self.root.query_tree().children]
        except xerror.XError:
            pass
        seen, out = set(), []
        for i in ids:
            if i not in seen:
                seen.add(i)
                out.append(i)
        return out

    def info(self, wid: int) -> dict | None:
        w = self.d.create_resource_object("window", wid)
        try:
            attrs = w.get_attributes()
            if attrs.map_state != X.IsViewable:
                return None
            geo = w.get_geometry()
        except xerror.XError:
            return None
        pid = self._prop(w, self.a_pid)
        name = self._prop(w, self.a_name)
        if name is not None and name.value:
            nm = bytes(name.value).decode("utf-8", "replace")
        else:
            try:
                nm = w.get_wm_name() or ""
            except xerror.XError:
                nm = ""
        try:
            cls = w.get_wm_class() or ("", "")
        except xerror.XError:
            cls = ("", "")
        return {"id": wid, "pid": int(pid.value[0]) if pid is not None and len(pid.value) else 0, "name": nm,
                "cls": " ".join(cls), "w": geo.width, "h": geo.height}

    def current(self) -> dict[int, dict]:
        out = {}
        for i in self.toplevels():
            inf = self.info(i)
            if inf:
                out[i] = inf
        return out

    def request_close(self, wid: int) -> None:
        """Bittet das Fenster höflich, sich zu schließen (wie der Schließknopf), damit das Programm noch Rückfragen stellen kann."""
        w = self.d.create_resource_object("window", wid)
        ev = xprotocol.event.ClientMessage(window=w, client_type=self.a_proto, data=(32, [self.a_delete, X.CurrentTime, 0, 0, 0]))
        w.send_event(ev, event_mask=X.NoEventMask)
        self.d.flush()

    def alive(self, wid: int) -> bool:
        try:
            self.d.create_resource_object("window", wid).get_attributes()
            return True
        except xerror.XError:
            return False

    def close(self):
        try:
            self.d.close()
        except Exception:
            pass


def pick(cands: dict[int, dict], before: set[int], pid: int, token: str, own_pid: int) -> int | None:
    """Wählt aus den Fenstern das neue Fenster des gestarteten Programms: erst nach Prozessnummer, dann nach Namen oder Klasse."""
    new = {i: c for i, c in cands.items() if i not in before and c["pid"] != own_pid}
    for i, c in new.items():
        if pid and c["pid"] == pid:
            return i
    t = token.lower()
    for i, c in new.items():
        if t and (t in c["name"].lower() or t in c["cls"].lower()):
            return i
    return None
