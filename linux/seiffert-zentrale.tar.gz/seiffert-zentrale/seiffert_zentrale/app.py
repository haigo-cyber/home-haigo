"""Seifferts Zentrale: ein Fenster für alle Seiffert-Programme mit Qt-Oberfläche."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

from . import VERSION, designctl, embed, skins
from .programs import BY_ID, PROGRAMS, Program, archive_dir, autostart_ids, update_command

HERE = Path(__file__).resolve().parent
CONF = skins.config_dir().parent / "seiffert-zentrale"
START_TIMEOUT_MS = 20000


def load_settings() -> dict:
    try:
        d = json.loads((CONF / "settings.json").read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def save_settings(d: dict) -> None:
    try:
        CONF.mkdir(parents=True, exist_ok=True)
        (CONF / "settings.json").write_text(json.dumps(d, indent=1), encoding="utf-8")
    except OSError:
        pass


def main(argv=None) -> int:
    argv = list(sys.argv if argv is None else argv)
    from PySide6.QtCore import QByteArray, QEvent, QProcess, QProcessEnvironment, QSize, Qt, QTimer, QUrl
    from PySide6.QtGui import QAction, QColor, QDesktopServices, QFont, QGuiApplication, QIcon, QKeySequence, QPainter, QPixmap
    from PySide6.QtNetwork import QLocalServer, QLocalSocket
    from PySide6.QtWidgets import (QApplication, QComboBox, QDialog, QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QListWidget,
                                   QListWidgetItem, QMainWindow, QMessageBox, QPlainTextEdit, QPushButton, QScrollArea, QStackedWidget,
                                   QVBoxLayout, QWidget)
    from . import seiffert_design as design

    app = QApplication(argv)
    app.setApplicationName("seiffert-zentrale")
    app.setApplicationDisplayName("Seifferts Zentrale")
    app.setDesktopFileName("seiffert-zentrale")
    want = next((a for a in argv[1:] if a in BY_ID), None)

    sock_name = "seiffert-zentrale-%d" % (os.getuid() if hasattr(os, "getuid") else 0)
    c = QLocalSocket()
    c.connectToServer(sock_name)
    if c.waitForConnected(300):                        # läuft schon: nach vorn holen
        c.write(("show " + (want or "")).encode())
        c.flush()
        c.waitForBytesWritten(500)
        return 0
    QLocalServer.removeServer(sock_name)

    design.install(app)
    icon = QIcon()
    for n in (16, 22, 24, 32, 48, 64, 128, 256):
        p = HERE / "icons" / ("icon-%d.png" % n)
        if p.exists():
            icon.addFile(str(p))
    app.setWindowIcon(icon)

    def prog_icon(p: Program, size: int = 32) -> QIcon:
        ic = QIcon.fromTheme(p.icon)
        if not ic.isNull():
            return ic
        pm = QPixmap(size * 2, size * 2)
        pm.fill(Qt.GlobalColor.transparent)
        qp = QPainter(pm)
        qp.setRenderHint(QPainter.RenderHint.Antialiasing)
        cc = design.current(app)["colors"]
        qp.setBrush(QColor(cc["accent_soft"]))
        qp.setPen(QColor(cc["accent"]))
        qp.drawRoundedRect(3, 3, size * 2 - 6, size * 2 - 6, size * 0.4, size * 0.4)
        f = QFont()
        f.setBold(True)
        f.setPixelSize(int(size * 1.2))
        qp.setFont(f)
        qp.drawText(pm.rect(), Qt.AlignmentFlag.AlignCenter, p.name.split()[-1][0])
        qp.end()
        return QIcon(pm)

    # ------------------------------------------------------------------------------------------------ eine Programmseite
    class ProgramPage(QWidget):
        """Startet ein Programm und zeigt, wenn möglich, dessen Fenster eingebettet."""

        def __init__(self, prog: Program, hub: "Hub"):
            super().__init__()
            self.prog, self.hub = prog, hub
            self.proc: QProcess | None = None
            self.wid = 0
            self.external = False
            self.before: set[int] = set()
            self.waited = 0
            self.closing = False
            lay = QVBoxLayout(self)
            lay.setContentsMargins(0, 0, 0, 0)
            lay.setSpacing(0)
            bar = QFrame()
            bar.setObjectName("progbar")
            bl = QHBoxLayout(bar)
            bl.setContentsMargins(12, 6, 12, 6)
            self.title = QLabel("<b>%s</b>" % prog.name)
            self.status = QLabel("")
            self.status.setEnabled(False)
            bl.addWidget(self.title)
            bl.addWidget(self.status, 1)
            self.b_restart = QPushButton("Neu starten")
            self.b_close = QPushButton("Beenden")
            self.b_restart.clicked.connect(self.restart)
            self.b_close.clicked.connect(self.request_close)
            bl.addWidget(self.b_restart)
            bl.addWidget(self.b_close)
            lay.addWidget(bar)
            self.stack = QStackedWidget()
            lay.addWidget(self.stack, 1)
            self.msg = QLabel("")
            self.msg.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.msg.setWordWrap(True)
            self.msg.setTextFormat(Qt.TextFormat.RichText)
            self.msg.setOpenExternalLinks(False)
            self.stack.addWidget(self.msg)
            self.holder = QWidget()
            self.hl = QVBoxLayout(self.holder)
            self.hl.setContentsMargins(0, 0, 0, 0)
            self.stack.addWidget(self.holder)
            self.timer = QTimer(self)
            self.timer.setInterval(200)
            self.timer.timeout.connect(self.tick)
            self.watch = QTimer(self)
            self.watch.setInterval(1000)
            self.watch.timeout.connect(self.check_alive)
            self.show_idle()

        # --- Zustände
        @property
        def running(self) -> bool:
            return bool(self.wid) or self.external or self.timer.isActive() or (self.proc is not None and self.proc.state() != QProcess.ProcessState.NotRunning)

        def set_buttons(self):
            self.b_restart.setVisible(self.running)
            self.b_close.setVisible(self.running)
            self.hub.refresh_sidebar()

        def show_idle(self, text: str | None = None):
            self.wid = 0
            self.external = False
            self.watch.stop()
            if text is None:
                if self.prog.installed:
                    text = ("<h2>%s</h2><p>%s</p><p>Das Programm läuft nicht.</p>" % (self.prog.name, self.prog.desc))
                else:
                    text = ("<h2>%s</h2><p>Das Programm ist nicht installiert (Startbefehl %s fehlt).</p>"
                            "<p>Archiv in den Sammelordner legen und seiffert-update aufrufen, oder: seiffert install ARCHIV.</p>"
                            % (self.prog.name, self.prog.command))
            self.msg.setText(text)
            self.stack.setCurrentIndex(0)
            self.status.setText("")
            self.set_buttons()
            self.hub.idle_start_button(self)

        # --- Starten
        def start(self):
            if self.running:
                return
            path = self.prog.path()
            if not path:
                self.show_idle()
                return
            self.msg.setText("<h2>%s</h2><p>Wird gestartet …</p>" % self.prog.name)
            self.stack.setCurrentIndex(0)
            self.status.setText("startet")
            self.closing = False
            self.can_embed = embed.available() and self.hub.xw is not None
            self.before = set(self.hub.xw.current()) if self.can_embed else set()
            self.proc = QProcess(self)
            self.proc.setProcessChannelMode(QProcess.ProcessChannelMode.ForwardedChannels)
            self.proc.finished.connect(self.on_finished)
            self.proc.errorOccurred.connect(self.on_error)
            self.proc.start(path, list(self.prog.embed_args) if self.can_embed else [])
            self.waited = 0
            if self.can_embed:
                self.timer.start()
            else:
                self.external = True
                self.status.setText("läuft in eigenem Fenster")
                self.msg.setText("<h2>%s</h2><p>Das Programm läuft in einem eigenen Fenster (Einbetten geht nur unter X11 "
                                 "mit python-xlib).</p>" % self.prog.name)
                self.watch.start()
            self.set_buttons()

        def tick(self):
            self.waited += self.timer.interval()
            cands = self.hub.xw.current()
            wid = embed.pick(cands, self.before, self.proc.processId() if self.proc else 0, self.prog.token, os.getpid())
            if wid:
                self.timer.stop()
                self.attach(wid)
                return
            gone = self.proc is None or self.proc.state() == QProcess.ProcessState.NotRunning
            if self.waited >= START_TIMEOUT_MS or (gone and self.waited >= 3000):
                self.timer.stop()
                self.show_idle("<h2>%s</h2><p>Das Fenster des Programms wurde nicht gefunden. Es läuft vielleicht schon in einem "
                               "eigenen Fenster, oder der Start ist fehlgeschlagen (Meldungen stehen im Terminal, in dem die "
                               "Zentrale gestartet wurde).</p>" % self.prog.name)

        def attach(self, wid: int):
            from PySide6.QtGui import QWindow
            win = QWindow.fromWinId(wid)
            if win is None:
                self.show_idle("<h2>%s</h2><p>Das Fenster lässt sich nicht einbetten.</p>" % self.prog.name)
                return
            self.container = QWidget.createWindowContainer(win, self.holder)
            self.container.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
            self.hl.addWidget(self.container)
            self.wid = wid
            self.stack.setCurrentIndex(1)
            self.status.setText("eingebettet")
            self.watch.start()
            self.set_buttons()
            self.container.setFocus()

        def detach_container(self):
            c = getattr(self, "container", None)
            if c is not None:
                self.hl.removeWidget(c)
                c.setParent(None)
                c.deleteLater()
                self.container = None

        def check_alive(self):
            if self.wid and self.hub.xw is not None and not self.hub.xw.alive(self.wid):
                self.detach_container()
                self.on_ended()
            elif self.external and (self.proc is None or self.proc.state() == QProcess.ProcessState.NotRunning):
                self.on_ended()

        def on_finished(self, *_):
            if self.wid:                     # das Fenster kann einem anderen Prozess gehören (zweiter Start, der nur weiterreicht)
                return
            if self.external:
                self.on_ended()

        def on_error(self, *_):
            if not self.wid and not self.timer.isActive():
                self.on_ended("<h2>%s</h2><p>Der Start ist fehlgeschlagen.</p>" % self.prog.name)

        def on_ended(self, text: str | None = None):
            self.timer.stop()
            self.proc = None
            self.show_idle(text)
            if self.closing:
                self.closing = False
                self.hub.maybe_finish_closing()

        # --- Beenden
        def request_close(self):
            """Wie der Schließknopf des Programms: es darf noch nachfragen (ungespeichert) und kann ablehnen."""
            if self.wid and self.hub.xw is not None:
                self.closing = True
                self.hub.xw.request_close(self.wid)
            elif self.proc is not None:
                self.closing = True
                self.proc.terminate()

        def restart(self):
            if not self.running:
                self.start()
                return
            self.hub.statusBar_msg("%s: bitte zuerst beenden, dann neu starten." % self.prog.name)

    # ------------------------------------------------------------------------------------------------ Seite Update
    class UpdatePage(QWidget):
        def __init__(self, prog: Program, hub: "Hub"):
            super().__init__()
            self.prog, self.hub = prog, hub
            self.proc: QProcess | None = None
            lay = QVBoxLayout(self)
            lay.setContentsMargins(16, 14, 16, 14)
            lay.addWidget(QLabel("<h2>Seifferts Update</h2>"))
            self.info = QLabel("")
            self.info.setWordWrap(True)
            lay.addWidget(self.info)
            row = QHBoxLayout()
            self.b_list = QPushButton("Stand zeigen")
            self.b_dry = QPushButton("Probelauf")
            self.b_run = QPushButton("Jetzt aktualisieren")
            self.b_open = QPushButton("Sammelordner öffnen")
            for b in (self.b_list, self.b_dry, self.b_run, self.b_open):
                row.addWidget(b)
            row.addStretch(1)
            lay.addLayout(row)
            self.out = QPlainTextEdit()
            self.out.setReadOnly(True)
            f = QFont("monospace")
            f.setStyleHint(QFont.StyleHint.Monospace)
            self.out.setFont(f)
            lay.addWidget(self.out, 1)
            self.b_list.clicked.connect(lambda: self.run(["--liste"]))
            self.b_dry.clicked.connect(lambda: self.run(["--trocken"]))
            self.b_run.clicked.connect(self.go)
            self.b_open.clicked.connect(lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(archive_dir())))
            self.refresh()

        @property
        def running(self) -> bool:
            return self.proc is not None and self.proc.state() != QProcess.ProcessState.NotRunning

        def refresh(self):
            cmd = update_command()
            if cmd:
                self.info.setText("Neue Archive (seiffert-….tar.gz) in den Sammelordner <b>%s</b> legen, dann hier aktualisieren. "
                                  "Pro Programm zählt das neueste Archiv, unveränderte werden übersprungen." % archive_dir())
            else:
                self.info.setText("Der Befehl seiffert-update ist nicht installiert. Archiv seiffert-update.tar.gz auspacken und "
                                  "./install.sh ausführen.")
            for b in (self.b_list, self.b_dry, self.b_run):
                b.setEnabled(bool(cmd))

        def go(self):
            busy = [p.prog.name for p in self.hub.pages.values() if isinstance(p, ProgramPage) and p.running]
            if busy:
                r = QMessageBox.question(self, "Programme laufen", "Diese Programme laufen noch: %s.\nBeim Aktualisieren werden ihre Dateien "
                                         "ersetzt. Trotzdem aktualisieren?" % ", ".join(busy))
                if r != QMessageBox.StandardButton.Yes:
                    return
            self.run([])

        def run(self, args: list[str]):
            cmd = update_command()
            if not cmd or self.running:
                return
            self.out.clear()
            self.proc = QProcess(self)
            self.proc.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)
            env = QProcessEnvironment.systemEnvironment()
            env.insert("PYTHONUNBUFFERED", "1")
            self.proc.setProcessEnvironment(env)
            self.proc.readyReadStandardOutput.connect(lambda: self.out.appendPlainText(bytes(self.proc.readAllStandardOutput()).decode("utf-8", "replace").rstrip("\n")))
            self.proc.finished.connect(lambda code, *_: (self.out.appendPlainText("\n[beendet, Rückgabewert %d]" % code), self.hub.refresh_sidebar()))
            self.proc.start(cmd, args)
            self.hub.refresh_sidebar()

    # ------------------------------------------------------------------------------------------------ Startseite
    class HomePage(QScrollArea):
        def __init__(self, hub: "Hub"):
            super().__init__()
            self.hub = hub
            self.setWidgetResizable(True)
            self.setFrameShape(QFrame.Shape.NoFrame)
            self.cards: dict[str, QPushButton] = {}
            w = QWidget()
            self.setWidget(w)
            lay = QVBoxLayout(w)
            lay.setContentsMargins(24, 20, 24, 20)
            h = QLabel("<h1>Seifferts Zentrale</h1>")
            lay.addWidget(h)
            sub = QLabel("Alle Seiffert-Programme in einem Fenster. Auswahl links oder mit Strg+K; Strg+1 bis Strg+%d springt direkt." % len(PROGRAMS))
            sub.setEnabled(False)
            lay.addWidget(sub)
            groups: dict[str, list[Program]] = {}
            for p in PROGRAMS:
                groups.setdefault(p.group, []).append(p)
            for g, items in groups.items():
                lay.addSpacing(10)
                lab = QLabel("<b>%s</b>" % g)
                lay.addWidget(lab)
                grid = QGridLayout()
                grid.setSpacing(10)
                for i, p in enumerate(items):
                    b = QPushButton()
                    b.setObjectName("card")
                    b.setMinimumHeight(86)
                    b.setCursor(Qt.CursorShape.PointingHandCursor)
                    b.setIcon(prog_icon(p))
                    b.setIconSize(QSize(40, 40))
                    b.setText("%s\n%s" % (p.name, p.desc))
                    b.setStyleSheet("text-align:left; padding:10px 14px;")
                    b.clicked.connect(lambda _=False, pid=p.id: hub.show_program(pid))
                    grid.addWidget(b, i // 2, i % 2)
                    self.cards[p.id] = b
                lay.addLayout(grid)
            lay.addStretch(1)
            self.refresh()

        def refresh(self):
            for pid, b in self.cards.items():
                p = BY_ID[pid]
                b.setEnabled(p.installed)
                b.setToolTip("" if p.installed else "Nicht installiert (%s fehlt)" % p.command)

    # ------------------------------------------------------------------------------------------------ Befehlsfeld Strg+K
    class Palette(QDialog):
        def __init__(self, hub: "Hub"):
            super().__init__(hub)
            self.hub = hub
            self.setWindowTitle("Programm wählen")
            self.setModal(True)
            self.resize(420, 320)
            lay = QVBoxLayout(self)
            self.edit = QLineEdit()
            self.edit.setPlaceholderText("Programm eintippen …")
            self.lst = QListWidget()
            lay.addWidget(self.edit)
            lay.addWidget(self.lst)
            self.edit.textChanged.connect(self.fill)
            self.edit.returnPressed.connect(self.accept_sel)
            self.lst.itemActivated.connect(lambda *_: self.accept_sel())
            self.fill("")

        def fill(self, text: str):
            t = text.strip().lower()
            self.lst.clear()
            for p in PROGRAMS:
                if t in p.name.lower() or t in p.desc.lower():
                    it = QListWidgetItem(prog_icon(p), p.name + ("" if p.installed else "  (nicht installiert)"))
                    it.setData(Qt.ItemDataRole.UserRole, p.id)
                    self.lst.addItem(it)
            if self.lst.count():
                self.lst.setCurrentRow(0)

        def keyPressEvent(self, e):
            if e.key() in (Qt.Key.Key_Down, Qt.Key.Key_Up):
                self.lst.setFocus()
                self.lst.keyPressEvent(e)
                self.edit.setFocus()
                return
            super().keyPressEvent(e)

        def accept_sel(self):
            it = self.lst.currentItem()
            if it:
                pid = it.data(Qt.ItemDataRole.UserRole)
                self.accept()
                self.hub.show_program(pid, start=True)

    # ------------------------------------------------------------------------------------------------ Hauptfenster
    class Hub(QMainWindow):
        def __init__(self):
            super().__init__()
            self.setWindowTitle("Seifferts Zentrale")
            self.resize(1280, 820)
            self.xw = None
            if embed.available():
                try:
                    self.xw = embed.XWins()
                except Exception:
                    self.xw = None
            self.settings = load_settings()
            self.finishing = False
            central = QWidget()
            self.setCentralWidget(central)
            root = QHBoxLayout(central)
            root.setContentsMargins(0, 0, 0, 0)
            root.setSpacing(0)
            side = QFrame()
            side.setObjectName("side")
            side.setFixedWidth(232)
            sl = QVBoxLayout(side)
            sl.setContentsMargins(8, 10, 8, 10)
            head = QPushButton("  Seifferts Zentrale")
            head.setFlat(True)
            head.setIcon(self.windowIcon())
            head.setIconSize(QSize(26, 26))
            head.setStyleSheet("text-align:left; font-weight:bold; font-size:15px; border:0; padding:6px;")
            head.clicked.connect(lambda: self.pages_stack.setCurrentIndex(0) or self.lst.setCurrentRow(-1))
            sl.addWidget(head)
            self.lst = QListWidget()
            self.lst.setFrameShape(QFrame.Shape.NoFrame)
            self.lst.setIconSize(QSize(24, 24))
            self.lst.setSpacing(1)
            self.lst.setStyleSheet("QListWidget{background:transparent;} QListWidget::item{padding:6px 6px;border-radius:6px;} "
                                   "QListWidget::item:selected{background:palette(highlight);color:palette(highlighted-text);}")
            sl.addWidget(self.lst, 1)
            self.b_exit = QPushButton("Beenden  (Strg+Q)")
            self.b_exit.setToolTip("Zentrale und alle eingebetteten Programme schließen (mit Rückfrage bei ungespeicherter Arbeit)")
            self.b_exit.clicked.connect(self.close)
            sl.addWidget(self.b_exit)
            sl.addWidget(QLabel("<b>Design</b>"))
            self.cb_skin = QComboBox()
            self.cb_theme = QComboBox()
            for s in skins.SKINS:
                pm = QPixmap(14, 14)
                pm.fill(QColor(skins.SKIN_COL[s][0]))
                self.cb_skin.addItem(QIcon(pm), skins.LABELS[s], s)
            for t in skins.THEMES:
                self.cb_theme.addItem(skins.THEME_LABELS[t], t)
            sl.addWidget(self.cb_skin)
            sl.addWidget(self.cb_theme)
            ver = QLabel("Version %s" % VERSION)
            ver.setEnabled(False)
            sl.addWidget(ver)
            root.addWidget(side)
            self.pages_stack = QStackedWidget()
            root.addWidget(self.pages_stack, 1)
            self.home = HomePage(self)
            self.pages_stack.addWidget(self.home)
            self.pages: dict[str, QWidget] = {}
            self.items: dict[str, QListWidgetItem] = {}
            last_group = None
            for i, p in enumerate(PROGRAMS):
                if p.group != last_group:
                    h = QListWidgetItem(p.group.upper())
                    h.setFlags(Qt.ItemFlag.NoItemFlags)
                    f = h.font()
                    f.setPointSizeF(max(7.0, f.pointSizeF() - 1.5))
                    f.setBold(True)
                    h.setFont(f)
                    self.lst.addItem(h)
                    last_group = p.group
                page = UpdatePage(p, self) if p.panel else ProgramPage(p, self)
                self.pages[p.id] = page
                self.pages_stack.addWidget(page)
                it = QListWidgetItem(prog_icon(p), p.name)
                it.setData(Qt.ItemDataRole.UserRole, p.id)
                self.lst.addItem(it)
                self.items[p.id] = it
                act = QAction(self)
                act.setShortcut(QKeySequence("Ctrl+%d" % (i + 1)))
                act.triggered.connect(lambda _=False, pid=p.id: self.show_program(pid, start=True))
                self.addAction(act)
            a = QAction(self)
            a.setShortcut(QKeySequence("Ctrl+K"))
            a.triggered.connect(lambda: Palette(self).exec())
            self.addAction(a)
            a = QAction(self)
            a.setShortcut(QKeySequence("Ctrl+Q"))
            a.triggered.connect(self.close)
            self.addAction(a)
            a = QAction(self)
            a.setShortcut(QKeySequence("F11"))
            a.triggered.connect(lambda: self.showNormal() if self.isFullScreen() else self.showFullScreen())
            self.addAction(a)
            self.lst.currentItemChanged.connect(self.on_select)
            cur = design.current(app)
            self.cb_skin.setCurrentIndex(max(0, self.cb_skin.findData(cur["skin"])))
            self.cb_theme.setCurrentIndex(max(0, self.cb_theme.findData(cur["theme"])))
            self.cb_skin.activated.connect(self.on_design)
            self.cb_theme.activated.connect(self.on_design)
            design.on_change(self.on_design_changed)
            self.refresh_sidebar()
            geo = self.settings.get("geometry")
            if geo:
                try:
                    self.restoreGeometry(QByteArray.fromBase64(geo.encode()))
                except Exception:
                    pass

        # --- Seitenleiste
        def refresh_sidebar(self):
            for pid, it in self.items.items():
                p, page = BY_ID[pid], self.pages[pid]
                run = bool(getattr(page, "running", False))
                it.setText(p.name + ("   ●" if run else ""))
                f = it.font()
                f.setBold(run)
                it.setFont(f)
                it.setForeground(app.palette().windowText() if p.installed else app.palette().placeholderText())
                it.setIcon(prog_icon(p))
            self.home.refresh()

        def idle_start_button(self, page: ProgramPage):
            pass

        def statusBar_msg(self, text: str):
            self.statusBar().showMessage(text, 5000)

        def on_select(self, cur, _prev):
            if cur is None:
                return
            pid = cur.data(Qt.ItemDataRole.UserRole)
            if pid:
                self.show_program(pid, start=True)

        def show_program(self, pid: str, start: bool = False):
            page = self.pages[pid]
            self.pages_stack.setCurrentWidget(page)
            self.lst.blockSignals(True)
            self.lst.setCurrentItem(self.items[pid])
            self.lst.blockSignals(False)
            if isinstance(page, ProgramPage):
                if start and not page.running and page.prog.installed:
                    page.start()
                elif getattr(page, "container", None) is not None:
                    page.container.setFocus()

        # --- Design
        def on_design(self, *_):
            try:
                designctl.set_design(self.cb_skin.currentData(), self.cb_theme.currentData())
            except (ValueError, OSError) as e:
                self.statusBar_msg(str(e))
                return
            design.apply(app)

        def on_design_changed(self, cur):
            for cb, key in ((self.cb_skin, cur["skin"]), (self.cb_theme, cur["theme"])):
                i = cb.findData(key)
                if i >= 0 and cb.currentIndex() != i:
                    cb.blockSignals(True)
                    cb.setCurrentIndex(i)
                    cb.blockSignals(False)
            self.refresh_sidebar()

        # --- Schließen
        def running_pages(self) -> list[ProgramPage]:
            return [p for p in self.pages.values() if isinstance(p, ProgramPage) and p.running]

        def maybe_finish_closing(self):
            if self.finishing and not self.running_pages():
                self.close()

        def closeEvent(self, e):
            self.settings["geometry"] = bytes(self.saveGeometry().toBase64()).decode()
            save_settings(self.settings)
            busy = self.running_pages()
            if not busy:
                if self.xw:
                    self.xw.close()
                e.accept()
                return
            if self.finishing:
                r = QMessageBox.question(self, "Programme laufen noch", "Noch laufen: %s.\nTrotzdem beenden? Ungespeicherte Arbeit geht verloren."
                                         % ", ".join(p.prog.name for p in busy))
                if r == QMessageBox.StandardButton.Yes:
                    for p in busy:
                        if p.proc:
                            p.proc.kill()
                    self.finishing = False
                    if self.xw:
                        self.xw.close()
                    e.accept()
                    return
                self.finishing = False
                e.ignore()
                return
            self.finishing = True                           # die Programme schließen sich selbst (mit Rückfragen), dann folgt die Zentrale
            for p in busy:
                p.request_close()
            self.statusBar_msg("Die Programme werden geschlossen; die Zentrale folgt, sobald alle beendet sind.")
            e.ignore()

    hub = Hub()
    srv = QLocalServer()
    srv.listen(sock_name)

    def on_conn():
        s = srv.nextPendingConnection()
        if s is None:
            return
        s.waitForReadyRead(300)
        msg = bytes(s.readAll()).decode("utf-8", "replace").strip()
        s.disconnectFromServer()
        if msg.startswith("show"):
            hub.showNormal()
            hub.raise_()
            hub.activateWindow()
            pid = msg[4:].strip()
            if pid in BY_ID:
                hub.show_program(pid, start=True)

    srv.newConnection.connect(on_conn)
    hub.show()
    if want:
        QTimer.singleShot(100, lambda: hub.show_program(want, start=True))

    def autostart():                                   # Dateien (und was in settings.json unter autostart steht) läuft von Anfang an im Hintergrund
        for pid in autostart_ids(hub.settings):
            pg = hub.pages.get(pid)
            if pg is not None and not pg.running:
                pg.start()
        hub.refresh_sidebar()
    QTimer.singleShot(400, autostart)
    return app.exec()
