"""Verschlüsselte Tresore (zuluCrypt) öffnen und schließen, über das Programm zuluCrypt-cli."""
from __future__ import annotations

import os
import pty
import re
import select
import shutil
import subprocess
import threading
import time

import backend as B

AppError = B.AppError

_ANSI = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")
CLI_NAME = "zuluCrypt-cli"


def _clean(text: str) -> str:
    text = _ANSI.sub("", text).replace("\r", "")
    return "\n".join(l.rstrip() for l in text.split("\n") if l.strip())


def _mount_name(path: str) -> str:
    base = os.path.basename(path.rstrip("/")) or "tresor"
    name = re.sub(r"[^A-Za-z0-9._-]+", "_", base).strip("._") or "tresor"
    return name[:60]


class Vaults:
    def _vault_cli(self) -> str:
        cli = shutil.which(CLI_NAME)
        if not cli:
            raise AppError("zuluCrypt-cli ist nicht installiert. Installiere zuluCrypt (bei Arch das Paket zulucrypt aus dem AUR) und versuche es noch einmal.")
        return cli

    def _vault_reg(self) -> dict:
        reg = getattr(self, "_vault_registry", None)
        if reg is None:
            reg = self._vault_registry = {}
            self._vault_lock = threading.Lock()
        return reg

    @staticmethod
    def _vault_mount_guess(name: str) -> str:
        user = os.environ.get("USER") or os.environ.get("LOGNAME") or ""
        if not user:
            try:
                import pwd
                user = pwd.getpwuid(os.getuid()).pw_name
            except KeyError:
                user = str(os.getuid())
        return os.path.join("/run/media/private", user, name)

    def _vault_run_pty(self, argv: list[str], secret: str, timeout: float = 180.0) -> tuple[int, str]:
        """Startet zuluCrypt-cli mit eigenem Terminal und gibt die Passphrase erst nach der Eingabeaufforderung ein, so steht sie nie in der Prozessliste."""
        pid, fd = pty.fork()
        if pid == 0:
            try:
                os.execv(argv[0], argv)
            finally:
                os._exit(127)
        buf = b""
        sent = False
        status = None
        end = time.monotonic() + timeout
        try:
            while True:
                left = end - time.monotonic()
                if left <= 0:
                    os.kill(pid, 15)
                    os.waitpid(pid, 0)
                    status = -1
                    break
                r, _, _ = select.select([fd], [], [], min(left, 1.0))
                if r:
                    try:
                        chunk = os.read(fd, 4096)
                    except OSError:
                        break
                    if not chunk:
                        break
                    buf += chunk
                    if not sent and b"assphrase" in buf:
                        os.write(fd, secret.encode("utf-8") + b"\n")
                        sent = True
                        buf = b""
                else:
                    done, st = os.waitpid(pid, os.WNOHANG)
                    if done:
                        status = st
                        break
        finally:
            try:
                os.close(fd)
            except OSError:
                pass
        if status == -1:
            raise AppError("Zeitüberschreitung beim Öffnen des Tresors.")
        if status is None:
            _p, status = os.waitpid(pid, 0)
        rc = os.waitstatus_to_exitcode(status)
        text = buf.decode("utf-8", "replace")
        if secret:
            text = text.replace(secret, "")      # das Terminal kann die Eingabe zurückspiegeln
        return rc, _clean(text)

    def api_vault_open(self, path: str, passphrase: str = "", keyfile: str = "", rw: bool = True, vtype: str = "") -> dict:
        cli = self._vault_cli()
        reg = self._vault_reg()
        p = B.norm_path(path)
        if not os.path.isfile(p) and not p.startswith("/dev/"):
            raise AppError("Die Tresordatei existiert nicht: " + p)
        if vtype not in ("", "luks", "vera"):
            raise AppError("Unbekannter Tresortyp.")
        keyfile = B.norm_path(keyfile) if keyfile.strip() else ""
        if not passphrase and not keyfile:
            raise AppError("Bitte Passphrase eingeben oder eine Schlüsseldatei angeben.")
        if keyfile and not os.path.isfile(keyfile):
            raise AppError("Die Schlüsseldatei existiert nicht.")
        with self._vault_lock:
            if p in reg and os.path.ismount(reg[p]["mount"]):
                raise AppError("Dieser Tresor ist schon geöffnet.")
        name = _mount_name(p)
        argv = [cli, "-o", "-d", p, "-m", name, "-e", "rw" if rw else "ro"]
        if vtype == "vera":
            argv += ["-t", "vera"]
        if keyfile:
            argv += ["-f", keyfile]
            r = subprocess.run(argv, capture_output=True, text=True, timeout=180, stdin=subprocess.DEVNULL)
            rc, out = r.returncode, _clean((r.stdout or "") + "\n" + (r.stderr or ""))
        else:
            argv.append("-h")
            rc, out = self._vault_run_pty(argv, passphrase)
        mount = self._vault_mount_guess(name)
        if rc != 0 or not os.path.ismount(mount):
            found = [v for v in self._vault_parse_list() if v["mount"].rstrip("/").endswith("/" + name)]
            if rc == 0 and found:
                mount = found[0]["mount"]
            else:
                raise AppError("Tresor konnte nicht geöffnet werden" + (": " + " – ".join(out.splitlines()[-3:]) if out else " (Passphrase oder Schlüsseldatei falsch?)"))
        with self._vault_lock:
            reg[p] = {"mount": mount, "name": name, "rw": bool(rw)}
        return {"mount": mount, "name": name, "rw": bool(rw)}

    def _vault_parse_list(self) -> list[dict]:
        cli = shutil.which(CLI_NAME)
        if not cli:
            return []
        try:
            r = subprocess.run([cli, "-L"], capture_output=True, text=True, timeout=15, stdin=subprocess.DEVNULL)
        except (OSError, subprocess.SubprocessError):
            return []
        out = []
        for line in (r.stdout or "").splitlines():
            m = re.search(r"(/(?:run/media|media|mnt)/\S+)", line)
            parts = line.split()
            if m and parts:
                out.append({"device": parts[0], "mount": m.group(1).rstrip("/")})
        return out

    def api_vault_list(self) -> dict:
        reg = self._vault_reg()
        items, seen = [], set()
        with self._vault_lock:
            for p, v in list(reg.items()):
                if os.path.ismount(v["mount"]):
                    items.append({"path": p, "mount": v["mount"], "name": v["name"], "rw": v["rw"]})
                    seen.add(v["mount"])
                else:
                    reg.pop(p, None)
        for v in self._vault_parse_list():
            if v["mount"] not in seen and os.path.ismount(v["mount"]):
                items.append({"path": v["device"], "mount": v["mount"], "name": os.path.basename(v["mount"]), "rw": None})
        return {"vaults": items, "available": bool(shutil.which(CLI_NAME))}

    def api_vault_close(self, path: str) -> dict:
        cli = self._vault_cli()
        reg = self._vault_reg()
        p = B.norm_path(path) if path.startswith("/") else path
        mount = ""
        with self._vault_lock:
            if p in reg:
                mount = reg[p]["mount"]
        if mount:
            os.sync()
        r = subprocess.run([cli, "-q", "-d", p], capture_output=True, text=True, timeout=60, stdin=subprocess.DEVNULL)
        if r.returncode != 0:
            msg = _clean((r.stdout or "") + "\n" + (r.stderr or ""))
            raise AppError("Tresor konnte nicht geschlossen werden" + (": " + " – ".join(msg.splitlines()[-3:]) if msg else ". Ist noch eine Datei darin geöffnet?"))
        with self._vault_lock:
            reg.pop(p, None)
        return {"closed": True}
