"""Zuschnitt in Seifferts Text: Kern ohne Oberfläche (Textrahmen, Einbrennen in PDF und Bild, Speichern, Teilen, Zusammenfügen).
Die Einstellungen des früheren eigenständigen Programms (~/.config/seiffert-zuschnitt) werden nur noch einmal als Vorgabe gelesen."""
import copy
import json
import os
import shutil
import subprocess
from dataclasses import dataclass, field

import pymupdf

CFG_DIR = os.path.join(os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")), "seiffert-zuschnitt")
CFG_FILE = os.path.join(CFG_DIR, "settings.json")
DEFAULTS = {"save_dir": "", "open_dir": "", "backup": True}

FONT_NAMES = {"sans": "Sans (Helvetica)", "serif": "Serif (Times)", "mono": "Mono (Courier)"}
BASE14 = {("sans", False): "helv", ("sans", True): "hebo",
          ("serif", False): "tiro", ("serif", True): "tibo",
          ("mono", False): "cour", ("mono", True): "cobo"}
FC_FAMILY = {"sans": "Liberation Sans", "serif": "Liberation Serif", "mono": "Liberation Mono"}


def load_settings(path=None):
    s = dict(DEFAULTS)
    try:
        with open(path or CFG_FILE, encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            for k in DEFAULTS:
                if k in data and isinstance(data[k], type(DEFAULTS[k])):
                    s[k] = data[k]
    except (OSError, ValueError):
        pass
    return s


def save_settings(s, path=None):
    path = path or CFG_FILE
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(s, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


@dataclass
class TextItem:
    x: float
    y: float
    w: float
    h: float
    text: str = ""
    size: float = 12.0
    font: str = "sans"
    bold: bool = False
    color: str = "#000000"
    align: int = 0          # 0 links, 1 Mitte, 2 rechts
    bg: bool = False        # weißer Hintergrund
    is_image = False

    def rect(self):
        return (self.x, self.y, self.x + self.w, self.y + self.h)


@dataclass
class ImageItem(TextItem):
    """Eingefügte Grafik oder PDF-Ausschnitt (Überlagerung, wird erst beim Speichern eingebrannt)."""
    src: str = "img"        # img: data ist PNG/JPEG-Datei; pdf: data ist eine einseitige PDF (Vektor)
    data: bytes = b""
    clip: tuple = None      # nur pdf: Ausschnitt (x0, y0, x1, y1) in Seitenmaßen der einseitigen PDF
    aspect: float = 1.0     # Breite / Höhe, beim Skalieren fest
    label: str = ""
    is_image = True


def copy_items(d):
    return {k: [copy.copy(i) for i in v] for k, v in d.items()}


def subst(text, page_no, page_count):
    return text.replace("{seite}", str(page_no + 1)).replace("{seiten}", str(page_count))


def hex_to_rgb01(h):
    h = h.lstrip("#")
    try:
        return tuple(int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4))
    except ValueError:
        return (0, 0, 0)


_font_file_cache = {}


def unicode_font_file(font, bold):
    """Pfad einer installierten TrueType-Schrift (für Zeichen außerhalb der Standardschrift)."""
    key = (font, bold)
    if key in _font_file_cache:
        return _font_file_cache[key]
    path = None
    for fam in (FC_FAMILY[font], "DejaVu " + {"sans": "Sans", "serif": "Serif", "mono": "Sans Mono"}[font]):
        try:
            out = subprocess.run(["fc-match", "-f", "%{file}", fam + (":bold" if bold else "")],
                                 capture_output=True, text=True, timeout=5).stdout.strip()
        except (OSError, subprocess.SubprocessError):
            out = ""
        if out and os.path.isfile(out) and out.lower().endswith((".ttf", ".otf")):
            path = out
            break
    _font_file_cache[key] = path
    return path


def needs_unicode(text, base_name):
    try:
        f = pymupdf.Font(base_name)
    except Exception:
        return False
    # Die eingebaute Schrift wird als Latin-1 kodiert: alles darüber (zum Beispiel €) braucht eine echte Schrift.
    return any(ch not in "\n\r\t" and (ord(ch) > 255 or not f.has_glyph(ord(ch))) for ch in text)


def burn_pdf(doc, items_by_page):
    """Schreibt die Textrahmen in die Seiten von doc. Gibt Liste von Hinweisen zurück."""
    notes = []
    n = doc.page_count
    for pno, lst in items_by_page.items():
        if not lst or pno >= n:
            continue
        page = doc[pno]
        rot = page.rotation
        for it in lst:
            if it.is_image:
                full = pymupdf.Rect(*it.rect())
                if (full & page.rect).is_empty:
                    notes.append(f"Seite {pno + 1}: Grafik liegt außerhalb der Seite und wurde ausgelassen.")
                    continue
                ur = draw_rect_for(page, full)
                try:
                    if it.src == "pdf":
                        sd = pymupdf.open("pdf", it.data)
                        try:
                            page.show_pdf_page(ur, sd, 0, clip=pymupdf.Rect(*it.clip), rotate=rot)
                        finally:
                            sd.close()
                    else:
                        page.insert_image(ur, stream=it.data, rotate=rot, keep_proportion=False)
                except Exception as ex:  # noqa: BLE001
                    notes.append(f"Seite {pno + 1}: Grafik konnte nicht eingefügt werden ({ex}).")
                continue
            txt = subst(it.text, pno, n)
            vr = pymupdf.Rect(*it.rect()) & page.rect
            if vr.is_empty:
                notes.append(f"Seite {pno + 1}: Textrahmen liegt außerhalb der Seite und wurde ausgelassen.")
                continue
            ur = draw_rect_for(page, vr)
            if it.bg:
                page.draw_rect(ur, color=None, fill=(1, 1, 1))
            if not txt.strip():
                continue
            base = BASE14[(it.font, it.bold)]
            kw = {"fontname": base}
            if needs_unicode(txt, base):
                ff = unicode_font_file(it.font, it.bold)
                if ff:
                    kw = {"fontname": "SZ" + base, "fontfile": ff}
                else:
                    notes.append(f"Seite {pno + 1}: Zeichen außerhalb der Standardschrift, keine passende Schrift installiert.")
            size = float(it.size)
            col = hex_to_rgb01(it.color)
            ok = False
            while size >= 3:
                rc = page.insert_textbox(ur, txt, fontsize=size, color=col, align=it.align, rotate=rot, **kw)
                if rc >= 0:
                    ok = True
                    break
                size *= 0.93
            if not ok:
                notes.append(f"Seite {pno + 1}: Text passt nicht in den Rahmen und fehlt.")
            elif size < it.size - 0.01:
                notes.append(f"Seite {pno + 1}: Schrift wurde auf {size:.1f} pt verkleinert, damit der Text passt.")
    return notes


def draw_rect_for(page, vrect):
    """Rechteck aus der Ansicht (sichtbare Seite, y nach unten, Ursprung oben links) in die Koordinaten,
    die die Einfügefunktionen von PyMuPDF (draw_rect, insert_textbox, insert_image, show_pdf_page) erwarten.
    PyMuPDF rechnet bei gedrehten Seiten mit abweichendem Ursprung (transformation_matrix berücksichtigt den
    Ursprung der CropBox nicht), deshalb wird über PDF-Koordinaten gerechnet."""
    doc = page.parent
    cx0, cy0, cx1, cy1 = raw_box(doc, page, "CropBox")
    ur = pymupdf.Rect(vrect) * page.derotation_matrix
    ur.normalize()
    p0 = pymupdf.Point(cx0 + ur.x0, cy1 - ur.y0) * page.transformation_matrix
    p1 = pymupdf.Point(cx0 + ur.x1, cy1 - ur.y1) * page.transformation_matrix
    r = pymupdf.Rect(p0, p1)
    r.normalize()
    return r


def pdf_source_item(path, pno, clip, pdf_bytes=None):
    """Ausschnitt aus einer PDF-Seite als ImageItem-Quelle. Gibt (src, data, clip, aspect, hinweis) zurück.
    Ohne Seitendrehung bleibt der Ausschnitt Vektor (einseitige PDF); gedrehte Quellseiten werden
    als PNG mit etwa 300 dpi übernommen, weil PyMuPDF dort die Drehung nicht übernimmt."""
    doc = pymupdf.open(path) if pdf_bytes is None else pymupdf.open("pdf", pdf_bytes)
    try:
        page = doc[pno]
        cl = pymupdf.Rect(*clip) & page.rect if clip else pymupdf.Rect(page.rect)
        if cl.is_empty or cl.width < 1 or cl.height < 1:
            raise ValueError("leerer Ausschnitt")
        if page.rotation == 0:
            one = pymupdf.open()
            one.insert_pdf(doc, from_page=pno, to_page=pno)
            data = one.tobytes(garbage=3, deflate=True)
            one.close()
            return "pdf", data, (cl.x0, cl.y0, cl.x1, cl.y1), cl.width / cl.height, ""
        scale = min(300 / 72.0, 5000.0 / max(cl.width, cl.height))
        pix = page.get_pixmap(matrix=pymupdf.Matrix(scale, scale), clip=cl, alpha=False)
        return "img", pix.tobytes("png"), None, cl.width / cl.height, "gedrehte Seite, als Bild übernommen"
    finally:
        doc.close()


def raw_box(doc, page, key="CropBox"):
    """Rechteck (x0, y0, x1, y1) einer Seitenbox in PDF-Koordinaten (y nach oben)."""
    for k in (key, "MediaBox"):
        t, v = doc.xref_get_key(page.xref, k)
        if t == "array":
            n = [float(x) for x in v.strip("[]").split()]
            return min(n[0], n[2]), min(n[1], n[3]), max(n[0], n[2]), max(n[1], n[3])
    r = page.mediabox
    return r.x0, r.y0, r.x1, r.y1


def extend_pdf_page(doc, pno, left, top, right, bottom):
    """Vergrößert die sichtbare Seite um weiße Ränder (in pt, in der angezeigten Ausrichtung).
    Inhalt außerhalb des alten Ausschnitts (früher abgeschnitten) wird mit Weiß überdeckt.
    Danach verschiebt sich der Ursprung der Ansicht um (left, top)."""
    page = doc[pno]
    W, H = page.rect.width, page.rect.height
    cx0, cy0, cx1, cy1 = raw_box(doc, page, "CropBox")
    mx0, my0, mx1, my1 = raw_box(doc, page, "MediaBox")
    # 1. weiße Streifen im alten Koordinatensystem außerhalb der alten Seite zeichnen (deckt auch früher
    #    abgeschnittenen Inhalt ab); das ist verlässlicher als nach dem Ändern der Boxen zu zeichnen
    strips = []
    if top > 0:
        strips.append(pymupdf.Rect(-left, -top, W + right, 0))
    if bottom > 0:
        strips.append(pymupdf.Rect(-left, H, W + right, H + bottom))
    if left > 0:
        strips.append(pymupdf.Rect(-left, 0, 0, H))
    if right > 0:
        strips.append(pymupdf.Rect(W, 0, W + right, H))
    for s in strips:
        page.draw_rect(draw_rect_for(page, s), color=None, fill=(1, 1, 1))
    # 2. Boxen vergrößern
    ur = pymupdf.Rect(-left, -top, W + right, H + bottom) * page.derotation_matrix
    ur.normalize()
    nx0, nx1 = cx0 + ur.x0, cx0 + ur.x1
    ny1, ny0 = cy1 - ur.y0, cy1 - ur.y1
    new = "[%g %g %g %g]" % (nx0, ny0, nx1, ny1)
    med = "[%g %g %g %g]" % (min(mx0, nx0), min(my0, ny0), max(mx1, nx1), max(my1, ny1))
    doc.xref_set_key(page.xref, "MediaBox", med)
    for key in ("CropBox", "TrimBox", "BleedBox", "ArtBox"):
        doc.xref_set_key(page.xref, key, new)
    page = doc[pno]
    return page.rect.width, page.rect.height


def fix_boxes(doc):
    """Setzt MediaBox (und Trim/Bleed/Art) auf den sichtbaren Ausschnitt, damit auch
    Programme, die nur die MediaBox lesen (z. B. poppler-Voransichten), den Zuschnitt zeigen."""
    for page in doc:
        cb = page.cropbox_position
        r = page.cropbox  # y-nach-unten, relativ zur linken oberen Ecke der MediaBox
        mb = page.mediabox
        if abs(cb.x) < 1e-6 and abs(cb.y) < 1e-6 and abs(r.width - mb.width) < 1e-6 and abs(r.height - mb.height) < 1e-6:
            continue
        xref = page.xref
        # Rechteck in PDF-Koordinaten (y nach oben) aus der Roh-CropBox lesen
        t, v = doc.xref_get_key(xref, "CropBox")
        if t != "array":
            continue
        nums = [float(x) for x in v.strip("[]").split()]
        x0, y0, x1, y1 = min(nums[0], nums[2]), min(nums[1], nums[3]), max(nums[0], nums[2]), max(nums[1], nums[3])
        arr = "[%g %g %g %g]" % (x0, y0, x1, y1)
        for key in ("MediaBox", "CropBox", "TrimBox", "BleedBox", "ArtBox"):
            doc.xref_set_key(xref, key, arr)


def save_pdf(doc, items_by_page, path, backup, keep_pages=None):
    """doc bleibt unverändert; gespeichert wird eine Kopie mit Textrahmen. Gibt Hinweise zurück.
    keep_pages: Liste der Seitennummern (ab 0), die in der Ausgabe bleiben; None = alle."""
    work = pymupdf.open("pdf", doc.tobytes())
    notes = burn_pdf(work, items_by_page)
    fix_boxes(work)
    if keep_pages:
        work.select([p for p in keep_pages if 0 <= p < work.page_count])
    tmp = path + ".zuschnitt-tmp"
    work.save(tmp, garbage=1, deflate=True)
    work.close()
    finish_write(tmp, path, backup)
    return notes


def split_pdf(doc, items_by_page, folder, stem):
    """Jede Seite als eigene PDF (mit Textrahmen und Zuschnitt der Sitzung). Überschreibt nie etwas:
    gibt es schon Dateien gleichen Namens, wird der Satz mit -2, -3 ... benannt. Gibt (Pfade, Hinweise) zurück."""
    work = pymupdf.open("pdf", doc.tobytes())
    notes = burn_pdf(work, items_by_page)
    fix_boxes(work)
    n = work.page_count
    width = max(2, len(str(n)))
    k = 1
    while True:
        base = stem if k == 1 else f"{stem}-{k}"
        paths = [os.path.join(folder, f"{base}-Seite-{i + 1:0{width}d}.pdf") for i in range(n)]
        if not any(os.path.exists(p) for p in paths):
            break
        k += 1
    for i, path in enumerate(paths):
        one = pymupdf.open()
        one.insert_pdf(work, from_page=i, to_page=i)
        tmp = path + ".zuschnitt-tmp"
        one.save(tmp, garbage=3, deflate=True)
        one.close()
        os.replace(tmp, path)
    work.close()
    return paths, notes


def pdf_info(path):
    """(Seitenzahl, Fehlertext oder None) für eine PDF-Datei."""
    try:
        d = pymupdf.open(path)
        try:
            if not d.is_pdf:
                return 0, "keine PDF-Datei"
            if d.needs_pass:
                return 0, "passwortgeschützt"
            if d.page_count < 1:
                return 0, "keine Seiten"
            return d.page_count, None
        finally:
            d.close()
    except Exception as e:  # noqa: BLE001
        return 0, str(e)


def merge_pdfs(paths, out_path):
    """Fügt die PDFs in der Reihenfolge der Liste zu einer Datei zusammen (atomar geschrieben).
    Die Quelldateien bleiben unverändert. Gibt die Seitenzahl zurück."""
    out = pymupdf.open()
    try:
        for p in paths:
            src = pymupdf.open(p)
            try:
                if not src.is_pdf or src.needs_pass or src.page_count < 1:
                    raise ValueError(f"{os.path.basename(p)}: nicht verwendbar (keine PDF, passwortgeschützt oder leer)")
                out.insert_pdf(src)
            finally:
                src.close()
        n = out.page_count
        tmp = out_path + ".zuschnitt-tmp"
        out.save(tmp, garbage=3, deflate=True)
    finally:
        out.close()
    os.replace(tmp, out_path)
    return n


def finish_write(tmp, path, backup):
    if backup and os.path.exists(path):
        shutil.copy2(path, path + ".bak")
    os.replace(tmp, path)


def read_image_meta(path):
    """dpi und ICC-Profil des Originals (für das Zurückschreiben)."""
    meta = {"dpi": None, "icc": None}
    try:
        from PIL import Image
        with Image.open(path) as im:
            dpi = im.info.get("dpi")
            if dpi and len(dpi) == 2 and dpi[0] and dpi[1]:
                meta["dpi"] = (float(dpi[0]), float(dpi[1]))
            meta["icc"] = im.info.get("icc_profile")
    except Exception:
        pass
    return meta


def write_image(qimg, path, backup, meta=None):
    """Speichert in voller Pixelgröße. JPEG: Qualität 100, keine Farbunterabtastung. PNG: verlustfrei."""
    from PySide6.QtGui import QImage
    meta = meta or {}
    ext = os.path.splitext(path)[1].lower()
    tmp = path + ".zuschnitt-tmp"
    try:
        from PIL import Image
        has_alpha = qimg.hasAlphaChannel() and ext == ".png"
        if has_alpha:
            q = qimg.convertToFormat(QImage.Format_RGBA8888)
            im = Image.frombuffer("RGBA", (q.width(), q.height()), bytes(q.constBits()), "raw", "RGBA", q.bytesPerLine(), 1)
        else:
            q = qimg.convertToFormat(QImage.Format_RGB888)
            im = Image.frombuffer("RGB", (q.width(), q.height()), bytes(q.constBits()), "raw", "RGB", q.bytesPerLine(), 1)
        extra = {}
        if meta.get("dpi"):
            extra["dpi"] = meta["dpi"]
        if meta.get("icc"):
            extra["icc_profile"] = meta["icc"]
        if ext in (".jpg", ".jpeg"):
            im.save(tmp, "JPEG", quality=100, subsampling=0, optimize=True, **extra)
        else:
            im.save(tmp, "PNG", compress_level=6, **extra)
    except ImportError:
        fmt = "JPG" if ext in (".jpg", ".jpeg") else "PNG"
        if not qimg.save(tmp, fmt, 100 if fmt == "JPG" else -1):
            raise OSError("Bild konnte nicht geschrieben werden")
    finish_write(tmp, path, backup)
