#!/usr/bin/env bash
# Entfernt das Programm. Deine Daten (Dokumente/Seifferts Konten) bleiben immer erhalten.
# Mit "./uninstall.sh --alles" werden zusaetzlich die Einstellungen und das Protokoll geloescht.
set -u
DATA="${XDG_DATA_HOME:-$HOME/.local/share}/seiffert-konten"
CONF="${XDG_CONFIG_HOME:-$HOME/.config}/seiffert-konten"
chmod -R u+w "$DATA/app" "$DATA/venv" 2>/dev/null || true
rm -rf "$DATA/app" "$DATA/venv"
rm -f "$HOME/.local/bin/seiffert-konten"
rm -f "${XDG_DATA_HOME:-$HOME/.local/share}/applications/seiffert-konten.desktop"
rm -f "${XDG_DATA_HOME:-$HOME/.local/share}/icons/hicolor/256x256/apps/seiffert-konten.png"
update-desktop-database "${XDG_DATA_HOME:-$HOME/.local/share}/applications" >/dev/null 2>&1 || true
if [ "${1:-}" = "--alles" ]; then rm -rf "$DATA" "$CONF"; echo "Einstellungen und Protokoll geloescht."; fi
echo "Seifferts Konten wurde entfernt. Der Ordner Dokumente/Seifferts Konten mit deinen Daten ist unveraendert."
