"""Testlauf für Seifferts Text (ohne Bildschirm):  QT_QPA_PLATFORM=offscreen python tests/run_tests.py
Benötigt für einzelne Prüfungen pdflatex und LibreOffice (fehlen sie, werden die Prüfungen übersprungen)."""
import os
import shutil
import subprocess
import sys
import tempfile

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from PySide6.QtCore import QEventLoop, QTimer
from PySide6.QtGui import QColor, QImage, QTextCursor
from PySide6.QtWidgets import QApplication

app = QApplication([])
from seiffert_text.app import MainWindow, VIEW_MD, VIEW_RICH, VIEW_TEX
from seiffert_text.builder import build_document
from seiffert_text.latex_in import parse_latex
from seiffert_text.latex_out import export_latex
from seiffert_text.odt_out import write_odt
from seiffert_text.readers import find_soffice, read_any

TMP = tempfile.mkdtemp(prefix="st-test-")
import seiffert_text.app as _app_mod
_app_mod.CONF_DIR = TMP                       # die Einstellungen des Benutzers bleiben unberührt
_app_mod.CONF_FILE = os.path.join(TMP, "settings.json")
OK = FAIL = SKIP = 0


def check(name, cond, extra=""):
    global OK, FAIL
    if cond:
        OK += 1
    else:
        FAIL += 1
        print("FEHLER:", name, extra)


def body(t):
    return t[t.index("\\begin{document}"):]


def pump(ms=200):
    l = QEventLoop()
    QTimer.singleShot(ms, l.quit)
    l.exec()


SRC = r"""\section{Titel}
\subsection*{Ohne Nummer}
Text mit \textbf{fett}, \emph{kursiv}, \underline{unter}, x\textsuperscript{2}, \texttt{Code} und \href{https://example.org}{Link}\footnote{Fußnote 50\%.}.
Neue Zeile\\
nach Umbruch, M\"uller und $a^2+b^2$.

\begin{itemize}
\item Eins
\item Zwei
 \begin{enumerate}
 \item A
 \item B
 \end{enumerate}
\item Drei
\end{itemize}

\begin{center}
\begin{tabular}{|l|l|}
\hline
x & y \\
\hline
\multicolumn{2}{|l|}{Verbunden} \\
\hline
1 & 2 \\
\hline
\end{tabular}
\end{center}
\begin{quote}Ein Zitat\end{quote}
\begin{verbatim}
print("hi")
\end{verbatim}
\[ E = mc^2 \]
\begin{figure}[h]\caption{Unbekannt}\end{figure}
"""

# 1. LaTeX -> Dokument -> LaTeX ist stabil
pre, blocks = parse_latex(SRC)
doc = build_document(blocks)
t1, _ = export_latex(doc, pre)
pre2, b2 = parse_latex(t1)
t2, _ = export_latex(build_document(b2), pre2)
check("LaTeX-Rundlauf stabil", t1 == t2)
check("Rohtext bleibt (Formel, figure)", "\\[ E = mc^2 \\]" in t1 and "\\caption{Unbekannt}" in t1)
check("Fußnote bleibt", "\\footnote{Fußnote 50\\%.}" in t1)
check("Umlaut umgewandelt", "Müller" in t1)

# 2. ODT: schreiben, lesen, gleiche LaTeX-Ausgabe
write_odt(doc, os.path.join(TMP, "a.odt"))
r = read_any(os.path.join(TMP, "a.odt"))
t3, _ = export_latex(build_document(r.blocks), pre)
check("ODT-Rundlauf gleich", body(t3) == body(t1), "\n".join(__import__("difflib").unified_diff(body(t1).splitlines(), body(t3).splitlines(), lineterm="")))

# 3. Fremdformate über LibreOffice erzeugen und lesen
if find_soffice():
    for ext in ("docx", "doc", "rtf"):
        subprocess.run([find_soffice(), "-env:UserInstallation=file:///tmp/st-lo", "--headless", "--convert-to", ext,
                        "--outdir", TMP, os.path.join(TMP, "a.odt")], capture_output=True, timeout=240)
        p = os.path.join(TMP, "a." + ext)
        if os.path.exists(p):
            tt, _ = export_latex(build_document(read_any(p).blocks))
            check("%s: Überschrift, fett, Liste, Tabelle" % ext, all(k in tt for k in
                  ("\\section{Titel}", "\\textbf{fett}", "\\begin{itemize}", "\\begin{tabular}", "\\multicolumn{2}")))
        else:
            check("%s erzeugt" % ext, False)
else:
    SKIP += 1

# 4. Tabellenkalkulation
try:
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Umsatz"
    ws.append(["Monat", "Betrag"])
    ws.append(["Jan", 1234.5])
    ws["B2"].number_format = '#,##0.00 "€"'
    wb.save(os.path.join(TMP, "t.xlsx"))
    tt, _ = export_latex(build_document(read_any(os.path.join(TMP, "t.xlsx")).blocks))
    check("xlsx: Blatt und Zahlenformat", "\\subsection{Umsatz}" in tt and "1.234,50 €" in tt)
    if find_soffice():
        for ext in ("ods", "xls"):
            subprocess.run([find_soffice(), "-env:UserInstallation=file:///tmp/st-lo", "--headless", "--convert-to", ext,
                            "--outdir", TMP, os.path.join(TMP, "t.xlsx")], capture_output=True, timeout=240)
            tt, _ = export_latex(build_document(read_any(os.path.join(TMP, "t." + ext)).blocks))
            check(ext + ": Tabelle", "\\begin{tabular}" in tt and "Jan" in tt)
except ImportError:
    SKIP += 1

# 5. Oberfläche: Ansichten, Umwandlung, Übersetzen
w = MainWindow()
w.show()
w.rich.textCursor().insertText("Hallo")
w.set_para(1)
w.set_view(VIEW_MD)
check("Markdown aus Formatiert", w.md_edit.toPlainText().startswith("# Hallo"))
w.md_edit.setPlainText("# Neu\n\nText *kursiv*\n\n- a\n- b\n")
w.set_view(VIEW_TEX)
check("LaTeX aus Markdown", "\\section{Neu}" in w.tex_edit.toPlainText() and "\\textit{kursiv}" in w.tex_edit.toPlainText())
w.tex_edit.setPlainText(w.tex_edit.toPlainText().replace("Text", "Text $x^2$ \\newpage"))
w.set_view(VIEW_RICH)
w.set_view(VIEW_TEX)
check("Rohtext bleibt über Ansichtswechsel", "$x^2$" in w.tex_edit.toPlainText() and "\\newpage" in w.tex_edit.toPlainText())
if shutil.which("pdflatex"):
    w.compile()
    for _ in range(100):
        pump(300)
        if w.proc is None:
            break
    check("Übersetzen ergibt PDF", os.path.exists(os.path.join(w.work, "main.pdf")), w.log.toPlainText()[:300])
else:
    SKIP += 1
for ext in (".odt", ".md", ".tex"):
    check("Speichern " + ext, w.save_to(os.path.join(TMP, "u" + ext)) and os.path.getsize(os.path.join(TMP, "u" + ext)) > 20)
w.modified = False
w.close()
w2 = MainWindow()
w2.open_file(os.path.join(TMP, "u.tex"))
check("tex geöffnet in LaTeX-Ansicht", w2.view == VIEW_TEX and w2.path.endswith("u.tex"))
w2.open_file(os.path.join(TMP, "u.md"))
check("md geöffnet in Markdown-Ansicht", w2.view == VIEW_MD)
w2.open_file(os.path.join(TMP, "u.odt"))
check("odt geöffnet in formatierter Ansicht", w2.view == VIEW_RICH)
if os.path.exists(os.path.join(TMP, "a.docx")):
    w2.open_file(os.path.join(TMP, "a.docx"))
    check("docx wird als LaTeX gezeigt", w2.view == VIEW_TEX and w2.path is None)
w2.modified = False
w2.close()

# 6. Tabs, Farben, Änderungen von außen, TeXstudio
import stat
import time
from PySide6.QtWidgets import QFileDialog, QMessageBox

_orig = {k: getattr(QMessageBox, k) for k in ("question", "warning", "exec", "clickedButton")}
asked = []
QMessageBox.warning = staticmethod(lambda *a, **k: asked.append(("warning", a[2:])) or QMessageBox.StandardButton.Ok)
QMessageBox.question = staticmethod(lambda *a, **k: asked.append(("question", a[2:])) or QMessageBox.StandardButton.Yes)
QMessageBox.exec = lambda self: 0
QMessageBox.clickedButton = lambda self: self.buttons()[0] if self.buttons() else None

ta = os.path.join(TMP, "t_a.tex")
tb = os.path.join(TMP, "t_b.md")
open(ta, "w", encoding="utf-8").write("\\section{Eins}\nText A\n")
open(tb, "w", encoding="utf-8").write("# Zwei\n\nText B\n")
w = MainWindow()
w.show()
w.open_file(ta)
check("Tab: erste Datei nutzt den leeren Tab", w.tabbar.count() == 1 and w.path == ta)
w.open_file(tb)
check("Tab: zweite Datei in neuem Tab", w.tabbar.count() == 2 and w.path == tb)
cols = [w._tab_color_at(i) for i in range(2)]
check("Tab: verschiedene Farben", cols[0] and cols[1] and cols[0] != cols[1], str(cols))
w.open_file(ta)
check("Tab: schon offene Datei wird nur aktiviert", w.tabbar.count() == 2 and w.path == ta and w.view == VIEW_TEX)
w.tex_edit.appendPlainText("Zusatz in A")
check("Tab: Änderung markiert Tab", w.tabbar.tabText(w._index_of(w.cur)).startswith("* "))
w.open_file(tb)
check("Tab: Zwei hat eigenen Inhalt", w.path == tb and "Text B" in w.md_edit.toPlainText()
      and "Zusatz" not in w.md_edit.toPlainText() and not w.modified)
w.open_file(ta)
check("Tab: Änderung in A bleibt beim Wechsel erhalten",
      w.modified and "Zusatz in A" in w.tex_edit.toPlainText() and "Zusatz in A" in w.doc.toPlainText())
w.cmd_new()
w.rich.textCursor().insertText("Drittes")
check("Tab: neues Dokument", w.tabbar.count() == 3 and w.doc.toPlainText() == "Drittes" and w.path is None)
c3 = w.cur.color
w._set_tab_color(w.cur, "#112233")
check("Tab: Farbe änderbar", w._tab_color_at(2) == "#112233")
check("Tab: Dokumente sind getrennt", w.tabs[w.tabbar.tabData(0)].doc is not w.tabs[w.tabbar.tabData(1)].doc)
n = len(w.tabs)
QMessageBox.question = staticmethod(lambda *a, **k: asked.append(("question", a[2:])) or QMessageBox.StandardButton.Discard)
w.close_tab(w._index_of(w.cur))
check("Tab: ungespeicherten Tab schließen fragt und entfernt ihn", w.tabbar.count() == 2 and len(w.tabs) == 2
      and any(a[0] == "question" for a in asked))
# Farbe wird für dieselbe Datei gemerkt
w._set_tab_color(w.cur, "#abcdef")
cur_path = w.path
w.modified = False
w.close_tab(w._index_of(w.cur))
w.open_file(cur_path)
check("Tab: Farbe der Datei wird gemerkt", w.cur.color == "#abcdef", w.cur.color)
# Änderung von außen
w.open_file(tb)
w.modified = False
time.sleep(0.05)
open(tb, "w", encoding="utf-8").write("# Zwei neu\n\nText B neu\n")
pump(1200)
check("Außenänderung: unveränderter Tab wird neu geladen", "Zwei neu" in w.md_edit.toPlainText()
      and "Zwei neu" in w.doc.toPlainText() and not w.modified)
w.open_file(ta)                                   # A hat ungespeicherte Änderung
asked.clear()
QMessageBox.question = staticmethod(lambda *a, **k: asked.append(("question", a[2:])) or QMessageBox.StandardButton.No)
time.sleep(0.05)
open(ta, "w", encoding="utf-8").write("\\section{Fremd}\nVon außen\n")
pump(1200)
check("Außenänderung: bei eigenen Änderungen wird gefragt und bei Nein behalten",
      any("anderen Programm" in str(a) for a in asked) and "Zusatz in A" in w.tex_edit.toPlainText() and w.modified)
QMessageBox.question = staticmethod(lambda *a, **k: asked.append(("question", a[2:])) or QMessageBox.StandardButton.Yes)
w.save_to(ta)                                     # eigener Speichervorgang darf nichts auslösen
asked.clear()
pump(1200)
check("Außenänderung: eigenes Speichern löst keine Rückfrage aus", not asked)
# Änderung in einem Hintergrund-Tab wird beim Aktivieren übernommen
w.open_file(tb)
time.sleep(0.05)
open(ta, "w", encoding="utf-8").write("\\section{Hinten}\nGeändert im Hintergrund\n")
pump(1200)
w.open_file(ta)
pump(200)
check("Außenänderung: Hintergrund-Tab wird beim Wechsel neu geladen", "Hinten" in w.tex_edit.toPlainText(),
      w.tex_edit.toPlainText()[:60])
# TeXstudio
fake = os.path.join(TMP, "fake_texstudio.sh")
argf = os.path.join(TMP, "args.txt")
open(fake, "w").write('#!/bin/sh\nprintf "%s\\n" "$@" > ' + argf + '\n')
os.chmod(fake, os.stat(fake).st_mode | stat.S_IEXEC)
w.settings["texstudio_path"] = fake
w.open_file(ta)
w.tex_edit.setPlainText("\\section{A}\nzweite\ndritte Zeile\n")
c = w.tex_edit.textCursor()
c.setPosition(w.tex_edit.document().findBlockByNumber(2).position())
w.tex_edit.setTextCursor(c)
w.cmd_texstudio()
for _ in range(30):
    pump(100)
    if os.path.exists(argf):
        break
got = open(argf).read().split() if os.path.exists(argf) else []
check("TeXstudio: Aufruf mit Zeile und Datei", got == ["--line", "3", ta], str(got))
check("TeXstudio: Änderungen wurden vorher gespeichert", "dritte Zeile" in open(ta, encoding="utf-8").read() and not w.modified)
os.remove(argf)
# Dokument ohne .tex-Pfad: wird als .tex gespeichert
w.cmd_new()
w.rich.textCursor().insertText("Aus neuem Dokument")
target = os.path.join(TMP, "aus_neu.tex")
_gs = QFileDialog.getSaveFileName
QFileDialog.getSaveFileName = staticmethod(lambda *a, **k: (target, ""))
w.cmd_texstudio()
QFileDialog.getSaveFileName = _gs
for _ in range(30):
    pump(100)
    if os.path.exists(argf):
        break
got = open(argf).read().split() if os.path.exists(argf) else []
check("TeXstudio: Dokument ohne Pfad wird als .tex gespeichert und geöffnet",
      got and got[-1] == target and os.path.exists(target) and "Aus neuem Dokument" in open(target, encoding="utf-8").read()
      and w.path == target, str(got))
# TeXstudio nicht vorhanden
os.remove(argf)
w.settings["texstudio_path"] = ""
_path = os.environ.get("PATH", "")
os.environ["PATH"] = "/nonexistent"
QMessageBox.clickedButton = lambda self: None
w.cmd_texstudio()
os.environ["PATH"] = _path
pump(300)
check("TeXstudio: fehlendes Programm startet nichts", not os.path.exists(argf))
# misslungenes Öffnen hinterlässt keinen leeren Tab
bad = os.path.join(TMP, "kaputt.docx")
open(bad, "wb").write(b"kein zip")
before = w.tabbar.count()
from seiffert_text.readers import ReaderError
_ra = _app_mod.read_any
def _fail(path, *a, **k):
    raise ReaderError("Testfehler")
_app_mod.read_any = _fail
w.open_file(bad)
_app_mod.read_any = _ra
check("Tab: misslungenes Öffnen hinterlässt keinen Tab", w.tabbar.count() == before and w.path != bad)

# ---- PDF in einem Tab (seit 0.15)
from seiffert_text.pdf_tools import available as _pdf_ok
if _pdf_ok():
    import fitz
    from PySide6.QtCore import Qt as _Qt
    from PySide6.QtTest import QTest as _QTest
    pdfp = os.path.join(TMP, "tab.pdf")
    _d = fitz.open()
    _d.new_page().insert_text((72, 72), "Hallo PDF")
    _d.save(pdfp)
    _d.close()
    mdp = os.path.join(TMP, "vorher.md")
    open(mdp, "w", encoding="utf-8").write("# Vorher\n\nText")
    wp = MainWindow()
    wp.show()
    wp.activateWindow()
    _QTest.qWaitForWindowActive(wp)
    wp.open_file(mdp)
    n_child = len(wp.children_windows)
    wp.open_file(pdfp)
    pump(100)
    check("PDF-Tab: öffnet als Tab nach einer anderen Datei", wp.tabbar.count() == 2 and wp.cur_pdf is not None)
    check("PDF-Tab: kein eigenes Fenster", len(wp.children_windows) == n_child)
    check("PDF-Tab: Tab zeigt Dateinamen", wp.tabbar.tabText(1) == "tab.pdf")
    check("PDF-Tab: PDF-Menü statt Hauptmenü", not wp.menuBar().isVisible() and wp.cur_pdf.widget.menuBar().isVisible())
    wp.open_file(pdfp)
    check("PDF-Tab: dieselbe Datei öffnet keinen zweiten Tab", wp.tabbar.count() == 2)
    wp.tabbar.setCurrentIndex(0)
    pump(50)
    check("PDF-Tab: Wechsel zum Textdokument stellt Menü und Text wieder her",
          wp.cur_pdf is None and wp.menuBar().isVisible() and wp.md_edit.toPlainText().startswith("# Vorher") and wp.path == mdp)
    wp.tabbar.setCurrentIndex(1)
    pump(50)
    pw = wp.cur_pdf.widget
    _hit = []
    pw.a_save.triggered.disconnect()
    pw.a_save.triggered.connect(lambda: _hit.append(1))
    pw.scroll.setFocus()
    _QTest.keyClick(pw.scroll, _Qt.Key.Key_S, _Qt.KeyboardModifier.ControlModifier)
    pump(50)
    check("PDF-Tab: Strg+S gehört dem PDF", _hit == [1])
    _QTest.keyClick(pw.scroll, _Qt.Key.Key_W, _Qt.KeyboardModifier.ControlModifier)
    pump(50)
    check("PDF-Tab: Strg+W schließt den Tab, Textdokument bleibt", wp.tabbar.count() == 1 and wp.cur_pdf is None and wp.path == mdp)
    _hit.clear()
    wp.a_save.triggered.disconnect()
    wp.a_save.triggered.connect(lambda: _hit.append(2))
    wp.rich.setFocus()
    _QTest.keyClick(wp.rich, _Qt.Key.Key_S, _Qt.KeyboardModifier.ControlModifier)
    pump(50)
    check("PDF-Tab: Strg+S gehört nach dem Schließen wieder dem Text", _hit == [2])
    wp.open_file(pdfp)
    wp.cur_pdf.widget.ed.modified = True
    wp.cur_pdf.widget.update_title()
    check("PDF-Tab: Änderung zeigt Stern im Tab", wp.tabbar.tabText(1).startswith("* "))
    check("PDF-Tab: Schließen mit Rückfrage (Verwerfen)", wp.close_tab(1) and wp.tabbar.count() == 1)
    wp.open_file(pdfp)
    wp.cmd_new()
    check("PDF-Tab: Neues Dokument aus dem PDF-Tab", wp.cur_pdf is None and wp.tabbar.count() == 3)
    for _i in range(wp.tabbar.count() - 1, -1, -1):
        wp.close_tab(_i)
    check("PDF-Tab: nach Schließen aller bleibt ein leeres Textdokument", wp.tabbar.count() == 1 and wp.cur_pdf is None)
    wp.modified = False
    wp.close()
else:
    SKIP += 1
    print("PyMuPDF fehlt: PDF-Tab-Prüfungen übersprungen")


# ---- PDF-Import nach LaTeX: Brüche, Ausfüllstriche, Seitenzahl (seit 0.16)
if _pdf_ok():
    import fitz
    fp = os.path.join(TMP, "arbeitsblatt.pdf")
    _d = fitz.open()
    _pg = _d.new_page()
    _pg.insert_text((72, 100), "Berechne", fontsize=11)
    _pg.insert_text((135, 94), "3", fontsize=8)
    _pg.draw_line((132, 97.5), (142, 97.5), width=0.5)
    _pg.insert_text((135, 106), "4", fontsize=8)
    _pg.insert_text((148, 100), "+ 2 Stück", fontsize=11)
    _pg.insert_text((72, 160), "Name:", fontsize=11)
    _pg.draw_line((110, 161), (210, 161), width=0.6)
    _pg.insert_text((300, 800), "1", fontsize=10)
    _pg.insert_text((72, 220), "Dies ist ein Absatz mit Text, der unterstrichen werden soll.", fontsize=11)
    _pg.draw_line((72, 222), (140, 222), width=0.5)
    _d.save(fp)
    _d.close()
    wi = MainWindow()
    wi.open_file(fp, convert=True, to_latex=True)
    pump(100)
    tx = wi.current_latex()
    check("PDF-Import: Bruch wird zu \\frac", "\\(\\frac{3}{4}\\)" in tx, tx[tx.index("\\begin{document}"):][:300])
    check("PDF-Import: Bruch steht an der richtigen Stelle im Satz", "Berechne \\(\\frac{3}{4}\\) + 2 Stück" in tx)
    check("PDF-Import: Ausfüllstrich wird zu \\underline{\\hspace}", "Name: \\underline{\\hspace{" in tx)
    check("PDF-Import: unterstrichener Text ist keine Lücke und kein Bruch", tx.count("\\hspace") == 1 and tx.count("\\frac") == 1)
    check("PDF-Import: freistehende Seitenzahl entfällt", "\\begin{flushright}\n1\n" not in tx and "\n1\n" not in tx.split("\\begin{document}")[1])
    wi.modified = False
    for _t in list(wi.tabs.values()):
        _t.s["modified"] = False
    wi.close()

# ---- PDF-Import: Kopf-/Fußzeile, Papier, Ränder, Farbe, Größe (seit 0.17)
if _pdf_ok():
    import fitz
    fp2 = os.path.join(TMP, "bericht.pdf")
    _d = fitz.open()
    for _n in range(2):
        _pg = _d.new_page(width=595.28, height=841.89)
        _pg.insert_text((90, 50), "Firma Muster GmbH", fontsize=9)
        _pg.insert_text((90, 130), "Titel %d" % _n, fontsize=20, color=(0.8, 0, 0))
        for _k in range(8):
            _pg.insert_text((90, 170 + 15 * _k), "Textzeile %d auf Seite %d mit etwas Inhalt zum Lesen." % (_k, _n), fontsize=11)
        _pg.insert_text((290, 800), "%d" % (_n + 1), fontsize=9)
    _d.save(fp2)
    _d.close()
    wi = MainWindow()
    wi.open_file(fp2, convert=True, to_latex=True)
    pump(100)
    tx = wi.current_latex()
    check("PDF-Import 0.17: Papier A4 und Ränder aus dem PDF", "a4paper" in tx and "left=31.8mm" in tx, tx[:600])
    check("PDF-Import 0.17: Kopfzeile als fancyhdr, nicht im Text", "\\fancyhead" in tx and "Firma Muster GmbH" in tx.split("\\begin{document}")[0]
          and "Firma Muster GmbH" not in tx.split("\\begin{document}")[1])
    check("PDF-Import 0.17: Seitenzahl als \\thepage in der Fußzeile", "\\fancyfoot" in tx and "\\thepage" in tx)
    check("PDF-Import 0.17: Schriftfarbe der Überschrift bleibt erhalten", "textcolor" in tx or "color[HTML]{CC0000}" in tx or "CC0000" in tx.upper())
    check("PDF-Import 0.17: Grundschriftgröße und Zeilenabstand werden gesetzt", "\\@setfontsize\\normalsize{11" in tx)
    wi.modified = False
    for _t in list(wi.tabs.values()):
        _t.s["modified"] = False
    wi.close()

w.cur.s["modified"] = False
for t in list(w.tabs.values()):
    t.s["modified"] = False
w.modified = False
w.close()
for k, v in _orig.items():
    setattr(QMessageBox, k, v)

shutil.rmtree(TMP, ignore_errors=True)
print("Ergebnis: %d Prüfungen ok, %d Fehler, %d übersprungen" % (OK, FAIL, SKIP))
sys.exit(1 if FAIL else 0)
