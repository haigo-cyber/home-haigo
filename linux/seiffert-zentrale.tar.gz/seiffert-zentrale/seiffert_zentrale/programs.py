"""Die Linux-Programme, die die Zentrale kennt, und wie man sie findet."""
from __future__ import annotations

import os
import shutil
from dataclasses import dataclass, field

BIN = os.path.expanduser("~/.local/bin")


@dataclass
class Program:
    id: str
    name: str
    group: str
    command: str                       # Name des Startbefehls (liegt in ~/.local/bin)
    desc: str
    icon: str                          # Symbolname im Icon-Theme
    token: str                         # Wort, an dem man das Fenster erkennt (Name oder Klasse)
    embed_args: list[str] = field(default_factory=list)   # Zusatz beim Einbetten (zum Beispiel neues Fenster erzwingen)
    panel: bool = False                # kein eigener Prozess, sondern eine Seite der Zentrale

    def path(self) -> str | None:
        if self.panel:
            return None
        p = os.path.join(BIN, self.command)
        if os.access(p, os.X_OK):
            return p
        return shutil.which(self.command)

    @property
    def installed(self) -> bool:
        return self.panel or self.path() is not None


PROGRAMS: list[Program] = [
    Program("dateien", "Seifferts Dateien", "Dateien und Text", "seiffert-dateien",
            "Dateien verwalten, suchen, Favoriten, Volltextsuche", "seiffert-dateien", "dateien", ["--new-window"]),
    Program("terminal", "Seifferts Terminal", "Dateien und Text", "seiffert-terminal",
            "Terminal mit den Farben der Seiffert-Programme", "seiffert-terminal", "terminal"),
    Program("text", "Seifferts Text", "Dateien und Text", "seiffert-text",
            "Textverarbeitung für ODT, Markdown und LaTeX, mit PDF und Zuschnitt", "seiffert-text", "text"),
    Program("todo", "Seifferts ToDo", "Büro", "seiffert-todo",
            "Aufgaben, Planung, Fokus und Logbuch mit Google-Tabelle", "seiffert-todo", "todo"),
    Program("zeit", "Seifferts Zeit", "Büro", "seiffert-zeit",
            "Arbeitszeit in Schulstunden erfassen und auswerten", "seiffert-zeit", "zeit"),
    Program("update", "Seifferts Update", "System", "seiffert-update",
            "Alle Seiffert-Programme aus dem Sammelordner aktualisieren", "system-software-update", "update", panel=True),
]
BY_ID = {p.id: p for p in PROGRAMS}


def update_command() -> str | None:
    p = os.path.join(BIN, "seiffert-update")
    return p if os.access(p, os.X_OK) else shutil.which("seiffert-update")


def archive_dir() -> str:
    return os.environ.get("SEIFFERT_ARCHIVE") or os.path.expanduser("~/Seiffert-Archive")


DEFAULT_AUTOSTART = ["dateien"]


def autostart_ids(settings: dict) -> list[str]:
    """Programme, die die Zentrale beim Start selbst startet (settings.json, Schlüssel autostart; Standard: Seifferts Dateien).
    Nur eingetragene und installierte Programme, keine Seiten der Zentrale."""
    v = settings.get("autostart", DEFAULT_AUTOSTART)
    if not isinstance(v, list):
        v = DEFAULT_AUTOSTART
    return [i for i in v if isinstance(i, str) and i in BY_ID and not BY_ID[i].panel and BY_ID[i].installed]
