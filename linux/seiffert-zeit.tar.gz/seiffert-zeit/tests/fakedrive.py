"""Nachbau der Drive-Schnittstelle fuer Tests."""
import json, re, threading, time, uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, parse_qs, unquote


class Fake:
    def __init__(self):
        self.files = {}  # id -> dict(name, parents, mime, data, mod)
        self.log = []
        self.tick = 0

    def now(self):
        self.tick += 1
        return "2026-11-12T12:%02d:%02d.000Z" % (self.tick // 60, self.tick % 60)


def serve(fake):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a): pass

        def _j(self, o, code=200):
            b = json.dumps(o).encode()
            self.send_response(code); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)

        def _auth(self):
            if self.headers.get("Authorization") != "Bearer TESTTOKEN":
                self._j({"error": "auth"}, 401); return False
            return True

        def do_GET(self):
            if not self._auth(): return
            u = urlsplit(self.path); q = parse_qs(u.query)
            fake.log.append("GET " + u.path)
            m = re.fullmatch(r"/drive/v3/files/(\w+)", u.path)
            if m:
                f = fake.files[m.group(1)]
                self.send_response(200); self.send_header("Content-Length", str(len(f["data"]))); self.end_headers(); self.wfile.write(f["data"]); return
            qq = q["q"][0]
            res = []
            for i, f in fake.files.items():
                if f.get("trashed"): continue
                if "name='%s'" % f["name"] in qq:
                    if "in parents" in qq and not any(("'%s' in parents" % p) in qq for p in f["parents"]): continue
                    if "mimeType='application/vnd.google-apps.folder'" in qq and f["mime"] != "application/vnd.google-apps.folder": continue
                    res.append({"id": i, "name": f["name"], "modifiedTime": f["mod"]})
            self._j({"files": res})

        def _body(self):
            return self.rfile.read(int(self.headers.get("Content-Length") or 0))

        def do_POST(self):
            if not self._auth(): return
            u = urlsplit(self.path); b = self._body()
            fake.log.append("POST " + u.path)
            if u.path == "/drive/v3/files":
                j = json.loads(b); i = uuid.uuid4().hex[:8]
                fake.files[i] = {"name": j["name"], "parents": j.get("parents", []), "mime": j.get("mimeType", ""), "data": b"", "mod": fake.now()}
                self._j({"id": i}); return
            m = re.fullmatch(r"/drive/v3/files/(\w+)/copy", u.path)
            if m:
                j = json.loads(b); src = fake.files[m.group(1)]; i = uuid.uuid4().hex[:8]
                fake.files[i] = {**src, "name": j["name"], "mod": fake.now()}; self._j({"id": i}); return
            if u.path == "/upload/drive/v3/files":
                meta, data = self._multi(b); i = uuid.uuid4().hex[:8]
                fake.files[i] = {"name": meta["name"], "parents": meta.get("parents", []), "mime": "application/json", "data": data, "mod": fake.now()}
                self._j({"id": i, "modifiedTime": fake.files[i]["mod"]}); return
            self._j({}, 404)

        def do_PATCH(self):
            if not self._auth(): return
            u = urlsplit(self.path); b = self._body()
            fake.log.append("PATCH " + u.path)
            m = re.fullmatch(r"/upload/drive/v3/files/(\w+)", u.path)
            meta, data = self._multi(b)
            f = fake.files[m.group(1)]; f["data"] = data; f["mod"] = fake.now()
            self._j({"id": m.group(1), "modifiedTime": f["mod"]})

        def _multi(self, b):
            bd = re.search(r'boundary=(\S+)', self.headers["Content-Type"]).group(1).encode()
            parts = [p for p in b.split(b"--" + bd) if p.strip(b"-\r\n")]
            def body(p): return p.split(b"\r\n\r\n", 1)[1].rstrip(b"\r\n")
            return json.loads(body(parts[0])), body(parts[1])

    srv = ThreadingHTTPServer(("127.0.0.1", 0), H); srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv
