"""PDF: Text als Dokument auslesen und PDF direkt ändern (über PyMuPDF, falls installiert)."""
import os
import re
import shutil
from collections import Counter

try:
    import pymupdf
except Exception:          # PyMuPDF fehlt oder passt nicht zum System
    pymupdf = None

from .readers import para, txt, ReaderError

_FONT_CACHE = None
FAMILY = {"sans": "LiberationSans", "serif": "LiberationSerif", "mono": "LiberationMono"}
FALLBACK = {"sans": "DejaVuSans", "serif": "DejaVuSerif", "mono": "DejaVuSansMono"}
BASE14 = {"sans": ("helv", "hebo", "heit", "hebi"), "serif": ("tiro", "tibo", "tiit", "tibi"),
          "mono": ("cour", "cobo", "coit", "cobi")}


class PdfError(Exception):
    pass


def available():
    return pymupdf is not None


# ---------------------------------------------------------------- PDF -> Dokument
def pdf_to_blocks(path):
    """PDF als Dokument mit Format (Überschriften, Listen, Tabellen, Bilder ...), siehe pdf_import.py."""
    if pymupdf is None:
        return _blocks_qt(path)
    from .pdf_import import pdf_to_blocks as _imp
    return _imp(path)


def _blocks_qt(path):
    try:
        from PySide6.QtPdf import QPdfDocument
    except Exception:
        raise ReaderError("Zum Lesen von PDF-Dateien fehlt das Python-Paket PyMuPDF.")
    doc = QPdfDocument(None)
    doc.load(path)
    if doc.pageCount() <= 0:
        raise ReaderError("Das PDF konnte nicht gelesen werden.")
    blocks = [para([txt(os.path.splitext(os.path.basename(path))[0])], h=1)]
    for n in range(doc.pageCount()):
        text = doc.getAllText(n).text()
        for chunk in re.split(r"\n\s*\n", text):
            t = re.sub(r"\s+", " ", chunk).strip()
            if t:
                blocks.append(para([txt(t)]))
    return blocks


# ---------------------------------------------------------------- Schriften
def _fonts():
    global _FONT_CACHE
    if _FONT_CACHE is None:
        _FONT_CACHE = {}
        for root in ("/usr/share/fonts", "/usr/local/share/fonts", os.path.expanduser("~/.local/share/fonts"),
                     os.path.expanduser("~/.fonts")):
            for dp, _, files in os.walk(root):
                for f in files:
                    if f.lower().endswith(".ttf"):
                        _FONT_CACHE.setdefault(f[:-4], os.path.join(dp, f))
    return _FONT_CACHE


def pick_font(flags):
    """(fontname, fontfile) passend zu Serife, Dicktengleichheit, fett und kursiv."""
    kind = "mono" if flags & 8 else ("serif" if flags & 4 else "sans")
    bold, ital = bool(flags & 16), bool(flags & 2)
    style = {(False, False): "Regular", (True, False): "Bold", (False, True): "Italic", (True, True): "BoldItalic"}
    fonts = _fonts()
    name = "%s-%s" % (FAMILY[kind], style[(bold, ital)])
    if name in fonts:
        return "Sf" + name.replace("-", ""), fonts[name]
    dj = FALLBACK[kind] + {(False, False): "", (True, False): "-Bold", (False, True): "-Oblique",
                           (True, True): "-BoldOblique"}[(bold, ital)]
    if dj in fonts:
        return "Sf" + dj.replace("-", ""), fonts[dj]
    return BASE14[kind][(1 if bold else 0) + (2 if ital else 0)], None


def _rgb(c):
    return ((c >> 16) & 255) / 255.0, ((c >> 8) & 255) / 255.0, (c & 255) / 255.0


# ---------------------------------------------------------------- PDF direkt ändern
class PdfEditor:
    def __init__(self, path):
        if pymupdf is None:
            raise PdfError("Zum Bearbeiten von PDF-Dateien fehlt das Python-Paket PyMuPDF. "
                           "Bitte ./install.sh erneut ausführen (mit Internetverbindung).")
        self.path = os.path.abspath(path)
        try:
            self.doc = pymupdf.open(self.path)
        except Exception as e:
            raise PdfError("Das PDF konnte nicht geöffnet werden: %s" % e)
        if self.doc.needs_pass:
            raise PdfError("Das PDF ist mit einem Kennwort geschützt.")
        if not self.doc.is_pdf:
            raise PdfError("Die Datei ist kein PDF.")
        self.undo = []
        self.modified = False
        self.backed_up = False

    def count(self):
        return self.doc.page_count

    # ---- Rückgängig
    def snapshot(self):
        self.undo.append(self.doc.tobytes())
        limit = 15 if len(self.undo[-1]) < 20_000_000 else 3
        del self.undo[:-limit]
        self.modified = True

    def undo_last(self):
        if not self.undo:
            return False
        data = self.undo.pop()
        self.doc.close()
        self.doc = pymupdf.open(stream=data, filetype="pdf")
        self.modified = True
        return True

    # ---- Anzeige
    def render(self, pno, zoom):
        pix = self.doc[pno].get_pixmap(matrix=pymupdf.Matrix(zoom, zoom), alpha=False)
        return pix.samples, pix.width, pix.height, pix.stride

    def page_size(self, pno):
        r = self.doc[pno].rect
        return r.width, r.height

    # ---- Text
    def line_at(self, pno, x, y):
        """Textzeile an der Stelle (PDF-Punkte) oder None."""
        page = self.doc[pno]
        best = None
        for b in page.get_text("dict").get("blocks", []):
            for ln in b.get("lines", []):
                spans = [s for s in ln.get("spans", []) if s["text"].strip()]
                if not spans:
                    continue
                x0, y0, x1, y1 = ln["bbox"]
                if x0 - 2 <= x <= x1 + 2 and y0 - 1 <= y <= y1 + 1:
                    s = spans[0]
                    uniform = all((round(q["size"], 1), q.get("flags", 0), q.get("color", 0)) ==
                                  (round(s["size"], 1), s.get("flags", 0), s.get("color", 0)) for q in spans)
                    best = {"uniform": uniform,"text": "".join(s2["text"] for s2 in ln["spans"]).rstrip(), "bbox": tuple(ln["bbox"]),
                            "origin": tuple(s["origin"]), "size": s["size"], "color": s.get("color", 0),
                            "flags": s.get("flags", 0), "dir": tuple(ln.get("dir", (1, 0)))}
        return best

    def _check(self, page):
        if page.rotation:
            raise PdfError("Auf einer gedrehten Seite kann Text nicht geändert werden.")

    def _redact(self, page, rects):
        for r in rects:
            page.add_redact_annot(pymupdf.Rect(r), fill=False, cross_out=False)
        page.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_NONE, graphics=pymupdf.PDF_REDACT_LINE_ART_NONE)

    def _insert(self, page, point, text, size, color, flags, scale=1.0):
        name, file = pick_font(flags)
        kw = {"fontsize": size, "fontname": name, "color": color}
        if file:
            kw["fontfile"] = file
        pt = pymupdf.Point(point)
        if abs(scale - 1.0) > 0.005:
            kw["morph"] = (pt, pymupdf.Matrix(scale, 1))      # waagerecht auf die Breite der Originalschrift strecken
        page.insert_text(pt, text, **kw)

    def _scale(self, old_text, old_width, size, flags):
        """Faktor, mit dem die Ersatzschrift so breit wird wie die Originalschrift an derselben Stelle."""
        w = self._width(old_text, size, flags)
        if w <= 0 or old_width <= 0 or not old_text.strip():
            return 1.0
        return min(1.3, max(0.75, old_width / w))

    def _shrink(self, bbox):
        x0, y0, x1, y1 = bbox
        h = y1 - y0
        return (x0 - 0.5, y0 + h * 0.18, x1 + 0.5, y1 - h * 0.18)

    def replace_line(self, pno, line, new_text, fmt=None):
        """Zeile neu setzen. fmt (optional): {"size", "flags", "color"} überschreibt Größe, Schrift (flags: 4 Serife,
        8 dicktengleich, 16 fett, 2 kursiv) und Farbe (RGB als Zahl). Bleiben Größe und Schrift wie im Original,
        wird die Breite der Originalschrift angeglichen (0.18); bei anderer Schrift oder Größe nicht."""
        page = self.doc[pno]
        self._check(page)
        if abs(line["dir"][0] - 1) > 0.01 or abs(line["dir"][1]) > 0.01:
            raise PdfError("Schräg oder senkrecht gesetzter Text kann nicht geändert werden.")
        size, flags, color = line["size"], line["flags"], line["color"]
        same_face = True
        if fmt:
            size = float(fmt.get("size", size))
            flags = int(fmt.get("flags", flags))
            color = int(fmt.get("color", color))
            same_face = abs(size - line["size"]) < 0.05 and (flags & 30) == (line["flags"] & 30)
        self.snapshot()
        self._redact(page, [self._shrink(line["bbox"])])
        if new_text.strip():
            r = self._scale(line["text"], line["bbox"][2] - line["bbox"][0], line["size"], line["flags"]) if same_face else 1.0
            self._insert(page, line["origin"], new_text, size, _rgb(color), flags, r)

    def _width(self, text, size, flags):
        name, file = pick_font(flags)
        try:
            f = pymupdf.Font(fontfile=file) if file else pymupdf.Font(name)
            return f.text_length(text, fontsize=size)
        except Exception:
            return len(text) * size * 0.5

    def replace_all(self, old, new):
        """Ersetzt jeden Treffer; liefert (Anzahl, übersprungene Treffer).

        Jede betroffene Zeile wird entfernt und Abschnitt für Abschnitt (mit jeweils eigener Größe, Farbe und
        Schriftart) neu gesetzt; folgende Abschnitte rücken nach, damit nichts überlappt.
        """
        if not old:
            return 0, 0
        pat = re.compile(re.escape(old), re.IGNORECASE)
        todo, skipped = [], 0
        for pno in range(self.doc.page_count):
            page = self.doc[pno]
            lines = []
            for b in page.get_text("dict").get("blocks", []):
                for ln in b.get("lines", []):
                    spans = [sp for sp in ln.get("spans", []) if sp["text"]]
                    whole = "".join(sp["text"] for sp in spans)
                    total = len(pat.findall(whole))
                    if not total:
                        continue
                    inside = sum(len(pat.findall(sp["text"])) for sp in spans)
                    d = ln.get("dir", (1, 0))
                    if page.rotation or abs(d[0] - 1) > 0.01 or abs(d[1]) > 0.01 or inside == 0:
                        skipped += total
                        continue
                    skipped += total - inside
                    lines.append((ln, spans, inside))
            if lines:
                todo.append((pno, lines))
        if not todo:
            return 0, skipped
        self.snapshot()
        n = 0
        for pno, lines in todo:
            page = self.doc[pno]
            self._redact(page, [self._shrink(ln["bbox"]) for ln, _, _ in lines])
            for ln, spans, cnt in lines:
                x, shifted = None, False
                for sp in spans:
                    text = pat.sub(lambda m: new, sp["text"])
                    ox, oy = sp["origin"]
                    px = x if (shifted and x is not None) else ox
                    r = self._scale(sp["text"], sp["bbox"][2] - sp["bbox"][0], sp["size"], sp.get("flags", 0))
                    if text.strip():
                        self._insert(page, (px, oy), text, sp["size"], _rgb(sp.get("color", 0)), sp.get("flags", 0), r)
                    if text != sp["text"]:
                        shifted = True
                    x = px + r * self._width(text, sp["size"], sp.get("flags", 0))
                n += cnt
        return n, skipped

    def add_text(self, pno, x, y, text, size, flags=0, color=0):
        page = self.doc[pno]
        self._check(page)
        self.snapshot()
        lines = text.split("\n")
        for k, line in enumerate(lines):
            if line:
                self._insert(page, (x, y + k * size * 1.25), line, size, _rgb(color), flags)

    # ---- Formularfelder
    def field_count(self):
        try:
            return int(self.doc.is_form_pdf or 0)
        except Exception:
            return 0

    @staticmethod
    def _on_name(w):
        """Name des Ein-Zustands eines Ankreuzfelds oder Optionsknopfs."""
        try:
            for st in (w.button_states() or {}).get("normal") or []:
                if st and st != "Off":
                    return st
        except Exception:
            pass
        st = w.on_state()
        return st if isinstance(st, str) and st else "Yes"

    @staticmethod
    def _pdf_name(st):
        """Zustandsname als gültiger PDF-Name (Sonderzeichen als #xx)."""
        raw = re.sub(r"\\([0-7]{3})", lambda m: chr(int(m.group(1), 8)), st)
        out = "/"
        for ch in raw.encode("latin-1", "replace"):
            c = chr(ch)
            out += c if (33 <= ch <= 126 and c not in "#/%()<>[]{}") else "#%02x" % ch
        return out

    def fields(self, pno, all_kinds=False):
        """Formularfelder der Seite mit Lage in Anzeige-Koordinaten (PDF-Punkte).
        all_kinds: auch Schaltflächen und Signaturfelder (zum Verschieben, nicht zum Ausfüllen)."""
        page = self.doc[pno]
        out = []
        rot = page.rotation_matrix
        for w in page.widgets():
            t = w.field_type
            kind = {pymupdf.PDF_WIDGET_TYPE_TEXT: "text", pymupdf.PDF_WIDGET_TYPE_CHECKBOX: "check",
                    pymupdf.PDF_WIDGET_TYPE_RADIOBUTTON: "radio", pymupdf.PDF_WIDGET_TYPE_COMBOBOX: "combo",
                    pymupdf.PDF_WIDGET_TYPE_LISTBOX: "list"}.get(t)
            if kind is None and all_kinds:
                kind = {pymupdf.PDF_WIDGET_TYPE_BUTTON: "button", pymupdf.PDF_WIDGET_TYPE_SIGNATURE: "signature"}.get(t, "other")
            if kind is None:
                continue
            flags = w.field_flags or 0
            r = w.rect * rot
            r.normalize()
            val = w.field_value
            if kind in ("button", "signature", "other"):
                val = ""
            if kind in ("check", "radio"):
                state = self.doc.xref_get_key(w.xref, "AS")
                val = state[0] == "name" and state[1] not in ("/Off", "")
            out.append({"xref": w.xref, "kind": kind, "name": w.field_name or "", "value": val,
                        "rect": (r.x0, r.y0, r.x1, r.y1), "choices": list(w.choice_values or []),
                        "multiline": bool(flags & pymupdf.PDF_TX_FIELD_IS_MULTILINE),
                        "password": bool(flags & pymupdf.PDF_TX_FIELD_IS_PASSWORD),
                        "editable": bool(flags & pymupdf.PDF_CH_FIELD_IS_EDIT),
                        "readonly": bool(flags & pymupdf.PDF_FIELD_IS_READ_ONLY),
                        "maxlen": int(w.text_maxlen or 0), "fontsize": float(w.text_fontsize or 0),
                        "font": str(w.text_font or ""), "align": self._quadding(w.xref)})
        return out

    def _quadding(self, xref):
        """Ausrichtung des Feldtexts: 0 links, 1 mittig, 2 rechts (auch vom Elternfeld oder Formular geerbt)."""
        doc = self.doc
        try:
            x = xref
            for _ in range(8):
                q = doc.xref_get_key(x, "Q")
                if q[0] == "int":
                    return int(q[1])
                par = doc.xref_get_key(x, "Parent")
                if par[0] != "xref":
                    break
                x = int(par[1].split()[0])
            q = doc.xref_get_key(doc.pdf_catalog(), "AcroForm/Q")
            if q[0] == "int":
                return int(q[1])
        except Exception:
            pass
        return 0

    def set_field(self, pno, xref, value):
        page = self.doc[pno]
        target = None
        for w in page.widgets():
            if w.xref == xref:
                target = w
                break
        if target is None:
            raise PdfError("Das Formularfeld wurde nicht gefunden.")
        self.snapshot()
        t = target.field_type
        if t in (pymupdf.PDF_WIDGET_TYPE_CHECKBOX, pymupdf.PDF_WIDGET_TYPE_RADIOBUTTON):
            self._set_button(target, bool(value), t == pymupdf.PDF_WIDGET_TYPE_RADIOBUTTON)
            return
        target.field_value = "" if value is None else str(value)
        target.update()

    # ---- Formularfelder bearbeiten (Lage, Größe, Eigenschaften, neu, kopieren, löschen)
    def _field_widget(self, pno, xref):
        page = self.doc[pno]
        for w in page.widgets():
            if w.xref == xref:
                w._seiffert_page = page          # die Seite muss leben, solange das Feld benutzt wird
                return w
        raise PdfError("Das Formularfeld wurde nicht gefunden.")

    def _to_page(self, pno, rect):
        """Anzeige-Rechteck (PDF-Punkte, gedrehte Seite) in die Koordinaten des Felds umrechnen."""
        r = pymupdf.Rect(*rect) * self.doc[pno].derotation_matrix
        r.normalize()
        return r

    def field_names(self):
        names = set()
        for page in self.doc:
            for w in page.widgets():
                if w.field_name:
                    names.add(w.field_name)
        return names

    def unique_name(self, base):
        names = self.field_names()
        if base not in names:
            return base
        m = re.match(r"^(.*?)[_ ]?(\d+)$", base)
        stem, n = (m.group(1), int(m.group(2))) if m else (base, 1)
        while True:
            n += 1
            cand = "%s_%d" % (stem, n)
            if cand not in names:
                return cand

    def _name_holder(self, xref):
        """xref des Objekts, das den Feldnamen (/T) trägt, wenn sich der volle Name dort umbenennen lässt, sonst None."""
        doc = self.doc
        x = xref
        for _ in range(8):
            t = doc.xref_get_key(x, "T")
            if t[0] == "string":
                full = None
                for pg in doc:
                    for w in pg.widgets():
                        if w.xref == xref:
                            full = w.field_name
                            break
                    if full is not None:
                        break
                return x if full == self._unesc(t[1]) else None
            par = doc.xref_get_key(x, "Parent")
            if par[0] != "xref":
                return None
            x = int(par[1].split()[0])
        return None

    @staticmethod
    def _unesc(s):
        s = re.sub(r"\\([nrtbf()\\])", lambda m: {"n": "\n", "r": "\r", "t": "\t", "b": "\b", "f": "\f"}.get(m.group(1), m.group(1)), s)
        return re.sub(r"\\([0-7]{3})", lambda m: chr(int(m.group(1), 8)), s)

    def _holder(self, xref, key):
        """Erstes Objekt in der Kette Feld -> Elternfelder, das den Schlüssel trägt (sonst None)."""
        doc = self.doc
        x = xref
        for _ in range(8):
            if doc.xref_get_key(x, key)[0] != "null":
                return x
            par = doc.xref_get_key(x, "Parent")
            if par[0] != "xref":
                return None
            x = int(par[1].split()[0])
        return None

    def _top(self, xref):
        """Oberstes Feldobjekt der Kette (dort gehören DA, Ff und Opt hin, wenn sie noch fehlen)."""
        doc = self.doc
        x = xref
        for _ in range(8):
            par = doc.xref_get_key(x, "Parent")
            if par[0] != "xref":
                return x
            x = int(par[1].split()[0])
        return x

    def _set_font_size(self, xref, size):
        doc = self.doc
        h = self._holder(xref, "DA")
        if h is None:
            da = doc.xref_get_key(doc.pdf_catalog(), "AcroForm/DA")
            da = self._unesc(da[1]) if da[0] == "string" else "0 g /Helv 0 Tf"
            h = self._top(xref)
        else:
            da = self._unesc(doc.xref_get_key(h, "DA")[1])
        if re.search(r"[-\d.]+\s+Tf", da):
            da = re.sub(r"[-\d.]+(\s+Tf)", lambda m: ("%g" % size) + m.group(1), da, count=1)
        else:
            da += " /Helv %g Tf" % size
        doc.xref_set_key(h, "DA", pymupdf.get_pdf_str(da))

    def _set_flags(self, xref, flags):
        h = self._holder(xref, "Ff") or self._top(xref)
        self.doc.xref_set_key(h, "Ff", str(int(flags)))

    def _set_choices(self, xref, choices):
        h = self._holder(xref, "Opt") or self._top(xref)
        self.doc.xref_set_key(h, "Opt", "[" + " ".join(pymupdf.get_pdf_str(c) for c in choices) + "]")

    def _redraw(self, w):
        """Aussehen des Felds neu erzeugen (nach Lage-, Größen- oder Eigenschaftsänderung).
        PyMuPDF setzt dabei die Randstärke auf 1; die ursprüngliche Randstärke wird wiederhergestellt."""
        doc = self.doc
        xref = w.xref
        bs = doc.xref_get_key(xref, "BS")
        bw = doc.xref_get_key(xref, "BS/W") if bs[0] != "null" else ("null", "null")
        try:
            w.update()
        except Exception as e:
            raise PdfError("Das Feld konnte nicht aktualisiert werden: %s" % e)
        if bw[0] == "null":
            if bs[0] == "null":
                doc.xref_set_key(xref, "BS", "null")
            else:
                doc.xref_set_key(xref, "BS/W", "null")
        else:
            doc.xref_set_key(xref, "BS/W", bw[1])

    def _set_rect_direct(self, pno, xref, r):
        """Nur das Rechteck ändern, Aussehen (z. B. Beschriftung einer Schaltfläche) unangetastet lassen."""
        n = r * ~self.doc[pno].transformation_matrix
        n.normalize()
        self.doc.xref_set_key(xref, "Rect", "[%g %g %g %g]" % (n.x0, n.y0, n.x1, n.y1))

    def _regenerates(self, w):
        return w.field_type in (pymupdf.PDF_WIDGET_TYPE_TEXT, pymupdf.PDF_WIDGET_TYPE_CHECKBOX,
                                pymupdf.PDF_WIDGET_TYPE_RADIOBUTTON, pymupdf.PDF_WIDGET_TYPE_COMBOBOX,
                                pymupdf.PDF_WIDGET_TYPE_LISTBOX)

    def place_fields(self, pno, changes):
        """changes: Liste (xref, (x0, y0, x1, y1) in Anzeige-Koordinaten). Alles zusammen ein Rückgängig-Schritt."""
        if not changes:
            return
        todo = []
        for xref, rect in changes:
            w = self._field_widget(pno, xref)
            r = self._to_page(pno, rect)
            if r.width < 3 or r.height < 3:
                raise PdfError("Ein Feld darf nicht kleiner als 3 Punkte werden.")
            todo.append((w, r))
        self.snapshot()
        for w, r in todo:
            if self._regenerates(w):
                w.rect = r
                self._redraw(w)
            else:
                self._set_rect_direct(pno, w.xref, r)

    def field_props(self, pno, xref):
        w = self._field_widget(pno, xref)
        flags = w.field_flags or 0
        kind = {pymupdf.PDF_WIDGET_TYPE_TEXT: "text", pymupdf.PDF_WIDGET_TYPE_CHECKBOX: "check",
                pymupdf.PDF_WIDGET_TYPE_RADIOBUTTON: "radio", pymupdf.PDF_WIDGET_TYPE_COMBOBOX: "combo",
                pymupdf.PDF_WIDGET_TYPE_LISTBOX: "list"}.get(w.field_type, "other")
        r = w.rect * self.doc[pno].rotation_matrix
        r.normalize()
        return {"kind": kind, "name": w.field_name or "", "rename_ok": self._name_holder(xref) is not None,
                "fontsize": float(w.text_fontsize or 0), "align": self._quadding(xref),
                "readonly": bool(flags & pymupdf.PDF_FIELD_IS_READ_ONLY),
                "multiline": bool(flags & pymupdf.PDF_TX_FIELD_IS_MULTILINE),
                "choices": [c if isinstance(c, str) else str(c[-1]) for c in (w.choice_values or [])],
                "rect": (r.x0, r.y0, r.x1, r.y1)}

    def set_field_props(self, pno, xref, props, rect=None, snap=True):
        """props: name, fontsize, align, readonly, multiline, choices (nur gesetzte Schlüssel werden geändert)."""
        w = self._field_widget(pno, xref)
        ftype = w.field_type
        if "name" in props and props["name"] and props["name"] != w.field_name:
            holder = self._name_holder(xref)
            if holder is None:
                raise PdfError("Dieser Feldname gehört zu einer Gliederung des Formulars und lässt sich hier nicht ändern.")
            if "." in props["name"]:
                raise PdfError("Der Feldname darf keinen Punkt enthalten.")
            if props["name"] in self.field_names():
                raise PdfError("Ein Feld mit diesem Namen gibt es schon.")
        newrect = None
        if rect is not None:
            newrect = self._to_page(pno, rect)
            if newrect.width < 3 or newrect.height < 3:
                raise PdfError("Ein Feld darf nicht kleiner als 3 Punkte werden.")
        if snap:
            self.snapshot()
        doc = self.doc
        if "name" in props and props["name"] and props["name"] != w.field_name:
            doc.xref_set_key(self._name_holder(xref), "T", pymupdf.get_pdf_str(props["name"]))
        text_like = ftype in (pymupdf.PDF_WIDGET_TYPE_TEXT, pymupdf.PDF_WIDGET_TYPE_COMBOBOX,
                              pymupdf.PDF_WIDGET_TYPE_LISTBOX)
        if "fontsize" in props and text_like:
            self._set_font_size(xref, float(props["fontsize"]))
        if "readonly" in props or "multiline" in props:
            flags = int(w.field_flags or 0)
            for key, bit in (("readonly", pymupdf.PDF_FIELD_IS_READ_ONLY), ("multiline", pymupdf.PDF_TX_FIELD_IS_MULTILINE)):
                if key in props and (key != "multiline" or ftype == pymupdf.PDF_WIDGET_TYPE_TEXT):
                    flags = (flags | bit) if props[key] else (flags & ~bit)
            self._set_flags(xref, flags)
        if "choices" in props and ftype in (pymupdf.PDF_WIDGET_TYPE_COMBOBOX, pymupdf.PDF_WIDGET_TYPE_LISTBOX):
            self._set_choices(xref, list(props["choices"]))
        if "align" in props and text_like:
            doc.xref_set_key(xref, "Q", str(int(props["align"])))
        w = self._field_widget(pno, xref)        # neu lesen, damit PyMuPDF die geänderten Werte kennt
        if not self._regenerates(w):
            if newrect is not None:
                self._set_rect_direct(pno, xref, newrect)
            return
        if newrect is not None:
            w.rect = newrect
        self._redraw(w)

    def add_field(self, pno, kind, rect, name=None, fontsize=0.0, snap=True):
        """Neues Feld: kind text | multiline | check | combo. rect in Anzeige-Koordinaten. Liefert die xref."""
        t = {"text": pymupdf.PDF_WIDGET_TYPE_TEXT, "multiline": pymupdf.PDF_WIDGET_TYPE_TEXT,
             "check": pymupdf.PDF_WIDGET_TYPE_CHECKBOX, "combo": pymupdf.PDF_WIDGET_TYPE_COMBOBOX}.get(kind)
        if t is None:
            raise PdfError("Unbekannte Feldart.")
        x0, y0, x1, y1 = rect
        if kind == "check":                      # Ankreuzfelder quadratisch
            side = min(x1 - x0, y1 - y0)
            x1, y1 = x0 + side, y0 + side
        r = self._to_page(pno, (x0, y0, x1, y1))
        if r.width < 3 or r.height < 3:
            raise PdfError("Das Feld ist zu klein.")
        name = self.unique_name(name or {"text": "Text", "multiline": "Text", "check": "Kontrollkaestchen",
                                         "combo": "Auswahl"}[kind])
        if snap:
            self.snapshot()
        w = pymupdf.Widget()
        w.field_type = t
        w.field_name = name
        w.rect = r
        w.border_color = (0.35, 0.35, 0.35)      # dünner grauer Rahmen, damit das neue Feld im PDF sichtbar ist
        w.border_width = 0.5
        if t == pymupdf.PDF_WIDGET_TYPE_TEXT:
            w.text_font = "Helv"
            w.text_fontsize = float(fontsize)
            w.text_color = (0, 0, 0)
            w.field_value = ""
            if kind == "multiline":
                w.field_flags = pymupdf.PDF_TX_FIELD_IS_MULTILINE
        elif t == pymupdf.PDF_WIDGET_TYPE_COMBOBOX:
            w.text_font = "Helv"
            w.text_fontsize = float(fontsize)
            w.choice_values = ["Auswahl 1", "Auswahl 2"]
            w.field_value = ""
        else:
            w.field_value = "Off"
        self.doc[pno].add_widget(w)
        return w.xref

    def delete_fields(self, pno, xrefs):
        page = self.doc[pno]
        todo = [self._field_widget(pno, x) for x in xrefs]
        if not todo:
            return
        self.snapshot()
        for w in todo:
            page.delete_widget(w)

    def copy_field(self, pno, xref, dx, dy, snap=True):
        """Feld kopieren und um (dx, dy) Punkte (Anzeige-Richtung) versetzen. Optionsknöpfe lassen sich nicht kopieren."""
        w = self._field_widget(pno, xref)
        if w.field_type == pymupdf.PDF_WIDGET_TYPE_RADIOBUTTON:
            raise PdfError("Optionsknöpfe gehören zu einer Gruppe und lassen sich nicht einzeln kopieren.")
        r = w.rect * self.doc[pno].rotation_matrix
        r.normalize()
        r = pymupdf.Rect(r.x0 + dx, r.y0 + dy, r.x1 + dx, r.y1 + dy)
        kind = {pymupdf.PDF_WIDGET_TYPE_TEXT: "multiline" if (w.field_flags or 0) & pymupdf.PDF_TX_FIELD_IS_MULTILINE
                else "text", pymupdf.PDF_WIDGET_TYPE_CHECKBOX: "check",
                pymupdf.PDF_WIDGET_TYPE_COMBOBOX: "combo"}.get(w.field_type)
        if kind is None:
            raise PdfError("Diese Feldart lässt sich nicht kopieren.")
        newx = self.add_field(pno, kind, (r.x0, r.y0, r.x1, r.y1), self.unique_name(w.field_name or "Feld"),
                              float(w.text_fontsize or 0), snap=snap)
        w2 = self._field_widget(pno, newx)
        if kind != "check":
            q = self._quadding(xref)
            if q:
                self.doc.xref_set_key(newx, "Q", str(q))
            w2.field_flags = int(w.field_flags or 0)
            if kind == "combo":
                w2.choice_values = list(w.choice_values or [])
            self._redraw(w2)
        return newx

    def _set_button(self, w, on, radio):
        doc = self.doc
        name = self._pdf_name(self._on_name(w)) if on else "/Off"
        doc.xref_set_key(w.xref, "AS", name)
        parent = doc.xref_get_key(w.xref, "Parent")
        if parent[0] == "xref":
            pxref = int(parent[1].split()[0])
            doc.xref_set_key(pxref, "V", name)
            kids = doc.xref_get_key(pxref, "Kids")
            if radio and on and kids[0] == "array":
                for k in re.findall(r"(\d+) 0 R", kids[1]):
                    if int(k) != w.xref:
                        doc.xref_set_key(int(k), "AS", "/Off")
        else:
            doc.xref_set_key(w.xref, "V", name)
            if radio and on:                     # Knöpfe gleichen Namens ohne gemeinsames Elternfeld
                for page in doc:
                    for o in page.widgets():
                        if (o.xref != w.xref and o.field_type == pymupdf.PDF_WIDGET_TYPE_RADIOBUTTON
                                and o.field_name == w.field_name):
                            doc.xref_set_key(o.xref, "AS", "/Off")
                            doc.xref_set_key(o.xref, "V", name)

    # ---- Seiten
    def delete_page(self, pno):
        if self.doc.page_count <= 1:
            raise PdfError("Die letzte Seite kann nicht gelöscht werden.")
        self.snapshot()
        self.doc.delete_page(pno)

    def rotate_page(self, pno, deg=90):
        self.snapshot()
        page = self.doc[pno]
        page.set_rotation((page.rotation + deg) % 360)

    def move_page(self, pno, delta):
        to = pno + delta
        if to < 0 or to >= self.doc.page_count:
            return pno
        self.snapshot()
        if delta > 0:
            self.doc.move_page(pno, to + 1)
        else:
            self.doc.move_page(pno, to)
        return to

    def append_pdf(self, other):
        try:
            src = pymupdf.open(other)
        except Exception as e:
            raise PdfError("Die Datei konnte nicht geöffnet werden: %s" % e)
        if not src.is_pdf:
            raise PdfError("Die Datei ist kein PDF.")
        self.snapshot()
        self.doc.insert_pdf(src)
        src.close()

    # ---- Speichern
    def save(self, dest):
        dest = os.path.abspath(dest)
        tmp = dest + ".teil"
        try:
            self.doc.save(tmp, garbage=3, deflate=True)
            chk = pymupdf.open(tmp)
            ok = chk.page_count == self.doc.page_count
            chk.close()
            if not ok:
                raise PdfError("Die geschriebene Datei ist unvollständig. Es wurde nichts überschrieben.")
            if dest == self.path and not self.backed_up and os.path.exists(self.path):
                shutil.copy2(self.path, self.path + ".bak")
                self.backed_up = True
            data = self.doc.tobytes()
            self.doc.close()
            os.replace(tmp, dest)
            self.doc = pymupdf.open(stream=data, filetype="pdf")
            self.path = dest
            self.modified = False
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)
