"""Gemeinsame Konstanten und Hilfen für Seifferts Text."""
from PySide6.QtGui import QTextFormat

# Eigene Eigenschaften in QTextDocument
PROP_RAW_BLOCK = QTextFormat.Property.UserProperty + 1     # Block enthält unverändertes LaTeX
PROP_RAW_INLINE = QTextFormat.Property.UserProperty + 2    # Textstück ist unverändertes LaTeX
PROP_ORIG_SRC = QTextFormat.Property.UserProperty + 3      # ursprünglicher Bildpfad aus einer .tex-Datei
PROP_SRC = QTextFormat.Property.UserProperty + 5        # Nummer des Absatzes in der ODT-Quelldatei (+1)
PROP_UNNUM = QTextFormat.Property.UserProperty + 4         # Überschrift ohne Nummer (\section*)

LS = "\u2028"   # Zeilenumbruch innerhalb eines Absatzes in QTextDocument

DEFAULT_PREAMBLE = r"""\documentclass[11pt,a4paper]{article}
\IfFileExists{lmodern.sty}{\usepackage[T1]{fontenc}\usepackage{lmodern}}{}
\IfFileExists{ngerman.ldf}{\usepackage[ngerman]{babel}}{}
\IfFileExists{geometry.sty}{\usepackage[a4paper,margin=2.5cm]{geometry}}{\setlength{\textwidth}{16cm}\setlength{\oddsidemargin}{0pt}\setlength{\topmargin}{-1cm}\setlength{\textheight}{24cm}}
\usepackage{graphicx}
\usepackage{array}
\usepackage{longtable}
\IfFileExists{ulem.sty}{\usepackage[normalem]{ulem}}{\newcommand{\uline}[1]{\underline{##1}}\newcommand{\sout}[1]{##1}}
\IfFileExists{hyperref.sty}{\usepackage[hidelinks]{hyperref}}{\newcommand{\href}[2]{##2}\newcommand{\url}[1]{\texttt{##1}}}
\setlength{\parindent}{0pt}
\setlength{\parskip}{0.6em}
"""

HEADING_SIZES = {1: 20, 2: 16, 3: 14, 4: 12, 5: 12, 6: 12}


def heading_cmds(preamble):
    """Zuordnung Überschriftenebene -> LaTeX-Befehl, je nach Dokumentklasse."""
    import re
    m = re.search(r"\\documentclass(?:\[[^\]]*\])?\{([^}]*)\}", preamble or "")
    cls = m.group(1).strip() if m else "article"
    if cls in ("book", "report", "scrbook", "scrreprt", "memoir"):
        return ["chapter", "section", "subsection", "subsubsection", "paragraph", "subparagraph"]
    return ["section", "subsection", "subsubsection", "paragraph", "subparagraph", "subparagraph"]
