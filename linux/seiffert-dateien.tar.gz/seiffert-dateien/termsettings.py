"""Einstellungen von Seifferts Terminal (ohne Qt, nur Standardbibliothek).

Alles, was der Benutzer einstellen kann, steht in DEFAULTS. clean() prüft jede Eingabe streng (falsche Werte
gibt es als AppError mit verständlicher Meldung), merge() legt eine Änderung über den bisherigen Stand,
resolve() rechnet Farbschema, eigene Farben und Syntaxfarben zu den fertigen Farben für die Oberfläche zusammen.
Gespeichert wird in ~/.config/seiffert-terminal/settings.json (atomar geschrieben)."""
from __future__ import annotations

import copy
import json
import os
import re
import shlex
import tempfile
from pathlib import Path

VERSION = "1.0"
APP_ID = "seiffert-terminal"


try:
    from backend import AppError            # gleiche Fehlerklasse wie im Rest des Pakets
except ImportError:                          # pragma: no cover - nur wenn das Modul allein benutzt wird
    class AppError(Exception):
        """Fehler mit Text für die Anzeige."""


def config_dir() -> Path:
    return Path(os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")) / APP_ID


# ---------------------------------------------------------------- Farbschemata
ANSI_NAMES = ("black", "red", "green", "yellow", "blue", "magenta", "cyan", "white",
              "bright_black", "bright_red", "bright_green", "bright_yellow", "bright_blue", "bright_magenta", "bright_cyan", "bright_white")
BASE_COLORS = ("foreground", "background", "cursor", "cursor_accent", "selection")
COLOR_KEYS = BASE_COLORS + ANSI_NAMES

# Name: (Anzeigename, Vordergrund, Hintergrund, Cursor, Auswahl, 16 ANSI-Farben)
THEMES: dict[str, tuple] = {
    "seiffert": ("Seiffert dunkel", "#d7e0f0", "#17233d", "#7fdcff", "#2d4a7a",
                 ["#1b2740", "#ff6b6b", "#7ee0a1", "#f2d479", "#6fa8ff", "#c792ea", "#7fdcff", "#d7e0f0",
                  "#4a5a7d", "#ff8e8e", "#a5f0c0", "#ffe49a", "#9cc2ff", "#dcb1f5", "#a8eaff", "#ffffff"]),
    "seiffert-hell": ("Seiffert hell", "#1f2a44", "#f6f8fc", "#1f6feb", "#cfdcf5",
                      ["#1f2a44", "#c0392b", "#1e8449", "#8a5f00", "#1f5fbf", "#8e44ad", "#12788a", "#cfd6e4",
                       "#5b6785", "#e74c3c", "#27ae60", "#b7791f", "#3b82f6", "#a569bd", "#1aa3ba", "#ffffff"]),
    "graphit": ("Graphit", "#d4d4d4", "#1e1e1e", "#ffffff", "#3a3d41",
                ["#1e1e1e", "#f14c4c", "#23d18b", "#f5f543", "#3b8eea", "#d670d6", "#29b8db", "#e5e5e5",
                 "#666666", "#f14c4c", "#23d18b", "#f5f543", "#3b8eea", "#d670d6", "#29b8db", "#ffffff"]),
    "dracula": ("Dracula", "#f8f8f2", "#282a36", "#f8f8f2", "#44475a",
                ["#21222c", "#ff5555", "#50fa7b", "#f1fa8c", "#bd93f9", "#ff79c6", "#8be9fd", "#f8f8f2",
                 "#6272a4", "#ff6e6e", "#69ff94", "#ffffa5", "#d6acff", "#ff92df", "#a4ffff", "#ffffff"]),
    "nord": ("Nord", "#d8dee9", "#2e3440", "#d8dee9", "#434c5e",
             ["#3b4252", "#bf616a", "#a3be8c", "#ebcb8b", "#81a1c1", "#b48ead", "#88c0d0", "#e5e9f0",
              "#4c566a", "#bf616a", "#a3be8c", "#ebcb8b", "#81a1c1", "#b48ead", "#8fbcbb", "#eceff4"]),
    "gruvbox": ("Gruvbox dunkel", "#ebdbb2", "#282828", "#ebdbb2", "#504945",
                ["#282828", "#cc241d", "#98971a", "#d79921", "#458588", "#b16286", "#689d6a", "#a89984",
                 "#928374", "#fb4934", "#b8bb26", "#fabd2f", "#83a598", "#d3869b", "#8ec07c", "#ebdbb2"]),
    "solarized-dunkel": ("Solarized dunkel", "#839496", "#002b36", "#93a1a1", "#073642",
                         ["#073642", "#dc322f", "#859900", "#b58900", "#268bd2", "#d33682", "#2aa198", "#eee8d5",
                          "#586e75", "#cb4b16", "#586e75", "#657b83", "#839496", "#6c71c4", "#93a1a1", "#fdf6e3"]),
    "solarized-hell": ("Solarized hell", "#657b83", "#fdf6e3", "#586e75", "#eee8d5",
                       ["#073642", "#dc322f", "#859900", "#b58900", "#268bd2", "#d33682", "#2aa198", "#eee8d5",
                        "#002b36", "#cb4b16", "#586e75", "#657b83", "#839496", "#6c71c4", "#93a1a1", "#fdf6e3"]),
    "monokai": ("Monokai", "#f8f8f2", "#272822", "#f8f8f0", "#49483e",
                ["#272822", "#f92672", "#a6e22e", "#f4bf75", "#66d9ef", "#ae81ff", "#a1efe4", "#f8f8f2",
                 "#75715e", "#f92672", "#a6e22e", "#f4bf75", "#66d9ef", "#ae81ff", "#a1efe4", "#f9f8f5"]),
    "tokyo-night": ("Tokyo Night", "#c0caf5", "#1a1b26", "#c0caf5", "#283457",
                    ["#15161e", "#f7768e", "#9ece6a", "#e0af68", "#7aa2f7", "#bb9af7", "#7dcfff", "#a9b1d6",
                     "#414868", "#f7768e", "#9ece6a", "#e0af68", "#7aa2f7", "#bb9af7", "#7dcfff", "#c0caf5"]),
    "matrix": ("Matrix", "#33ff66", "#000000", "#33ff66", "#0a4d1f",
               ["#000000", "#ff3b3b", "#33ff66", "#c8ff33", "#29b6f6", "#b388ff", "#33ffd0", "#cfffd9",
                "#1f6b36", "#ff6b6b", "#66ff99", "#e6ff66", "#66ccff", "#cdb2ff", "#66ffe0", "#ffffff"]),
    "bernstein": ("Bernstein (Röhrenmonitor)", "#ffb000", "#1a1200", "#ffcc33", "#5a3d00",
                  ["#1a1200", "#ff6a3d", "#b8c000", "#ffb000", "#d99a00", "#ff8c42", "#ffd166", "#ffcc66",
                   "#7a5a00", "#ff8a65", "#d4dc3a", "#ffd24d", "#f0b429", "#ffa566", "#ffe08a", "#fff1c4"]),
}
DEFAULT_THEME = "seiffert"

SYNTAX_KEYS = ("kw", "str", "num", "com", "fn", "type", "op", "path", "url", "err", "warn", "ok", "add", "del", "info", "var")
SYNTAX_LABELS = {
    "kw": "Schlüsselwörter", "str": "Zeichenketten", "num": "Zahlen", "com": "Kommentare", "fn": "Funktionen",
    "type": "Typen und Klassen", "op": "Operatoren und Optionen", "path": "Pfade", "url": "Adressen (URL)",
    "err": "Fehler", "warn": "Warnungen", "ok": "Erfolg", "add": "Hinzugefügt (Diff)", "del": "Entfernt (Diff)",
    "info": "Hinweise, Datum, IP", "var": "Variablen",
}

# ---------------------------------------------------------------- Hervorhebungsregeln (JavaScript-Ausdrücke)
# Reihenfolge = Vorrang: was weiter oben steht, belegt die Zeichen zuerst.
DEFAULT_RULES = [
    {"id": "kommentar", "name": "Kommentare (# und // am Zeilenanfang oder nach Leerzeichen)", "on": True, "flags": "", "color": "com", "bg": "",
     "pattern": r"(?<![\w$&#:])(?:#|\/\/)(?=\s|$).*$"},
    {"id": "zeichenkette", "name": "Zeichenketten in Anführungszeichen", "on": True, "flags": "", "color": "str", "bg": "",
     "pattern": r"\"(?:[^\"\\\n]|\\.)*\"|(?<!\w)'(?:[^'\\\n]|\\.)*'"},
    {"id": "url", "name": "Internetadressen", "on": True, "flags": "i", "color": "url", "bg": "",
     "pattern": r"\b(?:https?|ftp)://[^\s<>\"')\]]+"},
    {"id": "pfad", "name": "Dateipfade", "on": True, "flags": "", "color": "path", "bg": "",
     "pattern": r"(?<![\w/.:~-])(?:~|\.{1,2})?/[\w.@%+~-]+(?:/[\w.@%+~-]+)*/?"},
    {"id": "fehlerklasse", "name": "Fehlerklassen (ValueError, …Exception)", "on": True, "flags": "", "color": "err", "bg": "",
     "pattern": r"\b\w*(?:Error|Exception)\b"},
    {"id": "fehler", "name": "Fehlerwörter (error, fehler, failed, …)", "on": True, "flags": "i", "color": "err", "bg": "",
     "pattern": r"\b(?:error|errors|fehler|fatal|failed|failure|traceback|denied|panic|critical|abgelehnt|fehlgeschlagen)\b"},
    {"id": "warnung", "name": "Warnwörter (warning, warnung, deprecated)", "on": True, "flags": "i", "color": "warn", "bg": "",
     "pattern": r"\b(?:warn|warning|warnings|warnung|warnungen|deprecated|veraltet)\b"},
    {"id": "erfolg", "name": "Erfolgswörter (ok, success, fertig, passed)", "on": True, "flags": "i", "color": "ok", "bg": "",
     "pattern": r"\b(?:ok|success|successful|successfully|erfolgreich|fertig|passed|done)\b"},
    {"id": "schluesselwort", "name": "Schlüsselwörter der Programmiersprachen", "on": True, "flags": "", "color": "kw", "bg": "",
     "pattern": r"\b(?:def|class|function|return|import|export|const|let|var|async|await|try|catch|except|finally|throw|raise|public|private|protected|static|void|struct|enum|fn|pub|lambda|yield|interface|extends|implements|package|namespace|typeof|None|True|False|null|true|false|undefined|self|this)\b"},
    {"id": "steuerwort", "name": "Steuerwörter (if, else, for, while), wenn sie nach Code aussehen", "on": True, "flags": "", "color": "kw", "bg": "",
     "pattern": r"\b(?:if|elif|else|for|while)\b(?=\s*\(|[^\n]*[:{]\s*$)"},
    {"id": "funktion", "name": "Funktionsaufrufe (name( … )", "on": True, "flags": "", "color": "fn", "bg": "",
     "pattern": r"\b[A-Za-z_]\w*(?=\()"},
    {"id": "variable", "name": "Shell-Variablen ($HOME, ${name})", "on": True, "flags": "", "color": "var", "bg": "",
     "pattern": r"\$\{?[A-Za-z_]\w*\}?"},
    {"id": "datum", "name": "Datum und Uhrzeit (2026-11-10, 19:38:05)", "on": True, "flags": "", "color": "info", "bg": "",
     "pattern": r"\b\d{4}-\d{2}-\d{2}(?:[T ]\d{2}:\d{2}(?::\d{2})?)?\b|\b\d{1,2}:\d{2}:\d{2}\b"},
    {"id": "ip", "name": "IP-Adressen", "on": True, "flags": "", "color": "info", "bg": "",
     "pattern": r"\b\d{1,3}(?:\.\d{1,3}){3}(?::\d+)?\b"},
    {"id": "zahl", "name": "Zahlen", "on": True, "flags": "", "color": "num", "bg": "",
     "pattern": r"(?<![\w.])(?:0x[0-9a-fA-F]+|\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)(?![\w.])"},
    {"id": "optionen", "name": "Kommandozeilen-Optionen (-v, --help)", "on": False, "flags": "", "color": "op", "bg": "",
     "pattern": r"(?<![\w-])--?[A-Za-z][\w-]*"},
    {"id": "diff-plus", "name": "Git-Diff: hinzugefügte Zeilen (+ …)", "on": False, "flags": "", "color": "add", "bg": "",
     "pattern": r"^\+(?!\+\+).*$"},
    {"id": "diff-minus", "name": "Git-Diff: entfernte Zeilen (- …)", "on": False, "flags": "", "color": "del", "bg": "",
     "pattern": r"^-(?!--).*$"},
    {"id": "diff-kopf", "name": "Git-Diff: Abschnittskopf (@@ … @@)", "on": False, "flags": "", "color": "info", "bg": "",
     "pattern": r"^@@.*@@"},
]

# ---------------------------------------------------------------- Tastenkürzel
KEY_ACTIONS = {
    "tab_new": ("Neuer Reiter", ["Ctrl+Shift+T"]),
    "tab_close": ("Reiter schließen", ["Ctrl+Shift+W"]),
    "tab_next": ("Nächster Reiter", ["Ctrl+PageDown"]),
    "tab_prev": ("Vorheriger Reiter", ["Ctrl+PageUp"]),
    "window_new": ("Neues Fenster", ["Ctrl+Shift+N"]),
    "window_close": ("Fenster schließen", ["Ctrl+Shift+Q"]),
    "fullscreen": ("Vollbild ein/aus", ["F11"]),
    "settings": ("Einstellungen", ["Ctrl+,"]),
    "search": ("Suchen", ["Ctrl+Shift+F"]),
    "copy": ("Kopieren", ["Ctrl+Shift+C"]),
    "paste": ("Einfügen", ["Ctrl+Shift+V"]),
    "select_all": ("Alles auswählen", ["Ctrl+Shift+A"]),
    "clear": ("Anzeige leeren", ["Ctrl+Shift+K"]),
    "zoom_in": ("Schrift größer", ["Ctrl++", "Ctrl+="]),
    "zoom_out": ("Schrift kleiner", ["Ctrl+-"]),
    "zoom_reset": ("Schriftgröße zurücksetzen", ["Ctrl+0"]),
    "highlight": ("Hervorhebung ein/aus", ["Ctrl+Shift+H"]),
    "view_file": ("Datei in Farben anzeigen", ["Ctrl+Shift+O"]),
    "duplicate": ("Reiter duplizieren", []),
}
KEY_MODS = ("Ctrl", "Alt", "Shift", "Meta")
_KEYNAME = re.compile(r"^(?:[A-Z0-9]|F(?:[1-9]|1[0-9]|2[0-4])|Tab|Enter|Escape|Space|Backspace|Delete|Insert|Home|End|PageUp|PageDown|"
                      r"ArrowUp|ArrowDown|ArrowLeft|ArrowRight|[,.\-+=;/\\'\[\]`])$")


def normalize_combo(value: str) -> str:
    """„strg + shift + t“ → „Ctrl+Shift+T“. Wirft AppError, wenn die Kombination keinen Sinn ergibt."""
    v = (value or "").strip()
    if not v:
        raise AppError("Ein Tastenkürzel darf nicht leer sein.")
    if v.endswith("++"):
        parts, key = v[:-2].split("+") if v[:-2] else [], "+"
    elif v == "+":
        parts, key = [], "+"
    else:
        bits = [b.strip() for b in v.split("+")]
        parts, key = bits[:-1], bits[-1]
    alias = {"strg": "Ctrl", "ctrl": "Ctrl", "control": "Ctrl", "alt": "Alt", "umschalt": "Shift", "shift": "Shift",
             "meta": "Meta", "super": "Meta", "win": "Meta", "cmd": "Meta"}
    mods = set()
    for p in parts:
        m = alias.get(p.lower())
        if not m:
            raise AppError("Unbekannte Umschalttaste „%s“ im Tastenkürzel „%s“." % (p, value))
        mods.add(m)
    names = {"esc": "Escape", "return": "Enter", "space": "Space", " ": "Space", "del": "Delete", "pgup": "PageUp", "pgdn": "PageDown",
             "up": "ArrowUp", "down": "ArrowDown", "left": "ArrowLeft", "right": "ArrowRight", "tab": "Tab", "enter": "Enter",
             "escape": "Escape", "backspace": "Backspace", "delete": "Delete", "insert": "Insert", "home": "Home", "end": "End",
             "pageup": "PageUp", "pagedown": "PageDown", "arrowup": "ArrowUp", "arrowdown": "ArrowDown", "arrowleft": "ArrowLeft",
             "arrowright": "ArrowRight"}
    k = names.get(key.lower(), key.upper() if len(key) == 1 or re.match(r"^[fF]\d+$", key) else key)
    if not _KEYNAME.match(k):
        raise AppError("Die Taste „%s“ im Tastenkürzel „%s“ wird nicht unterstützt." % (key, value))
    if not mods and not re.match(r"^F\d+$", k) and k not in ("Escape",):
        raise AppError("Das Tastenkürzel „%s“ braucht mindestens Strg, Alt, Umschalt oder Meta (Funktionstasten gehen ohne)." % value)
    return "+".join([m for m in KEY_MODS if m in mods] + [k])


# ---------------------------------------------------------------- Vorgaben und Prüfung
FONT_DEFAULT = '"DejaVu Sans Mono", "Liberation Mono", "Noto Sans Mono", monospace'

DEFAULTS: dict = {
    "theme": DEFAULT_THEME,
    "colors": {k: "" for k in COLOR_KEYS},              # leer = aus dem Farbschema
    "syntax": {k: "" for k in SYNTAX_KEYS},             # leer = aus dem Farbschema abgeleitet
    "bg": {"mode": "farbe", "color2": "#0b1020", "angle": 160, "image": "", "fit": "cover", "dim": 35, "blur": 0, "opacity": 100,
           "image_opacity": 100},
    "window": {"opacity": 100, "translucent": False, "on_top": False, "padding": 10, "width": 1000, "height": 640,
               "start": "normal", "remember_geometry": True, "confirm_close": "laufend", "hide_tabs_fullscreen": True,
               "tabbar": "oben", "tabbar_autohide": False, "title": "{titel}"},
    "font": {"family": FONT_DEFAULT, "size": 14, "line_height": 1.15, "letter_spacing": 0, "weight": "normal",
             "weight_bold": "bold"},
    "cursor": {"style": "block", "blink": True, "blink_timeout": 20, "inactive": "outline", "width": 2},   # blink_timeout: Sekunden Ruhe, bis das Blinken endet; 0 = immer
    "term": {"scrollback": 10000, "bell": "visuell", "copy_on_select": False, "right_click": "menu", "scroll_sensitivity": 1,
             "fast_scroll": 5, "min_contrast": 4.5, "bright_bold": False, "word_separator": " ()[]{}',\"`", "links": True,
             "scroll_on_input": True, "smooth_scroll": 0},
    "shell": {"on_exit": "schließen", "new_tab_cwd": "profil", "title_mode": "programm"},
    "profiles": [{"name": "Shell", "command": "", "args": [], "cwd": "", "login": False, "env": {}, "theme": ""}],
    "highlight": {"on": True, "only_plain": True, "max_line": 1000},
    "rules": DEFAULT_RULES,
    "keys": {a: list(v[1]) for a, v in KEY_ACTIONS.items()},
}

_HEX = re.compile(r"^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$")
_SLUG = re.compile(r"^[a-z0-9][a-z0-9_-]{0,39}$")
_ENV = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,63}$")
_FAMILY = re.compile(r"^[\w .,\"'+-]{1,200}$", re.UNICODE)


def _hex(v, what: str, empty_ok: bool = False) -> str:
    if v is None or v == "":
        if empty_ok:
            return ""
        raise AppError("%s: eine Farbe wie #1a2b3c ist nötig." % what)
    if not isinstance(v, str) or not _HEX.match(v.strip()):
        raise AppError("%s: „%s“ ist keine Farbe. Erlaubt ist #rgb oder #rrggbb." % (what, v))
    v = v.strip().lower()
    if len(v) == 4:
        v = "#" + "".join(c * 2 for c in v[1:])
    return v


def _num(v, lo, hi, what: str, integer: bool = False):
    try:
        if isinstance(v, bool):
            raise ValueError
        n = float(v)
    except (TypeError, ValueError):
        raise AppError("%s: „%s“ ist keine Zahl." % (what, v))
    if n != n or n < lo or n > hi:
        raise AppError("%s: Erlaubt sind Werte von %s bis %s." % (what, lo, hi))
    return int(round(n)) if integer else round(n, 3)


def _choice(v, options, what: str):
    if v not in options:
        raise AppError("%s: „%s“ gibt es nicht. Erlaubt: %s." % (what, v, ", ".join(options)))
    return v


def _bool(v, what: str) -> bool:
    if not isinstance(v, bool):
        raise AppError("%s: ja oder nein ist nötig." % what)
    return v


def _str(v, maxlen: int, what: str, allow_empty: bool = True) -> str:
    if not isinstance(v, str):
        raise AppError("%s: Text ist nötig." % what)
    v = v.replace("\x00", "")
    if len(v) > maxlen:
        raise AppError("%s: Höchstens %d Zeichen." % (what, maxlen))
    if not allow_empty and not v.strip():
        raise AppError("%s darf nicht leer sein." % what)
    return v


def _args(v, what: str) -> list:
    if isinstance(v, str):
        try:
            v = shlex.split(v)
        except ValueError as e:
            raise AppError("%s: Die Anführungszeichen passen nicht zusammen (%s)." % (what, e))
    if not isinstance(v, list) or len(v) > 30 or any(not isinstance(a, str) or len(a) > 400 for a in v):
        raise AppError("%s: Höchstens 30 Argumente aus Text." % what)
    return [a.replace("\x00", "") for a in v]


def _env(v, what: str) -> dict:
    if isinstance(v, str):                       # Eingabe als Zeilen NAME=Wert
        out = {}
        for ln in v.splitlines():
            ln = ln.strip()
            if not ln or ln.startswith("#"):
                continue
            if "=" not in ln:
                raise AppError("%s: Zeile „%s“ ist nicht von der Form NAME=Wert." % (what, ln))
            k, _, val = ln.partition("=")
            out[k.strip()] = val
        v = out
    if not isinstance(v, dict) or len(v) > 40:
        raise AppError("%s: Höchstens 40 Umgebungsvariablen." % what)
    for k, val in v.items():
        if not isinstance(k, str) or not _ENV.match(k):
            raise AppError("%s: „%s“ ist kein gültiger Variablenname." % (what, k))
        if not isinstance(val, str) or len(val) > 1000:
            raise AppError("%s: Der Wert von %s muss Text sein." % (what, k))
    return dict(v)


def _group(raw, cur: dict, spec: dict, name: str) -> dict:
    if not isinstance(raw, dict):
        raise AppError("%s: Einstellungsgruppe erwartet." % name)
    out = dict(cur)
    for k, fn in spec.items():
        if k in raw:
            out[k] = fn(raw[k], "%s.%s" % (name, k))
    return out


def _spec_colors():
    return {k: (lambda v, w: _hex(v, w, True)) for k in COLOR_KEYS}


SPEC = {
    "colors": _spec_colors(),
    "syntax": {k: (lambda v, w: _hex(v, w, True)) for k in SYNTAX_KEYS},
    "bg": {
        "mode": lambda v, w: _choice(v, ("farbe", "verlauf", "bild"), w),
        "color2": lambda v, w: _hex(v, w),
        "angle": lambda v, w: _num(v, 0, 360, w, True),
        "image": lambda v, w: _str(v, 1000, w),
        "fit": lambda v, w: _choice(v, ("cover", "contain", "kacheln", "mitte", "strecken"), w),
        "dim": lambda v, w: _num(v, 0, 100, w, True),
        "blur": lambda v, w: _num(v, 0, 40, w, True),
        "opacity": lambda v, w: _num(v, 0, 100, w, True),
        "image_opacity": lambda v, w: _num(v, 0, 100, w, True),
    },
    "window": {
        "opacity": lambda v, w: _num(v, 35, 100, w, True),
        "translucent": lambda v, w: _bool(v, w),
        "on_top": lambda v, w: _bool(v, w),
        "padding": lambda v, w: _num(v, 0, 60, w, True),
        "width": lambda v, w: _num(v, 300, 8000, w, True),
        "height": lambda v, w: _num(v, 200, 6000, w, True),
        "start": lambda v, w: _choice(v, ("normal", "maximiert", "vollbild"), w),
        "remember_geometry": lambda v, w: _bool(v, w),
        "confirm_close": lambda v, w: _choice(v, ("nie", "laufend", "immer"), w),
        "hide_tabs_fullscreen": lambda v, w: _bool(v, w),
        "tabbar": lambda v, w: _choice(v, ("oben", "unten"), w),
        "tabbar_autohide": lambda v, w: _bool(v, w),
        "title": lambda v, w: _str(v, 120, w),
    },
    "font": {
        "family": lambda v, w: v if isinstance(v, str) and _FAMILY.match(v.strip()) else (_ for _ in ()).throw(AppError("%s: Schriftname mit Buchstaben, Ziffern, Leerzeichen, Komma und Anführungszeichen." % w)),
        "size": lambda v, w: _num(v, 6, 72, w),
        "line_height": lambda v, w: _num(v, 1.0, 2.5, w),
        "letter_spacing": lambda v, w: _num(v, -3, 10, w),
        "weight": lambda v, w: _choice(v, ("100", "200", "300", "normal", "500", "600", "bold"), w),
        "weight_bold": lambda v, w: _choice(v, ("normal", "500", "600", "bold", "800", "900"), w),
    },
    "cursor": {
        "style": lambda v, w: _choice(v, ("block", "bar", "underline"), w),
        "blink": lambda v, w: _bool(v, w),
        "blink_timeout": lambda v, w: _num(v, 0, 600, w, True),
        "inactive": lambda v, w: _choice(v, ("outline", "block", "bar", "underline", "none"), w),
        "width": lambda v, w: _num(v, 1, 8, w, True),
    },
    "term": {
        "scrollback": lambda v, w: _num(v, 0, 200000, w, True),
        "bell": lambda v, w: _choice(v, ("aus", "visuell", "ton", "beides"), w),
        "copy_on_select": lambda v, w: _bool(v, w),
        "right_click": lambda v, w: _choice(v, ("menu", "einfuegen", "nichts"), w),
        "scroll_sensitivity": lambda v, w: _num(v, 0.1, 10, w),
        "fast_scroll": lambda v, w: _num(v, 1, 50, w),
        "min_contrast": lambda v, w: _num(v, 1, 21, w),
        "bright_bold": lambda v, w: _bool(v, w),
        "word_separator": lambda v, w: _str(v, 80, w),
        "links": lambda v, w: _bool(v, w),
        "scroll_on_input": lambda v, w: _bool(v, w),
        "smooth_scroll": lambda v, w: _num(v, 0, 500, w, True),
    },
    "shell": {
        "on_exit": lambda v, w: _choice(v, ("schließen", "offen"), w),
        "new_tab_cwd": lambda v, w: _choice(v, ("profil", "aktuell"), w),
        "title_mode": lambda v, w: _choice(v, ("programm", "ordner", "fest"), w),
    },
    "highlight": {
        "on": lambda v, w: _bool(v, w),
        "only_plain": lambda v, w: _bool(v, w),
        "max_line": lambda v, w: _num(v, 80, 20000, w, True),
    },
}


def clean_profiles(raw) -> list:
    if not isinstance(raw, list) or not 1 <= len(raw) <= 20:
        raise AppError("profiles: Es braucht 1 bis 20 Profile.")
    out, names = [], set()
    for i, p in enumerate(raw):
        w = "profiles[%d]" % i
        if not isinstance(p, dict):
            raise AppError("%s: Profil erwartet." % w)
        d = {"name": _str(p.get("name", ""), 40, w + ".name", False).strip(),
             "command": _str(p.get("command", ""), 300, w + ".command").strip(),
             "args": _args(p.get("args", []), w + ".args"),
             "cwd": _str(p.get("cwd", ""), 500, w + ".cwd").strip(),
             "login": _bool(p.get("login", False), w + ".login"),
             "env": _env(p.get("env", {}), w + ".env"),
             "theme": _str(p.get("theme", ""), 40, w + ".theme")}
        if d["theme"] and d["theme"] not in THEMES:
            raise AppError("%s.theme: Das Farbschema „%s“ gibt es nicht." % (w, d["theme"]))
        if d["name"].lower() in names:
            raise AppError("Zwei Profile heißen „%s“. Die Namen müssen verschieden sein." % d["name"])
        names.add(d["name"].lower())
        out.append(d)
    return out


def clean_rules(raw) -> list:
    if not isinstance(raw, list) or len(raw) > 100:
        raise AppError("rules: Höchstens 100 Hervorhebungsregeln.")
    out, ids = [], set()
    for i, r in enumerate(raw):
        w = "rules[%d]" % i
        if not isinstance(r, dict):
            raise AppError("%s: Regel erwartet." % w)
        rid = _str(r.get("id", ""), 40, w + ".id")
        if not _SLUG.match(rid):
            rid = "regel-%d" % (i + 1)
        while rid in ids:
            rid += "x"
        ids.add(rid)
        pat = _str(r.get("pattern", ""), 600, w + ".pattern")
        if not pat:
            raise AppError("%s: Das Suchmuster darf nicht leer sein." % w)
        flags = _str(r.get("flags", ""), 6, w + ".flags")
        if any(c not in "ims" for c in flags):
            raise AppError("%s: Erlaubte Schalter sind i (Groß/klein egal), m (Zeilenanfang/-ende) und s (Punkt trifft Zeilenumbruch)." % w)
        color = r.get("color", "")
        if color not in SYNTAX_KEYS:
            color = _hex(color, w + ".color")
        out.append({"id": rid, "name": _str(r.get("name", ""), 100, w + ".name").strip() or rid, "on": _bool(r.get("on", True), w + ".on"),
                    "pattern": pat, "flags": "".join(sorted(set(flags))), "color": color, "bg": _hex(r.get("bg", ""), w + ".bg", True)})
    return out


def clean_keys(raw, cur: dict) -> dict:
    if not isinstance(raw, dict):
        raise AppError("keys: Tastenkürzel-Gruppe erwartet.")
    out = {a: list(v) for a, v in cur.items()}
    for action, combos in raw.items():
        if action not in KEY_ACTIONS:
            continue
        if isinstance(combos, str):
            combos = [c for c in re.split(r"\s*[,;]\s*(?=\S)|\n", combos) if c.strip()] if combos.strip() else []
        if not isinstance(combos, list) or len(combos) > 4:
            raise AppError("keys.%s: Höchstens 4 Tastenkürzel." % action)
        seen = []
        for c in combos:
            n = normalize_combo(c)
            if n not in seen:
                seen.append(n)
        out[action] = seen
    used: dict[str, str] = {}
    for a, combos in out.items():
        for c in combos:
            if c in used and used[c] != a:
                raise AppError("Das Tastenkürzel %s ist doppelt belegt: „%s“ und „%s“." % (c, KEY_ACTIONS[used[c]][0], KEY_ACTIONS[a][0]))
            used[c] = a
    return out


def clean(raw: dict, current: dict | None = None) -> dict:
    """Legt die Änderung raw über current (oder die Vorgaben) und gibt den vollständigen, geprüften Stand zurück."""
    cur = copy.deepcopy(current if current is not None else DEFAULTS)
    if not isinstance(raw, dict):
        raise AppError("Einstellungen: Eine Zuordnung wird erwartet.")
    out = cur
    if "theme" in raw:
        out["theme"] = _choice(raw["theme"], tuple(THEMES), "theme")
    for g, spec in SPEC.items():
        if g in raw:
            out[g] = _group(raw[g], out.get(g, {}), spec, g)
    if "profiles" in raw:
        out["profiles"] = clean_profiles(raw["profiles"])
    if "rules" in raw:
        out["rules"] = clean_rules(raw["rules"])
    if "keys" in raw:
        out["keys"] = clean_keys(raw["keys"], out["keys"])
    return out


def merge(current: dict, patch: dict) -> dict:
    return clean(patch, current)


# ---------------------------------------------------------------- Farben zusammenrechnen
def _rgb(h: str):
    h = h.lstrip("#")
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def _mix(a: str, b: str, t: float) -> str:
    ra, rb = _rgb(a), _rgb(b)
    return "#%02x%02x%02x" % tuple(round(x + (y - x) * t) for x, y in zip(ra, rb))


def luminance(h: str) -> float:
    def ch(v):
        v /= 255
        return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    r, g, b = _rgb(h)
    return 0.2126 * ch(r) + 0.7152 * ch(g) + 0.0722 * ch(b)


def contrast(a: str, b: str) -> float:
    la, lb = luminance(a), luminance(b)
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)


def theme_colors(name: str) -> dict:
    label, fg, bg, cur, sel, ansi = THEMES[name]
    out = {"foreground": fg, "background": bg, "cursor": cur, "cursor_accent": bg, "selection": sel}
    out.update(dict(zip(ANSI_NAMES, ansi)))
    return out


def _legible(color: str, bg: str, ratio: float) -> str:
    """Zieht die Farbe schrittweise Richtung Schwarz oder Weiß (je nach Hintergrund), bis sie genug Kontrast hat."""
    target = "#ffffff" if luminance(bg) < 0.4 else "#000000"
    for i in range(0, 21):
        c = _mix(color, target, i / 20)
        if contrast(c, bg) >= ratio:
            return c
    return c


def syntax_from_theme(c: dict) -> dict:
    raw = _syntax_raw(c)
    return {k: _legible(v, c["background"], 3.6 if k == "com" else 4.5) for k, v in raw.items()}


def _syntax_raw(c: dict) -> dict:
    return {"kw": c["magenta"], "str": c["green"], "num": c["yellow"], "com": _mix(c["foreground"], c["background"], 0.45),
            "fn": c["blue"], "type": c["cyan"], "op": c["bright_cyan"], "path": c["cyan"], "url": c["bright_blue"],
            "err": c["red"], "warn": c["yellow"], "ok": c["green"], "add": c["green"], "del": c["red"],
            "info": c["bright_blue"], "var": c["bright_magenta"]}


def resolve(s: dict, theme: str = "") -> dict:
    """Fertige Farben: Farbschema (auch je Profil abweichend), darüber die eigenen Farben; daraus die Syntaxfarben."""
    name = theme if theme in THEMES else s.get("theme", DEFAULT_THEME)
    colors = theme_colors(name)
    if not theme:                                           # eigene Farben gelten für das eingestellte Farbschema
        for k in COLOR_KEYS:
            v = s["colors"].get(k, "")
            if v:
                colors[k] = v
    syn = syntax_from_theme(colors)
    if not theme:
        for k in SYNTAX_KEYS:
            if s["syntax"].get(k):
                syn[k] = s["syntax"][k]
    return {"theme": name, "dark": luminance(colors["background"]) < 0.4, "colors": colors, "syntax": syn}


def theme_list() -> list:
    return [{"id": k, "label": v[0], "background": v[2], "foreground": v[1], "dark": luminance(v[2]) < 0.4,
             "palette": v[5][:8]} for k, v in THEMES.items()]


# ---------------------------------------------------------------- Laden und Speichern
def _atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def load() -> dict:
    """Liest die gespeicherten Einstellungen. Fehlt die Datei oder ist sie unlesbar, gelten die Vorgaben.
    Einzelne ungültige Werte werden durch die Vorgabe ersetzt, der Rest bleibt erhalten."""
    p = config_dir() / "settings.json"
    cur = copy.deepcopy(DEFAULTS)
    try:
        raw = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return cur
    if not isinstance(raw, dict):
        return cur
    for key in list(raw):                                   # Wert für Wert, damit ein kaputter Eintrag nicht alles verwirft
        try:
            cur = clean({key: raw[key]} if key not in SPEC else {key: raw[key]}, cur)
        except AppError:
            if key in SPEC and isinstance(raw[key], dict):
                for sub, val in raw[key].items():
                    try:
                        cur = clean({key: {sub: val}}, cur)
                    except AppError:
                        pass
    return cur


def save(settings: dict) -> None:
    _atomic_write(config_dir() / "settings.json", json.dumps(settings, ensure_ascii=False, indent=1) + "\n")


def load_state() -> dict:
    try:
        d = json.loads((config_dir() / "state.json").read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def save_state(state: dict) -> None:
    _atomic_write(config_dir() / "state.json", json.dumps(state, ensure_ascii=False) + "\n")


def export_text(settings: dict) -> str:
    return json.dumps({"seiffert-terminal": VERSION, "settings": settings}, ensure_ascii=False, indent=1)


def import_text(text: str, current: dict) -> dict:
    """Übernimmt eine exportierte Einstellungsdatei. Ungültiges wird nicht stillschweigend ignoriert."""
    try:
        d = json.loads(text)
    except ValueError as e:
        raise AppError("Die Datei ist keine gültige Einstellungsdatei (%s)." % e)
    if isinstance(d, dict) and "settings" in d and isinstance(d["settings"], dict):
        d = d["settings"]
    if not isinstance(d, dict):
        raise AppError("Die Datei enthält keine Einstellungen von Seifferts Terminal.")
    return clean(d, current)
