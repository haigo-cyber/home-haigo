"""Zuschnitt in Seifferts Text: PDF, PNG und JPEG zuschneiden, mit Textrahmen und Grafiken versehen, teilen und zusammenfügen.
Das Fenster läuft als Tab im Hauptfenster von Seifferts Text (wie die PDF-Tabs). Speichern legt immer eine NEUE Datei an."""
import math
import os
import re

import pymupdf
from PySide6.QtCore import QTimer, Qt, QRectF, QPointF, QRect, QByteArray, QBuffer, QIODevice
from PySide6.QtGui import (QImage, QRegion, QPainter, QColor, QFont, QPen, QBrush, QAction, QKeySequence,
                           QImageReader, QIcon, QPixmap, QTextOption, QImageIOHandler)
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QScrollArea, QFileDialog, QMessageBox,
                               QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QPlainTextEdit,
                               QDoubleSpinBox, QComboBox, QCheckBox, QPushButton, QLabel, QLineEdit,
                               QColorDialog, QDialogButtonBox, QSpinBox, QMenu, QListWidget, QListWidgetItem,
                               QAbstractItemView)

from . import APP_NAME, VERSION
from .common import fullscreen_action
from .zs_core import (TextItem, ImageItem, extend_pdf_page, pdf_source_item, copy_items, subst, save_pdf, split_pdf, merge_pdfs, pdf_info, write_image,
                   read_image_meta, FONT_NAMES, DEFAULTS as DEFAULT_CFG)

M = 220                      # Rand um die Seite in Bildschirmpunkten (Platz zum Aufziehen über den Seitenrand hinaus)
HANDLE = 9
IMG_EXT = (".png", ".jpg", ".jpeg")
OPEN_FILTER = "PDF und Bilder (*.pdf *.PDF *.png *.PNG *.jpg *.JPG *.jpeg *.JPEG);;PDF (*.pdf *.PDF);;Bilder (*.png *.PNG *.jpg *.JPG *.jpeg *.JPEG);;Alle Dateien (*)"


def qfont_for(it, px):
    f = QFont({"sans": "Liberation Sans", "serif": "Liberation Serif", "mono": "Liberation Mono"}[it.font])
    f.setStyleHint({"sans": QFont.SansSerif, "serif": QFont.Serif, "mono": QFont.Monospace}[it.font])
    f.setBold(it.bold)
    f.setPixelSize(max(1, int(round(px))))
    return f


def item_qimage(it, wpx, hpx):
    """Pixelbild einer Grafik oder eines PDF-Ausschnitts in der Zielgröße (für Anzeige und Bild-Ausgabe)."""
    wpx, hpx = max(1, int(round(wpx))), max(1, int(round(hpx)))
    key = (wpx, hpx)
    pv = getattr(it, "_pv", None)
    if pv and pv[0] == key:
        return pv[1]
    if it.src == "pdf":
        doc = pymupdf.open("pdf", it.data)
        try:
            cl = pymupdf.Rect(*it.clip)
            pix = doc[0].get_pixmap(matrix=pymupdf.Matrix(wpx / cl.width, hpx / cl.height), clip=cl, alpha=False)
            q = QImage(pix.samples, pix.width, pix.height, pix.stride, QImage.Format_RGB888).copy()
        finally:
            doc.close()
    else:
        orig = getattr(it, "_orig", None)
        if orig is None:
            orig = QImage.fromData(it.data)
            it._orig = orig
        q = orig if (orig.width(), orig.height()) == key else orig.scaled(wpx, hpx, Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
    it._pv = (key, q)
    return q


def paint_item(p, it, z, text, dpr=1.0):
    """Zeichnet einen Textrahmen oder eine Grafik (Dokumentmaße mal z). Für Anzeige und Bild-Export."""
    r = QRectF(it.x * z, it.y * z, it.w * z, it.h * z)
    if it.is_image:
        q = item_qimage(it, min(r.width() * dpr, 4000), min(r.height() * dpr, 4000))
        p.save()
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.drawImage(r, q)
        p.restore()
        return
    if it.bg:
        p.fillRect(r, QColor("white"))
    if not text.strip():
        return
    p.save()
    p.setClipRect(r)
    p.setPen(QColor(it.color))
    p.setFont(qfont_for(it, it.size * z))
    opt = QTextOption([Qt.AlignLeft, Qt.AlignHCenter, Qt.AlignRight][it.align])
    opt.setWrapMode(QTextOption.WrapAtWordBoundaryOrAnywhere)
    p.drawText(r, text, opt)
    p.restore()


class TextDialog(QDialog):
    def __init__(self, parent, it, unit, is_pdf, page_count):
        super().__init__(parent)
        self.setWindowTitle("Textrahmen")
        self.it = it
        self.color = it.color
        lay = QVBoxLayout(self)
        self.edit = QPlainTextEdit(it.text)
        self.edit.setMinimumSize(380, 110)
        lay.addWidget(self.edit)
        if is_pdf:
            lay.addWidget(QLabel("Tipp: {seite} wird zur Seitenzahl, {seiten} zur Seitenanzahl."))
        form = QFormLayout()
        self.size = QDoubleSpinBox()
        self.size.setRange(2, 2000)
        self.size.setDecimals(1)
        self.size.setValue(it.size)
        self.size.setSuffix(" " + unit)
        form.addRow("Schriftgröße", self.size)
        self.font = QComboBox()
        for k, v in FONT_NAMES.items():
            self.font.addItem(v, k)
        self.font.setCurrentIndex(list(FONT_NAMES).index(it.font))
        form.addRow("Schrift", self.font)
        self.bold = QCheckBox("Fett")
        self.bold.setChecked(it.bold)
        form.addRow("", self.bold)
        self.align = QComboBox()
        self.align.addItems(["Linksbündig", "Zentriert", "Rechtsbündig"])
        self.align.setCurrentIndex(it.align)
        form.addRow("Ausrichtung", self.align)
        self.colbtn = QPushButton()
        self.colbtn.clicked.connect(self.pick)
        self.paint_btn()
        form.addRow("Farbe", self.colbtn)
        self.bg = QCheckBox("Weißer Hintergrund (deckt Darunterliegendes ab)")
        self.bg.setChecked(it.bg)
        form.addRow("", self.bg)
        lay.addLayout(form)
        self.allp = None
        if is_pdf and page_count > 1:
            self.allp = QCheckBox("Zusätzlich auf alle anderen Seiten setzen (gleiche Stelle)")
            lay.addWidget(self.allp)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self.edit.setFocus()

    def paint_btn(self):
        self.colbtn.setText(self.color)
        self.colbtn.setStyleSheet(f"background:{self.color};color:{'#fff' if QColor(self.color).lightness() < 128 else '#000'}")

    def pick(self):
        c = QColorDialog.getColor(QColor(self.color), self, "Farbe")
        if c.isValid():
            self.color = c.name()
            self.paint_btn()

    def apply(self):
        it = self.it
        it.text = self.edit.toPlainText()
        it.size = self.size.value()
        it.font = self.font.currentData()
        it.bold = self.bold.isChecked()
        it.align = self.align.currentIndex()
        it.color = self.color
        it.bg = self.bg.isChecked()
        return self.allp is not None and self.allp.isChecked()


class MergeDialog(QDialog):
    """Mehrere PDF-Dateien zu einer zusammenfügen."""

    def __init__(self, parent, cfg, start_dir):
        super().__init__(parent)
        self.setWindowTitle("PDFs zusammenfügen")
        self.resize(620, 480)
        self.cfg = cfg
        self.start_dir = start_dir
        self.result_path = None
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Dateien in der Reihenfolge, in der sie zusammengefügt werden (Ziehen ändert die Reihenfolge):"))
        self.list = QListWidget()
        self.list.setDragDropMode(QAbstractItemView.InternalMove)
        self.list.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.list.model().rowsMoved.connect(self.update_info)
        lay.addWidget(self.list, 1)
        row = QHBoxLayout()
        for text, slot in (("Hinzufügen …", self.add_dialog), ("Entfernen", self.remove_selected),
                           ("Nach oben", lambda: self.move(-1)), ("Nach unten", lambda: self.move(1))):
            b = QPushButton(text)
            b.clicked.connect(slot)
            row.addWidget(b)
        row.addStretch(1)
        lay.addLayout(row)
        self.info = QLabel("")
        lay.addWidget(self.info)
        form = QFormLayout()
        self.name = QLineEdit("Zusammengefügt.pdf")
        form.addRow("Dateiname:", self.name)
        frow = QHBoxLayout()
        self.folder = QLineEdit(cfg.get("save_dir") or start_dir or "")
        fb = QPushButton("Wählen …")
        fb.clicked.connect(self.pick_folder)
        frow.addWidget(self.folder, 1)
        frow.addWidget(fb)
        form.addRow("Ordner:", frow)
        lay.addLayout(form)
        bb = QDialogButtonBox()
        self.ok_btn = bb.addButton("Zusammenfügen", QDialogButtonBox.AcceptRole)
        bb.addButton("Abbrechen", QDialogButtonBox.RejectRole)
        bb.accepted.connect(self.run_merge)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self.update_info()

    def paths(self):
        return [self.list.item(i).data(Qt.UserRole) for i in range(self.list.count())]

    def add_paths(self, paths):
        bad = []
        have = set(self.paths())
        for p in paths:
            p = os.path.abspath(p)
            n, err = pdf_info(p)
            if err:
                bad.append(f"{os.path.basename(p)}: {err}")
                continue
            it = QListWidgetItem(f"{os.path.basename(p)}   ({n} Seite{'n' if n != 1 else ''})")
            it.setData(Qt.UserRole, p)
            it.setData(Qt.UserRole + 1, n)
            it.setToolTip(p)
            self.list.addItem(it)
            if p in have:
                it.setText(it.text() + "   – mehrfach in der Liste")
        if bad:
            QMessageBox.warning(self, APP_NAME, "Nicht hinzugefügt:\n" + "\n".join(bad))
        self.update_info()
        return bad

    def add_dialog(self):
        files, _ = QFileDialog.getOpenFileNames(self, "PDF-Dateien wählen", self.start_dir or "", "PDF (*.pdf)")
        if files:
            self.start_dir = os.path.dirname(files[0])
            self.add_paths(files)

    def remove_selected(self):
        for it in self.list.selectedItems():
            self.list.takeItem(self.list.row(it))
        self.update_info()

    def move(self, d):
        rows = sorted(self.list.row(i) for i in self.list.selectedItems())
        if not rows:
            return
        if d < 0 and rows[0] == 0 or d > 0 and rows[-1] == self.list.count() - 1:
            return
        for r in (rows if d < 0 else reversed(rows)):
            it = self.list.takeItem(r)
            self.list.insertItem(r + d, it)
            it.setSelected(True)
        self.update_info()

    def pick_folder(self):
        f = QFileDialog.getExistingDirectory(self, "Ordner für die neue Datei", self.folder.text() or self.start_dir or "")
        if f:
            self.folder.setText(f)

    def update_info(self, *a):
        total = sum(self.list.item(i).data(Qt.UserRole + 1) for i in range(self.list.count()))
        self.info.setText(f"{self.list.count()} Datei(en), zusammen {total} Seiten")
        self.ok_btn.setEnabled(self.list.count() >= 2)

    def run_merge(self):
        paths = self.paths()
        if len(paths) < 2:
            QMessageBox.information(self, APP_NAME, "Bitte mindestens zwei Dateien hinzufügen.")
            return
        name = self.name.text().strip() or "Zusammengefügt.pdf"
        if not name.lower().endswith(".pdf"):
            name += ".pdf"
        name = os.path.basename(name)
        folder = self.folder.text().strip() or os.path.dirname(paths[0])
        if not os.path.isdir(folder):
            QMessageBox.warning(self, APP_NAME, f"Der Ordner existiert nicht:\n{folder}")
            return
        out = os.path.join(folder, name)
        if os.path.abspath(out) in [os.path.abspath(p) for p in paths]:
            QMessageBox.warning(self, APP_NAME, "Die neue Datei darf nicht den Namen einer der Quelldateien haben.")
            return
        if os.path.exists(out):
            if QMessageBox.question(self, APP_NAME, f"{name} existiert schon im Ordner. Überschreiben?",
                                    QMessageBox.Yes | QMessageBox.Cancel, QMessageBox.Cancel) != QMessageBox.Yes:
                return
        try:
            n = merge_pdfs(paths, out)
        except Exception as e:  # noqa: BLE001
            QMessageBox.critical(self, APP_NAME, f"Zusammenfügen nicht möglich:\n{e}")
            return
        self.result_path = out
        self.result_pages = n
        self.accept()


class ExtendDialog(QDialog):
    """Weiße Fläche an den Rändern ergänzen."""

    def __init__(self, parent, is_pdf, n_pages, size):
        super().__init__(parent)
        self.setWindowTitle("Weiße Fläche ergänzen")
        self.is_pdf = is_pdf
        self.size = size
        lay = QVBoxLayout(self)
        unit = "mm" if is_pdf else "Pixel"
        lay.addWidget(QLabel(f"Wie viel weiße Fläche soll an jedem Rand dazukommen? (in {unit}, wie angezeigt)"))
        form = QFormLayout()
        self.spins = {}
        for key, text in (("top", "Oben"), ("bottom", "Unten"), ("left", "Links"), ("right", "Rechts")):
            sp = QDoubleSpinBox() if is_pdf else QSpinBox()
            sp.setRange(0, 2000 if is_pdf else 20000)
            if is_pdf:
                sp.setDecimals(1)
                sp.setSingleStep(5)
            sp.setSuffix(" " + unit)
            sp.valueChanged.connect(lambda v, k=key: self.changed(k, v))
            self.spins[key] = sp
            form.addRow(text + ":", sp)
        lay.addLayout(form)
        self.same = QCheckBox("Alle vier Ränder gleich")
        lay.addWidget(self.same)
        self.all = QCheckBox("Auf alle Seiten anwenden")
        self.all.setVisible(is_pdf and n_pages > 1)
        lay.addWidget(self.all)
        self.info = QLabel("")
        lay.addWidget(self.info)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText("Ergänzen")
        bb.button(QDialogButtonBox.Cancel).setText("Abbrechen")
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self.update_info()

    def changed(self, key, v):
        if self.same.isChecked():
            for k, sp in self.spins.items():
                if k != key:
                    sp.blockSignals(True)
                    sp.setValue(v)
                    sp.blockSignals(False)
        self.update_info()

    def values(self):
        """(links, oben, rechts, unten) in Dokumentmaßen (pt bei PDF, Pixel bei Bildern)."""
        f = (72.0 / 25.4) if self.is_pdf else 1.0
        g = lambda k: float(self.spins[k].value()) * f  # noqa: E731
        return g("left"), g("top"), g("right"), g("bottom")

    def update_info(self):
        l, t, r, b = self.values()
        W, H = self.size
        if self.is_pdf:
            self.info.setText(f"Neue Größe: {(W + l + r) / 72 * 25.4:.1f} × {(H + t + b) / 72 * 25.4:.1f} mm")
        else:
            self.info.setText(f"Neue Größe: {int(W + l + r)} × {int(H + t + b)} Pixel")


class ClipView(QWidget):
    """Zeigt eine PDF-Seite und lässt mit der Maus einen Ausschnitt aufziehen."""

    def __init__(self, qimg, page_w, page_h):
        super().__init__()
        self.q = qimg
        self.pw, self.ph = page_w, page_h
        self.sel = None          # QRectF in Seitenmaßen
        self.drag = None
        self.setFixedSize(qimg.width(), qimg.height())
        self.setCursor(Qt.CrossCursor)

    def set_image(self, qimg, pw, ph):
        self.q, self.pw, self.ph = qimg, pw, ph
        self.sel = None
        self.setFixedSize(qimg.width(), qimg.height())
        self.update()

    def to_page(self, pos):
        x = min(max(pos.x(), 0), self.width()) * self.pw / self.width()
        y = min(max(pos.y(), 0), self.height()) * self.ph / self.height()
        return QPointF(x, y)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.drag = self.to_page(e.position())
            self.sel = QRectF(self.drag, self.drag)
            self.update()

    def mouseMoveEvent(self, e):
        if self.drag is not None:
            self.sel = QRectF(self.drag, self.to_page(e.position())).normalized()
            self.update()

    def mouseReleaseEvent(self, e):
        self.drag = None
        if self.sel is not None and (self.sel.width() < 3 or self.sel.height() < 3):
            self.sel = None
        self.update()

    def paintEvent(self, ev):
        p = QPainter(self)
        p.drawImage(0, 0, self.q)
        if self.sel is not None:
            sx, sy = self.width() / self.pw, self.height() / self.ph
            r = QRectF(self.sel.x() * sx, self.sel.y() * sy, self.sel.width() * sx, self.sel.height() * sy)
            dim = QColor(0, 0, 0, 110)
            p.fillRect(QRectF(0, 0, self.width(), r.top()), dim)
            p.fillRect(QRectF(0, r.bottom(), self.width(), self.height() - r.bottom()), dim)
            p.fillRect(QRectF(0, r.top(), r.left(), r.height()), dim)
            p.fillRect(QRectF(r.right(), r.top(), self.width() - r.right(), r.height()), dim)
            p.setPen(QPen(QColor("#1e90ff"), 2))
            p.drawRect(r)


class ClipDialog(QDialog):
    """Seite und Ausschnitt aus einer PDF wählen."""

    def __init__(self, parent, path):
        super().__init__(parent)
        self.setWindowTitle("Ausschnitt aus PDF wählen")
        self.path = path
        self.doc = pymupdf.open(path)
        self.pno = 0
        self.result_clip = None
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Mit der Maus den gewünschten Ausschnitt aufziehen. Ohne Auswahl wird die ganze Seite eingefügt."))
        row = QHBoxLayout()
        self.spin = QSpinBox()
        self.spin.setRange(1, self.doc.page_count)
        self.spin.setPrefix("Seite ")
        self.spin.setSuffix(f" von {self.doc.page_count}")
        self.spin.valueChanged.connect(self.load_page)
        row.addWidget(self.spin)
        b = QPushButton("Auswahl aufheben")
        b.clicked.connect(self.clear)
        row.addWidget(b)
        row.addStretch(1)
        lay.addLayout(row)
        self.view = ClipView(*self.render(0))
        sc = QScrollArea()
        sc.setWidget(self.view)
        sc.setMinimumSize(560, 520)
        lay.addWidget(sc, 1)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText("Einfügen")
        bb.button(QDialogButtonBox.Cancel).setText("Abbrechen")
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self.resize(720, 760)

    def render(self, pno):
        page = self.doc[pno]
        W, H = page.rect.width, page.rect.height
        z = min(1.5, 1100.0 / max(W, H))
        pix = page.get_pixmap(matrix=pymupdf.Matrix(z, z), alpha=False)
        q = QImage(pix.samples, pix.width, pix.height, pix.stride, QImage.Format_RGB888).copy()
        return q, W, H

    def load_page(self, v):
        self.pno = v - 1
        q, W, H = self.render(self.pno)
        self.view.set_image(q, W, H)

    def clear(self):
        self.view.sel = None
        self.view.update()

    def accept(self):
        s = self.view.sel
        self.result_clip = None if s is None else (s.left(), s.top(), s.right(), s.bottom())
        self.doc.close()
        super().accept()

    def reject(self):
        self.doc.close()
        super().reject()


class SettingsDialog(QDialog):
    def __init__(self, parent, s):
        super().__init__(parent)
        self.setWindowTitle("Einstellungen")
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Standardordner zum Speichern (für Speichern unter):"))
        row = QHBoxLayout()
        self.dir = QLineEdit(s["save_dir"])
        b = QPushButton("Wählen …")
        b.clicked.connect(self.choose)
        row.addWidget(self.dir, 1)
        row.addWidget(b)
        lay.addLayout(row)
        self.bak = QCheckBox("Beim Überschreiben eine Sicherung anlegen (Dateiname.bak)")
        self.bak.setChecked(s["backup"])
        lay.addWidget(self.bak)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self.setMinimumWidth(480)

    def choose(self):
        d = QFileDialog.getExistingDirectory(self, "Standardordner", self.dir.text() or os.path.expanduser("~"))
        if d:
            self.dir.setText(d)

    def values(self):
        return {"save_dir": self.dir.text().strip(), "backup": self.bak.isChecked()}


class Canvas(QWidget):
    def __init__(self, win):
        super().__init__()
        self.win = win
        self.z = 1.0
        self.mode = "crop"          # crop oder text
        self.crop = None            # QRectF in Dokumentmaßen
        self.sel = None
        self.drag = None
        self._scaled = None         # (key, QImage) für Bilder
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.StrongFocus)

    # --- Umrechnung
    def to_doc(self, pos):
        return QPointF((pos.x() - M) / self.z, (pos.y() - M) / self.z)

    def to_view(self, r):
        return QRectF(M + r.x() * self.z, M + r.y() * self.z, r.width() * self.z, r.height() * self.z)

    def item_rect(self, it):
        return QRectF(it.x, it.y, it.w, it.h)

    def relayout(self):
        if not self.win.has_doc():
            self.setFixedSize(10, 10)
            return
        W, H = self.win.page_size()
        self.setFixedSize(int(W * self.z) + 2 * M, int(H * self.z) + 2 * M)
        self.update()

    # --- Zeichnen
    def paintEvent(self, ev):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor("#505050"))
        w = self.win
        if not w.has_doc():
            p.setPen(QColor("#dddddd"))
            p.drawText(self.rect(), Qt.AlignCenter, "Datei öffnen (Strg+O) oder hierher ziehen")
            return
        W, H = w.page_size()
        dpr = self.devicePixelRatioF()
        base = w.base_image(self.z, dpr)
        if self.mode == "crop" and self.crop is not None and self.crop.width() > 0:
            p.fillRect(self.to_view(self.crop.normalized()), QColor("white"))   # Fläche über den Seitenrand hinaus wird weiß ergänzt
        p.drawImage(QPointF(M, M), base)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.TextAntialiasing)
        p.save()
        p.translate(M, M)
        for it in w.cur_items():
            paint_item(p, it, self.z, subst(it.text, w.page_no, w.page_count()), dpr)
        p.restore()
        for it in w.cur_items():
            r = self.to_view(self.item_rect(it))
            p.setBrush(Qt.NoBrush)
            if it is self.sel and self.mode == "text":
                p.setPen(QPen(QColor("#1e90ff"), 2))
                p.drawRect(r)
                p.fillRect(QRectF(r.right() - HANDLE, r.bottom() - HANDLE, HANDLE, HANDLE), QColor("#1e90ff"))
            elif self.mode == "text":
                p.setPen(QPen(QColor(30, 144, 255, 150), 1, Qt.DashLine))
                p.drawRect(r)
        if self.crop is not None and self.crop.width() > 0:
            c = self.to_view(self.crop.normalized())
            page = QRectF(M, M, W * self.z, H * self.z)
            dim = QColor(0, 0, 0, 120)
            reg = QRegion(page.toAlignedRect()).subtracted(QRegion(c.toAlignedRect()))
            for rc in reg:
                p.fillRect(rc, dim)
            p.setPen(QPen(QColor("white"), 1))
            p.drawRect(c)
            p.setPen(QPen(QColor("black"), 1, Qt.DashLine))
            p.drawRect(c)
            for hx, hy in self.handle_points(c).values():
                p.fillRect(QRectF(hx - HANDLE / 2, hy - HANDLE / 2, HANDLE, HANDLE), QColor("white"))
                p.setPen(QColor("black"))
                p.drawRect(QRectF(hx - HANDLE / 2, hy - HANDLE / 2, HANDLE, HANDLE))

    @staticmethod
    def handle_points(c):
        cx, cy = c.center().x(), c.center().y()
        return {"tl": (c.left(), c.top()), "t": (cx, c.top()), "tr": (c.right(), c.top()),
                "r": (c.right(), cy), "br": (c.right(), c.bottom()), "b": (cx, c.bottom()),
                "bl": (c.left(), c.bottom()), "l": (c.left(), cy)}

    def crop_hit(self, pos):
        if self.crop is None:
            return None
        c = self.to_view(self.crop.normalized())
        for name, (hx, hy) in self.handle_points(c).items():
            if abs(pos.x() - hx) <= HANDLE and abs(pos.y() - hy) <= HANDLE:
                return name
        if c.contains(pos):
            return "move"
        return None

    def clamp_point(self, d, over=False):
        W, H = self.win.page_size()
        if over:
            m = (M - 2) / self.z
            return QPointF(min(max(d.x(), -m), W + m), min(max(d.y(), -m), H + m))
        return QPointF(min(max(d.x(), 0), W), min(max(d.y(), 0), H))

    # --- Maus
    def mousePressEvent(self, e):
        w = self.win
        if not w.has_doc():
            return
        pos = e.position()
        d = self.clamp_point(self.to_doc(pos), self.mode == "crop")
        if self.mode == "crop":
            if e.button() != Qt.LeftButton:
                return
            h = self.crop_hit(pos)
            if h:
                self.drag = {"k": "crop", "h": h, "start": d, "orig": QRectF(self.crop.normalized())}
            else:
                self.crop = QRectF(d, d)
                self.drag = {"k": "newcrop", "start": d}
            self.update()
            return
        # Textmodus
        hit = None
        for it in reversed(w.cur_items()):
            if self.to_view(self.item_rect(it)).adjusted(-3, -3, 3, 3).contains(pos):
                hit = it
                break
        if e.button() == Qt.RightButton:
            if hit:
                self.sel = hit
                self.update()
                self.item_menu(hit, e.globalPosition().toPoint())
            return
        if e.button() != Qt.LeftButton:
            return
        if hit:
            self.sel = hit
            r = self.to_view(self.item_rect(hit))
            corner = pos.x() >= r.right() - HANDLE - 2 and pos.y() >= r.bottom() - HANDLE - 2
            self.drag = {"k": "resize" if corner else "move", "item": hit, "start": d,
                         "orig": QRectF(hit.x, hit.y, hit.w, hit.h), "snap": w.snap(), "moved": False}
        else:
            self.sel = None
            self.drag = {"k": "newtext", "start": d, "cur": d}
        self.update()

    def mouseMoveEvent(self, e):
        w = self.win
        if not w.has_doc():
            return
        pos = e.position()
        d = self.clamp_point(self.to_doc(pos), self.mode == "crop")
        dr = self.drag
        if not dr:
            if self.mode == "crop":
                h = self.crop_hit(pos)
                self.setCursor({"move": Qt.SizeAllCursor, "tl": Qt.SizeFDiagCursor, "br": Qt.SizeFDiagCursor,
                                "tr": Qt.SizeBDiagCursor, "bl": Qt.SizeBDiagCursor, "t": Qt.SizeVerCursor,
                                "b": Qt.SizeVerCursor, "l": Qt.SizeHorCursor, "r": Qt.SizeHorCursor}.get(h, Qt.CrossCursor))
            else:
                self.setCursor(Qt.CrossCursor)
            return
        k = dr["k"]
        if k == "newcrop":
            self.crop = QRectF(dr["start"], d)
        elif k == "crop":
            o = dr["orig"]
            h = dr["h"]
            if h == "move":
                W, H = w.page_size()
                dx, dy = d.x() - dr["start"].x(), d.y() - dr["start"].y()
                m = (M - 2) / self.z
                dx = min(max(dx, -m - o.left()), W + m - o.right())
                dy = min(max(dy, -m - o.top()), H + m - o.bottom())
                self.crop = o.translated(dx, dy)
            else:
                l, t, r, b = o.left(), o.top(), o.right(), o.bottom()
                if "l" in h:
                    l = d.x()
                if "r" in h:
                    r = d.x()
                if "t" in h:
                    t = d.y()
                if "b" in h:
                    b = d.y()
                self.crop = QRectF(QPointF(l, t), QPointF(r, b))
        elif k == "newtext":
            dr["cur"] = d
        elif k in ("move", "resize"):
            it = dr["item"]
            o = dr["orig"]
            dr["moved"] = True
            if k == "move":
                it.x = o.x() + d.x() - dr["start"].x()
                it.y = o.y() + d.y() - dr["start"].y()
            elif it.is_image:
                it.w = max(8.0, o.width() + d.x() - dr["start"].x())
                it.h = it.w / it.aspect
            else:
                it.w = max(4.0, o.width() + d.x() - dr["start"].x())
                it.h = max(4.0, o.height() + d.y() - dr["start"].y())
        self.update()

    def mouseReleaseEvent(self, e):
        w = self.win
        dr = self.drag
        self.drag = None
        if not dr or e.button() != Qt.LeftButton:
            return
        k = dr["k"]
        if k in ("newcrop", "crop"):
            if self.crop is not None:
                self.crop = self.crop.normalized()
                if self.crop.width() < 3 or self.crop.height() < 3:
                    self.crop = None
            w.update_actions()
        elif k == "newtext":
            a, b = dr["start"], dr["cur"]
            r = QRectF(a, b).normalized()
            if r.width() * self.z < 12 or r.height() * self.z < 12:
                size = w.default_font_size()
                W, H = w.page_size()
                rw = min(W * 0.3, W - a.x())
                r = QRectF(a.x(), a.y(), max(rw, 10), size * 1.6)
                r.setBottom(min(r.bottom(), H))
            it = TextItem(r.x(), r.y(), r.width(), r.height(), "", w.default_font_size())
            w.new_text(it)
        elif k in ("move", "resize"):
            if dr["moved"]:
                w.push_snap(dr["snap"])
        self.update()

    def mouseDoubleClickEvent(self, e):
        if self.mode != "text" or not self.win.has_doc():
            return
        pos = e.position()
        for it in reversed(self.win.cur_items()):
            if self.to_view(self.item_rect(it)).contains(pos):
                self.drag = None
                self.sel = it
                if not it.is_image:
                    self.win.edit_text(it)
                return

    def item_menu(self, it, gpos):
        m = QMenu(self)
        a1 = None if it.is_image else m.addAction("Bearbeiten …")
        a2 = m.addAction("Löschen")
        a3 = m.addAction("Auf alle anderen Seiten kopieren") if self.win.kind == "pdf" and self.win.page_count() > 1 else None
        ch = m.exec(gpos)
        if a1 is not None and ch is a1:
            self.win.edit_text(it)
        elif ch is a2:
            self.win.delete_item(it)
        elif ch is not None and ch is a3:
            self.win.copy_item_to_all(it)

    def keyPressEvent(self, e):
        if e.key() in (Qt.Key_Delete, Qt.Key_Backspace) and self.mode == "text" and self.sel:
            self.win.delete_item(self.sel)
        elif e.key() in (Qt.Key_Return, Qt.Key_Enter) and self.mode == "crop" and self.crop is not None:
            self.win.apply_crop(False)
        elif e.key() == Qt.Key_Escape:
            self.crop = None
            self.sel = None
            self.win.update_actions()
            self.update()
        else:
            super().keyPressEvent(e)


class ZuschnittWindow(QMainWindow):
    """Zuschnitt-Fenster. Mit main (Hauptfenster von Seifferts Text) läuft es als Tab; cfg und persist kommen dann von dort."""
    tab_prefix = "\u2702 "           # Marke im Tab-Text

    def __init__(self, main=None, cfg=None, persist=None):
        super().__init__()
        self.main = main
        self.embedded = main is not None
        if self.embedded:
            self.setWindowFlags(Qt.WindowType.Widget)
        self.cfg = dict(DEFAULT_CFG)
        if cfg:
            self.cfg.update(cfg)
        self._persist = persist
        self.kind = None            # "pdf" oder "img"
        self.path = None
        self.pdf = None
        self.img = None
        self.img_meta = {}
        self.page_no = 0
        self.items = {}             # Seite -> Liste von TextItem
        self.cropped = set()        # Seiten, die zugeschnitten wurden (nur diese kommen in die Ausgabe)
        self.undo = []
        self.modified = False
        self.zoom_fit = True
        self._base_cache = None
        if not self.embedded:
            self.resize(1100, 800)
            self.setAcceptDrops(True)        # als Tab nimmt das Hauptfenster Dateien an und wählt den passenden Tab
        self.canvas = Canvas(self)
        self.scroll = QScrollArea()
        self.scroll.setWidget(self.canvas)
        self.scroll.setAlignment(Qt.AlignCenter)
        self.setCentralWidget(self.scroll)
        self.build_actions()
        self.update_title()
        self.update_actions()

    # ---------- Aufbau
    def act(self, text, slot, key=None, checkable=False):
        a = QAction(text, self)
        a.triggered.connect(slot)
        if key:
            a.setShortcut(QKeySequence(key))
        a.setCheckable(checkable)
        return a

    def build_actions(self):
        self.a_open = self.act("In diesem Tab öffnen …" if self.embedded else "Öffnen …", self.cmd_open,
                               "Ctrl+Alt+O" if self.embedded else "Ctrl+O")
        self.a_save = self.act("Speichern", self.cmd_save, "Ctrl+S")
        self.a_saveas = self.act("Speichern unter …", self.cmd_save_as, "Ctrl+Shift+S")
        self.a_overwrite = self.act("Original überschreiben …", self.cmd_overwrite)
        self.a_split = self.act("PDF in Einzelseiten teilen …", self.cmd_split)
        self.a_merge = self.act("PDFs zusammenfügen …", self.cmd_merge)
        self.a_extend = self.act("Weiße Fläche ergänzen …", self.cmd_extend)
        self.a_graphic = self.act("PNG oder JPG einfügen …", self.cmd_graphic)
        self.a_clip = self.act("PDF-Ausschnitt einfügen …", self.cmd_clip)
        self.a_settings = self.act("Einstellungen …", self.cmd_settings)
        self.a_quit = self.act("Beenden", (lambda: self.main.close()) if self.embedded else self.close, "Ctrl+Q")
        self.a_undo = self.act("Rückgängig", self.cmd_undo, "Ctrl+Z")
        self.a_crop = self.act("Zuschneiden", lambda: self.set_mode("crop"), "F2", True)
        self.a_text = self.act("Text und Grafik", lambda: self.set_mode("text"), "F3", True)
        self.a_apply = self.act("Zuschnitt anwenden", lambda: self.apply_crop(False), "Ctrl+Return")
        self.a_apply_all = self.act("Zuschnitt auf alle Seiten", lambda: self.apply_crop(True))
        self.a_prev = self.act("◀ Seite", lambda: self.goto(self.page_no - 1), "PgUp")
        self.a_next = self.act("Seite ▶", lambda: self.goto(self.page_no + 1), "PgDown")
        self.a_zin = self.act("Vergrößern", lambda: self.set_zoom(self.canvas.z * 1.25), "Ctrl++")
        self.a_zout = self.act("Verkleinern", lambda: self.set_zoom(self.canvas.z / 1.25), "Ctrl+-")
        self.a_fit = self.act("Einpassen", self.fit, "Ctrl+0")
        self.a_full = fullscreen_action(self) if self.embedded else self.act("Vollbild", self.toggle_full, "F11")
        self.a_info = self.act("Über", self.cmd_about)
        m = self.menuBar()
        f = m.addMenu("Datei")
        if self.embedded:
            for text, slot, key in (("Neues Dokument", lambda: self.main.cmd_new(), "Ctrl+N"),
                                    ("Datei öffnen …", lambda: self.main.cmd_open(), "Ctrl+O"),
                                    ("Zuschnitt: weitere Datei in neuem Tab …", lambda: self.main.cmd_zuschnitt(), "Ctrl+Alt+Z"),
                                    ("Nächster Tab", lambda: self.main.next_tab(1), "Ctrl+PgDown"),
                                    ("Voriger Tab", lambda: self.main.next_tab(-1), "Ctrl+PgUp")):
                f.addAction(self.act(text, slot, key))
            f.addSeparator()
        for a in (self.a_open, self.a_save, self.a_saveas, self.a_overwrite, self.a_split, self.a_merge, None, self.a_settings, None):
            f.addAction(a) if a else f.addSeparator()
        if self.embedded:
            f.addAction(self.act("Schließen", self.close_me, "Ctrl+W"))
        f.addAction(self.a_quit)
        e = m.addMenu("Bearbeiten")
        for a in (self.a_undo, None, self.a_crop, self.a_text, None, self.a_apply, self.a_apply_all, None, self.a_extend, self.a_graphic, self.a_clip):
            e.addAction(a) if a else e.addSeparator()
        v = m.addMenu("Ansicht")
        for a in (self.a_prev, self.a_next, None, self.a_zin, self.a_zout, self.a_fit, None, self.a_full):
            v.addAction(a) if a else v.addSeparator()
        if self.embedded:
            v.addSeparator()
            v.addAction(self.act("Zwei Fenster: Referenzdatei rechts ein/aus", lambda: self.main.set_ref(not self.main.ref_pane.isVisible()), "F9"))
            v.addAction(self.act("Referenzdatei öffnen …", lambda: self.main.ref_open(), "Ctrl+Shift+R"))
        m.addMenu("Hilfe").addAction(self.a_info)
        tb = self.addToolBar("Werkzeuge")
        tb.setMovable(False)
        tb.setToolButtonStyle(Qt.ToolButtonTextOnly)
        self.a_save.setToolTip("Speichern: legt eine neue Datei an, das Original bleibt unverändert (Strg+S)")
        self.a_saveas.setToolTip("Speichern unter: neue Datei mit eigenem Namen (Strg+Umschalt+S)")
        self.a_overwrite.setToolTip("Überschreibt die geöffnete Originaldatei nach Rückfrage")
        self.a_split.setToolTip("Jede Seite als eigene PDF-Datei speichern")
        self.a_merge.setToolTip("Mehrere PDF-Dateien zu einer zusammenfügen")
        self.a_extend.setToolTip("An den Rändern weiße Fläche ergänzen (Platz für Text oder Grafiken)")
        self.a_graphic.setToolTip("Ein Bild (PNG, JPG) einfügen, verschiebbar und skalierbar")
        self.a_clip.setToolTip("Einen Ausschnitt aus einer anderen PDF einfügen, verschiebbar und skalierbar")
        for a in (self.a_open, self.a_save, self.a_saveas, self.a_overwrite, self.a_split, self.a_merge, None, self.a_crop, self.a_text, None, self.a_apply,
                  self.a_apply_all, None, self.a_extend, self.a_graphic, self.a_clip, None, self.a_undo):
            tb.addAction(a) if a else tb.addSeparator()
        self.addToolBarBreak()
        tb = self.addToolBar("Seite und Zoom")
        tb.setMovable(False)
        tb.setToolButtonStyle(Qt.ToolButtonTextOnly)
        tb.addAction(self.a_prev)
        self.spin = QSpinBox()
        self.spin.setMinimum(1)
        self.spin.setPrefix("Seite ")
        self.spin.valueChanged.connect(lambda v: self.goto(v - 1))
        tb.addWidget(self.spin)
        self.lbl_pages = QLabel(" ")
        tb.addWidget(self.lbl_pages)
        tb.addAction(self.a_next)
        tb.addSeparator()
        for a in (self.a_zout, self.a_zin, self.a_fit):
            tb.addAction(a)
        self.a_crop.setChecked(True)
        self.statusBar().showMessage("Bereit.")
        self.statusBar().addPermanentWidget(QLabel(f"Version {VERSION}  "))

    def update_actions(self):
        has = self.has_doc()
        pdf = self.kind == "pdf"
        self.a_split.setEnabled(self.has_doc() and self.kind == "pdf" and self.page_count() > 1)
        for a in (self.a_save, self.a_saveas, self.a_overwrite, self.a_extend, self.a_graphic, self.a_clip, self.a_crop, self.a_text, self.a_zin, self.a_zout, self.a_fit):
            a.setEnabled(has)
        self.a_apply.setEnabled(has and self.canvas.crop is not None)
        self.a_apply_all.setEnabled(pdf and self.page_count() > 1 and self.canvas.crop is not None)
        self.a_undo.setEnabled(bool(self.undo))
        n = self.page_count()
        self.a_prev.setEnabled(pdf and self.page_no > 0)
        self.a_next.setEnabled(pdf and self.page_no < n - 1)
        self.spin.setEnabled(pdf and n > 1)
        self.spin.blockSignals(True)
        self.spin.setMaximum(max(1, n))
        self.spin.setValue(self.page_no + 1)
        self.spin.blockSignals(False)
        self.lbl_pages.setText(f" von {n} " if pdf else " ")

    def update_title(self):
        name = os.path.basename(self.path) if self.path else "keine Datei"
        self.setWindowTitle(f"{'* ' if self.modified else ''}{name} – {APP_NAME} Zuschnitt – Version {VERSION}")
        if self.embedded and self.main is not None:
            self.main.pdf_title_changed(self)

    # ---------- Schnittstelle zum Tab im Hauptfenster
    def tab_path(self):
        return self.path

    def tab_modified(self):
        return bool(self.modified)

    def close_me(self):
        """Schließen: als Tab wird der Tab geschlossen, sonst das Fenster."""
        if self.embedded and self.main is not None:
            self.main.close_pdf_tab(self)
        else:
            self.close()

    def persist(self):
        """Einstellungen sichern: im Hauptfenster von Seifferts Text oder, ohne Hauptfenster, nirgends."""
        if self._persist is not None:
            self._persist(dict(self.cfg))

    def set_modified(self, v=True):
        self.modified = v
        self.update_title()

    # ---------- Modell
    def has_doc(self):
        return self.kind is not None

    def page_count(self):
        return self.pdf.page_count if self.kind == "pdf" else (1 if self.kind else 0)

    def page_size(self):
        if self.kind == "pdf":
            r = self.pdf[self.page_no].rect
            return r.width, r.height
        return float(self.img.width()), float(self.img.height())

    def cur_items(self):
        return self.items.setdefault(self.page_no if self.kind == "pdf" else 0, [])

    def default_font_size(self):
        W, H = self.page_size()
        return 14.0 if self.kind == "pdf" else max(12.0, round(H / 40))

    def base_image(self, z, dpr):
        key = (self.kind, self.page_no, round(z * dpr, 4), id(self.pdf), self.img.cacheKey() if self.img else 0)
        if self._base_cache and self._base_cache[0] == key:
            return self._base_cache[1]
        if self.kind == "pdf":
            pix = self.pdf[self.page_no].get_pixmap(matrix=pymupdf.Matrix(z * dpr, z * dpr), alpha=False)
            q = QImage(pix.samples, pix.width, pix.height, pix.stride, QImage.Format_RGB888).copy()
        else:
            tw, th = max(1, round(self.img.width() * z * dpr)), max(1, round(self.img.height() * z * dpr))
            q = self.img if (tw, th) == (self.img.width(), self.img.height()) else \
                self.img.scaled(tw, th, Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
            q = q.copy()
        q.setDevicePixelRatio(dpr)
        self._base_cache = (key, q)
        return q

    def snap(self, with_doc=False):
        s = {"items": copy_items(self.items), "page": self.page_no, "pdf": None, "img": None,
             "cropped": set(self.cropped)}
        if with_doc:
            if self.kind == "pdf":
                s["pdf"] = self.pdf.tobytes()
            else:
                s["img"] = self.img.copy()
        return s

    def push_snap(self, s):
        self.undo.append(s)
        del self.undo[:-25]
        self.set_modified(True)
        self.update_actions()

    def cmd_undo(self):
        if not self.undo:
            return
        s = self.undo.pop()
        self.items = s["items"]
        self.cropped = set(s.get("cropped", ()))
        if s["pdf"] is not None:
            self.pdf.close()
            self.pdf = pymupdf.open("pdf", s["pdf"])
        if s["img"] is not None:
            self.img = s["img"]
        self.page_no = min(s["page"], max(0, self.page_count() - 1))
        self.canvas.crop = None
        self.canvas.sel = None
        self._base_cache = None
        self.canvas.relayout()
        self.set_modified(True)
        self.update_actions()

    # ---------- Öffnen
    def cmd_open(self):
        if not self.maybe_discard():
            return
        start = self.cfg.get("open_dir") or (os.path.dirname(self.path) if self.path else os.path.expanduser("~"))
        path, _ = QFileDialog.getOpenFileName(self, "Datei öffnen", start, OPEN_FILTER)
        if path:
            self.open_path(path)

    def open_path(self, path):
        path = os.path.abspath(path)
        ext = os.path.splitext(path)[1].lower()
        try:
            if ext == ".pdf":
                doc = pymupdf.open(path)
                if not doc.is_pdf:
                    raise ValueError("keine PDF-Datei")
                if doc.needs_pass:
                    raise ValueError("die PDF ist passwortgeschützt")
                if doc.page_count < 1:
                    raise ValueError("die PDF hat keine Seiten")
                self.close_doc()
                self.pdf, self.kind = doc, "pdf"
            elif ext in IMG_EXT:
                rd = QImageReader(path)
                rd.setAutoTransform(True)
                img = rd.read()
                if img.isNull():
                    raise ValueError(rd.errorString())
                self.close_doc()
                self.img, self.kind = img, "img"
                self.img_meta = read_image_meta(path)
            else:
                raise ValueError("Dateityp nicht unterstützt (PDF, PNG, JPEG)")
        except Exception as ex:
            QMessageBox.warning(self, APP_NAME, f"Die Datei konnte nicht geöffnet werden:\n{path}\n\n{ex}")
            return
        self.path = path
        self.page_no = 0
        self.items = {}
        self.cropped = set()
        self.undo = []
        self.canvas.crop = None
        self.canvas.sel = None
        self._base_cache = None
        self.cfg["open_dir"] = os.path.dirname(path)
        self.persist()
        self.set_modified(False)
        self.zoom_fit = True
        self.fit()
        self.update_actions()
        if self.kind == "img":
            self.statusBar().showMessage(f"{self.img.width()} × {self.img.height()} Pixel – wird in voller Auflösung bearbeitet und gespeichert.")
        else:
            self.statusBar().showMessage(f"{self.pdf.page_count} Seite(n).")

    def close_doc(self):
        if self.pdf is not None:
            self.pdf.close()
        self.pdf = None
        self.img = None
        self.kind = None

    def maybe_discard(self):
        if not self.modified:
            return True
        r = QMessageBox.question(self, APP_NAME, "Es gibt ungespeicherte Änderungen. Trotzdem fortfahren?",
                                 QMessageBox.Yes | QMessageBox.Cancel, QMessageBox.Cancel)
        return r == QMessageBox.Yes

    def closeEvent(self, e):
        if self.maybe_discard():
            self.close_doc()
            e.accept()
        else:
            e.ignore()

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        for u in e.mimeData().urls():
            if u.isLocalFile():
                if self.maybe_discard():
                    self.open_path(u.toLocalFile())
                break

    # ---------- Ansicht
    def set_mode(self, m):
        self.canvas.mode = m
        self.a_crop.setChecked(m == "crop")
        self.a_text.setChecked(m == "text")
        self.canvas.sel = None
        self.canvas.update()

    def set_zoom(self, z, fit=False):
        if not self.has_doc():
            return
        W, H = self.page_size()
        z = max(0.02, min(z, 12000 / max(W, H)))
        self.zoom_fit = fit
        self.canvas.z = z
        self.canvas.relayout()

    def fit(self):
        if not self.has_doc():
            return
        W, H = self.page_size()
        vw = max(100, self.scroll.viewport().width() - 2 * 30 - 4)
        vh = max(100, self.scroll.viewport().height() - 2 * 30 - 4)
        self.set_zoom(min(vw / W, vh / H), True)
        self.center_scroll()

    def center_scroll(self):
        """Der breite graue Rand liegt außerhalb des Blickfelds; die Seite beginnt oben links im Fenster."""
        def go():
            self.scroll.horizontalScrollBar().setValue(M - 30)
            self.scroll.verticalScrollBar().setValue(M - 30)
        go()
        QTimer.singleShot(0, go)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        if self.zoom_fit and self.has_doc():
            self.fit()

    def toggle_full(self):
        self.showNormal() if self.isFullScreen() else self.showFullScreen()

    def goto(self, n):
        if self.kind != "pdf" or not (0 <= n < self.page_count()) or n == self.page_no:
            return
        self.page_no = n
        self.canvas.crop = None
        self.canvas.sel = None
        if self.zoom_fit:
            self.fit()
        else:
            self.canvas.relayout()
        self.update_actions()
        self.center_scroll()

    # ---------- Zuschneiden
    def apply_crop(self, all_pages):
        c = self.canvas.crop
        if not self.has_doc() or c is None:
            return
        c = c.normalized()
        s = self.snap(with_doc=True)
        # Ragt der Rahmen über den Seitenrand hinaus, wird dort zuerst weiße Fläche ergänzt
        W0, H0 = self.page_size()
        ol, ot = max(0.0, -c.left()), max(0.0, -c.top())
        orr, ob = max(0.0, c.right() - W0), max(0.0, c.bottom() - H0)
        if max(ol, ot, orr, ob) >= 0.5:
            if self.kind == "img":
                ol, ot, orr, ob = (float(math.ceil(v - 1e-6)) for v in (ol, ot, orr, ob))
            self.extend(ol, ot, orr, ob, all_pages, record=False)
            c = c.translated(ol, ot)
        if self.kind == "img":
            r = QRect(round(c.left()), round(c.top()), round(c.width()), round(c.height())).intersected(self.img.rect())
            if r.width() < 1 or r.height() < 1:
                return
            self.img = self.img.copy(r)
            for it in self.cur_items():
                it.x -= r.left()
                it.y -= r.top()
        else:
            pages = range(self.page_count()) if all_pages else [self.page_no]
            for pno in pages:
                page = self.pdf[pno]
                vr = pymupdf.Rect(c.left(), c.top(), c.right(), c.bottom()) & page.rect
                if vr.width < 2 or vr.height < 2:
                    continue
                ur = vr * page.derotation_matrix
                ur.normalize()
                pos = page.cropbox_position
                page.set_cropbox(pymupdf.Rect(ur.x0 + pos.x, ur.y0 + pos.y, ur.x1 + pos.x, ur.y1 + pos.y))
                self.cropped.add(pno)
                for it in self.items.get(pno, []):
                    it.x -= vr.x0
                    it.y -= vr.y0
        self.canvas.crop = None
        self._base_cache = None
        self.push_snap(s)
        self.canvas.relayout()
        if self.zoom_fit:
            self.fit()
        self.statusBar().showMessage("Zugeschnitten. Gespeichert wird erst mit Speichern.")

    # ---------- Weiße Fläche und Grafiken
    def mark_out(self, pno):
        """Seite gehört zur Ausgabe: nur wenn schon Seiten zugeschnitten wurden, sonst bleiben alle Seiten."""
        if self.cropped:
            self.cropped.add(pno)

    def cmd_extend(self):
        if not self.has_doc():
            return
        dlg = ExtendDialog(self, self.kind == "pdf", self.page_count(), self.page_size())
        if dlg.exec() != QDialog.Accepted:
            return
        self.extend(*dlg.values(), all_pages=dlg.all.isChecked())

    def extend(self, l, t, r, b, all_pages=False, record=True):
        """Ränder in Dokumentmaßen (pt bei PDF, Pixel bei Bildern). record=False: ohne eigenen Rückgängig-Schritt (beim Zuschnitt über den Rand)."""
        if not self.has_doc() or max(l, t, r, b) <= 0:
            return
        s = self.snap(with_doc=True) if record else None
        if self.kind == "img":
            l, t, r, b = (int(round(v)) for v in (l, t, r, b))
            old = self.img
            fmt = QImage.Format_ARGB32 if old.hasAlphaChannel() else QImage.Format_RGB32
            new = QImage(old.width() + l + r, old.height() + t + b, fmt)
            new.fill(QColor("white"))
            new.setDotsPerMeterX(old.dotsPerMeterX())
            new.setDotsPerMeterY(old.dotsPerMeterY())
            p = QPainter(new)
            p.setCompositionMode(QPainter.CompositionMode_Source)
            p.drawImage(l, t, old)
            p.end()
            self.img = new
            for it in self.cur_items():
                it.x += l
                it.y += t
        else:
            pages = range(self.page_count()) if all_pages else [self.page_no]
            for pno in pages:
                extend_pdf_page(self.pdf, pno, l, t, r, b)
                self.mark_out(pno)
                for it in self.items.get(pno, []):
                    it.x += l
                    it.y += t
        self._base_cache = None
        if not record:
            return
        self.canvas.crop = None
        self.push_snap(s)
        self.canvas.relayout()
        if self.zoom_fit:
            self.fit()
        self.statusBar().showMessage("Weiße Fläche ergänzt. Gespeichert wird erst mit Speichern.")

    def start_dir(self):
        return self.cfg.get("open_dir") or (os.path.dirname(self.path) if self.path else os.path.expanduser("~"))

    def cmd_graphic(self):
        """Bild (PNG, JPG und weitere Formate, die Qt lesen kann) einfügen."""
        if not self.has_doc():
            return
        path, _ = QFileDialog.getOpenFileName(self, "Bild wählen (PNG, JPG)", self.start_dir(),
                                              "Bilder (*.png *.PNG *.jpg *.JPG *.jpeg *.JPEG);;Alle Dateien (*)")
        if path:
            self.add_graphic(path)

    def cmd_clip(self):
        """Ausschnitt aus einer PDF einfügen."""
        if not self.has_doc():
            return
        path, _ = QFileDialog.getOpenFileName(self, "PDF wählen", self.start_dir(), "PDF (*.pdf *.PDF);;Alle Dateien (*)")
        if not path:
            return
        n, err = pdf_info(path)
        if err:
            QMessageBox.warning(self, APP_NAME, f"Diese PDF kann nicht verwendet werden: {err}")
            return
        dlg = ClipDialog(self, path)
        if dlg.exec() != QDialog.Accepted:
            return
        self.add_graphic(path, dlg.pno, dlg.result_clip)

    def add_graphic(self, path, pno=0, clip=None):
        """Fügt eine Grafik (PNG, JPG) oder einen PDF-Ausschnitt als Element auf der aktuellen Seite ein."""
        try:
            if path.lower().endswith(".pdf"):
                src, data, cl, aspect, note = pdf_source_item(path, pno, clip)
                nat_w = (cl[2] - cl[0]) if cl else None
                if note:
                    self.statusBar().showMessage(note)
            else:
                rd = QImageReader(path)
                rd.setAutoTransform(True)
                img = rd.read()
                if img.isNull():
                    raise ValueError("Bild kann nicht gelesen werden")
                if rd.transformation() != QImageIOHandler.TransformationNone:
                    ba = QByteArray()
                    buf = QBuffer(ba)
                    buf.open(QIODevice.WriteOnly)
                    img.save(buf, "PNG")
                    data = bytes(ba)
                else:
                    with open(path, "rb") as f:
                        data = f.read()
                src, cl, aspect, nat_w = "img", None, img.width() / img.height(), None
        except Exception as ex:  # noqa: BLE001
            QMessageBox.warning(self, APP_NAME, f"Einfügen nicht möglich:\n{ex}")
            return None
        W, H = self.page_size()
        w = min(nat_w, W * 0.9) if (nat_w and self.kind == "pdf" and src == "pdf") else W * 0.4
        h = w / aspect
        if h > H * 0.9:
            h = H * 0.9
            w = h * aspect
        it = ImageItem(max(0.0, (W - w) / 2), max(0.0, (H - h) / 2), w, h, "", 12.0,
                       src=src, data=data, clip=cl, aspect=aspect, label=os.path.basename(path))
        s = self.snap()
        self.cur_items().append(it)
        self.set_mode("text")
        self.canvas.sel = it
        self.push_snap(s)
        self.canvas.update()
        self.statusBar().showMessage("Grafik eingefügt: verschieben, an der Ecke unten rechts skalieren, Entf löscht.")
        return it

    # ---------- Text
    def new_text(self, it):
        s = self.snap()
        if self.edit_text(it, new=True, snap=s):
            pass

    def edit_text(self, it, new=False, snap=None):
        unit = "pt" if self.kind == "pdf" else "Pixel"
        before = snap or self.snap()
        dlg = TextDialog(self, it, unit, self.kind == "pdf", self.page_count())
        if dlg.exec() != QDialog.Accepted:
            self.canvas.update()
            return False
        if new and not dlg.edit.toPlainText().strip() and not dlg.bg.isChecked():
            self.canvas.update()
            return False
        everywhere = dlg.apply()
        if new:
            self.cur_items().append(it)
        self.canvas.sel = it
        if everywhere:
            self.copy_item_to_all(it, push=False)
        self.push_snap(before)
        self.canvas.update()
        return True

    def delete_item(self, it):
        s = self.snap()
        lst = self.cur_items()
        if it in lst:
            lst.remove(it)
            self.canvas.sel = None
            self.push_snap(s)
            self.canvas.update()

    def copy_item_to_all(self, it, push=True):
        s = self.snap()
        import copy as _copy
        for pno in range(self.page_count()):
            if pno == self.page_no:
                continue
            c = _copy.copy(it)
            self.items.setdefault(pno, []).append(c)
        if push:
            self.push_snap(s)
        self.canvas.update()

    # ---------- Speichern
    def has_changes_to_write(self):
        return True

    def kept_pages(self):
        """Seiten der Ausgabe: nur die zugeschnittenen; ohne Zuschnitt alle."""
        if self.kind != "pdf":
            return None
        return sorted(self.cropped) if self.cropped else None

    def free_path(self):
        """Neuer Dateiname neben dem Original oder im Standardordner; überschreibt nie etwas."""
        stem, ext = os.path.splitext(os.path.basename(self.path))
        stem = re.sub(r"-bearbeitet(-\d+)?$", "", stem)
        if self.kind == "pdf":
            ext = ".pdf"
        elif ext.lower() not in IMG_EXT:
            ext = ".png"
        folder = self.cfg.get("save_dir")
        if not folder or not os.path.isdir(folder):
            folder = os.path.dirname(self.path)
        cand = os.path.join(folder, f"{stem}-bearbeitet{ext}")
        n = 2
        while os.path.exists(cand):
            cand = os.path.join(folder, f"{stem}-bearbeitet-{n}{ext}")
            n += 1
        return cand

    def cmd_save(self):
        """Speichert immer in eine NEUE Datei; das Original bleibt unverändert."""
        if not self.has_doc() or not self.path:
            return
        self.write_to(self.free_path(), reload=False)

    def cmd_overwrite(self):
        if not self.has_doc() or not self.path:
            return
        text = f"Die Originaldatei wird überschrieben:\n{self.path}"
        kept = self.kept_pages()
        if kept is not None and len(kept) < self.page_count():
            text += f"\n\nSie enthält danach nur noch {len(kept)} von {self.page_count()} Seiten (die zugeschnittenen)."
        if self.cfg.get("backup"):
            text += "\n\nVorher wird eine Sicherung Dateiname.bak angelegt."
        else:
            text += "\n\nEine Sicherung wird NICHT angelegt (in den Einstellungen abgeschaltet)."
        if QMessageBox.question(self, APP_NAME, text, QMessageBox.Yes | QMessageBox.Cancel,
                                QMessageBox.Cancel) != QMessageBox.Yes:
            return
        self.write_to(self.path, reload=True)

    def cmd_merge(self):
        start = self.cfg.get("open_dir") or (os.path.dirname(self.path) if self.path else "") or os.path.expanduser("~")
        dlg = MergeDialog(self, self.cfg, start)
        if dlg.exec() != QDialog.Accepted or not dlg.result_path:
            return
        self.statusBar().showMessage(f"Zusammengefügt: {dlg.result_path} ({dlg.result_pages} Seiten)")
        if QMessageBox.question(self, APP_NAME, f"{dlg.result_pages} Seiten gespeichert:\n{dlg.result_path}\n\nJetzt öffnen?",
                                QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes) == QMessageBox.Yes:
            if self.maybe_discard():
                self.open_path(dlg.result_path)

    def cmd_split(self):
        """Jede Seite als eigene PDF-Datei (wie PDF Arranger). Nutzt Zuschnitt und Textrahmen der Sitzung."""
        if not self.has_doc() or self.kind != "pdf" or self.page_count() < 2:
            return
        folder = self.cfg.get("save_dir")
        if not folder or not os.path.isdir(folder):
            folder = os.path.dirname(self.path)
        folder = QFileDialog.getExistingDirectory(self, "Ordner für die Einzelseiten", folder)
        if not folder:
            return
        stem = re.sub(r"-bearbeitet(-\d+)?$", "", os.path.splitext(os.path.basename(self.path))[0])
        try:
            paths, notes = split_pdf(self.pdf, self.items, folder, stem)
        except Exception as e:
            QMessageBox.critical(self, APP_NAME, f"Teilen nicht möglich:\n{e}")
            return
        self.statusBar().showMessage(f"{len(paths)} Dateien gespeichert in {folder}")
        msg = f"{len(paths)} Einzelseiten gespeichert:\n{folder}\n\n{os.path.basename(paths[0])} bis {os.path.basename(paths[-1])}"
        if notes:
            msg += "\n\nHinweise:\n" + "\n".join(sorted(set(notes)))
        QMessageBox.information(self, APP_NAME, msg)

    def cmd_save_as(self):
        if not self.has_doc():
            return
        stem, ext = os.path.splitext(os.path.basename(self.path))
        sug = self.free_path()
        if self.kind == "pdf":
            flt = "PDF (*.pdf)"
        else:
            flt = "PNG (*.png);;JPEG (*.jpg *.jpeg)"
        path, selected = QFileDialog.getSaveFileName(self, "Speichern unter", sug, flt)
        if not path:
            return
        e = os.path.splitext(path)[1].lower()
        if self.kind == "pdf":
            if e != ".pdf":
                path += ".pdf"
        elif e not in IMG_EXT:
            path += ".jpg" if "JPEG" in selected else ".png"
        if os.path.abspath(path) == os.path.abspath(self.path):
            self.cmd_overwrite()
            return
        if os.path.exists(path):
            if QMessageBox.question(self, APP_NAME, f"{os.path.basename(path)} existiert schon. Überschreiben?",
                                    QMessageBox.Yes | QMessageBox.Cancel, QMessageBox.Cancel) != QMessageBox.Yes:
                return
        self.write_to(path, reload=False)

    def burn_image(self):
        img = self.img.convertToFormat(QImage.Format_ARGB32 if self.img.hasAlphaChannel() else QImage.Format_RGB32)
        p = QPainter(img)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.TextAntialiasing)
        for it in self.items.get(0, []):
            paint_item(p, it, 1.0, it.text, 1.0)
        p.end()
        return img

    def write_to(self, path, reload):
        backup = bool(self.cfg["backup"]) and reload
        try:
            if self.kind == "pdf":
                notes = save_pdf(self.pdf, self.items, path, backup, self.kept_pages())
            else:
                write_image(self.burn_image(), path, backup, self.img_meta)
                notes = []
        except Exception as ex:
            QMessageBox.critical(self, APP_NAME, f"Speichern nicht möglich:\n{ex}")
            return
        msg = f"Gespeichert: {path}"
        if notes:
            msg += "\n\nHinweise:\n" + "\n".join(sorted(set(notes)))
            QMessageBox.information(self, APP_NAME, msg)
        if reload:
            # Original überschrieben: neu laden, Textrahmen sind jetzt Teil der Datei
            self.modified = False
            self.open_path(path)
        else:
            # neue Datei: Sitzung bleibt offen, das Original ist unverändert
            self.set_modified(False)
        self.statusBar().showMessage(f"Gespeichert: {path}")

    # ---------- Sonstiges
    def cmd_settings(self):
        d = SettingsDialog(self, self.cfg)
        if d.exec() == QDialog.Accepted:
            self.cfg.update(d.values())
            self.persist()

    def cmd_about(self):
        QMessageBox.information(
            self, APP_NAME,
            f"{APP_NAME} {VERSION}: Zuschnitt\n\nPDF, PNG und JPEG zuschneiden und beschriften.\n"
            "F2 Zuschneiden, F3 Text einfügen, Strg+Eingabe Zuschnitt anwenden, Strg+S speichert in eine neue Datei "
            "(Name-bearbeitet), Strg+Umschalt+S Speichern unter, Datei, Original überschreiben nur nach Rückfrage.\n\n"
            "PDF: In die Ausgabe kommen nur die zugeschnittenen Seiten (ohne Zuschnitt alle Seiten). "
            "Der abgeschnittene Inhalt bleibt außerhalb des sichtbaren Bereichs in der Datei.\n"
            "Bilder: voller Pixelumfang, JPEG mit Qualität 100 ohne Farbunterabtastung, PNG verlustfrei.")
