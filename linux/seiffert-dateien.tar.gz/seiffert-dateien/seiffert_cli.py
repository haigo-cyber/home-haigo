#!/usr/bin/env python3
"""seiffert: ein gemeinsamer Befehl für alle Seiffert-Programme.

  seiffert                      Liste der installierten Seiffert-Programme mit Version
  seiffert start NAME [...]     Programm starten, zum Beispiel: seiffert start text  (NAME darf abgekürzt sein)
  seiffert NAME [...]           dasselbe, kürzer: seiffert funk
  seiffert install ARCHIV ...   ein oder mehrere Archive (seiffert-….tar.gz) auspacken und ihr install.sh ausführen
  seiffert install              sucht passende Archive im Ordner Downloads und zeigt sie
  seiffert design               zeigt das Farbdesign; mit --json für andere Programme
  seiffert design wald dunkel   stellt Farbdesign und Darstellung (hell, dunkel, auto) um
  seiffert pruefe               zeigt, welche Hilfsprogramme vorhanden sind und welche fehlen
  seiffert hilfe                diese Übersicht

Der Befehl braucht nur Python, keine weiteren Pakete."""
from __future__ import annotations

import glob
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
PREFIX = "seiffert-"
OWN = ("install", "design", "pruefe", "prüfe", "hilfe", "liste", "start", "help", "list", "version")
VERSION_RE = re.compile(r"""^\s*(?:__version__|VERSION|APP_VERSION)\s*=\s*["']([0-9][0-9A-Za-z.\-]{0,20})["']""", re.M)
HTML_VERSION_RE = re.compile(r"""(?:const|var|let)\s+(?:VERSION|APP_VERSION)\s*=\s*["']([0-9][0-9A-Za-z.\-]{0,20})["']""")
MAX_ARCHIVE_BYTES = 1_500_000_000
# Hilfsprogramme: (Programm, wofür, Paket unter Arch)
TOOLS = [
    ("tesseract", "Text vom Bildschirm lesen", "tesseract tesseract-data-deu tesseract-data-eng"),
    ("wmctrl", "neue Fenster auf eigene Arbeitsfläche legen (nur X11)", "wmctrl"),
    ("pdftotext", "Volltext und Vorschau für PDFs", "poppler"),
    ("soffice", "alte Office-Formate lesen, Vorschau in Seifferts Text", "libreoffice-fresh"),
    ("notify-send", "Meldung nach der Texterkennung", "libnotify"),
    ("xclip", "Zwischenablage ohne laufenden Starter (X11)", "xclip"),
    ("gsettings", "Tastenkürzel für den Starter setzen (Cinnamon, MATE)", "glib2"),
    ("pdflatex", "LaTeX übersetzen (Seifferts Text, Berichte)", "texlive-basic texlive-latex"),
    ("zuluCrypt-cli", "verschlüsselte Tresore öffnen", "zulucrypt (AUR)"),
]


def bin_dirs() -> list[str]:
    dirs = [os.path.expanduser("~/.local/bin")]
    for d in os.environ.get("PATH", "").split(os.pathsep):
        if d and d not in dirs:
            dirs.append(d)
    return dirs


def desktop_names() -> dict[str, str]:
    """Anzeigename je Startbefehl aus den Menüeinträgen (seiffert-….desktop)."""
    out: dict[str, str] = {}
    base = os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share")
    for f in sorted(glob.glob(os.path.join(base, "applications", PREFIX + "*.desktop"))):
        name = ""
        try:
            for line in open(f, encoding="utf-8", errors="replace"):
                if line.startswith("Name=") and not name:
                    name = line[5:].strip()
        except OSError:
            continue
        if name:
            out[os.path.basename(f)[:-len(".desktop")]] = name
    return out


def programs() -> list[dict]:
    """Alle Startbefehle seiffert-… (ohne diesen Befehl selbst), jeder nur einmal, der erste Fund im Suchpfad gilt."""
    names = desktop_names()
    found: dict[str, dict] = {}
    for d in bin_dirs():
        try:
            entries = sorted(os.listdir(d))
        except OSError:
            continue
        for e in entries:
            p = os.path.join(d, e)
            if e.startswith(PREFIX) and e not in found and os.path.isfile(p) and os.access(p, os.X_OK):
                found[e] = {"cmd": e, "short": e[len(PREFIX):], "path": p, "name": names.get(e, ""), "version": ""}
    out = sorted(found.values(), key=lambda x: x["cmd"])
    for p in out:
        p["version"] = version_of(p)
    return out


def _version_in_dir(d: str, depth: int = 2) -> str:
    """Sucht eine Versionsangabe in den Python-Dateien eines Programmordners (zuerst die üblichen Dateien)."""
    if not os.path.isdir(d):
        return ""
    first = ["__init__.py", "backend.py", "config.py", "app.py", "version.py", "common.py"]
    try:
        files = [f for f in os.listdir(d) if f.endswith(".py")]
    except OSError:
        return ""
    for f in [x for x in first if x in files] + sorted(x for x in files if x not in first):
        try:
            with open(os.path.join(d, f), encoding="utf-8", errors="replace") as fh:
                m = VERSION_RE.search(fh.read(200_000))
        except OSError:
            continue
        if m:
            return m.group(1)
    if depth > 0:
        try:
            subs = sorted(s for s in os.listdir(d) if os.path.isdir(os.path.join(d, s)) and s not in ("venv", "vendor", "icons", "tests", "__pycache__", "bin", "lib"))
        except OSError:
            subs = []
        for s in subs[:12]:
            v = _version_in_dir(os.path.join(d, s), depth - 1)
            if v:
                return v
    return ""


def version_of(prog: dict) -> str:
    """Version eines Programms: aus dem Ordner, auf den sein Startbefehl zeigt, sonst aus ~/.local/share/<name>. Leer = nicht feststellbar."""
    dirs: list[str] = []
    try:
        with open(prog["path"], encoding="utf-8", errors="replace") as f:
            text = f.read(20_000)
    except OSError:
        text = ""
    for m in re.finditer(r"""(/[^\s"'$]+?)/[^/\s"'$]+\.py\b""", text):
        if m.group(1) not in dirs:
            dirs.append(m.group(1))
    for m in re.finditer(r"""(/[^\s"'$]*/\.local/share/[^/\s"'$]+)""", text):
        if m.group(1) not in dirs:
            dirs.append(m.group(1))
    base = os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share")
    for cand in (prog["cmd"], prog["cmd"] + "-app"):
        p = os.path.join(base, cand)
        if p not in dirs:
            dirs.append(p)
    for d in dirs:
        v = _version_in_dir(d)
        if v:
            return v
    return ""


def find_program(name: str, progs: list[dict]) -> tuple[dict | None, str]:
    """Programm zu einem (auch abgekürzten) Namen. Rückgabe: (Programm, Fehlermeldung)."""
    n = name.lower()
    n = n[len(PREFIX):] if n.startswith(PREFIX) else n
    exact = [p for p in progs if p["short"] == n]
    if exact:
        return exact[0], ""
    hits = [p for p in progs if p["short"].startswith(n)] or [p for p in progs if n in p["short"] or n in p["name"].lower()]
    if len(hits) == 1:
        return hits[0], ""
    if not hits:
        return None, "Kein Seiffert-Programm passt zu \"%s\". Vorhanden: %s" % (name, ", ".join(p["short"] for p in progs) or "keins")
    return None, "\"%s\" ist nicht eindeutig: %s" % (name, ", ".join(p["short"] for p in hits))


# ---------------------------------------------------------------------------------------------- Befehle
def cmd_list(_args: list[str]) -> int:
    progs = programs()
    if not progs:
        print("Keine Seiffert-Programme gefunden (gesucht wird nach seiffert-… in ~/.local/bin und im Suchpfad).")
        return 0
    w = max(len(p["short"]) for p in progs)
    print("Installierte Seiffert-Programme:")
    for p in progs:
        print("  %-*s  %-8s %s" % (w, p["short"], p["version"] or "?", p["name"]))
    print("\nStarten:  seiffert NAME      Hilfe:  seiffert hilfe      (? = Version nicht feststellbar)")
    return 0


def cmd_start(args: list[str]) -> int:
    if not args:
        print("Welches Programm? Beispiel: seiffert start text", file=sys.stderr)
        return 2
    prog, err = find_program(args[0], programs())
    if not prog:
        print(err, file=sys.stderr)
        return 2
    os.execv(prog["path"], [prog["path"]] + args[1:])
    return 0  # pragma: no cover


def _safe_members(tar: tarfile.TarFile) -> list[tarfile.TarInfo]:
    """Nur gewöhnliche Dateien und Ordner mit Pfaden innerhalb des Archivs; alles andere führt zur Ablehnung."""
    members, total = [], 0
    for m in tar.getmembers():
        name = m.name
        if name.startswith("/") or ".." in name.replace("\\", "/").split("/"):
            raise ValueError("Das Archiv enthält einen Pfad außerhalb seines Ordners: %s" % name)
        if not (m.isfile() or m.isdir()):
            raise ValueError("Das Archiv enthält etwas anderes als Dateien und Ordner (Verweis oder Gerät): %s" % name)
        total += m.size
        if total > MAX_ARCHIVE_BYTES:
            raise ValueError("Das Archiv ist ausgepackt größer als 1,5 GB.")
        members.append(m)
    return members


def install_archive(path: str) -> int:
    path = os.path.abspath(os.path.expanduser(path))
    if not os.path.isfile(path):
        print("Die Datei gibt es nicht: %s" % path, file=sys.stderr)
        return 1
    tmp = tempfile.mkdtemp(prefix="seiffert-install-")
    try:
        try:
            with tarfile.open(path) as tar:
                members = _safe_members(tar)
                try:
                    tar.extractall(tmp, members=members, filter="data")
                except TypeError:                                       # ältere Python-Fassung ohne Filter
                    tar.extractall(tmp, members=members)
        except (tarfile.TarError, OSError, ValueError) as e:
            print("Das Archiv ließ sich nicht auspacken: %s" % e, file=sys.stderr)
            return 1
        scripts = [os.path.join(tmp, "install.sh")] + sorted(glob.glob(os.path.join(tmp, "*", "install.sh")))
        script = next((s for s in scripts if os.path.isfile(s)), None)
        if not script:
            print("Im Archiv ist kein install.sh (weder oben noch im ersten Ordner): %s" % os.path.basename(path), file=sys.stderr)
            return 1
        print("== %s: install.sh wird ausgeführt" % os.path.basename(path))
        sys.stdout.flush()
        r = subprocess.run(["sh", "./install.sh"], cwd=os.path.dirname(script))
        if r.returncode != 0:
            print("install.sh endete mit Fehler %d." % r.returncode, file=sys.stderr)
        return r.returncode
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def downloads_dir() -> str:
    try:
        r = subprocess.run(["xdg-user-dir", "DOWNLOAD"], capture_output=True, text=True, timeout=3)
        d = r.stdout.strip()
        if r.returncode == 0 and d and os.path.isdir(d):
            return d
    except (OSError, subprocess.SubprocessError):
        pass
    return os.path.expanduser("~/Downloads")


def cmd_install(args: list[str]) -> int:
    if not args:
        d = downloads_dir()
        found = sorted(glob.glob(os.path.join(d, PREFIX + "*.tar.gz")) + glob.glob(os.path.join(d, PREFIX + "*.tgz")), key=os.path.getmtime, reverse=True)
        if not found:
            print("In %s liegt kein Archiv seiffert-….tar.gz. Aufruf: seiffert install PFAD/ZUM/ARCHIV.tar.gz" % d)
            return 0
        print("Archive in %s (neueste zuerst):" % d)
        for f in found[:30]:
            print("  %s  %s" % (time.strftime("%d.%m.%Y %H:%M", time.localtime(os.path.getmtime(f))), os.path.basename(f)))
        print("\nInstallieren mit:  seiffert install \"%s\"" % found[0])
        return 0
    worst = 0
    for a in args:
        worst = max(worst, install_archive(a))
    return worst


def cmd_design(args: list[str]) -> int:
    import skins
    as_json = "--json" in args
    as_css = "--css" in args
    words = [a.lower() for a in args if not a.startswith("--")]
    skin = theme = None
    tmap = {"hell": "light", "light": "light", "dunkel": "dark", "dark": "dark", "auto": "auto", "automatisch": "auto"}
    for w in words:
        if w in skins.SKINS:
            skin = w
        elif w in tmap:
            theme = tmap[w]
        else:
            print("Unbekannt: %s. Farbdesigns: %s. Darstellung: hell, dunkel, auto." % (w, ", ".join(skins.SKINS)), file=sys.stderr)
            return 2
    if skin or theme:
        import starterextra as SX
        try:
            via = SX.set_design(skin=skin, theme=theme)
        except ValueError as e:
            print(str(e), file=sys.stderr)
            return 1
        if not (as_json or as_css):
            print("Umgestellt (%s)." % ("Seifferts Dateien hat es sofort übernommen" if via == "dateien" else "gilt ab dem nächsten Start von Seifferts Dateien"))
    cur = skins.current()
    if as_json:
        print(json.dumps(cur, ensure_ascii=False, indent=1))
    elif as_css:
        print(":root{%s}" % skins.css_vars(cur["colors"]))
    else:
        print("Farbdesign: %s, Darstellung: %s%s" % (cur["label"], skins.THEME_LABELS[cur["theme"]],
                                                     " (zurzeit %s)" % ("dunkel" if cur["dark"] else "hell") if cur["theme"] == "auto" else ""))
        print("Akzentfarbe %s, Hintergrund %s" % (cur["colors"]["accent"], cur["colors"]["bg"]))
    return 0


def cmd_check(_args: list[str]) -> int:
    print("Python %s (%s)" % (sys.version.split()[0], sys.executable))
    progs = programs()
    print("Seiffert-Programme: %s" % (", ".join(p["short"] for p in progs) or "keine gefunden"))
    sess = os.environ.get("XDG_SESSION_TYPE", "") or ("wayland" if os.environ.get("WAYLAND_DISPLAY") else "x11" if os.environ.get("DISPLAY") else "unbekannt")
    print("Sitzung: %s, Desktop: %s" % (sess, os.environ.get("XDG_CURRENT_DESKTOP", "unbekannt")))
    if sess == "wayland":
        print("  Hinweis: Unter Wayland gehen das Bildschirmfoto für die Texterkennung und die eigene Arbeitsfläche für neue Fenster nicht;")
        print("  ob der Verlauf der Zwischenablage dort vollständig ist, ist nicht geprüft.")
    print("Hilfsprogramme:")
    missing = 0
    for exe, what, pkg in TOOLS:
        ok = bool(shutil.which(exe))
        missing += 0 if ok else 1
        print("  %-7s %-14s %s%s" % ("da" if ok else "FEHLT", exe, what, "" if ok else "   -> Paket: " + pkg))
    if shutil.which("tesseract"):
        try:
            r = subprocess.run(["tesseract", "--list-langs"], capture_output=True, text=True, timeout=10)
            langs = [ln.strip() for ln in (r.stdout + "\n" + r.stderr).splitlines()[1:] if ln.strip()]
            print("  tesseract-Sprachen: %s%s" % (", ".join(langs[:12]) or "keine", "" if "deu" in langs else "   -> Deutsch fehlt: tesseract-data-deu"))
        except (OSError, subprocess.SubprocessError):
            pass
    print("\n%s" % ("Alles vorhanden." if not missing else "%d Hilfsprogramme fehlen. Sie sind alle freiwillig; die Zeile nennt, wofür sie gebraucht werden." % missing))
    return 0


def main(argv: list[str]) -> int:
    args = argv[1:]
    if not args or args[0] in ("liste", "list"):
        return cmd_list(args[1:])
    cmd, rest = args[0].lower(), args[1:]
    if cmd in ("hilfe", "help", "-h", "--help"):
        print(__doc__)
        return 0
    if cmd == "start":
        return cmd_start(rest)
    if cmd == "install":
        return cmd_install(rest)
    if cmd == "design":
        return cmd_design(rest)
    if cmd in ("pruefe", "prüfe"):
        return cmd_check(rest)
    if cmd in ("version", "--version"):
        return cmd_list(rest)
    return cmd_start(args)                                           # seiffert text = seiffert start text


if __name__ == "__main__":
    try:
        code = main(sys.argv)
        sys.stdout.flush()
    except BrokenPipeError:                                          # Ausgabe wurde abgeschnitten (zum Beispiel mit | head)
        os.dup2(os.open(os.devnull, os.O_WRONLY), sys.stdout.fileno())
        code = 0
    sys.exit(code)
