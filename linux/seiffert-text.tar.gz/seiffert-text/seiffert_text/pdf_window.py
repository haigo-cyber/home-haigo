"""PDF-Fenster: ansehen, Text ändern und hinzufügen, Seiten verwalten (pdf_tools.py)."""
import os

from PySide6.QtCore import Qt, Signal, QRectF
from PySide6.QtGui import QAction, QActionGroup, QFont, QFontMetricsF, QImage, QKeySequence, QPixmap
from PySide6.QtWidgets import (QCheckBox, QComboBox, QRadioButton, QApplication, QDialog, QDialogButtonBox, QFileDialog, QFormLayout, QInputDialog,
                               QLabel, QLineEdit, QListWidget, QMainWindow, QMessageBox, QPlainTextEdit, QTextEdit,
                               QScrollArea, QSpinBox, QSplitter)

from . import APP_NAME, VERSION
from .pdf_tools import PdfEditor, PdfError

MODE_VIEW, MODE_EDIT, MODE_ADD = 0, 1, 2


class PageLabel(QLabel):
    clicked = Signal(float, float)

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(e.position().x(), e.position().y())


class _MultiLine(QTextEdit):
    """Mehrzeiliges Formularfeld. Hat es den Fokus und passt der Text nicht in lesbarer Größe hinein,
    wächst es nach unten, bis der ganze Text zu sehen ist; beim Verlassen schrumpft es wieder."""
    done = Signal()

    def __init__(self, parent, win, f):
        super().__init__(parent)
        self.win, self.f = win, f
        self.base = None
        self.expanded = False
        self.setAcceptRichText(False)
        self.setFrameShape(QTextEdit.Shape.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setLineWrapMode(QTextEdit.LineWrapMode.WidgetWidth)
        self.document().setDocumentMargin(2)

    def focusInEvent(self, e):
        super().focusInEvent(e)
        self.win.expand_field(self)

    def focusOutEvent(self, e):
        super().focusOutEvent(e)
        self.win.collapse_field(self)
        self.done.emit()


FIELD_CSS = ("background-color: #dbe7ff; color: #000000; border: 1px solid %s; "
             "padding: 0px 1px; margin: 0px; font-size: %dpx;")
BORDER_OK, BORDER_CLIP = "#5b8dd9", "#e07b00"


def field_font(name):
    """Bildschirmschrift passend zur Schrift des Formularfelds (Helvetica, Times, Courier)."""
    n = (name or "").lower()
    f = QFont()
    if n.startswith(("cour", "co")):
        f.setFamilies(["Liberation Mono", "DejaVu Sans Mono", "Courier New", "monospace"])
    elif n.startswith(("ti", "times")):
        f.setFamilies(["Liberation Serif", "Tinos", "Times New Roman", "DejaVu Serif", "serif"])
    else:
        f.setFamilies(["Liberation Sans", "Arimo", "Arial", "Helvetica", "DejaVu Sans", "sans-serif"])
    return f


class PdfWindow(QMainWindow):
    def __init__(self, path, main=None, embedded=False):
        super().__init__()
        self.main = main
        self.embedded = embedded        # als Tab im Hauptfenster statt als eigenes Fenster
        if embedded:
            self.setWindowFlags(Qt.WindowType.Widget)
        self.ed = PdfEditor(path)
        self.pno = 0
        self.zoom = 1.4
        self.mode = MODE_VIEW
        if not embedded:
            self.resize(1150, 800)
        if main is not None:
            self.setWindowIcon(main.windowIcon())
        self._build()
        self.statusBar().addPermanentWidget(QLabel("Version %s " % VERSION))
        self.fill_list()
        self.show_page()
        n = self.ed.field_count()
        if n:
            self.statusBar().showMessage("%d Formularfeld(er) erkannt: Die blau hinterlegten Felder lassen sich direkt "
                                         "ausfüllen (Tab springt zum nächsten Feld)." % n)
        else:
            self.statusBar().showMessage("Text bearbeiten: Werkzeug wählen und auf eine Zeile klicken. "
                                         "Der Text wird an derselben Stelle neu gesetzt; es wird nicht neu umbrochen.")

    def _build(self):
        split = QSplitter()
        self.list = QListWidget()
        self.list.setMaximumWidth(140)
        self.list.currentRowChanged.connect(self.goto)
        self.page = PageLabel()
        self.page.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        self.page.clicked.connect(self.on_click)
        self.scroll = QScrollArea()
        self.scroll.setWidget(self.page)
        self.scroll.setWidgetResizable(False)
        self.scroll.setAlignment(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop)
        split.addWidget(self.list)
        split.addWidget(self.scroll)
        split.setStretchFactor(1, 1)
        self.setCentralWidget(split)

        def A(text, slot, key=None, check=False):
            a = QAction(text, self)
            a.triggered.connect(slot)
            if key:
                a.setShortcut(QKeySequence(key))
            a.setCheckable(check)
            return a
        self.a_save = A("Speichern", self.save, "Ctrl+S")
        self.a_saveas = A("Speichern unter …", self.save_as, "Ctrl+Shift+S")
        self.a_tex = A("Text als LaTeX-Quelltext im Textfenster öffnen", self.to_latex)
        self.a_src = A("PDF-Quelltext bearbeiten", self.to_source, "Ctrl+U")
        self.a_undo = A("Rückgängig", self.undo, "Ctrl+Z")
        self.a_view = A("Ansehen", lambda: self.set_mode(MODE_VIEW), "Esc", True)
        self.a_edit = A("Text bearbeiten", lambda: self.set_mode(MODE_EDIT), "Ctrl+E", True)
        self.a_add = A("Text hinzufügen", lambda: self.set_mode(MODE_ADD), "Ctrl+T", True)
        grp = QActionGroup(self)
        for a in (self.a_view, self.a_edit, self.a_add):
            grp.addAction(a)
        self.a_view.setChecked(True)
        self.a_replace = A("Suchen und ersetzen …", self.replace, "Ctrl+H")
        self.a_fields = A("Formularfelder zum Ausfüllen anzeigen", lambda: self.show_page(), "F8", True)
        self.a_fields.setChecked(True)
        self.a_del = A("Seite löschen", self.del_page)
        self.a_rot = A("Seite drehen", self.rot_page, "Ctrl+R")
        self.a_up = A("Seite nach vorn", lambda: self.move(-1), "Ctrl+Up")
        self.a_down = A("Seite nach hinten", lambda: self.move(1), "Ctrl+Down")
        self.a_append = A("PDF anhängen …", self.append)
        self.a_zin = A("Vergrößern", lambda: self.set_zoom(self.zoom * 1.2), "Ctrl++")
        self.a_zout = A("Verkleinern", lambda: self.set_zoom(self.zoom / 1.2), "Ctrl+-")
        self.a_prev = A("Vorige Seite", lambda: self.list.setCurrentRow(max(0, self.pno - 1)), "PgUp")
        self.a_next = A("Nächste Seite", lambda: self.list.setCurrentRow(min(self.ed.count() - 1, self.pno + 1)), "PgDown")
        mb = self.menuBar()
        m = mb.addMenu("&Datei")
        for a in (self.a_save, self.a_saveas, None, self.a_src, self.a_tex, None):
            m.addSeparator() if a is None else m.addAction(a)
        if self.embedded:
            m.addSeparator()
            for text, slot, key in (("Neues Dokument", lambda: self.main.cmd_new(), "Ctrl+N"),
                                    ("Datei öffnen …", lambda: self.main.cmd_open(), "Ctrl+O"),
                                    ("Nächster Tab", lambda: self.main.next_tab(1), "Ctrl+PgDown"),
                                    ("Voriger Tab", lambda: self.main.next_tab(-1), "Ctrl+PgUp")):
                m.addAction(A(text, slot, key))
            m.addSeparator()
        m.addAction(A("Schließen", self.close_me, "Ctrl+W"))
        if self.embedded:
            m.addAction(A("Beenden", lambda: self.main.close(), "Ctrl+Q"))
        m = mb.addMenu("&Bearbeiten")
        for a in (self.a_undo, None, self.a_view, self.a_edit, self.a_add, None, self.a_replace):
            m.addSeparator() if a is None else m.addAction(a)
        m = mb.addMenu("&Seiten")
        for a in (self.a_prev, self.a_next, None, self.a_up, self.a_down, self.a_rot, self.a_del, None, self.a_append):
            m.addSeparator() if a is None else m.addAction(a)
        m = mb.addMenu("&Ansicht")
        m.addAction(self.a_zin)
        m.addAction(self.a_zout)
        m.addSeparator()
        m.addAction(self.a_fields)
        m = mb.addMenu("&Hilfe")
        m.addAction(A("Hinweise zur PDF-Bearbeitung", self.help))
        tb = self.addToolBar("PDF")
        tb.setMovable(False)
        for a in (self.a_save, self.a_undo, None, self.a_view, self.a_edit, self.a_add, self.a_replace, None,
                  self.a_up, self.a_down, self.a_rot, self.a_del, None, self.a_zout, self.a_zin):
            tb.addSeparator() if a is None else tb.addAction(a)
        tb.addSeparator()
        tb.addWidget(QLabel(" Schriftgröße für neuen Text: "))
        self.size = QSpinBox()
        self.size.setRange(5, 72)
        self.size.setValue(11)
        tb.addWidget(self.size)

    # ---- Anzeige
    def update_title(self):
        self.setWindowTitle("%s%s – %s %s PDF" % ("* " if self.ed.modified else "",
                                                  os.path.basename(self.ed.path), APP_NAME, VERSION))
        if self.embedded and self.main is not None:
            self.main.pdf_title_changed(self)

    def close_me(self):
        """Schließen: als Tab wird der Tab geschlossen, sonst das Fenster."""
        if self.embedded and self.main is not None:
            self.main.close_pdf_tab(self)
        else:
            self.close()

    def fill_list(self):
        self.list.blockSignals(True)
        self.list.clear()
        for n in range(self.ed.count()):
            self.list.addItem("Seite %d" % (n + 1))
        self.pno = max(0, min(self.pno, self.ed.count() - 1))
        self.list.setCurrentRow(self.pno)
        self.list.blockSignals(False)

    def goto(self, row):
        self.commit_fields()
        if 0 <= row < self.ed.count():
            self.pno = row
            self.show_page()
            self.scroll.verticalScrollBar().setValue(0)

    def show_page(self):
        samples, w, h, stride = self.ed.render(self.pno, self.zoom)
        img = QImage(samples, w, h, stride, QImage.Format.Format_RGB888).copy()
        self.page.setPixmap(QPixmap.fromImage(img))
        self.page.resize(w, h)
        self.build_fields()
        self.update_title()

    # ---- Formularfelder als Eingabefelder über der Seite
    def build_fields(self):
        for w in getattr(self, "field_widgets", []):
            w.setParent(None)
            w.deleteLater()
        self.field_widgets = []
        self.field_commits = []
        if not self.a_fields.isChecked():
            return
        try:
            fields = self.ed.fields(self.pno)
        except Exception:
            return
        z = self.zoom
        for f in fields:
            x0, y0, x1, y1 = f["rect"]
            gx, gy, gw, gh = int(x0 * z), int(y0 * z), max(8, int((x1 - x0) * z)), max(8, int((y1 - y0) * z))
            css = FIELD_CSS % (BORDER_OK, 10)
            kind, xref = f["kind"], f["xref"]
            if kind == "text" and f["multiline"]:
                w = _MultiLine(self.page, self, f)
                w.setPlainText(str(f["value"] or "").replace("\r\n", "\n").replace("\r", "\n"))
                f["value"] = w.toPlainText()
                w.textChanged.connect(lambda w=w, f=f: self.fit_field(w, f))
                w.done.connect(lambda w=w, xref=xref: self.field_changed(xref, w.toPlainText(), w))
                self.field_commits.append(lambda w=w, xref=xref: self.field_changed(xref, w.toPlainText(), w))
                w.setReadOnly(f["readonly"])
            elif kind == "text":
                w = QLineEdit(self.page)
                w.setText(str(f["value"] or ""))
                w.setTextMargins(0, 0, 0, 0)
                w.setAlignment({1: Qt.AlignmentFlag.AlignHCenter, 2: Qt.AlignmentFlag.AlignRight}
                               .get(f["align"], Qt.AlignmentFlag.AlignLeft) | Qt.AlignmentFlag.AlignVCenter)
                w.textChanged.connect(lambda _=None, w=w, f=f: self.fit_field(w, f))
                if f["maxlen"]:
                    w.setMaxLength(f["maxlen"])
                if f["password"]:
                    w.setEchoMode(QLineEdit.EchoMode.Password)
                w.editingFinished.connect(lambda w=w, xref=xref: self.field_changed(xref, w.text(), w))
                self.field_commits.append(lambda w=w, xref=xref: self.field_changed(xref, w.text(), w))
                w.setReadOnly(f["readonly"])
            elif kind in ("combo", "list"):
                w = QComboBox(self.page)
                items = [c if isinstance(c, str) else str(c[-1]) for c in f["choices"]]
                if kind == "list" or "" not in items:
                    w.addItem("")
                w.addItems(items)
                w.setEditable(f["editable"])
                cur = str(f["value"] or "")
                if w.findText(cur) < 0:
                    w.addItem(cur)
                w.setCurrentIndex(w.findText(cur))
                w.activated.connect(lambda _=0, w=w, xref=xref: self.field_changed(xref, w.currentText(), w))
                if f["editable"]:
                    w.lineEdit().editingFinished.connect(
                        lambda w=w, xref=xref: self.field_changed(xref, w.currentText(), w))
                w.setEnabled(not f["readonly"])
            else:
                w = QRadioButton(self.page) if kind == "radio" else QCheckBox(self.page)
                w.setAutoExclusive(False)
                w.setChecked(bool(f["value"]))
                w.clicked.connect(lambda on, xref=xref: self.button_changed(xref, on))
                w.setEnabled(not f["readonly"])
                css = "background-color: #dbe7ff;"
            w.setProperty("pdf_value", f["value"] if kind in ("check", "radio") else str(f["value"] or ""))
            w.setStyleSheet(css)
            w.setToolTip(f["name"])
            w.setGeometry(gx, gy, gw, gh)
            if kind == "text":
                w.show()
                if isinstance(w, _MultiLine):
                    w.base = w.geometry()
                self.fit_field(w, f)
                if isinstance(w, QLineEdit):
                    w.setCursorPosition(0)          # Anfang des Texts zeigen, nicht das Ende
            elif kind in ("combo", "list"):
                fnt = field_font(f["font"])
                fnt.setPixelSize(max(6, int(min(f["fontsize"] * z if f["fontsize"] else 99, (gh - 2) * 0.72))))
                w.setFont(fnt)
            w.show()
            self.field_widgets.append(w)

    def _nominal(self, w, f):
        z = self.zoom
        if f["fontsize"] > 0:
            return f["fontsize"] * z
        if isinstance(w, _MultiLine):
            return 12.0 * z
        return max(5.0, min(12.0 * z, (w.height() - 3) * 0.74))

    def _apply_font(self, w, f, px, border):
        px = max(1, int(px))
        fnt = field_font(f["font"])
        fnt.setPixelSize(px)
        fam = ", ".join('"%s"' % x for x in fnt.families())
        w.setStyleSheet((FIELD_CSS % (border, px)) + " font-family: %s;" % fam)
        w.setFont(fnt)
        if isinstance(w, _MultiLine):
            w.document().setDefaultFont(fnt)
        return fnt

    def _doc_height(self, w, fnt, width):
        """Höhe, die der Text des mehrzeiligen Felds bei dieser Schrift und Breite wirklich braucht."""
        doc = w.document().clone()
        doc.setDocumentMargin(2)
        doc.setDefaultFont(fnt)
        doc.setTextWidth(max(20, width))
        h = doc.size().height()
        doc.deleteLater()
        return h

    def fit_field(self, w, f):
        """Schrift so wählen, dass der ganze Feldtext sichtbar ist.

        Felder mit automatischer Schriftgröße verkleinert auch das PDF selbst. Bei fester Schriftgröße
        schneidet das PDF den Text ab; das Eingabefeld zeigt ihn trotzdem ganz (verkleinert) und bekommt
        einen orangen Rand als Hinweis. Mehrzeilige Felder wachsen zusätzlich, solange man darin schreibt.
        """
        z = self.zoom
        multi = isinstance(w, _MultiLine)
        if multi and w.expanded:
            self.expand_field(w)
            return
        text = w.toPlainText() if multi else w.text()
        gw, gh = w.width(), w.height()
        fixed = f["fontsize"] > 0
        nominal = self._nominal(w, f)
        fnt = field_font(f["font"])
        floor = max(5.0, 4.0 * z)
        # Rand, den Rahmen und Stil des Systems wirklich verbrauchen
        if multi:
            vp = w.viewport()
            sane = gh - 30 <= vp.height() <= gh and gw - 60 <= vp.width() <= gw
            vh = vp.height() if sane else gh - 4
            vw = vp.width() if sane else gw - 4
            if sane and w.verticalScrollBar().isVisible():
                vw += w.verticalScrollBar().width()

        def fits(px):
            fnt.setPixelSize(max(1, int(px)))
            if multi:
                return self._doc_height(w, fnt, vw) <= vh
            fm = QFontMetricsF(fnt)
            return fm.horizontalAdvance(text) <= gw - 8 and fm.height() <= gh + 2
        px = nominal
        while px > floor and not fits(px):
            px -= max(0.5, px * 0.04)
        ok = fits(px)
        clipped = fixed and (px < nominal - 0.4 or not ok)
        w.blockSignals(True)
        self._apply_font(w, f, px, BORDER_CLIP if (clipped or not ok) else BORDER_OK)
        w.blockSignals(False)
        tip = f["name"]
        if clipped:
            tip += ("\nDer Text ist länger als das Feld. Hier wird er verkleinert ganz angezeigt; im PDF selbst "
                    "ist für dieses Feld eine feste Schriftgröße von %g pt vorgegeben, dort ist nur der Anfang "
                    "sichtbar." % f["fontsize"])
        elif not ok:
            tip += "\nDer Text passt auch verkleinert nicht ganz ins Feld. Beim Hineinklicken wird das Feld größer."
        if len(text) > 30:
            tip += "\n\n" + text
        w.setToolTip(tip)
        if multi:
            w.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff if ok
                                         else Qt.ScrollBarPolicy.ScrollBarAsNeeded)

    def expand_field(self, w):
        """Mehrzeiliges Feld beim Schreiben so groß machen, dass der ganze Text in lesbarer Schrift sichtbar ist."""
        if w.base is None or w.isReadOnly():
            return
        f = w.f
        z = self.zoom
        px = max(self._nominal(w, f) if f["fontsize"] > 0 else 10.0 * z, 8.0 * z)
        px = min(px, 14.0 * z)
        fnt = field_font(f["font"])
        fnt.setPixelSize(max(1, int(px)))
        extra = w.height() - w.viewport().height()
        if not 0 <= extra <= 30:
            extra = 4
        need = int(self._doc_height(w, fnt, w.base.width() - 6)) + extra + 4
        if not w.expanded and need <= w.base.height():
            return                                   # passt ohnehin: nichts tun, normale Anpassung genügt
        w.expanded = True
        w.blockSignals(True)
        self._apply_font(w, f, px, BORDER_OK)
        w.blockSignals(False)
        h = max(w.base.height(), need)
        y = w.base.y()
        ph = self.page.height()
        if y + h > ph:
            y = max(0, ph - h)
            h = min(h, ph)
        w.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded if h >= ph
                                     else Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        w.setGeometry(w.base.x(), y, w.base.width(), h)
        w.raise_()

    def collapse_field(self, w):
        if w.base is None:
            return
        try:
            w.expanded = False
            w.setGeometry(w.base)
            self.fit_field(w, w.f)
        except RuntimeError:
            pass

    def commit_fields(self):
        """Noch nicht übernommene Eingaben (Feld hat noch den Fokus) ins PDF schreiben."""
        for c in list(getattr(self, "field_commits", [])):
            c()

    def field_changed(self, xref, value, w):
        if value == w.property("pdf_value"):
            return
        try:
            self.ed.set_field(self.pno, xref, value)
        except Exception as e:
            self.fail(e)
            return
        try:
            w.setProperty("pdf_value", value)
            self.update_title()
        except RuntimeError:          # Fenster wird gerade geschlossen
            pass

    def button_changed(self, xref, on):
        try:
            self.ed.set_field(self.pno, xref, on)
        except Exception as e:
            self.fail(e)
        self.show_page()

    def refresh(self):
        self.fill_list()
        self.show_page()

    def set_zoom(self, z):
        self.zoom = max(0.4, min(4.0, z))
        self.show_page()

    def set_mode(self, mode):
        self.mode = mode
        (self.a_view, self.a_edit, self.a_add)[mode].setChecked(True)
        self.page.setCursor(Qt.CursorShape.ArrowCursor if mode == MODE_VIEW else
                            (Qt.CursorShape.IBeamCursor if mode == MODE_EDIT else Qt.CursorShape.CrossCursor))

    def fail(self, e):
        QMessageBox.warning(self, APP_NAME, str(e))

    # ---- Text
    def on_click(self, px, py):
        if self.mode == MODE_VIEW:
            return
        x, y = px / self.zoom, py / self.zoom
        try:
            if self.mode == MODE_EDIT:
                line = self.ed.line_at(self.pno, x, y)
                if line is None:
                    self.statusBar().showMessage("An dieser Stelle steht kein Text (oder er ist ein Bild).", 5000)
                    return
                new, ok = QInputDialog.getText(self, "Zeile ändern", "Text der Zeile (leer löscht die Zeile):",
                                               QLineEdit.EchoMode.Normal, line["text"])
                if ok and new != line["text"]:
                    self.ed.replace_line(self.pno, line, new)
                    self.show_page()
            else:
                text = self.ask_text()
                if text:
                    self.ed.add_text(self.pno, x, y, text, self.size.value())
                    self.show_page()
        except PdfError as e:
            self.fail(e)

    def ask_text(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("Text hinzufügen")
        lay = QFormLayout(dlg)
        ed = QPlainTextEdit()
        ed.setMinimumSize(420, 120)
        lay.addRow("Text:", ed)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        lay.addRow(bb)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            return ed.toPlainText().strip("\n")
        return ""

    def replace(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("Suchen und ersetzen")
        lay = QFormLayout(dlg)
        a, b = QLineEdit(), QLineEdit()
        a.setMinimumWidth(360)
        lay.addRow("Suchen:", a)
        lay.addRow("Ersetzen durch:", b)
        lay.addRow(QLabel("Ersetzt wird im ganzen PDF, ohne Unterscheidung von Groß- und Kleinschreibung."))
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        lay.addRow(bb)
        if dlg.exec() != QDialog.DialogCode.Accepted or not a.text():
            return
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            n, skipped = self.ed.replace_all(a.text(), b.text())
        except PdfError as e:
            QApplication.restoreOverrideCursor()
            self.fail(e)
            return
        QApplication.restoreOverrideCursor()
        self.show_page()
        msg = "%d Stelle(n) ersetzt." % n
        if skipped:
            msg += " %d Stelle(n) übersprungen (gedrehte Seite oder nicht zuordenbar)." % skipped
        self.statusBar().showMessage(msg, 10000)

    def undo(self):
        if self.ed.undo_last():
            self.refresh()
        else:
            self.statusBar().showMessage("Nichts rückgängig zu machen.", 4000)

    # ---- Seiten
    def del_page(self):
        try:
            self.ed.delete_page(self.pno)
        except PdfError as e:
            return self.fail(e)
        self.refresh()

    def rot_page(self):
        self.ed.rotate_page(self.pno)
        self.show_page()

    def move(self, delta):
        self.pno = self.ed.move_page(self.pno, delta)
        self.refresh()

    def append(self):
        p, _ = QFileDialog.getOpenFileName(self, "PDF anhängen", os.path.dirname(self.ed.path), "PDF (*.pdf)")
        if not p:
            return
        try:
            self.ed.append_pdf(p)
        except PdfError as e:
            return self.fail(e)
        self.refresh()

    # ---- Datei
    def save(self):
        return self._save(self.ed.path)

    def save_as(self):
        p, _ = QFileDialog.getSaveFileName(self, "PDF speichern unter", self.ed.path, "PDF (*.pdf)")
        if not p:
            return False
        if not p.lower().endswith(".pdf"):
            p += ".pdf"
        return self._save(p)

    def _save(self, dest):
        self.commit_fields()
        try:
            self.ed.save(dest)
        except Exception as e:
            QMessageBox.warning(self, APP_NAME, "Das PDF konnte nicht gespeichert werden:\n%s" % e)
            return False
        self.update_title()
        self.statusBar().showMessage("Gespeichert: " + self.ed.path, 6000)
        return True

    def to_source(self):
        if self.main is not None:
            if self.ed.modified:
                QMessageBox.information(self, APP_NAME, "Geöffnet wird der zuletzt gespeicherte Stand der Datei.")
            self.main.open_pdf_source(self.ed.path)

    def to_latex(self):
        if self.main is not None:
            if self.ed.modified:
                QMessageBox.information(self, APP_NAME, "Ausgelesen wird der zuletzt gespeicherte Stand der Datei.")
            self.main.open_file(self.ed.path, convert=True)
            self.main.raise_()
            self.main.activateWindow()

    def help(self):
        QMessageBox.information(self, APP_NAME, (
            "Ein PDF ist ein fertig gesetztes Blatt, kein Fließtext. Deshalb gilt:\n\n"
            "Text bearbeiten: Die angeklickte Zeile wird entfernt und an derselben Stelle neu gesetzt, in "
            "gleicher Größe und Farbe und einer möglichst ähnlichen Schrift (Liberation oder DejaVu). Wird die "
            "Zeile länger, läuft sie über den alten Rand hinaus; es wird nicht neu umbrochen.\n\n"
            "Suchen und ersetzen: wie oben, für alle Treffer im PDF.\n\n"
            "Text hinzufügen: an die angeklickte Stelle, in der eingestellten Größe.\n\n"
            "Seiten: verschieben, drehen, löschen, weiteres PDF anhängen.\n\n"
            "Formulare: Ausfüllbare Felder des PDF erscheinen blau hinterlegt und lassen sich direkt ausfüllen "
            "(Textfelder, Ankreuzfelder, Optionsknöpfe, Auswahllisten). F8 blendet sie aus und ein.\n\n"
            "Nicht möglich: Text in gescannten Seiten (das sind Bilder), Absätze neu umbrechen, Bilder ändern. "
            "Für größere Änderungen den Text als LaTeX-Quelltext öffnen (Menü Datei) und ein neues PDF erzeugen.\n\n"
            "Beim ersten Speichern entsteht eine Sicherung mit der Endung .bak."))

    def closeEvent(self, e):
        self.commit_fields()
        if self.ed.modified:
            r = QMessageBox.question(self, APP_NAME, "Änderungen an %s speichern?" % os.path.basename(self.ed.path),
                                     QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard
                                     | QMessageBox.StandardButton.Cancel)
            if r == QMessageBox.StandardButton.Cancel or (r == QMessageBox.StandardButton.Save and not self.save()):
                e.ignore()
                return
        if self.main is not None and self in self.main.children_windows:
            self.main.children_windows.remove(self)
        e.accept()
