#!/usr/bin/env bash
# Entfernt das Programm. Deine Daten (Dokumente/Seifferts Depot) bleiben immer erhalten.
# Mit "./uninstall.sh --alles" werden zusaetzlich die Einstellungen und das Protokoll geloescht.
set -u
DATA="${XDG_DATA_HOME:-$HOME/.local/share}/seiffert-depot"
CONF="${XDG_CONFIG_HOME:-$HOME/.config}/seiffert-depot"
chmod -R u+w "$DATA/app" "$DATA/venv" 2>/dev/null || true
rm -rf "$DATA/app" "$DATA/venv"
rm -f "$HOME/.local/bin/seiffert-depot"
rm -f "${XDG_DATA_HOME:-$HOME/.local/share}/applications/seiffert-depot.desktop"
rm -f "${XDG_DATA_HOME:-$HOME/.local/share}/icons/hicolor/256x256/apps/seiffert-depot.png"
update-desktop-database "${XDG_DATA_HOME:-$HOME/.local/share}/applications" >/dev/null 2>&1 || true
if [ "${1:-}" = "--alles" ]; then rm -rf "$DATA" "$CONF"; echo "Einstellungen und Protokoll geloescht."; fi
echo "Seifferts Depot wurde entfernt. Der Ordner Dokumente/Seifferts Depot mit deinen Daten ist unveraendert."
