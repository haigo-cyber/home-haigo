"""Eigene Bedienelemente: formatierter Editor, Quelltext-Editor, Suchleiste."""
from PySide6.QtCore import Qt, QUrl, Signal
from PySide6.QtGui import (QAction, QFont, QImage, QKeySequence, QTextCursor, QTextDocument, QTextImageFormat,
                           QTextListFormat, QPainter, QColor, QFontDatabase, QTextFormat)
from PySide6.QtWidgets import (QCheckBox, QHBoxLayout, QLabel, QLineEdit, QPlainTextEdit, QPushButton,
                               QTextEdit, QWidget, QToolButton, QApplication)

from .builder import DPI


_IMG_COUNTER = [0]


def insert_image_into(edit, image, name_hint="bild"):
    doc = edit.document()
    _IMG_COUNTER[0] += 1
    name = "seiffert-img:%s-%d" % (name_hint, _IMG_COUNTER[0] + 100000)
    doc.addResource(QTextDocument.ResourceType.ImageResource, QUrl(name), image)
    fmt = QTextImageFormat()
    fmt.setName(name)
    wpx = min(image.width(), 16 / 2.54 * DPI)
    fmt.setWidth(wpx)
    fmt.setHeight(wpx * image.height() / max(1, image.width()))
    edit.textCursor().insertImage(fmt)


class RichEdit(QTextEdit):
    """Formatierter Editor mit Listen-Einrückung per Tab und Einfügen von Bildern."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptRichText(True)
        self.setTabChangesFocus(False)

    def keyPressEvent(self, e):
        cur = self.textCursor()
        lst = cur.currentList()
        if lst is not None and e.key() in (Qt.Key.Key_Tab, Qt.Key.Key_Backtab) and not cur.hasSelection():
            fmt = lst.format()
            ind = fmt.indent()
            if e.key() == Qt.Key.Key_Tab:
                ind += 1
            elif ind > 1:
                ind -= 1
            else:
                return super().keyPressEvent(e)
            nf = QTextListFormat(fmt)
            nf.setIndent(ind)
            cur.createList(nf)
            return
        if lst is not None and e.key() == Qt.Key.Key_Backspace and cur.atBlockStart() and not cur.hasSelection():
            lst.remove(cur.block())
            bf = cur.blockFormat()
            bf.setIndent(0)
            cur.setBlockFormat(bf)
            return
        was_heading = (e.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter) and cur.blockFormat().headingLevel() > 0
                       and cur.atBlockEnd() and not cur.hasSelection())
        super().keyPressEvent(e)
        if was_heading:
            from .builder import apply_heading
            c = self.textCursor()
            apply_heading(c, 0)
            self.setTextCursor(c)

    # ---- Links öffnen: Strg+Klick, Kontextmenü „Link öffnen“, Mauszeiger über dem Link
    def anchor_at(self, pos):
        return self.anchorAt(pos)

    def open_link(self, href):
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        import os
        if not href:
            return False
        if href.startswith("#"):
            return False
        url = QUrl(href)
        if not url.scheme() or (len(url.scheme()) == 1):       # relativer Pfad oder Laufwerksangabe
            base = self.document().baseUrl().toLocalFile() or ""
            p = href if os.path.isabs(href) else os.path.join(base, href)
            if os.path.exists(p):
                url = QUrl.fromLocalFile(p)
            else:
                url = QUrl.fromUserInput(href)
        return QDesktopServices.openUrl(url)

    def mouseMoveEvent(self, e):
        super().mouseMoveEvent(e)
        h = self.anchorAt(e.position().toPoint())
        if h:
            self.viewport().setCursor(Qt.CursorShape.PointingHandCursor
                                      if e.modifiers() & Qt.KeyboardModifier.ControlModifier
                                      else Qt.CursorShape.IBeamCursor)
            self.viewport().setToolTip(h + "\n(Strg+Klick öffnet den Link)")
        else:
            self.viewport().setCursor(Qt.CursorShape.IBeamCursor)
            self.viewport().setToolTip("")

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton and e.modifiers() & Qt.KeyboardModifier.ControlModifier:
            h = self.anchorAt(e.position().toPoint())
            if h and self.open_link(h):
                e.accept()
                return
        super().mouseReleaseEvent(e)

    def contextMenuEvent(self, e):
        h = self.anchorAt(e.pos())
        menu = self.createStandardContextMenu()
        if h:
            first = menu.actions()[0] if menu.actions() else None
            a = QAction("Link öffnen", menu)
            a.triggered.connect(lambda: self.open_link(h))
            c = QAction("Link-Adresse kopieren", menu)
            c.triggered.connect(lambda: __import__("PySide6.QtWidgets", fromlist=["QApplication"])
                                .QApplication.clipboard().setText(h))
            menu.insertAction(first, a)
            menu.insertAction(first, c)
            menu.insertSeparator(first)
        menu.exec(e.globalPos())

    def insertFromMimeData(self, src):
        if src.hasImage() and not src.hasHtml():
            img = src.imageData()
            if isinstance(img, QImage) and not img.isNull():
                insert_image_into(self, img, "einfuegen")
                return
        super().insertFromMimeData(src)


class SourceEdit(QPlainTextEdit):
    """Quelltext-Editor (Markdown, LaTeX) mit Zeilennummern."""

    def __init__(self, parent=None):
        super().__init__(parent)
        f = QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont)
        f.setPointSize(11)
        self.setFont(f)
        self.setLineWrapMode(QPlainTextEdit.LineWrapMode.WidgetWidth)
        self.setTabStopDistance(self.fontMetrics().horizontalAdvance(" ") * 4)
        self.gutter = _Gutter(self)
        self.blockCountChanged.connect(self._update_width)
        self.updateRequest.connect(self._update_gutter)
        self._update_width()

    def gutter_width(self):
        digits = len(str(max(1, self.blockCount())))
        return 12 + self.fontMetrics().horizontalAdvance("9") * digits

    def _update_width(self, *_):
        self.setViewportMargins(self.gutter_width(), 0, 0, 0)

    def _update_gutter(self, rect, dy):
        if dy:
            self.gutter.scroll(0, dy)
        else:
            self.gutter.update(0, rect.y(), self.gutter.width(), rect.height())
        if rect.contains(self.viewport().rect()):
            self._update_width()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        cr = self.contentsRect()
        self.gutter.setGeometry(cr.left(), cr.top(), self.gutter_width(), cr.height())

    def paint_gutter(self, ev):
        p = QPainter(self.gutter)
        pal = self.palette()
        p.fillRect(ev.rect(), pal.alternateBase().color())
        p.setPen(QColor(128, 128, 128))
        block = self.firstVisibleBlock()
        n = block.blockNumber()
        top = round(self.blockBoundingGeometry(block).translated(self.contentOffset()).top())
        bottom = top + round(self.blockBoundingRect(block).height())
        while block.isValid() and top <= ev.rect().bottom():
            if block.isVisible() and bottom >= ev.rect().top():
                p.drawText(0, top, self.gutter.width() - 6, self.fontMetrics().height(),
                           Qt.AlignmentFlag.AlignRight, str(n + 1))
            block = block.next()
            top = bottom
            bottom = top + round(self.blockBoundingRect(block).height())
            n += 1

    def goto_line(self, line):
        blk = self.document().findBlockByNumber(max(0, line - 1))
        cur = QTextCursor(blk)
        self.setTextCursor(cur)
        self.centerCursor()


class _Gutter(QWidget):
    def __init__(self, edit):
        super().__init__(edit)
        self.edit = edit

    def sizeHint(self):
        from PySide6.QtCore import QSize
        return QSize(self.edit.gutter_width(), 0)

    def paintEvent(self, e):
        self.edit.paint_gutter(e)


class FindBar(QWidget):
    closed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(6, 2, 6, 2)
        self.find = QLineEdit()
        self.find.setPlaceholderText("Suchen")
        self.repl = QLineEdit()
        self.repl.setPlaceholderText("Ersetzen durch")
        self.case = QCheckBox("Groß/klein")
        self.btn_prev = QPushButton("Zurück")
        self.btn_next = QPushButton("Weiter")
        self.btn_rep = QPushButton("Ersetzen")
        self.btn_all = QPushButton("Alle ersetzen")
        self.info = QLabel("")
        close = QToolButton()
        close.setText("✕")
        close.clicked.connect(self.hide)
        close.clicked.connect(self.closed)
        for w in (self.find, self.btn_prev, self.btn_next, self.case, self.repl, self.btn_rep,
                  self.btn_all, self.info):
            lay.addWidget(w)
        lay.addStretch(1)
        lay.addWidget(close)
        self.target = lambda: None
        self.btn_next.clicked.connect(lambda: self.go(False))
        self.btn_prev.clicked.connect(lambda: self.go(True))
        self.find.returnPressed.connect(lambda: self.go(False))
        self.btn_rep.clicked.connect(self.replace_one)
        self.btn_all.clicked.connect(self.replace_all)
        self.hide()

    def flags(self, back):
        f = QTextDocument.FindFlag(0)
        if self.case.isChecked():
            f |= QTextDocument.FindFlag.FindCaseSensitively
        if back:
            f |= QTextDocument.FindFlag.FindBackward
        return f

    def go(self, back):
        w = self.target()
        t = self.find.text()
        if w is None or not t:
            return
        if not w.find(t, self.flags(back)):
            cur = w.textCursor()
            cur.movePosition(QTextCursor.MoveOperation.End if back else QTextCursor.MoveOperation.Start)
            w.setTextCursor(cur)
            if not w.find(t, self.flags(back)):
                self.info.setText("nicht gefunden")
                return
        self.info.setText("")

    def replace_one(self):
        w = self.target()
        if w is None:
            return
        cur = w.textCursor()
        sel = cur.selectedText()
        t = self.find.text()
        if t and (sel == t or (not self.case.isChecked() and sel.lower() == t.lower())):
            cur.insertText(self.repl.text())
        self.go(False)

    def replace_all(self):
        w = self.target()
        t = self.find.text()
        if w is None or not t:
            return
        cur = w.textCursor()
        cur.movePosition(QTextCursor.MoveOperation.Start)
        w.setTextCursor(cur)
        n = 0
        cur.beginEditBlock()
        while w.find(t, self.flags(False)):
            w.textCursor().insertText(self.repl.text())
            n += 1
        cur.endEditBlock()
        self.info.setText("%d ersetzt" % n)

    def open(self, text=""):
        self.show()
        if text:
            self.find.setText(text)
        self.find.setFocus()
        self.find.selectAll()
