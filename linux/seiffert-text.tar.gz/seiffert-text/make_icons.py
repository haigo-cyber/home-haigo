"""Erzeugt Platzhalter-Symbole (dunkelblaues Quadrat mit Punktraster und T). Eigene PNGs mit denselben Namen
(icon-32 bis icon-256) in seiffert_text/icons ersetzen das Symbol."""
import os, sys
from PySide6.QtGui import QGuiApplication, QImage, QPainter, QColor, QFont, QPen
from PySide6.QtCore import Qt, QRectF
app = QGuiApplication([])
out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "seiffert_text", "icons")
os.makedirs(out, exist_ok=True)
for sz in (32, 48, 64, 128, 256):
    img = QImage(sz, sz, QImage.Format.Format_ARGB32)
    img.fill(Qt.GlobalColor.transparent)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setBrush(QColor("#10285c"))
    p.setPen(Qt.PenStyle.NoPen)
    p.drawRoundedRect(QRectF(0, 0, sz, sz), sz * 0.12, sz * 0.12)
    n = 9
    step = sz / (n + 1)
    p.setBrush(QColor(255, 255, 255, 70))
    for i in range(1, n + 1):
        for j in range(1, n + 1):
            p.drawEllipse(QRectF(i * step - sz * 0.012, j * step - sz * 0.012, sz * 0.024, sz * 0.024))
    f = QFont("DejaVu Serif")
    f.setBold(True)
    f.setPixelSize(int(sz * 0.62))
    p.setFont(f)
    p.setPen(QColor("white"))
    p.drawText(QRectF(0, 0, sz, sz), Qt.AlignmentFlag.AlignCenter, "T")
    p.end()
    img.save(os.path.join(out, "icon-%d.png" % sz))
print("ok")
