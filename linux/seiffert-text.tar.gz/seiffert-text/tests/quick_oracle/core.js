'use strict';

/* Befehle, deren Klammerinhalte reine Steuerung sind (nie als Text anbieten) */
const LAYOUT_CMDS = new Set(('documentclass usepackage begin end fontsize hspace vspace hskip vskip kern rule ' +
  'includegraphics setlength addtolength settowidth setcounter addtocounter newcommand renewcommand providecommand ' +
  'def let label ref pageref eqref cite input include color definecolor pagecolor geometry pagestyle thispagestyle ' +
  'newlength newcounter bibliography bibliographystyle vphantom hphantom phantom cline lstset tikzset ' +
  'usetikzlibrary newenvironment renewenvironment hypersetup selectlanguage setmainfont setsansfont newpage ' +
  'clearpage pagebreak nopagebreak linebreak hline arraystretch').split(' '));

/* Befehle, bei denen nur bestimmte Klammergruppen (Zählung ab 0) Text sind */
const GROUP_POLICY = {
  textcolor: [1], colorbox: [1], fcolorbox: [2], multicolumn: [2], multirow: [2], parbox: [1],
  raisebox: [1], scalebox: [1], rotatebox: [1], resizebox: [2], href: [1], foreignlanguage: [1],
  hyperlink: [1], hypertarget: [1]
};

/* Befehle, die mitten im Text stehen und Teil des Textes bleiben (Sonderzeichen, Anführungszeichen ...) */
const GLYPH_CMDS = new Set(('ss SS glqq grqq glq grq flqq frqq dq ldots dots textbackslash textasciitilde textasciicircum ' +
  'euro texteuro textendash textemdash textbullet copyright pounds dag ddag S P o O ae AE oe OE aa AA l L i j ' +
  'LaTeX TeX today textellipsis textquotedblleft textquotedblright degree textdegree textregistered texttrademark ' +
  'checkmark').split(' '));

/* Umgebungen, deren Inhalt nie als Text angeboten wird */
const RAW_ENVS = ['tikzpicture', 'verbatim', 'lstlisting', 'minted', 'align', 'align*', 'equation', 'equation*',
  'gather', 'gather*', 'multline', 'multline*', 'eqnarray', 'eqnarray*', 'displaymath', 'math', 'pgfpicture',
  'filecontents', 'filecontents*'];

let _uid = 1;
const newId = () => _uid++;
const cloneJSON = o => JSON.parse(JSON.stringify(o));

/* ---------- Zerlegung einer Zeile in Struktur (s) und Textfelder (x) ---------- */

function isTextCore(t) {
  if (!/[A-Za-z0-9À-ɏ]/.test(t)) return false;
  if (/^[-+]?(\d+\.?\d*|\.\d+)\s*(pt|em|ex|cm|mm|in|bp|sp|pc|dd|cc|mu|px)$/.test(t.trim())) return false;
  return true;
}

function groupEditable(name, idx) {
  if (LAYOUT_CMDS.has(name)) return false;
  if (GROUP_POLICY[name]) return GROUP_POLICY[name].indexOf(idx) >= 0;
  return true;
}

function findClose(line, i, open, close) {
  let d = 0;
  for (let j = i + 1; j < line.length; j++) {
    const c = line[j];
    if (c === '\\') { j++; continue; }
    if (c === '{') d++;
    else if (c === '}') d--;
    else if (c === close && d <= 0) return j;
  }
  return -1;
}

function tokenizeLine(line, raw) {
  if (raw) return line === '' ? [] : [{ k: 's', v: line }];
  const out = [];
  const n = line.length;
  let i = 0;
  const stack = [];
  let pend = null;
  let textOwner = null;
  let buf = '';
  const pushS = v => {
    if (!v) return;
    const l = out[out.length - 1];
    if (l && l.k === 's') l.v += v; else out.push({ k: 's', v });
  };
  const ownerOk = () => stack.length ? stack[stack.length - 1].e : (textOwner ? !LAYOUT_CMDS.has(textOwner) : true);
  const flush = () => {
    if (!buf) return;
    const t = buf; buf = '';
    const m = /^(\s*)([\s\S]*?)(\s*)$/.exec(t);
    if (m[2] && ownerOk() && isTextCore(m[2])) {
      pushS(m[1]);
      const sg = { k: 'x', v: m[2] };
      if (stack.length && stack[stack.length - 1].name === 'url') sg.raw = true; // Adressen nie maskieren
      out.push(sg); pushS(m[3]);
    }
    else pushS(t);
  };
  while (i < n) {
    const c = line[i];
    if (pend && c !== '{' && c !== '[') pend = null;
    if (c === '%') { flush(); pushS(line.slice(i)); i = n; break; }
    if (c === '\\') {
      const re = /\\([A-Za-z@]+)(\*?)/y;
      re.lastIndex = i;
      const m = re.exec(line);
      if (m) {
        const name = m[1];
        if (GLYPH_CMDS.has(name)) { buf += m[0]; i += m[0].length; continue; }
        flush();
        pushS(m[0]); i += m[0].length;
        pend = { name, idx: 0 }; textOwner = name;
        continue;
      }
      const d = line[i + 1];
      if (d === undefined) { buf += '\\'; i++; continue; }
      if (d === '\\') {
        flush(); pushS('\\\\'); i += 2; textOwner = null;
        if (line[i] === '[') { const j = findClose(line, i, '[', ']'); const e = j < 0 ? n - 1 : j; pushS(line.slice(i, e + 1)); i = e + 1; }
        continue;
      }
      if (d === '(' || d === '[') {
        flush();
        const close = d === '(' ? '\\)' : '\\]';
        const j = line.indexOf(close, i + 2);
        const end = j < 0 ? n : j + 2;
        pushS(line.slice(i, end)); i = end; textOwner = null;
        continue;
      }
      if (d === ')' || d === ']') { flush(); pushS(line.slice(i, i + 2)); i += 2; continue; }
      buf += line.slice(i, i + 2); i += 2; continue;
    }
    if (c === '{') {
      flush();
      if (pend) {
        const parentE = stack.length ? stack[stack.length - 1].e : true;
        stack.push({ e: parentE && groupEditable(pend.name, pend.idx), name: pend.name, idx: pend.idx });
        pend = null;
      } else {
        stack.push({ e: stack.length ? stack[stack.length - 1].e : true, name: null, idx: 0 });
      }
      pushS('{'); i++; textOwner = null;
      continue;
    }
    if (c === '}') {
      flush();
      pushS('}'); i++;
      const e = stack.pop();
      pend = (e && e.name) ? { name: e.name, idx: e.idx + 1 } : null;
      textOwner = null;
      continue;
    }
    if (c === '[' && pend) {
      const j = findClose(line, i, '[', ']');
      const e = j < 0 ? n - 1 : j;
      pushS(line.slice(i, e + 1)); i = e + 1;
      continue;
    }
    if (c === '$') {
      flush();
      let end;
      if (line[i + 1] === '$') { const j = line.indexOf('$$', i + 2); end = j < 0 ? n : j + 2; }
      else {
        let j = i + 1;
        while (j < n) { if (line[j] === '\\') { j += 2; continue; } if (line[j] === '$') break; j++; }
        end = j >= n ? n : j + 1;
      }
      pushS(line.slice(i, end)); i = end; textOwner = null;
      continue;
    }
    if (c === '&') { flush(); pushS('&'); i++; textOwner = null; continue; }
    buf += c; i++;
  }
  flush();
  return out;
}

/* ---------- Datei -> Dokument ---------- */

function stripComment(line) { return line.replace(/(^|[^\\])%.*$/, '$1'); }

function rawStateFor(line, st) {
  const lc = stripComment(line);
  let raw = st.rawDepth > 0 || st.disp;
  const re = /\\(begin|end)\{([^}]*)\}/g;
  let m;
  while ((m = re.exec(lc))) {
    if (RAW_ENVS.indexOf(m[2]) >= 0) { raw = true; st.rawDepth += m[1] === 'begin' ? 1 : -1; }
  }
  if (st.rawDepth < 0) st.rawDepth = 0;
  const o = (lc.match(/\\\[/g) || []).length, c = (lc.match(/\\\]/g) || []).length;
  if (o > c) { st.disp = true; raw = true; }
  else if (c > o) { raw = true; st.disp = false; }
  return raw;
}

/* Grafikzeile: genau die Form, die das Tool selbst erzeugt */
const IMG_RE = /^\\noindent\\makebox\[\\linewidth\]\[([lcr])\]\{\\includegraphics\[width=([0-9]+(?:\.[0-9]+)?)cm\]\{([^{}\s]+)\}\}\\par$/;
function fmtCm(w) { return String(Math.round(w * 100) / 100); }
function imgLine(im) { return '\\noindent\\makebox[\\linewidth][' + im.a + ']{\\includegraphics[width=' + fmtCm(im.w) + 'cm]{' + im.file + '}}\\par'; }
function makeUnit(line, raw) {
  const u = { id: newId(), segs: tokenizeLine(line, raw), raw: !!raw };
  if (!raw) {
    const m = IMG_RE.exec(line);
    if (m) u.img = { a: m[1], w: parseFloat(m[2]), file: m[3] };
  }
  return u;
}
function isContent(u) { return hasFields(u) || !!u.img; }

function parseTex(text) {
  let eol = '\n';
  if (text.indexOf('\r\n') >= 0) { eol = '\r\n'; text = text.replace(/\r\n/g, '\n'); }
  const TAG = '\\begin{document}';
  const b = text.indexOf(TAG);
  const e = text.lastIndexOf('\\end{document}');
  if (b < 0 || e < 0 || e < b) throw new Error('In der Datei fehlen \\begin{document} und \\end{document}. Das ist keine vollständige LaTeX-Vorlage.');
  const headEnd = b + TAG.length;
  const head = text.slice(0, headEnd), body = text.slice(headEnd, e), tail = text.slice(e);
  const lines = body.split('\n');
  const st = { rawDepth: 0, disp: false };
  const units = lines.map(l => makeUnit(l, rawStateFor(l, st)));
  if (units.length >= 2) {
    if (lines[0].trim() === '') units[0].fixed = true;
    if (lines[lines.length - 1].trim() === '') units[units.length - 1].fixed = true;
  }
  return { eol, head, tail, units };
}

/* ---------- Ausgabe ---------- */

/* Nur Zeichen absichern, die in normalem Text sonst die Kompilierung stören */
function escSpecial(s) {
  return s.replace(/(\\[\s\S])|([&%#_$])|(\\$)/g, (m, a, b, c) => a ? a : (b ? '\\' + b : '\\textbackslash{}'));
}
function segOut(sg, opts) {
  if (sg.k === 'x' && sg.edited && !sg.raw && opts && opts.autoEscape) return escSpecial(sg.v);
  return sg.v;
}
/* ---------- Automatischer Zeilenumbruch in festen Boxen ----------
   \makebox mit fester Breite bricht nie um. Steht ein Textfeld darin, wird die Box beim Ausgeben
   durch \umbruchbox ersetzt: kurzer Text bleibt wie bisher, langer Text bricht in einer Box
   von 60 Prozent der Zeilenbreite um. */
const UB_DEF = '% Automatischer Zeilenumbruch in festen Boxen (vom LaTeX-Schnelleditor)\n' +
  '\\newlength{\\umbruchbreite}\n' +
  '\\newcommand{\\umbruchbox}[3]{%\n' +
  '\t\\settowidth{\\umbruchbreite}{#3}%\n' +
  '\t\\ifdim\\umbruchbreite>0.6\\linewidth\n' +
  '\t\t\\parbox[t]{0.6\\linewidth}{\\if#2c\\centering\\fi\\if#2l\\raggedright\\fi\\if#2r\\raggedleft\\fi #3}%\n' +
  '\t\\else\n' +
  '\t\t\\makebox[#1][#2]{#3}%\n' +
  '\t\\fi}\n\n';
const EM_DEF = '% Text nie über den Rand laufen lassen (vom LaTeX-Schnelleditor)\n\\emergencystretch=3em\n\n';
function closesEarly(t) {
  let d = 0;
  for (let i = 0; i < t.length; i++) {
    const c = t[i];
    if (c === '\\') { i++; continue; }
    if (c === '{') d++; else if (c === '}') { d--; if (d < 0) return true; }
  }
  return false;
}
function autoBreakOut(u, opts) {
  const parts = u.segs.map(sg => segOut(sg, opts));
  return parts.map((t, i) => {
    if (u.segs[i].k !== 's' || !u.segs.slice(i + 1).some(x => x.k === 'x')) return t;
    return t.replace(/\\makebox\[([^\]]*)\]\[([lcrs])\]\{/g, (m, w, a, off) =>
      closesEarly(t.slice(off + m.length)) ? m : '\\umbruchbox{' + w + '}{' + a + '}{');
  }).join('');
}
function unitOut(u, opts) {
  if (opts && opts.autoBreak && !u.raw && hasFields(u)) return autoBreakOut(u, opts);
  return u.segs.map(s => segOut(s, opts)).join('');
}
function bodyOut(doc, opts) { return doc.units.map(u => unitOut(u, opts)).join('\n'); }
function serialize(doc, opts) {
  const body = bodyOut(doc, opts);
  let head = doc.head;
  const TAGB = '\\begin{document}';
  if (opts && opts.autoBreak && head.slice(-TAGB.length) === TAGB) {
    let extra = '';
    if (body.indexOf('\\umbruchbox{') >= 0 && head.indexOf('\\umbruchbox') < 0) extra += UB_DEF;
    /* Ohne Dehnungsreserve lässt LaTeX bei langen fetten Zeilen (Themenzeilen, Überschriften) den Text
       über den rechten Rand hinausragen, statt umzubrechen. */
    if (!/\\emergencystretch|\\sloppy/.test(head)) extra += EM_DEF;
    if (extra) head = head.slice(0, head.length - TAGB.length) + extra + TAGB;
  }
  return head + body + doc.tail;
}
function serializeFile(doc, opts) {
  const t = serialize(doc, opts);
  return doc.eol === '\r\n' ? t.replace(/\n/g, '\r\n') : t;
}

function hasFields(u) { return u.segs.some(s => s.k === 'x'); }
function isBlankUnit(u) { return u.segs.every(s => s.k === 's' && s.v.trim() === ''); }
function rawOfUnit(u) { return u.segs.map(s => s.v).join(''); }

function braceDelta(s) {
  let d = 0;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (c === '\\') { i++; continue; }
    if (c === '{') d++; else if (c === '}') d--;
  }
  return d;
}

function checkDoc(doc, opts) {
  const w = [];
  doc.units.forEach(u => {
    u.segs.forEach(s => {
      if (s.k === 'x' && s.edited) {
        const t = segOut(s, opts);
        if (braceDelta(t) !== 0) w.push({ id: u.id, msg: 'Ein Textfeld enthält ungleich viele { und }: „' + t.slice(0, 30) + '“' });
      }
    });
  });
  const hasGfx = /^[^%\n]*\\usepackage(?:\[[^\]]*\])?\{[^}]*\bgraphicx\b[^}]*\}/m.test(doc.head);
  doc.units.forEach(u => {
    if (!u.img) return;
    if (!hasGfx) { w.push({ id: u.id, msg: 'Die Vorlage lädt das Paket graphicx nicht, Grafiken lassen sich so nicht kompilieren.' }); }
    if (/[\s%#&{}\\~^$]/.test(u.img.file)) w.push({ id: u.id, msg: 'Der Dateiname „' + u.img.file + '“ enthält Leerzeichen oder Sonderzeichen. Das macht LaTeX Probleme, bitte die Datei umbenennen.' });
  });
  return w.filter((x, i) => w.findIndex(y => y.msg === x.msg) === i);
}

function findImages(doc, opts) {
  const text = stripCommentsAll(doc.head + '\n' + bodyOut(doc, opts));
  const re = /\\includegraphics\s*(?:\[[^\]]*\])?\s*\{([^}]+)\}/g;
  const out = [];
  let m;
  while ((m = re.exec(text))) { const p = m[1].trim(); if (out.indexOf(p) < 0) out.push(p); }
  return out;
}
function stripCommentsAll(t) { return t.split('\n').map(stripComment).join('\n'); }

/* ---------- Zeilenoperationen ---------- */

function templateOf(u) {
  const c = cloneJSON(u);
  c.id = newId();
  delete c.fixed;
  c.segs.forEach(s => { if (s.k === 'x') { s.v = ''; s.edited = true; } });
  return c;
}
function opInsertBelow(doc, idx) {
  const t = doc.units[idx];
  const nu = hasFields(t) ? templateOf(t) : { id: newId(), segs: [], raw: false };
  doc.units.splice(idx + 1, 0, nu);
  return nu;
}
function opDuplicate(doc, idx) {
  const c = cloneJSON(doc.units[idx]);
  c.id = newId(); delete c.fixed;
  doc.units.splice(idx + 1, 0, c);
  return c;
}
function opRemove(doc, idx) { doc.units.splice(idx, 1); }
function opMove(doc, from, to) { const u = doc.units.splice(from, 1)[0]; doc.units.splice(to, 0, u); }
function opMoveRelative(doc, idx, dir, isVisible) {
  let j = idx + dir;
  while (j >= 0 && j < doc.units.length && !isVisible(doc.units[j])) j += dir;
  if (j < 0 || j >= doc.units.length) return false;
  opMove(doc, idx, j);
  return true;
}
function opBulk(doc, idx, text) {
  const t = doc.units[idx];
  if (!hasFields(t)) return [];
  const lines = text.split(/\r?\n/).filter(l => l.trim() !== '');
  const made = [];
  let at = idx;
  for (const l of lines) {
    const u = templateOf(t);
    const cells = l.split('\t');
    const xs = u.segs.filter(s => s.k === 'x');
    xs.forEach((s, k) => {
      if (k === xs.length - 1) s.v = cells.slice(k).join(' ').trim();
      else s.v = cells[k] !== undefined ? cells[k].trim() : '';
    });
    doc.units.splice(++at, 0, u);
    made.push(u);
  }
  return made;
}
function opSetRaw(doc, idx, rawLine) {
  const u = doc.units[idx];
  u.segs = tokenizeLine(rawLine, u.raw);
}


/* ---------- Zeilenarten (eigene Makros der Vorlage) ---------- */
function definedMacros(head) {
  const set = new Set();
  const re = /\\(?:re|provide)?newcommand\*?\s*(?:\{\\([A-Za-z@]+)\}|\\([A-Za-z@]+))/g;
  let m;
  while ((m = re.exec(head))) set.add(m[1] || m[2]);
  return set;
}
function unitMacro(u, macros) {
  if (!hasFields(u)) return null;
  const m = /^\s*\\([A-Za-z@]+)/.exec(rawOfUnit(u));
  return m && macros.has(m[1]) ? m[1] : null;
}


/* ---------- Themenblöcke ----------
   Ein Block beginnt mit einer Themenzeile und reicht bis zur letzten Textzeile
   vor dem nächsten Thema. Die Zeilen dazwischen (Leerzeilen, Abstände) bleiben
   beim Verschieben an ihrer Stelle, damit die Abstände gleich bleiben. */
function themeMacro(doc) {
  const macros = definedMacros(doc.head);
  for (const u of doc.units) {
    const m = unitMacro(u, macros);
    if (m && /thema/i.test(m)) return m;
  }
  return null;
}
function blocksOf(doc, theme) {
  if (!theme) return [];
  const macros = definedMacros(doc.head);
  const U = doc.units, starts = [];
  U.forEach((u, i) => { if (unitMacro(u, macros) === theme) starts.push(i); });
  return starts.map((st, k) => {
    const lim = k + 1 < starts.length ? starts[k + 1] : U.length;
    let e = lim;
    while (e > st + 1 && !isContent(U[e - 1])) e--;
    return { start: st, end: e, next: lim, id: U[st].id };
  });
}
function cloneUnits(arr) {
  return arr.map(u => { const c = cloneJSON(u); c.id = newId(); delete c.fixed; return c; });
}
function gapFor(U, bl, k) {
  const own = U.slice(bl[k].end, bl[k].next);
  if (own.length) return own;
  if (k > 0) return U.slice(bl[k - 1].end, bl[k - 1].next);
  return [];
}
function insertAfterBlock(doc, bl, k, units) {
  const U = doc.units, b = bl[k];
  const hasOwnGap = b.next > b.end;
  const gap = cloneUnits(gapFor(U, bl, k));
  if (hasOwnGap) U.splice(b.next, 0, ...units, ...gap);
  else U.splice(b.end, 0, ...gap, ...units);
}
function opBlockMove(doc, theme, id, dir) {
  const bl = blocksOf(doc, theme);
  const k = bl.findIndex(b => b.id === id), j = k + dir;
  if (k < 0 || j < 0 || j >= bl.length) return false;
  const a = bl[Math.min(k, j)], b = bl[Math.max(k, j)], U = doc.units;
  const A = U.slice(a.start, a.end), gap = U.slice(a.end, b.start), B = U.slice(b.start, b.end);
  U.splice(a.start, b.end - a.start, ...B, ...gap, ...A);
  return true;
}
function opBlockDuplicate(doc, theme, id) {
  const bl = blocksOf(doc, theme), k = bl.findIndex(b => b.id === id);
  if (k < 0) return null;
  const copy = cloneUnits(doc.units.slice(bl[k].start, bl[k].end));
  insertAfterBlock(doc, bl, k, copy);
  return copy[0];
}
function opBlockRemove(doc, theme, id) {
  const bl = blocksOf(doc, theme), k = bl.findIndex(b => b.id === id);
  if (k < 0) return 0;
  const b = bl[k];
  let from = b.start, to = b.next;
  if (b.next === b.end && k > 0) { from = bl[k - 1].end; to = b.end; }
  doc.units.splice(from, to - from);
  return b.end - b.start;
}
function opInsertTypeAfterBlock(doc, theme, id, exemplar) {
  const bl = blocksOf(doc, theme), k = bl.findIndex(b => b.id === id);
  if (k < 0) return null;
  const nu = templateOf(exemplar);
  insertAfterBlock(doc, bl, k, [nu]);
  return nu;
}
function opInsertType(doc, idx, exemplar) {
  const nu = templateOf(exemplar);
  doc.units.splice(idx + 1, 0, nu);
  return nu;
}
/* Grafikzeilen */
function opInsertImage(doc, idx, file, w, a) {
  const im = { a: a || 'l', w: w || 3, file };
  const nu = { id: newId(), segs: [{ k: 's', v: imgLine(im) }], raw: false, img: im };
  doc.units.splice(idx + 1, 0, nu);
  return nu;
}
function opSetImg(u, patch) {
  Object.assign(u.img, patch);
  u.img.w = Math.max(0.2, Math.min(40, Number(u.img.w) || 0.2));
  u.segs = [{ k: 's', v: imgLine(u.img) }];
}
/* Zeilenarten: alle eigenen Makros, die im Text mit Feldern vorkommen, je mit einer Beispielzeile */
function lineTypes(doc) {
  const macros = definedMacros(doc.head), seen = {}, out = [];
  doc.units.forEach(u => {
    const m = unitMacro(u, macros);
    if (m && !seen[m]) { seen[m] = true; out.push({ macro: m, unit: u, fields: u.segs.filter(s => s.k === 'x').length }); }
  });
  return out;
}


/* ---------- Kopfdaten: einfache Text-Makros im Vorspann (z. B. \Titel, \Fach) ---------- */
function isSimpleText(b) {
  if (b === '') return true;
  if (/%/.test(b.replace(/\\%/g, ''))) return false;
  if (/#\d/.test(b)) return false;
  /* reine Zahlen und Längen (0.4pt, 1.0) sind keine Kopftexte */
  if (/^\s*-?[0-9.,]+\s*(cm|mm|pt|em|ex|bp|in|sp|px)?\s*$/.test(b)) return false;
  const t = b.replace(/\\textbar\{\}/g, ' ').replace(/\\(?:textbf|textit|emph|textsc|texttt|underline)\{/g, '{')
    .replace(/\\[&%#_$,;\- ]/g, ' ').replace(/\\(?:quad|qquad|ldots|dots|ss|glqq|grqq|enspace)\b\s*(?:\{\})?/g, ' ').replace(/\\"[A-Za-z]/g, ' ');
  return !/\\/.test(t);
}
/* only: Namen, die schon früher als Kopfdaten erkannt wurden (bleiben auch dann bearbeitbar, wenn der Text jetzt Befehle enthält) */
function headFields(head, only) {
  const all = [];
  const re = /\\(?:re)?newcommand\*?\s*\{\\([A-Za-z@]+)\}\s*\{/g;
  let m;
  while ((m = re.exec(head))) {
    const ls = head.lastIndexOf('\n', m.index) + 1;
    if (/(^|[^\\])%/.test(head.slice(ls, m.index))) continue;
    const open = m.index + m[0].length - 1;
    let d = 0, j = open;
    for (; j < head.length; j++) {
      const c = head[j];
      if (c === '\\') { j++; continue; }
      if (c === '{') d++; else if (c === '}') { d--; if (d === 0) break; }
    }
    if (j >= head.length) continue;
    const body = head.slice(open + 1, j);
    re.lastIndex = j + 1;
    if (/\n/.test(body)) continue;
    const ok = only ? only.indexOf(m[1]) >= 0 : isSimpleText(body);
    if (ok) all.push({ name: m[1], start: open + 1, end: j, value: body });
  }
  /* bei mehrfacher Definition gilt die letzte, die Reihenfolge der ersten Nennung bleibt */
  const order = [], last = {};
  all.forEach(f => { if (!(f.name in last)) order.push(f.name); last[f.name] = f; });
  return order.map(n => last[n]);
}
function setHeadField(doc, name, value, opts, only) {
  const f = headFields(doc.head, only).find(x => x.name === name);
  if (!f) return false;
  let v = String(value).replace(/\r?\n/g, ' ');
  if (opts && opts.autoEscape) v = escSpecial(v);
  doc.head = doc.head.slice(0, f.start) + v + doc.head.slice(f.end);
  return true;
}


/* ---------- Schriftgröße des Dateinamens im Seitenkopf ---------- */
function nameMacros(head) {
  const names = ['jobname'];
  head.split('\n').forEach(l => {
    if (/^\s*%/.test(l)) return;
    const m = /\\(?:re)?newcommand\*?\s*\{\\([A-Za-z@]+)\}.*\\jobname/.exec(l);
    if (m && names.indexOf(m[1]) < 0) names.push(m[1]);
  });
  return names;
}
function findNameSize(head) {
  const lines = head.split('\n');
  let off = 0;
  for (const l of lines) {
    const code = stripComment(l);
    for (const nm of nameMacros(head)) {
      if (/\\(?:re)?newcommand/.test(code)) continue;
      const re = new RegExp('(\\\\fontsize\\{)([0-9.]+)(pt)?(\\}\\{)([0-9.]+)(pt)?(\\}\\s*\\\\selectfont\\s*(?:\\\\textbf\\{)?\\\\' + nm + '\\b)');
      const m = re.exec(code);
      if (m) return { start: off + m.index, len: m[0].length, size: parseFloat(m[2]), base: parseFloat(m[5]), unit: m[3] || '', unit2: m[6] || '', pre: m[1], mid: m[4], post: m[7] };
    }
    off += l.length + 1;
  }
  return null;
}
function headheightCm(head) {
  const m = /headheight\s*=\s*([0-9.]+)\s*(cm|mm|pt)/.exec(head);
  if (!m) return null;
  const v = parseFloat(m[1]);
  return { m, cm: m[2] === 'cm' ? v : (m[2] === 'mm' ? v / 10 : v * 0.0351464) };
}
/* Setzt die Schriftgröße (pt). Der Zeilenabstand behält sein Verhältnis. Die Kopfhöhe wird nur erhöht, wenn die Schrift sonst nicht mehr passt. */
function setNameSize(doc, size) {
  const f = findNameSize(doc.head);
  if (!f) return null;
  if (!doc.nameMeta) doc.nameMeta = { ratio: f.base / f.size, hh: (headheightCm(doc.head) || {}).cm };
  const sz = Math.max(6, Math.min(96, size));
  const base = Math.round(sz * doc.nameMeta.ratio * 2) / 2;
  const rep = f.pre + fmtCm(sz) + f.unit + f.mid + fmtCm(base) + f.unit2 + f.post;
  doc.head = doc.head.slice(0, f.start) + rep + doc.head.slice(f.start + f.len);
  let note = '';
  const hh = headheightCm(doc.head);
  if (hh && doc.nameMeta.hh != null) {
    const need = Math.ceil((base * 0.0351464 + 0.2) * 10) / 10;
    const want = Math.max(doc.nameMeta.hh, need);
    const wantTxt = fmtCm(want) + 'cm';
    if (Math.abs(want - hh.cm) > 0.001) {
      doc.head = doc.head.replace(/(headheight\s*=\s*)[0-9.]+\s*(?:cm|mm|pt)/, (a, b) => b + wantTxt);
    }
    if (want > doc.nameMeta.hh + 0.001) note = 'Kopfhöhe auf ' + fmtCm(want).replace('.', ',') + ' cm erhöht, damit die Schrift hineinpasst.';
  }
  return { size: sz, note };
}

if (typeof module !== 'undefined') {
  module.exports = { tokenizeLine, parseTex, serialize, serializeFile, escSpecial, opInsertBelow, opDuplicate, opRemove, opMove,
    opMoveRelative, opBulk, opSetRaw, definedMacros, unitMacro, templateOf, themeMacro, blocksOf, opBlockMove, opBlockDuplicate, opBlockRemove, opInsertTypeAfterBlock, opInsertType, findNameSize, setNameSize, opInsertImage, opSetImg, imgLine, isContent, lineTypes, cloneUnits, hasFields, isBlankUnit, rawOfUnit, checkDoc, findImages, braceDelta, bodyOut, unitOut, segOut, headFields, setHeadField };
}