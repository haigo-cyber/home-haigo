"""Testlauf für Seifferts Text (ohne Bildschirm):  QT_QPA_PLATFORM=offscreen python tests/run_tests.py
Benötigt für einzelne Prüfungen pdflatex und LibreOffice (fehlen sie, werden die Prüfungen übersprungen)."""
import os
import shutil
import subprocess
import sys
import tempfile

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from PySide6.QtCore import QEventLoop, QTimer
from PySide6.QtGui import QColor, QImage, QTextCursor
from PySide6.QtWidgets import QApplication

app = QApplication([])
from seiffert_text.app import MainWindow, VIEW_MD, VIEW_RICH, VIEW_TEX
from seiffert_text.builder import build_document
from seiffert_text.latex_in import parse_latex
from seiffert_text.latex_out import export_latex
from seiffert_text.odt_out import write_odt
from seiffert_text.readers import find_soffice, read_any

TMP = tempfile.mkdtemp(prefix="st-test-")
import seiffert_text.app as _app_mod
_app_mod.CONF_DIR = TMP                       # die Einstellungen des Benutzers bleiben unberührt
_app_mod.CONF_FILE = os.path.join(TMP, "settings.json")
OK = FAIL = SKIP = 0


def check(name, cond, extra=""):
    global OK, FAIL
    if cond:
        OK += 1
    else:
        FAIL += 1
        print("FEHLER:", name, extra)


def body(t):
    return t[t.index("\\begin{document}"):]


def pump(ms=200):
    l = QEventLoop()
    QTimer.singleShot(ms, l.quit)
    l.exec()


SRC = r"""\section{Titel}
\subsection*{Ohne Nummer}
Text mit \textbf{fett}, \emph{kursiv}, \underline{unter}, x\textsuperscript{2}, \texttt{Code} und \href{https://example.org}{Link}\footnote{Fußnote 50\%.}.
Neue Zeile\\
nach Umbruch, M\"uller und $a^2+b^2$.

\begin{itemize}
\item Eins
\item Zwei
 \begin{enumerate}
 \item A
 \item B
 \end{enumerate}
\item Drei
\end{itemize}

\begin{center}
\begin{tabular}{|l|l|}
\hline
x & y \\
\hline
\multicolumn{2}{|l|}{Verbunden} \\
\hline
1 & 2 \\
\hline
\end{tabular}
\end{center}
\begin{quote}Ein Zitat\end{quote}
\begin{verbatim}
print("hi")
\end{verbatim}
\[ E = mc^2 \]
\begin{figure}[h]\caption{Unbekannt}\end{figure}
"""

# 1. LaTeX -> Dokument -> LaTeX ist stabil
pre, blocks = parse_latex(SRC)
doc = build_document(blocks)
t1, _ = export_latex(doc, pre)
pre2, b2 = parse_latex(t1)
t2, _ = export_latex(build_document(b2), pre2)
check("LaTeX-Rundlauf stabil", t1 == t2)
check("Rohtext bleibt (Formel, figure)", "\\[ E = mc^2 \\]" in t1 and "\\caption{Unbekannt}" in t1)
check("Fußnote bleibt", "\\footnote{Fußnote 50\\%.}" in t1)
check("Umlaut umgewandelt", "Müller" in t1)

# 2. ODT: schreiben, lesen, gleiche LaTeX-Ausgabe
write_odt(doc, os.path.join(TMP, "a.odt"))
r = read_any(os.path.join(TMP, "a.odt"))
t3, _ = export_latex(build_document(r.blocks), pre)
check("ODT-Rundlauf gleich", body(t3) == body(t1), "\n".join(__import__("difflib").unified_diff(body(t1).splitlines(), body(t3).splitlines(), lineterm="")))

# 3. Fremdformate über LibreOffice erzeugen und lesen
if find_soffice():
    for ext in ("docx", "doc", "rtf"):
        subprocess.run([find_soffice(), "-env:UserInstallation=file:///tmp/st-lo", "--headless", "--convert-to", ext,
                        "--outdir", TMP, os.path.join(TMP, "a.odt")], capture_output=True, timeout=240)
        p = os.path.join(TMP, "a." + ext)
        if os.path.exists(p):
            tt, _ = export_latex(build_document(read_any(p).blocks))
            check("%s: Überschrift, fett, Liste, Tabelle" % ext, all(k in tt for k in
                  ("\\section{Titel}", "\\textbf{fett}", "\\begin{itemize}", "\\begin{tabular}", "\\multicolumn{2}")))
        else:
            check("%s erzeugt" % ext, False)
else:
    SKIP += 1

# 4. Tabellenkalkulation
try:
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Umsatz"
    ws.append(["Monat", "Betrag"])
    ws.append(["Jan", 1234.5])
    ws["B2"].number_format = '#,##0.00 "€"'
    wb.save(os.path.join(TMP, "t.xlsx"))
    tt, _ = export_latex(build_document(read_any(os.path.join(TMP, "t.xlsx")).blocks))
    check("xlsx: Blatt und Zahlenformat", "\\subsection{Umsatz}" in tt and "1.234,50 €" in tt)
    if find_soffice():
        for ext in ("ods", "xls"):
            subprocess.run([find_soffice(), "-env:UserInstallation=file:///tmp/st-lo", "--headless", "--convert-to", ext,
                            "--outdir", TMP, os.path.join(TMP, "t.xlsx")], capture_output=True, timeout=240)
            tt, _ = export_latex(build_document(read_any(os.path.join(TMP, "t." + ext)).blocks))
            check(ext + ": Tabelle", "\\begin{tabular}" in tt and "Jan" in tt)
except ImportError:
    SKIP += 1

# 5. Oberfläche: Ansichten, Umwandlung, Übersetzen
w = MainWindow()
w.show()
w.rich.textCursor().insertText("Hallo")
w.set_para(1)
w.set_view(VIEW_MD)
check("Markdown aus Formatiert", w.md_edit.toPlainText().startswith("# Hallo"))
w.md_edit.setPlainText("# Neu\n\nText *kursiv*\n\n- a\n- b\n")
w.set_view(VIEW_TEX)
check("LaTeX aus Markdown", "\\section{Neu}" in w.tex_edit.toPlainText() and "\\textit{kursiv}" in w.tex_edit.toPlainText())
w.tex_edit.setPlainText(w.tex_edit.toPlainText().replace("Text", "Text $x^2$ \\newpage"))
w.set_view(VIEW_RICH)
w.set_view(VIEW_TEX)
check("Rohtext bleibt über Ansichtswechsel", "$x^2$" in w.tex_edit.toPlainText() and "\\newpage" in w.tex_edit.toPlainText())
if shutil.which("pdflatex"):
    w.compile()
    for _ in range(100):
        pump(300)
        if w.proc is None:
            break
    check("Übersetzen ergibt PDF", os.path.exists(os.path.join(w.work, "main.pdf")), w.log.toPlainText()[:300])
else:
    SKIP += 1
for ext in (".odt", ".md", ".tex"):
    check("Speichern " + ext, w.save_to(os.path.join(TMP, "u" + ext)) and os.path.getsize(os.path.join(TMP, "u" + ext)) > 20)
w.modified = False
w.close()
w2 = MainWindow()
w2.open_file(os.path.join(TMP, "u.tex"))
check("tex geöffnet in LaTeX-Ansicht", w2.view == VIEW_TEX and w2.path.endswith("u.tex"))
w2.open_file(os.path.join(TMP, "u.md"))
check("md geöffnet in Markdown-Ansicht", w2.view == VIEW_MD)
w2.open_file(os.path.join(TMP, "u.odt"))
check("odt geöffnet in formatierter Ansicht", w2.view == VIEW_RICH)
if os.path.exists(os.path.join(TMP, "a.docx")):
    w2.open_file(os.path.join(TMP, "a.docx"))
    check("docx wird als LaTeX gezeigt", w2.view == VIEW_TEX and w2.path is None)
w2.modified = False
w2.close()

# 6. Tabs, Farben, Änderungen von außen, TeXstudio
import stat
import time
from PySide6.QtWidgets import QFileDialog, QMessageBox

_orig = {k: getattr(QMessageBox, k) for k in ("question", "warning", "exec", "clickedButton")}
asked = []
QMessageBox.warning = staticmethod(lambda *a, **k: asked.append(("warning", a[2:])) or QMessageBox.StandardButton.Ok)
QMessageBox.question = staticmethod(lambda *a, **k: asked.append(("question", a[2:])) or QMessageBox.StandardButton.Yes)
QMessageBox.exec = lambda self: 0
QMessageBox.clickedButton = lambda self: self.buttons()[0] if self.buttons() else None

ta = os.path.join(TMP, "t_a.tex")
tb = os.path.join(TMP, "t_b.md")
open(ta, "w", encoding="utf-8").write("\\section{Eins}\nText A\n")
open(tb, "w", encoding="utf-8").write("# Zwei\n\nText B\n")
w = MainWindow()
w.show()
w.open_file(ta)
check("Tab: erste Datei nutzt den leeren Tab", w.tabbar.count() == 1 and w.path == ta)
w.open_file(tb)
check("Tab: zweite Datei in neuem Tab", w.tabbar.count() == 2 and w.path == tb)
cols = [w._tab_color_at(i) for i in range(2)]
check("Tab: verschiedene Farben", cols[0] and cols[1] and cols[0] != cols[1], str(cols))
w.open_file(ta)
check("Tab: schon offene Datei wird nur aktiviert", w.tabbar.count() == 2 and w.path == ta and w.view == VIEW_TEX)
w.tex_edit.appendPlainText("Zusatz in A")
check("Tab: Änderung markiert Tab", w.tabbar.tabText(w._index_of(w.cur)).startswith("* "))
w.open_file(tb)
check("Tab: Zwei hat eigenen Inhalt", w.path == tb and "Text B" in w.md_edit.toPlainText()
      and "Zusatz" not in w.md_edit.toPlainText() and not w.modified)
w.open_file(ta)
check("Tab: Änderung in A bleibt beim Wechsel erhalten",
      w.modified and "Zusatz in A" in w.tex_edit.toPlainText() and "Zusatz in A" in w.doc.toPlainText())
w.cmd_new()
w.rich.textCursor().insertText("Drittes")
check("Tab: neues Dokument", w.tabbar.count() == 3 and w.doc.toPlainText() == "Drittes" and w.path is None)
c3 = w.cur.color
w._set_tab_color(w.cur, "#112233")
check("Tab: Farbe änderbar", w._tab_color_at(2) == "#112233")
check("Tab: Dokumente sind getrennt", w.tabs[w.tabbar.tabData(0)].doc is not w.tabs[w.tabbar.tabData(1)].doc)
n = len(w.tabs)
QMessageBox.question = staticmethod(lambda *a, **k: asked.append(("question", a[2:])) or QMessageBox.StandardButton.Discard)
w.close_tab(w._index_of(w.cur))
check("Tab: ungespeicherten Tab schließen fragt und entfernt ihn", w.tabbar.count() == 2 and len(w.tabs) == 2
      and any(a[0] == "question" for a in asked))
# Farbe wird für dieselbe Datei gemerkt
w._set_tab_color(w.cur, "#abcdef")
cur_path = w.path
w.modified = False
w.close_tab(w._index_of(w.cur))
w.open_file(cur_path)
check("Tab: Farbe der Datei wird gemerkt", w.cur.color == "#abcdef", w.cur.color)
# Änderung von außen
w.open_file(tb)
w.modified = False
time.sleep(0.05)
open(tb, "w", encoding="utf-8").write("# Zwei neu\n\nText B neu\n")
pump(1200)
check("Außenänderung: unveränderter Tab wird neu geladen", "Zwei neu" in w.md_edit.toPlainText()
      and "Zwei neu" in w.doc.toPlainText() and not w.modified)
w.open_file(ta)                                   # A hat ungespeicherte Änderung
asked.clear()
QMessageBox.question = staticmethod(lambda *a, **k: asked.append(("question", a[2:])) or QMessageBox.StandardButton.No)
time.sleep(0.05)
open(ta, "w", encoding="utf-8").write("\\section{Fremd}\nVon außen\n")
pump(1200)
check("Außenänderung: bei eigenen Änderungen wird gefragt und bei Nein behalten",
      any("anderen Programm" in str(a) for a in asked) and "Zusatz in A" in w.tex_edit.toPlainText() and w.modified)
QMessageBox.question = staticmethod(lambda *a, **k: asked.append(("question", a[2:])) or QMessageBox.StandardButton.Yes)
w.save_to(ta)                                     # eigener Speichervorgang darf nichts auslösen
asked.clear()
pump(1200)
check("Außenänderung: eigenes Speichern löst keine Rückfrage aus", not asked)
# Änderung in einem Hintergrund-Tab wird beim Aktivieren übernommen
w.open_file(tb)
time.sleep(0.05)
open(ta, "w", encoding="utf-8").write("\\section{Hinten}\nGeändert im Hintergrund\n")
pump(1200)
w.open_file(ta)
pump(200)
check("Außenänderung: Hintergrund-Tab wird beim Wechsel neu geladen", "Hinten" in w.tex_edit.toPlainText(),
      w.tex_edit.toPlainText()[:60])
# TeXstudio
fake = os.path.join(TMP, "fake_texstudio.sh")
argf = os.path.join(TMP, "args.txt")
open(fake, "w").write('#!/bin/sh\nprintf "%s\\n" "$@" > ' + argf + '\n')
os.chmod(fake, os.stat(fake).st_mode | stat.S_IEXEC)
w.settings["texstudio_path"] = fake
w.open_file(ta)
w.tex_edit.setPlainText("\\section{A}\nzweite\ndritte Zeile\n")
c = w.tex_edit.textCursor()
c.setPosition(w.tex_edit.document().findBlockByNumber(2).position())
w.tex_edit.setTextCursor(c)
w.cmd_texstudio()
for _ in range(30):
    pump(100)
    if os.path.exists(argf):
        break
got = open(argf).read().split() if os.path.exists(argf) else []
check("TeXstudio: Aufruf mit Zeile und Datei", got == ["--line", "3", ta], str(got))
check("TeXstudio: Änderungen wurden vorher gespeichert", "dritte Zeile" in open(ta, encoding="utf-8").read() and not w.modified)
os.remove(argf)
# Dokument ohne .tex-Pfad: wird als .tex gespeichert
w.cmd_new()
w.rich.textCursor().insertText("Aus neuem Dokument")
target = os.path.join(TMP, "aus_neu.tex")
_gs = QFileDialog.getSaveFileName
QFileDialog.getSaveFileName = staticmethod(lambda *a, **k: (target, ""))
w.cmd_texstudio()
QFileDialog.getSaveFileName = _gs
for _ in range(30):
    pump(100)
    if os.path.exists(argf):
        break
got = open(argf).read().split() if os.path.exists(argf) else []
check("TeXstudio: Dokument ohne Pfad wird als .tex gespeichert und geöffnet",
      got and got[-1] == target and os.path.exists(target) and "Aus neuem Dokument" in open(target, encoding="utf-8").read()
      and w.path == target, str(got))
# TeXstudio nicht vorhanden
os.remove(argf)
w.settings["texstudio_path"] = ""
_path = os.environ.get("PATH", "")
os.environ["PATH"] = "/nonexistent"
QMessageBox.clickedButton = lambda self: None
w.cmd_texstudio()
os.environ["PATH"] = _path
pump(300)
check("TeXstudio: fehlendes Programm startet nichts", not os.path.exists(argf))
# misslungenes Öffnen hinterlässt keinen leeren Tab
bad = os.path.join(TMP, "kaputt.docx")
open(bad, "wb").write(b"kein zip")
before = w.tabbar.count()
from seiffert_text.readers import ReaderError
_ra = _app_mod.read_any
def _fail(path, *a, **k):
    raise ReaderError("Testfehler")
_app_mod.read_any = _fail
w.open_file(bad)
_app_mod.read_any = _ra
check("Tab: misslungenes Öffnen hinterlässt keinen Tab", w.tabbar.count() == before and w.path != bad)

# ---- PDF in einem Tab (seit 0.15)
from seiffert_text.pdf_tools import available as _pdf_ok
if _pdf_ok():
    import fitz
    from PySide6.QtCore import Qt as _Qt
    from PySide6.QtTest import QTest as _QTest
    pdfp = os.path.join(TMP, "tab.pdf")
    _d = fitz.open()
    _d.new_page().insert_text((72, 72), "Hallo PDF")
    _d.save(pdfp)
    _d.close()
    mdp = os.path.join(TMP, "vorher.md")
    open(mdp, "w", encoding="utf-8").write("# Vorher\n\nText")
    wp = MainWindow()
    wp.show()
    wp.activateWindow()
    _QTest.qWaitForWindowActive(wp)
    wp.open_file(mdp)
    n_child = len(wp.children_windows)
    wp.open_file(pdfp)
    pump(100)
    check("PDF-Tab: öffnet als Tab nach einer anderen Datei", wp.tabbar.count() == 2 and wp.cur_pdf is not None)
    check("PDF-Tab: kein eigenes Fenster", len(wp.children_windows) == n_child)
    check("PDF-Tab: Tab zeigt Dateinamen", wp.tabbar.tabText(1) == "tab.pdf")
    check("PDF-Tab: PDF-Menü statt Hauptmenü", not wp.menuBar().isVisible() and wp.cur_pdf.widget.menuBar().isVisible())
    wp.open_file(pdfp)
    check("PDF-Tab: dieselbe Datei öffnet keinen zweiten Tab", wp.tabbar.count() == 2)
    wp.tabbar.setCurrentIndex(0)
    pump(50)
    check("PDF-Tab: Wechsel zum Textdokument stellt Menü und Text wieder her",
          wp.cur_pdf is None and wp.menuBar().isVisible() and wp.md_edit.toPlainText().startswith("# Vorher") and wp.path == mdp)
    wp.tabbar.setCurrentIndex(1)
    pump(50)
    pw = wp.cur_pdf.widget
    _hit = []
    pw.a_save.triggered.disconnect()
    pw.a_save.triggered.connect(lambda: _hit.append(1))
    pw.scroll.setFocus()
    _QTest.keyClick(pw.scroll, _Qt.Key.Key_S, _Qt.KeyboardModifier.ControlModifier)
    pump(50)
    check("PDF-Tab: Strg+S gehört dem PDF", _hit == [1])
    _QTest.keyClick(pw.scroll, _Qt.Key.Key_W, _Qt.KeyboardModifier.ControlModifier)
    pump(50)
    check("PDF-Tab: Strg+W schließt den Tab, Textdokument bleibt", wp.tabbar.count() == 1 and wp.cur_pdf is None and wp.path == mdp)
    _hit.clear()
    wp.a_save.triggered.disconnect()
    wp.a_save.triggered.connect(lambda: _hit.append(2))
    wp.rich.setFocus()
    _QTest.keyClick(wp.rich, _Qt.Key.Key_S, _Qt.KeyboardModifier.ControlModifier)
    pump(50)
    check("PDF-Tab: Strg+S gehört nach dem Schließen wieder dem Text", _hit == [2])
    wp.open_file(pdfp)
    wp.cur_pdf.widget.ed.modified = True
    wp.cur_pdf.widget.update_title()
    check("PDF-Tab: Änderung zeigt Stern im Tab", wp.tabbar.tabText(1).startswith("* "))
    check("PDF-Tab: Schließen mit Rückfrage (Verwerfen)", wp.close_tab(1) and wp.tabbar.count() == 1)
    wp.open_file(pdfp)
    wp.cmd_new()
    check("PDF-Tab: Neues Dokument aus dem PDF-Tab", wp.cur_pdf is None and wp.tabbar.count() == 3)
    for _i in range(wp.tabbar.count() - 1, -1, -1):
        wp.close_tab(_i)
    check("PDF-Tab: nach Schließen aller bleibt ein leeres Textdokument", wp.tabbar.count() == 1 and wp.cur_pdf is None)
    wp.modified = False
    wp.close()
else:
    SKIP += 1
    print("PyMuPDF fehlt: PDF-Tab-Prüfungen übersprungen")


# ---- PDF-Import nach LaTeX: Brüche, Ausfüllstriche, Seitenzahl (seit 0.16)
if _pdf_ok():
    import fitz
    fp = os.path.join(TMP, "arbeitsblatt.pdf")
    _d = fitz.open()
    _pg = _d.new_page()
    _pg.insert_text((72, 100), "Berechne", fontsize=11)
    _pg.insert_text((135, 94), "3", fontsize=8)
    _pg.draw_line((132, 97.5), (142, 97.5), width=0.5)
    _pg.insert_text((135, 106), "4", fontsize=8)
    _pg.insert_text((148, 100), "+ 2 Stück", fontsize=11)
    _pg.insert_text((72, 160), "Name:", fontsize=11)
    _pg.draw_line((110, 161), (210, 161), width=0.6)
    _pg.insert_text((300, 800), "1", fontsize=10)
    _pg.insert_text((72, 220), "Dies ist ein Absatz mit Text, der unterstrichen werden soll.", fontsize=11)
    _pg.draw_line((72, 222), (140, 222), width=0.5)
    _d.save(fp)
    _d.close()
    wi = MainWindow()
    wi.open_file(fp, convert=True, to_latex=True)
    pump(100)
    tx = wi.current_latex()
    check("PDF-Import: Bruch wird zu \\frac", "\\(\\frac{3}{4}\\)" in tx, tx[tx.index("\\begin{document}"):][:300])
    check("PDF-Import: Bruch steht an der richtigen Stelle im Satz", "Berechne \\(\\frac{3}{4}\\) + 2 Stück" in tx)
    check("PDF-Import: Ausfüllstrich wird zu \\underline{\\hspace}", "Name: \\underline{\\hspace{" in tx)
    check("PDF-Import: unterstrichener Text ist keine Lücke und kein Bruch", tx.count("\\hspace") == 1 and tx.count("\\frac") == 1)
    check("PDF-Import: freistehende Seitenzahl entfällt", "\\begin{flushright}\n1\n" not in tx and "\n1\n" not in tx.split("\\begin{document}")[1])
    wi.modified = False
    for _t in list(wi.tabs.values()):
        _t.s["modified"] = False
    wi.close()

# ---- PDF-Import: Kopf-/Fußzeile, Papier, Ränder, Farbe, Größe (seit 0.17)
if _pdf_ok():
    import fitz
    fp2 = os.path.join(TMP, "bericht.pdf")
    _d = fitz.open()
    for _n in range(2):
        _pg = _d.new_page(width=595.28, height=841.89)
        _pg.insert_text((90, 50), "Firma Muster GmbH", fontsize=9)
        _pg.insert_text((90, 130), "Titel %d" % _n, fontsize=20, color=(0.8, 0, 0))
        for _k in range(8):
            _pg.insert_text((90, 170 + 15 * _k), "Textzeile %d auf Seite %d mit etwas Inhalt zum Lesen." % (_k, _n), fontsize=11)
        _pg.insert_text((290, 800), "%d" % (_n + 1), fontsize=9)
    _d.save(fp2)
    _d.close()
    wi = MainWindow()
    wi.open_file(fp2, convert=True, to_latex=True)
    pump(100)
    tx = wi.current_latex()
    check("PDF-Import 0.17: Papier A4 und Ränder aus dem PDF", "a4paper" in tx and "left=31.8mm" in tx, tx[:600])
    check("PDF-Import 0.17: Kopfzeile als fancyhdr, nicht im Text", "\\fancyhead" in tx and "Firma Muster GmbH" in tx.split("\\begin{document}")[0]
          and "Firma Muster GmbH" not in tx.split("\\begin{document}")[1])
    check("PDF-Import 0.17: Seitenzahl als \\thepage in der Fußzeile", "\\fancyfoot" in tx and "\\thepage" in tx)
    check("PDF-Import 0.17: Schriftfarbe der Überschrift bleibt erhalten", "textcolor" in tx or "color[HTML]{CC0000}" in tx or "CC0000" in tx.upper())
    check("PDF-Import 0.17: Grundschriftgröße und Zeilenabstand werden gesetzt", "\\@setfontsize\\normalsize{11" in tx)
    wi.modified = False
    for _t in list(wi.tabs.values()):
        _t.s["modified"] = False
    wi.close()

# ---- Ansicht Coding (0.19) --------------------------------------------------------------------------
if True:
    from seiffert_text import app as _A
    from PySide6.QtCore import Qt as _Qt
    from PySide6.QtTest import QTest as _QT

    def _fm(b):
        return [(b.text()[f.start:f.start + f.length], f.format.foreground().color().name())
                for f in b.layout().formats() if f.format.foreground().style() != 0]

    cdir = os.path.join(TMP, "coding")
    os.makedirs(cdir, exist_ok=True)
    srcs = {"a.py": b'import os\n@deco\nclass A:\n    def f(self):\n        return "x"  # k\n',
            "crlf.js": b'// c\r\nvar a = `x\r\ny`;\r\n', "latin.py": b'caf\xe9 = 1\n',
            "t.html": b'<p class="a">&amp;</p>\n<!-- c\n -->\n', "s.tex": b"\\section{A}\n% k\n$x$\n"}
    for n, d in srcs.items():
        with open(os.path.join(cdir, n), "wb") as f:
            f.write(d)
    wc = MainWindow()
    wc.open_file(os.path.join(cdir, "a.py"))
    pump(100)
    b = wc.tex_edit.document()
    check("Coding 0.19: Python-Datei öffnet in der Ansicht Coding als Code-Dokument",
          wc.view == _A.VIEW_CODE and wc.kind == "code" and wc.current_lang() == "python" and not wc.modified)
    check("Coding 0.19: Schlüsselwörter, Namen, Zeichenketten, Kommentare farbig",
          ("class", "#8a2fa8") in _fm(b.findBlockByNumber(2)) and ("A", "#1a5fb4") in _fm(b.findBlockByNumber(2))
          and ("@deco", "#9a5b00") in _fm(b.findBlockByNumber(1)) and ('"x"', "#2e7d32") in _fm(b.findBlockByNumber(4))
          and ("# k", "#7a7a7a") in _fm(b.findBlockByNumber(4)), str(_fm(b.findBlockByNumber(4))))
    wc.set_view(_A.VIEW_RICH)
    check("Coding 0.19: Code-Datei wird nie in ein Dokument umgewandelt (Ansicht bleibt Coding)", wc.view == _A.VIEW_CODE)
    check("Coding 0.19: PDF-Vorschau-Seite bei Code-Dateien ausgeblendet", not wc.tex_right.isVisible())
    for n in ("a.py", "crlf.js", "latin.py", "t.html"):
        fp = os.path.join(cdir, n)
        wc.open_file(fp)
        pump(60)
        wc.save_to(fp)
        check("Coding 0.19: unverändert gespeichert ist byteidentisch (%s)" % n, open(fp, "rb").read() == srcs[n])
    wc.open_file(os.path.join(cdir, "latin.py"))
    ed = wc.tex_edit
    cu = ed.textCursor()
    cu.movePosition(cu.MoveOperation.End)
    ed.setTextCursor(cu)
    ed.insertPlainText("x = 2\n")
    wc.save_to(os.path.join(cdir, "latin.py"))
    check("Coding 0.19: Kodierung (Windows-1252) bleibt beim Speichern", open(os.path.join(cdir, "latin.py"), "rb").read() == b"caf\xe9 = 1\nx = 2\n")
    wc.open_file(os.path.join(cdir, "t.html"))
    pump(60)
    f = _fm(wc.tex_edit.document().findBlockByNumber(0))
    check("Coding 0.19: HTML-Tags, Attribute, Werte, Entitäten", ("<p", "#a6192e") in f and ("class", "#9a5b00") in f
          and ('"a"', "#2e7d32") in f and ("&amp;", "#b35900") in f, str(f))
    check("Coding 0.19: HTML-Kommentar über mehrere Zeilen",
          _fm(wc.tex_edit.document().findBlockByNumber(2)) == [(" -->", "#7a7a7a")])
    wc.set_code_lang("python")
    ed = wc.tex_edit
    ed.setFocus()
    ed.setPlainText("if x:\ny\n")
    cu = ed.textCursor()
    cu.setPosition(5)
    ed.setTextCursor(cu)
    _QT.keyClick(ed, _Qt.Key.Key_Return)
    check("Coding 0.19: Enter nach Doppelpunkt rückt ein", ed.toPlainText().split("\n")[1] == "    ")
    ed.selectAll()
    _QT.keyClick(ed, _Qt.Key.Key_Slash, _Qt.KeyboardModifier.ControlModifier)
    check("Coding 0.19: Strg+/ kommentiert alle markierten Zeilen", ed.toPlainText().startswith("# if x:"))
    wc.open_file(os.path.join(cdir, "s.tex"))
    pump(100)
    wc.set_view(_A.VIEW_CODE)
    pump(60)
    f = _fm(wc.tex_edit.document().findBlockByNumber(0))
    check("Coding 0.19: LaTeX in der Ansicht Coding farbig, Dokument unverändert", wc.kind == "tex" and not wc.modified
          and ("\\section", "#0b4f9c") in f, str(f))
    wc.set_view(_A.VIEW_RICH)
    wc.set_view(_A.VIEW_CODE)
    check("Coding 0.19: Wechsel Coding und Formatiert und zurück behält den LaTeX-Text",
          "\\section{A}" in wc.tex_edit.toPlainText())
    wc.modified = False
    for _t in list(wc.tabs.values()):
        _t.s["modified"] = False
    wc.close()

# ---- PDF-Quelltext gefärbt (0.20) --------------------------------------------------------------------
if HAVE_FITZ if "HAVE_FITZ" in globals() else True:
    try:
        import fitz as _fz
        from seiffert_text.pdf_source import PdfSourceWindow as _PSW
        _d = _fz.open()
        _p = _d.new_page()
        _p.insert_text((72, 100), "Hallo Welt (Test)", fontsize=14)
        _fp = os.path.join(TMP, "farbe.pdf")
        _d.save(_fp)
        _d.close()
        _ps = _PSW(_fp)
        _ps.show()
        pump(100)

        def _fp_(b):
            return [(b.text()[f.start:f.start + f.length], f.format.foreground().color().name())
                    for f in b.layout().formats() if f.format.foreground().style() != 0]
        _doc = _ps.edit.document()
        _all = {}
        _b = _doc.firstBlock()
        while _b.isValid():
            for _t, _c in _fp_(_b):
                _all.setdefault(_t, set()).add(_c)
            _b = _b.next()
        check("PDF-Quelltext 0.20: Objektgrenzen, Namen und Verweise farbig",
              "1 0 obj" in _all and "endobj" in _all and "/Type" in _all and any(k.endswith(" R") for k in _all), str(list(_all)[:12]))
        check("PDF-Quelltext 0.20: Textbefehle im Seiteninhalt farbig (BT, Tf, Tj)",
              all(k in _all for k in ("BT", "Tf", "ET")) and any(k.startswith("(Hallo") for k in _all) , str([k for k in _all][-12:]))
        check("PDF-Quelltext 0.20: Färben gilt nicht als Änderung", not _doc.isModified())
        _ps.close()
    except ImportError:
        pass

from PySide6.QtTest import QTest as _QT
from PySide6.QtGui import QAction
w.show(); w.activateWindow(); app.processEvents()
from PySide6.QtCore import Qt as _Qt
_f0 = w.isFullScreen()
_QT.keyClick(w.rich, _Qt.Key_F11); app.processEvents()
_f1 = w.isFullScreen()
_QT.keyClick(w.rich, _Qt.Key_F11); app.processEvents()
check("Vollbild 0.21: F11 schaltet Vollbild ein und wieder aus", (not _f0) and _f1 and not w.isFullScreen())
check("Vollbild 0.21: Menüpunkt Ansicht, Vollbild vorhanden", any(a.shortcut().toString() == "F11" for a in w.findChildren(QAction)))

# ---- 0.22: PDF-Format im Dialog Zeile ändern, Zwei-Fenster-Ansicht -------------------------------------
try:
    import pymupdf as _mu
except ImportError:
    _mu = None
if _mu is not None:
    import hashlib
    from PySide6.QtWidgets import QDialog as _QD, QLineEdit as _QLE, QPlainTextEdit as _QPT
    from seiffert_text.pdf_tools import PdfEditor as _PE
    from seiffert_text.pdf_window import PdfWindow as _PW, FormatRow as _FR

    _src = os.path.join(TMP, "fmt_in.pdf")
    _d = _mu.open()
    _pg = _d.new_page()
    _pg.insert_text((72, 100), "Titel in Times", fontsize=14, fontname="tiro")
    _pg.insert_text((72, 140), "Zweite Zeile Helvetica", fontsize=11, fontname="helv")
    _pg.insert_text((72, 180), "Dritte Zeile bleibt", fontsize=11, fontname="helv")
    _d.save(_src)
    _d.close()

    def _spans(doc):
        out = {}
        for b in doc[0].get_text("dict")["blocks"]:
            for ln in b.get("lines", []):
                for sp in ln["spans"]:
                    out[sp["text"]] = (sp["font"], round(sp["size"], 1), sp["flags"], sp["color"])
        return out

    _e = _PE(_src)
    _ln = _e.line_at(0, 80, 96)
    _e.replace_line(0, _ln, "Neuer Titel", {"size": 20, "flags": 16 | 8, "color": 0xFF0000})
    _sp = _spans(_e.doc).get("Neuer Titel")
    check("PDF-Format 0.22: Schrift, Größe, fett und Farbe aus fmt", _sp is not None and "Mono" in _sp[0] and _sp[1] == 20.0
          and _sp[2] & 16 and _sp[3] == 0xFF0000, str(_sp))
    check("PDF-Format 0.22: andere Zeilen bleiben unverändert", _spans(_e.doc).get("Zweite Zeile Helvetica", ("",))[0] == "Helvetica")

    _w = _PW(_src)
    _w.show()
    _w.set_mode(1)

    def _drive(fn):
        def go():
            dlg = app.activeModalWidget()
            fn(dlg)
        QTimer.singleShot(250, go)
    seen = {}

    def _d1(dlg):
        seen["pre"] = dlg.findChild(_FR).value()
        dlg.findChild(_QLE).setText("Zweite Zeile NEU")
        r = dlg.findChild(_FR)
        r.kind.setCurrentIndex(1)
        r.size.setValue(16)
        r.bold.setChecked(True)
        r.ital.setChecked(True)
        r.rgb = 0x0000C0
        dlg.accept()
    _drive(_d1)
    _w.on_click(80 * _w.zoom, 136 * _w.zoom)
    _sp = _spans(_w.ed.doc).get("Zweite Zeile NEU")
    check("PDF-Format 0.22: Dialog ist mit den Werten der Zeile vorbelegt", seen["pre"]["size"] == 11.0 and seen["pre"]["flags"] & 30 == 0, str(seen))
    check("PDF-Format 0.22: Dialog setzt Serif, fett, kursiv, 16 pt, Blau",
          _sp is not None and "Serif" in _sp[0] and _sp[1] == 16.0 and _sp[2] & 16 and _sp[2] & 2 and _sp[3] == 0x0000C0, str(_sp))

    def _d2(dlg):
        r = dlg.findChild(_FR)
        seen["unchanged"] = not r.changed()
        r.rgb = 0x00AA00
        seen["changed"] = r.changed()
        dlg.accept()
    _drive(_d2)
    _w.on_click(80 * _w.zoom, 176 * _w.zoom)
    _sp = _spans(_w.ed.doc).get("Dritte Zeile bleibt")
    check("PDF-Format 0.22: nur die Farbe ändern (Text gleich) geht",
          seen["unchanged"] and seen["changed"] and _sp is not None and _sp[3] == 0x00AA00 and "Sans" in _sp[0], str(_sp))

    _n0 = len(_w.ed.undo)
    _drive(lambda dlg: dlg.accept())
    _w.on_click(80 * _w.zoom, 96 * _w.zoom)
    check("PDF-Format 0.22: OK ohne Änderung ändert nichts", len(_w.ed.undo) == _n0)

    _w.set_mode(2)

    def _d4(dlg):
        dlg.findChildren(_QPT)[0].setPlainText("Hinzu rot")
        r = dlg.findChild(_FR)
        r.rgb = 0xFF0000
        r.bold.setChecked(True)
        r.size.setValue(18)
        dlg.accept()
    _drive(_d4)
    _w.on_click(300 * _w.zoom, 300 * _w.zoom)
    _sp = _spans(_w.ed.doc).get("Hinzu rot")
    check("PDF-Format 0.22: Text hinzufügen mit Format", _sp is not None and _sp[1] == 18.0 and _sp[2] & 16 and _sp[3] == 0xFF0000, str(_sp))
    _w.ed.modified = False
    _w.close()

    # ---- Zwei Fenster (Referenzdatei rechts)
    _ref1 = os.path.join(TMP, "ref1.pdf")
    _d = _mu.open()
    _d.new_page().insert_text((72, 100), "Stichworte: Bruch, Zähler, Nenner", fontsize=14)
    _d.save(_ref1)
    _d.close()
    _ref2 = os.path.join(TMP, "ref2.md")
    open(_ref2, "w", encoding="utf-8").write("# Stichworte\n\n- **Bruch**: Teil vom Ganzen\n")
    _sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()
    _h1, _h2 = _sha(_ref1), _sha(_ref2)

    w.resize(1500, 800)
    w.show()
    pump(150)
    check("Zwei Fenster 0.22: Referenzfenster ist am Anfang zu", not w.ref_pane.isVisible() and not w.a_ref.isChecked())
    _calls = []
    _real_choose = w.ref_pane.choose
    w.ref_pane.choose = lambda: _calls.append(1)
    w.set_ref(True)
    pump(100)
    check("Zwei Fenster 0.22: F9 zeigt rechts das Fenster und fragt nach einer Datei",
          w.ref_pane.isVisible() and w.a_ref.isChecked() and len(_calls) == 1)
    _sz = w.main_split.sizes()
    check("Zwei Fenster 0.22: beide Hälften sind breit genug (kein Zwang durch die Schnellbearbeitung)",
          min(_sz) > 300 and w.minimumSizeHint().width() < 1100, str(_sz) + " " + str(w.minimumSizeHint().width()))
    w.ref_pane.choose = _real_choose
    check("Zwei Fenster 0.22: PDF wird angezeigt", w.ref_pane.open_file(_ref1) and w.ref_pane.kind == 1 and w.ref_pane.pdf_doc.pageCount() == 1)
    check("Zwei Fenster 0.22: Markdown wird angezeigt", w.ref_pane.open_file(_ref2) and w.ref_pane.kind == 2
          and "Bruch" in w.ref_pane.md_view.toPlainText())
    w.rich.moveCursor(QTextCursor.MoveOperation.End)
    w.rich.insertPlainText(" links getippt")
    pump(100)
    check("Zwei Fenster 0.22: links schreiben funktioniert weiter, Referenzdateien bleiben byteidentisch",
          w.modified and _sha(_ref1) == _h1 and _sha(_ref2) == _h2)
    w.ref_pane.closed.emit()
    check("Zwei Fenster 0.22: Schließen-Knopf des Fensters blendet es aus", not w.ref_pane.isVisible() and not w.a_ref.isChecked())
    w.set_ref(True)
    pump(50)
    check("Zwei Fenster 0.22: erneutes Einblenden behält die Datei", w.ref_pane.isVisible() and w.ref_pane.path == _ref2)
    w.set_ref(False)
    if find_soffice():
        _docx = os.path.join(TMP, "ref3.docx")
        _html = os.path.join(TMP, "ref3.html")
        open(_html, "w").write("<html><body><h1>Wort Stichworte</h1><p>Erster <b>Punkt</b></p></body></html>")
        subprocess.run([find_soffice(), "--headless", "--convert-to", "docx:MS Word 2007 XML", "--outdir", TMP, _html],
                       capture_output=True, timeout=120)
        if os.path.exists(_docx):
            _h3 = _sha(_docx)
            w.ref_pane.open_file(_docx)
            import time as _tm
            _t0 = _tm.time()
            while w.ref_pane.kind is None and _tm.time() - _t0 < 90:
                pump(200)
            check("Zwei Fenster 0.22: Word-Datei wird über LibreOffice als PDF angezeigt",
                  w.ref_pane.kind == 1 and w.ref_pane.pdf_doc.pageCount() >= 1 and _sha(_docx) == _h3)
        else:
            SKIP += 1
    else:
        SKIP += 1
    w.ref_pane.shutdown()
    w.set_ref(False)

# ---- 0.23: Formatvorlagen aus LaTeX-Vorgabe (ott, dotx), Verwaltung -----------------------------------
import json as _json
import zipfile as _zf
from seiffert_text import formatvorlage as _fv
from seiffert_text.fv_dialog import FormatvorlagenDialog as _FD
from PySide6.QtWidgets import QInputDialog as _QID

_FVTEX = r"""
\documentclass[11pt,a4paper]{article}
\usepackage[ngerman]{babel}
\usepackage[left=3cm,right=2cm,top=2.5cm,bottom=2cm]{geometry}
\usepackage{xcolor}
\definecolor{haupt}{HTML}{1F4E79}
\usepackage{helvet}
\renewcommand{\familydefault}{\sfdefault}
\usepackage{parskip}
\linespread{1.15}
\usepackage{titlesec}
\titleformat{\section}{\Large\bfseries\color{haupt}}{}{0pt}{}
\titlespacing*{\section}{0pt}{12pt}{6pt}
\titleformat{\subsection}{\large\bfseries\itshape}{}{0pt}{}
\usepackage{fancyhdr}
\pagestyle{fancy}
\fancyhf{}
\fancyhead[L]{Klasse 5b}
\fancyhead[R]{\today}
\fancyfoot[C]{Seite \thepage}
\renewcommand{\headrulewidth}{0.4pt}
\begin{document}
Text
\end{document}
"""
_sp = _fv.spec_from_latex(_FVTEX, "Klasse 5b")
check("Formatvorlage 0.23: Papier, Ränder und Grundgröße aus der LaTeX-Vorgabe",
      _sp["paper"] == [21.0, 29.7] and _sp["margins"] == {"top": 2.5, "bottom": 2.0, "left": 3.0, "right": 2.0}
      and abs(_sp["size"] - 10.95) < 0.01, str(_sp["margins"]))
check("Formatvorlage 0.23: Schrift (helvet als Standardschrift), Sprache, Absatzabstand statt Einzug",
      _sp["font"] == "Liberation Sans" and _sp["lang"] == "de-DE" and _sp["parskip"] > 0 and _sp["indent"] == 0)
check("Formatvorlage 0.23: Überschrift 1 mit Größe, fett und Farbe, Überschrift 2 kursiv",
      abs(_sp["headings"]["1"]["size"] - 14.4) < 0.01 and _sp["headings"]["1"]["bold"] and _sp["headings"]["1"]["color"] == "1F4E79"
      and _sp["headings"]["2"]["italic"] and abs(_sp["headings"]["1"]["before"] - 12 / 72.27 * 2.54) < 0.01)
check("Formatvorlage 0.23: Kopfzeile links und rechts, Datum, Linie; Fußzeile mit Seitenzahl",
      _sp["header"]["L"] == "Klasse 5b" and _sp["header"]["R"] == "{date}" and _sp["footer"]["C"] == "Seite {page}"
      and _sp["header_rule"] is True)
_sp2 = _fv.spec_from_latex(r"\documentclass[12pt]{report}\pagestyle{empty}\begin{document}\end{document}", "leer")
check("Formatvorlage 0.23: Standardwerte der Klasse (report: Überschrift 1 ist das Kapitel), keine Kopf-/Fußzeile bei empty",
      abs(_sp2["headings"]["1"]["size"] - 24.88) < 0.01 and _sp2["header"] is None and _sp2["footer"] is None
      and "Keine geometry-Angabe" in " ".join(_sp2["report"]))
_sp3 = _fv.spec_from_latex(r"\documentclass{article}\begin{document}\end{document}", "std")
check("Formatvorlage 0.23: ohne pagestyle gilt plain (Seitenzahl mittig unten)", _sp3["footer"] == {"L": "", "C": "{page}", "R": ""})
_sp4 = _fv.spec_from_latex(r"\documentclass{scrartcl}\usepackage{fontspec}\setmainfont{Carlito}\setkomafont{section}{\sffamily\Large\color{red}}"
                           r"\usepackage{tcolorbox}\begin{document}\end{document}", "koma")
check("Formatvorlage 0.23: fontspec, KOMA-Schrift für Überschriften, Bericht über Nicht-Übernommenes",
      _sp4["font"] == "Carlito" and _sp4["headings"]["1"]["family"] == "sans" and _sp4["headings"]["1"]["color"] == "FF0000"
      and "Kästen" in " ".join(_sp4["report"]))

_fvdir = os.path.join(TMP, "fvstore")
os.makedirs(_fvdir)
_fv.save_template(_sp, _fvdir)
_fv.save_template(_sp2, _fvdir)
check("Formatvorlage 0.23: Speichern und Auflisten der Vorlagen", [x["name"] for x in _fv.list_templates(_fvdir)] == ["Klasse 5b", "leer"])
check("Formatvorlage 0.23: Laden gibt dieselben Werte zurück", _fv.load_template("Klasse 5b", _fvdir) == _json.loads(_json.dumps(_sp)))

_ott = os.path.join(TMP, "v.ott")
_fv.write_ott(_sp, _ott)
with _zf.ZipFile(_ott) as _z:
    _names = _z.namelist()
    _st = _z.read("styles.xml").decode("utf-8")
    _mt = _z.read("mimetype").decode()
check("Formatvorlage 0.23: ODT-Vorlage hat den Vorlagen-Typ, mimetype zuerst",
      _names[0] == "mimetype" and _mt == "application/vnd.oasis.opendocument.text-template")
check("Formatvorlage 0.23: ODT-Vorlage enthält Seitenmaße, Ränder, Überschrift in Farbe, Kopf- und Fußzeile mit Seitenzahl",
      'fo:page-width="21.000cm"' in _st and 'fo:margin-left="3.000cm"' in _st and 'fo:color="#1F4E79"' in _st
      and "<style:header>" in _st and "<style:footer>" in _st and "text:page-number" in _st)

if find_soffice():
    _dx = os.path.join(TMP, "v.dotx")
    _fv.write_dotx(_sp, _dx)
    with _zf.ZipFile(_dx) as _z:
        _wd = _z.read("word/document.xml").decode("utf-8")
        _ws = _z.read("word/styles.xml").decode("utf-8")
        _wn = _z.namelist()
        _ct = _z.read("[Content_Types].xml").decode("utf-8")
    check("Formatvorlage 0.23: Word-Vorlage (dotx) mit A4, linkem Rand 3 cm, Überschrift-1-Farbe, Kopf- und Fußzeile",
          'w:w="11906"' in _wd and 'w:left="1701"' in _wd and "1F4E79" in _ws and any("header" in n for n in _wn)
          and any("footer" in n for n in _wn) and "template" in _ct, _ct[:300])
else:
    SKIP += 1

# ---- im Programm: neues Dokument aus Vorlage, Speichern, Vorschau, Anwenden, Dialog
w.fv_store = _fvdir
w.cmd_new() if False else None
w._fill_fv_new()
check("Formatvorlage 0.23: Menü „Neu aus Formatvorlage“ listet die Vorlagen", [a.text() for a in w.fv_new_menu.actions()][:2] == ["Klasse 5b", "leer"])
_ntab = len(w.tabs)
w.rich.setPlainText("besetzt")
w.new_from_format("Klasse 5b")
pump(100)
check("Formatvorlage 0.23: neues Dokument aus Vorlage öffnet einen Tab und merkt die Vorlage",
      len(w.tabs) == _ntab + 1 and w.fmt_spec and w.fmt_spec["name"] == "Klasse 5b" and not w.modified)
w.rich.setPlainText("Überschrift\n\nErster Absatz mit Text.\n\nZweiter Absatz.")
_c = QTextCursor(w.rich.document())
_c.movePosition(QTextCursor.MoveOperation.Start)
w.rich.setTextCursor(_c)
w.set_para(1)
pump(100)
_o = os.path.join(TMP, "mitvorlage.odt")
check("Formatvorlage 0.23: Speichern als ODT mit Vorlage", w.save_to(_o))
with _zf.ZipFile(_o) as _z:
    _ost = _z.read("styles.xml").decode("utf-8")
    _oct = _z.read("content.xml").decode("utf-8")
check("Formatvorlage 0.23: gespeichertes ODT trägt Ränder, Kopfzeile und echte Überschriftenformate",
      'fo:margin-left="3.000cm"' in _ost and "Klasse 5b" in _ost and 'text:style-name="Heading_20_1"' in _oct)
if find_soffice():
    _pd = os.path.join(TMP, "pdfv")
    subprocess.run([find_soffice(), "-env:UserInstallation=file:///tmp/st-lo", "--headless", "--convert-to", "pdf", "--outdir", _pd, _o],
                   capture_output=True, timeout=200)
    try:
        import pymupdf as _mu2
        _pg = _mu2.open(os.path.join(_pd, "mitvorlage.pdf"))[0]
        _lines = []
        for _b in _pg.get_text("dict")["blocks"]:
            for _l in _b.get("lines", []):
                _lines.append((_l["bbox"], _l["spans"][0]))
        _head = [x for x in _lines if "berschrift" in "".join(x[1]["text"] for _ in [0])]
        _hl = [x for x in _lines if x[1]["text"].startswith("Überschrift")]
        _body = [x for x in _lines if x[1]["text"].startswith("Erster")]
        check("Formatvorlage 0.23: PDF aus der Vorlage hat A4, 3 cm Rand links, blaue fette Überschrift in Sans, Kopfzeile",
              abs(_pg.rect.width / 28.3465 - 21.0) < 0.02 and _hl and abs(_hl[0][0][0] / 28.3465 - 3.0) < 0.05
              and "Bold" in _hl[0][1]["font"] and _hl[0][1]["color"] == 0x1F4E79 and abs(_hl[0][1]["size"] - 14.4) < 0.3
              and any(x[1]["text"] == "Klasse 5b" for x in _lines) and any(x[1]["text"].startswith("Seite") for x in _lines),
              str([(round(x[0][0] / 28.3465, 2), x[1]["font"], x[1]["text"][:12]) for x in _lines]))
    except ImportError:
        SKIP += 1
else:
    SKIP += 1
w.apply_format(None)
_o2 = os.path.join(TMP, "ohnevorlage.odt")
w.save_to(_o2)
with _zf.ZipFile(_o2) as _z:
    _ost2 = _z.read("styles.xml").decode("utf-8")
check("Formatvorlage 0.23: ohne Vorlage bleibt das bisherige Standardformat (Ränder 2,5 cm)",
      w.fmt_spec is None and 'fo:margin-left="2.5cm"' in _ost2 and "Klasse 5b" not in _ost2)

# Dialog: aus LaTeX erstellen, umbenennen, löschen, in LibreOffice-Ordner ablegen
_dlg = _FD(w, _fvdir)
_real_gt = _QID.getText
_QID.getText = staticmethod(lambda *a, **k: ("Aus Test", True))
_dlg._make(_FVTEX, "x")
check("Formatvorlage 0.23: Dialog legt aus LaTeX-Text eine Vorlage an und zeigt den Bericht",
      "Aus Test" in [x["name"] for x in _dlg.items] and _dlg.current()["name"] == "Aus Test" and "Erkannt" in _dlg.rep.toPlainText())
_QID.getText = staticmethod(lambda *a, **k: ("Umbenannt", True))
_dlg._rename()
check("Formatvorlage 0.23: Umbenennen", "Umbenannt" in [x["name"] for x in _dlg.items] and "Aus Test" not in [x["name"] for x in _dlg.items])
_QID.getText = _real_gt
_home0 = os.environ.get("HOME")
os.environ["HOME"] = os.path.join(TMP, "home")
_orig_info = QMessageBox.information
QMessageBox.information = staticmethod(lambda *a, **k: None)
_dlg._to_lo()
QMessageBox.information = _orig_info
if _home0 is not None:
    os.environ["HOME"] = _home0
check("Formatvorlage 0.23: „In LibreOffice-Vorlagen ablegen“ schreibt eine .ott",
      os.path.exists(os.path.join(TMP, "home", ".config", "libreoffice", "4", "user", "template", "Umbenannt.ott")))
_orig_q = QMessageBox.question
QMessageBox.question = staticmethod(lambda *a, **k: QMessageBox.StandardButton.Yes)
_dlg._delete()
QMessageBox.question = _orig_q
check("Formatvorlage 0.23: Löschen", "Umbenannt" not in [x["name"] for x in _dlg.items])
_dlg.close()


# ---------------------------------------------------------------- 0.24: Formularfelder bearbeiten
if _mu is not None:
    from PySide6.QtCore import Qt as _Qt, QPoint as _QPoint
    from seiffert_text.fieldlayer import move_rects, resize_rect, align_rects, best_snap
    from seiffert_text.pdf_window import MODE_FIELDS as _MF, MODE_VIEW as _MV

    # Geometrie ohne Oberfläche
    _new, _gx, _gy = move_rects([(10, 10, 50, 30)], 22.0, 3.0, [(70, 100, 120, 120)], 6.0, (200, 200))
    check("Felder 0.24: Verschieben rastet an Kante ein", abs(_new[0][0] - 30.0) < 1e-6 or abs(_new[0][2] - 70.0) < 1e-6, str(_new))
    _new, _, _ = move_rects([(10, 10, 50, 30)], -50.0, -50.0, [], 6.0, (200, 200))
    check("Felder 0.24: Verschieben bleibt auf der Seite", _new[0][0] == 0.0 and _new[0][1] == 0.0, str(_new))
    _r, _, _ = resize_rect((10, 10, 50, 30), (1, 1), -100.0, -100.0, [], 0.0, (200, 200))
    check("Felder 0.24: Mindestgröße", _r[2] - _r[0] >= 3.0 and _r[3] - _r[1] >= 3.0, str(_r))
    _al = align_rects([(10, 10, 50, 30), (20, 40, 100, 60), (5, 80, 25, 90)], "left")
    check("Felder 0.24: Links bündig", all(abs(r[0] - 5) < 1e-6 for r in _al), str(_al))
    _al = align_rects([(10, 10, 50, 30), (20, 40, 100, 60)], "same_size")
    check("Felder 0.24: Gleiche Größe nach dem ersten", _al[1][2] - _al[1][0] == 40 and _al[1][3] - _al[1][1] == 20, str(_al))
    _al = align_rects([(0, 0, 10, 10), (30, 0, 40, 10), (100, 0, 110, 10)], "dist_h")
    check("Felder 0.24: Gleichmäßig verteilen", abs(_al[1][0] - 50.0) < 1e-6, str(_al))

    def _form(path, rot=0):
        d = _mu.open()
        pg = d.new_page()
        pg.insert_text((50, 40), "Formular", fontsize=16)
        def add(t, name, r, **k):
            wd = _mu.Widget()
            wd.field_type = t
            wd.field_name = name
            wd.rect = _mu.Rect(*r)
            wd.border_color = (0, 0, 0)
            wd.border_width = 0
            for a, b in k.items():
                setattr(wd, a, b)
            pg.add_widget(wd)
        add(_mu.PDF_WIDGET_TYPE_TEXT, "Name", (50, 100, 250, 120), field_value="Max", text_fontsize=0, text_font="Helv")
        add(_mu.PDF_WIDGET_TYPE_TEXT, "Ort", (50, 140, 250, 160), field_value="Köln", text_fontsize=0, text_font="Helv")
        add(_mu.PDF_WIDGET_TYPE_CHECKBOX, "ck", (50, 190, 64, 204), field_value="On")
        add(_mu.PDF_WIDGET_TYPE_COMBOBOX, "cb", (50, 230, 200, 250), choice_values=["a", "b"], field_value="a",
            text_font="Helv")
        pg.set_rotation(rot)
        d.save(path)
        d.close()

    for _rot in (0, 90):
        _fp = os.path.join(TMP, "form%d.pdf" % _rot)
        _form(_fp, _rot)
        _e = _PE(_fp)
        _fl = {f["name"]: f for f in _e.fields(0)}
        _x = _fl["Name"]["xref"]
        _r0 = _fl["Name"]["rect"]
        _e.place_fields(0, [(_x, (_r0[0] + 30, _r0[1] + 20, _r0[2] + 50, _r0[3] + 20))])
        _r1 = {f["name"]: f for f in _e.fields(0)}["Name"]
        check("Felder 0.24: Lage und Größe (Drehung %d)" % _rot,
              all(abs(a - b) < 0.6 for a, b in zip(_r1["rect"], (_r0[0] + 30, _r0[1] + 20, _r0[2] + 50, _r0[3] + 20))), str(_r1["rect"]))
        check("Felder 0.24: Wert bleibt beim Verschieben (Drehung %d)" % _rot,
              _r1["value"] == "Max" and {f["name"]: f for f in _e.fields(0)}["ck"]["value"] is True)
        check("Felder 0.24: Randstärke 0 bleibt (Drehung %d)" % _rot,
              _e.doc.xref_get_key(_x, "BS/W")[1] in ("0", "0.0"), str(_e.doc.xref_get_key(_x, "BS/W")))
        _e.set_field_props(0, _x, {"name": "Vorname", "fontsize": 12, "align": 2, "readonly": True})
        _pp = _e.field_props(0, _x)
        check("Felder 0.24: Eigenschaften (Drehung %d)" % _rot,
              _pp["name"] == "Vorname" and _pp["fontsize"] == 12.0 and _pp["align"] == 2 and _pp["readonly"], str(_pp))
        try:
            _e.set_field_props(0, _x, {"name": "Ort"})
            _dup = False
        except Exception:
            _dup = True
        check("Felder 0.24: doppelter Name wird abgelehnt (Drehung %d)" % _rot, _dup)
        _n = _e.add_field(0, "text", (300, 300, 400, 320))
        _c = _e.add_field(0, "check", (300, 350, 330, 380))
        _k = {f["xref"]: f for f in _e.fields(0)}
        check("Felder 0.24: neue Felder an der angegebenen Stelle (Drehung %d)" % _rot,
              all(abs(a - b) < 0.6 for a, b in zip(_k[_n]["rect"], (300, 300, 400, 320)))
              and abs((_k[_c]["rect"][2] - _k[_c]["rect"][0]) - (_k[_c]["rect"][3] - _k[_c]["rect"][1])) < 0.6)
        _cp = _e.copy_field(0, _n, 10, 10)
        check("Felder 0.24: Kopie mit eigenem Namen (Drehung %d)" % _rot,
              {f["xref"]: f for f in _e.fields(0)}[_cp]["name"] != "Text" and len(_e.fields(0)) == 7)
        _e.delete_fields(0, [_cp, _c])
        check("Felder 0.24: Löschen (Drehung %d)" % _rot, len(_e.fields(0)) == 5)
        _e.undo_last()
        check("Felder 0.24: Rückgängig nach Löschen (Drehung %d)" % _rot, len(_e.fields(0)) == 7)
        _out = os.path.join(TMP, "form_out%d.pdf" % _rot)
        _e.save(_out)
        _chk = _mu.open(_out)
        _ws = {x.field_name: x for x in _chk[0].widgets()}
        check("Felder 0.24: gespeichertes PDF enthält die Änderungen (Drehung %d)" % _rot,
              "Vorname" in _ws and "Text" in _ws and _ws["Vorname"].field_value == "Max")
        _chk.close()

    # Schaltfläche: Aussehen bleibt beim Verschieben unangetastet
    _bd = _mu.open()
    _bp = _bd.new_page()
    _bw = _mu.Widget()
    _bw.field_type = _mu.PDF_WIDGET_TYPE_BUTTON
    _bw.field_name = "senden"
    _bw.rect = _mu.Rect(50, 300, 120, 320)
    _bw.button_caption = "Senden"
    _bw.fill_color = (0.9, 0.9, 0.9)
    _bw.border_color = (0, 0, 0)
    _bp.add_widget(_bw)
    _bfp = os.path.join(TMP, "button.pdf")
    _bd.save(_bfp)
    _bd.close()
    _be = _PE(_bfp)
    _bf = _be.fields(0, all_kinds=True)[0]
    _ap0 = _be.doc.xref_get_key(_bf["xref"], "AP/N")
    _be.place_fields(0, [(_bf["xref"], (80, 340, 170, 370))])
    _bf2 = _be.fields(0, all_kinds=True)[0]
    check("Felder 0.24: Schaltfläche verschieben ohne neues Aussehen", _bf["kind"] == "button"
          and _be.doc.xref_get_key(_bf["xref"], "AP/N") == _ap0
          and all(abs(a - b) < 0.6 for a, b in zip(_bf2["rect"], (80, 340, 170, 370))), str(_bf2["rect"]))

    # Fenster: Maus und Tastatur
    _fp = os.path.join(TMP, "formw.pdf")
    _form(_fp)
    _pw = _PW(_fp)
    _pw.show()
    _pw.set_mode(_MF)
    _lay = _pw.layer
    _z = _pw.zoom
    _nm = {f["name"]: x for x, f in _lay.fields.items()}
    P = lambda a, b: _QPoint(int(a * _z), int(b * _z))
    _QT.mouseClick(_lay, _Qt.MouseButton.LeftButton, pos=P(100, 110))
    check("Felder 0.24: Klick markiert", [_lay.fields[x]["name"] for x in _lay.sel] == ["Name"])
    _QT.mousePress(_lay, _Qt.MouseButton.LeftButton, pos=P(100, 110))
    for _k2 in range(1, 11):
        _QT.mouseMove(_lay, P(100 + 4 * _k2, 110 + 3 * _k2))
    _QT.mouseRelease(_lay, _Qt.MouseButton.LeftButton, pos=P(140, 140))
    _rr = _pw.layer.rects[_nm["Name"]]
    check("Felder 0.24: Ziehen verschiebt das Feld", abs(_rr[0] - 90) < 1.5 and abs(_rr[1] - 130) < 1.5, str(_rr))
    _x0, _y0, _x1, _y1 = _rr
    _QT.mousePress(_pw.layer, _Qt.MouseButton.LeftButton, pos=P(_x1, _y1))
    for _k2 in range(1, 11):
        _QT.mouseMove(_pw.layer, P(_x1 + 3 * _k2, _y1 + 2 * _k2))
    _QT.mouseRelease(_pw.layer, _Qt.MouseButton.LeftButton, pos=P(_x1 + 30, _y1 + 20))
    _r2 = _pw.layer.rects[_nm["Name"]]
    check("Felder 0.24: Griff ändert die Größe", abs(_r2[2] - (_x1 + 30)) < 1.5 and abs(_r2[0] - _x0) < 0.6, str(_r2))
    _QT.keyClick(_pw.layer, _Qt.Key.Key_Right, _Qt.KeyboardModifier.ShiftModifier)
    check("Felder 0.24: Umschalt+Pfeil verschiebt um 10 Punkte", abs(_pw.layer.rects[_nm["Name"]][0] - (_x0 + 10)) < 0.6)
    _w_before = _pw.layer.rects[_nm["Name"]][2] - _pw.layer.rects[_nm["Name"]][0]
    _QT.keyClick(_pw.layer, _Qt.Key.Key_Right, _Qt.KeyboardModifier.ControlModifier)
    check("Felder 0.24: Strg+Pfeil ändert die Breite", abs((_pw.layer.rects[_nm["Name"]][2] - _pw.layer.rects[_nm["Name"]][0]) - (_w_before + 1)) < 0.6)
    _pw.fields_select_all()
    check("Felder 0.24: alle markieren", len(_pw.layer.sel) == 4)
    _QT.keyClick(_pw.layer, _Qt.Key.Key_D, _Qt.KeyboardModifier.ControlModifier)
    check("Felder 0.24: Strg+D kopiert (Optionen ohne Optionsknöpfe)", len(_pw.layer.fields) == 8)
    _QT.keyClick(_pw.layer, _Qt.Key.Key_Delete)
    check("Felder 0.24: Entf löscht die markierten Kopien", len(_pw.layer.fields) == 4)
    for _k2 in range(6):
        _pw.undo()
    check("Felder 0.24: Rückgängig bis zum Ausgangszustand",
          _pw.layer.rects[_nm["Name"]] == (50.0, 100.0, 250.0, 120.0) or
          all(abs(a - b) < 0.6 for a, b in zip(_pw.layer.rects[_nm["Name"]], (50.0, 100.0, 250.0, 120.0))))
    _pw.fields_tool("text")
    _QT.mouseClick(_pw.layer, _Qt.MouseButton.LeftButton, pos=P(300, 300))
    check("Felder 0.24: Werkzeug legt neues Feld an", len(_pw.layer.fields) == 5 and len(_pw.layer.sel) == 1)
    _pw.set_mode(_MV)
    check("Felder 0.24: Ausfüllansicht zeigt wieder Eingabefelder", _pw.layer is None and len(_pw.field_widgets) == 5)
    _pw.ed.modified = False
    _pw.close()

    # als Tab im Hauptfenster (Tastenkürzel dürfen nicht kollidieren)
    _wm = MainWindow()
    _wm.show()
    _wm.activateWindow()
    _QT.qWaitForWindowActive(_wm)
    _wm.open_file(_fp)
    pump(100)
    _tw = _wm.cur_pdf.widget
    _tw.set_mode(_MF)
    pump(50)
    _tw.layer.setFocus()
    _QT.keyClick(_tw.layer, _Qt.Key.Key_A, _Qt.KeyboardModifier.ControlModifier)
    check("Felder 0.24: Strg+A im PDF-Tab markiert alle Felder", len(_tw.layer.sel) == len(_tw.layer.fields) and len(_tw.layer.sel) > 0)
    _QT.keyClick(_tw.layer, _Qt.Key.Key_Delete)
    check("Felder 0.24: Entf im PDF-Tab löscht", len(_tw.layer.fields) == 0)
    _tw.undo()
    check("Felder 0.24: Rückgängig im PDF-Tab", len(_tw.layer.fields) > 0)
    _tw.ed.modified = False
    _wm.cur_pdf.s["modified"] = False
    _wm.modified = False
    _wm.close()
    pump(100)

w.cur.s["modified"] = False
for t in list(w.tabs.values()):
    t.s["modified"] = False
w.modified = False
w.close()
for k, v in _orig.items():
    setattr(QMessageBox, k, v)

shutil.rmtree(TMP, ignore_errors=True)
print("Ergebnis: %d Prüfungen ok, %d Fehler, %d übersprungen" % (OK, FAIL, SKIP))
sys.exit(1 if FAIL else 0)
