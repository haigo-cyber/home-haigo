#!/usr/bin/env python3
"""Seifferts Bildtext: Text von einem Bildschirmausschnitt ablesen (Texterkennung mit tesseract).

Ablauf: Der Bildschirm wird fotografiert und abgedunkelt angezeigt. Mit der Maus einen Rahmen um den Text ziehen, loslassen:
Der erkannte Text liegt in der Zwischenablage. Esc oder Rechtsklick bricht ab.

Aufruf:  seiffert-bildtext                 Ausschnitt mit der Maus wählen
         seiffert-bildtext --file BILD     Text aus einer Bilddatei lesen (ohne Bildschirmfoto)
         seiffert-bildtext --stdout        Text zusätzlich ausgeben
Optionen: --lang deu+eng (Sprachen für tesseract), --delay SEKUNDEN (vor dem Foto warten), --rect X,Y,B,H (Ausschnitt ohne Maus)

Benötigt: tesseract mit deutschen Sprachdaten (Arch: sudo pacman -S tesseract tesseract-data-deu tesseract-data-eng).
Das Bildschirmfoto funktioniert unter X11 (Cinnamon, MATE). Unter Wayland (COSMIC) erlaubt das System Programmen kein direktes Foto;
dort bleibt der Weg über --file mit einem Bildschirmfoto des Desktops."""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
NAME = "Seifferts Bildtext"
INSTALL_HINT = "sudo pacman -S tesseract tesseract-data-deu tesseract-data-eng"
MIN_SIDE = 8                    # kleinere Rahmen gelten als versehentlicher Klick


# ---------------------------------------------------------------------------------------------- Texterkennung (ohne Oberfläche)
def tesseract_path() -> str:
    return shutil.which("tesseract") or ""


def installed_langs(exe: str) -> list[str]:
    try:
        r = subprocess.run([exe, "--list-langs"], capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.SubprocessError):
        return []
    return [ln.strip() for ln in (r.stdout + "\n" + r.stderr).splitlines()[1:] if ln.strip() and " " not in ln.strip() and ln.strip() != "osd"]


def pick_langs(wanted: str, have: list[str]) -> tuple[str, list[str]]:
    """Gewünschte Sprachen, soweit installiert. Rückgabe: (Angabe für tesseract, fehlende Sprachen)."""
    want = [w for w in wanted.replace(",", "+").split("+") if w]
    ok = [w for w in want if w in have]
    missing = [w for w in want if w not in have]
    if not ok:
        ok = ["eng"] if "eng" in have else have[:1]
    return "+".join(ok), missing


def clean_text(raw: str) -> str:
    """Leerraum am Zeilenende und Leerzeilen an Anfang und Ende entfernen, mehrere Leerzeilen zu einer zusammenziehen."""
    lines = [ln.rstrip() for ln in raw.replace("\x0c", "").splitlines()]
    out: list[str] = []
    for ln in lines:
        if not ln and (not out or not out[-1]):
            continue
        out.append(ln)
    while out and not out[-1]:
        out.pop()
    return "\n".join(out)


def recognize(image_path: str, langs: str = "deu+eng") -> tuple[str, str]:
    """Liest den Text aus einer Bilddatei. Rückgabe: (Text, Hinweis). Wirft RuntimeError mit einer Meldung für den Benutzer."""
    exe = tesseract_path()
    if not exe:
        raise RuntimeError("Das Programm tesseract fehlt. Installieren mit:  " + INSTALL_HINT)
    have = installed_langs(exe)
    if not have:
        raise RuntimeError("tesseract hat keine Sprachdaten. Installieren mit:  " + INSTALL_HINT)
    use, missing = pick_langs(langs, have)
    note = ("Sprachdaten fehlen für: %s (benutzt: %s)." % (", ".join(missing), use)) if missing else ""
    try:
        r = subprocess.run([exe, image_path, "stdout", "-l", use, "--psm", "6"], capture_output=True, timeout=60)
    except subprocess.TimeoutExpired:
        raise RuntimeError("Die Texterkennung hat zu lange gedauert (über 60 Sekunden).")
    except OSError as e:
        raise RuntimeError("tesseract ließ sich nicht starten: %s" % (e.strerror or e))
    if r.returncode != 0:
        err = r.stderr.decode("utf-8", "replace").strip().splitlines()
        raise RuntimeError("tesseract meldet einen Fehler: %s" % (err[-1] if err else "unbekannt"))
    return clean_text(r.stdout.decode("utf-8", "replace")), note


# ---------------------------------------------------------------------------------------------- Ergebnis abliefern
def hand_over(text: str) -> str:
    """Legt den Text in die Zwischenablage. Zuerst über den laufenden Starter (der weiterläuft und den Text behält), sonst über
    xclip, xsel oder wl-copy. Rückgabe: wer es übernommen hat, leer wenn niemand."""
    try:
        import starterextra as SX
        if SX._send("seiffert-starter-%s" % SX._uid(), "copy\x1f" + text, timeout=1.0):
            return "starter"
    except Exception:  # noqa: BLE001
        pass
    for argv in (["wl-copy"] if os.environ.get("WAYLAND_DISPLAY") else []) + [["xclip", "-selection", "clipboard"], ["xsel", "--clipboard", "--input"]]:
        argv = argv if isinstance(argv, list) else [argv]
        if shutil.which(argv[0]):
            try:
                subprocess.run(argv, input=text.encode("utf-8"), timeout=5, check=True)
                return argv[0]
            except (OSError, subprocess.SubprocessError):
                continue
    return ""


def notify(title: str, body: str) -> None:
    exe = shutil.which("notify-send")
    if exe:
        try:
            subprocess.Popen([exe, "-a", NAME, "-i", "seiffert-dateien", "-t", "6000", title, body], stdin=subprocess.DEVNULL,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except OSError:
            pass


def preview(text: str, width: int = 160) -> str:
    one = " ".join(text.split())
    return one if len(one) <= width else one[:width - 1] + "…"


# ---------------------------------------------------------------------------------------------- Ausschnitt wählen
def build_selector():
    from PySide6.QtCore import QPoint, QRect, Qt
    from PySide6.QtGui import QColor, QCursor, QGuiApplication, QPainter, QPen
    from PySide6.QtWidgets import QWidget

    class Selector(QWidget):
        """Zeigt das Bildschirmfoto abgedunkelt im Vollbild; der gezogene Rahmen ist hell."""

        def __init__(self, shot, geometry: QRect) -> None:
            super().__init__(None, Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint | Qt.WindowType.Tool)
            self.shot = shot
            self.setGeometry(geometry)
            self.setCursor(Qt.CursorShape.CrossCursor)
            self.setMouseTracking(True)
            self.a: QPoint | None = None
            self.b: QPoint | None = None
            self.result: QRect | None = None
            self.done = False

        def rect_sel(self) -> QRect:
            return QRect(self.a, self.b).normalized() if self.a is not None and self.b is not None else QRect()

        def paintEvent(self, _ev) -> None:  # noqa: N802
            p = QPainter(self)
            p.drawPixmap(self.rect(), self.shot)
            p.fillRect(self.rect(), QColor(0, 0, 0, 110))
            r = self.rect_sel()
            if r.width() > 1 and r.height() > 1:
                ratio = self.shot.width() / max(1, self.width())
                src = QRect(round(r.x() * ratio), round(r.y() * ratio), round(r.width() * ratio), round(r.height() * ratio))
                p.drawPixmap(r, self.shot, src)
                p.setPen(QPen(QColor("#ffd479"), 2))
                p.drawRect(r.adjusted(0, 0, -1, -1))
            else:
                p.setPen(QColor("#ffffff"))
                f = p.font()
                f.setPixelSize(20)
                p.setFont(f)
                p.drawText(self.rect().adjusted(0, 40, 0, 0), Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop,
                           "Rahmen um den Text ziehen. Esc bricht ab.")
            p.end()

        def mousePressEvent(self, ev) -> None:  # noqa: N802
            if ev.button() == Qt.MouseButton.RightButton:
                self.finish(None)
                return
            self.a = self.b = ev.position().toPoint()
            self.update()

        def mouseMoveEvent(self, ev) -> None:  # noqa: N802
            if self.a is not None and ev.buttons() & Qt.MouseButton.LeftButton:
                self.b = ev.position().toPoint()
                self.update()

        def mouseReleaseEvent(self, ev) -> None:  # noqa: N802
            if ev.button() != Qt.MouseButton.LeftButton or self.a is None:
                return
            self.b = ev.position().toPoint()
            r = self.rect_sel().intersected(self.rect())
            if r.width() < MIN_SIDE or r.height() < MIN_SIDE:        # nur geklickt: weiter warten
                self.a = self.b = None
                self.update()
                return
            self.finish(r)

        def keyPressEvent(self, ev) -> None:  # noqa: N802
            if ev.key() == Qt.Key.Key_Escape:
                self.finish(None)

        def finish(self, r) -> None:
            self.result = r
            self.done = True
            self.close()

    return Selector, QCursor, QGuiApplication, QRect


def crop(shot, widget_rect, widget_width: int):
    """Schneidet den gewählten Rahmen aus dem Foto (das bei hoher Auflösung mehr Bildpunkte hat als das Fenster) und vergrößert
    kleine Schrift, weil tesseract mit größeren Buchstaben deutlich besser liest."""
    from PySide6.QtCore import QRect, Qt
    ratio = shot.width() / max(1, widget_width)
    src = QRect(round(widget_rect.x() * ratio), round(widget_rect.y() * ratio), round(widget_rect.width() * ratio), round(widget_rect.height() * ratio))
    img = shot.copy(src).toImage()
    scale = 3 if img.height() < 60 else 2 if img.width() < 2400 and img.height() < 1600 else 1
    if scale > 1:
        img = img.scaled(img.width() * scale, img.height() * scale, Qt.AspectRatioMode.IgnoreAspectRatio, Qt.TransformationMode.SmoothTransformation)
    return img


def looks_empty(img) -> bool:
    """Ein einfarbiges (meist schwarzes) Foto heißt: Das System hat das Bildschirmfoto nicht erlaubt (Wayland)."""
    if img.isNull() or img.width() < 2:
        return True
    first = img.pixel(0, 0)
    stepx, stepy = max(1, img.width() // 24), max(1, img.height() // 24)
    return all(img.pixel(x, y) == first for x in range(0, img.width(), stepx) for y in range(0, img.height(), stepy))


def parse_args(argv: list[str]) -> dict:
    out = {"lang": "deu+eng", "delay": 0.0, "file": "", "rect": None, "stdout": False, "help": False, "error": ""}
    i = 0
    while i < len(argv):
        a = argv[i]
        val = None
        if a.startswith("--") and "=" in a:
            a, _, val = a.partition("=")
        if a in ("-h", "--help"):
            out["help"] = True
        elif a == "--stdout":
            out["stdout"] = True
        elif a in ("--lang", "--delay", "--file", "--rect"):
            if val is None:
                i += 1
                if i >= len(argv):
                    out["error"] = "Nach %s fehlt ein Wert." % a
                    return out
                val = argv[i]
            try:
                if a == "--delay":
                    out["delay"] = max(0.0, min(10.0, float(val)))
                elif a == "--rect":
                    r = [int(x) for x in val.split(",")]
                    if len(r) != 4 or r[2] < 1 or r[3] < 1:
                        raise ValueError
                    out["rect"] = tuple(r)
                else:
                    out[a[2:]] = val
            except ValueError:
                out["error"] = "Ungültiger Wert für %s: %s" % (a, val)
                return out
        else:
            out["error"] = "Unbekannte Angabe %s. Hilfe: seiffert-bildtext --help" % a
            return out
        i += 1
    return out


def main(argv: list[str]) -> int:
    a = parse_args(argv[1:])
    if a["help"]:
        sys.stdout.write(__doc__ + "\n")
        return 0
    if a["error"]:
        sys.stderr.write(a["error"] + "\n")
        return 2

    def fail(msg: str) -> int:
        sys.stderr.write(msg + "\n")
        notify("Text vom Bildschirm", msg)
        return 1

    def deliver(text: str, note: str) -> int:
        if not text.strip():
            return fail("Im gewählten Ausschnitt wurde kein Text erkannt." + (" " + note if note else ""))
        via = hand_over(text)
        if a["stdout"] or not via:
            sys.stdout.write(text + "\n")
        if via:
            notify("Text in der Zwischenablage (%d Zeichen)" % len(text), preview(text) + ("\n" + note if note else ""))
        else:
            notify("Text erkannt, aber nicht in der Zwischenablage",
                   "Der Seifferts Starter läuft nicht und xclip, xsel oder wl-copy fehlen. Der Text wurde im Terminal ausgegeben.")
        return 0

    if a["file"]:
        path = os.path.abspath(os.path.expanduser(a["file"]))
        if not os.path.isfile(path):
            return fail("Die Bilddatei gibt es nicht: %s" % path)
        try:
            text, note = recognize(path, a["lang"])
        except RuntimeError as e:
            return fail(str(e))
        return deliver(text, note)

    if not tesseract_path():                                        # vor dem Foto prüfen, sonst zieht man den Rahmen umsonst
        return fail("Das Programm tesseract fehlt. Installieren mit:  " + INSTALL_HINT)
    try:
        from PySide6.QtWidgets import QApplication
    except ImportError as e:
        return fail("PySide6 fehlt (%s)." % e)
    Selector, QCursor, QGuiApplication, QRect = build_selector()
    app = QApplication([argv[0]])
    app.setApplicationName(NAME)
    app.setDesktopFileName("seiffert-dateien")
    if a["delay"]:
        time.sleep(a["delay"])                                      # der Starter braucht einen Moment, bis seine Wolke verschwunden ist
    scr = QGuiApplication.screenAt(QCursor.pos()) or QGuiApplication.primaryScreen()
    if scr is None:
        return fail("Kein Bildschirm gefunden.")
    shot = scr.grabWindow(0)
    if shot.isNull() or looks_empty(shot.toImage()):
        return fail("Das Bildschirmfoto ist leer. Unter Wayland (zum Beispiel COSMIC) erlaubt das System kein direktes Foto. "
                    "Ausweg: ein Bildschirmfoto mit dem Desktop machen und dann  seiffert-bildtext --file BILD  aufrufen.")
    geo = scr.geometry()
    if a["rect"]:
        x, y, w, h = a["rect"]
        sel = QRect(x, y, w, h).intersected(QRect(0, 0, geo.width(), geo.height()))
        if sel.isEmpty():
            return fail("Der angegebene Ausschnitt liegt außerhalb des Bildschirms.")
    else:
        win = Selector(shot, geo)
        win.showFullScreen()
        win.raise_()
        win.activateWindow()
        while not win.done and win.isVisible():
            app.processEvents()
            time.sleep(0.01)
        if win.result is None:
            return 0                                                # abgebrochen
        sel = win.result
    img = crop(shot, sel, geo.width())
    fd, tmp = tempfile.mkstemp(prefix="seiffert-bildtext-", suffix=".png")
    os.close(fd)
    try:
        if not img.save(tmp, "PNG"):
            return fail("Der Ausschnitt ließ sich nicht zwischenspeichern.")
        try:
            text, note = recognize(tmp, a["lang"])
        except RuntimeError as e:
            return fail(str(e))
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            pass
    return deliver(text, note)


if __name__ == "__main__":
    sys.exit(main(sys.argv))
