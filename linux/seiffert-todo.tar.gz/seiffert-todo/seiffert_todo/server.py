"""Lokaler Server für Seifferts ToDo (Linux).

Aufgaben:
- liefert die HTML-Datei der ToDo-App mit eingefügten Skripten aus (nur 127.0.0.1, geheimer Pfadanteil, Host-Prüfung)
- führt Google-Aufrufe (Sheets, Drive, Kalender, Tasks) für die Seite aus (kein CORS-Problem, IPv4 zuerst)
- nimmt das Anmelde-Token aus dem Browser entgegen (Übergabe über GitHub Pages) und hält es
- spiegelt den localStorage der Seite in eine Datei (die Seite läuft bei jedem Start unter einem anderen Anschluss)
- legt täglich eine lokale Kopie der Google-Daten ab
Google bleibt führend: die Seite liest vor jedem Schreiben den Serverstand und führt zusammen.
"""
import http.client
import json
import os
import re
import secrets
import socket
import ssl
import threading
import time
import urllib.parse
from datetime import datetime, date
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

APP = "seiffert-todo"
HOME = Path.home()
CONFIG_DIR = Path(os.environ.get("XDG_CONFIG_HOME", HOME / ".config")) / APP
DATA_DIR = Path(os.environ.get("XDG_DATA_HOME", HOME / ".local" / "share")) / APP
KOPIEN_DIR = DATA_DIR / "kopien"
PKG_DIR = Path(__file__).resolve().parent

ALLOWED_HOSTS = {"www.googleapis.com", "sheets.googleapis.com", "tasks.googleapis.com"}
FORWARD_HEADERS = {"content-type", "accept", "range", "if-match", "if-none-match", "x-goog-api-client"}
LOGIN_TIMEOUT = 300  # Sekunden
GOOGLE_BASE = os.environ.get("SEIFFERT_TODO_GOOGLE_BASE", "")  # Testhook: alle Google-Adressen auf diesen Server umleiten

DEFAULT_SETTINGS = {
    "handoff_url": "",
    "auto_anmelden": True,     # beim Start sofort anmelden und Daten holen
    "token_merken": True,      # Token (gilt etwa eine Stunde) für einen Neustart in dieser Zeit behalten
    "zoom": 1.0,
    "software_rendering": False,
    "html_datei": "",
}


def now_iso():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def atomic_write(path: Path, data: str, mode=0o600):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, mode)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


class Log:
    def __init__(self):
        self.path = DATA_DIR / "protokoll.txt"
        self.lock = threading.Lock()

    def __call__(self, msg):
        try:
            with self.lock:
                self.path.parent.mkdir(parents=True, exist_ok=True)
                if self.path.exists() and self.path.stat().st_size > 400_000:
                    old = self.path.read_text("utf-8", "replace")[-150_000:]
                    self.path.write_text(old, "utf-8")
                with open(self.path, "a", encoding="utf-8") as f:
                    f.write(f"{now_iso()} {msg}\n")
        except Exception:
            pass


log = Log()


class Settings:
    def __init__(self):
        self.path = CONFIG_DIR / "settings.json"
        self.data = dict(DEFAULT_SETTINGS)
        try:
            self.data.update(json.loads(self.path.read_text("utf-8")))
        except Exception:
            pass

    def get(self, k):
        return self.data.get(k, DEFAULT_SETTINGS.get(k))

    def set(self, k, v):
        self.data[k] = v
        try:
            atomic_write(self.path, json.dumps(self.data, ensure_ascii=False, indent=2), 0o600)
        except Exception as e:
            log(f"Einstellungen nicht gespeichert: {e}")


# ---------------------------------------------------------------- Adresse der veröffentlichten Seite
def clean_handoff_url(u: str):
    """Gibt (url, fehler) zurück. Gleiche Prüfungen wie bei Seifferts Depot."""
    u = (u or "").strip()
    if not u:
        return "", "Keine Adresse eingegeben."
    if u.count("https://") + u.count("http://") > 1:
        return "", "Die Adresse enthält mehrfach https://."
    if not re.match(r"^https?://", u, re.I):
        u = "https://" + u
    u = u.split("#", 1)[0]
    p = urllib.parse.urlsplit(u)
    host = (p.hostname or "").lower()
    if not host or "." not in host:
        return "", "Das ist keine gültige Internetadresse."
    if host.endswith("google.com") or host.endswith("googleusercontent.com") or host.endswith("googleapis.com"):
        return "", "Gemeint ist die Adresse der veröffentlichten ToDo-Seite (GitHub Pages), nicht eine Google-Adresse."
    if host == "github.com" or host.endswith(".github.com") or host == "raw.githubusercontent.com":
        return "", ("Das ist die Seite des Repositorys auf GitHub, nicht die veröffentlichte Seite. Gemeint ist die Adresse auf GitHub Pages, "
                    "sie sieht so aus: https://BENUTZER.github.io/REPOSITORY/ (bei dir vermutlich https://haigo-cyber.github.io/home-haigo/ "
                    "mit dem Dateinamen der ToDo-Seite, falls sie nicht index.html heißt).")
    if "linuxport" in p.query or "linuxstate" in p.query:
        return "", "Die Adresse darf keinen Teil mit linuxport enthalten."
    if p.scheme != "https":
        return "", "Die Adresse muss mit https:// beginnen."
    return urllib.parse.urlunsplit((p.scheme, p.netloc, p.path, p.query, "")), ""


# ---------------------------------------------------------------- localStorage-Spiegel
class LocalStore:
    def __init__(self):
        self.path = DATA_DIR / "localstorage.json"
        self.lock = threading.Lock()
        self.data = {}
        self.dirty = False
        self.timer = None
        try:
            d = json.loads(self.path.read_text("utf-8"))
            if isinstance(d, dict):
                self.data = {str(k): str(v) for k, v in d.items()}
        except FileNotFoundError:
            pass
        except Exception as e:
            log(f"localstorage.json unlesbar ({e}), wird beiseite gelegt")
            try:
                self.path.rename(self.path.with_name("localstorage.defekt.json"))
            except Exception:
                pass

    def apply(self, diff):
        with self.lock:
            if diff.get("clear"):
                self.data.clear()
            for k, v in (diff.get("set") or {}).items():
                self.data[str(k)] = "" if v is None else str(v)
            for k in diff.get("del") or []:
                self.data.pop(str(k), None)
            self.dirty = True
            if self.timer is None:
                self.timer = threading.Timer(1.0, self.flush)
                self.timer.daemon = True
                self.timer.start()

    def flush(self):
        with self.lock:
            self.timer = None
            if not self.dirty:
                return
            self.dirty = False
            snap = json.dumps(self.data, ensure_ascii=False)
        try:
            atomic_write(self.path, snap)
        except Exception as e:
            log(f"localStorage nicht gespeichert: {e}")

    def snapshot(self):
        with self.lock:
            return dict(self.data)


# ---------------------------------------------------------------- Anmeldung
class Auth:
    def __init__(self, settings):
        self.settings = settings
        self.lock = threading.Lock()
        self.token = ""
        self.expires_at = 0.0
        self.scope = ""
        self.logins = {}        # state -> dict
        self.current_state = "" # aktuell wartender Versuch
        self.on_login = None    # Rückruf (state, scope) -> öffnet den Browser (GUI-Thread)
        self.path = DATA_DIR / "token.json"
        self._load()

    def _load(self):
        if not self.settings.get("token_merken"):
            self._forget_file()
            return
        try:
            d = json.loads(self.path.read_text("utf-8"))
            if float(d.get("expires_at", 0)) - 120 > time.time() and d.get("token"):
                self.token, self.expires_at, self.scope = d["token"], float(d["expires_at"]), d.get("scope", "")
                log("Gespeichertes Token wiederverwendet (Rest %d Min)" % int((self.expires_at - time.time()) / 60))
            else:
                self._forget_file()
        except Exception:
            pass

    def _forget_file(self):
        try:
            self.path.unlink()
        except Exception:
            pass

    def valid(self, margin=30):
        return bool(self.token) and self.expires_at - margin > time.time()

    def has_scopes(self, wanted: str):
        have = set(self.scope.split())
        need = set(wanted.split())
        # ohne Angabe der Gegenseite gilt das Token als ausreichend
        return (not have) or need <= have

    def info(self):
        return {"valid": self.valid(), "expires_in": max(0, int(self.expires_at - time.time())) if self.token else 0,
                "scope": self.scope}

    def store(self, token, expires_in, scope):
        with self.lock:
            self.token = token
            self.expires_at = time.time() + max(60, int(expires_in))
            self.scope = scope or self.scope
        if self.settings.get("token_merken"):
            try:
                atomic_write(self.path, json.dumps({"token": token, "expires_at": self.expires_at, "scope": self.scope}))
            except Exception as e:
                log(f"Token nicht gespeichert: {e}")

    def expire(self):
        """Google hat das Token abgelehnt (401): nicht weiter benutzen."""
        with self.lock:
            had = bool(self.token)
            self.token, self.expires_at = "", 0.0
        if had:
            log("Token von Google abgelehnt (401), neue Anmeldung nötig")
        self._forget_file()

    def clear(self):
        with self.lock:
            self.token, self.expires_at, self.scope = "", 0.0, ""
        self._forget_file()

    # --- Anmeldeversuche
    def start(self, scope, force):
        """Gibt ein Dict zurück: status ok (mit Token) oder pending (mit state)."""
        with self.lock:
            if not force and self.valid() and self.has_scopes(scope):
                return {"status": "ok", "token": self.token, "expires_in": int(self.expires_at - time.time()), "scope": self.scope}
            cur = self.logins.get(self.current_state)
            if cur and not force and cur["result"] is None and time.time() - cur["t0"] < LOGIN_TIMEOUT - 10 and cur["scope"] == scope:
                return {"status": "pending", "state": cur["state"]}
            state = secrets.token_urlsafe(24)
            if cur and cur["result"] is None:
                cur["result"] = {"status": "superseded", "state": state}
            self.logins[state] = {"state": state, "t0": time.time(), "scope": scope, "result": None}
            self.current_state = state
            # alte Einträge aufräumen
            for k in [k for k, v in self.logins.items() if time.time() - v["t0"] > 900]:
                self.logins.pop(k, None)
        log(f"Anmeldeversuch gestartet ({'neu erzwungen' if force else 'nötig'})")
        if self.on_login:
            try:
                self.on_login(state, scope)
            except Exception as e:
                self.fail(state, f"Browser nicht geöffnet: {e}")
        return {"status": "pending", "state": state}

    def wait(self, state):
        with self.lock:
            lg = self.logins.get(state)
            if not lg:
                return {"status": "fail", "message": "Unbekannter Anmeldeversuch"}
            if lg["result"] is None:
                if time.time() - lg["t0"] > LOGIN_TIMEOUT:
                    lg["result"] = {"status": "fail", "message": "Zeit abgelaufen (5 Minuten)"}
                else:
                    return {"status": "pending"}
            r = lg["result"]
            if r["status"] == "ok":
                return {"status": "ok", "token": self.token, "expires_in": int(self.expires_at - time.time()), "scope": self.scope}
            return r

    def fail(self, state, message):
        with self.lock:
            lg = self.logins.get(state)
            if lg and lg["result"] is None:
                lg["result"] = {"status": "fail", "message": message}
        log(f"Anmeldung fehlgeschlagen: {message}")

    def handoff(self, state, token, expires_in, scope):
        with self.lock:
            lg = self.logins.get(state)
            if not lg or lg["result"] is not None or time.time() - lg["t0"] > LOGIN_TIMEOUT + 30:
                return False
        self.store(token, expires_in, scope)
        with self.lock:
            lg["result"] = {"status": "ok"}
        log("Anmeldung erfolgreich (Token erhalten, Gültigkeit %s s)" % expires_in)
        return True


# ---------------------------------------------------------------- Verbindung zu Google
class _Verbindung(http.client.HTTPSConnection):
    """HTTPS mit IPv4 zuerst und kurzer Wartezeit je Adresse; unterstützt einen Proxy-Tunnel."""

    def connect(self):
        if self._tunnel_host:
            return super().connect()
        infos = socket.getaddrinfo(self.host, self.port, 0, socket.SOCK_STREAM)
        infos.sort(key=lambda i: 0 if i[0] == socket.AF_INET else 1)
        last = None
        for fam, typ, proto, _c, addr in infos:
            s = None
            try:
                s = socket.socket(fam, typ, proto)
                s.settimeout(6)
                s.connect(addr)
                s.settimeout(self.timeout)
                self.sock = self._context.wrap_socket(s, server_hostname=self.host)
                return
            except Exception as e:
                last = e
                if s:
                    s.close()
        raise last or OSError("Keine Adresse")


class ConnErr(OSError):
    """Verbindungsaufbau gescheitert, es wurde nichts gesendet."""


def google_request(method, url, headers, body, timeout=60):
    """Gibt (status, header_dict, bytes) zurück; wirft OSError bei Netzfehlern."""
    p = urllib.parse.urlsplit(url)
    path = p.path + ("?" + p.query if p.query else "")
    if GOOGLE_BASE:
        b = urllib.parse.urlsplit(GOOGLE_BASE)
        conn = http.client.HTTPConnection(b.hostname, b.port, timeout=timeout)
    else:
        proxy = os.environ.get("HTTPS_PROXY") or os.environ.get("https_proxy")
        ctx = ssl.create_default_context()
        if proxy:
            pp = urllib.parse.urlsplit(proxy if "://" in proxy else "http://" + proxy)
            conn = _Verbindung(pp.hostname, pp.port or 3128, timeout=timeout, context=ctx)
            conn.set_tunnel(p.hostname, 443)
        else:
            conn = _Verbindung(p.hostname, 443, timeout=timeout, context=ctx)
    try:
        try:
            conn.connect()
        except Exception as e:
            raise ConnErr(e)
        conn.request(method, path, body=body, headers=headers)
        r = conn.getresponse()
        data = r.read()
        return r.status, {k.lower(): v for k, v in r.getheaders()}, data
    finally:
        try:
            conn.close()
        except Exception:
            pass


# ---------------------------------------------------------------- Lokale Kopie der Google-Daten
class Kopie:
    TABS = ("Tasks", "Log", "Projects", "Notes", "Links")

    def __init__(self):
        self.snap = {}
        self.lock = threading.Lock()
        self.last_day = ""
        self.timer = None

    def feed(self, url, status, data):
        if status != 200:
            return
        m = re.search(r"/v4/spreadsheets/([^/]+)/values/([A-Za-z]+)(?:!|%21)([A-Za-z0-9:]+)", url)
        if not m or m.group(2) not in self.TABS:
            return
        try:
            vals = json.loads(data.decode("utf-8")).get("values", [])
        except Exception:
            return
        tab, rng = m.group(2), m.group(3)
        with self.lock:
            # je Blatt und Bereich getrennt halten: eine Abfrage nur der Kopfzeile ersetzt nicht die Daten
            self.snap[tab + "!" + rng] = {"sheet": m.group(1), "values": vals}
            today = date.today().isoformat()
            have = lambda t: any(k.startswith(t + "!A2") for k in self.snap)
            if self.last_day != today and not self.timer and have("Tasks") and have("Log"):
                # kurz warten, damit auch Projekte, Notizen und Links des Startvorgangs enthalten sind
                self.timer = threading.Timer(float(os.environ.get("SEIFFERT_TODO_KOPIE_WARTEN", "12")), self._late)
                self.timer.daemon = True
                self.timer.start()

    def _late(self):
        with self.lock:
            self.timer = None
            self._write(date.today().isoformat())

    def _write(self, today):
        f = KOPIEN_DIR / f"todo-kopie-{today}.json"
        if f.exists():
            self.last_day = today
            return
        try:
            atomic_write(f, json.dumps({"app": "seiffert-todo", "zeit": now_iso(), "bereiche": self.snap}, ensure_ascii=False))
            self.last_day = today
            log(f"Lokale Kopie geschrieben: {f.name}")
            files = sorted(KOPIEN_DIR.glob("todo-kopie-*.json"))
            for old in files[:-30]:
                old.unlink()
        except Exception as e:
            log(f"Lokale Kopie nicht geschrieben: {e}")


# ---------------------------------------------------------------- HTTP-Server
class App:
    def __init__(self, html_path=None, ask_login=None):
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        self.settings = Settings()
        self.store = LocalStore()
        self.auth = Auth(self.settings)
        self.kopie = Kopie()
        self.secret = secrets.token_urlsafe(18)
        self.html_path = Path(html_path) if html_path else None
        self._bild_fehlt = set()
        self.bild_holen = None   # Testhook
        self.httpd = None
        self.port = 0
        self.shim_early = (PKG_DIR / "shim_early.js").read_text("utf-8")
        self.shim_late = (PKG_DIR / "shim_late.js").read_text("utf-8")

    # --- HTML vorbereiten
    def page(self):
        path = self.html_path or (PKG_DIR / "index.html")
        s = path.read_text("utf-8")
        s = re.sub(r'<script[^>]*src="https://accounts\.google\.com/gsi/client"[^>]*></script>', "<!-- gsi/client entfernt -->", s)
        cfg = {
            "base": f"/{self.secret}/",
            "ls": self.store.snapshot(),
            "autoLogin": bool(self.settings.get("auto_anmelden")),
            "auth": self.auth.info(),
        }
        cfg_js = json.dumps(cfg, ensure_ascii=False).replace("</", "<\\/")
        head = f"<script>window.__LINUX={cfg_js};</script><script>{self.shim_early}</script>"
        if "<head>" in s:
            s = s.replace("<head>", "<head>" + head, 1)
        else:
            s = head + s
        late = f"<script>{self.shim_late}</script>"
        i = s.rfind("</body>")
        s = (s[:i] + late + s[i:]) if i >= 0 else s + late
        return s

    # --- Bilder der Seite (Logo im Kopf, Symbole): Paket, dann Zwischenspeicher, dann veröffentlichte Seite, sonst Logo
    BILD_TYPEN = {"png": "image/png", "ico": "image/x-icon", "svg": "image/svg+xml", "jpg": "image/jpeg",
                  "jpeg": "image/jpeg", "webp": "image/webp", "gif": "image/gif"}

    def bild(self, name):
        ctype = self.BILD_TYPEN.get(name.rsplit(".", 1)[-1].lower(), "application/octet-stream")
        cache = DATA_DIR / "bilder" / name
        for f in (PKG_DIR / "bilder" / name, cache):
            try:
                if f.is_file():
                    return f.read_bytes(), ctype
            except Exception:
                pass
        base, err = clean_handoff_url(os.environ.get("SEIFFERT_TODO_HANDOFF_URL") or self.settings.get("handoff_url") or "")
        if base and not err and name not in self._bild_fehlt:
            p = urllib.parse.urlsplit(base)
            ordner = p.path if "." not in p.path.rsplit("/", 1)[-1] else p.path.rsplit("/", 1)[0]   # Adresse ohne Dateinamen ist selbst der Ordner
            url = urllib.parse.urlunsplit((p.scheme, p.netloc, ordner.rstrip("/") + "/" + name, "", ""))
            try:
                st, rh, data = (self.bild_holen or google_request)("GET", url, {"Accept-Encoding": "identity"}, None, 8)
                if st == 200 and data and len(data) < 3_000_000 and rh.get("content-type", "").startswith("image/"):
                    cache.parent.mkdir(parents=True, exist_ok=True)
                    cache.write_bytes(data)
                    log(f"Bild von der veröffentlichten Seite geholt: {name}")
                    return data, ctype
                log(f"Bild {name} nicht auf der veröffentlichten Seite (Status {st})")
            except Exception as e:
                log(f"Bild {name} nicht geholt: {type(e).__name__}")
            self._bild_fehlt.add(name)
        return (PKG_DIR / "icons" / "seiffert-todo-256.png").read_bytes(), "image/png"   # Ersatz: Logo Seiffert Apps

    def start(self):
        app = self

        class H(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"
            server_version = "SeiffertsToDo"

            def log_message(self, *a):
                pass

            # -- Hilfen
            def _host_ok(self):
                h = (self.headers.get("Host") or "").lower()
                return h in (f"127.0.0.1:{app.port}", f"localhost:{app.port}")

            def _send(self, code, body=b"", ctype="text/plain; charset=utf-8", extra=None):
                if isinstance(body, str):
                    body = body.encode("utf-8")
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Content-Type-Options", "nosniff")
                for k, v in (extra or {}).items():
                    self.send_header(k, v)
                self.end_headers()
                if self.command != "HEAD" and code not in (204, 304):
                    self.wfile.write(body)

            def _json(self, obj, code=200):
                self._send(code, json.dumps(obj, ensure_ascii=False), "application/json; charset=utf-8")

            def _body(self):
                n = int(self.headers.get("Content-Length") or 0)
                return self.rfile.read(n) if n > 0 else b""

            # -- GET
            def do_GET(self):
                if not self._host_ok():
                    return self._send(403, "Host nicht erlaubt")
                u = urllib.parse.urlsplit(self.path)
                if u.path == "/handoff":
                    return self._handoff(u)
                if u.path == "/handoff-done":
                    return self._send(200, HANDOFF_OK, "text/html; charset=utf-8")
                pre = f"/{app.secret}/"
                if not u.path.startswith(pre):
                    return self._send(404, "nicht gefunden")
                rest = u.path[len(pre):]
                q = urllib.parse.parse_qs(u.query)
                if rest in ("", "index.html"):
                    return self._send(200, app.page(), "text/html; charset=utf-8")
                if re.fullmatch(r"[A-Za-z0-9._-]{1,80}\.(png|ico|svg|jpg|jpeg|webp|gif)", rest):
                    data, ctype = app.bild(rest)
                    return self._send(200, data, ctype)
                if rest == "api/auth":
                    return self._json(app.auth.info())
                if rest == "api/login/wait":
                    return self._json(app.auth.wait((q.get("state") or [""])[0]))
                return self._send(404, "nicht gefunden")

            # -- POST
            def do_POST(self):
                if not self._host_ok():
                    return self._send(403, "Host nicht erlaubt")
                u = urllib.parse.urlsplit(self.path)
                pre = f"/{app.secret}/"
                if not u.path.startswith(pre):
                    return self._send(404, "nicht gefunden")
                rest = u.path[len(pre):]
                body = self._body()
                if rest == "api/g":
                    return self._google(body)
                try:
                    j = json.loads(body.decode("utf-8")) if body else {}
                except Exception:
                    return self._send(400, "JSON erwartet")
                if rest == "api/ls":
                    app.store.apply(j)
                    return self._json({"ok": True})
                if rest == "api/login/start":
                    return self._json(app.auth.start(str(j.get("scope") or ""), bool(j.get("force"))))
                if rest == "api/login/expired":
                    app.auth.expire()
                    return self._json({"ok": True})
                if rest == "api/logout":
                    app.auth.clear()
                    log("Abgemeldet")
                    return self._json({"ok": True})
                if rest == "api/log":
                    log("Seite: " + str(j.get("msg", ""))[:300])
                    return self._json({"ok": True})
                return self._send(404, "nicht gefunden")

            do_PUT = do_POST

            # -- Google
            def _google(self, body):
                url = urllib.parse.unquote(self.headers.get("X-G-Url") or "")
                method = (self.headers.get("X-G-Method") or "GET").upper()
                try:
                    hdrs_in = json.loads(urllib.parse.unquote(self.headers.get("X-G-Headers") or "{}"))
                except Exception:
                    hdrs_in = {}
                p = urllib.parse.urlsplit(url)
                if p.scheme != "https" or (p.hostname or "").lower() not in ALLOWED_HOSTS:
                    log(f"Gesperrte Adresse: {p.hostname}")
                    return self._send(403, "Adresse nicht erlaubt")
                if method not in ("GET", "POST", "PUT", "PATCH", "DELETE"):
                    return self._send(405, "Methode nicht erlaubt")
                headers = {k: v for k, v in hdrs_in.items() if k.lower() in FORWARD_HEADERS}
                headers["Accept-Encoding"] = "identity"
                if app.auth.token:
                    headers["Authorization"] = "Bearer " + app.auth.token   # immer das aktuelle Token verwenden
                else:
                    auth = hdrs_in.get("Authorization") or hdrs_in.get("authorization")
                    if auth:
                        headers["Authorization"] = auth
                if body or method in ("POST", "PUT", "PATCH"):
                    headers["Content-Length"] = str(len(body))
                last = None
                st = None
                for attempt in range(2):
                    try:
                        st, rh, data = google_request(method, url, headers, body or None)
                        break
                    except ConnErr as e:          # nichts gesendet: sicher wiederholbar
                        last = e
                    except (OSError, http.client.HTTPException) as e:
                        last = e
                        if method != "GET":        # Änderungen nicht blind wiederholen
                            break
                    time.sleep(0.5)
                if st is None:
                    log(f"Netzfehler {method} {p.path[:80]}: {type(last).__name__}")
                    return self._send(502, "Netzfehler", extra={"X-G-Netfail": "1"})
                if st >= 400:
                    log(f"Google {st} {method} {p.path[:90]}")
                app.kopie.feed(url, st, data) if method == "GET" else None
                if "content-type" in rh:
                    ctype = rh["content-type"]
                else:
                    ctype = "application/octet-stream"
                self.send_response(st)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(data) if st not in (204, 304) else 0))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                if st not in (204, 304):
                    self.wfile.write(data)

            # -- Übergabe des Tokens aus dem Browser
            def _handoff(self, u):
                q = urllib.parse.parse_qs(u.query)
                g = lambda k: (q.get(k) or [""])[0]
                state = g("state")
                if g("error"):
                    app.auth.fail(state, "Google: " + g("error")[:80])
                    return self._send(200, HANDOFF_FAIL.replace("@@", g("error")[:80]), "text/html; charset=utf-8")
                tok = g("access_token")
                if not tok or not re.fullmatch(r"[A-Za-z0-9._~+/=-]{20,2048}", tok):
                    return self._send(400, "Token fehlt oder ist ungültig")
                try:
                    exp = int(g("expires_in") or 3600)
                except ValueError:
                    exp = 3600
                ok = app.auth.handoff(state, tok, min(max(exp, 60), 7200), g("scope"))
                if not ok:
                    return self._send(400, HANDOFF_OLD, "text/html; charset=utf-8")
                # Token aus der Adresszeile entfernen
                self.send_response(303)
                self.send_header("Location", "/handoff-done")
                self.send_header("Content-Length", "0")
                self.send_header("Cache-Control", "no-store")
                self.end_headers()

        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.httpd.daemon_threads = True
        self.port = self.httpd.server_address[1]
        t = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        t.start()
        log(f"Server gestartet auf 127.0.0.1:{self.port}")
        return self.port

    def url(self):
        return f"http://127.0.0.1:{self.port}/{self.secret}/"

    def stop(self):
        try:
            self.store.flush()
            self.httpd.shutdown()
        except Exception:
            pass


_STYLE = "font-family:sans-serif;max-width:32em;margin:15vh auto;padding:0 1em;text-align:center"
HANDOFF_OK = f"""<!doctype html><meta charset=utf-8><title>Seifferts ToDo</title>
<body style="{_STYLE}"><h2>Angemeldet</h2><p>Die Linux-App hat die Anmeldung erhalten. Du kannst diesen Tab schließen.</p>
<script>setTimeout(function(){{try{{window.close()}}catch(e){{}}}},800)</script></body>"""
HANDOFF_FAIL = f"""<!doctype html><meta charset=utf-8><title>Seifferts ToDo</title>
<body style="{_STYLE}"><h2>Anmeldung nicht erfolgreich</h2><p>Google meldet: @@</p><p>Bitte in der Linux-App erneut auf Anmelden gehen.</p></body>"""
HANDOFF_OLD = f"""<!doctype html><meta charset=utf-8><title>Seifferts ToDo</title>
<body style="{_STYLE}"><h2>Dieser Anmeldeversuch ist nicht mehr gültig</h2><p>Bitte in der Linux-App erneut auf Anmelden gehen. Die Anmeldung hat dann einen neuen Versuch gestartet.</p></body>"""
