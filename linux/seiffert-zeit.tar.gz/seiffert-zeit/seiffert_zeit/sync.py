import secrets, threading, time, urllib.parse, webbrowser, subprocess
from .config import log
from .drive import Drive, DriveError


class Sync:
    def __init__(self, settings, store, port_getter):
        self.s, self.store, self.port = settings, store, port_getter
        self.drive = Drive()
        self.lock = threading.Lock()
        self.busy = False
        self.msg = ""
        self.error = False
        self.pending = None
        self.pending_t = 0
        self._timer = None

    # ---- Anmeldung ueber die veroeffentlichte Seite (GitHub Pages)
    def begin_login(self):
        url, cid = self.s.get("handoff_url"), self.s.get("client_id")
        if not url or not cid:
            return False
        self.pending = secrets.token_urlsafe(18)
        self.pending_t = time.time()
        q = urllib.parse.urlencode({"linuxport": self.port(), "linuxstate": self.pending, "linuxcid": cid})
        full = url + ("&" if "?" in url else "?") + q
        log("Anmeldung gestartet, Browser wird geoeffnet")
        try:
            if not webbrowser.open(full):
                raise OSError
        except Exception:
            try:
                subprocess.Popen(["xdg-open", full])
            except Exception as e:
                log("Browser nicht startbar: %s" % e)
        return True

    def accept_token(self, state, token, expires):
        if not self.pending or time.time() - self.pending_t > 600 or not secrets.compare_digest(state, self.pending):
            log("Token abgelehnt (Zustand passt nicht)")
            return False
        self.pending = None
        try:
            secs = int(float(expires))
        except Exception:
            secs = 3300
        self.drive.set_token(token, secs)
        self.msg, self.error = "", False
        log("Token erhalten (gilt etwa %d Minuten)" % (secs // 60))
        self.sync_async()
        return True

    # ---- Abgleich
    def sync_async(self, delay=0.0):
        if self._timer:
            self._timer.cancel()
        self._timer = threading.Timer(delay, self.run)
        self._timer.daemon = True
        self._timer.start()

    def on_change(self):
        if self.drive.valid():
            self.sync_async(5.0)

    def run(self):
        if not self.drive.valid():
            return {"need_login": True}
        if not self.lock.acquire(blocking=False):
            return {"busy": True}
        self.busy = True
        try:
            self._sync()
            self.error = False
            return {"ok": True}
        except DriveError as e:
            self.error = True
            self.msg = str(e) + (" (Anmeldung abgelaufen, bitte neu anmelden)" if e.status == 401 else "")
            return {"error": self.msg}
        except Exception as e:
            self.error = True
            self.msg = "Fehler beim Abgleich: %s" % type(e).__name__
            log("Abgleich Fehler: %r" % e)
            return {"error": self.msg}
        finally:
            self.busy = False
            self.lock.release()

    def _sync(self):
        d, st, s = self.drive, self.store, self.s
        folder = d.folder_id(True)
        remote = d.find(folder)
        last = s.get("drive_remote_modified")
        dirty = bool(s.get("drive_dirty")) or not last
        if remote is None:
            if st.is_empty():
                self._done("nichts zu sichern", None)
                return
            r = d.upload(folder, None, st.raw_bytes())
            self._done("Stand nach Drive geschrieben", r)
            return
        if st.is_empty():
            st.replace(st.parse(d.download(remote["id"])))
            self._done("Stand aus Drive geladen", remote)
            return
        if not dirty and remote["modifiedTime"] != last:
            st.replace(st.parse(d.download(remote["id"])))
            self._done("neueren Drive-Stand uebernommen", remote)
            return
        if not dirty:
            self._done("alles aktuell", remote, write=False)
            return
        if remote["modifiedTime"] != last:
            stamp = time.strftime("%Y-%m-%d-%H%M%S")
            d.copy(remote["id"], "zeit-daten-vor-ueberschreiben-%s.json" % stamp)
            log("Alter Drive-Stand als Kopie gesichert")
        r = d.upload(folder, remote["id"], st.raw_bytes())
        self._done("Stand nach Drive geschrieben", r)

    def _done(self, text, rec, write=True):
        upd = {"drive_last": time.strftime("%d.%m.%Y %H:%M")}
        if rec and rec.get("modifiedTime"):
            upd["drive_remote_modified"] = rec["modifiedTime"]
        if write:
            upd["drive_dirty"] = False
        self.s.set(**upd)
        self.msg = text
        log("Abgleich: %s" % text)

    def status(self):
        v = self.drive.valid()
        if self.busy:
            label = "Abgleich läuft"
        elif self.error:
            label = "Fehler"
        elif v:
            label = "verbunden" + (", Änderungen offen" if self.s.get("drive_dirty") else "")
        else:
            label = "anmelden" + (" (Änderungen offen)" if self.s.get("drive_dirty") and not self.store.is_empty() else "")
        return {"state": "ok" if v and not self.error else "login", "label": label, "last": self.s.get("drive_last"),
                "msg": self.msg, "handoff_url": self.s.get("handoff_url"), "client_set": bool(self.s.get("client_id"))}
