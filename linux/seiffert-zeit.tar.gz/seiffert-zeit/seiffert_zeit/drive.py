import json, os, time, urllib.error, urllib.parse, urllib.request
from .config import log

API = os.environ.get("SZ_DRIVE_API", "https://www.googleapis.com/drive/v3")
UPLOAD = os.environ.get("SZ_DRIVE_UPLOAD", "https://www.googleapis.com/upload/drive/v3")
FOLDER = "Seifferts Zeit"
FILE = "zeit-daten.json"


class DriveError(Exception):
    def __init__(self, status, msg):
        super().__init__(msg)
        self.status = status


class Drive:
    def __init__(self):
        self.token = None
        self.exp = 0.0

    def set_token(self, tok, secs):
        self.token = tok
        self.exp = time.time() + max(60, secs) - 60

    def valid(self):
        return bool(self.token) and time.time() < self.exp

    def _req(self, method, url, body=None, ctype=None, timeout=30, raw=False):
        h = {"Authorization": "Bearer " + (self.token or "")}
        if ctype:
            h["Content-Type"] = ctype
        req = urllib.request.Request(url, data=body, method=method, headers=h)
        path = urllib.parse.urlsplit(url).path
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                data = r.read()
            log("Drive %s %s -> 200" % (method, path))
            return data if raw else (json.loads(data) if data else {})
        except urllib.error.HTTPError as e:
            log("Drive %s %s -> %s" % (method, path, e.code))
            if e.code == 401:
                self.token = None
            raise DriveError(e.code, "Google antwortet mit Fehler %s" % e.code)
        except (urllib.error.URLError, OSError) as e:
            log("Drive %s %s -> Netzwerkfehler" % (method, path))
            raise DriveError(0, "Keine Verbindung zu Google")

    def _list(self, q, fields):
        url = API + "/files?" + urllib.parse.urlencode({"q": q, "fields": "files(%s)" % fields, "spaces": "drive", "pageSize": 10})
        return self._req("GET", url).get("files", [])

    def folder_id(self, create=True):
        fl = self._list("name='%s' and mimeType='application/vnd.google-apps.folder' and trashed=false" % FOLDER, "id,name")
        if fl:
            return fl[0]["id"]
        if not create:
            return None
        r = self._req("POST", API + "/files?fields=id", json.dumps({"name": FOLDER, "mimeType": "application/vnd.google-apps.folder"}).encode(), "application/json")
        return r["id"]

    def find(self, folder):
        fl = self._list("name='%s' and '%s' in parents and trashed=false" % (FILE, folder), "id,modifiedTime")
        return fl[0] if fl else None

    def download(self, fid):
        return self._req("GET", API + "/files/%s?alt=media" % fid, raw=True)

    def upload(self, folder, fid, data):
        b = "szb" + str(int(time.time() * 1000))
        meta = {"name": FILE} if fid else {"name": FILE, "parents": [folder]}
        body = ("--%s\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n%s\r\n--%s\r\nContent-Type: application/json\r\n\r\n" % (b, json.dumps(meta), b)).encode() + data + ("\r\n--%s--" % b).encode()
        ct = "multipart/related; boundary=" + b
        if fid:
            return self._req("PATCH", UPLOAD + "/files/%s?uploadType=multipart&fields=id,modifiedTime" % fid, body, ct)
        return self._req("POST", UPLOAD + "/files?uploadType=multipart&fields=id,modifiedTime", body, ct)

    def copy(self, fid, name):
        return self._req("POST", API + "/files/%s/copy?fields=id" % fid, json.dumps({"name": name}).encode(), "application/json")
