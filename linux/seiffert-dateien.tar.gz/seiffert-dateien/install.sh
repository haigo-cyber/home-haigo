#!/bin/sh
# Installiert Seifferts Dateien für den aktuellen Benutzer (ohne sudo).
# Aufruf im entpackten Ordner:  ./install.sh      Entfernen:  ./install.sh --remove
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
APP="${XDG_DATA_HOME:-$HOME/.local/share}/seiffert-dateien-app"
BIN="$HOME/.local/bin"
DESK="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
ICON="${XDG_DATA_HOME:-$HOME/.local/share}/icons/hicolor/scalable/apps"

if [ "$1" = "--remove" ]; then
  rm -rf "$APP" "$BIN/seiffert-dateien" "$DESK/seiffert-dateien.desktop" "$ICON/seiffert-dateien.svg"
  command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$DESK" 2>/dev/null || true
  echo "Entfernt. Einstellungen und Index bleiben in ~/.config/seiffert-dateien und ~/.local/share/seiffert-dateien."
  exit 0
fi

PY=python3
if ! $PY -c "from PySide6 import QtWebEngineWidgets, QtWebChannel" 2>/dev/null; then
  echo "Hinweis: PySide6 mit QtWebEngine wurde nicht gefunden." >&2
  echo "  Arch:  sudo pacman -S pyside6 qt6-webengine" >&2
  echo "  oder:  python3 -m venv --system-site-packages $APP/venv && $APP/venv/bin/pip install PySide6 PySide6-WebEngine" >&2
  echo "Die Dateien werden trotzdem installiert." >&2
fi
command -v soffice >/dev/null 2>&1 || echo "Hinweis: LibreOffice fehlt, alte Dateien (doc, xls, ppt) lassen sich im Volltext nicht lesen (optional)." >&2
command -v pdftotext >/dev/null 2>&1 || echo "Hinweis: pdftotext fehlt, PDFs bleiben im Volltext und in der Vorschau unberücksichtigt (Arch: sudo pacman -S poppler)." >&2

mkdir -p "$APP" "$BIN" "$DESK" "$ICON"
cp "$HERE/app.py" "$HERE/backend.py" "$HERE/fileops.py" "$HERE/terminal.py" "$HERE/index.html" "$HERE/seiffert-dateien.svg" "$APP/"
rm -rf "$APP/vendor" && cp -r "$HERE/vendor" "$APP/vendor"
cp "$HERE/seiffert-dateien.svg" "$ICON/seiffert-dateien.svg"
cat > "$BIN/seiffert-dateien" <<LAUNCH
#!/bin/sh
PY=python3
[ -x "$APP/venv/bin/python" ] && PY="$APP/venv/bin/python"
exec "\$PY" "$APP/app.py" "\$@"
LAUNCH
chmod +x "$BIN/seiffert-dateien"
cat > "$DESK/seiffert-dateien.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=Seifferts Dateien
GenericName=Dateien und Favoriten
Comment=Dateiverwaltung mit Terminal, Favoriten als Karussell, Dateinamen- und Volltextsuche
Exec=$BIN/seiffert-dateien %f
Icon=seiffert-dateien
Terminal=false
Categories=Utility;FileTools;
StartupWMClass=seiffert-dateien
DESKTOP
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$DESK" 2>/dev/null || true
echo "Fertig. Start über das Menü (Seifferts Dateien) oder mit:  $BIN/seiffert-dateien"
case ":$PATH:" in *":$BIN:"*) ;; *) echo "Hinweis: $BIN steht nicht in PATH. Das Menü funktioniert trotzdem." ;; esac
