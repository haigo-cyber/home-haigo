"""Dialog zur Verwaltung der Formatvorlagen (Seifferts Text 0.23)."""
import os
import shutil

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QDialog, QFileDialog, QHBoxLayout, QInputDialog, QLabel, QListWidget, QMessageBox,
                               QPlainTextEdit, QPushButton, QVBoxLayout)

from . import formatvorlage as fv
from .readers import find_soffice, ReaderError


def lo_template_dir():
    return os.path.join(os.path.expanduser("~"), ".config", "libreoffice", "4", "user", "template")


class FormatvorlagenDialog(QDialog):
    """Vorlagen anlegen (aus LaTeX), ansehen, umbenennen, löschen, als .ott/.dotx speichern, für ein neues Dokument wählen."""

    def __init__(self, main, store=None):
        super().__init__(main)
        self.main = main
        self.store = store
        self.chosen = None          # Name, wenn „Neues Dokument damit“ gewählt wurde
        self.setWindowTitle("Formatvorlagen")
        self.resize(820, 520)
        lay = QHBoxLayout(self)
        left = QVBoxLayout()
        lay.addLayout(left, 2)
        left.addWidget(QLabel("Gespeicherte Formatvorlagen:"))
        self.lst = QListWidget()
        self.lst.currentRowChanged.connect(self._show)
        self.lst.itemDoubleClicked.connect(lambda _i: self._new_doc())
        left.addWidget(self.lst, 1)
        b = QPushButton("Aus LaTeX-Datei erstellen …")
        b.clicked.connect(self._from_file)
        left.addWidget(b)
        self.b_cur = QPushButton("Aus dem LaTeX-Text dieses Tabs erstellen …")
        self.b_cur.clicked.connect(self._from_current)
        left.addWidget(self.b_cur)
        right = QVBoxLayout()
        lay.addLayout(right, 3)
        self.info = QLabel("")
        self.info.setWordWrap(True)
        self.info.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        right.addWidget(self.info)
        right.addWidget(QLabel("Bericht der Umwandlung (was erkannt und was nicht übernommen wurde):"))
        self.rep = QPlainTextEdit()
        self.rep.setReadOnly(True)
        right.addWidget(self.rep, 1)
        self.btns = []
        for text, fn in (("Neues Dokument mit dieser Vorlage", self._new_doc),
                         ("Auf das Dokument im aktuellen Tab anwenden", self._apply),
                         ("Als ODT-Vorlage (.ott) speichern …", self._save_ott),
                         ("Als Word-Vorlage (.dotx) speichern …", self._save_dotx),
                         ("In LibreOffice-Vorlagen ablegen", self._to_lo),
                         ("Umbenennen …", self._rename),
                         ("Löschen", self._delete)):
            b = QPushButton(text)
            b.clicked.connect(fn)
            right.addWidget(b)
            self.btns.append(b)
        c = QPushButton("Schließen")
        c.clicked.connect(self.reject)
        right.addWidget(c)
        self.reload()

    # ------------------------------------------------------------------
    def reload(self, select=None):
        self.items = fv.list_templates(self.store)
        self.lst.blockSignals(True)
        self.lst.clear()
        for sp in self.items:
            self.lst.addItem(sp["name"])
        self.lst.blockSignals(False)
        row = 0
        if select:
            for i, sp in enumerate(self.items):
                if sp["name"] == select:
                    row = i
        if self.items:
            self.lst.setCurrentRow(row)
        else:
            self._show(-1)

    def current(self):
        r = self.lst.currentRow()
        return self.items[r] if 0 <= r < len(self.items) else None

    def _show(self, _row):
        sp = self.current()
        for b in self.btns:
            b.setEnabled(sp is not None)
        if sp is None:
            self.info.setText("Noch keine Formatvorlage. Mit „Aus LaTeX-Datei erstellen“ wird aus der Präambel einer "
                              "LaTeX-Datei (Seitenränder, Schrift, Überschriften, Kopf- und Fußzeile …) eine Vorlage.")
            self.rep.setPlainText("")
            return
        self.info.setText("<b>%s</b><br>%s" % (sp["name"], fv.summary(sp)))
        self.rep.setPlainText("\n\n".join(sp.get("report", [])))

    # ------------------------------------------------------------------
    def _ask_name(self, default):
        name, ok = QInputDialog.getText(self, "Formatvorlage", "Name der Formatvorlage:", text=default)
        name = name.strip()
        if not ok or not name:
            return None
        if os.path.exists(fv.path_of(name, self.store)):
            if QMessageBox.question(self, "Formatvorlage", "„%s“ gibt es schon. Überschreiben?" % name) != QMessageBox.StandardButton.Yes:
                return None
        return name

    def _make(self, tex, default):
        name = self._ask_name(default)
        if not name:
            return
        try:
            sp = fv.spec_from_latex(tex, name)
            fv.save_template(sp, self.store)
        except Exception as e:      # noqa: BLE001 - Meldung an den Benutzer
            QMessageBox.warning(self, "Formatvorlage", "Die LaTeX-Vorgabe ließ sich nicht auslesen:\n%s" % e)
            return
        self.reload(name)

    def _from_file(self):
        start = os.path.dirname(self.main.path) if getattr(self.main, "path", None) else os.path.expanduser("~")
        p, _ = QFileDialog.getOpenFileName(self, "LaTeX-Vorgabe wählen", start, "LaTeX (*.tex *.cls *.sty);;Alle Dateien (*)")
        if not p:
            return
        try:
            with open(p, "rb") as f:
                raw = f.read()
            try:
                tex = raw.decode("utf-8")
            except UnicodeDecodeError:
                tex = raw.decode("latin-1")
        except OSError as e:
            QMessageBox.warning(self, "Formatvorlage", str(e))
            return
        self._make(tex, os.path.splitext(os.path.basename(p))[0])

    def _from_current(self):
        try:
            tex = self.main.current_latex()
        except Exception as e:      # noqa: BLE001
            QMessageBox.warning(self, "Formatvorlage", "Der LaTeX-Text lässt sich nicht bilden:\n%s" % e)
            return
        base = os.path.splitext(os.path.basename(self.main.path))[0] if getattr(self.main, "path", None) else "Vorlage"
        self._make(tex, base)

    def _new_doc(self):
        sp = self.current()
        if sp:
            self.chosen = sp["name"]
            self.accept()

    def _apply(self):
        sp = self.current()
        if sp and self.main.apply_format(sp):
            self.accept()

    def _save_ott(self):
        sp = self.current()
        if not sp:
            return
        p, _ = QFileDialog.getSaveFileName(self, "ODT-Vorlage speichern", os.path.join(os.path.expanduser("~"), sp["name"] + ".ott"),
                                           "ODT-Vorlage (*.ott)")
        if p:
            if not p.lower().endswith(".ott"):
                p += ".ott"
            fv.write_ott(sp, p)
            QMessageBox.information(self, "Formatvorlage", "Gespeichert: " + p)

    def _save_dotx(self):
        sp = self.current()
        if not sp:
            return
        if not find_soffice():
            QMessageBox.warning(self, "Formatvorlage", "Für Word-Vorlagen wird LibreOffice benötigt. Es wurde nicht gefunden.")
            return
        p, _ = QFileDialog.getSaveFileName(self, "Word-Vorlage speichern", os.path.join(os.path.expanduser("~"), sp["name"] + ".dotx"),
                                           "Word-Vorlage (*.dotx)")
        if not p:
            return
        if not p.lower().endswith(".dotx"):
            p += ".dotx"
        try:
            fv.write_dotx(sp, p)
        except ReaderError as e:
            QMessageBox.warning(self, "Formatvorlage", str(e))
            return
        QMessageBox.information(self, "Formatvorlage", "Gespeichert: " + p)

    def _to_lo(self):
        sp = self.current()
        if not sp:
            return
        d = lo_template_dir()
        try:
            os.makedirs(d, exist_ok=True)
            fv.write_ott(sp, os.path.join(d, fv._safe(sp["name"]) + ".ott"))
        except OSError as e:
            QMessageBox.warning(self, "Formatvorlage", str(e))
            return
        QMessageBox.information(self, "Formatvorlage",
                                "Abgelegt in %s. In LibreOffice erscheint sie beim nächsten Start unter Datei, Neu, Vorlagen "
                                "(im Ordner Standard oder Meine Vorlagen)." % d)

    def _rename(self):
        sp = self.current()
        if not sp:
            return
        new = self._ask_name(sp["name"])
        if not new or new == sp["name"]:
            return
        old = sp["name"]
        sp["name"] = new
        fv.save_template(sp, self.store)
        fv.delete_template(old, self.store)
        self.reload(new)

    def _delete(self):
        sp = self.current()
        if sp and QMessageBox.question(self, "Formatvorlage", "„%s“ löschen?" % sp["name"]) == QMessageBox.StandardButton.Yes:
            fv.delete_template(sp["name"], self.store)
            self.reload()
