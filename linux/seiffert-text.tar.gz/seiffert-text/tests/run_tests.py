"""Testlauf für Seifferts Text (ohne Bildschirm):  QT_QPA_PLATFORM=offscreen python tests/run_tests.py
Benötigt für einzelne Prüfungen pdflatex und LibreOffice (fehlen sie, werden die Prüfungen übersprungen)."""
import os
import shutil
import subprocess
import sys
import tempfile

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from PySide6.QtCore import QEventLoop, QTimer
from PySide6.QtGui import QColor, QImage, QTextCursor
from PySide6.QtWidgets import QApplication

app = QApplication([])
from seiffert_text.app import MainWindow, VIEW_MD, VIEW_RICH, VIEW_TEX
from seiffert_text.builder import build_document
from seiffert_text.latex_in import parse_latex
from seiffert_text.latex_out import export_latex
from seiffert_text.odt_out import write_odt
from seiffert_text.readers import find_soffice, read_any

TMP = tempfile.mkdtemp(prefix="st-test-")
OK = FAIL = SKIP = 0


def check(name, cond, extra=""):
    global OK, FAIL
    if cond:
        OK += 1
    else:
        FAIL += 1
        print("FEHLER:", name, extra)


def body(t):
    return t[t.index("\\begin{document}"):]


def pump(ms=200):
    l = QEventLoop()
    QTimer.singleShot(ms, l.quit)
    l.exec()


SRC = r"""\section{Titel}
\subsection*{Ohne Nummer}
Text mit \textbf{fett}, \emph{kursiv}, \underline{unter}, x\textsuperscript{2}, \texttt{Code} und \href{https://example.org}{Link}\footnote{Fußnote 50\%.}.
Neue Zeile\\
nach Umbruch, M\"uller und $a^2+b^2$.

\begin{itemize}
\item Eins
\item Zwei
 \begin{enumerate}
 \item A
 \item B
 \end{enumerate}
\item Drei
\end{itemize}

\begin{center}
\begin{tabular}{|l|l|}
\hline
x & y \\
\hline
\multicolumn{2}{|l|}{Verbunden} \\
\hline
1 & 2 \\
\hline
\end{tabular}
\end{center}
\begin{quote}Ein Zitat\end{quote}
\begin{verbatim}
print("hi")
\end{verbatim}
\[ E = mc^2 \]
\begin{figure}[h]\caption{Unbekannt}\end{figure}
"""

# 1. LaTeX -> Dokument -> LaTeX ist stabil
pre, blocks = parse_latex(SRC)
doc = build_document(blocks)
t1, _ = export_latex(doc, pre)
pre2, b2 = parse_latex(t1)
t2, _ = export_latex(build_document(b2), pre2)
check("LaTeX-Rundlauf stabil", t1 == t2)
check("Rohtext bleibt (Formel, figure)", "\\[ E = mc^2 \\]" in t1 and "\\caption{Unbekannt}" in t1)
check("Fußnote bleibt", "\\footnote{Fußnote 50\\%.}" in t1)
check("Umlaut umgewandelt", "Müller" in t1)

# 2. ODT: schreiben, lesen, gleiche LaTeX-Ausgabe
write_odt(doc, os.path.join(TMP, "a.odt"))
r = read_any(os.path.join(TMP, "a.odt"))
t3, _ = export_latex(build_document(r.blocks), pre)
check("ODT-Rundlauf gleich", body(t3) == body(t1), "\n".join(__import__("difflib").unified_diff(body(t1).splitlines(), body(t3).splitlines(), lineterm="")))

# 3. Fremdformate über LibreOffice erzeugen und lesen
if find_soffice():
    for ext in ("docx", "doc", "rtf"):
        subprocess.run([find_soffice(), "-env:UserInstallation=file:///tmp/st-lo", "--headless", "--convert-to", ext,
                        "--outdir", TMP, os.path.join(TMP, "a.odt")], capture_output=True, timeout=240)
        p = os.path.join(TMP, "a." + ext)
        if os.path.exists(p):
            tt, _ = export_latex(build_document(read_any(p).blocks))
            check("%s: Überschrift, fett, Liste, Tabelle" % ext, all(k in tt for k in
                  ("\\section{Titel}", "\\textbf{fett}", "\\begin{itemize}", "\\begin{tabular}", "\\multicolumn{2}")))
        else:
            check("%s erzeugt" % ext, False)
else:
    SKIP += 1

# 4. Tabellenkalkulation
try:
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Umsatz"
    ws.append(["Monat", "Betrag"])
    ws.append(["Jan", 1234.5])
    ws["B2"].number_format = '#,##0.00 "€"'
    wb.save(os.path.join(TMP, "t.xlsx"))
    tt, _ = export_latex(build_document(read_any(os.path.join(TMP, "t.xlsx")).blocks))
    check("xlsx: Blatt und Zahlenformat", "\\subsection{Umsatz}" in tt and "1.234,50 €" in tt)
    if find_soffice():
        for ext in ("ods", "xls"):
            subprocess.run([find_soffice(), "-env:UserInstallation=file:///tmp/st-lo", "--headless", "--convert-to", ext,
                            "--outdir", TMP, os.path.join(TMP, "t.xlsx")], capture_output=True, timeout=240)
            tt, _ = export_latex(build_document(read_any(os.path.join(TMP, "t." + ext)).blocks))
            check(ext + ": Tabelle", "\\begin{tabular}" in tt and "Jan" in tt)
except ImportError:
    SKIP += 1

# 5. Oberfläche: Ansichten, Umwandlung, Übersetzen
w = MainWindow()
w.show()
w.rich.textCursor().insertText("Hallo")
w.set_para(1)
w.set_view(VIEW_MD)
check("Markdown aus Formatiert", w.md_edit.toPlainText().startswith("# Hallo"))
w.md_edit.setPlainText("# Neu\n\nText *kursiv*\n\n- a\n- b\n")
w.set_view(VIEW_TEX)
check("LaTeX aus Markdown", "\\section{Neu}" in w.tex_edit.toPlainText() and "\\textit{kursiv}" in w.tex_edit.toPlainText())
w.tex_edit.setPlainText(w.tex_edit.toPlainText().replace("Text", "Text $x^2$ \\newpage"))
w.set_view(VIEW_RICH)
w.set_view(VIEW_TEX)
check("Rohtext bleibt über Ansichtswechsel", "$x^2$" in w.tex_edit.toPlainText() and "\\newpage" in w.tex_edit.toPlainText())
if shutil.which("pdflatex"):
    w.compile()
    for _ in range(100):
        pump(300)
        if w.proc is None:
            break
    check("Übersetzen ergibt PDF", os.path.exists(os.path.join(w.work, "main.pdf")), w.log.toPlainText()[:300])
else:
    SKIP += 1
for ext in (".odt", ".md", ".tex"):
    check("Speichern " + ext, w.save_to(os.path.join(TMP, "u" + ext)) and os.path.getsize(os.path.join(TMP, "u" + ext)) > 20)
w.modified = False
w.close()
w2 = MainWindow()
w2.open_file(os.path.join(TMP, "u.tex"))
check("tex geöffnet in LaTeX-Ansicht", w2.view == VIEW_TEX and w2.path.endswith("u.tex"))
w2.open_file(os.path.join(TMP, "u.md"))
check("md geöffnet in Markdown-Ansicht", w2.view == VIEW_MD)
w2.open_file(os.path.join(TMP, "u.odt"))
check("odt geöffnet in formatierter Ansicht", w2.view == VIEW_RICH)
if os.path.exists(os.path.join(TMP, "a.docx")):
    w2.open_file(os.path.join(TMP, "a.docx"))
    check("docx wird als LaTeX gezeigt", w2.view == VIEW_TEX and w2.path is None)
w2.modified = False
w2.close()
shutil.rmtree(TMP, ignore_errors=True)
print("Ergebnis: %d Prüfungen ok, %d Fehler, %d übersprungen" % (OK, FAIL, SKIP))
sys.exit(1 if FAIL else 0)
