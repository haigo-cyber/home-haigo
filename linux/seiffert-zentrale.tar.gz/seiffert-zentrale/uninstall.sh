#!/usr/bin/env bash
# Entfernt Seifferts Zentrale. Die Einstellungen (~/.config/seiffert-zentrale) und die anderen Programme bleiben unberührt.
set -u
DATA="${XDG_DATA_HOME:-$HOME/.local/share}"
CONF="${XDG_CONFIG_HOME:-$HOME/.config}"
chmod -R u+w "$DATA/seiffert-zentrale/app" 2>/dev/null
rm -rf "$DATA/seiffert-zentrale/app" "$DATA/seiffert-zentrale/venv" "$HOME/.local/bin/seiffert-zentrale" "$DATA/applications/seiffert-zentrale.desktop" "$CONF/seiffert-dateien/befehle.d/zentrale.json"
for n in 16 22 24 32 48 64 128 256; do rm -f "$DATA/icons/hicolor/${n}x${n}/apps/seiffert-zentrale.png"; done
echo "Seifferts Zentrale entfernt."
