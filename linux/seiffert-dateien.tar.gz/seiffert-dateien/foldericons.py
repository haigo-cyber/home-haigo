"""Ordner-Icons von Seifferts Dateien für den Starter: dieselben sechs Stile und drei Farbmodi wie in index.html (folderMarkup, folderBase).

Die Zeichenroutine ist eine genaue Übertragung der JavaScript-Funktion; ui_v22 vergleicht beide Ausgaben Zeichen für Zeichen.
Nur Standardbibliothek, damit sie ohne Oberfläche getestet werden kann.
"""
from __future__ import annotations

import math

STYLES = ("klassisch", "flach", "mappe", "offen", "glas", "etikett")
COLORS = ("design", "bunt", "gelb")
PALETTE = ["#e0a23a", "#d9774a", "#c8566b", "#a56bc4", "#6b83d6", "#3f9bc4", "#3aa89a", "#5aa65a", "#9aab45", "#c28b5c"]


def _round(v: float) -> int:
    """Math.round aus JavaScript (halbe Werte nach oben), nicht das kaufmännische Runden von Python."""
    return int(math.floor(v + 0.5))


def rgb_of(hexs: str) -> list[int]:
    h = hexs.strip().lstrip("#")
    return [int(h[i:i + 2], 16) for i in (0, 2, 4)]


def hx(c) -> str:
    return "#" + "".join("%02x" % max(0, min(255, _round(v))) for v in c)


def tone(hexs: str, k: float) -> str:
    rgb = rgb_of(hexs)
    return hx([v * (1 + k) for v in rgb]) if k < 0 else hx([v + (255 - v) * k for v in rgb])


def js_hash(name: str) -> int:
    h = 0
    for ch in str(name or ""):
        h = (h * 31 + ord(ch)) & 0xFFFFFFFF
    return h


def base_color(name: str, mode: str, accent_dark: str) -> str:
    """Grundfarbe eines Ordners. Der Starter hat eine dunkle Fläche, deshalb gilt immer die dunkle Variante des Farbdesigns."""
    if mode == "gelb":
        return "#e3b04b"
    if mode == "bunt":
        return PALETTE[js_hash(name) % len(PALETTE)]
    return accent_dark


def markup(style: str, base: str) -> str:
    dk, dk2, lt, pale = tone(base, -0.3), tone(base, -0.48), tone(base, 0.4), tone(base, 0.78)
    ident = "fg" + style + base[1:]
    BACK = "M5 13a5 5 0 0 1 5-5h14.5a4 4 0 0 1 3 1.4L33 15h21a5 5 0 0 1 5 5v31a5 5 0 0 1-5 5H10a5 5 0 0 1-5-5z"
    FRONT = "M5 27a5 5 0 0 1 5-5h44a5 5 0 0 1 5 5v24a5 5 0 0 1-5 5H10a5 5 0 0 1-5-5z"
    PAPER = ('<rect x="11" y="13" width="42" height="30" rx="2" fill="#ffffff" stroke="#c4ccd6" stroke-width="1"/>'
             '<path d="M16 20h26M16 26h30M16 32h20" stroke="#aeb8c4" stroke-width="2" stroke-linecap="round"/>')
    if style == "klassisch":
        return (f'<path d="{BACK}" fill="{pale}" stroke="{dk2}" stroke-width="3" stroke-linejoin="round"/>'
                f'<path d="M5 24h54" stroke="{dk2}" stroke-width="2.6" stroke-linecap="round"/>')
    if style == "mappe":
        return (f'<path d="{BACK}" fill="{dk}"/><g transform="rotate(-4 32 30)">{PAPER}</g><path d="{FRONT}" fill="{base}"/>'
                f'<path d="M9 25.5h46" stroke="{lt}" stroke-width="1.5" stroke-linecap="round" opacity=".85"/>'
                f'<path d="M5 46h54v5a5 5 0 0 1-5 5H10a5 5 0 0 1-5-5z" fill="{dk}" opacity=".28"/>')
    if style == "offen":
        return (f'<path d="{BACK}" fill="{dk}"/><g transform="rotate(3 32 28)">{PAPER}</g>'
                f'<path d="M2.6 52.8 10.4 29.2a4 4 0 0 1 3.8-2.7H60a2.2 2.2 0 0 1 2.1 2.9l-7.6 22.6a4.4 4.4 0 0 1-4.2 3H5.3a2.2 2.2 0 0 1-2.7-3.2z" fill="{base}"/>'
                f'<path d="M12.5 29.5h46" stroke="{lt}" stroke-width="1.4" stroke-linecap="round" opacity=".85"/>')
    if style == "glas":
        return (f'<defs><linearGradient id="{ident}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".62"/>'
                f'<stop offset=".55" stop-color="#fff" stop-opacity=".12"/><stop offset="1" stop-color="#fff" stop-opacity=".02"/></linearGradient></defs>'
                f'<path d="{BACK}" fill="{base}" fill-opacity=".7" stroke="{dk}" stroke-opacity=".85" stroke-width="1.6"/>'
                f'<path d="{FRONT}" fill="{base}" fill-opacity=".9"/>'
                f'<path d="{FRONT}" fill="url(#{ident})" stroke="{dk}" stroke-opacity=".7" stroke-width="1.6"/>'
                f'<path d="M11 30.5c6-2 14-2.5 22-2.5" stroke="#fff" stroke-opacity=".7" stroke-width="2" stroke-linecap="round" fill="none"/>'
                f'<path d="M8 51.5h48" stroke="{dk2}" stroke-opacity=".35" stroke-width="2" stroke-linecap="round"/>')
    if style == "etikett":
        return (f'<path d="{BACK}" fill="{dk}"/><path d="{FRONT}" fill="{base}"/>'
                f'<path d="M9 25.5h46" stroke="{lt}" stroke-width="1.5" stroke-linecap="round" opacity=".85"/>'
                f'<rect x="15" y="32" width="34" height="15" rx="3" fill="#fff" fill-opacity=".94"/>'
                f'<rect x="19.5" y="36" width="19" height="3" rx="1.5" fill="{dk2}"/><rect x="19.5" y="41.5" width="11" height="2.4" rx="1.2" fill="{base}"/>')
    return (f'<path d="{BACK}" fill="{dk}"/><path d="{FRONT}" fill="{base}"/>'
            f'<path d="M9 25.5h46" stroke="{lt}" stroke-width="1.5" stroke-linecap="round" opacity=".8"/>')


def svg_doc(style: str, base: str, px: int = 192) -> bytes:
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="%d" height="%d">%s</svg>' % (px, px, markup(style, base))).encode("utf-8")


# Allgemeines Dateisymbol (aus CARSVG.file von Seifferts Dateien), wenn kein Programm zum Dateityp gefunden wird
FILE_GLYPH = ('<path d="M14 6h24l12 12v40H14z"/><path d="M38 6v12h12M22 30h20M22 38h20M22 46h12"/>')


def file_svg_doc(stroke: str = "#2b3a47", px: int = 192) -> bytes:
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="%d" height="%d" fill="none" stroke="%s" stroke-width="3.4" '
            'stroke-linecap="round" stroke-linejoin="round">%s</svg>' % (px, px, stroke, FILE_GLYPH)).encode("utf-8")
