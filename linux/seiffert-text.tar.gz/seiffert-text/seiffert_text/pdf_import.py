"""PDF -> Dokument mit Format (Überschriften, fett/kursiv, Listen, Tabellen, Bilder, Spalten, Links ...).

Grundlage ist PyMuPDF. Das Ergebnis sind Blöcke im Zwischenmodell (siehe builder.py).
Nicht übernommen werden Schriftarten, Farben, Seitenränder, Fußnotentexte als Fußnoten und Formeln als Formeln.
"""
import os
import re
from collections import Counter

try:
    import pymupdf
except Exception:
    pymupdf = None

from .readers import para, txt, ReaderError

BULLETS = "•·▪■●◦‣⁃–—-∙*"
RE_BULLET = re.compile(r"^\s*([%s])\s+(?=\S)" % re.escape(BULLETS))
RE_NUM = re.compile(r"^\s*(\d{1,3}[.)]|\(\d{1,2}\)|[a-zA-Z][.)])\s+(?=\S)")
END_SENT = ".!?:;…»\"”)"
MAX_IMAGES = 200


class _Line:
    __slots__ = ("bbox", "spans", "text", "size", "mono", "bold", "page", "base")

    def __init__(self, bbox, spans, page, base=None):
        self.base = base
        self.bbox = bbox
        self.spans = spans
        self.page = page
        self.text = "".join(s["text"] for s in spans)
        n = sum(len(s["text"]) for s in spans) or 1
        self.size = sum(s["size"] * len(s["text"]) for s in spans) / n
        self.bold = all(s["b"] for s in spans if s["text"].strip())
        self.mono = all(s["tt"] for s in spans if s["text"].strip())


SYMBOL_FONTS = ("symbol", "opensymbol", "wingdings", "zapfdingbats", "webdings")
PUA_BULLET = {"\uf0b7": "•", "\uf0a7": "▪", "\uf06e": "■", "\uf076": "❖", "\uf0d8": "➢", "\uf0fc": "✓",
              "\uf02d": "–", "\uf0a8": "◦", "\uf06f": "o", "\uf0e0": "→", "\uf0b2": "◦"}


def _clean(text, fontname):
    out = []
    for ch in text:
        if ch in PUA_BULLET:
            out.append(PUA_BULLET[ch])
        elif 0xE000 <= ord(ch) <= 0xF8FF:
            out.append("•" if any(k in fontname for k in SYMBOL_FONTS) else "")
        else:
            out.append(ch)
    return "".join(out)


SANS_NAMES = ("nimbussan", "arial", "helvet", "sans", "calibri", "verdana", "tahoma", "segoe", "roboto", "open", "gothic",
              "myriad", "futura", "univers", "frutiger", "trebuchet", "cmss", "lato", "noto")
SERIF_NAMES = ("times", "roman", "serif", "georgia", "garamond", "palatino", "cambria", "bookman", "minion",
               "cmr", "nimbusrom", "tinos", "charter", "utopia", "century", "pagella", "termes")


def _family(name, flags):
    """'sf' (serifenlos) oder 'rm' (Serifen); Schreibmaschinenschrift gilt hier als rm und wird über tt behandelt."""
    n = name.lower()
    if any(k in n for k in ("sans", "arial", "helvet", "calibri", "verdana", "tahoma", "segoe", "roboto",
                            "myriad", "futura", "univers", "frutiger", "trebuchet", "cmss", "lato", "nimbussan")) \
            and "serif" not in n.replace("sans-serif", "").replace("sansserif", ""):
        return "sf"
    if any(k in n for k in SERIF_NAMES):
        return "rm"
    if any(k in n for k in SANS_NAMES):
        return "sf"
    return "rm" if flags & 4 else "sf"


_FC = {}
COMPAT = {"calibri": "carlito", "cambria": "caladea", "arial": "liberationsans", "arialmt": "liberationsans",
          "timesnewroman": "liberationserif", "timesnewromanps": "liberationserif", "times": "nimbusroman",
          "timesroman": "nimbusroman", "couriernew": "liberationmono", "couriernewps": "liberationmono",
          "courier": "nimbusmono", "helvetica": "nimbussans", "helveticaneue": "nimbussans"}


def _norm(n):
    return re.sub(r"[^a-z0-9]", "", n.lower())


def _installed():
    """Installierte Schriftfamilien (normalisierter Name -> Name wie fontconfig ihn nennt)."""
    if not _FC:
        _FC["_"] = None
        try:
            import subprocess
            out = subprocess.run(["fc-list", ":", "family"], capture_output=True, text=True, timeout=20).stdout
            for line in out.splitlines():
                for part in line.split(","):
                    part = part.strip()
                    if part:
                        _FC.setdefault(_norm(part), part)
        except Exception:
            pass
    return _FC


def _family_name(fname):
    """PDF-Schriftname (ABCDEF+Caladea-Bold) -> Familienname ohne Schnitt."""
    n = fname.split("+", 1)[-1]
    n = re.split(r"[-,]", n)[0]
    n = re.sub(r"(PSMT|MT|PS)$", "", n)
    return n


def _resolve_font(fname):
    """Auf diesem Rechner vorhandene Schrift für den PDF-Schriftnamen, sonst None."""
    fam = _family_name(fname)
    inst = _installed()
    k = _norm(fam)
    if k in inst:
        return inst[k]
    alt = COMPAT.get(k)
    if alt and alt in inst:
        return inst[alt]
    return None


def _font_roles(pages, body_fam):
    """Welche installierte Schrift gehört zu Fließtext, serifenloser und Schreibmaschinenschrift."""
    cnt = {"rm": Counter(), "sf": Counter(), "tt": Counter()}
    for p in pages:
        for l in p["lines"]:
            for sp in l.spans:
                if sp.get("raw") or not sp.get("fname"):
                    continue
                if any(k in sp["fname"].lower() for k in SYMBOL_FONTS):
                    continue
                role = "tt" if sp["tt"] else sp.get("fam", "rm")
                cnt[role][_family_name(sp["fname"])] += len(sp["text"].strip())
    res = {}
    for role, c in cnt.items():
        for fam, _n in c.most_common(3):
            got = _resolve_font(fam)
            if got:
                res[role] = got
                break
    main = res.get(body_fam)
    return {"main": main, "sans": res.get("sf"), "mono": res.get("tt")} if main else None


def _hexcolor(c):
    """sRGB-Zahl -> 'RRGGBB' oder None bei (fast) Schwarz."""
    try:
        c = int(c)
    except Exception:
        return None
    r, g, b = (c >> 16) & 255, (c >> 8) & 255, c & 255
    if r < 56 and g < 56 and b < 56:
        return None
    return "%02X%02X%02X" % (r, g, b)


def _span_dicts(sp, base_y, line_size, links, hlines):
    """Ein PyMuPDF-Span (rawdict) -> Spans mit einheitlicher Auszeichnung; Unterstreichung, Streichung
    und Links gelten zeichenweise und teilen den Span deshalb bei Bedarf."""
    fl = sp.get("flags", 0)
    name = (sp.get("font") or "").lower()
    base = {"size": sp["size"],
            "b": bool(fl & 16) or any(k in name for k in ("bold", "black", "heavy", "demi", "cmbx", "-bd", "-bx")),
            "i": bool(fl & 2) or any(k in name for k in ("italic", "oblique", "cmti", "cmsl", "-it", "ital")),
            "tt": bool(fl & 8) or any(k in name for k in ("mono", "courier", "consolas", "typewriter", "cmtt")),
            "sup": False, "sub": False}
    base["fname"] = sp.get("font") or ""
    base["color"] = _hexcolor(sp.get("color", 0))
    base["fam"] = _family(name, fl)
    ox, oy = sp.get("origin", (sp["bbox"][0], sp["bbox"][3]))
    if not base["sup"] and sp["size"] < line_size * 0.82 and oy < base_y - line_size * 0.12:
        base["sup"] = True
    elif not base["sup"] and sp["size"] < line_size * 0.82 and oy > base_y + line_size * 0.04:
        base["sub"] = True
    chars = sp.get("chars") or []
    res = []
    cur = None
    for ch in chars:
        c = ch["c"]
        x0, y0, x1, y1 = ch["bbox"]
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        href = None
        for rect, uri in links:
            if rect[0] - 1 <= cx <= rect[2] + 1 and rect[1] - 1 <= cy <= rect[3] + 1:
                href = uri
                break
        u = st = False
        if c.strip():
            for (hx0, hx1, hy) in hlines:
                if hx0 - 0.5 <= cx <= hx1 + 0.5:
                    if y1 - 3.5 <= hy <= y1 + 2.5 and hx1 - hx0 < 600:
                        u = True
                    elif y0 + (y1 - y0) * 0.38 <= hy <= y0 + (y1 - y0) * 0.68:
                        st = True
        key = (u, st, href)
        if cur is not None and cur["key"] == key:
            cur["text"] += c
            cur["bbox"] = (cur["bbox"][0], min(cur["bbox"][1], y0), x1, max(cur["bbox"][3], y1))
        else:
            cur = {"key": key, "text": c, "bbox": (x0, y0, x1, y1)}
            res.append(cur)
    out = []
    for r in res:
        # Leerzeichen am Rand bekommen keine Unterstreichung
        d = dict(base)
        d.update({"text": _clean(r["text"], name), "bbox": r["bbox"], "u": r["key"][0], "st": r["key"][1],
                  "href": r["key"][2]})
        if d["text"] != "":
            out.append(d)
    return out


def _hlines(page):
    out = []
    try:
        for dr in page.get_drawings():
            for it in dr.get("items", []):
                if it[0] == "l":
                    p, q = it[1], it[2]
                    if abs(p.y - q.y) < 0.8 and abs(p.x - q.x) > 2.2:
                        out.append((min(p.x, q.x), max(p.x, q.x), (p.y + q.y) / 2))
                elif it[0] == "re":
                    r = it[1]
                    if r.height < 1.2 and r.width > 2.2:
                        out.append((r.x0, r.x1, (r.y0 + r.y1) / 2))
    except Exception:
        pass
    return out[:4000]


def _vlines(page):
    out = []
    try:
        for dr in page.get_drawings():
            for it in dr.get("items", []):
                if it[0] == "l":
                    p, q = it[1], it[2]
                    if abs(p.x - q.x) < 0.8 and abs(p.y - q.y) > 4:
                        out.append(((p.x + q.x) / 2, min(p.y, q.y), max(p.y, q.y)))
                elif it[0] == "re":
                    r = it[1]
                    if r.width < 1.2 and r.height > 4:
                        out.append(((r.x0 + r.x1) / 2, r.y0, r.y1))
    except Exception:
        pass
    return out[:4000]


def _links(page):
    out = []
    try:
        for lk in page.get_links():
            uri = lk.get("uri")
            if uri and lk.get("kind") == getattr(pymupdf, "LINK_URI", 2):
                out.append((tuple(lk["from"]), uri))
    except Exception:
        pass
    return out


MATH_MAP = {"\u2212": "-", "\u2013": "-", "\u00b7": "\\cdot ", "\u22c5": "\\cdot ", "\u00d7": "\\times ",
            "\u00f7": "\\div ", "\u2264": "\\le ", "\u2265": "\\ge ", "\u2260": "\\ne ", "\u00b2": "^2",
            "\u00b3": "^3", "\u221a": "\\sqrt{}", "\u00b1": "\\pm ", "%": "\\%", "&": "\\&", "#": "\\#",
            "_": "\\_", "$": "\\$", "\u03c0": "\\pi ", "\u00b0": "^\\circ ", "{": "\\{", "}": "\\}"}


def _mathtext(chars):
    """Zeichen eines Zählers oder Nenners (Liste von (c, bbox, size)) -> Mathe-LaTeX."""
    if not chars:
        return ""
    rows = sorted(chars, key=lambda c: ((c[1][1] + c[1][3]) / 2, c[1][0]))
    # Zeilen nach Höhe trennen
    lines, cur = [], [rows[0]]
    for c in rows[1:]:
        if abs((c[1][1] + c[1][3]) / 2 - (cur[-1][1][1] + cur[-1][1][3]) / 2) > 0.5 * max(c[2], 1):
            lines.append(cur)
            cur = [c]
        else:
            cur.append(c)
    lines.append(cur)
    parts = []
    for ln in lines:
        ln = sorted(ln, key=lambda c: c[1][0])
        t = ""
        for k, (c, bb, size) in enumerate(ln):
            if k and bb[0] - ln[k - 1][1][2] > 0.55 * size:
                t += "\\ "
            t += MATH_MAP.get(c, c)
        parts.append(t)
    return " ".join(parts)


def _fractions_and_blanks(chars, hsegs, vsegs, skip_rects, body):
    """Bruchstriche (Zähler/Nenner) und Ausfüll-Linien erkennen.
    chars: Liste (c, bbox, size, key). Liefert (Brüche, Lücken, verbrauchte Zeichenschlüssel);
    Brüche: (bbox, latex); Lücken: (bbox, latex)."""
    used, fracs, blanks = set(), [], []

    def in_skip(cx, cy):
        return any(r[0] <= cx <= r[2] and r[1] <= cy <= r[3] for r in skip_rects)

    def touches_v(x, y):
        return any(abs(vx - x) <= 2.2 and vy0 - 2.5 <= y <= vy1 + 2.5 for vx, vy0, vy1 in vsegs)

    cand = []
    for hx0, hx1, hy in hsegs:
        w = hx1 - hx0
        if w < 2.5 or w > 260 or in_skip((hx0 + hx1) / 2, hy):
            continue
        if touches_v(hx0, hy) or touches_v(hx1, hy):
            continue
        cand.append((hx0, hx1, hy))
    cand = sorted(set((round(a, 1), round(b, 1), round(y, 1)) for a, b, y in cand))
    for hx0, hx1, hy in cand:
        w = hx1 - hx0
        inx = [c for c in chars if c[0].strip() and hx0 - 2.5 <= (c[1][0] + c[1][2]) / 2 <= hx1 + 2.5
               and c[3] not in used]
        sz = max([c[2] for c in inx if abs((c[1][1] + c[1][3]) / 2 - hy) < 2.2 * max(c[2], 6)] or [body])
        num = [c for c in inx if hy - c[1][3] >= -0.4 and hy - c[1][3] <= 0.9 * c[2] + 1]
        den = [c for c in inx if c[1][1] - hy >= -0.4 and c[1][1] - hy <= 0.9 * c[2] + 1]
        if num and den and w <= 130:
            def span_ok(group):
                xs0 = min(c[1][0] for c in group)
                xs1 = max(c[1][2] for c in group)
                return xs0 >= hx0 - 4 and xs1 <= hx1 + 4 and (xs1 - xs0) >= 0.3 * w
            # nur die jeweils nächste Zeile über bzw. unter dem Strich
            ny = max((c[1][3] + c[1][1]) / 2 for c in num)
            dy = min((c[1][3] + c[1][1]) / 2 for c in den)
            num = [c for c in num if ny - (c[1][3] + c[1][1]) / 2 < 0.5 * c[2]]
            den = [c for c in den if (c[1][3] + c[1][1]) / 2 - dy < 0.5 * c[2]]
            if span_ok(num) and span_ok(den):
                a = _mathtext([(c[0], c[1], c[2]) for c in num])
                b = _mathtext([(c[0], c[1], c[2]) for c in den])
                for c in num + den:
                    used.add(c[3])
                top = min(c[1][1] for c in num)
                bot = max(c[1][3] for c in den)
                fracs.append(((hx0, top, hx1, bot), "\\(\\frac{%s}{%s}\\)" % (a, b), sz))
                continue
        # Ausfüll-Linie: keine unterstrichene Schrift darüber, nichts direkt darunter
        if w < 25 or w > 260:
            continue
        over = [c for c in inx if -3.5 <= hy - c[1][3] <= 0.4 or (c[1][1] < hy < c[1][3] - 0.8)]
        if over:
            continue
        blanks.append(((hx0, hy - body * 0.85, hx1, hy + 1.0),
                       "\\underline{\\hspace{%.1fcm}}" % (w / 72 * 2.54), body))
    if len(blanks) > 40:
        blanks = []
    return fracs, blanks, used


def _page_lines(page, pno, skip_rects):
    """Alle Textzeilen der Seite (ohne Tabellen- und Bildbereiche) mit Formatangaben."""
    d = page.get_text("rawdict")
    links = _links(page)
    hl = _hlines(page)
    vl = _vlines(page)
    allc = []
    sizes = []
    for bi, b in enumerate(d.get("blocks", [])):
        if b.get("type", 0) != 0:
            continue
        for li, ln in enumerate(b.get("lines", [])):
            for si, sp in enumerate(ln.get("spans", [])):
                for ci, ch in enumerate(sp.get("chars") or []):
                    allc.append((ch["c"], ch["bbox"], sp["size"], (bi, li, si, ci)))
                    if ch["c"].strip():
                        sizes.append(sp["size"])
    sizes.sort()
    body = sizes[len(sizes) // 2] if sizes else 11.0
    fracs, blanks, used = _fractions_and_blanks(allc, hl, vl, skip_rects, body)
    # Zeichen, die in Brüchen stecken, bleiben nicht in den Textzeilen
    lines = []
    for bi, b in enumerate(d.get("blocks", [])):
        if b.get("type", 0) != 0:
            continue
        for li, ln in enumerate(b.get("lines", [])):
            sps = []
            for si, s0 in enumerate(ln.get("spans", [])):
                chs = [c for ci, c in enumerate(s0.get("chars") or []) if (bi, li, si, ci) not in used]
                if chs:
                    s1 = dict(s0)
                    s1["chars"] = chs
                    sps.append(s1)
            if not sps or not "".join(c["c"] for s in sps for c in s["chars"]).strip():
                continue
            if ln.get("dir", (1, 0))[1] != 0 and abs(ln.get("dir", (1, 0))[1]) > 0.5:
                continue        # senkrechter Text (Randnotizen, Wasserzeichen)
            x0 = min(c["bbox"][0] for s in sps for c in s["chars"])
            x1 = max(c["bbox"][2] for s in sps for c in s["chars"])
            y0 = min(c["bbox"][1] for s in sps for c in s["chars"])
            y1 = max(c["bbox"][3] for s in sps for c in s["chars"])
            cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
            if any(r[0] <= cx <= r[2] and r[1] <= cy <= r[3] for r in skip_rects):
                continue
            main = max(sps, key=lambda s: len("".join(c["c"] for c in s["chars"]).strip()) * s["size"])
            base_y = main.get("origin", (0, y1))[1]
            ds = []
            for s in sps:
                ds.extend(_span_dicts(s, base_y, main["size"], links, hl))
            if not ds:
                continue
            lines.append(_Line((x0, y0, x1, y1), ds, pno, base_y))
    for bb, latex, size in fracs + blanks:
        sp = {"size": size, "b": False, "i": False, "tt": False, "sup": False, "sub": False, "u": False,
              "st": False, "href": None, "text": "\ufffc", "bbox": bb, "raw": latex}
        if (bb[0] + bb[2]) / 2 and not any(r[0] <= (bb[0] + bb[2]) / 2 <= r[2] and r[1] <= (bb[1] + bb[3]) / 2 <= r[3]
                                           for r in skip_rects):
            mid = (bb[1] + bb[3]) / 2
            lines.append(_Line((bb[0], mid - size * 0.65, bb[2], mid + size * 0.65), [sp], pno))
    return _hfill(_merge_rows(lines), page.rect.width)


def _hfill(rows, pw):
    """Kurze Stücke links und rechts in derselben Zeile (Name links, Klasse rechts) mit \\hfill verbinden;
    nur wenn es auf der Seite wenige solche Zeilen gibt (sonst sind es Spalten oder Tabellen)."""
    cand = []
    for i, a in enumerate(rows):
        for j, b in enumerate(rows):
            if i == j or a.bbox[0] >= b.bbox[0]:
                continue
            ov = min(a.bbox[3], b.bbox[3]) - max(a.bbox[1], b.bbox[1])
            h = min(a.bbox[3] - a.bbox[1], b.bbox[3] - b.bbox[1])
            gap = b.bbox[0] - a.bbox[2]
            if h > 0 and ov > 0.7 * h and gap > 1.8 * max(a.size, b.size) \
                    and a.bbox[0] < 0.35 * pw and b.bbox[2] > 0.55 * pw \
                    and (a.bbox[2] - a.bbox[0]) < 0.42 * pw and (b.bbox[2] - b.bbox[0]) < 0.42 * pw \
                    and len(a.text) + len(b.text) < 90:
                cand.append((i, j))
    if not cand or len(cand) > 4:
        return rows
    used, out = set(), []
    for i, j in cand:
        if i in used or j in used:
            continue
        a, b = rows[i], rows[j]
        sp = list(a.spans) + [{"size": a.size, "b": False, "i": False, "tt": False, "sup": False, "sub": False,
                               "u": False, "st": False, "href": None, "text": "\ufffc", "raw": "\\hfill ",
                               "bbox": (a.bbox[2], a.bbox[1], b.bbox[0], a.bbox[3])}] + list(b.spans)
        out.append(_Line((min(a.bbox[0], b.bbox[0]), min(a.bbox[1], b.bbox[1]),
                          max(a.bbox[2], b.bbox[2]), max(a.bbox[3], b.bbox[3])), sp, a.page, a.base))
        used.update((i, j))
    return [r for k, r in enumerate(rows) if k not in used] + out


def _merge_rows(lines):
    """Zeilen, die optisch in derselben Zeile liegen (z. B. Aufzählungszeichen und Text, Nummer und Überschrift),
    zu einer Zeile verbinden. Brüche und Ausfüll-Linien (Raw-Spans) werden danach an der passenden Stelle
    in die Zeile gesetzt."""
    syn = [l for l in lines if len(l.spans) == 1 and l.spans[0].get("raw")]
    norm = [l for l in lines if not (len(l.spans) == 1 and l.spans[0].get("raw"))]
    out = _merge_norm(norm)
    for sl in sorted(syn, key=lambda l: (l.bbox[0], l.bbox[1])):
        best, bov = None, 0.0
        for k, o in enumerate(out):
            ov = min(o.bbox[3], sl.bbox[3]) - max(o.bbox[1], sl.bbox[1])
            h = min(o.bbox[3] - o.bbox[1], sl.bbox[3] - sl.bbox[1])
            gap = max(o.bbox[0] - sl.bbox[2], sl.bbox[0] - o.bbox[2])
            if h > 0 and ov > 0.55 * h and gap <= 1.8 * max(o.size, sl.size) and ov > bov:
                best, bov = k, ov
        if best is None:
            out.append(sl)
            continue
        o = out[best]
        sp0 = sorted(o.spans + sl.spans, key=lambda s: s["bbox"][0])
        sp = []
        for q in sp0:
            if sp and (q is sl.spans[0] or sp[-1] is sl.spans[0]) and q["bbox"][0] - sp[-1]["bbox"][2] > 0.2 * q["size"] \
                    and not sp[-1]["text"].endswith(" ") and not q["text"].startswith(" "):
                sp.append(dict(sp[-1], text=" ", u=False, st=False, href=None, sup=False, sub=False, raw=None))
            sp.append(q)
        out[best] = _Line((min(o.bbox[0], sl.bbox[0]), min(o.bbox[1], sl.bbox[1]),
                           max(o.bbox[2], sl.bbox[2]), max(o.bbox[3], sl.bbox[3])), sp, o.page, o.base)
    if syn:
        out = _merge_norm(out)      # Bruch schließt die Lücke zwischen zwei Textstücken derselben Zeile
    return sorted(out, key=lambda l: (l.bbox[1], l.bbox[0]))


def _merge_norm(lines):
    lines = sorted(lines, key=lambda l: (l.bbox[1], l.bbox[0]))
    out = []
    for ln in lines:
        done = False
        for k in range(len(out) - 1, max(-1, len(out) - 5), -1):
            o = out[k]
            a, b = (o, ln) if o.bbox[0] <= ln.bbox[0] else (ln, o)
            ab, bb = a.bbox, b.bbox
            ov = min(ab[3], bb[3]) - max(ab[1], bb[1])
            h = min(ab[3] - ab[1], bb[3] - bb[1])
            gap = bb[0] - ab[2]
            lo = -9 if (a.spans[-1].get("raw") or b.spans[0].get("raw")) else -2
            if h > 0 and ov > 0.6 * h and lo <= gap <= 1.8 * max(a.size, b.size):
                sp = list(a.spans)
                if gap > 0.25 * b.size and not sp[-1]["text"].endswith(" ") and not b.spans[0]["text"].startswith(" "):
                    sp.append(dict(sp[-1], text=" ", u=False, st=False, href=None, sup=False, sub=False, raw=None))
                out[k] = _Line((min(ab[0], bb[0]), min(ab[1], bb[1]), max(ab[2], bb[2]), max(ab[3], bb[3])),
                               sp + list(b.spans), a.page, a.base if a.base is not None else b.base)
                done = True
                break
        if not done:
            out.append(ln)
    return out


def _tables(page):
    """Tabellen der Seite: Liste von (bbox, Zeilen aus Zellentext, Kopfzeile?)."""
    out = []
    try:
        found = page.find_tables()
    except Exception:
        return out
    for t in getattr(found, "tables", []) or []:
        try:
            rows = t.extract()
        except Exception:
            continue
        rows = [[(c or "").strip() for c in r] for r in rows]
        if len(rows) < 2 or max((len(r) for r in rows), default=0) < 2:
            continue
        filled = sum(1 for r in rows for c in r if c)
        if filled < 4:
            continue
        head = False
        try:
            head = bool(t.header and not t.header.external)
        except Exception:
            pass
        out.append((tuple(t.bbox), rows, head))
    return out


def _images(doc, page, seen):
    out = []
    try:
        infos = page.get_image_info(xrefs=True)
    except Exception:
        return out
    pw = page.rect.width
    for info in infos:
        xref = info.get("xref") or 0
        bb = info["bbox"]
        w, h = bb[2] - bb[0], bb[3] - bb[1]
        if w < 18 or h < 18 or len(seen) >= MAX_IMAGES:
            continue
        data = None
        try:
            if xref:
                pm = pymupdf.Pixmap(doc, xref)
                if pm.alpha == 0 and info.get("has-mask"):
                    pass
                if pm.n - pm.alpha >= 4 or pm.colorspace is None or pm.colorspace.n not in (1, 3):
                    pm = pymupdf.Pixmap(pymupdf.csRGB, pm)
                data = pm.tobytes("png")
        except Exception:
            data = None
        if data is None:
            try:
                data = page.get_pixmap(clip=pymupdf.Rect(bb), dpi=150).tobytes("png")
            except Exception:
                continue
        key = (xref, round(bb[0]), round(bb[1]))
        seen.add(key)
        out.append((tuple(bb), data, w / 72 * 2.54))
    return out


# ---------------------------------------------------------------- Seitenaufbau
def _columns(items, page_w):
    """Ordnet Elemente (mit .bbox) in Lesereihenfolge; erkennt mehrere Spalten. items: Liste von (bbox, objekt)."""
    if not items:
        return []
    items = sorted(items, key=lambda it: (it[0][1], it[0][0]))
    xs0 = min(it[0][0] for it in items)
    xs1 = max(it[0][2] for it in items)
    width = max(1.0, xs1 - xs0)
    narrow = [it for it in items if (it[0][2] - it[0][0]) < 0.62 * width]
    gutters = []
    if len(narrow) >= 6:
        iv = sorted((it[0][0], it[0][2]) for it in narrow)
        cur_end = iv[0][1]
        for a, b in iv[1:]:
            if a - cur_end >= 10 and 0.2 * width <= (cur_end - xs0) <= 0.8 * width:
                left = sum(1 for it in narrow if it[0][2] <= cur_end + 1)
                right = sum(1 for it in narrow if it[0][0] >= a - 1)
                if left >= 3 and right >= 3:
                    gutters.append((cur_end + a) / 2)
            cur_end = max(cur_end, b)
    if not gutters:
        return [(it[1], (0, 0)) for it in items]

    def col_of(bb):
        return sum(1 for g in gutters if (bb[0] + bb[2]) / 2 > g)

    def spans_gutter(bb):
        return any(bb[0] < g - 6 and bb[2] > g + 6 for g in gutters)

    result, segment, segno = [], [], [0]

    def flush():
        cols = {}
        for it in segment:
            cols.setdefault(col_of(it[0]), []).append(it)
        for c in sorted(cols):
            result.extend((x[1], (segno[0], c)) for x in sorted(cols[c], key=lambda it: (it[0][1], it[0][0])))
        segment.clear()
        segno[0] += 1

    for it in items:
        if spans_gutter(it[0]):
            flush()
            result.append((it[1], (segno[0], -1)))
            segno[0] += 1
        else:
            segment.append(it)
    flush()
    return result


def _noise(pages_lines, page_heights):
    """Kopf- und Fußzeilen: Zeilen im oberen/unteren Rand, die auf vielen Seiten gleich vorkommen, und Seitenzahlen."""
    n = len(pages_lines)
    cnt = Counter()
    for pno, lines in enumerate(pages_lines):
        seen = set()
        for ln in lines:
            h = page_heights[pno]
            if ln.bbox[3] < h * 0.09 or ln.bbox[1] > h * 0.91:
                key = re.sub(r"\d+", "#", ln.text.strip())
                if key not in seen:
                    seen.add(key)
                    cnt[key] += 1
    bad = {k for k, v in cnt.items() if n >= 3 and v >= max(3, 0.5 * n)}
    return bad


def _is_pagenum(ln, h):
    t = ln.text.strip()
    return (ln.bbox[3] < h * 0.09 or ln.bbox[1] > h * 0.91) and re.fullmatch(
        r"(Seite\s*)?[-–]?\s*\d{1,4}\s*[-–]?(\s*(/|von)\s*\d{1,4})?", t, re.I) is not None


_CTX = {"body": 11.0, "fam": "rm"}
BP = 72.27 / 72.0        # 1 bp in pt: PDF-Größen sind in bp, LaTeX rechnet in pt


def _pt(bp):
    return round(bp * BP * 20) / 20


def _inlines(lines, plain=False):
    """Spans mehrerer Zeilen zu Textstücken (Silbentrennung am Zeilenende wird aufgelöst)."""
    inl = []
    prev_text = ""
    for ln in lines:
        spans = [s for s in ln.spans if s["text"] != ""]
        if not spans:
            continue
        if inl:
            if prev_text.endswith("-") and len(prev_text) > 1 and prev_text[-2].isalpha() \
                    and spans[0]["text"][:1].islower():
                last = inl[-1]
                last["s"] = last["s"][:-1]
            elif not prev_text.endswith(" ") and not spans[0]["text"].startswith(" "):
                inl.append(txt(" "))
        for s in spans:
            if s.get("raw"):
                inl.append({"t": "raw", "s": s["raw"]})
                continue
            sz = None
            if not plain and not s["sup"] and not s["sub"] and abs(s["size"] - _CTX["body"]) >= 0.75:
                sz = _pt(s["size"])
            fam = s.get("fam") if (not plain and not s["tt"] and s.get("fam") != _CTX["fam"]) else None
            col = None if plain else s.get("color")
            inl.append(txt(s["text"], b=s["b"], i=s["i"], u=s["u"], st=s["st"], tt=s["tt"],
                           sup=s["sup"], sub=s["sub"], href=s["href"], size=sz, color=col, fam=fam))
        prev_text = spans[-1]["text"]
    return _merge(inl)


def _merge(inl):
    out = []
    for x in inl:
        if out and {k: v for k, v in out[-1].items() if k != "s"} == {k: v for k, v in x.items() if k != "s"}:
            out[-1]["s"] += x["s"]
        else:
            out.append(dict(x))
    # Leerraum an Formatgrenzen nicht fett/kursiv/unterstrichen halten
    res = []
    for x in out:
        if x["s"].strip() == "" and x.get("href") is None:
            x = {"t": "txt", "s": x["s"]}
        res.append(x)
    res = _merge2(res)
    if res:
        res[0]["s"] = res[0]["s"].lstrip()
        res[-1]["s"] = res[-1]["s"].rstrip()
    return [x for x in res if x["s"]]


def _merge2(res):
    out = []
    for x in res:
        if out and {k: v for k, v in out[-1].items() if k != "s"} == {k: v for k, v in x.items() if k != "s"}:
            out[-1]["s"] += x["s"]
        else:
            out.append(x)
    return out


def _lead_marker(line):
    """Aufzählungs- oder Nummernzeichen am Zeilenanfang: (ordered, Text ohne Zeichen) oder None."""
    t = line.text
    m = RE_BULLET.match(t)
    if m:
        # ein einzelner Strich/Stern am Anfang ist nur dann ein Listenzeichen, wenn der Text danach klein anfängt
        if m.group(1) in "-–—*" and not line.text[m.end():m.end() + 1].strip():
            return None
        return False, m.end(), None
    m = RE_NUM.match(t)
    if m and not re.match(r"^\s*[a-zA-Z]\.\s", t):
        return True, m.end(), _label_of(m.group(1))
    return None


def _label_of(tok):
    """'a)' -> ('alph','',')'); '1.' -> None (Standard); '(1)' -> ('arabic','(',')')."""
    pre = "(" if tok.startswith("(") else ""
    core = tok.strip("().")
    suf = ")" if tok.endswith(")") else "."
    if core.isdigit():
        return None if (not pre and suf == ".") else ("arabic", pre, suf)
    if len(core) == 1 and core.isalpha():
        return ("alph" if core.islower() else "Alph", pre, suf)
    return None


def _strip_chars(line, n):
    """Entfernt die ersten n Zeichen der Zeile (Listenzeichen)."""
    spans = []
    for s in line.spans:
        if n <= 0:
            spans.append(s)
            continue
        if len(s["text"]) <= n:
            n -= len(s["text"])
            continue
        s = dict(s)
        s["text"] = s["text"][n:]
        n = 0
        spans.append(s)
    ln = _Line(line.bbox, spans, line.page)
    return ln


def _paragraphs(lines, body, left, right, page_w):
    """Zeilen einer Spalte -> Blöcke (Absätze, Listen, Code, Überschriften)."""
    out = []
    i, n = 0, len(lines)
    cur = []        # Zeilen des laufenden Absatzes
    mode = None     # None | 'list'
    items = []      # Listeneinträge: (ordered, [Zeilen])

    def end_para():
        nonlocal cur
        if cur:
            out.append(("p", cur))
            cur = []

    def end_list():
        nonlocal items
        if items:
            out.append(("list", items))
            items = []

    prev = None
    for ln in lines:
        x0, y0, x1, y1 = ln.bbox
        lh = max(ln.size, 1.0)
        mk = _lead_marker(ln)
        new_para = False
        if prev is not None:
            gap = y0 - prev.bbox[3]
            if gap > 0.55 * lh:
                new_para = True
            if abs(ln.size - prev.size) > 1.2 or ln.bold != prev.bold and (ln.size > body * 1.05 or prev.size > body * 1.05):
                new_para = True
            if ln.mono != prev.mono:
                new_para = True
            if not new_para and not (ln.mono and prev.mono) and not prev.text.rstrip().endswith("-"):
                # Passte das erste Wort der neuen Zeile noch auf die vorige Zeile, war der Umbruch kein Zeilenumbruch
                first = ln.text.strip().split(" ")[0] if ln.text.strip() else ""
                cw = (x1 - x0) / max(1, len(ln.text))
                if first and right - prev.bbox[2] > len(first) * cw + 1.5 * cw + 2:
                    new_para = True
            if not new_para and not (ln.mono and prev.mono) and x0 > left + 0.9 * lh and x0 > prev.bbox[0] + 0.9 * lh and not items:
                new_para = True      # Einzug der ersten Zeile
        if mk:
            end_para()
            ordered, k, lab = mk
            if items and (items[-1][0] != ordered or (ordered and items[-1][3] != lab)):
                end_list()
            items_line = _strip_chars(ln, k)
            items.append((ordered, [items_line], x0, lab))
            prev = ln
            continue
        if items:
            # Fortsetzung des letzten Eintrags, solange eingerückt und ohne großen Abstand
            if not new_para and x0 >= items[-1][2] - 1 and ln.size <= body * 1.15:
                items[-1][1].append(ln)
                prev = ln
                continue
            end_list()
            new_para = True
        if new_para:
            end_para()
        cur.append(ln)
        prev = ln
    end_para()
    end_list()
    return out


def _align(lines, left, right):
    x0 = min(l.bbox[0] for l in lines)
    x1 = max(l.bbox[2] for l in lines)
    cx = (left + right) / 2
    tol = 0.04 * (right - left) + 3
    if abs((x0 + x1) / 2 - cx) <= tol and x0 - left > 0.06 * (right - left) and right - x1 > 0.06 * (right - left):
        return "center"
    if right - x1 <= 3 and x0 - left > 0.25 * (right - left) and len(lines) <= 3:
        return "right"
    return None


def pdf_to_blocks(path):
    if pymupdf is None:
        raise ReaderError("Zum Lesen von PDF-Dateien fehlt das Python-Paket PyMuPDF.")
    try:
        doc = pymupdf.open(path)
    except Exception as e:
        raise ReaderError("Das PDF konnte nicht gelesen werden: %s" % e)
    if doc.needs_pass:
        raise ReaderError("Das PDF ist mit einem Kennwort geschützt.")

    pages = []          # je Seite: {lines, tables, images, w, h}
    seen_img = set()
    for pno, page in enumerate(doc):
        tabs = _tables(page)
        imgs = _images(doc, page, seen_img)
        skip = [t[0] for t in tabs] + [i[0] for i in imgs]
        lines = _page_lines(page, pno, skip)
        pages.append({"lines": lines, "tables": tabs, "images": imgs, "rules": _hlines(page),
                      "w": page.rect.width, "h": page.rect.height})
    total_chars = sum(len(l.text) for p in pages for l in p["lines"])
    has_img = any(p["images"] for p in pages)
    if total_chars == 0 and not has_img:
        raise ReaderError("Das PDF enthält keinen auslesbaren Text (vermutlich nur gescannte Bilder).")

    sizes = Counter()
    for p in pages:
        for l in p["lines"]:
            sizes[round(l.size * 2) / 2] += len(l.text)
    body = sizes.most_common(1)[0][0] if sizes else 11
    _ex = [(l.size, len(l.text)) for p in pages for l in p["lines"] if round(l.size * 2) / 2 == body]
    body_exact = sum(a * b for a, b in _ex) / max(1, sum(b for a, b in _ex)) if _ex else body
    # Schriftfamilie des Fließtextes
    fams = Counter()
    for p in pages:
        for l in p["lines"]:
            for sp in l.spans:
                if sp.get("fam") and not sp["tt"] and not sp.get("raw"):
                    fams[sp["fam"]] += len(sp["text"].strip())
    body_fam = fams.most_common(1)[0][0] if fams else "rm"
    _TIMES_HINT[0] = False
    tnames = Counter()
    for pg in doc:
        try:
            for f in pg.get_fonts():
                tnames[f[3].lower()] += 1
        except Exception:
            pass
    if tnames:
        first = sorted(tnames.items(), key=lambda kv: -kv[1])
        _TIMES_HINT[0] = any(any(k in n for k in ("times", "nimbusrom", "termes", "tinos", "liberationserif", "liberation serif"))
                             for n, _ in first[:3])
    _CTX["body"], _CTX["fam"] = body, body_fam
    hf = _extract_header_footer(pages, body)

    # Überschriftengrößen: alle Größen deutlich über Fließtext, nach Größe geordnet
    head_sizes = sorted({round(l.size) for p in pages for l in p["lines"]
                         if l.size >= body * 1.18 and len(l.text.strip()) < 160}, reverse=True)

    def head_level(lines):
        if len(lines) > 3:
            return None
        text = " ".join(l.text.strip() for l in lines)
        if not text or len(text) >= 160:
            return None
        sz = max(l.size for l in lines)
        if round(sz) in head_sizes:
            return head_sizes.index(round(sz))  # 0 = größte Stufe
        if sz >= body * 1.0 - 0.3 and all(l.bold for l in lines) and len(lines) == 1 and \
                text[-1:] not in ".,;:" and len(text.split()) <= 12:
            return len(head_sizes)               # nur fett: unterste Stufe
        return None

    flow = []       # Blöcke in Lesereihenfolge; Seitenwechsel als {"page": n}
    for pno, p in enumerate(pages):
        items = []
        for l in p["lines"]:
            items.append((l.bbox, ("line", l)))
        for bb, rows, head in p["tables"]:
            items.append((bb, ("table", rows, head)))
        for bb, data, wcm in p["images"]:
            items.append((bb, ("img", data, wcm)))
        ordered = _columns(items, p["w"])
        flow.append({"page": pno})
        run, runkey = [], None
        for obj, key in ordered:
            if obj[0] == "line":
                if run and key != runkey:
                    flow.append({"lines": run, "page": pno})
                    run = []
                run.append(obj[1])
                runkey = key
            else:
                if run:
                    flow.append({"lines": run, "page": pno})
                    run, runkey = [], None
                flow.append({"obj": obj, "page": pno})
        if run:
            flow.append({"lines": run, "page": pno})

    # Ränder bestimmen (häufigster linker Rand der Zeilen)
    xs = Counter(round(l.bbox[0]) for p in pages for l in p["lines"] if l.size <= body * 1.1)
    default_left = xs.most_common(1)[0][0] if xs else 50

    blocks = []
    pending_title = None
    pstats, hstats = [], []
    lstats = {"item": [], "top": []}
    had_num = False
    for fi, f in enumerate(flow):
        if "page" in f and len(f) == 1:
            if blocks and isinstance(blocks[-1], dict):
                blocks[-1].setdefault("_pageend", True)
            continue
        if "obj" in f:
            g = f["obj"]
            if g[0] == "table":
                rows = [[{"blocks": [para([txt(c)] if c else [])], "hd": bool(g[2] and ri == 0)} for c in r]
                        for ri, r in enumerate(g[1])]
                blocks.append({"t": "table", "rows": rows})
            else:
                blocks.append(para([{"t": "img", "data": g[1], "w": min(g[2], 16.0)}], al="center"))
            continue
        lines = f["lines"]
        p = pages[f["page"]]
        left = min(l.bbox[0] for l in lines)
        left = min(left, default_left) if abs(left - default_left) < 25 else left
        small = [l for l in lines if l.size <= body * 1.15] or lines
        right = max(l.bbox[2] for l in small)
        for kind, content in _paragraphs(lines, body, left, right, p["w"]):
            if kind == "list":
                lb_items = []
                ordered = content[0][0]
                for _o, ls, _x, _lab in content:
                    lb_items.append([para(_inlines(ls))])
                bs = [[(l.base if l.base is not None else l.bbox[3]) for l in c[1]] for c in content]
                for k in range(len(bs) - 1):
                    lstats["item"].append(bs[k + 1][0] - bs[k][-1])
                lx0 = min(l.bbox[0] for c in content for l in c[1])
                abl = [l for l in p["lines"]
                       if l.bbox[3] <= min(l.bbox[1] for l in content[0][1]) + 1 and l.bbox[2] > lx0 - 40 and l not in content[0][1]]
                if abl:
                    nb = max(abl, key=lambda l: (l.base if l.base is not None else l.bbox[3]))
                    if nb.size <= body + 0.6:        # nach Überschriften regeln diese den Abstand
                        lstats["top"].append(bs[0][0] - (nb.base if nb.base is not None else nb.bbox[3]))
                lb = {"t": "list", "ord": ordered, "items": lb_items}
                if ordered and content[0][3]:
                    lb["lab"] = content[0][3]
                blocks.append(lb)
                continue
            ls = content
            lvl = head_level(ls)
            if lvl is not None and lvl == len(head_sizes) and _align(ls, left, right):
                lvl = None           # nur fett und zentriert/rechts: Hervorhebung, keine Überschrift
            if lvl is not None:
                text = re.sub(r"\s+", " ", " ".join(l.text.strip() for l in ls)).strip()
                t2 = re.sub(r"^(\d+(\.\d+){0,4}\.?|[IVX]+\.)\s+(?=\S)", "", text) or text    # Gliederungsnummern setzt LaTeX selbst
                had_num = had_num or t2 != text
                text = t2
                hb = para([txt(text)], h=lvl + 1)
                hy0, hy1 = min(l.bbox[1] for l in ls), max(l.bbox[3] for l in ls)
                hx0, hx1 = min(l.bbox[0] for l in ls), max(l.bbox[2] for l in ls)
                prev_b = [(l.base if l.base is not None else l.bbox[3]) for l in p["lines"]
                          if l.bbox[3] <= hy0 + 1 and l.bbox[2] > hx0 and l.bbox[0] < hx1 and l not in ls]
                next_t = [(l.base if l.base is not None else l.bbox[1]) for l in p["lines"]
                          if l.bbox[1] >= hy1 - 1 and l.bbox[2] > hx0 and l.bbox[0] < hx1 and l not in ls]
                msz = max(l.size for l in ls)
                hstats.append({"lvl": lvl + 1, "size": round(msz * 10) / 10,
                               "bold": all(l.bold for l in ls), "fam": max(ls[0].spans, key=lambda q: len(q["text"])).get("fam"),
                               "color": max(ls[0].spans, key=lambda q: len(q["text"])).get("color"),
                               "al": _align(ls, left, right),
                               "pg": f["page"], "b0": ls[0].base, "b1": ls[-1].base,
                               "before": (ls[0].base - max(prev_b)) if prev_b else None,
                               "after": (min(next_t) - ls[-1].base) if next_t else None})
                blocks.append(hb)
                continue
            if all(l.mono for l in ls) and len(ls) >= 2:
                cw = max(3.0, sum(l.size for l in ls) / len(ls) * 0.6)
                x_min = min(l.bbox[0] for l in ls)
                rows = []
                for l in ls:
                    t = l.text.rstrip()
                    if t == t.lstrip():
                        t = " " * int(round((l.bbox[0] - x_min) / cw)) + t
                    rows.append(t)
                blocks.append(para([txt("\n".join(rows))], code=True))
                continue
            al = _align(ls, left, right)
            b = para(_inlines(ls))
            if al:
                b["al"] = al
            if b["inl"]:
                blocks.append(b)
                if not al and max(l.size for l in ls) <= body * 1.15:
                    pstats.append({"item": fi, "page": f["page"], "x0": ls[0].bbox[0], "y1": ls[0].bbox[3],
                                   "ly1": ls[-1].bbox[3], "n": len(ls), "left": left, "right": right,
                                   "rights": [l.bbox[2] for l in ls[:-1]],
                                   "ys": [(l.base if l.base is not None else l.bbox[3]) for l in ls],
                                   "sizes": [l.size for l in ls]})
        if blocks:
            blocks[-1]["_col_end"] = True

    blocks = _join_pages(blocks)
    title_in_doc = True      # keine erfundene Titelzeile: es erscheint nur, was im PDF steht
    for b in blocks:
        b.pop("_pageend", None)
        b.pop("_col_end", None)
    if not had_num:
        for b in blocks:
            if b.get("t") == "p" and b.get("h"):
                b["unnum"] = True
    res = _Blocks(blocks)
    try:
        res.preamble = _layout_preamble(pages, hf, body, body_exact, body_fam, pstats, hstats, left_default=default_left, lstats=lstats,
                                        title_added=not title_in_doc)
    except Exception:
        res.preamble = None
    return res


class _Blocks(list):
    preamble = None


def _layout_preamble(pages, hf, body, body_exact, body_fam, pstats, hstats, left_default, title_added, lstats=None):
    # Zeilenabstand: Abstand der Unterkanten aufeinanderfolgender Zeilen im Fließtext
    pit = []
    for ps in pstats:
        for a, b, sa, sb in zip(ps["ys"], ps["ys"][1:], ps["sizes"], ps["sizes"][1:]):
            if abs(sa - body) < 0.8 and abs(sb - body) < 0.8 and 0.9 * body < b - a < 2.2 * body:
                pit.append(b - a)
    pitch = _median(pit, {10: 12.0, 11: 13.6, 12: 14.5}.get(round(body), body * 1.2))
    # Absatzabstand und Einzug
    extra = []
    for a, b in zip(pstats, pstats[1:]):
        if a["item"] == b["item"] and a["page"] == b["page"]:
            d = b["ys"][0] - a["ys"][-1] - pitch
            if -2 < d < 3 * body:
                extra.append(max(0.0, d))
    parskip = _median(extra, 0.0)
    if parskip < 1.0:
        parskip = 0.0
    ind = [ps["x0"] - ps["left"] for ps in pstats if ps["x0"] - ps["left"] > 0.4 * body]
    parindent = 0.0
    if pstats and len(ind) >= 0.4 * len(pstats) and len(ind) >= 2:
        parindent = _median(ind)
    # Blocksatz?
    tot = ok = 0
    for ps in pstats:
        if ps["n"] >= 2:
            for r in ps["rights"]:
                tot += 1
                if abs(r - ps["right"]) <= 2.5:
                    ok += 1
    justify = (tot == 0) or ok >= 0.6 * tot
    if _DEBUG:
        print("justify", tot, ok, [(ps["rights"], ps["right"]) for ps in pstats if ps["n"] >= 2])
    # Seitenränder
    p0 = pages[0]
    lines_all = [(pi, l) for pi, p in enumerate(pages) for l in p["lines"]]
    if lines_all:
        xl = Counter(round(l.bbox[0]) for _, l in lines_all if len(l.text) > 25)
        left = xl.most_common(1)[0][0] if xl else left_default
        rights = sorted(l.bbox[2] for _, l in lines_all if len(l.text) > 30)
        right_edge = rights[min(len(rights) - 1, int(0.95 * len(rights)))] if rights else max(l.bbox[2] for _, l in lines_all)
        tops, bots = [], []
        def _b(l):
            return l.base if l.base is not None else l.bbox[3]
        for p in pages:
            if p["lines"]:
                first = min(p["lines"], key=lambda l: (l.bbox[1], l.bbox[0]))
                tops.append(_b(first))
                bots.append(max(_b(l) for l in p["lines"]))
        top = _median(tops) - 0.9964 * min((10, 11, 12), key=lambda k: abs(k - body_exact * BP))
        bots.sort()
        bottom_y = bots[min(len(bots) - 1, int(0.75 * len(bots)))] if len(bots) > 1 else bots[0]
    else:
        left, right_edge, top, bottom_y = 56.7, p0["w"] - 56.7, 56.7, p0["h"] - 56.7
    bottom_m = p0["h"] - bottom_y
    bottom_m = min(bottom_m, max(top, 56.7))
    g = {"body": body_exact * BP, "pitch": pitch * BP, "body_fam": body_fam, "paper": _paper(p0["w"], p0["h"]),
         "left": left, "right": p0["w"] - right_edge, "top": top, "bottom": bottom_m, "hf": hf,
         "parskip": parskip, "parindent": parindent, "justify": justify, "times": False}
    names = Counter()
    for p in pages:
        for l in p["lines"]:
            pass
    g["times"] = _TIMES_HINT[0]
    g["fonts"] = _font_roles(pages, body_fam)
    if hf["head"]:
        g["head_h"] = (hf.get("head_bottom", 0) - hf.get("head_top", 0)) * 1.0
        hh = max(12.0, g["head_h"])
        g["head_h"] = hh
        g["head_sep"] = top - hf.get("head_base", hf.get("head_bottom", top)) - hh + 0.7 * pitch
    if hf["foot"]:
        g["foot_skip"] = max(0.0, hf.get("foot_base", hf.get("foot_bottom", 0)) - (p0["h"] - bottom_m))
    # Überschriften je Ebene
    heads = {}
    by = {}
    for h in hstats:
        by.setdefault(h["lvl"] + (1 if title_added else 0), []).append(h)
    for h in hstats:
        # folgt direkt eine weitere Überschrift, so gehört deren Zeilenhöhe zum gemessenen Abstand
        for h2 in hstats:
            if h2 is not h and h2["pg"] == h["pg"] and h["after"] is not None and h2["b0"] is not None and h["b1"] is not None \
                    and abs((h2["b0"] - h["b1"]) - h["after"]) < 0.6:
                h["after"] = h["after"] - 1.2 * h2["size"] + parskip
                break
    for lvl, hs in by.items():
        key = Counter((h["size"], h["bold"], h["fam"], h["color"], h["al"]) for h in hs).most_common(1)[0][0]
        hsz = key[0]
        bv = [h["before"] for h in hs if h["before"] is not None]
        av = [h["after"] for h in hs if h["after"] is not None]
        # Bilder zwischen Überschrift und Text blähen den Abstand nur auf: kleinster Wert gilt
        bef = (min(bv) if bv else 1.2 * hsz + 8.0) - 1.2 * hsz - parskip
        aft = (min(av) if av else pitch + 4.0) - pitch - parskip
        # Maße der Zeilenkästen -> Abstände zwischen den Zeilengrundlinien
        heads[lvl] = (key, round(bef, 1), round(aft, 1))
    g["heads"] = heads
    if lstats and lstats["item"]:
        g["list_item"] = min(lstats["item"]) - pitch
    if lstats and lstats["top"]:
        g["list_top"] = _median(lstats["top"]) - pitch - parskip
    return _build_preamble(g)


_TIMES_HINT = [False]
_DEBUG = False


# ---------------------------------------------------------------- Kopf- und Fußzeilen, Seitenaufbau
PN = "\ue500"        # Platzhalter für die Seitenzahl


def _inl_tex(inls):
    """Textstücke des Zwischenmodells -> LaTeX-Text (für Kopf- und Fußzeilen)."""
    from .latex_out import esc
    out = []
    for x in inls:
        if x["t"] == "raw":
            out.append(x["s"])
            continue
        if x["t"] != "txt":
            continue
        t = esc(x["s"]).replace(PN, "\\thepage{}")
        lead = t[:len(t) - len(t.lstrip(" "))]
        trail = t[len(t.rstrip(" ")):] if t.strip(" ") else ""
        core = t.strip(" ")
        if not core:
            out.append(t)
            continue
        if x.get("tt"):
            core = "\\texttt{%s}" % core
        if x.get("sup"):
            core = "\\textsuperscript{%s}" % core
        if x.get("sub"):
            core = "\\textsubscript{%s}" % core
        if x.get("st"):
            core = "\\sout{%s}" % core
        if x.get("u"):
            core = "\\uline{%s}" % core
        if x.get("i"):
            core = "\\textit{%s}" % core
        if x.get("b"):
            core = "\\textbf{%s}" % core
        if x.get("fam") and not x.get("tt"):
            core = "\\text%s{%s}" % (x["fam"], core)
        if x.get("color"):
            core = "\\textcolor[HTML]{%s}{%s}" % (x["color"], core)
        if x.get("size"):
            core = "\\fsz{%g}{%s}" % (x["size"], core)
        out.append(lead + core + trail)
    return "".join(out)


def _extract_header_footer(pages, body):
    """Kopf- und Fußzeilen aus den Seiten nehmen. Liefert {'head': {'L','C','R'}, 'foot': {...},
    'headrule', 'footrule', 'head_bottom', 'foot_top', 'head_h', 'foot_h'} (Abstände in pt)."""
    n = len(pages)
    info = {"head": {}, "foot": {}, "headrule": False, "footrule": False}
    cnt = Counter()
    offs = Counter()
    for pno, p in enumerate(pages):
        h = p["h"]
        seen = set()
        for l in p["lines"]:
            if l.bbox[3] < h * 0.12 or l.bbox[1] > h * 0.86:
                key = re.sub(r"\d+", "#", l.text.strip())
                if key not in seen:
                    seen.add(key)
                    cnt[key] += 1
                t = l.text.strip()
                if t.isdigit() and len(t) <= 4:
                    offs[int(t) - pno] += 1
    rep = set()
    if n >= 2:
        rep = {k for k, v in cnt.items() if v >= max(2, 0.5 * n)}
    pn_off = None
    if offs:
        o, c = offs.most_common(1)[0]
        if c >= 2 or (n == 1 and o == 1):
            pn_off = o
    per_page = []      # je Seite {(zone, slot): [Zeilen]}
    for pno, p in enumerate(pages):
        h = p["h"]
        keep, hf = [], []
        for l in p["lines"]:
            top = l.bbox[3] < h * 0.12
            bot = l.bbox[1] > h * 0.86
            t = l.text.strip()
            key = re.sub(r"\d+", "#", t)
            is_pn = pn_off is not None and (top or bot) and t.isdigit() and int(t) - pno == pn_off
            small_edge = n <= 1 and l.size <= body * 1.1 and (l.bbox[3] < h * 0.075 or l.bbox[1] > h * 0.925)
            if (top or bot) and (key in rep or is_pn or small_edge):
                hf.append((l, "head" if top else "foot"))
            else:
                keep.append(l)
        p["lines"] = keep
        per_page.append(hf)
    if not any(per_page):
        return info
    # Ränder aus dem Fließtext schätzen, um Linksbündig, Mitte und Rechtsbündig zu unterscheiden
    xs0 = Counter(round(l.bbox[0]) for p in pages for l in p["lines"])
    left_m = xs0.most_common(1)[0][0] if xs0 else 56
    rights = sorted(l.bbox[2] for p in pages for l in p["lines"] if len(l.text) > 30) or \
        [max([l.bbox[2] for p in pages for l in p["lines"]] or [pages[0]["w"] - 56])]
    right_m = rights[min(len(rights) - 1, int(0.95 * len(rights)))]
    pw = pages[0]["w"]
    slots = {}
    ypos = {"head": [], "foot": []}
    ybase = {"head": [], "foot": []}
    for pno, hf in enumerate(per_page):
        groups = {}
        for l, zone in hf:
            x0, x1 = l.bbox[0], l.bbox[2]
            cx = (x0 + x1) / 2
            dl, dr, dc = abs(x0 - left_m), abs(right_m - x1), abs(cx - pw / 2)
            slot = "L" if dl <= dr and dl <= dc else ("R" if dr < dc else "C")
            if x1 - x0 > 0.7 * (right_m - left_m):
                slot = "C"
            groups.setdefault((zone, slot), []).append(l)
            ypos[zone].append((l.bbox[1], l.bbox[3]))
            ybase[zone].append(l.base if l.base is not None else l.bbox[3] - 0.2 * l.size)
        for key, ls in groups.items():
            ls.sort(key=lambda l: (l.bbox[1], l.bbox[0]))
            parts = []
            for l in ls:
                inl = _inlines([l])
                for x in inl:
                    if x["t"] == "txt" and pn_off is not None:
                        want = str(pno + pn_off)
                        x["s"] = re.sub(r"(?<!\d)%s(?!\d)" % re.escape(want), PN, x["s"])
                parts.append(_inl_tex(inl))
            tex = " \\\\ ".join(t for t in parts if t.strip())
            slots.setdefault(key, []).append(tex)
    for (zone, slot), vals in slots.items():
        best, c = Counter(vals).most_common(1)[0]
        if c >= max(1, 0.5 * n) and best.strip():
            info[zone][slot] = best
    for zone in ("head", "foot"):
        if ypos[zone]:
            ys0 = sorted(a for a, b in ypos[zone])
            ys1 = sorted(b for a, b in ypos[zone])
            info[zone + "_top"] = ys0[len(ys0) // 2]
            info[zone + "_bottom"] = ys1[len(ys1) // 2]
            info[zone + "_base"] = _median(ybase[zone])
    # Linien über der Fußzeile oder unter der Kopfzeile
    for zone in ("head", "foot"):
        if not info[zone]:
            continue
        hits = 0
        for p in pages:
            body_y0 = min([l.bbox[1] for l in p["lines"]] or [p["h"] * 0.1])
            body_y1 = max([l.bbox[3] for l in p["lines"]] or [p["h"] * 0.9])
            for x0, x1, y in p["rules"]:
                if x1 - x0 >= 0.5 * (right_m - left_m):
                    if zone == "head" and y < body_y0 and y < p["h"] * 0.2:
                        hits += 1
                        break
                    if zone == "foot" and y > body_y1 and y > p["h"] * 0.8:
                        hits += 1
                        break
        info[zone + "rule"] = hits >= max(1, 0.5 * n)
    return info


def _median(v, default=0.0):
    v = sorted(v)
    return v[len(v) // 2] if v else default


def _paper(w, h):
    for name, (a, b) in (("a4paper", (595.3, 841.9)), ("a5paper", (419.5, 595.3)), ("a3paper", (841.9, 1190.6)),
                         ("letterpaper", (612, 792)), ("legalpaper", (612, 1008))):
        if abs(w - a) < 4 and abs(h - b) < 4:
            return name, None
    return None, "paperwidth=%.1fmm,paperheight=%.1fmm" % (w / 72 * 25.4, h / 72 * 25.4)


def _mm(pt):
    return "%.1fmm" % (max(0.0, pt) / 72 * 25.4)


def _titlefmt(cmd, st):
    size, bold, fam, color, al = st
    f = "\\fontsize{%g}{%g}\\selectfont" % (_pt(size), round(_pt(size) * 1.2, 2))
    f += "\\sffamily" if fam == "sf" else "\\rmfamily"
    f += "\\bfseries" if bold else "\\mdseries"
    if color:
        f += "\\color[HTML]{%s}" % color
    f += {"center": "\\centering", "right": "\\raggedleft"}.get(al, "\\raggedright")
    return f


def _build_preamble(g):
    """Präambel passend zum PDF: Papier, Ränder, Schrift, Zeilenabstand, Kopf- und Fußzeile, Überschriftenformate."""
    body, pitch = g["body"], g["pitch"]
    cls_size = min((10, 11, 12), key=lambda k: abs(k - body))
    L = ["\\documentclass[%dpt,%s]{article}" % (cls_size, g["paper"][0] or "a4paper")]
    fnt = g.get("fonts")
    if fnt:
        L.append("\\usepackage{iftex}")
        L.append("\\ifPDFTeX")
    fb = []
    if g["body_fam"] == "sf":
        fb.append("\\IfFileExists{helvet.sty}{\\usepackage[T1]{fontenc}\\usepackage{helvet}}"
                 "{\\IfFileExists{lmodern.sty}{\\usepackage[T1]{fontenc}\\usepackage{lmodern}}{}}")
        fb.append("\\renewcommand{\\familydefault}{\\sfdefault}")
    elif g["times"]:
        fb.append("\\IfFileExists{mathptmx.sty}{\\usepackage[T1]{fontenc}\\usepackage{mathptmx}}"
                 "{\\IfFileExists{lmodern.sty}{\\usepackage[T1]{fontenc}\\usepackage{lmodern}}{}}")
    else:
        fb.append("\\IfFileExists{lmodern.sty}{\\usepackage[T1]{fontenc}\\usepackage{lmodern}}{}")
    if g["body_fam"] != "sf":
        fb.append("\\IfFileExists{helvet.sty}{\\usepackage{helvet}}{}")
    fb.append("\\IfFileExists{courier.sty}{\\usepackage{courier}}{}")
    L.extend(fb)
    if fnt:
        L.append("\\else")
        L.append("\\usepackage{fontspec}\\setmainfont{%s}" % fnt["main"] + ("\\setsansfont{%s}" % fnt["sans"] if fnt["sans"] else "")
                 + ("\\setmonofont{%s}" % fnt["mono"] if fnt["mono"] else ""))
        if g["body_fam"] == "sf":
            L.append("\\renewcommand{\\familydefault}{\\sfdefault}")
        L.append("\\fi")
    L.append("\\IfFileExists{ngerman.ldf}{\\usepackage[ngerman]{babel}}{}")
    L.append("\\usepackage[table]{xcolor}")
    L.append("\\newcommand{\\fsz}[2]{{\\fontsize{#1}{\\dimexpr#1pt*12/10\\relax}\\selectfont #2}}")
    opts = [g["paper"][0] or g["paper"][1],
            "left=%s" % _mm(g["left"]), "right=%s" % _mm(g["right"]),
            "top=%s" % _mm(g["top"]), "bottom=%s" % _mm(g["bottom"])]
    hf = g["hf"]
    if hf["head"]:
        opts.append("headheight=%gbp" % round(max(12.0, g.get("head_h", 12.0)), 1))
        opts.append("headsep=%gbp" % round(max(4.0, g.get("head_sep", 12.0)), 1))
    else:
        opts.append("nohead")
    if hf["foot"]:
        opts.append("footskip=%gbp" % round(max(8.0, g.get("foot_skip", 24.0)), 1))
    else:
        opts.append("nofoot")
    L.append("\\IfFileExists{geometry.sty}{\\usepackage[%s]{geometry}}{}" % ",".join(o for o in opts if o))
    if hf["head"] or hf["foot"]:
        L.append("\\usepackage{fancyhdr}\\pagestyle{fancy}\\fancyhf{}")
        for zone, cmd in (("head", "fancyhead"), ("foot", "fancyfoot")):
            for slot in "LCR":
                if hf[zone].get(slot):
                    L.append("\\%s[%s]{%s}" % (cmd, slot, hf[zone][slot]))
        L.append("\\renewcommand{\\headrulewidth}{%s}\\renewcommand{\\footrulewidth}{%s}"
                 % ("0.4pt" if hf["headrule"] else "0pt", "0.4pt" if hf["footrule"] else "0pt"))
    else:
        L.append("\\pagestyle{empty}")
    L.append("\\usepackage{graphicx}\\usepackage{array}\\usepackage{longtable}")
    L.append("\\IfFileExists{ulem.sty}{\\usepackage[normalem]{ulem}}{\\newcommand{\\uline}[1]{\\underline{##1}}\\newcommand{\\sout}[1]{##1}}")
    L.append("\\IfFileExists{hyperref.sty}{\\usepackage[hidelinks]{hyperref}}{\\newcommand{\\href}[2]{##2}\\newcommand{\\url}[1]{\\texttt{##1}}}")
    L.append("\\makeatletter\\renewcommand\\normalsize{\\@setfontsize\\normalsize{%g}{%g}}\\makeatother"
             % (round(body, 2), round(pitch, 2)))
    L.append("\\setlength{\\parindent}{%gbp}" % round(g["parindent"], 1))
    L.append("\\setlength{\\parskip}{%gbp}\\setlength{\\topsep}{0pt}\\setlength{\\partopsep}{0pt}" % round(g["parskip"], 1))
    if "list_item" in g or "list_top" in g:
        L.append("\\IfFileExists{enumitem.sty}{\\usepackage{enumitem}\\setlist{itemsep=%gbp,parsep=0pt,partopsep=0pt,topsep=%gbp}}{}"
                 % (round(g.get("list_item", 0.0), 1), round(g.get("list_top", 0.0), 1)))
    if not g["justify"]:
        L.append("\\raggedright")
    if g["heads"]:
        tl = []
        cmds = ["section", "subsection", "subsubsection", "paragraph", "subparagraph", "subparagraph"]
        for lvl, st in sorted(g["heads"].items()):
            if lvl - 1 >= len(cmds) - 1 and lvl > 5:
                continue
            c = cmds[lvl - 1]
            fmt, bef, aft = st
            tl.append("\\titleformat{\\%s}[block]{%s}{\\the%s}{0.6em}{}\\titlespacing*{\\%s}{0pt}{%gbp}{%gbp}"
                      % (c, _titlefmt(c, fmt), c, c, bef, aft))
        L.append("\\IfFileExists{titlesec.sty}{\\usepackage{titlesec}%s}{}" % "".join(tl))
    return "\n".join(L) + "\n"


def _join_pages(blocks):
    """Absatz, der am Seiten- oder Spaltenende abbricht, mit dem folgenden Absatz verbinden."""
    out = []
    for b in blocks:
        if out and b.get("t") == "p" and out[-1].get("t") == "p" and not b.get("h") and not out[-1].get("h") \
                and not b.get("code") and not out[-1].get("code") and not b.get("al") and not out[-1].get("al") \
                and (out[-1].get("_pageend") or out[-1].get("_col_end")) and out[-1]["inl"] and b["inl"]:
            last = out[-1]["inl"][-1]["s"].rstrip()
            first = b["inl"][0]["s"]
            if last and (first[:1].islower() or last[-1] not in END_SENT) and first.strip():
                if last.endswith("-") and len(last) > 1 and last[-2].isalpha():
                    out[-1]["inl"][-1]["s"] = last[:-1]
                else:
                    out[-1]["inl"].append(txt(" "))
                out[-1]["inl"] = _merge(out[-1]["inl"] + b["inl"])
                out[-1]["_pageend"] = b.get("_pageend")
                out[-1]["_col_end"] = b.get("_col_end")
                continue
        out.append(b)
    return out
