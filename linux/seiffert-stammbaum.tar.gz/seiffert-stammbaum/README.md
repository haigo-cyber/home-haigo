Seifferts Stammbaum für Linux
=============================

Installation im Terminal
------------------------

    tar -xzf seiffert-stammbaum.tar.gz
    cd seiffert-stammbaum  # bzw. den entpackten Ordner betreten
    ./install.sh

Das Stammbaum-Tool als eigenes Fenster. Es zeigt dieselbe HTML-Datei wie die Browser-Version (stammbaum.html, unverändert). Das Programm ergänzt nur, was ein eingebetteter Browser nicht kann: Dateien und Ordner mit echten Pfaden, Speichern-Dialoge, die Anmeldung bei Google Drive über den normalen Browser, Drucken als PDF und die Kartenbibliothek ohne Netz.

Voraussetzungen
---------------

Python 3 und PySide6 mit QtWebEngine. Unter Arch/EndeavourOS:

    sudo pacman -S pyside6 qt6-webengine

Alternativ in einer eigenen Umgebung:

    python3 -m venv --system-site-packages ~/.local/share/seiffert-stammbaum-app/venv
    ~/.local/share/seiffert-stammbaum-app/venv/bin/pip install PySide6 PySide6-WebEngine

Installation (ohne sudo)
------------------------

    tar -xzf seiffert-stammbaum.tar.gz
    cd seiffert-stammbaum
    ./install.sh

Danach steht "Seifferts Stammbaum" im Menü. Start im Terminal: ~/.local/bin/seiffert-stammbaum. Entfernen mit ./install.sh --remove (Einstellungen und Verbindungen bleiben erhalten). Ohne Installation geht auch: python3 app.py

Datei und Ordner
----------------

Wie in der Browser-Version: "Datei öffnen" wählt die Hauptdatei, "Ordner verbinden" den Medienordner. Beides wird gespeichert und beim nächsten Start automatisch wieder verbunden. Eine Berechtigungsabfrage wie im Browser gibt es nicht. Gespeichert wird weiterhin mit Prüfung, mit Vorversionen und mit Warnung, wenn die Datei außerhalb geändert wurde. Das Programm darf nur Pfade lesen und schreiben, die du über einen Auswahldialog gewählt hast.

Downloads (Berichte, Kalender, CSV, Viewer-Datei, GEDCOM-Export) öffnen einen Speichern-Dialog. Drucken speichert die aktuelle Ansicht als PDF.

Google Drive (Datensicherung)
-----------------------------

Die Sicherung, die Wiederherstellung und der Ordner "Stammbaum Daten" funktionieren wie im HTML-Tool. Eingerichtet wird so:

1. Die neue Fassung des HTML-Tools (stammbaum.html aus diesem Paket) auf GitHub Pages veröffentlichen, wie du es sonst auch tust. Sie enthält zusätzlich die Anmeldeseite für das Linux-Programm.
2. Im Programm den Knopf für die Google-Anmeldung drücken. Beim ersten Mal fragt ein Fenster nach der Internetadresse deines Tools (die Adresse, die du im Browser benutzt). Sie wird gespeichert.
3. Der normale Browser öffnet die Seite. Dort auf "Bei Google anmelden" klicken, wie sonst auch. Danach das Browserfenster schließen.

Es ist keine Einrichtung bei Google nötig. Das Programm benutzt dieselbe Client-ID wie das HTML-Tool, weil die Anmeldung über deine veröffentlichte Seite läuft. Das Anmeldetoken gilt wie im Browser etwa eine Stunde. Danach meldest du dich beim nächsten Klick auf die Anmeldung wieder an. Das Token wird nicht auf der Platte gespeichert, nur die Adresse (in ~/.config/seiffert-stammbaum/settings.json).

Kommt nach dem Klick nur die normale Seite und keine Anmeldeseite, ist unter der Adresse noch die alte Fassung veröffentlicht. Nach fünf Minuten ohne Anmeldung bricht das Programm ab.

Kartenansicht
-------------

Die Kartenbibliothek (Leaflet) liegt im Paket. Die Kartenkacheln und die Ortssuche brauchen weiterhin Internet.

Neue Fassung des HTML-Tools übernehmen
--------------------------------------

Das Paket enthält keine eigene Kopie des Tools, sondern genau die HTML-Datei, die es zum Zeitpunkt des Baus gab (Stand siehe Info im Programm). Für eine neue Fassung:

1. Im entpackten Ordner die Datei stammbaum.html durch die neue ersetzen (gleicher Name).
2. ./install.sh erneut ausführen.

Der Python-Teil (app.py, shim.js) muss nur angefasst werden, wenn das HTML-Tool neue Browser-Funktionen benutzt, die QtWebEngine nicht kennt.

Grenzen
-------

Nicht geprüft: das Verhalten auf deinem Arch-System und die echte Google-Anmeldung. Die Tests liefen mit einem Nachbau der Google-Schnittstellen.


Fehlersuche Google Drive: Das Programm schreibt ein kurzes Protokoll der Google-Zugriffe (ohne Token und ohne Dateiinhalte) nach ~/.local/share/seiffert-stammbaum/protokoll.txt
