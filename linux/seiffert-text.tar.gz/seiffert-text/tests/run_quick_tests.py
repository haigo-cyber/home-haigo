"""Prüfungen der Schnellbearbeitung:  QT_QPA_PLATFORM=offscreen python tests/run_quick_tests.py
Der Vergleich mit dem Originalkern des HTML-Schnelleditors braucht Node (fehlt es, wird er übersprungen),
das Übersetzen braucht pdflatex."""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
from PySide6.QtGui import QColor, QImage
from PySide6.QtWidgets import QApplication, QMessageBox, QWidget

app = QApplication([])
import seiffert_text.app as A
from seiffert_text import quick as Q
from seiffert_text.quick_view import Fld

TMP = tempfile.mkdtemp(prefix="st-quick-")
A.CONF_DIR = TMP
A.CONF_FILE = os.path.join(TMP, "settings.json")
OK = FAIL = SKIP = 0


def check(name, cond, extra=""):
    global OK, FAIL
    if cond:
        OK += 1
    else:
        FAIL += 1
        print("FEHLER:", name, extra)


def pump(ms=100):
    end = time.time() + ms / 1000
    while time.time() < end:
        app.processEvents()
        time.sleep(0.01)


# ---- 1. Vergleich mit dem Originalkern (Node)
node = shutil.which("node") or ("/opt/node22/bin/node" if os.path.exists("/opt/node22/bin/node") else None)
VOR = os.path.join(HERE, "..", "seiffert_text", "vorlagen")
files = [os.path.join(HERE, "quick_oracle", "stress.tex")] + [os.path.join(VOR, n) for n in sorted(os.listdir(VOR))]
if node:
    od = os.path.join(HERE, "quick_oracle")
    js = subprocess.run([node, "h.js"] + files, cwd=od, capture_output=True, text=True)
    py = subprocess.run([sys.executable, "h.py"] + files, cwd=od, capture_output=True, text=True)
    check("Vergleich: beide Läufe liefen", js.returncode == 0 and py.returncode == 0, js.stderr[-300:] + py.stderr[-300:])

    def nz(o):
        if isinstance(o, float) and o == int(o):
            return int(o)
        if isinstance(o, list):
            return [nz(x) for x in o]
        if isinstance(o, dict):
            return {k: nz(v) for k, v in o.items()}
        return o
    if js.returncode == 0 and py.returncode == 0:
        a, b = nz(json.loads(js.stdout)), nz(json.loads(py.stdout))
        for f in a:
            for k in a[f]:
                check("Vergleich %s / %s" % (os.path.basename(f), k), json.dumps(a[f][k], sort_keys=True) == json.dumps(b[f][k], sort_keys=True))
else:
    SKIP += 1
    print("Node fehlt: Vergleich mit dem Originalkern übersprungen")

# ---- 2. Eigenschaften des Modells
t = open(os.path.join(VOR, "Lernplan mit Themen.tex"), encoding="utf-8", newline="").read()
d = Q.parse_tex(t)
check("Modell: unveränderte Vorlage kommt Zeichen für Zeichen zurück", Q.serialize(d, {"autoEscape": True, "autoBreak": False}) == t)
crlf = t.replace("\n", "\r\n")
d2 = Q.parse_tex(crlf)
check("Modell: CRLF bleibt erhalten", Q.serialize_file(d2, {"autoEscape": True, "autoBreak": False}) == crlf)
try:
    Q.parse_tex("kein Dokument")
    check("Modell: Datei ohne document wird abgelehnt", False)
except Q.TexError:
    check("Modell: Datei ohne document wird abgelehnt", True)
check("Modell: Nummerierung beginnt bei 01", Q.next_template_name("Plan", ["Plan.tex"]) == ("Plan01.tex", True))
check("Modell: Nummerierung zählt weiter", Q.next_template_name("Plan01", ["Plan.tex", "Plan01.tex", "Plan02.tex"]) == ("Plan03.tex", False))

# ---- 3. Bedienung
out = os.path.join(TMP, "ziel")
os.makedirs(os.path.join(out, "content"))
im = QImage(40, 30, QImage.Format.Format_RGB32)
im.fill(QColor("red"))
im.save(os.path.join(out, "EvT.png"))
im.save(os.path.join(out, "content", "bild1.png"))
_q = QMessageBox.question
QMessageBox.question = staticmethod(lambda *a, **k: QMessageBox.StandardButton.Yes)
w = A.MainWindow()
w.settings["quick_outdir"] = out
tpl = dict(w.builtin_templates())
check("Vorlagen: zwei eingebaute", set(tpl) == {"Lernplan mit Themen", "Lernplan einfach"})
check("Vorlage laden", w.open_template(tpl["Lernplan mit Themen"], "Lernplan mit Themen", "builtin:Lernplan mit Themen", None)
      and w.view == A.VIEW_QUICK)
check("Vorlage hat keinen Dateipfad (kann nicht überschrieben werden)", w.path is None)
qv = w.quick
doc = w.q_doc
u = [x for x in doc["units"] if Q.has_fields(x)][0]
f = qv.host.findChild(QWidget, "row%d" % u["id"]).findChildren(Fld)[0]
f.setPlainText("Bruchrechnen & mehr 50%")
qv.flush_typing()
qv.commit_if_changed()
check("Feld ändern wirkt im LaTeX-Text", "Bruchrechnen \\& mehr 50\\%" in w.tex_edit.toPlainText())
check("Feld ändern markiert als geändert", w.modified)
n = len(doc["units"])
qv.enter_below(u, 0)
check("Enter legt Zeile an", len(w.q_doc["units"]) == n + 1)
qv.do_undo()
check("Rückgängig", len(w.q_doc["units"]) == n)
qv.do_redo()
check("Wiederholen", len(w.q_doc["units"]) == n + 1)
# Kopfdaten
# Name, Speichern
qv.ed_name.setText("Tim")
qv.on_name_edited("Tim")
check("Speichern unter anderem Namen", qv.save_tex() and os.path.exists(os.path.join(out, "Tim.tex")))
saved = open(os.path.join(out, "Tim.tex"), encoding="utf-8").read()
check("Gespeicherte Datei enthält die Änderung", "Bruchrechnen \\& mehr 50\\%" in saved)
check("Original-Text der Vorlage unverändert im Speicher", w.q_original == tpl["Lernplan mit Themen"].replace("\r\n", "\n"))
# Ansichtswechsel behält den Stand
w.set_view(A.VIEW_RICH)
w.set_view(A.VIEW_QUICK)
check("Wechsel Formatiert und zurück behält die Zeilen", len(w.q_doc["units"]) == n + 1)
w.set_view(A.VIEW_TEX)
check("LaTeX-Ansicht zeigt den bearbeiteten Text", "Bruchrechnen" in w.tex_edit.toPlainText())

# ---- 4. Übersetzen (echtes pdflatex; ohne die Sprachoption, falls ngerman im System fehlt)
if shutil.which("pdflatex"):
    w2 = A.MainWindow()
    w2.settings["quick_outdir"] = out
    w2.open_template(tpl["Lernplan mit Themen"].replace("\\usepackage[ngerman]{babel}", ""), "Lernplan", "file", None)
    for nm in ("Tim", "Tim Meier"):
        w2.quick.ed_name.setText(nm)
        w2.quick.on_name_edited(nm)
        w2.compile()
        for i in range(600):
            pump(100)
            if w2.proc is None:
                break
        pdf = os.path.join(w2.work, nm + ".pdf")
        check("Übersetzen mit Dateiname %r als Jobname" % nm, os.path.exists(pdf) and w2.lbl_compile.text() == "Fertig", w2.lbl_compile.text())
        if shutil.which("pdftotext") and os.path.exists(pdf):
            txt = subprocess.run(["pdftotext", pdf, "-"], capture_output=True, text=True).stdout
            check("Dateiname steht im Seitenkopf (%r)" % nm, nm in txt)
    w2.modified = False
    w2.close()
else:
    SKIP += 1
    print("pdflatex fehlt: Übersetzen übersprungen")


# ---- 5. Kontrollkästchen
from PySide6.QtCore import QPoint, Qt
from PySide6.QtGui import QTextCursor
from PySide6.QtTest import QTest
wb = A.MainWindow()
wb.show()
wb.rich.setPlainText("Aufgabe eins\nAufgabe zwei\n\nAufgabe drei")
wb.rich.selectAll()
wb.ins_checkbox(False)
check("Kästchen: jede markierte Zeile bekommt eines, Leerzeile nicht",
      wb.rich.toPlainText() == "\u2610 Aufgabe eins\n\u2610 Aufgabe zwei\n\n\u2610 Aufgabe drei", repr(wb.rich.toPlainText()))
wb.rich.selectAll()
wb.ins_checkbox(False)
check("Kästchen: schon vorhandene werden nicht verdoppelt", wb.rich.toPlainText().count("\u2610") == 3)
c = QTextCursor(wb.rich.document())
c.setPosition(0)
r0, r1 = wb.rich.cursorRect(c), None
c.setPosition(1)
r1 = wb.rich.cursorRect(c)
QTest.mouseDClick(wb.rich.viewport(), Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier,
                  QPoint((r0.left() + r1.left()) // 2, r0.center().y()))
check("Kästchen: Doppelklick kreuzt an", wb.rich.toPlainText().startswith("\u2612 Aufgabe eins"), repr(wb.rich.toPlainText()[:12]))
QTest.mouseDClick(wb.rich.viewport(), Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier,
                  QPoint((r0.left() + r1.left()) // 2, r0.center().y()))
check("Kästchen: zweiter Doppelklick leert wieder", wb.rich.toPlainText().startswith("\u2610 Aufgabe eins"))
wb.set_view(A.VIEW_TEX)
tx = wb.tex_edit.toPlainText()
check("Kästchen: LaTeX enthält $\\square$ und amssymb", "$\\square$ Aufgabe eins" in tx and "amssymb" in tx)
wb.set_view(A.VIEW_RICH)
check("Kästchen: LaTeX zurück in die formatierte Ansicht", wb.rich.toPlainText().count("\u2610") == 3, repr(wb.rich.toPlainText()))
wb.set_view(A.VIEW_TEX)
wb.tex_edit.setPlainText(tx.replace("amssymb", "amsmath"))
c = wb.tex_edit.textCursor()
c.setPosition(wb.tex_edit.toPlainText().index("Aufgabe drei"))
wb.tex_edit.setTextCursor(c)
wb.ins_checkbox(True)
check("Kästchen: in der LaTeX-Ansicht eingefügt, amssymb ergänzt",
      "$\\boxtimes$ Aufgabe drei" in wb.tex_edit.toPlainText().replace("$\\square$ ", "") or "$\\boxtimes$ " in wb.tex_edit.toPlainText())
check("Kästchen: amssymb genau einmal", wb.tex_edit.toPlainText().count("{amssymb}") == 1)
if shutil.which("pdflatex"):
    dd = os.path.join(TMP, "box")
    os.makedirs(dd)
    open(os.path.join(dd, "b.tex"), "w", encoding="utf-8").write(wb.tex_edit.toPlainText())
    rr = subprocess.run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "b.tex"], cwd=dd, capture_output=True, text=True)
    check("Kästchen: LaTeX-Text übersetzt mit pdflatex", rr.returncode == 0, rr.stdout[-300:])
# Schnellbearbeitung: Kästchen im Feld, Vorlage ohne amssymb
w3 = A.MainWindow()
w3.settings["quick_outdir"] = out
import re as _re
tpl_ohne = _re.sub(r"[^\n]*amssymb[^\n]*\n", "", tpl["Lernplan einfach"])
w3.open_template(tpl_ohne, "einfach", "file", None)
u3 = [x for x in w3.q_doc["units"] if Q.has_fields(x)][-1]
w3.quick.render_editor()
f3 = w3.quick.host.findChild(QWidget, "row%d" % u3["id"]).findChildren(Fld)[0]
f3.setFocus()
w3.quick.last_fld = f3
w3.quick.insert_box(False, u3)
check("Kästchen: Schnellbearbeitung setzt \\(\\square\\) ins Feld", "\\(\\square\\) " in w3.tex_edit.toPlainText())
check("Kästchen: Schnellbearbeitung ergänzt amssymb, wenn es fehlt",
      "amssymb" not in tpl_ohne and w3.tex_edit.toPlainText().count("{amssymb}") == 1)
w3.modified = False
w3.close()
wb.modified = False
wb.close()
QMessageBox.question = _q
w.modified = False
for tt in list(w.tabs.values()):
    tt.s["modified"] = False
w.close()
shutil.rmtree(TMP, ignore_errors=True)
print("Ergebnis: %d Prüfungen ok, %d Fehler, %d übersprungen" % (OK, FAIL, SKIP))
sys.exit(1 if FAIL else 0)
