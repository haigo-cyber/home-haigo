"""Befehlsoberfläche: eine Befehlszeile wird in ein Formular zerlegt und wieder zusammengesetzt; Befehle lassen sich speichern.

Die Teile bleiben so erhalten, wie sie in der Befehlszeile stehen (mit Anführungszeichen), damit das Zusammensetzen den Befehl
nicht verändert, etwa bei Platzhaltern wie *.txt oder Umgebungsvariablen."""
from __future__ import annotations

import base64
import fcntl
import json
import os
import pty
import re
import select
import shlex
import shutil
import signal
import struct
import subprocess
import termios
import threading
import time
import uuid

import backend as B

AppError = B.AppError

PREFIXES = {"sudo", "doas", "time", "nice", "nohup", "env", "ionice"}
# Optionen, die erfahrungsgemäß keinen Wert nehmen; alles andere mit folgendem Nicht-Schalter gilt zunächst als Option mit Wert
BOOL_LONG = {
    "verbose", "recursive", "force", "quiet", "silent", "progress", "dry-run", "archive", "all", "human-readable", "help", "version",
    "interactive", "update", "delete", "remove", "parents", "preserve", "compress", "checksum", "list", "color", "colour", "debug",
    "ignore-case", "invert-match", "count", "line-number", "no-clobber", "no-preserve-root", "summarize", "dereference", "symbolic",
    "stats", "itemize-changes", "partial", "inplace", "whole-file", "times", "links", "perms", "owner", "group", "devices", "specials",
}
BOOL_SHORT = set("rRvaqhflxzuspWwHLPDI")      # grobe Voreinstellung für einzelne Buchstaben; im Formular umschaltbar
_SINGLE = re.compile(r"^-[A-Za-z0-9]$")
_CLUSTER = re.compile(r"^-[A-Za-z]{2,3}$")
_SHORTVAL = re.compile(r"^(-[A-Za-z])([0-9][^\s]*)$")
_OPS = set("|&;<>()")


def _tokens(line: str) -> list[str]:
    lex = shlex.shlex(line, posix=False, punctuation_chars=True)
    lex.whitespace_split = True
    lex.commenters = ""
    try:
        return list(lex)
    except ValueError as e:
        raise AppError("Die Befehlszeile ist nicht vollständig (Anführungszeichen offen?).") from e


def is_bool_long(name: str) -> bool:
    n = name.lstrip("-")
    return n in BOOL_LONG or n.startswith("no-") or n.startswith("dry")


def parse_command(line: str) -> dict:
    line = (line or "").strip()
    if not line:
        raise AppError("Bitte einen Befehl eingeben.")
    if "\n" in line:
        return {"complex": True, "line": line, "reason": "Der Befehl hat mehrere Zeilen."}
    toks = _tokens(line)
    if any(t and set(t) <= _OPS for t in toks):
        return {"complex": True, "line": line, "reason": "Der Befehl enthält Verkettungen oder Umleitungen (zum Beispiel | && > ;). Dafür gibt es kein Formular, er lässt sich aber bearbeiten, speichern und ausführen."}
    prefix = []
    while toks and (toks[0] in PREFIXES or re.match(r"^[A-Za-z_][A-Za-z0-9_]*=", toks[0])) and len(toks) > 1:
        prefix.append(toks.pop(0))
    if not toks:
        raise AppError("Es fehlt das Programm.")
    program = toks.pop(0)
    items: list[dict] = []
    i = 0
    after_dd = False
    while i < len(toks):
        t = toks[i]
        i += 1
        if after_dd or not t.startswith("-") or t == "-" or re.match(r"^-[0-9.]+$", t):
            items.append({"k": "arg", "text": t})
            continue
        if t == "--":
            after_dd = True
            items.append({"k": "sep", "text": t})
            continue
        if t.startswith("--"):
            if "=" in t:
                name, val = t.split("=", 1)
                items.append({"k": "opt", "name": name, "value": val, "join": "="})
                continue
            nxt = toks[i] if i < len(toks) else None
            if nxt is not None and not nxt.startswith("-") and not is_bool_long(t):
                items.append({"k": "opt", "name": t, "value": nxt, "join": " "})
                i += 1
            else:
                items.append({"k": "flag", "text": t})
            continue
        m = _SHORTVAL.match(t)
        if m and not _CLUSTER.match(t):
            items.append({"k": "opt", "name": m.group(1), "value": m.group(2), "join": ""})
            continue
        nxt = toks[i] if i < len(toks) else None
        if _CLUSTER.match(t) and not (nxt is not None and re.match(r"^[0-9][0-9.]*$", nxt)):
            items.append({"k": "flag", "text": t})
            continue
        single_bool = _SINGLE.match(t) and t[1] in BOOL_SHORT
        if nxt is not None and not nxt.startswith("-") and not single_bool:
            items.append({"k": "opt", "name": t, "value": nxt, "join": " "})
            i += 1
        else:
            items.append({"k": "flag", "text": t})
    return {"complex": False, "prefix": prefix, "program": program, "items": items}


def build_command(model: dict) -> str:
    if model.get("complex"):
        return (model.get("line") or "").strip()
    parts = list(model.get("prefix") or [])
    prog = (model.get("program") or "").strip()
    if not prog:
        raise AppError("Es fehlt das Programm.")
    parts.append(prog)
    for it in model.get("items") or []:
        if it.get("on") is False:
            continue
        k = it.get("k")
        if k in ("flag", "arg", "sep"):
            txt = (it.get("text") or "").strip()
            if txt:
                parts.append(txt)
        elif k == "opt":
            name = (it.get("name") or "").strip()
            val = (it.get("value") or "").strip()
            j = it.get("join", " ")
            if not name:
                continue
            if not val:
                parts.append(name)
            elif j == "=":
                parts.append(name + "=" + val)
            elif j == "":
                parts.append(name + val)
            else:
                parts.extend([name, val])
    return " ".join(parts)


class CmdGui:
    _cmd_lock = threading.Lock()

    @staticmethod
    def _cmd_file():
        return B.config_dir() / "commands.json"

    def _cmd_load(self) -> list[dict]:
        try:
            data = json.loads(self._cmd_file().read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return []
        return [c for c in data if isinstance(c, dict) and c.get("id") and c.get("line")] if isinstance(data, list) else []

    def _cmd_store(self, items: list[dict]) -> None:
        f = self._cmd_file()
        f.parent.mkdir(parents=True, exist_ok=True)
        tmp = f.with_suffix(".tmp")
        tmp.write_text(json.dumps(items, ensure_ascii=False, indent=1), encoding="utf-8")
        os.replace(tmp, f)

    def api_cmd_parse(self, line: str) -> dict:
        return parse_command(line)

    def api_cmd_build(self, model: dict) -> dict:
        return {"line": build_command(model)}

    def api_cmd_saved(self) -> dict:
        with self._cmd_lock:
            return {"items": self._cmd_load()}

    def api_cmd_save(self, name: str, line: str, id: str = "") -> dict:
        name = (name or "").strip()
        line = (line or "").strip()
        if not name:
            raise AppError("Bitte einen Namen für den Befehl angeben.")
        if not line:
            raise AppError("Der Befehl ist leer.")
        if len(line) > 8000 or len(name) > 120:
            raise AppError("Name oder Befehl sind zu lang.")
        with self._cmd_lock:
            items = self._cmd_load()
            cur = next((c for c in items if c["id"] == id), None) if id else None
            if cur:
                cur.update(name=name, line=line)
            else:
                cur = {"id": uuid.uuid4().hex[:10], "name": name, "line": line, "created": int(time.time())}
                items.append(cur)
            items.sort(key=lambda c: c["name"].lower())
            self._cmd_store(items)
        return {"item": cur}

    def api_cmd_delete(self, id: str) -> dict:
        with self._cmd_lock:
            items = self._cmd_load()
            new = [c for c in items if c["id"] != id]
            if len(new) != len(items):
                self._cmd_store(new)
        return {"deleted": len(items) - len(new)}

    # ------------------------------------------------------------ Ausführen mit Ausgabe im Dialog
    MAX_RUNS = 4

    def _run_init(self) -> None:
        if not hasattr(self, "_runs"):
            self._runs: dict[int, dict] = {}
            self._run_next = 1
            self._run_lock = threading.Lock()

    def api_cmd_exec(self, line: str, cwd: str = "", cols: int = 100, rows: int = 24) -> dict:
        """Führt eine Befehlszeile aus. Ausgabe und Ende kommen als Ereignis "cmd". Die Eingabe ist geschlossen: Programme, die etwas
        erfragen (Passwörter, Ja/Nein), gehören ins Terminal."""
        self._run_init()
        line = (line or "").strip()
        if not line:
            raise AppError("Bitte einen Befehl eingeben.")
        d = os.path.expanduser(cwd) if cwd else os.path.expanduser("~")
        if not os.path.isdir(d):
            d = os.path.expanduser("~")
        with self._run_lock:
            if sum(1 for r in self._runs.values() if r["alive"]) >= self.MAX_RUNS:
                raise AppError("Es laufen schon %d Befehle. Bitte einen abbrechen oder warten." % self.MAX_RUNS)
            rid = self._run_next
            self._run_next += 1
        shell = shutil.which("bash") or "/bin/sh"
        env = dict(os.environ)
        env.update(TERM="xterm-256color", COLORTERM="truecolor")
        for k in ("QT_QPA_PLATFORM", "QTWEBENGINE_CHROMIUM_FLAGS", "SD_DEBUG", "PYTHONINSPECT"):
            env.pop(k, None)
        master, slave = pty.openpty()
        try:
            fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", max(2, int(rows)), max(2, int(cols)), 0, 0))
            proc = subprocess.Popen([shell, "-c", line], stdin=subprocess.DEVNULL, stdout=slave, stderr=slave, cwd=d, env=env,
                                    close_fds=True, start_new_session=True)
        except OSError as e:
            os.close(master)
            os.close(slave)
            raise AppError("Der Befehl konnte nicht gestartet werden: " + (e.strerror or str(e)))
        os.close(slave)
        r = {"proc": proc, "fd": master, "alive": True, "cancelled": False}
        with self._run_lock:
            self._runs[rid] = r
        threading.Thread(target=self._run_reader, args=(rid, r), name="sd-cmd-%d" % rid, daemon=True).start()
        return {"id": rid, "shell": os.path.basename(shell), "cwd": d}

    def _run_reader(self, rid: int, r: dict) -> None:
        fd, proc = r["fd"], r["proc"]
        pending, last = b"", time.monotonic()
        def flush():
            nonlocal pending, last
            if pending:
                self.emit("cmd", {"id": rid, "data": base64.b64encode(pending).decode("ascii")})
                pending, last = b"", time.monotonic()
        while True:
            try:
                ready, _, _ = select.select([fd], [], [], 0.1)
            except (OSError, ValueError):
                break
            if not ready:
                flush()
                if proc.poll() is not None:
                    try:
                        again, _, _ = select.select([fd], [], [], 0.05)
                    except (OSError, ValueError):
                        break
                    if not again:
                        break
                continue
            try:
                data = os.read(fd, 65536)
            except OSError:
                break
            if not data:
                break
            pending += data
            if len(pending) > 32768 or time.monotonic() - last > 0.05:
                flush()
        flush()
        r["alive"] = False
        try:
            code = proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            code = None
        try:
            os.close(fd)
        except OSError:
            pass
        self.emit("cmd", {"id": rid, "exit": code, "cancelled": r["cancelled"]})
        with self._run_lock:
            self._runs.pop(rid, None)

    def api_cmd_cancel(self, id: int) -> dict:
        self._run_init()
        r = self._runs.get(int(id))
        if not r or not r["alive"]:
            return {"cancelled": False}
        r["cancelled"] = True
        pid = r["proc"].pid
        try:
            os.killpg(pid, signal.SIGTERM)
        except OSError:
            pass
        def hard():
            time.sleep(3)
            if r["proc"].poll() is None:
                try:
                    os.killpg(pid, signal.SIGKILL)
                except OSError:
                    pass
        threading.Thread(target=hard, daemon=True).start()
        return {"cancelled": True}
