#!/usr/bin/env python3
"""Ergänzungen des Seifferts Starters ohne Oberfläche: eigene Befehle, eingebaute Aktionen und der Verlauf der Zwischenablage.

Befehle kommen aus drei Quellen:
  1. commands.json: was in Seifferts Dateien unter "Befehl als Oberfläche" (F8) gespeichert wurde,
  2. dem Ordner befehle.d im Konfigurationsordner: dort können andere Programme (oder du selbst) JSON-Dateien ablegen,
  3. eingebauten Aktionen (Farbdesign wechseln, Text vom Bildschirm lesen, Verlauf leeren).

Eine Datei in befehle.d enthält eine Liste von Einträgen:
  [{"name": "Tafel verbinden", "line": "seiffert-funk --tafel", "desc": "Bildschirm auf die Tafel spiegeln",
    "words": ["airplay", "apple tv"], "terminal": false, "confirm": false}]
Pflicht sind name und line. terminal = im Seifferts Terminal ausführen, confirm = vorher nachfragen."""
from __future__ import annotations

import hashlib
import json
import os
import shlex
import shutil
import socket
import subprocess
import tempfile
import threading
import time
from pathlib import Path

import skins

APP_ID = "seiffert-dateien"
MAX_LINE = 8000
MAX_DROPIN_FILES = 40
MAX_COMMANDS = 400
_OPS = set("|&;<>()`$")
TERMINAL_FIRST = {"sudo", "doas", "su", "ssh", "pacman", "yay", "paru", "top", "htop", "btop", "nano", "vim", "nvim", "less", "man"}


def config_dir() -> Path:
    return Path(os.environ.get("XDG_CONFIG_HOME") or (Path.home() / ".config")) / APP_ID


def dropin_dir() -> Path:
    return config_dir() / "befehle.d"


# ---------------------------------------------------------------------------------------------- Befehle
def _first_word(line: str) -> str:
    try:
        parts = shlex.split(line)
    except ValueError:
        return ""
    for p in parts:
        if "=" in p and not p.startswith("-") and p.split("=", 1)[0].isidentifier():
            continue                                             # VAR=wert vor dem Programm
        return os.path.basename(p)
    return ""


def needs_terminal(line: str) -> bool:
    """Grobe Einstufung: Programme, die etwas erfragen oder den Bildschirm füllen, gehören ins Terminal."""
    return _first_word(line) in TERMINAL_FIRST


def _clean(e, source: str, n: int) -> dict | None:
    if not isinstance(e, dict):
        return None
    name, line = str(e.get("name") or "").strip(), str(e.get("line") or "").strip()
    if not name or not line or len(line) > MAX_LINE or len(name) > 120 or any(ord(c) < 32 for c in name):
        return None
    if "{auswahl}" in line:                                      # braucht markierte Dateien, die es im Starter nicht gibt
        return None
    words = e.get("words") if isinstance(e.get("words"), list) else []
    cid = str(e.get("id") or "")[:40] or hashlib.sha1(("%s\x1f%s" % (name, line)).encode("utf-8")).hexdigest()[:10]
    return {"id": "%s:%s" % (source, cid), "name": name, "line": line, "desc": str(e.get("desc") or "").strip()[:200],
            "words": [str(w)[:60] for w in words[:20]], "terminal": bool(e.get("terminal", needs_terminal(line))),
            "confirm": bool(e.get("confirm", False)), "source": source, "builtin": ""}


def _read_list(path: Path) -> list:
    try:
        if path.stat().st_size > 512_000:
            return []
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    return data if isinstance(data, list) else []


def user_commands() -> list[dict]:
    """Gespeicherte Befehle aus Seifferts Dateien und Einträge aus befehle.d (Dateien in alphabetischer Reihenfolge)."""
    out: list[dict] = []
    for n, e in enumerate(_read_list(config_dir() / "commands.json")):
        c = _clean(e, "eigen", n)
        if c:
            out.append(c)
    try:
        files = sorted(p for p in dropin_dir().iterdir() if p.suffix == ".json" and p.is_file())[:MAX_DROPIN_FILES]
    except OSError:
        files = []
    for f in files:
        for n, e in enumerate(_read_list(f)):
            c = _clean(e, f.stem[:40], n)
            if c:
                out.append(c)
    seen, uniq = set(), []
    for c in out:
        if c["id"] not in seen:
            seen.add(c["id"])
            uniq.append(c)
    return uniq[:MAX_COMMANDS]


def builtin_commands(clip: bool = True) -> list[dict]:
    out = []

    def add(key: str, name: str, desc: str, words: list[str]) -> None:
        out.append({"id": "intern:" + key, "name": name, "line": "", "desc": desc, "words": words, "terminal": False, "confirm": False,
                    "source": "intern", "builtin": key})
    add("ocr", "Text vom Bildschirm lesen", "Ausschnitt aufziehen, der erkannte Text kommt in die Zwischenablage",
        ["ocr", "texterkennung", "bildschirmtext", "abschreiben", "bild zu text", "screenshot"])
    for s in skins.SKINS:
        add("skin:" + s, "Farbdesign: " + skins.LABELS[s], "Farbdesign der Seiffert-Programme auf %s stellen" % skins.LABELS[s],
            ["farbe", "farben", "design", "theme", "aussehen", s])
    for t in skins.THEMES:
        add("theme:" + t, "Darstellung: " + skins.THEME_LABELS[t], "Helle oder dunkle Darstellung von Seifferts Dateien",
            ["hell", "dunkel", "theme", "modus", "dark", "light", "nachtmodus", "design"])
    if clip:
        add("clipclear", "Zwischenablage-Verlauf leeren", "Vergisst alle gemerkten Texte der Zwischenablage",
            ["zwischenablage", "verlauf", "clipboard", "loeschen", "leeren"])
    return out


def all_commands(clip: bool = True) -> list[dict]:
    return user_commands() + builtin_commands(clip)


def expand(line: str) -> str:
    """{ordner} gibt es im Starter nicht als aktuellen Ordner; es steht dort für den persönlichen Ordner."""
    return line.replace("{ordner}", shlex.quote(os.path.expanduser("~")))


def _env() -> dict:
    env = dict(os.environ)
    for k in ("QT_QPA_PLATFORM", "QTWEBENGINE_CHROMIUM_FLAGS", "SD_DEBUG", "PYTHONINSPECT", "SEIFFERT_STARTER_NOHIDE", "SEIFFERT_STARTER_STYLE"):
        env.pop(k, None)
    return env


def terminal_argv(line: str) -> list[str]:
    """Aufruf, der die Befehlszeile in einem Terminalfenster ausführt und das Fenster danach offen lässt. Leer, wenn kein Terminal da ist."""
    shell = shutil.which("bash") or "/bin/sh"
    script = line + '\nprintf "\\n[Befehl beendet. Enter schließt das Fenster] "; read _'
    own = shutil.which("seiffert-terminal") or os.path.expanduser("~/.local/bin/seiffert-terminal")
    if os.access(own, os.X_OK):
        return [own, "-e", shell, "-c", script]
    for name, flag in (("xterm", "-e"), ("mate-terminal", "-x"), ("gnome-terminal", "--"), ("cosmic-term", "--"), ("konsole", "-e"),
                       ("xfce4-terminal", "-x"), ("alacritty", "-e"), ("kitty", "")):
        exe = shutil.which(name)
        if exe:
            return [exe] + ([flag] if flag else []) + [shell, "-c", script]
    return []


def run_line(line: str, terminal: bool = False, wait: float = 0.35) -> None:
    """Führt eine Befehlszeile aus: im Hintergrund über die Shell (wie der Dialog in Seifferts Dateien) oder in einem Terminalfenster.
    Wirft ValueError mit einer Meldung für den Benutzer, wenn der Start scheitert."""
    line = expand((line or "").strip())
    if not line:
        raise ValueError("Der Befehl ist leer.")
    home = os.path.expanduser("~")
    if terminal:
        argv = terminal_argv(line)
        if not argv:
            raise ValueError("Kein Terminal gefunden (seiffert-terminal fehlt).")
    else:
        argv = [shutil.which("bash") or "/bin/sh", "-c", line]
    try:
        proc = subprocess.Popen(argv, cwd=home, env=_env(), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                start_new_session=True)
    except OSError as e:
        raise ValueError("Der Befehl ließ sich nicht starten: %s" % (e.strerror or e))
    if terminal:
        return
    try:
        code = proc.wait(timeout=wait)                           # nur kurz warten: Tippfehler im Programmnamen sofort melden
    except subprocess.TimeoutExpired:
        return
    if code == 127:
        raise ValueError("Programm nicht gefunden: %s" % (_first_word(line) or line[:40]))
    if code == 126:
        raise ValueError("Das Programm lässt sich nicht ausführen (keine Berechtigung): %s" % (_first_word(line) or line[:40]))


# ---------------------------------------------------------------------------------------------- Farbdesign umstellen
def _send(sock_name: str, payload: str, timeout: float = 0.4) -> bool:
    """Schickt eine Nachricht an ein laufendes Seiffert-Programm (Qt legt dessen Socket im temporären Ordner an)."""
    path = os.path.join(os.environ.get("TMPDIR") or tempfile.gettempdir(), sock_name)
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as c:
            c.settimeout(timeout)
            c.connect(path)
            c.sendall(payload.encode("utf-8"))
            c.shutdown(socket.SHUT_WR)
            try:
                c.recv(16)
            except OSError:
                pass
        return True
    except (OSError, AttributeError):
        return False


def _uid() -> str:
    return str(os.getuid()) if hasattr(os, "getuid") else "user"


CONFIG_MSG = "\x1dconfig"       # Nachricht an Seifferts Dateien: Farbdesign oder Darstellung übernehmen (Rest nach \x1f: JSON)


def set_design(skin: str | None = None, theme: str | None = None, backend=None) -> str:
    """Stellt Farbdesign und/oder Darstellung um. Läuft Seifferts Dateien, übernimmt es die Änderung sofort (und speichert sie selbst,
    damit es sie beim nächsten Speichern nicht überschreibt); sonst wird config.json direkt geändert. Rückgabe: "dateien" oder "datei"."""
    patch = {}
    if skin is not None:
        if skin not in skins.SKINS:
            raise ValueError("Das Farbdesign \"%s\" gibt es nicht. Möglich: %s." % (skin, ", ".join(skins.SKINS)))
        patch["skin"] = skin
    if theme is not None:
        if theme not in skins.THEMES:
            raise ValueError("Die Darstellung \"%s\" gibt es nicht. Möglich: %s." % (theme, ", ".join(skins.THEMES)))
        patch["theme"] = theme
    if not patch:
        raise ValueError("Nichts zu ändern.")
    if _send("%s-%s" % (APP_ID, _uid()), CONFIG_MSG + "\x1f" + json.dumps(patch)):
        via = "dateien"
    else:
        if backend is not None:
            backend.api_set_config(patch)
        else:
            _patch_config_file(patch)
        via = "datei"
    _send("seiffert-oberflaeche-%s" % _uid(), "reload")          # die Oberfläche liest das Farbdesign neu, falls sie läuft
    return via


def _patch_config_file(patch: dict) -> None:
    d = config_dir()
    p = d / "config.json"
    try:
        cur = json.loads(p.read_text(encoding="utf-8"))
        if not isinstance(cur, dict):
            cur = {}
    except OSError:
        cur = {}
    except ValueError:
        raise ValueError("config.json von Seifferts Dateien ist beschädigt und wurde nicht verändert.")
    cur.update(patch)
    d.mkdir(parents=True, exist_ok=True)
    tmp = d / "config.json.tmp"
    tmp.write_text(json.dumps(cur, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, p)


# ---------------------------------------------------------------------------------------------- Verlauf der Zwischenablage
class ClipStore:
    """Merkt sich die zuletzt kopierten Texte, nur im Arbeitsspeicher: nach dem Beenden des Starters ist der Verlauf weg.
    So landen kopierte Kennwörter nie auf der Festplatte."""

    def __init__(self, limit: int = 30, max_chars: int = 200_000) -> None:
        self.limit, self.max_chars = limit, max_chars
        self._items: list[dict] = []
        self._lock = threading.Lock()

    def add(self, text: str) -> bool:
        if not isinstance(text, str) or not text.strip() or len(text) > self.max_chars:
            return False
        key = hashlib.sha1(text.encode("utf-8", "replace")).hexdigest()[:16]
        with self._lock:
            self._items = [i for i in self._items if i["key"] != key]
            self._items.insert(0, {"key": key, "text": text, "at": time.time()})
            del self._items[self.limit:]
        return True

    def items(self) -> list[dict]:
        with self._lock:
            return list(self._items)

    def get(self, key: str) -> str | None:
        with self._lock:
            return next((i["text"] for i in self._items if i["key"] == key), None)

    def clear(self) -> int:
        with self._lock:
            n = len(self._items)
            self._items = []
        return n

    def __len__(self) -> int:
        return len(self._items)


def clip_title(text: str, width: int = 60) -> str:
    """Erste nichtleere Zeile, gekürzt: so heißt ein Eintrag des Verlaufs in der Wolke."""
    line = next((ln.strip() for ln in text.splitlines() if ln.strip()), "")
    line = " ".join(line.split())
    return line if len(line) <= width else line[:width - 1].rstrip() + "…"


def clip_info(text: str, at: float, now: float | None = None) -> str:
    n, lines = len(text), text.count("\n") + 1
    age = max(0, int((now or time.time()) - at))
    when = "gerade eben" if age < 60 else "vor %d Min." % (age // 60) if age < 3600 else "vor %d Std." % (age // 3600)
    return "%d Zeichen%s, %s" % (n, ", %d Zeilen" % lines if lines > 1 else "", when)
