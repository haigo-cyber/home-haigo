"""Zuschnitt in Text (alleinstehendes Fenster, Funktionstests aus Seifferts Zuschnitt 0.6.4), offscreen: python tests/run_zs_tests.py"""
import os
import random
import shutil
import sys
import tempfile

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import pymupdf
from PIL import Image, JpegImagePlugin
from PySide6.QtCore import Qt, QPoint, QPointF
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QDialog, QMessageBox, QFileDialog

from seiffert_text import zs_window as A
from seiffert_text import zs_core as core

tmp = tempfile.mkdtemp(prefix="zuschnitt-test-")
core.CFG_DIR = os.path.join(tmp, "cfg")
core.CFG_FILE = os.path.join(core.CFG_DIR, "settings.json")

qapp = QApplication([])
ok_count = 0
fails = []


def check(name, cond, extra=""):
    global ok_count
    if cond:
        ok_count += 1
    else:
        fails.append(f"{name} {extra}")
        print("FEHLER:", name, extra)


# Dialoge ersetzen
DLG = {"text": "Beispiel", "size": 20.0, "all": False, "bold": False, "bg": False, "color": "#ff0000", "accept": True}


def fake_exec(self):
    if not DLG["accept"]:
        return QDialog.Rejected
    self.edit.setPlainText(DLG["text"])
    self.size.setValue(DLG["size"])
    self.bold.setChecked(DLG["bold"])
    self.bg.setChecked(DLG["bg"])
    self.color = DLG["color"]
    if self.allp is not None:
        self.allp.setChecked(DLG["all"])
    return QDialog.Accepted


A.TextDialog.exec = fake_exec
QMessageBox.information = staticmethod(lambda *a, **k: QMessageBox.Ok)
QMessageBox.warning = staticmethod(lambda *a, **k: QMessageBox.Ok)
QMessageBox.question = staticmethod(lambda *a, **k: QMessageBox.Yes)

# ---------- Testdateien
pdf_path = os.path.join(tmp, "test.pdf")
d = pymupdf.open()
for i in range(3):
    p = d.new_page(width=600, height=800)
    p.draw_rect((200, 300, 300, 400), fill=(1, 0, 0))
    p.insert_text((50, 60), f"Seite {i + 1} Original", fontsize=14)
d.save(pdf_path)
d.close()

jpg_path = os.path.join(tmp, "foto.jpg")
random.seed(1)
im = Image.new("RGB", (3000, 2000), (240, 240, 240))
px = im.load()
for x in range(0, 3000, 7):
    for y in range(0, 2000, 7):
        px[x, y] = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
im.save(jpg_path, "JPEG", quality=90, dpi=(300, 300))

png_path = os.path.join(tmp, "grafik.png")
im2 = Image.new("RGBA", (800, 600), (0, 0, 255, 0))
for x in range(400, 800):
    for y in range(0, 600):
        im2.putpixel((x, y), (0, 200, 0, 255))
im2.save(png_path, dpi=(150, 150))

w = A.ZuschnittWindow(None, core.load_settings(core.CFG_FILE), lambda c: core.save_settings(c, core.CFG_FILE))
w.resize(1000, 800)
w.show()
qapp.processEvents()

# ---------- PDF
w.open_path(pdf_path)
check("pdf geöffnet", w.kind == "pdf" and w.page_count() == 3)
check("pdf Größe", w.page_size() == (600, 800), str(w.page_size()))
w.canvas.crop = A.QRectF(100, 200, 400, 500)
w.apply_crop(False)
check("pdf Zuschnitt Größe", w.page_size() == (400, 500), str(w.page_size()))
check("pdf andere Seiten unverändert", w.pdf[1].rect.width == 600)
w.canvas.crop = A.QRectF(50, 50, 200, 200)   # in neuen Koordinaten
w.apply_crop(False)
pix = w.pdf[0].get_pixmap()
check("pdf zweiter Zuschnitt: Marker an richtiger Stelle",
      pix.pixel(60, 60) == (255, 0, 0) and pix.pixel(140, 140) == (255, 0, 0) and pix.pixel(160, 160) != (255, 0, 0),
      str([pix.pixel(60, 60), pix.pixel(140, 140), pix.pixel(160, 160)]))
w.cmd_undo()
check("undo stellt ersten Zuschnitt her", w.page_size() == (400, 500), str(w.page_size()))
w.cmd_undo()
check("undo stellt Original her", w.page_size() == (600, 800))
check("undo leer", not w.undo or True)

# Alle Seiten
w.canvas.crop = A.QRectF(0, 0, 300, 400)
w.apply_crop(True)
check("alle Seiten zugeschnitten", all(w.pdf[i].rect.width == 300 for i in range(3)))
w.cmd_undo()
check("undo alle Seiten", all(w.pdf[i].rect.width == 600 for i in range(3)))

# Text mit Seitenzahl auf allen Seiten, über Mausklick im Textmodus
w.set_mode("text")
DLG.update(text="- {seite} / {seiten} -", all=True, size=16.0, color="#0000ff")
w.canvas.z = 1.0
w.canvas.relayout()
qapp.processEvents()
QTest.mouseClick(w.canvas, Qt.LeftButton, Qt.NoModifier, QPoint(A.M + 250, A.M + 700))
check("Textrahmen per Klick angelegt", len(w.items.get(0, [])) == 1, str(w.items))
check("auf alle Seiten kopiert", all(len(w.items.get(i, [])) == 1 for i in range(3)))
check("unterschiedliche Objekte", w.items[0][0] is not w.items[1][0])

# Ziehen eines neuen Rahmens, Verschieben, Größe ändern
DLG.update(text="A1", all=False, size=18.0, color="#000000")
QTest.mousePress(w.canvas, Qt.LeftButton, Qt.NoModifier, QPoint(A.M + 50, A.M + 100))
QTest.mouseMove(w.canvas, QPoint(A.M + 200, A.M + 140))
QTest.mouseRelease(w.canvas, Qt.LeftButton, Qt.NoModifier, QPoint(A.M + 200, A.M + 140))
its = w.items[0]
check("Rahmen per Ziehen", len(its) == 2 and abs(its[1].w - 150) < 2 and abs(its[1].h - 40) < 2, str(its[1]))
n_undo = len(w.undo)
QTest.mousePress(w.canvas, Qt.LeftButton, Qt.NoModifier, QPoint(A.M + 100, A.M + 120))
QTest.mouseMove(w.canvas, QPoint(A.M + 130, A.M + 150))
QTest.mouseRelease(w.canvas, Qt.LeftButton, Qt.NoModifier, QPoint(A.M + 130, A.M + 150))
check("Verschieben", abs(its[1].x - 80) < 2 and abs(its[1].y - 130) < 2, f"{its[1].x},{its[1].y}")
check("Verschieben ist rückgängig machbar", len(w.undo) == n_undo + 1)
w.cmd_undo()
check("Undo Verschieben", abs(w.items[0][1].x - 50) < 2)
w.canvas.sel = w.items[0][1]
w.canvas.keyPressEvent(type("E", (), {"key": lambda s: Qt.Key_Delete})())
check("Löschen mit Entf", len(w.items[0]) == 1)

# Abbrechen im Dialog legt nichts an
DLG["accept"] = False
n = len(w.items[0])
QTest.mouseClick(w.canvas, Qt.LeftButton, Qt.NoModifier, QPoint(A.M + 100, A.M + 300))
check("Abbruch legt nichts an", len(w.items[0]) == n)
DLG["accept"] = True

# Speichern überschreibt, .bak, neu laden
orig_size = os.path.getsize(pdf_path)
w.cmd_overwrite()
check(".bak angelegt", os.path.exists(pdf_path + ".bak") and os.path.getsize(pdf_path + ".bak") == orig_size)
check("nach Speichern keine offenen Rahmen", not any(w.items.values()))
doc = pymupdf.open(pdf_path)
for i in range(3):
    t = doc[i].get_text()
    check(f"Seitenzahl Seite {i + 1} im PDF", f"- {i + 1} / 3 -" in t, repr(t))
    hits = doc[i].search_for(f"- {i + 1} / 3 -")
    hits = doc[i].search_for(f"{i + 1} / 3")
    check(f"Seitenzahl Seite {i + 1} an Stelle", hits and 250 < hits[0].x0 < 275 and 695 < hits[0].y0 < 720, str(hits))
check("Originaltext bleibt", "Seite 1 Original" in doc[0].get_text())
doc.close()

# Zuschnitt muss auch in Programmen sichtbar sein, die nur die MediaBox lesen (poppler)
import subprocess
for label, rot in (("normal", 0), ("gedreht", 90)):
    zd = pymupdf.open()
    zp = zd.new_page(width=600, height=800)
    zp.insert_text((50, 60), "Oben", fontsize=14)
    if rot:
        zp.set_rotation(rot)
    zdoc_path = os.path.join(tmp, f"zb-{label}.pdf")
    zd.save(zdoc_path)
    zd.close()
    w.open_path(zdoc_path)
    vw, vh = w.pdf[0].rect.width, w.pdf[0].rect.height
    from PySide6.QtCore import QRectF
    w.canvas.crop = QRectF(vw * 0.1, vh * 0.1, vw * 0.5, vh * 0.4)
    w.apply_crop(False)
    w.cmd_overwrite()
    cd = pymupdf.open(zdoc_path)
    vis = cd[0].rect
    check(f"MediaBox gleich Zuschnitt ({label})", abs(vis.width - vw * 0.5) < 1.5 and abs(vis.height - vh * 0.4) < 1.5, f"{vis}")
    raw = [cd.xref_get_key(cd[0].xref, k)[1] for k in ("MediaBox", "CropBox", "TrimBox", "BleedBox", "ArtBox")]
    check(f"alle Boxen gleich ({label})", len(set(raw)) == 1, str(raw))
    cd.close()
    info = subprocess.run(["pdfinfo", zdoc_path], capture_output=True, text=True).stdout
    sz = [l for l in info.splitlines() if l.startswith("Page size")][0]
    check(f"pdfinfo zeigt Zuschnitt ({label})", ("%d x %d" % (round(vis.width), round(vis.height))) in sz or ("%d x %d" % (round(vis.height), round(vis.width))) in sz, sz)
    # erneut öffnen und ein zweites Mal zuschneiden
    w.open_path(zdoc_path)
    vw2, vh2 = w.pdf[0].rect.width, w.pdf[0].rect.height
    from PySide6.QtCore import QRectF
    w.canvas.crop = QRectF(vw2 * 0.25, vh2 * 0.25, vw2 * 0.5, vh2 * 0.5)
    w.apply_crop(False)
    w.cmd_overwrite()
    cd = pymupdf.open(zdoc_path)
    check(f"zweiter Zuschnitt nach Neuladen ({label})", abs(cd[0].rect.width - vw2 * 0.5) < 1.5 and abs(cd[0].rect.height - vh2 * 0.5) < 1.5, f"{cd[0].rect}")
    cd.close()

# Nur der Ausschnitt wird gespeichert; Strg+S überschreibt nie das Original
from PySide6.QtCore import QRectF
mp = os.path.join(tmp, "mehr.pdf")
md = pymupdf.open()
for i in range(4):
    mpg = md.new_page(width=600, height=800)
    mpg.insert_text((50, 60), f"Blatt {i + 1}", fontsize=14)
md.save(mp)
md.close()
mp_size = os.path.getsize(mp)
w.modified = False
w.open_path(mp)
w.goto(1)
w.canvas.crop = QRectF(0, 0, 300, 200)
w.apply_crop(False)
check("zugeschnittene Seite vermerkt", w.cropped == {1}, str(w.cropped))
w.cmd_save()
new1 = os.path.join(tmp, "mehr-bearbeitet.pdf")
check("Strg+S legt neue Datei an", os.path.exists(new1))
check("Original bleibt unverändert", os.path.getsize(mp) == mp_size and not os.path.exists(mp + ".bak") and pymupdf.open(mp).page_count == 4)
r1 = pymupdf.open(new1)
check("nur der Ausschnitt in der Ausgabe", r1.page_count == 1 and abs(r1[0].rect.width - 300) < 1.5 and abs(r1[0].rect.height - 200) < 1.5 and "Blatt 2" in r1[0].get_text(), f"{r1.page_count} {r1[0].rect}")
r1.close()
check("Sitzung bleibt offen und Pfad bleibt Original", w.path == mp and w.pdf.page_count == 4)
w.cmd_save()
check("zweites Strg+S überschreibt nichts", os.path.exists(os.path.join(tmp, "mehr-bearbeitet-2.pdf")) and pymupdf.open(new1).page_count == 1)
# zweiter Ausschnitt auf einer anderen Seite: beide Seiten in der Ausgabe
w.goto(3)
w.canvas.crop = QRectF(0, 0, 200, 100)
w.apply_crop(False)
w.cmd_save()
r3 = pymupdf.open(os.path.join(tmp, "mehr-bearbeitet-3.pdf"))
check("zwei Ausschnitte: genau zwei Seiten", r3.page_count == 2 and "Blatt 2" in r3[0].get_text() and "Blatt 4" in r3[1].get_text())
r3.close()
w.cmd_undo()
check("Rückgängig nimmt Seite aus der Ausgabe", w.cropped == {1}, str(w.cropped))
# Zuschnitt auf alle Seiten
w.canvas.crop = QRectF(0, 0, 100, 100)
w.apply_crop(True)
w.cmd_save()
r4 = pymupdf.open(os.path.join(tmp, "mehr-bearbeitet-4.pdf"))
check("alle Seiten zugeschnitten: alle in der Ausgabe", r4.page_count == 4)
r4.close()
# nur Text, kein Zuschnitt: alle Seiten
w.modified = False
w.open_path(mp)
DLG.update(text="X", all=False, size=14.0)
w.new_text(A.TextItem(10, 10, 100, 30, "", 14.0))
w.cmd_save()
r5 = pymupdf.open(os.path.join(tmp, "mehr-bearbeitet-5.pdf"))
check("ohne Zuschnitt bleiben alle Seiten", r5.page_count == 4)
r5.close()
# Überschreiben nur nach Rückfrage
asked = []
QMessageBox.question = staticmethod(lambda parent, t, text, *a, **k: (asked.append(text) or QMessageBox.Cancel))
w.goto(2)
w.canvas.crop = QRectF(0, 0, 300, 200)
w.apply_crop(False)
w.cmd_overwrite()
check("Überschreiben fragt nach und kann abgebrochen werden", len(asked) == 1 and "1 von 4" in asked[0] and os.path.getsize(mp) == mp_size)
w.cmd_save_as_target = None
QFileDialog.getSaveFileName = staticmethod(lambda parent, cap, sug, flt: (mp, "PDF (*.pdf)"))
w.cmd_save_as()
check("Speichern unter mit Originalnamen fragt ebenfalls nach", len(asked) == 2 and os.path.getsize(mp) == mp_size)
QMessageBox.question = staticmethod(lambda *a, **k: QMessageBox.Yes)
w.cmd_overwrite()
ro = pymupdf.open(mp)
check("Überschreiben nach Bestätigung: nur der Ausschnitt, .bak vorhanden", ro.page_count == 1 and os.path.exists(mp + ".bak") and pymupdf.open(mp + ".bak").page_count == 4)
ro.close()

# PDF in Einzelseiten teilen
from PySide6.QtWidgets import QFileDialog as _QFD
sp_dir = os.path.join(tmp, "teilen")
os.makedirs(sp_dir)
w.modified = False
w.open_path(mp)  # mp: vierseitig, ggf. überschrieben; neu anlegen
sp_src = os.path.join(tmp, "teil.pdf")
sd = pymupdf.open()
for i in range(12):
    spg = sd.new_page(width=600, height=800)
    spg.insert_text((50, 60), f"Teil{i + 1}", fontsize=14)
sd.save(sp_src)
sd.close()
w.open_path(sp_src)
check("Teilen-Aktion aktiv bei mehrseitiger PDF", w.a_split.isEnabled())
_QFD.getExistingDirectory = staticmethod(lambda *a, **k: sp_dir)
QMessageBox.information = staticmethod(lambda *a, **k: None)
w.goto(2)
w.canvas.crop = QRectF(0, 0, 300, 200)
w.apply_crop(False)
DLG.update(text="Nr. {seite}", all=False, size=14.0)
w.new_text(A.TextItem(10, 10, 100, 30, "", 14.0))
w.cmd_split()
files = sorted(os.listdir(sp_dir))
check("zwölf Dateien, zweistellig nummeriert", files == [f"teil-Seite-{i:02d}.pdf" for i in range(1, 13)], str(files))
ok_pages = all(pymupdf.open(os.path.join(sp_dir, f)).page_count == 1 for f in files)
check("jede Datei hat genau eine Seite", ok_pages)
texts = [pymupdf.open(os.path.join(sp_dir, f))[0].get_text() for f in files]
check("richtiger Inhalt je Datei", all(f"Teil{i + 1}" in texts[i] for i in range(12)))
r3 = pymupdf.open(os.path.join(sp_dir, "teil-Seite-03.pdf"))
check("Zuschnitt der Sitzung übernommen", abs(r3[0].rect.width - 300) < 1.5 and abs(r3[0].rect.height - 200) < 1.5, str(r3[0].rect))
check("Textrahmen nur auf seiner Seite", "Nr. 3" in r3[0].get_text() and "Nr." not in texts[0], texts[0])
check("Original unverändert", pymupdf.open(sp_src).page_count == 12)
w.cmd_split()
files2 = sorted(os.listdir(sp_dir))
check("zweites Teilen überschreibt nichts (-2)", len(files2) == 24 and "teil-2-Seite-01.pdf" in files2, str(len(files2)))
w.open_path(os.path.join(sp_dir, "teil-Seite-01.pdf"))
check("Teilen bei einer Seite gesperrt", not w.a_split.isEnabled())

# PDFs zusammenfügen
mg_dir = os.path.join(tmp, "merge")
os.makedirs(mg_dir)
srcs = []
for name, pages, size in (("a.pdf", 2, (600, 800)), ("b.pdf", 3, (800, 600)), ("c.pdf", 1, (500, 500))):
    md2 = pymupdf.open()
    for i in range(pages):
        pg2 = md2.new_page(width=size[0], height=size[1])
        pg2.insert_text((50, 60), f"{name[0].upper()}{i + 1}", fontsize=20)
    pth = os.path.join(mg_dir, name)
    md2.save(pth)
    md2.close()
    srcs.append(pth)
open(os.path.join(mg_dir, "kaputt.pdf"), "wb").write(b"kein pdf")
QMessageBox.warning = staticmethod(lambda *a, **k: None)
dlgm = A.MergeDialog(w, {"save_dir": mg_dir}, mg_dir)
bad = dlgm.add_paths([srcs[0], srcs[1], srcs[2], os.path.join(mg_dir, "kaputt.pdf")])
check("kaputte Datei wird abgelehnt", len(bad) == 1 and dlgm.list.count() == 3)
check("Seitensumme angezeigt", "6 Seiten" in dlgm.info.text(), dlgm.info.text())
dlgm.list.item(2).setSelected(True)
dlgm.move(-1)
check("Nach oben verschiebt", [os.path.basename(p) for p in dlgm.paths()] == ["a.pdf", "c.pdf", "b.pdf"], str(dlgm.paths()))
dlgm.list.clearSelection()
dlgm.list.item(0).setSelected(True)
dlgm.move(1)
check("Nach unten verschiebt", [os.path.basename(p) for p in dlgm.paths()] == ["c.pdf", "a.pdf", "b.pdf"])
dlgm.name.setText("Alles")
dlgm.run_merge()
mo = os.path.join(mg_dir, "Alles.pdf")
check("Ausgabedatei mit .pdf angelegt", os.path.exists(mo) and dlgm.result_path == mo)
mr = pymupdf.open(mo)
order = [mr[i].get_text().strip() for i in range(mr.page_count)]
check("Seiten in Listenreihenfolge", order == ["C1", "A1", "A2", "B1", "B2", "B3"], str(order))
check("Seitengrößen bleiben", [round(mr[i].rect.width) for i in range(6)] == [500, 600, 600, 800, 800, 800])
mr.close()
check("Quelldateien unverändert", [pymupdf.open(p).page_count for p in srcs] == [2, 3, 1])
dlg2 = A.MergeDialog(w, {"save_dir": mg_dir}, mg_dir)
dlg2.add_paths(srcs[:2])
dlg2.name.setText("a.pdf")
dlg2.run_merge()
check("Name einer Quelldatei wird verweigert", dlg2.result_path is None and pymupdf.open(srcs[0]).page_count == 2)
dlg2.name.setText("Alles.pdf")
QMessageBox.question = staticmethod(lambda *a, **k: QMessageBox.Cancel)
dlg2.run_merge()
check("Vorhandene Datei: Abbruch ändert nichts", dlg2.result_path is None and pymupdf.open(mo).page_count == 6)
dlg3 = A.MergeDialog(w, {"save_dir": mg_dir}, mg_dir)
dlg3.add_paths(srcs[:1])
check("Zusammenfügen erst ab zwei Dateien", not dlg3.ok_btn.isEnabled())
QMessageBox.question = staticmethod(lambda *a, **k: QMessageBox.Yes)

# Weiße Fläche ergänzen und Grafiken einfügen
from PySide6.QtCore import QRectF
from PySide6.QtGui import QImage as _QI, QColor as _QC, QPainter as _QP
from PIL import Image as _PI


def colors_at(pix, pts):
    return [pix.pixel(int(x), int(y)) for x, y in pts]


def find_color(pix, col, step=1):
    xs, ys = [], []
    for y in range(0, pix.height, step):
        for x in range(0, pix.width, step):
            if pix.pixel(x, y) == col:
                xs.append(x)
                ys.append(y)
    return (min(xs), min(ys), max(xs), max(ys)) if xs else None


# Testgrafik 200x100: rot oben links (40x30), blau unten rechts (40x30), sonst grau
g_path = os.path.join(tmp, "testgrafik.png")
gim = _PI.new("RGB", (200, 100), (200, 200, 200))
for gx in range(40):
    for gy in range(30):
        gim.putpixel((gx, gy), (255, 0, 0))
        gim.putpixel((199 - gx, 99 - gy), (0, 0, 255))
gim.save(g_path)

for rot in (0, 90, 180, 270):
    for crop in (False, True):
        ep = os.path.join(tmp, f"ext-{rot}-{int(crop)}.pdf")
        ed = pymupdf.open()
        epg = ed.new_page(width=600, height=800)
        epg.draw_rect(pymupdf.Rect(540, 760, 600, 800), color=None, fill=(0, 1, 1))
        epg.draw_rect(pymupdf.Rect(0, 300, 600, 320), color=None, fill=(0, 0.6, 0))
        if crop:
            epg.set_cropbox(pymupdf.Rect(70, 130, 470, 730))
        if rot:
            epg.set_rotation(rot)
        ed.save(ep)
        ed.close()
        w.modified = False
        w.open_path(ep)
        W0, H0 = w.page_size()
        before = w.pdf[0].get_pixmap(alpha=False)
        w.extend(30, 50, 70, 20)
        W1, H1 = w.page_size()
        check(f"Ergänzen: neue Größe (Drehung {rot}, Zuschnitt {crop})", abs(W1 - (W0 + 100)) < 1 and abs(H1 - (H0 + 70)) < 1, f"{W1}x{H1}")
        w.canvas.sel = None
        it = w.add_graphic(g_path)
        it.x, it.y, it.w, it.h = 40.0, 60.0, 100.0, 50.0
        outp = os.path.join(tmp, f"ext-out-{rot}-{int(crop)}.pdf")
        w.write_to(outp, reload=False)
        od = pymupdf.open(outp)
        pix = od[0].get_pixmap(alpha=False)
        inside_ok = True
        for (x, y) in ((5, 5), (W0 / 2, H0 / 2), (W0 - 6, H0 - 6), (W0 / 3, H0 / 5)):
            a, bpx = before.pixel(int(x), int(y)), pix.pixel(int(x + 30), int(y + 50))
            # Pixel unter der Grafik auslassen
            if 40 <= x + 30 <= 140 and 60 <= y + 50 <= 110:
                continue
            if a != bpx:
                inside_ok = False
        white_ok = all(pix.pixel(x, y) == (255, 255, 255) for x, y in ((3, 3), (int(W1) - 4, 3), (3, int(H1) - 4), (int(W1) - 4, int(H1) - 4)))
        red = find_color(pix, (255, 0, 0))
        blue = find_color(pix, (0, 0, 255))
        pos_ok = red is not None and abs(red[0] - 40) <= 1 and abs(red[1] - 60) <= 1 and abs(red[2] - (40 + 20 - 1)) <= 2 and abs(red[3] - (60 + 15 - 1)) <= 2
        bl_ok = blue is not None and abs(blue[2] - 139) <= 1 and abs(blue[3] - 109) <= 1
        check(f"Ergänzen: Inhalt verschoben, Rand weiß (Drehung {rot}, Zuschnitt {crop})", inside_ok and white_ok)
        check(f"Grafik an richtiger Stelle (Drehung {rot}, Zuschnitt {crop})", pos_ok and bl_ok, f"rot {red} blau {blue}")
        od.close()
        w.cmd_undo()
        w.cmd_undo()
        W2, H2 = w.page_size()
        check(f"Rückgängig stellt Größe wieder her ({rot}, {crop})", abs(W2 - W0) < 1 and abs(H2 - H0) < 1)

# Grafik: Seitenverhältnis bleibt beim Skalieren, Löschen, Kopieren
w.modified = False
w.open_path(mp)
w.goto(0)
it = w.add_graphic(g_path)
ow, oh = it.w, it.h
check("Grafik beim Einfügen mit Seitenverhältnis", abs(it.w / it.h - 2.0) < 1e-6)
w.canvas.mode = "text"
w.canvas.sel = it
z = w.canvas.z
start = w.canvas.to_view(QRectF(it.x, it.y, it.w, it.h)).bottomRight() - QPointF(3, 3)
QTest.mousePress(w.canvas, Qt.LeftButton, Qt.NoModifier, start.toPoint())
QTest.mouseMove(w.canvas, (start + QPointF(60, 5)).toPoint())
QTest.mouseRelease(w.canvas, Qt.LeftButton, Qt.NoModifier, (start + QPointF(60, 5)).toPoint())
check("Skalieren behält Seitenverhältnis", it.w > ow and abs(it.w / it.h - 2.0) < 1e-6, f"{it.w}x{it.h}")
w.copy_item_to_all(it)
check("Grafik auf alle Seiten kopiert", all(any(i.is_image for i in w.items.get(p, [])) for p in range(w.page_count())))
w.delete_item(it)
check("Grafik löschen", not any(i.is_image for i in w.items.get(0, [])))

# PDF-Ausschnitt einfügen (Vektor) in PDF
cs = os.path.join(tmp, "quelle.pdf")
cd0 = pymupdf.open()
cp0 = cd0.new_page(width=600, height=800)
cp0.insert_text((100, 200), "Aufgabe 7 Rechne", fontsize=20)
cp0.insert_text((100, 600), "Nicht dabei", fontsize=20)
cp0.draw_rect(pymupdf.Rect(100, 220, 160, 260), color=None, fill=(1, 0, 0))
cd0.new_page(width=300, height=300).insert_text((20, 40), "Seite zwei", fontsize=14)
cd0.save(cs)
cd0.close()
w.modified = False
w.open_path(mp)
w.goto(1)
it = w.add_graphic(cs, 0, (80, 170, 400, 280))
check("PDF-Ausschnitt als Vektor", it.src == "pdf" and abs(it.aspect - 320 / 110) < 1e-6)
check("Ausschnitt in natürlicher Größe (höchstens 90 Prozent der Seite)", abs(it.w - min(320, w.page_size()[0] * 0.9)) < 1e-6, str(it.w))
w.cmd_save()
cres = pymupdf.open(os.path.join(tmp, "mehr-bearbeitet-6.pdf") if os.path.exists(os.path.join(tmp, "mehr-bearbeitet-6.pdf")) else sorted([os.path.join(tmp, f) for f in os.listdir(tmp) if f.startswith("mehr-bearbeitet")])[-1])
txts = [cres[i].get_text() for i in range(cres.page_count)]
check("Vektor-Ausschnitt enthält den Text, aber nicht den Rest", any("Aufgabe 7" in t for t in txts) and not any("Nicht dabei" in t for t in txts), str(txts))
cres.close()

# gedrehte Quellseite wird als Bild übernommen
cr = os.path.join(tmp, "quelle-rot.pdf")
crd = pymupdf.open()
crp = crd.new_page(width=600, height=800)
crp.draw_rect(pymupdf.Rect(0, 0, 60, 40), color=None, fill=(1, 0, 0))
crp.set_rotation(90)
crd.save(cr)
crd.close()
it = w.add_graphic(cr, 0, None)
check("gedrehte Quelle als Bild", it.src == "img" and abs(it.aspect - 800 / 600) < 1e-3)

# Grafik und PDF-Ausschnitt in PNG und JPG
for ext in (".png", ".jpg"):
    ip = os.path.join(tmp, "ziel" + ext)
    im0 = _PI.new("RGB", (800, 600), (255, 255, 255))
    im0.save(ip, quality=100) if ext == ".jpg" else im0.save(ip)
    w.modified = False
    w.open_path(ip)
    w.extend(20, 30, 40, 50)
    check(f"Bild ergänzt {ext}", (w.img.width(), w.img.height()) == (860, 680))
    it = w.add_graphic(g_path)
    it.x, it.y, it.w, it.h = 100.0, 100.0, 200.0, 100.0
    outi = os.path.join(tmp, "ziel-out" + ext)
    w.write_to(outi, reload=False)
    ri = _PI.open(outi).convert("RGB")
    check(f"Bild: Rand weiß {ext}", ri.getpixel((5, 5)) == (255, 255, 255) and ri.getpixel((855, 675)) == (255, 255, 255))
    pr = ri.getpixel((101, 101))
    pb = ri.getpixel((298, 198))
    near = lambda a, b: all(abs(x - y) < 40 for x, y in zip(a, b))  # noqa: E731
    check(f"Bild: Grafik an der Stelle {ext}", near(pr, (255, 0, 0)) and near(pb, (0, 0, 255)), f"{pr} {pb}")
    it2 = w.add_graphic(cs, 0, (80, 170, 400, 280))
    it2.x, it2.y = 300.0, 300.0
    w.write_to(outi, reload=False)
    ri = _PI.open(outi).convert("RGB")
    check(f"Bild: PDF-Ausschnitt gerendert {ext}", ri.getpixel((int(300 + 20 + 1), int(300 + 50 + 1))) != (255, 255, 255) or any(ri.getpixel((x, y)) != (255, 255, 255) for x in range(300, 620, 6) for y in range(300, 410, 6)))

# PNG mit Transparenz: Rand weiß, Inhalt bleibt durchsichtig
tp = os.path.join(tmp, "transp.png")
tim = _PI.new("RGBA", (100, 100), (0, 0, 0, 0))
tim.save(tp)
w.modified = False
w.open_path(tp)
w.extend(10, 10, 10, 10)
tout = os.path.join(tmp, "transp-out.png")
w.write_to(tout, reload=False)
tr = _PI.open(tout).convert("RGBA")
check("PNG mit Transparenz: Rand weiß und deckend, Mitte durchsichtig", tr.getpixel((2, 2)) == (255, 255, 255, 255) and tr.getpixel((60, 60))[3] == 0, f"{tr.getpixel((2, 2))} {tr.getpixel((60, 60))}")

# Ergänzen mit Ausgabe nur zugeschnittener Seiten: ergänzte Seite kommt hinein, wenn schon Zuschnitte da sind
mp4 = os.path.join(tmp, "vier.pdf")
d4 = pymupdf.open()
for _i in range(4):
    d4.new_page(width=600, height=800)
d4.save(mp4)
d4.close()
w.modified = False
w.open_path(mp4)
w.canvas.crop = QRectF(0, 0, 300, 200)
w.apply_crop(False)
w.goto(1)
w.extend(10, 10, 10, 10)
check("Ergänzte Seite wird Teil der Ausgabe, wenn schon zugeschnitten wurde", w.cropped == {0, 1}, str(w.cropped))
w.cmd_undo()
w.cmd_undo()

# Zuschnitt über den Seitenrand hinaus ergänzt weiße Fläche
for rot in (0, 90):
    op = os.path.join(tmp, f"over-{rot}.pdf")
    od_ = pymupdf.open()
    opg = od_.new_page(width=600, height=800)
    opg.draw_rect(pymupdf.Rect(0, 0, 600, 800), color=None, fill=(0, 0.6, 0))
    if rot:
        opg.set_rotation(rot)
    od_.save(op)
    od_.close()
    w.modified = False
    w.open_path(op)
    W0, H0 = w.page_size()
    w.canvas.crop = QRectF(-40, -30, W0 + 40 + 60, H0 + 30 + 20)
    w.apply_crop(False)
    W1, H1 = w.page_size()
    check(f"Zuschnitt über den Rand: Größe (Drehung {rot})", abs(W1 - (W0 + 100)) < 1 and abs(H1 - (H0 + 50)) < 1, f"{W1}x{H1}")
    oo = os.path.join(tmp, f"over-out-{rot}.pdf")
    w.write_to(oo, reload=False)
    od_ = pymupdf.open(oo)
    pxo = od_[0].get_pixmap(alpha=False)
    od_.close()
    check(f"Zuschnitt über den Rand: Rand weiß, Inhalt grün (Drehung {rot})",
          pxo.pixel(2, 2) == (255, 255, 255) and pxo.pixel(int(W1) - 3, int(H1) - 3) == (255, 255, 255) and pxo.pixel(60, 40)[1] > 100 and pxo.pixel(60, 40)[0] < 60)
    w.cmd_undo()
    check(f"Zuschnitt über den Rand: ein Rückgängig genügt (Drehung {rot})", abs(w.page_size()[0] - W0) < 1)
imo = os.path.join(tmp, "over.png")
_PI.new("RGB", (200, 100), (0, 150, 0)).save(imo)
w.modified = False
w.open_path(imo)
w.canvas.crop = QRectF(-10, -20, 230, 140)
w.apply_crop(False)
check("Bild: Zuschnitt über den Rand ergänzt", (w.img.width(), w.img.height()) == (230, 140), f"{w.img.width()}x{w.img.height()}")
check("Bild: Rand weiß, Inhalt grün", _QC(w.img.pixel(2, 2)).name() == "#ffffff" and _QC(w.img.pixel(50, 50)).name() == "#009600")

# Rahmen lässt sich über den Seitenrand hinaus verschieben (Original liegt dann frei im größeren Rahmen)
w.modified = False
w.open_path(os.path.join(tmp, "over-0.pdf"))
w.canvas.z = 1.0
w.canvas.relayout()
w.canvas.mode = "crop"
w.canvas.crop = QRectF(50, 50, 300, 300)
cx, cy = A.M + 200, A.M + 200
QTest.mousePress(w.canvas, Qt.LeftButton, Qt.NoModifier, QPoint(cx, cy))
QTest.mouseMove(w.canvas, QPoint(cx - 120, cy - 100))
QTest.mouseRelease(w.canvas, Qt.LeftButton, Qt.NoModifier, QPoint(cx - 120, cy - 100))
cr_ = w.canvas.crop
check("Rahmen über den Rand verschiebbar", cr_.left() < -50 and cr_.top() < -40, str(cr_))
w.apply_crop(False)
check("verschobener Rahmen ergänzt weiße Fläche", abs(w.page_size()[0] - 300) < 1.5 and abs(w.page_size()[1] - 300) < 1.5, str(w.page_size()))
w.cmd_undo()

# Zuschnitt + Text + Speichern auf gedrehter Seite
rot_path = os.path.join(tmp, "rot.pdf")
dd = pymupdf.open()
q = dd.new_page(width=600, height=800)
q.set_rotation(90)
dd.save(rot_path)
dd.close()
w.modified = False
w.open_path(rot_path)
check("gedrehte Seite Größe", w.page_size() == (800, 600), str(w.page_size()))
DLG.update(text="Gedreht äöü €", all=False, size=20.0)
w.new_text(A.TextItem(100, 50, 300, 40, "", 20.0))
w.cmd_save_as_target = None
out_rot = os.path.join(tmp, "rot-out.pdf")
w.write_to(out_rot, reload=True)
doc = pymupdf.open(out_rot)
pm = doc[0].get_pixmap()
dark = [(x, y) for x in range(pm.width) for y in range(pm.height) if sum(pm.pixel(x, y)) < 300]
bx0, by0 = min(x for x, y in dark), min(y for x, y in dark)
bx1 = max(x for x, y in dark)
check("gedrehte Seite: Text liegt waagerecht an Stelle", dark and abs(bx0 - 100) < 4 and 50 <= by0 < 75 and bx1 - bx0 > 80, f"{bx0},{by0},{bx1}")
check("Euro und Umlaute im PDF", "€" in doc[0].get_text() and "äöü" in doc[0].get_text(), repr(doc[0].get_text()))
doc.close()

# ---------- JPEG
w.modified = False
w.open_path(jpg_path)
check("jpg geöffnet", w.kind == "img" and (w.img.width(), w.img.height()) == (3000, 2000))
w.canvas.crop = A.QRectF(500, 400, 1200, 900)
w.apply_crop(False)
check("jpg Zuschnitt Größe", (w.img.width(), w.img.height()) == (1200, 900), str((w.img.width(), w.img.height())))
w.set_mode("text")
DLG.update(text="Aufgabe 3", size=80.0, bg=True, color="#ff0000", all=False)
w.new_text(A.TextItem(100, 100, 600, 120, "", 80.0))
out_jpg = os.path.join(tmp, "foto-out.jpg")
w.write_to(out_jpg, reload=True)
with Image.open(out_jpg) as r:
    check("jpg Pixelgröße exakt", r.size == (1200, 900), str(r.size))
    check("jpg dpi erhalten", r.info.get("dpi") and round(r.info["dpi"][0]) == 300, str(r.info.get("dpi")))
    check("jpg keine Farbunterabtastung", JpegImagePlugin.get_sampling(r) == 0, str(JpegImagePlugin.get_sampling(r)))
    q = r.quantization[0][0]
    check("jpg Qualität 100 (Quantisierung 1)", q <= 2, str(q))
    rgb = r.convert("RGB")
    reds = sum(1 for x in range(100, 700) for y in range(100, 220) if rgb.getpixel((x, y))[0] > 200 and rgb.getpixel((x, y))[1] < 80)
    whites = sum(1 for x in range(100, 700, 5) for y in range(100, 220, 5) if min(rgb.getpixel((x, y))) > 245)
    check("jpg Text sichtbar", reds > 500, str(reds))
    check("jpg weißer Hintergrund", whites > 100, str(whites))
    # Inhalt außerhalb des Textes unverändert gegenüber Original-Ausschnitt
    with Image.open(jpg_path) as o:
        crop = o.crop((500, 400, 1700, 1300)).convert("RGB")
        diff = sum(abs(a - b) for x in range(800, 1100, 3) for y in range(500, 800, 3)
                   for a, b in zip(rgb.getpixel((x, y)), crop.getpixel((x, y)))) / (100 * 100 * 3)
        check("jpg Ausschnitt entspricht Original (mittlere Abweichung klein)", diff < 6, f"{diff:.2f}")
check("nach Speichern unter neuem Namen: neuer Pfad", w.path == out_jpg)

# Voreingestellter Ordner für Speichern unter
sd = os.path.join(tmp, "ziel")
os.makedirs(sd)
w.cfg["save_dir"] = sd
seen = {}
QFileDialog.getSaveFileName = staticmethod(lambda parent, cap, sug, flt: (seen.update(sug=sug) or (os.path.join(sd, "neu.png"), "PNG (*.png)")))
w.cmd_save_as()
check("Standardordner im Dialog", os.path.dirname(seen["sug"]) == sd, seen["sug"])
check("Speichern unter schreibt in Standardordner", os.path.exists(os.path.join(sd, "neu.png")))
with Image.open(os.path.join(sd, "neu.png")) as r:
    check("PNG aus JPEG voller Größe", r.size == (1200, 900), str(r.size))

# ---------- PNG mit Transparenz
w.modified = False
w.open_path(png_path)
w.canvas.crop = A.QRectF(300, 100, 400, 300)
w.apply_crop(False)
DLG.update(text="Nr. 1", size=40.0, bg=False, color="#000000")
w.new_text(A.TextItem(20, 20, 200, 60, "", 40.0))
w.cmd_overwrite()
with Image.open(png_path) as r:
    check("png Größe", r.size == (400, 300), str(r.size))
    check("png Alpha erhalten", r.mode == "RGBA" and r.getpixel((10, 250))[3] == 0 and r.getpixel((390, 250))[3] == 255,
          f"{r.mode} {r.getpixel((10, 250))} {r.getpixel((390, 250))}")
    check("png dpi erhalten", r.info.get("dpi") and round(r.info["dpi"][0]) == 150, str(r.info.get("dpi")))
    dark = sum(1 for x in range(20, 220) for y in range(20, 80) if r.getpixel((x, y))[0] < 60 and r.getpixel((x, y))[3] > 200)
    check("png Text sichtbar", dark > 100, str(dark))
check("png .bak", os.path.exists(png_path + ".bak"))

# ---------- Zuschneiden per Maus im Zuschneiden-Modus
w.modified = False
w.open_path(jpg_path)
w.set_mode("crop")
w.canvas.z = 0.2
w.canvas.relayout()
qapp.processEvents()
QTest.mousePress(w.canvas, Qt.LeftButton, Qt.NoModifier, QPoint(A.M + 100, A.M + 100))
QTest.mouseMove(w.canvas, QPoint(A.M + 300, A.M + 250))
QTest.mouseRelease(w.canvas, Qt.LeftButton, Qt.NoModifier, QPoint(A.M + 300, A.M + 250))
c = w.canvas.crop
check("Zuschnitt per Maus", c is not None and abs(c.x() - 500) < 6 and abs(c.width() - 1000) < 6 and abs(c.height() - 750) < 6, str(c))
# Griff ziehen (rechte untere Ecke)
QTest.mousePress(w.canvas, Qt.LeftButton, Qt.NoModifier, QPoint(A.M + 300, A.M + 250))
QTest.mouseMove(w.canvas, QPoint(A.M + 400, A.M + 300))
QTest.mouseRelease(w.canvas, Qt.LeftButton, Qt.NoModifier, QPoint(A.M + 400, A.M + 300))
c = w.canvas.crop
check("Griff ziehen", abs(c.width() - 1500) < 6 and abs(c.height() - 1000) < 6, str(c))
w.canvas.keyPressEvent(type("E", (), {"key": lambda s: Qt.Key_Return})())
check("Eingabetaste wendet Zuschnitt an", abs(w.img.width() - 1500) <= 6 and w.canvas.crop is None, str(w.img.width()))
# Außerhalb der Seite ziehen wird begrenzt
w.canvas.z = 0.2
w.canvas.relayout()
QTest.mousePress(w.canvas, Qt.LeftButton, Qt.NoModifier, QPoint(A.M + 10, A.M + 10))
QTest.mouseMove(w.canvas, QPoint(A.M + 5000, A.M + 5000))
QTest.mouseRelease(w.canvas, Qt.LeftButton, Qt.NoModifier, QPoint(A.M + 5000, A.M + 5000))
W, H = w.page_size()
check("Aufziehen endet am Randstreifen um die Seite", w.canvas.crop.right() <= W + (A.M - 2) / w.canvas.z + 0.01 and w.canvas.crop.bottom() <= H + (A.M - 2) / w.canvas.z + 0.01, str(w.canvas.crop))

# Einstellungen werden geschrieben
w.cfg["save_dir"] = sd
core.save_settings(w.cfg, core.CFG_FILE)
check("Einstellungen gespeichert", core.load_settings(core.CFG_FILE)["save_dir"] == sd)

# Rendern bei hohem Zoom und Neuzeichnen ohne Fehler
w.canvas.z = 0.5
w.canvas.relayout()
img = w.canvas.grab()
check("Neuzeichnen", not img.isNull())

w.modified = False
w.close()
shutil.rmtree(tmp, ignore_errors=True)
print(f"{ok_count} Prüfungen bestanden, {len(fails)} Fehler")
sys.exit(1 if fails else 0)
