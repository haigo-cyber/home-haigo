#!/bin/sh
# Installiert Seifferts Update (Befehl seiffert-update) für den aktuellen Benutzer, ohne sudo.
# Entfernen:  ./install.sh --remove
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
APP="${XDG_DATA_HOME:-$HOME/.local/share}/seiffert-update"
BIN="$HOME/.local/bin"
ARCH="${SEIFFERT_ARCHIVE:-$HOME/Seiffert-Archive}"
if [ "$1" = "--remove" ]; then
  rm -f "$APP/seiffert_update.py" "$BIN/seiffert-update"
  echo "Entfernt. Der Stand (stand.json) und der Sammelordner $ARCH bleiben erhalten."
  exit 0
fi
mkdir -p "$APP" "$BIN" "$ARCH"
cp "$HERE/seiffert_update.py" "$APP/"
cat > "$BIN/seiffert-update" <<LAUNCH
#!/bin/sh
exec python3 "$APP/seiffert_update.py" "\$@"
LAUNCH
chmod +x "$BIN/seiffert-update"
echo "Fertig. Sammelordner: $ARCH"
echo "Lege dort die aktuellen Archive (.tar.gz) ab und rufe  seiffert-update  auf (Hilfe: seiffert-update --hilfe)."
case ":$PATH:" in *":$BIN:"*) ;; *) echo "Hinweis: $BIN steht nicht in PATH. Aufruf dann mit $BIN/seiffert-update." ;; esac
