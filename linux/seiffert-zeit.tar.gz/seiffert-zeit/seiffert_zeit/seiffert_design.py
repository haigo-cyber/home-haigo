"""Gemeinsame Designschicht der Seiffert-Programme mit Qt-Oberfläche (PySide6).

Quelle der Farben ist skins.py (dieselbe Datei wie in Seifferts Dateien); gewählt wird in ~/.config/seiffert-dateien/config.json
(Schlüssel skin und theme). Ein Programm bindet das so ein, gleich nach dem Anlegen der QApplication:

    import seiffert_design
    seiffert_design.install(app)

Danach folgt das Programm Farbdesign und Darstellung, auch während es läuft (die Datei wird beobachtet)."""
from __future__ import annotations

import os

try:
    from . import skins
except ImportError:                      # als lose Datei neben skins.py
    import skins                         # type: ignore

from PySide6.QtCore import QFileSystemWatcher, QObject, Qt, QTimer
from PySide6.QtGui import QColor, QPalette
from PySide6.QtWidgets import QApplication

VERSION = "1.0"
_state: dict = {}


def is_dark(theme: str, app: QApplication | None = None) -> bool:
    if theme == "dark":
        return True
    if theme == "light":
        return False
    app = app or QApplication.instance()
    try:                                  # Qt 6.5 und neuer fragt den Desktop selbst
        cs = app.styleHints().colorScheme()
        if cs == Qt.ColorScheme.Dark:
            return True
        if cs == Qt.ColorScheme.Light:
            return False
    except AttributeError:
        pass
    return bool(skins.system_dark())


def current(app: QApplication | None = None) -> dict:
    skin, theme = skins.read_choice()
    dark = is_dark(theme, app)
    return {"skin": skin, "theme": theme, "dark": dark, "colors": skins.palette(skin, dark)}


def make_palette(c: dict) -> QPalette:
    p = QPalette()
    g = QColor
    p.setColor(QPalette.ColorRole.Window, g(c["bg"]))
    p.setColor(QPalette.ColorRole.WindowText, g(c["ink"]))
    p.setColor(QPalette.ColorRole.Base, g(c["panel"]))
    p.setColor(QPalette.ColorRole.AlternateBase, g(c["bg"]))
    p.setColor(QPalette.ColorRole.Text, g(c["ink"]))
    p.setColor(QPalette.ColorRole.PlaceholderText, g(c["muted"]))
    p.setColor(QPalette.ColorRole.Button, g(c["panel"]))
    p.setColor(QPalette.ColorRole.ButtonText, g(c["ink"]))
    p.setColor(QPalette.ColorRole.ToolTipBase, g(c["panel"]))
    p.setColor(QPalette.ColorRole.ToolTipText, g(c["ink"]))
    p.setColor(QPalette.ColorRole.Highlight, g(c["accent"]))
    p.setColor(QPalette.ColorRole.HighlightedText, g(c["accent_ink"]))
    p.setColor(QPalette.ColorRole.Link, g(c["accent"]))
    p.setColor(QPalette.ColorRole.BrightText, g(c["danger"]))
    p.setColor(QPalette.ColorRole.Light, g(c["panel"]))
    p.setColor(QPalette.ColorRole.Midlight, g(c["line2"]))
    p.setColor(QPalette.ColorRole.Mid, g(c["line"]))
    p.setColor(QPalette.ColorRole.Dark, g(c["ctl"]))
    p.setColor(QPalette.ColorRole.Shadow, g("#000000"))
    for role in (QPalette.ColorRole.WindowText, QPalette.ColorRole.Text, QPalette.ColorRole.ButtonText):
        p.setColor(QPalette.ColorGroup.Disabled, role, g(c["muted"]))
    return p


def stylesheet(c: dict) -> str:
    """Zurückhaltend: Fusion samt Palette bildet die Flächen, hier kommen nur Rundung, Fokus und Rollbalken dazu."""
    return """
QToolTip { background: %(panel)s; color: %(ink)s; border: 1px solid %(line)s; padding: 3px 6px; }
QPushButton, QToolButton { border: 1px solid %(line)s; border-radius: 6px; padding: 4px 12px; background: %(panel)s; }
QToolButton { padding: 3px 7px; }
QPushButton:hover, QToolButton:hover { border-color: %(accent)s; background: %(accent_soft)s; }
QPushButton:pressed, QToolButton:pressed { background: %(accent_soft)s; }
QPushButton:default { border-color: %(accent)s; }
QPushButton:disabled, QToolButton:disabled { color: %(muted)s; border-color: %(line2)s; }
QPushButton:focus, QToolButton:focus { border: 1px solid %(focus)s; }
QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox { border: 1px solid %(line)s; border-radius: 5px; padding: 3px 6px; background: %(panel)s; }
QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus { border: 1px solid %(accent)s; }
QTabBar::tab { padding: 6px 14px; border: 1px solid transparent; border-top-left-radius: 6px; border-top-right-radius: 6px; }
QTabBar::tab:selected { background: %(panel)s; border-color: %(line)s; border-bottom-color: %(panel)s; }
QTabBar::tab:hover:!selected { background: %(accent_soft)s; }
QMenu { border: 1px solid %(line)s; }
QMenu::item:selected { background: %(accent)s; color: %(accent_ink)s; }
QScrollBar:vertical { width: 12px; background: transparent; margin: 0; }
QScrollBar:horizontal { height: 12px; background: transparent; margin: 0; }
QScrollBar::handle { background: %(ctl)s; border-radius: 5px; min-height: 28px; min-width: 28px; margin: 2px; }
QScrollBar::handle:hover { background: %(accent)s; }
QScrollBar::add-line, QScrollBar::sub-line { width: 0; height: 0; }
QScrollBar::add-page, QScrollBar::sub-page { background: transparent; }
""" % c


def apply(app: QApplication | None = None) -> dict:
    app = app or QApplication.instance()
    cur = current(app)
    if _state.get("sig") == (cur["skin"], cur["dark"]):
        return cur
    _state["sig"] = (cur["skin"], cur["dark"])
    if not _state.get("style"):
        app.setStyle("Fusion")
        _state["style"] = True
    app.setPalette(make_palette(cur["colors"]))
    app.setStyleSheet(stylesheet(cur["colors"]))
    for cb in list(_state.get("callbacks", [])):
        try:
            cb(cur)
        except Exception:
            pass
    return cur


class _Watch(QObject):
    def __init__(self, app):
        super().__init__(app)
        self.app = app
        self.fw = QFileSystemWatcher(self)
        self.timer = QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.setInterval(150)
        self.timer.timeout.connect(self.fire)
        self.fw.fileChanged.connect(self.kick)
        self.fw.directoryChanged.connect(self.kick)
        self.rearm()
        try:
            app.styleHints().colorSchemeChanged.connect(lambda *_: self.kick())
        except AttributeError:
            pass

    def rearm(self):
        d = str(skins.config_dir())
        f = os.path.join(d, "config.json")
        if os.path.isdir(d) and d not in self.fw.directories():
            self.fw.addPath(d)
        if os.path.isfile(f) and f not in self.fw.files():
            self.fw.addPath(f)

    def kick(self, *_):
        self.timer.start()

    def fire(self):
        self.rearm()                     # config.json wird beim Speichern oft ersetzt, dann fällt die Beobachtung weg
        apply(self.app)


def on_change(callback) -> None:
    """callback(cur) wird nach jedem Wechsel des Farbdesigns aufgerufen (cur wie current())."""
    _state.setdefault("callbacks", []).append(callback)


def install(app: QApplication | None = None, watch: bool = True) -> dict:
    app = app or QApplication.instance()
    cur = apply(app)
    if watch and not _state.get("watch"):
        _state["watch"] = _Watch(app)
    return cur


def web_css(cur: dict, mapping: dict[str, str]) -> str:
    """CSS-Variablen für Programme mit Webansicht. cur kommt aus current(); mapping ordnet Variablennamen der Seite den Farben
    des Designs zu, zum Beispiel {"--bg": "bg", "--acc": "accent"}. Ergebnis ist ein :root-Block samt color-scheme."""
    c = cur["colors"]
    return "html:root{" + ";".join("%s:%s" % (k, c[v]) for k, v in mapping.items()) + "}" + \
        "html{color-scheme:%s}" % ("dark" if cur["dark"] else "light")
