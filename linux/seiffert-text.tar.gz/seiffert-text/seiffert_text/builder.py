"""Zwischenmodell (IR) -> QTextDocument.

Blöcke:
 {'t':'p','inl':[...],'h':0,'al':None,'quote':False,'code':False,'unnum':False}
 {'t':'list','ord':bool,'items':[[blocks],...]}
 {'t':'table','rows':[[{'blocks':[...],'cs':1,'rs':1,'hd':False}]]}
 {'t':'raw','text':str}
 {'t':'hr'}
Textstücke:
 {'t':'txt','s':str,'b':..,'i':..,'u':..,'st':..,'tt':..,'sup':..,'sub':..,'href':..}
 {'t':'br'} {'t':'raw','s':str} {'t':'img','data':bytes|None,'path':str|None,'w':cm|None,'orig':str|None}
"""
from PySide6.QtCore import QUrl, Qt
from PySide6.QtGui import (QFont, QImage, QTextBlockFormat, QTextCharFormat, QTextCursor,
                           QTextDocument, QTextFormat, QTextImageFormat, QTextLength,
                           QTextListFormat, QTextTableFormat, QColor, QBrush)

from .common import (PROP_SRC, PROP_RAW_BLOCK, PROP_RAW_INLINE, PROP_ORIG_SRC, PROP_UNNUM, LS,
                     HEADING_SIZES)

DPI = 96.0


def base_font():
    f = QFont("serif")
    f.setPointSize(12)
    return f


def mono_font_families():
    return ["monospace", "DejaVu Sans Mono", "Courier New"]


def char_format(b=False, i=False, u=False, st=False, tt=False, sup=False, sub=False, href=None,
                size=None):
    cf = QTextCharFormat()
    if b:
        cf.setFontWeight(QFont.Weight.Bold)
    if i:
        cf.setFontItalic(True)
    if u:
        cf.setFontUnderline(True)
    if st:
        cf.setFontStrikeOut(True)
    if tt:
        cf.setFontFamilies(mono_font_families())
        cf.setFontFixedPitch(True)
    if sup:
        cf.setVerticalAlignment(QTextCharFormat.VerticalAlignment.AlignSuperScript)
    if sub:
        cf.setVerticalAlignment(QTextCharFormat.VerticalAlignment.AlignSubScript)
    if href:
        cf.setAnchor(True)
        cf.setAnchorHref(href)
        cf.setForeground(QBrush(QColor("#1a5fb4")))
        cf.setFontUnderline(True)
    if size:
        cf.setFontPointSize(size)
    return cf


def raw_inline_format():
    cf = QTextCharFormat()
    cf.setFontFamilies(mono_font_families())
    cf.setFontFixedPitch(True)
    cf.setFontPointSize(10.5)
    cf.setBackground(QBrush(QColor(128, 128, 128, 45)))
    cf.setProperty(PROP_RAW_INLINE, True)
    return cf


def raw_block_formats():
    bf = QTextBlockFormat()
    bf.setProperty(PROP_RAW_BLOCK, True)
    bf.setBackground(QBrush(QColor(128, 128, 128, 45)))
    bf.setNonBreakableLines(True)
    bf.setTopMargin(4)
    bf.setBottomMargin(4)
    cf = QTextCharFormat()
    cf.setFontFamilies(mono_font_families())
    cf.setFontFixedPitch(True)
    cf.setFontPointSize(10.5)
    return bf, cf


def code_block_formats():
    bf = QTextBlockFormat()
    bf.setNonBreakableLines(True)
    bf.setProperty(QTextFormat.Property.BlockCodeFence, "`")
    bf.setProperty(QTextFormat.Property.BlockCodeLanguage, "")
    bf.setBackground(QBrush(QColor(128, 128, 128, 30)))
    bf.setTopMargin(0)
    bf.setBottomMargin(0)
    cf = QTextCharFormat()
    cf.setFontFamilies(mono_font_families())
    cf.setFontFixedPitch(True)
    cf.setFontPointSize(10.5)
    return bf, cf


def heading_formats(level):
    bf = QTextBlockFormat()
    bf.setHeadingLevel(level)
    bf.setTopMargin(12)
    bf.setBottomMargin(6)
    cf = QTextCharFormat()
    cf.setFontWeight(QFont.Weight.Bold)
    cf.setFontPointSize(HEADING_SIZES.get(level, 12))
    return bf, cf


def apply_heading(cursor, level):
    """Überschriftenebene 0..6 auf den Absatz des Cursors anwenden (Werkzeugleiste)."""
    block = cursor.block()
    bf = block.blockFormat()
    cur = QTextCursor(block)
    cur.select(QTextCursor.SelectionType.BlockUnderCursor)
    cur = QTextCursor(block)
    cur.movePosition(QTextCursor.MoveOperation.StartOfBlock)
    cur.movePosition(QTextCursor.MoveOperation.EndOfBlock, QTextCursor.MoveMode.KeepAnchor)
    cur.beginEditBlock()
    if level == 0:
        bf.setHeadingLevel(0)
        bf.setTopMargin(0)
        bf.setBottomMargin(0)
        cur.setBlockFormat(bf)
        cf = QTextCharFormat()
        cf.setFontWeight(QFont.Weight.Normal)
        cf.setFontPointSize(12)
        cur.mergeCharFormat(cf)
    else:
        hb, hc = heading_formats(level)
        bf.setHeadingLevel(level)
        bf.setTopMargin(hb.topMargin())
        bf.setBottomMargin(hb.bottomMargin())
        cur.setBlockFormat(bf)
        cur.mergeCharFormat(hc)
    cur.endEditBlock()


class _State:
    def __init__(self, doc):
        self.doc = doc
        self.fresh = True        # aktueller (leerer) Absatz darf wiederverwendet werden
        self.imgn = 0


def _image_from(inl, st):
    img = QImage()
    if inl.get("data"):
        img.loadFromData(inl["data"])
    elif inl.get("path"):
        img.load(inl["path"])
    if img.isNull():
        return None
    st.imgn += 1
    name = "seiffert-img:%d" % st.imgn
    st.doc.addResource(QTextDocument.ResourceType.ImageResource, QUrl(name), img)
    fmt = QTextImageFormat()
    fmt.setName(name)
    w = inl.get("w")
    if w:
        wpx = w / 2.54 * DPI
    else:
        wpx = img.width()
    maxw = 16 / 2.54 * DPI
    if wpx > maxw:
        wpx = maxw
    hpx = wpx * img.height() / max(1, img.width())
    fmt.setWidth(wpx)
    fmt.setHeight(hpx)
    if inl.get("orig"):
        fmt.setProperty(PROP_ORIG_SRC, inl["orig"])
    return fmt


def _insert_inlines(cursor, inls, st, base_cf=None):
    for x in inls:
        t = x["t"]
        if t == "txt":
            cf = char_format(x.get("b"), x.get("i"), x.get("u"), x.get("st"), x.get("tt"),
                             x.get("sup"), x.get("sub"), x.get("href"))
            if base_cf is not None:
                m = QTextCharFormat(base_cf)
                m.merge(cf)
                cf = m
            cursor.insertText(x["s"], cf)
        elif t == "br":
            cursor.insertText(LS, base_cf or QTextCharFormat())
        elif t == "raw":
            cursor.insertText(x["s"].replace("\n", LS), raw_inline_format())
        elif t == "img":
            fmt = _image_from(x, st)
            if fmt is None:
                alt = x.get("orig") or "Bild"
                cursor.insertText("\\includegraphics{%s}" % alt, raw_inline_format())
            else:
                cursor.insertImage(fmt)
    # Zeichenformat für folgenden Text zurücksetzen
    cursor.setCharFormat(QTextCharFormat())


def _mark(bf, b):
    if b.get("src") is not None:
        bf.setProperty(PROP_SRC, int(b["src"]) + 1)


def _new_block(cursor, st, bf, cf):
    if st.fresh:
        cursor.setBlockFormat(bf)
        cursor.setBlockCharFormat(cf)
        cursor.setCharFormat(cf)
        st.fresh = False
    else:
        cursor.insertBlock(bf, cf)


def _insert_blocks(cursor, blocks, st, list_ctx=None):
    for b in blocks:
        t = b["t"]
        if t == "p":
            level = b.get("h", 0)
            if b.get("code"):
                bf, cf = code_block_formats()
                _mark(bf, b)
                text = "".join(x.get("s", "") for x in b["inl"] if x["t"] == "txt")
                for ln in text.split("\n"):
                    _new_block(cursor, st, bf, cf)
                    cursor.insertText(ln, cf)
                continue
            if level:
                bf, cf = heading_formats(level)
                if b.get("unnum"):
                    bf.setProperty(PROP_UNNUM, True)
            else:
                bf, cf = QTextBlockFormat(), QTextCharFormat()
                bf.setTopMargin(0)
                bf.setBottomMargin(8)
            if b.get("quote"):
                bf.setProperty(QTextFormat.Property.BlockQuoteLevel, 1)
                bf.setLeftMargin(32)
                bf.setRightMargin(16)
            al = b.get("al")
            if al:
                bf.setAlignment({"center": Qt.AlignmentFlag.AlignHCenter,
                                 "right": Qt.AlignmentFlag.AlignRight,
                                 "left": Qt.AlignmentFlag.AlignLeft,
                                 "justify": Qt.AlignmentFlag.AlignJustify}[al])
            _mark(bf, b)
            _new_block(cursor, st, bf, cf)
            _insert_inlines(cursor, b["inl"], st, cf if level else None)
        elif t == "raw":
            bf, cf = raw_block_formats()
            _new_block(cursor, st, bf, cf)
            cursor.insertText(b["text"].replace("\n", LS), cf)
        elif t == "hr":
            bf = QTextBlockFormat()
            bf.setProperty(QTextFormat.Property.BlockTrailingHorizontalRulerWidth,
                           QTextLength(QTextLength.Type.PercentageLength, 100))
            _new_block(cursor, st, bf, QTextCharFormat())
        elif t == "list":
            _insert_list(cursor, b, st, 1)
        elif t == "table":
            _insert_table(cursor, b, st)


def _insert_list(cursor, lb, st, indent):
    fmt = QTextListFormat()
    fmt.setStyle(QTextListFormat.Style.ListDecimal if lb.get("ord") else QTextListFormat.Style.ListDisc)
    fmt.setIndent(indent)
    qlist = None
    for item in lb["items"]:
        first = True
        for blk in item:
            if blk["t"] == "list":
                _insert_list(cursor, blk, st, indent + 1)
            elif blk["t"] == "p" and first and not blk.get("h"):
                bf = QTextBlockFormat()
                bf.setTopMargin(0)
                bf.setBottomMargin(2)
                _mark(bf, blk)
                _new_block(cursor, st, bf, QTextCharFormat())
                if qlist is None:
                    qlist = cursor.createList(fmt)
                else:
                    qlist.add(cursor.block())
                _insert_inlines(cursor, blk["inl"], st)
                first = False
            else:
                if first:
                    # Eintrag beginnt mit etwas anderem als Text: leeren Listenpunkt anlegen
                    bf = QTextBlockFormat()
                    _new_block(cursor, st, bf, QTextCharFormat())
                    if qlist is None:
                        qlist = cursor.createList(fmt)
                    else:
                        qlist.add(cursor.block())
                    first = False
                _insert_blocks(cursor, [blk], st)
    return qlist


def _flatten_cell(blocks):
    """Verschachtelte Tabellen werden in Zellen zu Text abgeflacht."""
    out = []
    for b in blocks:
        if b["t"] == "table":
            for row in b["rows"]:
                inl = []
                for c in row:
                    for cb in _flatten_cell(c["blocks"]):
                        if cb["t"] == "p":
                            inl += cb["inl"] + [{"t": "txt", "s": "  "}]
                out.append({"t": "p", "inl": inl})
        else:
            out.append(b)
    return out


def _insert_table(cursor, tb, st):
    rows = tb["rows"]
    if not rows:
        return
    # Raster belegen
    occ = {}
    placed = []
    ncols = 0
    for r, row in enumerate(rows):
        c = 0
        for cell in row:
            while occ.get((r, c)):
                c += 1
            cs = max(1, cell.get("cs", 1))
            rs = max(1, cell.get("rs", 1))
            for rr in range(r, r + rs):
                for cc in range(c, c + cs):
                    occ[(rr, cc)] = True
            placed.append((r, c, cs, rs, cell))
            c += cs
            ncols = max(ncols, c)
    nrows = len(rows)
    nrows = max(nrows, max(r + rs for r, c, cs, rs, cell in placed))
    tf = QTextTableFormat()
    tf.setBorder(1)
    tf.setBorderStyle(QTextTableFormat.BorderStyle.BorderStyle_Solid)
    tf.setCellPadding(4)
    tf.setCellSpacing(0)
    tf.setWidth(QTextLength(QTextLength.Type.PercentageLength, 100))
    if any(cell.get("hd") for r, c, cs, rs, cell in placed if r == 0):
        tf.setHeaderRowCount(1)
    if not st.fresh:
        cursor.insertBlock(QTextBlockFormat(), QTextCharFormat())
    st.fresh = False
    table = cursor.insertTable(nrows, ncols, tf)
    merges = []
    for r, c, cs, rs, cell in placed:
        cc = table.cellAt(r, c).firstCursorPosition()
        cst = _State(st.doc)
        cst.fresh = True
        cst.imgn = st.imgn
        blocks = _flatten_cell(cell["blocks"]) or [{"t": "p", "inl": []}]
        if cell.get("hd"):
            for b in blocks:
                if b["t"] == "p":
                    for x in b["inl"]:
                        if x["t"] == "txt":
                            x["b"] = True
        _insert_blocks(cc, blocks, cst)
        st.imgn = cst.imgn
        # Zelle ohne Absatzabstand
        if cs > 1 or rs > 1:
            merges.append((r, c, rs, cs))
    for r, c, rs, cs in merges:
        table.mergeCells(r, c, rs, cs)
    cursor.movePosition(QTextCursor.MoveOperation.End)
    st.fresh = True


def build_document(blocks, doc=None):
    """Baut ein QTextDocument aus IR-Blöcken."""
    if doc is None:
        doc = QTextDocument()
    undo = doc.isUndoRedoEnabled()
    doc.setUndoRedoEnabled(False)     # ohne Rückgängig-Verlauf aufbauen (viel schneller)
    doc.clear()
    doc.setDefaultFont(base_font())
    doc.setDocumentMargin(24)
    cursor = QTextCursor(doc)
    st = _State(doc)
    _insert_blocks(cursor, blocks, st)
    # überzähligen leeren Schlussabsatz entfernen, wenn davor Text steht
    last = doc.lastBlock()
    if last.length() <= 1 and doc.blockCount() > 1 and not QTextCursor(last).currentTable():
        prev = last.previous()
        if prev.isValid() and not QTextCursor(prev).currentTable():
            c = QTextCursor(doc)
            c.movePosition(QTextCursor.MoveOperation.End)
            c.deletePreviousChar()
    doc.setModified(False)
    doc.clearUndoRedoStacks()
    doc.setUndoRedoEnabled(undo)
    return doc
