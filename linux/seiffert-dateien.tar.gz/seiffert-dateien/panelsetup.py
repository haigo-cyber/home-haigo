#!/usr/bin/env python3
"""Seifferts Panels: die beiden Seitenleisten des Schreibtischs (Sortenknöpfe und Favoriten) als ganz normale Panels der Panel-Software
des Desktops. Ohne Qt und GTK, nur Python-Standardbibliothek.

  seiffert-panel status                   zeigt, welche Panel-Software gefunden wurde und ob die Panels schon da sind
  seiffert-panel create [--panel=NAME]    legt die Panels an (oder aktualisiert sie)
  seiffert-panel sync                     gleicht die Favoriten ab (nur wenn die Panels schon angelegt sind)
  seiffert-panel remove [--panel=NAME]    entfernt die Panels und stellt die Panel-Einstellungen wieder her
  NAME: mate, lxpanel, lxqt, cinnamon (ohne Angabe wird die laufende Panel-Software erkannt)
  Zusätzlich: --dry-run zeigt nur, was geändert würde; --side=left|right setzt die Seite der Sortenknöpfe (sonst wie beim Schreibtisch).

Die Panels sind zusätzliche, senkrechte Leisten. Die vorhandenen Panels werden nie verändert; vor dem ersten Anlegen wird gesichert,
was geändert wird (Ordner panel-sicherung in ~/.config/seiffert-dateien)."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

APP_ID = "seiffert-dateien"
SORTS = [("all", "Alles"), ("favapp", "Favoriten"), ("app", "Programme"), ("file", "Dateien"), ("folder", "Ordner"), ("text", "Volltext"),
         ("command", "Befehle"), ("clip", "Zwischenablage"), ("system", "System")]
COLORS = {"all": "#5aa0c8", "favapp": "#e0b84c", "app": "#6f9cb9", "file": "#8a6fb5", "folder": "#d6a24a", "text": "#5b9876",
          "command": "#b35a8f", "clip": "#8d97a3", "system": "#b1523f"}
# Zeichen im 64er Raster; jedes Symbol: Kreis in der Sortenfarbe plus ein weißes Zeichen
GLYPHS = {
    "all": '<circle cx="24" cy="24" r="6"/><circle cx="40" cy="24" r="6"/><circle cx="24" cy="40" r="6"/><circle cx="40" cy="40" r="6"/>',
    "favapp": '<path d="M32 15l5.2 10.6 11.7 1.7-8.5 8.2 2 11.6L32 41.6 21.6 47.1l2-11.6-8.5-8.2 11.7-1.7z"/>',
    "app": '<rect x="17" y="17" width="12" height="12" rx="2"/><rect x="35" y="17" width="12" height="12" rx="2"/>'
           '<rect x="17" y="35" width="12" height="12" rx="2"/><rect x="35" y="35" width="12" height="12" rx="2"/>',
    "file": '<path d="M20 14h16l10 10v26H20z"/>',
    "folder": '<path d="M14 22h14l4 5h18v21H14z"/>',
    "text": '<rect x="16" y="19" width="32" height="5" rx="2"/><rect x="16" y="29" width="32" height="5" rx="2"/><rect x="16" y="39" width="20" height="5" rx="2"/>',
    "command": '<path d="M17 20l14 12-14 12" fill="none" stroke="#fff" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>'
               '<rect x="34" y="41" width="16" height="5" rx="2"/>',
    "clip": '<rect x="18" y="19" width="28" height="32" rx="4"/><rect x="26" y="13" width="12" height="9" rx="3" fill="#333"/>',
    "system": '<circle cx="32" cy="32" r="9" fill="none" stroke="#fff" stroke-width="6"/><path d="M32 12v9M32 43v9M12 32h9M43 32h9" stroke="#fff" stroke-width="6" stroke-linecap="round"/>',
}
SIDES = ("left", "right")
MINE = "seiffert"                                  # Kennzeichen aller eigenen Einträge in den Panel-Dateien


class PanelError(Exception):
    pass


def home() -> Path:
    return Path.home()


def config_home() -> Path:
    return Path(os.environ.get("XDG_CONFIG_HOME") or (home() / ".config"))


def data_home() -> Path:
    return Path(os.environ.get("XDG_DATA_HOME") or (home() / ".local" / "share"))


def own_dir() -> Path:
    return data_home() / "seiffert-panel"


def backup_dir() -> Path:
    return config_home() / APP_ID / "panel-sicherung"


def load_config() -> dict:
    try:
        d = json.loads((config_home() / APP_ID / "config.json").read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def starter_bin() -> str:
    p = home() / ".local" / "bin" / "seiffert-starter"
    return str(p) if p.exists() else (shutil.which("seiffert-starter") or str(p))


def app_dirs() -> list[Path]:
    out = [data_home() / "applications"]
    for d in (os.environ.get("XDG_DATA_DIRS") or "/usr/local/share:/usr/share").split(":"):
        if d:
            out.append(Path(d) / "applications")
    return out


def find_desktop(app_id: str) -> Path | None:
    for d in app_dirs():
        p = d / app_id
        if p.is_file():
            return p
    return None


def desktop_name(path: Path) -> str:
    try:
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            if line.startswith("Name="):
                return line[5:].strip()
    except OSError:
        pass
    return path.stem


def svg_icon(cat: str) -> str:
    return ('<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><circle cx="32" cy="32" r="30" fill="%s"/>'
            '<g fill="#fff">%s</g></svg>\n' % (COLORS[cat], GLYPHS[cat]))


class Model:
    """Neutrale Beschreibung: zwei Leisten, jede mit einer Liste von Startern (Name, .desktop-Datei)."""

    def __init__(self, cfg: dict | None = None, side: str | None = None):
        cfg = cfg if cfg is not None else load_config()
        st = cfg.get("starter") if isinstance(cfg.get("starter"), dict) else {}
        side = side or st.get("desk_side") or "left"
        self.side = side if side in SIDES else "left"
        self.other = "right" if self.side == "left" else "left"
        try:
            self.size = max(24, min(128, int(st.get("desk_btn", 64))))
        except (TypeError, ValueError):
            self.size = 64
        self.icon = max(16, min(96, self.size - 12))
        favs = st.get("app_favs") if isinstance(st.get("app_favs"), list) else []
        self.sorts: list[tuple[str, str, Path]] = []
        self.favs: list[tuple[str, str, Path]] = []
        self.missing: list[str] = []
        self._files(favs)

    def _files(self, favs: list) -> None:
        d = own_dir()
        for cat, label in SORTS:
            if cat == "favapp" and not favs:
                continue
            self.sorts.append((cat, label, d / ("sorte-%s.desktop" % cat)))
        for a in favs:
            a = str(a)
            p = find_desktop(a) if re.fullmatch(r"[A-Za-z0-9._+-]+\.desktop", a) else None
            if p:
                self.favs.append((a, desktop_name(p), p))
            else:
                self.missing.append(a)

    def write_files(self) -> None:
        """Eigene Starterdateien und Symbole schreiben (nur im eigenen Ordner)."""
        d = own_dir()
        (d / "icons").mkdir(parents=True, exist_ok=True)
        keep = set()
        exe = starter_bin()
        for cat, label, path in self.sorts:
            ic = d / "icons" / ("sorte-%s.svg" % cat)
            ic.write_text(svg_icon(cat), encoding="utf-8")
            path.write_text("[Desktop Entry]\nType=Application\nName=Starter: %s\nComment=Seifferts Starter, Sorte %s\nExec=%s --cat=%s\nIcon=%s\n"
                            "Terminal=false\nCategories=Utility;\nX-Seiffert-Panel=1\n" % (label, label, exe, cat, ic), encoding="utf-8")
            keep.add(path.name)
            keep.add(ic.name)
        for old in list(d.glob("sorte-*.desktop")) + list((d / "icons").glob("sorte-*.svg")):
            if old.name not in keep:
                old.unlink()

    def remove_files(self) -> None:
        shutil.rmtree(own_dir(), ignore_errors=True)


def run(cmd: list[str], env: dict | None = None) -> tuple[int, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=20, env=env)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except (OSError, subprocess.SubprocessError) as e:
        return 1, str(e)


def backup_write(name: str, text: str) -> None:
    """Sichert einmalig (die erste Sicherung bleibt erhalten, sie ist der Zustand vor Seifferts Panels)."""
    d = backup_dir()
    d.mkdir(parents=True, exist_ok=True)
    p = d / name
    if not p.exists():
        p.write_text(text, encoding="utf-8")


def backup_read(name: str) -> str | None:
    try:
        return (backup_dir() / name).read_text(encoding="utf-8")
    except OSError:
        return None


# --------------------------------------------------------------------------------------------------------------- MATE
class Mate:
    name = "mate"
    label = "MATE-Panel"
    TOP = "org.mate.panel.toplevel:/org/mate/panel/toplevels/%s/"
    OBJ = "org.mate.panel.object:/org/mate/panel/objects/%s/"
    TOPS = ("seiffert-sorten", "seiffert-favoriten")

    def __init__(self, dry: bool = False):
        self.dry = dry
        self.log: list[str] = []

    def available(self) -> bool:
        if not shutil.which("gsettings"):
            return False
        rc, out = run(["gsettings", "list-schemas"])
        return rc == 0 and "org.mate.panel" in out.split()

    def active(self) -> bool:
        return bool(re.search(r"\bmate", (os.environ.get("XDG_CURRENT_DESKTOP", "") + os.environ.get("DESKTOP_SESSION", "")).lower())) \
            or run(["pgrep", "-x", "mate-panel"])[0] == 0

    def get(self, key: str) -> list[str]:
        rc, out = run(["gsettings", "get", "org.mate.panel", key])
        if rc != 0:
            raise PanelError("MATE: %s lässt sich nicht lesen (%s)" % (key, out.strip()))
        return re.findall(r"'([^']*)'", out)

    def set(self, schema: str, key: str, val: str) -> None:
        self.log.append("%s %s = %s" % (schema, key, val))
        if self.dry:
            return
        rc, out = run(["gsettings", "set", schema, key, val])
        if rc != 0:
            raise PanelError("MATE: %s ließ sich nicht setzen (%s)" % (key, out.strip()))

    @staticmethod
    def lst(items: list[str]) -> str:
        return "[" + ", ".join("'%s'" % i for i in items) + "]"

    def object_ids(self, tid: str, n: int) -> list[str]:
        return ["%s-%d" % (tid, i) for i in range(n)]

    def plan(self, m: Model) -> list[tuple[str, str, list[Path]]]:
        return [("seiffert-sorten", m.side, [p for _, _, p in m.sorts]), ("seiffert-favoriten", m.other, [p for _, _, p in m.favs])]

    def create(self, m: Model) -> None:
        tops, objs = self.get("toplevel-id-list"), self.get("object-id-list")
        backup_write("mate-listen.json", json.dumps({"toplevel-id-list": tops, "object-id-list": objs}))
        # eigene Einträge zuerst entfernen (neu aufbauen), die fremden bleiben unangetastet
        tops = [t for t in tops if t not in self.TOPS]
        objs = [o for o in objs if not o.startswith(MINE + "-")]
        for tid, side, files in self.plan(m):
            if not files:
                continue
            tops.append(tid)
            t = self.TOP % tid
            self.set(t, "orientation", "'%s'" % side)
            self.set(t, "size", str(m.size))
            self.set(t, "expand", "false")
            self.set(t, "y-centered", "true")
            self.set(t, "x-centered", "false")
            self.set(t, "x", "-1" if side == "right" else "0")           # der nicht benutzte Anker muss auf -1 zurück, sonst gewinnt er
            self.set(t, "x-right", "0" if side == "right" else "-1")
            self.set(t, "enable-buttons", "false")
            self.set(t, "monitor", "0")
            for i, f in enumerate(files):
                oid = "%s-%d" % (tid, i)
                objs.append(oid)
                o = self.OBJ % oid
                self.set(o, "object-type", "'launcher'")
                self.set(o, "toplevel-id", "'%s'" % tid)
                self.set(o, "position", str(i))
                self.set(o, "launcher-location", "'%s'" % f)
                self.set(o, "locked", "false")
        self.set("org.mate.panel", "object-id-list", self.lst(objs))
        self.set("org.mate.panel", "toplevel-id-list", self.lst(tops))

    def remove(self) -> None:
        tops, objs = self.get("toplevel-id-list"), self.get("object-id-list")
        mine_o = [o for o in objs if o.startswith(MINE + "-")]
        self.set("org.mate.panel", "object-id-list", self.lst([o for o in objs if o not in mine_o]))
        self.set("org.mate.panel", "toplevel-id-list", self.lst([t for t in tops if t not in self.TOPS]))
        if not self.dry:
            for o in mine_o:
                run(["gsettings", "reset-recursively", self.OBJ % o])
            for t in self.TOPS:
                run(["gsettings", "reset-recursively", self.TOP % t])

    def present(self) -> bool:
        try:
            return any(t in self.TOPS for t in self.get("toplevel-id-list"))
        except PanelError:
            return False


# ------------------------------------------------------------------------------------------------------------- LXPanel
class LXPanel:
    name = "lxpanel"
    label = "LXPanel (LXDE)"
    FILES = ("seiffert-sorten", "seiffert-favoriten")

    def __init__(self, dry: bool = False):
        self.dry = dry
        self.log: list[str] = []

    def profile_dir(self) -> Path | None:
        base = config_home() / "lxpanel"
        prof = os.environ.get("LXPANEL_PROFILE") or ""
        if prof and (base / prof).is_dir():
            return base / prof
        for n in ("LXDE", "LXDE-pi", "default"):
            if (base / n / "panels").is_dir():
                return base / n
        subs = [p for p in sorted(base.glob("*")) if (p / "panels").is_dir()] if base.is_dir() else []
        return subs[0] if len(subs) == 1 else None

    def available(self) -> bool:
        return shutil.which("lxpanel") is not None and self.profile_dir() is not None

    def active(self) -> bool:
        return run(["pgrep", "-x", "lxpanel"])[0] == 0

    @staticmethod
    def conf(side: str, size: int, files: list[str]) -> str:
        btn = "".join("    Button {\n      id=%s\n    }\n" % f for f in files)
        return ("# Seifferts Panels: wird von seiffert-panel erzeugt und beim Aktualisieren überschrieben.\n\n"
                "Global {\n  edge=%s\n  allign=center\n  margin=0\n  widthtype=pixel\n  width=%d\n  height=%d\n  transparent=0\n"
                "  autohide=0\n  heightwhenhidden=2\n  setdocktype=1\n  setpartialstrut=1\n  usefontcolor=0\n  usefontsize=0\n"
                "  background=0\n  iconsize=%d\n}\n\nPlugin {\n  type=launchbar\n  Config {\n%s  }\n}\n"
                % (side, max(1, len(files)) * size + 8, size, max(16, size - 12), btn))

    PREFIX = "seiffert-panel-"

    def own_apps(self) -> list[Path]:
        return sorted((data_home() / "applications").glob(self.PREFIX + "sorte-*.desktop"))

    def create(self, m: Model) -> None:
        """LXPanel kennt in der Startleiste nur Programme aus seinem Menü-Cache; deshalb liegen die Sortenstarter (ohne Menüeintrag,
        NoDisplay) als Kopien im Ordner der Programmstarter und werden über ihren Namen angesprochen. Favoriten sind ohnehin dort."""
        d = self.profile_dir()
        if d is None:
            raise PanelError("LXPanel: kein Profil unter ~/.config/lxpanel gefunden.")
        ids: dict[str, list[str]] = {"seiffert-sorten": [], "seiffert-favoriten": [a for a, _, _ in m.favs]}
        if not self.dry:
            for old in self.own_apps():
                old.unlink()
            (data_home() / "applications").mkdir(parents=True, exist_ok=True)
        for cat, _, path in m.sorts:
            name = "%ssorte-%s.desktop" % (self.PREFIX, cat)
            ids["seiffert-sorten"].append(name)
            if not self.dry:
                (data_home() / "applications" / name).write_text(path.read_text(encoding="utf-8") + "NoDisplay=true\n", encoding="utf-8")
        for n, side in (("seiffert-sorten", m.side), ("seiffert-favoriten", m.other)):
            target = d / "panels" / n
            self.log.append("%s: %d Starter, Seite %s" % (target, len(ids[n]), side))
            if self.dry:
                continue
            if ids[n]:
                target.write_text(self.conf(side, m.size, ids[n]), encoding="utf-8")
            elif target.exists():
                target.unlink()

    def remove(self) -> None:
        d = self.profile_dir()
        if d is None:
            return
        for n in self.FILES:
            p = d / "panels" / n
            if p.exists():
                self.log.append("entfernt: %s" % p)
                if not self.dry:
                    p.unlink()
        for p in self.own_apps():
            self.log.append("entfernt: %s" % p)
            if not self.dry:
                p.unlink()

    def present(self) -> bool:
        d = self.profile_dir()
        return bool(d) and any((d / "panels" / n).exists() for n in self.FILES)

    def reload_hint(self) -> str:
        return "LXPanel liest die Leisten beim Start: lxpanel --profile %s neu starten (lxpanelctl restart)." % (self.profile_dir().name if self.profile_dir() else "…")


# ---------------------------------------------------------------------------------------------------------------- LXQt
class LXQt:
    name = "lxqt"
    label = "LXQt-Panel"
    IDS = ("seiffert-sorten", "seiffert-favoriten")

    def __init__(self, dry: bool = False):
        self.dry = dry
        self.log: list[str] = []

    def path(self) -> Path:
        return config_home() / "lxqt" / "panel.conf"

    def available(self) -> bool:
        return shutil.which("lxqt-panel") is not None and self.path().exists()

    def active(self) -> bool:
        return run(["pgrep", "-x", "lxqt-panel"])[0] == 0

    @staticmethod
    def parse(text: str) -> list[tuple[str, list[str]]]:
        """Abschnitte (Name, Zeilen) in der Reihenfolge der Datei; Zeilen vor dem ersten Abschnitt unter dem Namen ''."""
        secs: list[tuple[str, list[str]]] = [("", [])]
        for line in text.splitlines():
            m = re.fullmatch(r"\[(.+)\]", line.strip())
            if m:
                secs.append((m.group(1), []))
            else:
                secs[-1][1].append(line)
        return secs

    @staticmethod
    def dump(secs: list[tuple[str, list[str]]]) -> str:
        out: list[str] = []
        for name, lines in secs:
            if name:
                out.append("[%s]" % name)
            out.extend(lines)
        return "\n".join(out).rstrip("\n") + "\n"

    def create(self, m: Model) -> None:
        p = self.path()
        text = p.read_text(encoding="utf-8")
        backup_write("lxqt-panel.conf", text)
        secs = [s for s in self.parse(text) if s[0] not in self.IDS and s[0] not in ("seiffert-sorten-start", "seiffert-favoriten-start")]
        # die Liste der Leisten steht in der Vorlage vor dem ersten Abschnitt, bei manchen Versionen unter [General]
        general = next((s for s in secs if s[0] in ("", "General") and any(l.startswith("panels=") for l in s[1])), None)
        if general is None:
            raise PanelError("LXQt: Die Zeile panels= in panel.conf fehlt.")
        panels = []
        for line in general[1]:
            if line.startswith("panels="):
                panels = [x.strip() for x in line[7:].split(",") if x.strip()]
        panels = [x for x in panels if x not in self.IDS]
        # eigene Leisten: Abschnitt je Leiste, dazu je ein Schnellstarter-Abschnitt
        new: list[tuple[str, list[str]]] = []
        for pid, side, files in (("seiffert-sorten", m.side, [p for _, _, p in m.sorts]), ("seiffert-favoriten", m.other, [p for _, _, p in m.favs])):
            if not files:
                continue
            panels.append(pid)
            q = pid + "-start"
            new.append((pid, ["alignment=0", "animation-duration=0", "desktop=0", "hidable=false", "hide-on-overlap=false",
                              "iconSize=%d" % m.icon, "lineCount=1", "lockPanel=false", "opacity=100", "panelSize=%d" % m.size,
                              "position=%s" % ("Left" if side == "left" else "Right"), "plugins=%s" % q, "reserve-space=true",
                              "show-delay=0", "visible-margin=true", "width=%d" % (len(files) * m.size + 8), "width-percent=false"]))
            lines = ["alignment=Left", "type=quicklaunch"]
            for i, f in enumerate(files, 1):
                lines.append("apps\\%d\\desktop=%s" % (i, f))
            lines.append("apps\\size=%d" % len(files))
            new.append((q, lines))
        gl = [("panels=%s" % ", ".join(panels)) if l.startswith("panels=") else l for l in general[1]]
        secs = [(n, gl if ls is general[1] else ls) for n, ls in secs]
        secs.extend(new)
        self.log.append("%s: Leisten %s" % (p, ", ".join(panels)))
        if not self.dry:
            p.write_text(self.dump(secs), encoding="utf-8")

    def remove(self) -> None:
        p = self.path()
        if not p.exists():
            return
        secs = [s for s in self.parse(p.read_text(encoding="utf-8")) if s[0] not in self.IDS and not s[0].endswith("-start")]
        secs = [(n, [("panels=%s" % ", ".join(x for x in l[7:].split(",") if x.strip() and x.strip() not in self.IDS)) if l.startswith("panels=") else l for l in ls])
                for n, ls in secs]
        self.log.append("%s: eigene Leisten entfernt" % p)
        if not self.dry:
            p.write_text(self.dump(secs), encoding="utf-8")

    def present(self) -> bool:
        p = self.path()
        return p.exists() and "[seiffert-sorten]" in p.read_text(encoding="utf-8", errors="replace")


# ------------------------------------------------------------------------------------------------------------ Cinnamon
class Cinnamon:
    """Nicht getestet: Cinnamon lässt sich im Prüfstand nicht ohne Grafikbeschleunigung starten. Der Aufbau folgt den GSettings-Schlüsseln
    org.cinnamon (panels-enabled, enabled-applets, panel-zone-icon-sizes) und der Konfigurationsdatei des Applets panel-launchers@cinnamon.org."""
    name = "cinnamon"
    label = "Cinnamon-Panel"
    UUID = "panel-launchers@cinnamon.org"
    INSTANCE = "9317"                                      # feste Nummer der eigenen Applet-Instanzen (zwei Leisten: 9317, 9318)

    def __init__(self, dry: bool = False):
        self.dry = dry
        self.log: list[str] = []

    def available(self) -> bool:
        if not shutil.which("gsettings"):
            return False
        return "org.cinnamon" in run(["gsettings", "list-schemas"])[1].split()

    def active(self) -> bool:
        return run(["pgrep", "-x", "cinnamon"])[0] == 0

    def gget(self, key: str) -> list[str]:
        rc, out = run(["gsettings", "get", "org.cinnamon", key])
        if rc != 0:
            raise PanelError("Cinnamon: %s lässt sich nicht lesen" % key)
        return re.findall(r"'([^']*)'", out)

    def gset(self, key: str, items: list[str]) -> None:
        val = "[" + ", ".join("'%s'" % i for i in items) + "]"
        self.log.append("org.cinnamon %s = %s" % (key, val))
        if not self.dry:
            rc, out = run(["gsettings", "set", "org.cinnamon", key, val])
            if rc != 0:
                raise PanelError("Cinnamon: %s ließ sich nicht setzen (%s)" % (key, out.strip()))

    def cfg_path(self, inst: str) -> Path:
        base = Path(os.environ.get("XDG_CONFIG_HOME") or (home() / ".config"))
        return base / "cinnamon" / "spices" / self.UUID / ("%s.json" % inst)

    def launcher_dir(self) -> Path:
        """Eigene Starter, die Cinnamon nicht über das Menü kennt, liegen hier; das Applet findet sie über den Dateinamen."""
        return data_home() / "cinnamon" / "panel-launchers"

    def create(self, m: Model) -> None:
        panels, applets = self.gget("panels-enabled"), self.gget("enabled-applets")
        backup_write("cinnamon-listen.json", json.dumps({"panels-enabled": panels, "enabled-applets": applets}))
        panels = [p for p in panels if not p.split(":")[0].startswith("9")]
        applets = [a for a in applets if self.UUID not in a or not a.split(":")[0].startswith("panel9")]
        names = {"9317": [], "9318": []}
        if not self.dry:
            self.launcher_dir().mkdir(parents=True, exist_ok=True)
        for cat, _, path in m.sorts:
            name = "seiffert-panel-sorte-%s.desktop" % cat
            names["9317"].append(name)
            if not self.dry:
                (self.launcher_dir() / name).write_text(path.read_text(encoding="utf-8"), encoding="utf-8")
        names["9318"] = [a for a, _, _ in m.favs]                 # Favoriten sind Programme des Menüs: Cinnamon findet sie über ihre Kennung
        todo = [("9", m.side, names["9317"], "9317"), ("8", m.other, names["9318"], "9318")]
        sizes = []
        try:
            sizes = self.gget("panel-zone-icon-sizes")
        except PanelError:
            pass
        for pid, side, files, inst in todo:
            if not files:
                continue
            panels.append("%s:0:%s" % (pid, side))
            applets.append("panel%s:center:0:%s:%s" % (pid, self.UUID, inst))
            if not self.dry:
                cp = self.cfg_path(inst)
                cp.parent.mkdir(parents=True, exist_ok=True)
                cp.write_text(json.dumps({"launcherList": {"type": "generic", "default": list(files), "value": list(files)}}, indent=2), encoding="utf-8")
        self.gset("panels-enabled", panels)
        self.gset("enabled-applets", applets)

    def remove(self) -> None:
        panels, applets = self.gget("panels-enabled"), self.gget("enabled-applets")
        self.gset("panels-enabled", [p for p in panels if not p.split(":")[0] in ("8", "9")])
        self.gset("enabled-applets", [a for a in applets if not (self.UUID in a and a.split(":")[0] in ("panel8", "panel9"))])
        if not self.dry:
            for inst in ("9317", "9318"):
                self.cfg_path(inst).unlink(missing_ok=True)
            for f in self.launcher_dir().glob("seiffert-panel-sorte-*.desktop"):
                f.unlink()

    def present(self) -> bool:
        try:
            return any(p.split(":")[0] in ("8", "9") for p in self.gget("panels-enabled"))
        except PanelError:
            return False


ADAPTERS = {"mate": Mate, "lxpanel": LXPanel, "lxqt": LXQt, "cinnamon": Cinnamon}
ORDER = ("mate", "lxpanel", "lxqt", "cinnamon")         # Reihenfolge der Erkennung, wenn mehrere installiert sind


def detect(dry: bool = False) -> list:
    """Gefundene Panel-Software: zuerst die gerade laufende, danach die übrigen installierten in fester Reihenfolge.
    Läuft Cinnamon, wird es zuerst gewählt."""
    cin = ADAPTERS["cinnamon"](dry)
    if cin.available() and (cin.active() or "cinnamon" in os.environ.get("XDG_CURRENT_DESKTOP", "").lower()):
        return [cin]                                           # unter Cinnamon wirken die Panels von MATE oder LXDE nicht, auch wenn sie installiert sind
    found = [ADAPTERS[n](dry) for n in ORDER if n != "cinnamon" and ADAPTERS[n](dry).available()]
    return sorted(found, key=lambda a: 0 if a.active() else 1)


def pick(name: str | None, dry: bool = False):
    if name:
        if name not in ADAPTERS:
            raise PanelError("Unbekannte Panel-Software \"%s\". Möglich: %s." % (name, ", ".join(ORDER)))
        a = ADAPTERS[name](dry)
        if not a.available():
            raise PanelError("%s wurde nicht gefunden oder ist nicht eingerichtet." % a.label)
        return a
    found = detect(dry)
    if not found:
        raise PanelError("Keine unterstützte Panel-Software gefunden (MATE, LXDE/LXPanel, LXQt). Cinnamon wird erkannt, wenn es läuft.")
    return found[0]


def create(name: str | None = None, dry: bool = False, side: str | None = None) -> list[str]:
    a = pick(name, dry)
    m = Model(side=side)
    if not dry:
        m.write_files()
    a.create(m)
    msg = ["%s: Panels %s (Sortenknöpfe %s, Favoriten %s)." % (a.label, "würden angelegt" if dry else "angelegt", "links" if m.side == "left" else "rechts", "rechts" if m.side == "left" else "links")]
    if m.missing:
        msg.append("Nicht gefunden und ausgelassen: %s" % ", ".join(m.missing))
    if hasattr(a, "reload_hint"):
        msg.append(a.reload_hint())
    return msg + (["Geplant (nichts geändert):"] + a.log if dry else [])


def sync(dry: bool = False) -> list[str]:
    """Favoriten abgleichen, aber nur dort, wo die Panels schon angelegt sind."""
    out = []
    for n in ORDER:
        a = ADAPTERS[n](dry)
        if a.available() and a.present():
            out += create(n, dry)
    return out


def remove(name: str | None = None, dry: bool = False) -> list[str]:
    targets = [pick(name, dry)] if name else [a for a in detect(dry) if a.present()]
    if not targets:
        return ["Es sind keine Seifferts Panels angelegt."]
    out = []
    for a in targets:
        a.remove()
        out.append("%s: Panels entfernt." % a.label)
        if dry:
            out += a.log
    if not dry and not any(ADAPTERS[n](False).available() and ADAPTERS[n](False).present() for n in ORDER):
        Model().remove_files()
    return out


def status() -> list[str]:
    out = []
    found = detect()
    if not found:
        return ["Keine unterstützte Panel-Software gefunden (MATE, LXDE/LXPanel, LXQt, Cinnamon)."]
    for a in found:
        out.append("%s: %s%s" % (a.label, "angelegt" if a.present() else "nicht angelegt", ", läuft" if a.active() else ""))
    return out


def main(argv: list[str]) -> int:
    args = [a for a in argv[1:] if not a.startswith("--")]
    opts = dict(a[2:].split("=", 1) if "=" in a else (a[2:], "1") for a in argv[1:] if a.startswith("--"))
    cmd = args[0] if args else "status"
    dry = "dry-run" in opts
    try:
        if cmd == "status":
            lines = status()
        elif cmd == "create":
            lines = create(opts.get("panel"), dry, opts.get("side") if opts.get("side") in SIDES else None)
        elif cmd == "sync":
            lines = sync(dry)
        elif cmd == "remove":
            lines = remove(opts.get("panel"), dry)
        else:
            sys.stderr.write(__doc__ + "\n")
            return 2
    except PanelError as e:
        sys.stderr.write("seiffert-panel: %s\n" % e)
        return 1
    print("\n".join(lines))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
