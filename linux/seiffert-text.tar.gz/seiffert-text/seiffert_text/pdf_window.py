"""PDF-Fenster: ansehen, Text ändern und hinzufügen, Seiten verwalten (pdf_tools.py)."""
import os

from PySide6.QtCore import Qt, Signal, QRectF
from PySide6.QtGui import QAction, QActionGroup, QColor, QFont, QFontMetricsF, QImage, QKeySequence, QPixmap
from PySide6.QtWidgets import (QCheckBox, QColorDialog, QComboBox, QDoubleSpinBox, QHBoxLayout, QPushButton, QWidget, QRadioButton, QApplication, QDialog, QDialogButtonBox, QFileDialog, QFormLayout, QInputDialog,
                               QLabel, QLineEdit, QListWidget, QMainWindow, QMessageBox, QPlainTextEdit, QTextEdit,
                               QScrollArea, QSpinBox, QSplitter)

from . import APP_NAME, VERSION
from .common import fullscreen_action
from .pdf_tools import PdfEditor, PdfError
from .fieldlayer import FieldLayer, align_rects

MODE_VIEW, MODE_EDIT, MODE_ADD, MODE_FIELDS = 0, 1, 2, 3

KINDS = (("Sans (Liberation Sans)", "sans"), ("Serif (Liberation Serif)", "serif"), ("Mono (Liberation Mono)", "mono"))


def flags_kind(flags):
    return "mono" if flags & 8 else ("serif" if flags & 4 else "sans")


def make_flags(kind, bold, italic, base=0):
    """PyMuPDF-Schriftmerkmale: 2 kursiv, 4 Serife, 8 dicktengleich, 16 fett; sonstige Bits bleiben."""
    f = base & ~30
    if kind == "serif":
        f |= 4
    elif kind == "mono":
        f |= 8
    if bold:
        f |= 16
    if italic:
        f |= 2
    return f


class FormatRow(QWidget):
    """Zeile mit Schriftart, Größe, fett, kursiv und Farbe (für Zeile ändern und Text hinzufügen)."""

    def __init__(self, flags, size, color, parent=None):
        super().__init__(parent)
        self.base_flags = flags
        self.orig = (flags & 30, round(float(size), 1), int(color))
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.kind = QComboBox()
        for text, key in KINDS:
            self.kind.addItem(text, key)
        self.kind.setCurrentIndex([k for _, k in KINDS].index(flags_kind(flags)))
        self.size = QDoubleSpinBox()
        self.size.setRange(4, 200)
        self.size.setDecimals(1)
        self.size.setSingleStep(0.5)
        self.size.setSuffix(" pt")
        self.size.setValue(round(float(size), 1))
        self.bold = QCheckBox("fett")
        self.bold.setChecked(bool(flags & 16))
        f = self.bold.font()
        f.setBold(True)
        self.bold.setFont(f)
        self.ital = QCheckBox("kursiv")
        self.ital.setChecked(bool(flags & 2))
        f2 = self.ital.font()
        f2.setItalic(True)
        self.ital.setFont(f2)
        self.col = QPushButton("Farbe")
        self.rgb = int(color)
        self.col.clicked.connect(self.pick)
        self.reset_btn = QPushButton("Wie Original")
        self.reset_btn.setToolTip("Schrift, Größe, fett, kursiv und Farbe der Zeile wieder wie im Original")
        self.reset_btn.clicked.connect(self.reset)
        for w in (self.kind, self.size, self.bold, self.ital, self.col, self.reset_btn):
            lay.addWidget(w)
        self.paint()

    def paint(self):
        c = QColor((self.rgb >> 16) & 255, (self.rgb >> 8) & 255, self.rgb & 255)
        self.col.setStyleSheet("QPushButton{border-left:18px solid %s;padding:3px 10px;}" % c.name())

    def pick(self):
        c = QColorDialog.getColor(QColor((self.rgb >> 16) & 255, (self.rgb >> 8) & 255, self.rgb & 255), self, "Textfarbe")
        if c.isValid():
            self.rgb = (c.red() << 16) | (c.green() << 8) | c.blue()
            self.paint()

    def reset(self):
        fl, size, color = self.base_flags, self.orig[1], self.orig[2]
        self.kind.setCurrentIndex([k for _, k in KINDS].index(flags_kind(fl)))
        self.size.setValue(size)
        self.bold.setChecked(bool(fl & 16))
        self.ital.setChecked(bool(fl & 2))
        self.rgb = color
        self.paint()

    def value(self):
        return {"size": self.size.value(), "flags": make_flags(self.kind.currentData(), self.bold.isChecked(),
                                                               self.ital.isChecked(), self.base_flags),
                "color": self.rgb}

    def changed(self):
        v = self.value()
        return (v["flags"] & 30, round(v["size"], 1), v["color"]) != self.orig


class PageLabel(QLabel):
    clicked = Signal(float, float)

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(e.position().x(), e.position().y())


class _MultiLine(QTextEdit):
    """Mehrzeiliges Formularfeld. Hat es den Fokus und passt der Text nicht in lesbarer Größe hinein,
    wächst es nach unten, bis der ganze Text zu sehen ist; beim Verlassen schrumpft es wieder."""
    done = Signal()

    def __init__(self, parent, win, f):
        super().__init__(parent)
        self.win, self.f = win, f
        self.base = None
        self.expanded = False
        self.setAcceptRichText(False)
        self.setFrameShape(QTextEdit.Shape.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setLineWrapMode(QTextEdit.LineWrapMode.WidgetWidth)
        self.document().setDocumentMargin(2)

    def focusInEvent(self, e):
        super().focusInEvent(e)
        self.win.expand_field(self)

    def focusOutEvent(self, e):
        super().focusOutEvent(e)
        self.win.collapse_field(self)
        self.done.emit()


FIELD_CSS = ("background-color: #dbe7ff; color: #000000; border: 1px solid %s; "
             "padding: 0px 1px; margin: 0px; font-size: %dpx;")
BORDER_OK, BORDER_CLIP = "#5b8dd9", "#e07b00"
MM = 25.4 / 72.0      # Millimeter je PDF-Punkt


def field_font(name):
    """Bildschirmschrift passend zur Schrift des Formularfelds (Helvetica, Times, Courier)."""
    n = (name or "").lower()
    f = QFont()
    if n.startswith(("cour", "co")):
        f.setFamilies(["Liberation Mono", "DejaVu Sans Mono", "Courier New", "monospace"])
    elif n.startswith(("ti", "times")):
        f.setFamilies(["Liberation Serif", "Tinos", "Times New Roman", "DejaVu Serif", "serif"])
    else:
        f.setFamilies(["Liberation Sans", "Arimo", "Arial", "Helvetica", "DejaVu Sans", "sans-serif"])
    return f


class PdfWindow(QMainWindow):
    def __init__(self, path, main=None, embedded=False):
        super().__init__()
        self.main = main
        self.embedded = embedded        # als Tab im Hauptfenster statt als eigenes Fenster
        if embedded:
            self.setWindowFlags(Qt.WindowType.Widget)
        self.ed = PdfEditor(path)
        self.pno = 0
        self.zoom = 1.4
        self.mode = MODE_VIEW
        self.layer = None
        self._sel_next = []
        if not embedded:
            self.resize(1150, 800)
        if main is not None:
            self.setWindowIcon(main.windowIcon())
        self._build()
        self.statusBar().addPermanentWidget(QLabel("Version %s " % VERSION))
        self.fill_list()
        self.show_page()
        n = self.ed.field_count()
        if n:
            self.statusBar().showMessage("%d Formularfeld(er) erkannt: Die blau hinterlegten Felder lassen sich direkt "
                                         "ausfüllen (Tab springt zum nächsten Feld)." % n)
        else:
            self.statusBar().showMessage("Text bearbeiten: Werkzeug wählen und auf eine Zeile klicken. "
                                         "Der Text wird an derselben Stelle neu gesetzt; es wird nicht neu umbrochen.")

    def _build(self):
        split = QSplitter()
        self.list = QListWidget()
        self.list.setMaximumWidth(140)
        self.list.currentRowChanged.connect(self.goto)
        self.page = PageLabel()
        self.page.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        self.page.clicked.connect(self.on_click)
        self.scroll = QScrollArea()
        self.scroll.setWidget(self.page)
        self.scroll.setWidgetResizable(False)
        self.scroll.setAlignment(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop)
        split.addWidget(self.list)
        split.addWidget(self.scroll)
        split.setStretchFactor(1, 1)
        self.setCentralWidget(split)

        def A(text, slot, key=None, check=False):
            a = QAction(text, self)
            a.triggered.connect(slot)
            if key:
                a.setShortcut(QKeySequence(key))
            a.setCheckable(check)
            return a
        self.a_save = A("Speichern", self.save, "Ctrl+S")
        self.a_saveas = A("Speichern unter …", self.save_as, "Ctrl+Shift+S")
        self.a_tex = A("Text als LaTeX-Quelltext im Textfenster öffnen", self.to_latex)
        self.a_src = A("PDF-Quelltext bearbeiten", self.to_source, "Ctrl+U")
        self.a_undo = A("Rückgängig", self.undo, "Ctrl+Z")
        self.a_view = A("Ansehen", lambda: self.set_mode(MODE_VIEW), "Esc", True)
        self.a_edit = A("Text bearbeiten", lambda: self.set_mode(MODE_EDIT), "Ctrl+E", True)
        self.a_add = A("Text hinzufügen", lambda: self.set_mode(MODE_ADD), "Ctrl+T", True)
        self.a_fmode = A("Formularfelder bearbeiten", lambda: self.set_mode(MODE_FIELDS), "Ctrl+Shift+E", True)
        self.a_fnew_text = A("Neues Textfeld", lambda: self.fields_tool("text"))
        self.a_fnew_multi = A("Neues mehrzeiliges Textfeld", lambda: self.fields_tool("multiline"))
        self.a_fnew_check = A("Neues Ankreuzfeld", lambda: self.fields_tool("check"))
        self.a_fnew_combo = A("Neues Auswahlfeld", lambda: self.fields_tool("combo"))
        self.a_fprops = A("Eigenschaften des Felds …", self.fields_properties, "F2")
        self.a_fcopy = A("Feld kopieren", self.fields_copy, "Ctrl+D")
        self.a_fdel = A("Feld löschen", self.fields_delete, "Delete")
        self.a_fall = A("Alle Felder der Seite markieren (Strg+A)", self.fields_select_all)
        self.a_falign = [(A(t, lambda _=False, op=op: self.fields_align(op)), op) for t, op in (
            ("Links bündig", "left"), ("Rechts bündig", "right"), ("Oben bündig", "top"), ("Unten bündig", "bottom"),
            ("Waagerecht mittig", "hcenter"), ("Senkrecht mittig", "vcenter"),
            ("Gleiche Breite (wie das zuerst markierte)", "same_w"), ("Gleiche Höhe (wie das zuerst markierte)", "same_h"),
            ("Gleiche Größe (wie das zuerst markierte)", "same_size"),
            ("Waagerecht gleichmäßig verteilen", "dist_h"), ("Senkrecht gleichmäßig verteilen", "dist_v"))]
        grp = QActionGroup(self)
        for a in (self.a_view, self.a_edit, self.a_add, self.a_fmode):
            grp.addAction(a)
        self.a_view.setChecked(True)
        self._field_actions = [self.a_fprops, self.a_fcopy, self.a_fdel, self.a_fall] + [a for a, _ in self.a_falign]
        for a in self._field_actions:
            a.setEnabled(False)
        self.a_replace = A("Suchen und ersetzen …", self.replace, "Ctrl+H")
        self.a_fields = A("Formularfelder zum Ausfüllen anzeigen", lambda: self.show_page(), "F8", True)
        self.a_fields.setChecked(True)
        self.a_del = A("Seite löschen", self.del_page)
        self.a_rot = A("Seite drehen", self.rot_page, "Ctrl+R")
        self.a_up = A("Seite nach vorn", lambda: self.move(-1), "Ctrl+Up")
        self.a_down = A("Seite nach hinten", lambda: self.move(1), "Ctrl+Down")
        self.a_append = A("PDF anhängen …", self.append)
        self.a_zin = A("Vergrößern", lambda: self.set_zoom(self.zoom * 1.2), "Ctrl++")
        self.a_zout = A("Verkleinern", lambda: self.set_zoom(self.zoom / 1.2), "Ctrl+-")
        self.a_prev = A("Vorige Seite", lambda: self.list.setCurrentRow(max(0, self.pno - 1)), "PgUp")
        self.a_next = A("Nächste Seite", lambda: self.list.setCurrentRow(min(self.ed.count() - 1, self.pno + 1)), "PgDown")
        mb = self.menuBar()
        m = mb.addMenu("&Datei")
        for a in (self.a_save, self.a_saveas, None, self.a_src, self.a_tex, None):
            m.addSeparator() if a is None else m.addAction(a)
        if self.embedded:
            m.addSeparator()
            for text, slot, key in (("Neues Dokument", lambda: self.main.cmd_new(), "Ctrl+N"),
                                    ("Datei öffnen …", lambda: self.main.cmd_open(), "Ctrl+O"),
                                    ("Nächster Tab", lambda: self.main.next_tab(1), "Ctrl+PgDown"),
                                    ("Voriger Tab", lambda: self.main.next_tab(-1), "Ctrl+PgUp")):
                m.addAction(A(text, slot, key))
            m.addSeparator()
        m.addAction(A("Schließen", self.close_me, "Ctrl+W"))
        if self.embedded:
            m.addAction(A("Beenden", lambda: self.main.close(), "Ctrl+Q"))
        m = mb.addMenu("&Bearbeiten")
        for a in (self.a_undo, None, self.a_view, self.a_edit, self.a_add, None, self.a_replace):
            m.addSeparator() if a is None else m.addAction(a)
        m = mb.addMenu("&Formulare")
        for a in (self.a_fmode, None, self.a_fnew_text, self.a_fnew_multi, self.a_fnew_check, self.a_fnew_combo, None,
                  self.a_fprops, self.a_fcopy, self.a_fdel, self.a_fall):
            m.addSeparator() if a is None else m.addAction(a)
        sub = m.addMenu("Ausrichten")
        for a, op in self.a_falign:
            sub.addAction(a)
        m.addSeparator()
        m.addAction(self.a_fields)
        m = mb.addMenu("&Seiten")
        for a in (self.a_prev, self.a_next, None, self.a_up, self.a_down, self.a_rot, self.a_del, None, self.a_append):
            m.addSeparator() if a is None else m.addAction(a)
        m = mb.addMenu("&Ansicht")
        m.addAction(self.a_zin)
        m.addAction(self.a_zout)
        m.addSeparator()
        m.addAction(self.a_fields)
        m.addSeparator()
        m.addAction(fullscreen_action(self))
        if self.embedded and self.main is not None:
            m.addSeparator()
            m.addAction(A("Zwei Fenster: Referenzdatei rechts ein/aus", lambda: self.main.set_ref(not self.main.ref_pane.isVisible()), "F9"))
            m.addAction(A("Referenzdatei öffnen …", lambda: self.main.ref_open(), "Ctrl+Shift+R"))
        m = mb.addMenu("&Hilfe")
        m.addAction(A("Hinweise zur PDF-Bearbeitung", self.help))
        tb = self.addToolBar("PDF")
        tb.setMovable(False)
        for a in (self.a_save, self.a_undo, None, self.a_view, self.a_edit, self.a_add, self.a_fmode, self.a_replace, None,
                  self.a_up, self.a_down, self.a_rot, self.a_del, None, self.a_zout, self.a_zin):
            tb.addSeparator() if a is None else tb.addAction(a)
        tb.addSeparator()
        tb.addWidget(QLabel(" Schriftgröße für neuen Text: "))
        self.size = QSpinBox()
        self.size.setRange(5, 72)
        self.size.setValue(11)
        tb.addWidget(self.size)

    # ---- Anzeige
    def update_title(self):
        self.setWindowTitle("%s%s – %s %s PDF" % ("* " if self.ed.modified else "",
                                                  os.path.basename(self.ed.path), APP_NAME, VERSION))
        if self.embedded and self.main is not None:
            self.main.pdf_title_changed(self)

    def tab_path(self):
        return self.ed.path

    def tab_modified(self):
        return bool(self.ed.modified)

    def close_me(self):
        """Schließen: als Tab wird der Tab geschlossen, sonst das Fenster."""
        if self.embedded and self.main is not None:
            self.main.close_pdf_tab(self)
        else:
            self.close()

    def fill_list(self):
        self.list.blockSignals(True)
        self.list.clear()
        for n in range(self.ed.count()):
            self.list.addItem("Seite %d" % (n + 1))
        self.pno = max(0, min(self.pno, self.ed.count() - 1))
        self.list.setCurrentRow(self.pno)
        self.list.blockSignals(False)

    def goto(self, row):
        self.commit_fields()
        self._sel_next = []
        if 0 <= row < self.ed.count():
            self.pno = row
            self.show_page()
            self.scroll.verticalScrollBar().setValue(0)

    def show_page(self):
        samples, w, h, stride = self.ed.render(self.pno, self.zoom)
        img = QImage(samples, w, h, stride, QImage.Format.Format_RGB888).copy()
        self.page.setPixmap(QPixmap.fromImage(img))
        self.page.resize(w, h)
        self.build_fields()
        self.update_title()

    # ---- Formularfelder als Eingabefelder über der Seite
    def build_fields(self):
        for w in getattr(self, "field_widgets", []):
            w.setParent(None)
            w.deleteLater()
        self.field_widgets = []
        self.field_commits = []
        old = getattr(self, "layer", None)
        if old is not None:
            old.setParent(None)
            old.deleteLater()
            self.layer = None
        if self.mode == MODE_FIELDS:
            return self.build_layer()
        if not self.a_fields.isChecked():
            return
        try:
            fields = self.ed.fields(self.pno)
        except Exception:
            return
        z = self.zoom
        for f in fields:
            x0, y0, x1, y1 = f["rect"]
            gx, gy, gw, gh = int(x0 * z), int(y0 * z), max(8, int((x1 - x0) * z)), max(8, int((y1 - y0) * z))
            css = FIELD_CSS % (BORDER_OK, 10)
            kind, xref = f["kind"], f["xref"]
            if kind == "text" and f["multiline"]:
                w = _MultiLine(self.page, self, f)
                w.setPlainText(str(f["value"] or "").replace("\r\n", "\n").replace("\r", "\n"))
                f["value"] = w.toPlainText()
                w.textChanged.connect(lambda w=w, f=f: self.fit_field(w, f))
                w.done.connect(lambda w=w, xref=xref: self.field_changed(xref, w.toPlainText(), w))
                self.field_commits.append(lambda w=w, xref=xref: self.field_changed(xref, w.toPlainText(), w))
                w.setReadOnly(f["readonly"])
            elif kind == "text":
                w = QLineEdit(self.page)
                w.setText(str(f["value"] or ""))
                w.setTextMargins(0, 0, 0, 0)
                w.setAlignment({1: Qt.AlignmentFlag.AlignHCenter, 2: Qt.AlignmentFlag.AlignRight}
                               .get(f["align"], Qt.AlignmentFlag.AlignLeft) | Qt.AlignmentFlag.AlignVCenter)
                w.textChanged.connect(lambda _=None, w=w, f=f: self.fit_field(w, f))
                if f["maxlen"]:
                    w.setMaxLength(f["maxlen"])
                if f["password"]:
                    w.setEchoMode(QLineEdit.EchoMode.Password)
                w.editingFinished.connect(lambda w=w, xref=xref: self.field_changed(xref, w.text(), w))
                self.field_commits.append(lambda w=w, xref=xref: self.field_changed(xref, w.text(), w))
                w.setReadOnly(f["readonly"])
            elif kind in ("combo", "list"):
                w = QComboBox(self.page)
                items = [c if isinstance(c, str) else str(c[-1]) for c in f["choices"]]
                if kind == "list" or "" not in items:
                    w.addItem("")
                w.addItems(items)
                w.setEditable(f["editable"])
                cur = str(f["value"] or "")
                if w.findText(cur) < 0:
                    w.addItem(cur)
                w.setCurrentIndex(w.findText(cur))
                w.activated.connect(lambda _=0, w=w, xref=xref: self.field_changed(xref, w.currentText(), w))
                if f["editable"]:
                    w.lineEdit().editingFinished.connect(
                        lambda w=w, xref=xref: self.field_changed(xref, w.currentText(), w))
                w.setEnabled(not f["readonly"])
            else:
                w = QRadioButton(self.page) if kind == "radio" else QCheckBox(self.page)
                w.setAutoExclusive(False)
                w.setChecked(bool(f["value"]))
                w.clicked.connect(lambda on, xref=xref: self.button_changed(xref, on))
                w.setEnabled(not f["readonly"])
                css = "background-color: #dbe7ff;"
            w.setProperty("pdf_value", f["value"] if kind in ("check", "radio") else str(f["value"] or ""))
            w.setStyleSheet(css)
            w.setToolTip(f["name"])
            w.setGeometry(gx, gy, gw, gh)
            if kind == "text":
                w.show()
                if isinstance(w, _MultiLine):
                    w.base = w.geometry()
                self.fit_field(w, f)
                if isinstance(w, QLineEdit):
                    w.setCursorPosition(0)          # Anfang des Texts zeigen, nicht das Ende
            elif kind in ("combo", "list"):
                fnt = field_font(f["font"])
                fnt.setPixelSize(max(6, int(min(f["fontsize"] * z if f["fontsize"] else 99, (gh - 2) * 0.72))))
                w.setFont(fnt)
            w.show()
            self.field_widgets.append(w)

    def _nominal(self, w, f):
        z = self.zoom
        if f["fontsize"] > 0:
            return f["fontsize"] * z
        if isinstance(w, _MultiLine):
            return 12.0 * z
        return max(5.0, min(12.0 * z, (w.height() - 3) * 0.74))

    def _apply_font(self, w, f, px, border):
        px = max(1, int(px))
        fnt = field_font(f["font"])
        fnt.setPixelSize(px)
        fam = ", ".join('"%s"' % x for x in fnt.families())
        w.setStyleSheet((FIELD_CSS % (border, px)) + " font-family: %s;" % fam)
        w.setFont(fnt)
        if isinstance(w, _MultiLine):
            w.document().setDefaultFont(fnt)
        return fnt

    def _doc_height(self, w, fnt, width):
        """Höhe, die der Text des mehrzeiligen Felds bei dieser Schrift und Breite wirklich braucht."""
        doc = w.document().clone()
        doc.setDocumentMargin(2)
        doc.setDefaultFont(fnt)
        doc.setTextWidth(max(20, width))
        h = doc.size().height()
        doc.deleteLater()
        return h

    def fit_field(self, w, f):
        """Schrift so wählen, dass der ganze Feldtext sichtbar ist.

        Felder mit automatischer Schriftgröße verkleinert auch das PDF selbst. Bei fester Schriftgröße
        schneidet das PDF den Text ab; das Eingabefeld zeigt ihn trotzdem ganz (verkleinert) und bekommt
        einen orangen Rand als Hinweis. Mehrzeilige Felder wachsen zusätzlich, solange man darin schreibt.
        """
        z = self.zoom
        multi = isinstance(w, _MultiLine)
        if multi and w.expanded:
            self.expand_field(w)
            return
        text = w.toPlainText() if multi else w.text()
        gw, gh = w.width(), w.height()
        fixed = f["fontsize"] > 0
        nominal = self._nominal(w, f)
        fnt = field_font(f["font"])
        floor = max(5.0, 4.0 * z)
        # Rand, den Rahmen und Stil des Systems wirklich verbrauchen
        if multi:
            vp = w.viewport()
            sane = gh - 30 <= vp.height() <= gh and gw - 60 <= vp.width() <= gw
            vh = vp.height() if sane else gh - 4
            vw = vp.width() if sane else gw - 4
            if sane and w.verticalScrollBar().isVisible():
                vw += w.verticalScrollBar().width()

        def fits(px):
            fnt.setPixelSize(max(1, int(px)))
            if multi:
                return self._doc_height(w, fnt, vw) <= vh
            fm = QFontMetricsF(fnt)
            return fm.horizontalAdvance(text) <= gw - 8 and fm.height() <= gh + 2
        px = nominal
        while px > floor and not fits(px):
            px -= max(0.5, px * 0.04)
        ok = fits(px)
        clipped = fixed and (px < nominal - 0.4 or not ok)
        w.blockSignals(True)
        self._apply_font(w, f, px, BORDER_CLIP if (clipped or not ok) else BORDER_OK)
        w.blockSignals(False)
        tip = f["name"]
        if clipped:
            tip += ("\nDer Text ist länger als das Feld. Hier wird er verkleinert ganz angezeigt; im PDF selbst "
                    "ist für dieses Feld eine feste Schriftgröße von %g pt vorgegeben, dort ist nur der Anfang "
                    "sichtbar." % f["fontsize"])
        elif not ok:
            tip += "\nDer Text passt auch verkleinert nicht ganz ins Feld. Beim Hineinklicken wird das Feld größer."
        if len(text) > 30:
            tip += "\n\n" + text
        w.setToolTip(tip)
        if multi:
            w.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff if ok
                                         else Qt.ScrollBarPolicy.ScrollBarAsNeeded)

    def expand_field(self, w):
        """Mehrzeiliges Feld beim Schreiben so groß machen, dass der ganze Text in lesbarer Schrift sichtbar ist."""
        if w.base is None or w.isReadOnly():
            return
        f = w.f
        z = self.zoom
        px = max(self._nominal(w, f) if f["fontsize"] > 0 else 10.0 * z, 8.0 * z)
        px = min(px, 14.0 * z)
        fnt = field_font(f["font"])
        fnt.setPixelSize(max(1, int(px)))
        extra = w.height() - w.viewport().height()
        if not 0 <= extra <= 30:
            extra = 4
        need = int(self._doc_height(w, fnt, w.base.width() - 6)) + extra + 4
        if not w.expanded and need <= w.base.height():
            return                                   # passt ohnehin: nichts tun, normale Anpassung genügt
        w.expanded = True
        w.blockSignals(True)
        self._apply_font(w, f, px, BORDER_OK)
        w.blockSignals(False)
        h = max(w.base.height(), need)
        y = w.base.y()
        ph = self.page.height()
        if y + h > ph:
            y = max(0, ph - h)
            h = min(h, ph)
        w.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded if h >= ph
                                     else Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        w.setGeometry(w.base.x(), y, w.base.width(), h)
        w.raise_()

    def collapse_field(self, w):
        if w.base is None:
            return
        try:
            w.expanded = False
            w.setGeometry(w.base)
            self.fit_field(w, w.f)
        except RuntimeError:
            pass

    def commit_fields(self):
        """Noch nicht übernommene Eingaben (Feld hat noch den Fokus) ins PDF schreiben."""
        for c in list(getattr(self, "field_commits", [])):
            c()

    def field_changed(self, xref, value, w):
        if value == w.property("pdf_value"):
            return
        try:
            self.ed.set_field(self.pno, xref, value)
        except Exception as e:
            self.fail(e)
            return
        try:
            w.setProperty("pdf_value", value)
            self.update_title()
        except RuntimeError:          # Fenster wird gerade geschlossen
            pass

    def button_changed(self, xref, on):
        try:
            self.ed.set_field(self.pno, xref, on)
        except Exception as e:
            self.fail(e)
        self.show_page()

    def refresh(self):
        self.fill_list()
        self.show_page()

    def set_zoom(self, z):
        self.zoom = max(0.4, min(4.0, z))
        self.show_page()

    def set_mode(self, mode):
        old = self.mode
        if (old == MODE_FIELDS) != (mode == MODE_FIELDS):
            self.commit_fields()
        self.mode = mode
        (self.a_view, self.a_edit, self.a_add, self.a_fmode)[mode].setChecked(True)
        for a in self._field_actions:
            a.setEnabled(mode == MODE_FIELDS)
        self.page.setCursor(Qt.CursorShape.ArrowCursor if mode in (MODE_VIEW, MODE_FIELDS) else
                            (Qt.CursorShape.IBeamCursor if mode == MODE_EDIT else Qt.CursorShape.CrossCursor))
        if (old == MODE_FIELDS) != (mode == MODE_FIELDS):
            self._sel_next = []
            self.show_page()
            if mode == MODE_FIELDS:
                n = self.ed.field_count()
                self.statusBar().showMessage(
                    "Feldmodus: Feld anklicken und ziehen; Griffe am Rand ändern die Größe; Umschalt+Klick markiert "
                    "mehrere; Pfeiltasten verschieben (Umschalt: 10 Punkte, Strg: Größe); Doppelklick: Maße und "
                    "Eigenschaften; Alt hält das Einrasten aus.", 15000)

    def fail(self, e):
        QMessageBox.warning(self, APP_NAME, str(e))

    # ---- Formularfelder bearbeiten (Feldmodus)
    def build_layer(self):
        try:
            fields = self.ed.fields(self.pno, all_kinds=True)
        except Exception:
            return
        self.layer = FieldLayer(self.page, self, fields, self.zoom, self.ed.page_size(self.pno))
        self.layer.show()
        self.layer.selection_changed.connect(self._sel_status)
        keep = [x for x in getattr(self, "_sel_next", []) if x in self.layer.rects]
        self._sel_next = []
        self.layer.set_selection(keep)
        self.layer.setFocus()
        if not fields:
            self.statusBar().showMessage("Auf dieser Seite gibt es keine Formularfelder. Über das Menü Formulare lassen "
                                         "sich neue anlegen.", 8000)

    def _sel_status(self):
        lay = getattr(self, "layer", None)
        if lay is None:
            return
        n = len(lay.sel)
        if n == 1:
            f = lay.fields[lay.sel[0]]
            x0, y0, x1, y1 = lay.rects[lay.sel[0]]
            self.statusBar().showMessage("%s: %s, Breite %.1f mm, Höhe %.1f mm, links %.1f mm, oben %.1f mm" % (
                {"text": "Textfeld", "check": "Ankreuzfeld", "radio": "Optionsknopf", "combo": "Auswahlfeld",
                 "list": "Liste", "button": "Schaltfläche", "signature": "Signaturfeld"}.get(f["kind"], "Feld"),
                f["name"], (x1 - x0) * MM, (y1 - y0) * MM, x0 * MM, y0 * MM))
        elif n > 1:
            self.statusBar().showMessage("%d Felder markiert (das zuerst markierte gibt bei gleicher Größe das Maß vor)." % n)

    def _layer(self):
        lay = getattr(self, "layer", None)
        if self.mode != MODE_FIELDS or lay is None:
            self.statusBar().showMessage("Zuerst den Feldmodus einschalten (Menü Formulare, Strg+Umschalt+E).", 5000)
            return None
        return lay

    def fields_tool(self, kind):
        if self.mode != MODE_FIELDS:
            self.set_mode(MODE_FIELDS)
        lay = self._layer()
        if lay is not None:
            lay.tool = kind
            lay.setCursor(Qt.CursorShape.CrossCursor)
            lay.setFocus()
            self.statusBar().showMessage("Auf der Seite ein Rechteck aufziehen (oder einmal klicken für die Standardgröße).", 8000)

    def fields_select_all(self):
        lay = self._layer()
        if lay is not None:
            lay.set_selection(list(lay.order))

    def fields_place(self, changes):
        """Lage und Größe ändern; changes: Liste (xref, Rechteck in Punkten)."""
        lay = self._layer()
        if lay is None:
            return
        sel = list(lay.sel)
        try:
            self.ed.place_fields(self.pno, changes)
        except Exception as e:
            self.fail(e)
        self._sel_next = sel
        self.show_page()

    def fields_create(self, kind, rect):
        try:
            xref = self.ed.add_field(self.pno, kind, rect)
        except Exception as e:
            self.fail(e)
            self._sel_next = []
            self.show_page()
            return
        self._sel_next = [xref]
        self.show_page()

    def fields_delete(self):
        lay = self._layer()
        if lay is None or not lay.sel:
            return
        n = len(lay.sel)
        try:
            self.ed.delete_fields(self.pno, list(lay.sel))
        except Exception as e:
            self.fail(e)
        self._sel_next = []
        self.show_page()
        self.statusBar().showMessage("%d Feld(er) gelöscht (Strg+Z macht es rückgängig)." % n, 6000)

    def fields_copy(self):
        lay = self._layer()
        if lay is None or not lay.sel:
            return
        new = []
        try:
            self.ed.snapshot()                       # alle Kopien sind zusammen ein Rückgängig-Schritt
            for xr in list(lay.sel):
                new.append(self.ed.copy_field(self.pno, xr, 14.0, 14.0, snap=False))
        except Exception as e:
            self.fail(e)
        self._sel_next = new
        self.show_page()

    def fields_align(self, op):
        lay = self._layer()
        if lay is None:
            return
        if len(lay.sel) < 2:
            self.statusBar().showMessage("Zum Ausrichten mindestens zwei Felder markieren (Umschalt+Klick).", 6000)
            return
        sel = list(lay.sel)
        rects = [lay.rects[x] for x in sel]
        if op in ("dist_h", "dist_v") and len(sel) < 3:
            self.statusBar().showMessage("Zum Verteilen mindestens drei Felder markieren.", 6000)
            return
        new = align_rects(rects, op)
        self.fields_place(list(zip(sel, new)))

    def fields_properties(self):
        lay = self._layer()
        if lay is None or not lay.sel:
            return
        sel = list(lay.sel)
        try:
            if len(sel) == 1:
                self._props_single(sel[0])
            else:
                self._props_multi(sel)
        except PdfError as e:
            self.fail(e)
            return
        self._sel_next = sel
        self.show_page()

    def _props_single(self, xref):
        pr = self.ed.field_props(self.pno, xref)
        pw, ph = self.ed.page_size(self.pno)
        dlg = QDialog(self)
        dlg.setWindowTitle("Eigenschaften des Felds")
        lay = QFormLayout(dlg)
        name = QLineEdit(pr["name"])
        name.setMinimumWidth(320)
        name.setEnabled(pr["rename_ok"])
        if not pr["rename_ok"]:
            name.setToolTip("Der Name gehört zu einer Gliederung des Formulars und bleibt unverändert.")
        lay.addRow("Name", name)

        def spin(v, hi):
            sp = QDoubleSpinBox()
            sp.setDecimals(1)
            sp.setRange(0.0, hi)
            sp.setSingleStep(0.5)
            sp.setSuffix(" mm")
            sp.setValue(v)
            return sp
        x0, y0, x1, y1 = pr["rect"]
        sx, sy = spin(x0 * MM, pw * MM), spin(y0 * MM, ph * MM)
        sw, sh = spin((x1 - x0) * MM, pw * MM), spin((y1 - y0) * MM, ph * MM)
        sw.setMinimum(1.1)
        sh.setMinimum(1.1)
        lay.addRow("Links (von der Seitenkante)", sx)
        lay.addRow("Oben (von der Seitenkante)", sy)
        lay.addRow("Breite", sw)
        lay.addRow("Höhe", sh)
        kind = pr["kind"]
        size = QDoubleSpinBox()
        size.setRange(0, 72)
        size.setDecimals(1)
        size.setSpecialValueText("automatisch")
        size.setValue(pr["fontsize"])
        align = QComboBox()
        align.addItems(["links", "mittig", "rechts"])
        align.setCurrentIndex(max(0, min(2, pr["align"])))
        text_like = kind in ("text", "combo", "list")
        if text_like:
            lay.addRow("Schriftgröße", size)
            lay.addRow("Ausrichtung", align)
        ro = QCheckBox("schreibgeschützt")
        ro.setChecked(pr["readonly"])
        lay.addRow("", ro)
        multi = QCheckBox("mehrzeilig")
        multi.setChecked(pr["multiline"])
        if kind == "text":
            lay.addRow("", multi)
        choices = QPlainTextEdit("\n".join(pr["choices"]))
        choices.setMinimumHeight(90)
        if kind in ("combo", "list"):
            lay.addRow("Auswahlwerte (einer je Zeile)", choices)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        lay.addRow(bb)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        props = {"readonly": ro.isChecked()}
        if pr["rename_ok"] and name.text().strip() and name.text().strip() != pr["name"]:
            props["name"] = name.text().strip()
        if text_like:
            props["fontsize"] = size.value()
            props["align"] = align.currentIndex()
        if kind == "text":
            props["multiline"] = multi.isChecked()
        if kind in ("combo", "list"):
            props["choices"] = [c for c in choices.toPlainText().split("\n") if c.strip()]
        nx0, ny0 = sx.value() / MM, sy.value() / MM
        rect = (nx0, ny0, nx0 + sw.value() / MM, ny0 + sh.value() / MM)
        self.ed.set_field_props(self.pno, xref, props, rect)

    def _props_multi(self, sel):
        dlg = QDialog(self)
        dlg.setWindowTitle("Eigenschaften von %d Feldern" % len(sel))
        lay = QFormLayout(dlg)
        size = QComboBox()
        size.addItems(["unverändert", "automatisch"] + ["%d" % n for n in (6, 7, 8, 9, 10, 11, 12, 14, 16, 18, 20, 24)])
        align = QComboBox()
        align.addItems(["unverändert", "links", "mittig", "rechts"])
        ro = QComboBox()
        ro.addItems(["unverändert", "schreibgeschützt", "nicht schreibgeschützt"])
        lay.addRow("Schriftgröße (Text- und Auswahlfelder)", size)
        lay.addRow("Ausrichtung (Text- und Auswahlfelder)", align)
        lay.addRow("Schutz", ro)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        lay.addRow(bb)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        props = {}
        if size.currentIndex() == 1:
            props["fontsize"] = 0.0
        elif size.currentIndex() > 1:
            props["fontsize"] = float(size.currentText())
        if align.currentIndex() > 0:
            props["align"] = align.currentIndex() - 1
        if ro.currentIndex() > 0:
            props["readonly"] = ro.currentIndex() == 1
        if not props:
            return
        self.ed.snapshot()
        for xr in sel:
            self.ed.set_field_props(self.pno, xr, props, snap=False)

    # ---- Text
    def on_click(self, px, py):
        if self.mode == MODE_VIEW:
            return
        x, y = px / self.zoom, py / self.zoom
        try:
            if self.mode == MODE_EDIT:
                line = self.ed.line_at(self.pno, x, y)
                if line is None:
                    self.statusBar().showMessage("An dieser Stelle steht kein Text (oder er ist ein Bild).", 5000)
                    return
                res = self.ask_line(line)
                if res is not None:
                    new, fmt = res
                    if new != line["text"] or fmt is not None:
                        self.ed.replace_line(self.pno, line, new, fmt)
                        self.show_page()
            else:
                res = self.ask_text()
                if res and res[0]:
                    text, fmt = res
                    self.size.setValue(max(5, min(72, int(round(fmt["size"])))))
                    self.ed.add_text(self.pno, x, y, text, fmt["size"], fmt["flags"], fmt["color"])
                    self.show_page()
        except PdfError as e:
            self.fail(e)

    def ask_line(self, line):
        """Dialog Zeile ändern: Text und Format. Liefert (Text, Format oder None, wenn das Format unverändert ist)
        oder None bei Abbruch."""
        dlg = QDialog(self)
        dlg.setWindowTitle("Zeile ändern")
        lay = QFormLayout(dlg)
        ed = QLineEdit(line["text"])
        ed.setMinimumWidth(560)
        lay.addRow("Text (leer löscht die Zeile):", ed)
        row = FormatRow(line["flags"], line["size"], line["color"])
        lay.addRow("Format:", row)
        note = QLabel("Der Text wird in einer der drei Standardschriften neu gesetzt (Liberation, sonst DejaVu). "
                      "Bleiben Schrift und Größe wie im Original, wird die Breite der Originalschrift angeglichen.")
        note.setWordWrap(True)
        note.setStyleSheet("color: gray;")
        lay.addRow(note)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        lay.addRow(bb)
        ed.setFocus()
        ed.selectAll()
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return None
        return ed.text(), (row.value() if row.changed() else None)

    def ask_text(self):
        """Dialog Text hinzufügen: (Text, Format) oder None."""
        dlg = QDialog(self)
        dlg.setWindowTitle("Text hinzufügen")
        lay = QFormLayout(dlg)
        ed = QPlainTextEdit()
        ed.setMinimumSize(420, 120)
        lay.addRow("Text:", ed)
        row = FormatRow(0, self.size.value(), 0)
        lay.addRow("Format:", row)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        lay.addRow(bb)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            return ed.toPlainText().strip("\n"), row.value()
        return None

    def replace(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("Suchen und ersetzen")
        lay = QFormLayout(dlg)
        a, b = QLineEdit(), QLineEdit()
        a.setMinimumWidth(360)
        lay.addRow("Suchen:", a)
        lay.addRow("Ersetzen durch:", b)
        lay.addRow(QLabel("Ersetzt wird im ganzen PDF, ohne Unterscheidung von Groß- und Kleinschreibung."))
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        lay.addRow(bb)
        if dlg.exec() != QDialog.DialogCode.Accepted or not a.text():
            return
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            n, skipped = self.ed.replace_all(a.text(), b.text())
        except PdfError as e:
            QApplication.restoreOverrideCursor()
            self.fail(e)
            return
        QApplication.restoreOverrideCursor()
        self.show_page()
        msg = "%d Stelle(n) ersetzt." % n
        if skipped:
            msg += " %d Stelle(n) übersprungen (gedrehte Seite oder nicht zuordenbar)." % skipped
        self.statusBar().showMessage(msg, 10000)

    def undo(self):
        if self.ed.undo_last():
            self.refresh()
        else:
            self.statusBar().showMessage("Nichts rückgängig zu machen.", 4000)

    # ---- Seiten
    def del_page(self):
        try:
            self.ed.delete_page(self.pno)
        except PdfError as e:
            return self.fail(e)
        self.refresh()

    def rot_page(self):
        self.ed.rotate_page(self.pno)
        self.show_page()

    def move(self, delta):
        self.pno = self.ed.move_page(self.pno, delta)
        self.refresh()

    def append(self):
        p, _ = QFileDialog.getOpenFileName(self, "PDF anhängen", os.path.dirname(self.ed.path), "PDF (*.pdf)")
        if not p:
            return
        try:
            self.ed.append_pdf(p)
        except PdfError as e:
            return self.fail(e)
        self.refresh()

    # ---- Datei
    def save(self):
        return self._save(self.ed.path)

    def save_as(self):
        p, _ = QFileDialog.getSaveFileName(self, "PDF speichern unter", self.ed.path, "PDF (*.pdf)")
        if not p:
            return False
        if not p.lower().endswith(".pdf"):
            p += ".pdf"
        return self._save(p)

    def _save(self, dest):
        self.commit_fields()
        try:
            self.ed.save(dest)
        except Exception as e:
            QMessageBox.warning(self, APP_NAME, "Das PDF konnte nicht gespeichert werden:\n%s" % e)
            return False
        self.update_title()
        self.statusBar().showMessage("Gespeichert: " + self.ed.path, 6000)
        return True

    def to_source(self):
        if self.main is not None:
            if self.ed.modified:
                QMessageBox.information(self, APP_NAME, "Geöffnet wird der zuletzt gespeicherte Stand der Datei.")
            self.main.open_pdf_source(self.ed.path)

    def to_latex(self):
        if self.main is not None:
            if self.ed.modified:
                QMessageBox.information(self, APP_NAME, "Ausgelesen wird der zuletzt gespeicherte Stand der Datei.")
            self.main.open_file(self.ed.path, convert=True, to_latex=True)
            self.main.raise_()
            self.main.activateWindow()

    def help(self):
        QMessageBox.information(self, APP_NAME, (
            "Ein PDF ist ein fertig gesetztes Blatt, kein Fließtext. Deshalb gilt:\n\n"
            "Text bearbeiten: Die angeklickte Zeile wird entfernt und an derselben Stelle neu gesetzt, in "
            "gleicher Größe und Farbe und einer möglichst ähnlichen Schrift (Liberation oder DejaVu). Wird die "
            "Zeile länger, läuft sie über den alten Rand hinaus; es wird nicht neu umbrochen.\n\n"
            "Format: Im Dialog Zeile ändern lassen sich Schriftart (Sans, Serif, Mono), Größe, fett, kursiv und "
            "Farbe der ganzen Zeile ändern, auch ohne den Text zu ändern. Die Vorbelegung wird aus dem Original "
            "gelesen. Die Originalschrift selbst wird nie benutzt; bei geänderter Schrift oder Größe wird die "
            "Breite nicht mehr an das Original angeglichen. Gemischte Formatierung innerhalb einer Zeile gibt es "
            "nicht.\n\n"
            "Suchen und ersetzen: wie oben, für alle Treffer im PDF.\n\n"
            "Text hinzufügen: an die angeklickte Stelle, mit Schrift, Größe, fett, kursiv und Farbe aus dem Dialog.\n\n"
            "Seiten: verschieben, drehen, löschen, weiteres PDF anhängen.\n\n"
            "Formulare: Ausfüllbare Felder des PDF erscheinen blau hinterlegt und lassen sich direkt ausfüllen "
            "(Textfelder, Ankreuzfelder, Optionsknöpfe, Auswahllisten). F8 blendet sie aus und ein.\n\n"
            "Formularfelder bearbeiten (Menü Formulare, Strg+Umschalt+E): Felder anklicken und ziehen, an den Griffen am "
            "Rand in der Größe ändern; Umschalt+Klick oder ein Rahmen markieren mehrere. Pfeiltasten verschieben um "
            "einen Punkt (mit Umschalt um zehn), mit Strg ändern sie die Größe. Beim Ziehen rasten die Kanten an "
            "anderen Feldern ein (Alt hält das aus). Doppelklick oder F2: genaue Maße in Millimetern, Name, "
            "Schriftgröße, Ausrichtung, Schreibschutz, Auswahlwerte. Strg+D kopiert, Entf löscht. Mehrere markierte "
            "Felder lassen sich ausrichten, gleich groß machen und gleichmäßig verteilen. Neue Textfelder, "
            "Ankreuzfelder und Auswahlfelder entstehen im Menü Formulare. Strg+Z macht jeden Schritt rückgängig.\n\n"
            "Nicht möglich: Text in gescannten Seiten (das sind Bilder), Absätze neu umbrechen, Bilder ändern. "
            "Für größere Änderungen den Text als LaTeX-Quelltext öffnen (Menü Datei) und ein neues PDF erzeugen.\n\n"
            "Beim ersten Speichern entsteht eine Sicherung mit der Endung .bak."))

    def closeEvent(self, e):
        self.commit_fields()
        if self.ed.modified:
            r = QMessageBox.question(self, APP_NAME, "Änderungen an %s speichern?" % os.path.basename(self.ed.path),
                                     QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard
                                     | QMessageBox.StandardButton.Cancel)
            if r == QMessageBox.StandardButton.Cancel or (r == QMessageBox.StandardButton.Save and not self.save()):
                e.ignore()
                return
        if self.main is not None and self in self.main.children_windows:
            self.main.children_windows.remove(self)
        e.accept()
