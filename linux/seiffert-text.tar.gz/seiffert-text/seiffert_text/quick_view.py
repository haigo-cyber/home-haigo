"""Ansicht „Schnellbearbeitung“: Zeilen einer LaTeX-Vorlage mit bearbeitbaren Textfeldern.

Übertragung der Oberfläche des Schnelleditors. Das Modell steht in quick.py, der Zustand je Dokument im
Hauptfenster (Attribute q_*). Die Vorschau ist das echte PDF aus dem LaTeX-Übersetzer."""
import os
import shutil

from PySide6.QtCore import QSize, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QFontDatabase, QIcon, QPixmap, QTextCursor
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QDialog, QDoubleSpinBox, QFileDialog, QFrame,
                               QGridLayout, QHBoxLayout, QLabel, QLineEdit, QMenu, QMessageBox, QPlainTextEdit,
                               QPushButton, QScrollArea, QSizePolicy, QSlider, QSplitter, QSpinBox, QTabWidget,
                               QTextEdit, QToolButton, QVBoxLayout, QWidget)

from . import quick as Q
from .highlight import LatexHighlighter

try:
    from PySide6.QtPdfWidgets import QPdfView
    HAVE_PDF = True
except Exception:   # pragma: no cover
    HAVE_PDF = False

TYPE_NAMES = {"thema": "Thema", "zeile": "Zeile", "aufgabe": "Aufgabe", "hinweis": "Hinweis"}
BAD_CSS = "border: 1px solid #d33; background-color: rgba(220, 50, 50, 40);"


def type_label(macro):
    import re
    k = re.sub("^lernplan", "", macro.lower())
    return TYPE_NAMES.get(k, k[:1].upper() + k[1:])


class Fld(QTextEdit):
    """Textfeld einer Zeile: wächst mit dem Text, Enter legt eine neue Zeile an, Umschalt+Enter setzt \\\\."""
    enterPressed = Signal()
    navigate = Signal(int)
    focusedIn = Signal()

    def __init__(self, text, wrap=True):
        super().__init__()
        self.setAcceptRichText(False)
        self.setTabChangesFocus(True)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setLineWrapMode(QTextEdit.LineWrapMode.WidgetWidth if wrap else QTextEdit.LineWrapMode.NoWrap)
        self.setPlainText(text)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.document().documentLayout().documentSizeChanged.connect(self._fit)
        self._fit()

    def _fit(self, *_):
        h = int(self.document().size().height()) + 2 * self.frameWidth() + 2
        self.setFixedHeight(max(h, self.fontMetrics().lineSpacing() + 12))

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._fit()

    def insertFromMimeData(self, src):
        if src.hasText():
            self.insertPlainText(" ".join(src.text().split("\n")).replace("\r", ""))

    def insert_break(self):
        c = self.textCursor()
        txt = self.toPlainText()
        nxt = txt[c.selectionEnd():c.selectionEnd() + 1]
        ins = "\\\\" + ("" if nxt == "" or nxt.isspace() else " ")
        c.insertText(ins)
        self.setTextCursor(c)

    def keyPressEvent(self, e):
        mods = e.modifiers()
        if e.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            if mods & Qt.KeyboardModifier.ShiftModifier and not mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.AltModifier):
                self.insert_break()
            elif not mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.AltModifier):
                self.enterPressed.emit()
            return
        if e.key() in (Qt.Key.Key_Up, Qt.Key.Key_Down) and not mods:
            before = self.textCursor().position()
            super().keyPressEvent(e)
            if self.textCursor().position() == before:
                self.navigate.emit(-1 if e.key() == Qt.Key.Key_Up else 1)
            return
        super().keyPressEvent(e)

    def focusInEvent(self, e):
        super().focusInEvent(e)
        self.focusedIn.emit()


class RawIn(Fld):
    """Eingabe der rohen LaTeX-Zeile; Enter übernimmt, Esc verwirft."""
    done = Signal(bool)

    def __init__(self, text):
        super().__init__(text, True)
        self._finished = False
        mono = QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont)
        self.setFont(mono)

    def keyPressEvent(self, e):
        if e.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            self.finish(True)
            return
        if e.key() == Qt.Key.Key_Escape:
            self.finish(False)
            return
        QTextEdit.keyPressEvent(self, e)

    def finish(self, apply):
        if self._finished:
            return
        self._finished = True
        self.done.emit(apply)

    def focusOutEvent(self, e):
        super().focusOutEvent(e)
        self.finish(True)


class QuickPage(QWidget):
    def __init__(self, main):
        super().__init__()
        self.m = main
        self.raw_edit = None
        self.focus_req = None
        self.last_fld = None
        self._building = False
        self._type_timer = QTimer(self)
        self._type_timer.setSingleShot(True)
        self._type_timer.setInterval(250)
        self._type_timer.timeout.connect(self.flush_typing)
        self._build()

    # ------------------------------------------------------------------ Aufbau
    def _build(self):
        m = self.m
        outer = QVBoxLayout(self)
        outer.setContentsMargins(6, 6, 6, 4)
        outer.setSpacing(4)
        # Zeile 1: Vorlage
        r1 = QHBoxLayout()
        r1.addWidget(QLabel("Vorlage"))
        self.cmb_tpl = QComboBox()
        self.cmb_tpl.setMinimumWidth(220)
        self.cmb_tpl.activated.connect(self.on_tpl_chosen)
        r1.addWidget(self.cmb_tpl)
        self.btn_load = QPushButton("Datei laden …")
        self.btn_load.setToolTip("Eine .tex-Vorlage laden. Die Datei selbst bleibt unverändert, gespeichert wird unter neuem Namen.")
        self.btn_load.clicked.connect(self.load_file)
        self.btn_upd = QPushButton("Vorlage aktualisieren")
        self.btn_upd.setToolTip("Speichert die bearbeitete Vorlage als neue, fortlaufend nummerierte Datei (Name01.tex, Name02.tex …). "
                                "Das Original bleibt unverändert.")
        self.btn_upd.clicked.connect(self.update_template)
        self.btn_keep = QPushButton("Vorlage merken")
        self.btn_keep.setToolTip("Die geladene Vorlage in die Liste übernehmen")
        self.btn_keep.clicked.connect(self.keep_template)
        self.btn_forget = QPushButton("Vergessen")
        self.btn_forget.setToolTip("Die gewählte gemerkte Vorlage aus der Liste entfernen")
        self.btn_forget.clicked.connect(self.forget_template)
        for b in (self.btn_load, self.btn_upd, self.btn_keep, self.btn_forget):
            r1.addWidget(b)
        r1.addStretch(1)
        outer.addLayout(r1)
        # Zeile 2: Dateiname, Schrift, Zielordner
        r2 = QHBoxLayout()
        r2.addWidget(QLabel("Dateiname"))
        self.ed_name = QLineEdit()
        self.ed_name.setPlaceholderText("z. B. Tim")
        self.ed_name.setMinimumWidth(200)
        self.ed_name.setToolTip("Name der .tex-Datei. Er erscheint auch im Seitenkopf, wenn die Vorlage \\jobname verwendet.")
        self.ed_name.textEdited.connect(self.on_name_edited)
        r2.addWidget(self.ed_name)
        r2.addWidget(QLabel(".tex"))
        self.grp_size = QWidget()
        sl = QHBoxLayout(self.grp_size)
        sl.setContentsMargins(8, 0, 0, 0)
        sl.addWidget(QLabel("Schrift"))
        self.sp_size = QSpinBox()
        self.sp_size.setRange(6, 96)
        self.sp_size.setSuffix(" pt")
        self.sp_size.setToolTip("Schriftgröße des Dateinamens oben rechts auf jeder Seite")
        self.sp_size.valueChanged.connect(self.on_size)
        sl.addWidget(self.sp_size)
        self.lbl_size = QLabel("")
        sl.addWidget(self.lbl_size)
        r2.addWidget(self.grp_size)
        r2.addSpacing(12)
        r2.addWidget(QLabel("Zielordner:"))
        self.lbl_out = QLabel("")
        f = self.lbl_out.font()
        f.setBold(True)
        self.lbl_out.setFont(f)
        r2.addWidget(self.lbl_out)
        self.btn_out = QPushButton("Ändern …")
        self.btn_out.setToolTip("Ordner, in den „Als .tex speichern“ und „Vorlage aktualisieren“ schreiben und in dem content und Bilder gesucht werden")
        self.btn_out.clicked.connect(self.choose_outdir)
        self.btn_outclr = QPushButton("✕")
        self.btn_outclr.setFixedWidth(28)
        self.btn_outclr.setToolTip("Zielordner zurücksetzen (Ordner der Datei beziehungsweise der Vorlage)")
        self.btn_outclr.clicked.connect(self.clear_outdir)
        r2.addWidget(self.btn_out)
        r2.addWidget(self.btn_outclr)
        r2.addStretch(1)
        outer.addLayout(r2)

        split = QSplitter()
        outer.addWidget(split, 1)
        # linke Seite: Bearbeiten
        left = QWidget()
        ll = QVBoxLayout(left)
        ll.setContentsMargins(0, 0, 0, 0)
        ll.setSpacing(3)
        hdr = QHBoxLayout()
        t = QLabel("Bearbeiten")
        tf = t.font()
        tf.setBold(True)
        t.setFont(tf)
        hdr.addWidget(t)
        s = m.settings
        self.chk_esc = QCheckBox("Sonderzeichen absichern (& % # _ $)")
        self.chk_esc.setChecked(s.get("quick_escape", True))
        self.chk_brk = QCheckBox("Automatischer Zeilenumbruch im PDF")
        self.chk_brk.setToolTip("Lange Texte in Boxen fester Breite brechen im PDF um, statt über den Rand zu laufen. Kurze Texte sehen aus wie vorher.")
        self.chk_brk.setChecked(s.get("quick_break", True))
        self.chk_cmd = QCheckBox("Befehlszeilen zeigen")
        self.chk_cmd.setChecked(bool(s.get("quick_cmd", False)))
        self.chk_wrap = QCheckBox("Anzeige umbrechen")
        self.chk_wrap.setToolTip("Nur die Anzeige hier: lange Texte umbrechen oder in einer Zeile lassen. Der Zeilenumbruch im PDF wird mit ↵ oder Umschalt+Enter gesetzt.")
        self.chk_wrap.setChecked(s.get("quick_wrap", True))
        self.chk_esc.toggled.connect(self.on_opts)
        self.chk_brk.toggled.connect(self.on_opts)
        self.chk_cmd.toggled.connect(self.on_opts)
        self.chk_wrap.toggled.connect(self.on_opts)
        for c in (self.chk_esc, self.chk_brk, self.chk_cmd, self.chk_wrap):
            hdr.addWidget(c)
        hdr.addStretch(1)
        ll.addLayout(hdr)
        hdr2 = QHBoxLayout()
        self.btn_coll = QPushButton("Themen einklappen")
        self.btn_exp = QPushButton("Alle aufklappen")
        self.btn_coll.clicked.connect(self.collapse_all)
        self.btn_exp.clicked.connect(self.expand_all)
        hdr2.addWidget(self.btn_coll)
        hdr2.addWidget(self.btn_exp)
        hdr2.addStretch(1)
        self.theme_bar = QWidget()
        self.theme_bar.setLayout(hdr2)
        hdr2.setContentsMargins(0, 0, 0, 0)
        ll.addWidget(self.theme_bar)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.StyledPanel)
        self.host = QWidget()
        self.vl = QVBoxLayout(self.host)
        self.vl.setContentsMargins(4, 4, 4, 4)
        self.vl.setSpacing(2)
        self.vl.addStretch(1)
        self.scroll.setWidget(self.host)
        ll.addWidget(self.scroll, 1)
        hint = QLabel("Enter in einem Feld legt darunter eine neue Zeile an. Umschalt+Enter (oder ↵) setzt einen Zeilenumbruch in den Text, "
                      "im PDF beginnt dort eine neue Zeile. Pfeil hoch und runter wechselt die Zeile. Alle Änderungen lassen sich mit Rückgängig zurückholen.")
        hint.setWordWrap(True)
        hint.setStyleSheet("color: palette(mid);")
        ll.addWidget(hint)
        self.lbl_warn = QLabel("")
        self.lbl_warn.setWordWrap(True)
        self.lbl_warn.setStyleSheet("color: #d33;")
        ll.addWidget(self.lbl_warn)
        split.addWidget(left)
        # rechte Seite: Vorschau (PDF), Quelltext, Meldungen
        right = QWidget()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(0, 0, 0, 0)
        rl.setSpacing(3)
        bar = QHBoxLayout()
        self.btn_compile = QPushButton("Übersetzen (F5)")
        self.btn_compile.clicked.connect(lambda: self.m.compile())
        self.cmb_engine = QComboBox()
        self.cmb_engine.addItems(["pdflatex", "xelatex", "lualatex"])
        self.cmb_engine.setCurrentText(m.cmb_engine.currentText())
        self.cmb_engine.currentTextChanged.connect(lambda x: m.cmb_engine.setCurrentText(x))
        self.chk_auto = QCheckBox("Automatisch")
        self.chk_auto.setToolTip("Nach einer Schreibpause automatisch übersetzen")
        self.chk_auto.setChecked(m.chk_auto.isChecked())
        self.chk_auto.toggled.connect(lambda v: m.chk_auto.setChecked(v))
        m.chk_auto.toggled.connect(lambda v: self.chk_auto.setChecked(v))
        self.lbl_status = QLabel("")
        self.btn_pdf = QPushButton("PDF speichern …")
        self.btn_pdf.setToolTip("Das zuletzt übersetzte PDF unter einem Namen speichern")
        self.btn_pdf.clicked.connect(self.save_pdf)
        for w in (self.btn_compile, self.cmb_engine, self.chk_auto):
            bar.addWidget(w)
        bar.addWidget(self.lbl_status, 1)
        bar.addWidget(self.btn_pdf)
        rl.addLayout(bar)
        self.tabs = QTabWidget()
        if HAVE_PDF and m.pdf_doc is not None:
            self.pdf_view = QPdfView()
            self.pdf_view.setDocument(m.pdf_doc)
            from PySide6.QtPdfWidgets import QPdfView as _V
            self.pdf_view.setPageMode(_V.PageMode.MultiPage)
            self.pdf_view.setZoomMode(_V.ZoomMode.FitToWidth)
            self.tabs.addTab(self.pdf_view, "Vorschau (PDF)")
        else:
            self.pdf_view = None
            self.tabs.addTab(QLabel("Die PDF-Anzeige ist nicht verfügbar."), "Vorschau (PDF)")
        self.src = QPlainTextEdit()
        self.src.setReadOnly(True)
        self.src.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        self.src.setFont(QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont))
        dark = self.palette().window().color().lightness() < 128
        self.src_hl = LatexHighlighter(self.src.document(), dark)
        self.tabs.addTab(self.src, "LaTeX-Quelltext")
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setPlaceholderText("Meldungen des Übersetzers")
        self.log.mouseDoubleClickEvent = self._log_dbl
        self.tabs.addTab(self.log, "Meldungen")
        rl.addWidget(self.tabs, 1)
        split.addWidget(right)
        split.setSizes([620, 560])
        # Fuß
        foot = QHBoxLayout()
        self.btn_undo = QPushButton("↶ Rückgängig")
        self.btn_redo = QPushButton("↷ Wiederholen")
        self.btn_reset = QPushButton("Zurücksetzen")
        self.btn_reset.setToolTip("Zurück zur Vorlage, wie sie geladen wurde")
        self.btn_undo.clicked.connect(self.do_undo)
        self.btn_redo.clicked.connect(self.do_redo)
        self.btn_reset.clicked.connect(self.reset)
        for b in (self.btn_undo, self.btn_redo, self.btn_reset):
            foot.addWidget(b)
        self.lbl_remind = QLabel("")
        self.lbl_remind.setWordWrap(True)
        foot.addWidget(self.lbl_remind, 1)
        self.btn_copy = QPushButton("LaTeX kopieren")
        self.btn_copy.clicked.connect(self.copy_latex)
        self.btn_save = QPushButton("Als .tex speichern")
        self.btn_save.setDefault(False)
        f = self.btn_save.font()
        f.setBold(True)
        self.btn_save.setFont(f)
        self.btn_save.clicked.connect(self.save_tex)
        foot.addWidget(self.btn_copy)
        foot.addWidget(self.btn_save)
        outer.addLayout(foot)

    # ------------------------------------------------------------------ Optionen und Hilfen
    @property
    def opts(self):
        return {"autoEscape": self.chk_esc.isChecked(), "autoBreak": self.chk_brk.isChecked()}

    def wrap(self):
        return self.chk_wrap.isChecked()

    def on_opts(self, *_):
        s = self.m.settings
        s["quick_escape"] = self.chk_esc.isChecked()
        s["quick_break"] = self.chk_brk.isChecked()
        s["quick_cmd"] = self.chk_cmd.isChecked()
        s["quick_wrap"] = self.chk_wrap.isChecked()
        if self.m.q_doc is None:
            return
        self.commit_if_changed()
        self.apply_model()
        self.render_editor()

    def is_visible(self, u):
        return (not u.get("fixed")) and (self.chk_cmd.isChecked() or Q.has_fields(u) or bool(u.get("img"))
                                         or self.raw_edit == u["id"])

    def idx_of(self, id_):
        for i, u in enumerate(self.m.q_doc["units"]):
            if u["id"] == id_:
                return i
        return -1

    # ------------------------------------------------------------------ Rückgängig
    def commit(self):
        m = self.m
        m.q_undo.append(m.q_last)
        if len(m.q_undo) > 200:
            m.q_undo.pop(0)
        m.q_last = Q.snap(m.q_doc)
        m.q_redo = []
        self.update_buttons()

    def commit_if_changed(self):
        if self.m.q_doc is not None and Q.snap(self.m.q_doc) != self.m.q_last:
            self.commit()

    def do_undo(self):
        m = self.m
        if m.q_doc is None:
            return
        self.flush_typing()
        self.commit_if_changed()
        if not m.q_undo:
            return
        m.q_redo.append(Q.snap(m.q_doc))
        Q.restore(m.q_doc, m.q_undo.pop())
        m.q_last = Q.snap(m.q_doc)
        self.raw_edit = None
        self.changed(render=True)

    def do_redo(self):
        m = self.m
        if m.q_doc is None or not m.q_redo:
            return
        m.q_undo.append(Q.snap(m.q_doc))
        Q.restore(m.q_doc, m.q_redo.pop())
        m.q_last = Q.snap(m.q_doc)
        self.raw_edit = None
        self.changed(render=True)

    def update_buttons(self):
        self.btn_undo.setEnabled(bool(self.m.q_undo))
        self.btn_redo.setEnabled(bool(self.m.q_redo))

    def changed(self, render=True, focus=None):
        """Nach einer Änderung des Modells: Text im Hauptfenster erneuern, Anzeige aufbauen."""
        if focus is not None:
            self.focus_req = focus
        self.apply_model()
        if render:
            self.render_editor()
        self.update_buttons()

    def flush_typing(self):
        self._type_timer.stop()
        if self.m.q_doc is None:
            return
        self.apply_model()

    def apply_model(self):
        m = self.m
        if m.q_doc is None:
            return
        text = Q.serialize(m.q_doc, self.opts)
        m.tex_eol = m.q_doc["eol"]
        if text != m.tex_edit.toPlainText():
            m.tex_edit.setPlainText(text)
        m.q_text_sig = text
        self.src.setPlainText(text)
        self.render_warnings()
        self.render_reminder()

    # ------------------------------------------------------------------ Zustand beim Betreten
    def prepare(self):
        """Modell aus dem LaTeX-Text des Dokuments aufbauen (falls nötig). False, wenn das nicht geht."""
        m = self.m
        text = m.tex_edit.toPlainText()
        if m.q_doc is not None and m.q_text_sig == text:
            return True
        try:
            doc = Q.parse_tex(text)
        except Q.TexError as e:
            QMessageBox.information(m, "Schnellbearbeitung", str(e))
            return False
        doc["eol"] = m.tex_eol
        m.q_doc = doc
        m.q_undo, m.q_redo = [], []
        m.q_last = Q.snap(doc)
        m.q_collapsed = set()
        m.q_text_sig = text
        m.q_original = text
        m.q_headnames = [f["name"] for f in Q.head_fields(doc["head"])]
        if not m.q_tpl:
            m.q_tpl = os.path.splitext(os.path.basename(m.path))[0] if m.path else "Dokument"
        if m.q_name_auto and m.path:
            m.q_name = os.path.splitext(os.path.basename(m.path))[0]
        return True

    def show_view(self):
        """Beim Wechsel in diese Ansicht und beim Wechsel des Tabs."""
        self.ed_name.setText(self.m.q_name)
        self.update_size_box()
        self.update_out_ui()
        self.fill_tpl_combo()
        self.src.setPlainText(Q.serialize(self.m.q_doc, self.opts) if self.m.q_doc else "")
        self.render_editor()
        self.render_warnings()
        self.render_reminder()
        self.update_buttons()
        self.sync_compile()

    # ------------------------------------------------------------------ Zeilen aufbauen
    def clear_rows(self):
        while self.vl.count() > 1:
            it = self.vl.takeAt(0)
            w = it.widget()
            if w is not None:
                w.hide()
                w.setParent(None)
                w.deleteLater()

    def render_editor(self):
        m = self.m
        if m.q_doc is None:
            return
        bar = self.scroll.verticalScrollBar().value()
        self._building = True
        self.clear_rows()
        doc = m.q_doc
        self.theme = Q.theme_macro(doc)
        self.blocks = Q.blocks_of(doc, self.theme)
        head_of = {}
        hidden = set()
        for b in self.blocks:
            head_of[b["start"]] = b
            if b["id"] in m.q_collapsed:
                hidden.update(range(b["start"] + 1, b["end"]))
        self.theme_bar.setVisible(bool(self.blocks))
        hd = self.make_head_data()
        pos = 0
        if hd is not None:
            self.vl.insertWidget(pos, hd)
            pos += 1
        prev_sig = None
        count = 0
        for ui, u in enumerate(doc["units"]):
            if not self.is_visible(u) or ui in hidden:
                continue
            count += 1
            blk = head_of.get(ui)
            sig = "".join("\x01" if s["k"] == "x" else s["v"] for s in u["segs"])
            gap = prev_sig is not None and (sig != prev_sig or blk is not None)
            prev_sig = sig
            in_blk = bool(self.theme) and not blk and any(ui > b["start"] and ui < b["end"] for b in self.blocks)
            row = self.make_row(u, blk, gap, in_blk)
            self.vl.insertWidget(pos, row)
            pos += 1
        if not count:
            lab = QLabel("In dieser Vorlage wurden keine Textstellen gefunden. Mit „Befehlszeilen zeigen“ siehst du alle Zeilen "
                         "und kannst sie über </> direkt bearbeiten.")
            lab.setWordWrap(True)
            self.vl.insertWidget(pos, lab)
        self._building = False
        QTimer.singleShot(0, lambda: self.scroll.verticalScrollBar().setValue(bar))
        if self.focus_req is not None:
            f, self.focus_req = self.focus_req, None
            QTimer.singleShot(0, lambda f=f: self.focus_field(*f))

    def focus_field(self, id_, fi=0, img=False):
        row = self.host.findChild(QWidget, "row%d" % id_)
        if row is None:
            return
        if img:
            sp = row.findChild(QDoubleSpinBox)
            if sp:
                sp.setFocus()
                sp.selectAll()
            return
        flds = [w for w in row.findChildren(Fld)]
        if not flds:
            return
        w = flds[min(fi, len(flds) - 1)]
        w.setFocus()
        c = w.textCursor()
        c.movePosition(QTextCursor.MoveOperation.End)
        w.setTextCursor(c)
        self.scroll.ensureWidgetVisible(w)

    def make_row(self, u, blk, gap, in_blk):
        row = QFrame()
        row.setObjectName("row%d" % u["id"])
        lay = QHBoxLayout(row)
        lay.setContentsMargins(18 if in_blk else 2, 8 if gap else 1, 2, 1)
        lay.setSpacing(4)
        if blk is not None:
            row.setStyleSheet("QFrame#row%d { background-color: palette(alternate-base); border-radius: 3px; }" % u["id"])
            col = blk["id"] in self.m.q_collapsed
            tg = QToolButton()
            tg.setText("▸" if col else "▾")
            tg.setAutoRaise(True)
            tg.setToolTip("Thema aufklappen" if col else "Thema einklappen")
            tg.clicked.connect(lambda _=False, b=blk: self.toggle_block(b))
            lay.addWidget(tg)
        cnt = QHBoxLayout()
        cnt.setSpacing(4)
        cnt.setContentsMargins(0, 0, 0, 0)
        if self.raw_edit == u["id"]:
            raw = Q.raw_of_unit(u)
            inp = RawIn(raw)
            inp.done.connect(lambda apply, u=u, raw=raw, inp=inp: self.finish_raw(u, raw, inp, apply))
            cnt.addWidget(inp, 1)
            QTimer.singleShot(0, inp.setFocus)
        elif u.get("img"):
            cnt.addWidget(self.make_img_row(u), 1)
        elif Q.has_fields(u):
            acc = ""
            fi = 0
            first = True
            flds = []
            for sg in u["segs"]:
                if sg["k"] == "s":
                    acc += sg["v"]
                    continue
                if acc.strip():
                    cnt.addWidget(self.chip(acc, "lead" if first else "mid"), 0, Qt.AlignmentFlag.AlignTop)
                acc = ""
                first = False
                f = self.make_field(u, sg, fi)
                flds.append(f)
                cnt.addWidget(f, 1, Qt.AlignmentFlag.AlignTop)
                fi += 1
            if acc.strip():
                cnt.addWidget(self.chip(acc, "end"), 0, Qt.AlignmentFlag.AlignTop)
            if blk is not None and len(flds) == 3:
                for f, ph in zip(flds, ("Nummer", "Thema", "Zeit")):
                    f.setPlaceholderText(ph)
        else:
            raw = Q.raw_of_unit(u)
            txt = "(leere Zeile)" if raw.strip() == "" else (raw[:90] + "…" if len(raw) > 90 else raw)
            cnt.addWidget(self.chip(txt, None, mono=True, full=raw), 1)
        lay.addLayout(cnt, 1)
        if blk is not None:
            n = blk["end"] - blk["start"] - 1
            lbl = QLabel("%d %s" % (n, "Zeile" if n == 1 else "Zeilen"))
            lbl.setStyleSheet("color: palette(mid);")
            lay.addWidget(lbl)
            if self.raw_edit != u["id"]:
                lay.addWidget(self.block_actions(u, blk))
        else:
            lay.addWidget(self.row_actions(u))
        return row

    def chip(self, s, mode, mono=False, full=None):
        import re
        s2 = re.sub(r"\s+", " ", s).strip() if not mono else s
        if not self.wrap() and mode and len(s2) > 26:
            s2 = ("…" + s2[-26:]) if mode == "lead" else (s2[:26] + "…" if mode == "end" else s2[:12] + "…" + s2[-12:])
        lab = QLabel(s2)
        lab.setToolTip(full if full is not None else s)
        lab.setStyleSheet("QLabel { background-color: palette(alternate-base); border: 1px solid palette(mid); "
                          "border-radius: 3px; padding: 1px 4px; color: palette(text); }")
        if mono:
            lab.setFont(QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont))
            lab.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        else:
            lab.setSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)
            lab.setMaximumWidth(380)
        return lab

    def make_field(self, u, sg, fi):
        f = Fld(sg["v"], self.wrap())
        f.setStyleSheet("")
        self.mark_field(f, sg)
        f.setMinimumWidth(90)
        f.textChanged.connect(lambda f=f, sg=sg: self.on_field_changed(f, sg))
        f.enterPressed.connect(lambda u=u, fi=fi: self.enter_below(u, fi))
        f.navigate.connect(lambda d, f=f, fi=fi: self.move_focus(f, d, fi))
        f.focusedIn.connect(lambda f=f: setattr(self, "last_fld", f))
        return f

    def mark_field(self, f, sg):
        bad = Q.brace_delta(Q.seg_out(sg, self.opts)) != 0
        f.setStyleSheet(BAD_CSS if bad else "")

    def on_field_changed(self, f, sg):
        if self._building:
            return
        sg["v"] = f.toPlainText()
        sg["edited"] = True
        self.mark_field(f, sg)
        self._type_timer.start()

    def enter_below(self, u, fi):
        self.flush_typing()
        self.commit_if_changed()
        nu = Q.op_insert_below(self.m.q_doc, self.idx_of(u["id"]))
        self.commit()
        self.changed(focus=(nu["id"], fi))

    def move_focus(self, f, d, fi):
        row = f.parent()
        while row is not None and not (row.objectName() or "").startswith("row"):
            row = row.parent()
        if row is None:
            return
        rows = [self.vl.itemAt(i).widget() for i in range(self.vl.count() - 1)]
        rows = [r for r in rows if r is not None]
        if row not in rows:
            return
        i = rows.index(row) + d
        while 0 <= i < len(rows):
            flds = rows[i].findChildren(Fld)
            if flds:
                w = flds[min(fi, len(flds) - 1)]
                w.setFocus()
                c = w.textCursor()
                c.movePosition(QTextCursor.MoveOperation.End)
                w.setTextCursor(c)
                self.scroll.ensureWidgetVisible(w)
                return
            i += d

    # ------------------------------------------------------------------ Knöpfe einer Zeile
    def _btn(self, label, tip, fn):
        b = QToolButton()
        b.setText(label)
        b.setToolTip(tip)
        b.setAutoRaise(True)
        b.clicked.connect(lambda _=False: fn())
        return b

    def _run(self, fn):
        def go():
            self.flush_typing()
            self.commit_if_changed()
            fn()
        return go

    def row_actions(self, u):
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(0)
        doc = self.m.q_doc
        idx = lambda: self.idx_of(u["id"])

        def mv(d):
            if Q.op_move_relative(doc, idx(), d, self.is_visible):
                self.commit()
                self.changed(focus=(u["id"], 0))
        h.addWidget(self._btn("▲", "Eine Zeile nach oben", self._run(lambda: mv(-1))))
        h.addWidget(self._btn("▼", "Eine Zeile nach unten", self._run(lambda: mv(1))))

        def plus():
            if len(Q.line_types(doc)) > 1:
                self.type_menu(self.sender_widget(h, 2), u, False)
                return
            nu = Q.op_insert_below(doc, idx())
            self.commit()
            self.changed(focus=(nu["id"], 0))
        h.addWidget(self._btn("＋", "Leere Zeile darunter einfügen (bei mehreren Zeilenarten: Art wählen)", self._run(plus)))
        h.addWidget(self._btn("▣", "Grafik aus dem Ordner content darunter einfügen", self._run(lambda: self.image_dialog(u))))
        if Q.has_fields(u):
            h.addWidget(self._btn("☐", "Kontrollkästchen in den Text einfügen (an der Cursorstelle im Feld)",
                                  lambda: self.insert_box(False, u)))
            h.addWidget(self._btn("↵", "Zeilenumbruch im Text einfügen (Umschalt+Enter). Im PDF beginnt dort eine neue Zeile.",
                                  lambda: self.break_in_row(u)))
            h.addWidget(self._btn("≡＋", "Mehrere Zeilen darunter einfügen (eine pro Zeile, auch aus Excel)",
                                  self._run(lambda: self.bulk_dialog(u))))

        def dup():
            c = Q.op_duplicate(doc, idx())
            self.commit()
            self.changed(focus=(c["id"], 0))
        h.addWidget(self._btn("⧉", "Zeile duplizieren", self._run(dup)))
        h.addWidget(self._btn("</>", "LaTeX dieser Zeile direkt bearbeiten", self._run(lambda: self.start_raw(u))))

        def rm():
            Q.op_remove(doc, idx())
            self.commit()
            self.changed()
        h.addWidget(self._btn("✕", "Zeile löschen", self._run(rm)))
        return w

    def sender_widget(self, h, i):
        return h.itemAt(i).widget()

    def block_actions(self, u, b):
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(0)
        doc = self.m.q_doc

        def mv(d):
            if Q.op_block_move(doc, self.theme, u["id"], d):
                self.commit()
                self.changed(focus=(u["id"], 0))
        h.addWidget(self._btn("▲", "Ganzes Thema mit allen Zeilen nach oben", self._run(lambda: mv(-1))))
        h.addWidget(self._btn("▼", "Ganzes Thema mit allen Zeilen nach unten", self._run(lambda: mv(1))))
        h.addWidget(self._btn("＋", "Zeile in diesem Thema oder neues Thema einfügen",
                              self._run(lambda: self.type_menu(h.itemAt(2).widget(), u, True))))
        h.addWidget(self._btn("↵", "Zeilenumbruch im Text einfügen (Umschalt+Enter)", lambda: self.break_in_row(u)))
        h.addWidget(self._btn("▣", "Grafik unter der Themenzeile einfügen", self._run(lambda: self.image_dialog(u))))

        def dup():
            c = Q.op_block_duplicate(doc, self.theme, u["id"])
            if c:
                self.commit()
                self.changed(focus=(c["id"], 0))
        h.addWidget(self._btn("⧉", "Ganzes Thema mit allen Zeilen duplizieren", self._run(dup)))
        h.addWidget(self._btn("</>", "LaTeX der Themenzeile direkt bearbeiten", self._run(lambda: self.start_raw(u))))

        def rm():
            n = b["end"] - b["start"]
            if n > 1 and QMessageBox.question(
                    self.m, "Thema löschen", "Dieses Thema mit allen %d Zeilen löschen? (Mit Rückgängig holst du es zurück.)" % n
            ) != QMessageBox.StandardButton.Yes:
                return
            Q.op_block_remove(doc, self.theme, u["id"])
            self.commit()
            self.changed()
        h.addWidget(self._btn("✕", "Ganzes Thema mit allen Zeilen löschen", self._run(rm)))
        return w

    def type_menu(self, anchor, u, is_block_head):
        doc = self.m.q_doc
        types = Q.line_types(doc)
        menu = QMenu(self)
        menu.addSection("Einfügen" if is_block_head else "Darunter einfügen")
        for t in types:
            if is_block_head and t["macro"] == self.theme:
                a = menu.addAction("Neues Thema (nach diesem Block)  –  %d Felder" % t["fields"])
                a.triggered.connect(lambda _=False, t=t: self._ins_theme(u, t))
            else:
                a = menu.addAction("%s  –  %d %s" % (type_label(t["macro"]), t["fields"], "Feld" if t["fields"] == 1 else "Felder"))
                a.triggered.connect(lambda _=False, t=t: self._ins_type(u, t))
        a = menu.addAction("Grafik aus content …")
        a.triggered.connect(lambda: self.image_dialog(u))
        if Q.has_fields(u) and not is_block_head:
            a = menu.addAction("Gleiche Art wie diese Zeile")
            a.triggered.connect(lambda: self._ins_same(u))
        menu.exec(anchor.mapToGlobal(anchor.rect().bottomLeft()))

    def _ins_theme(self, u, t):
        self.commit_if_changed()
        nu = Q.op_insert_type_after_block(self.m.q_doc, self.theme, u["id"], t["unit"])
        self.commit()
        self.changed(focus=(nu["id"], 0))

    def _ins_type(self, u, t):
        self.commit_if_changed()
        nu = Q.op_insert_type(self.m.q_doc, self.idx_of(u["id"]), t["unit"])
        self.commit()
        self.changed(focus=(nu["id"], 0))

    def _ins_same(self, u):
        self.commit_if_changed()
        nu = Q.op_insert_below(self.m.q_doc, self.idx_of(u["id"]))
        self.commit()
        self.changed(focus=(nu["id"], 0))

    def break_in_row(self, u):
        row = self.host.findChild(QWidget, "row%d" % u["id"])
        if row is None:
            return
        flds = row.findChildren(Fld)
        if not flds:
            return
        f = self.last_fld if self.last_fld in flds else flds[0]
        f.setFocus()
        if f is not self.last_fld:
            c = f.textCursor()
            c.movePosition(QTextCursor.MoveOperation.End)
            f.setTextCursor(c)
        f.insert_break()
        self.flush_typing()
        self.commit_if_changed()

    def insert_box(self, checked=False, u=None):
        """Kontrollkästchen als \\(\\square\\) an die Cursorstelle des zuletzt benutzten Felds (der Zeile u) setzen."""
        flds = []
        if u is not None:
            row = self.host.findChild(QWidget, "row%d" % u["id"])
            flds = row.findChildren(Fld) if row else []
        f = self.last_fld if (self.last_fld is not None and (u is None or self.last_fld in flds)) else (flds[0] if flds else None)
        if f is None:
            self.m.status.showMessage("Zuerst in ein Textfeld klicken, dann das Kontrollkästchen einfügen.", 6000)
            return
        try:
            f.objectName()
        except RuntimeError:
            self.m.status.showMessage("Zuerst in ein Textfeld klicken, dann das Kontrollkästchen einfügen.", 6000)
            return
        f.setFocus()
        f.textCursor().insertText("\\(\\boxtimes\\) " if checked else "\\(\\square\\) ")
        self.flush_typing()
        self.commit_if_changed()

    def start_raw(self, u):
        self.raw_edit = u["id"]
        self.render_editor()

    def finish_raw(self, u, raw, inp, apply):
        if self.raw_edit != u["id"]:
            return
        val = " ".join(inp.toPlainText().splitlines())
        self.raw_edit = None
        if apply and val != raw:
            Q.op_set_raw(self.m.q_doc, self.idx_of(u["id"]), val)
            self.commit()
            self.changed()
        else:
            QTimer.singleShot(0, self.render_editor)

    def toggle_block(self, b):
        c = self.m.q_collapsed
        if b["id"] in c:
            c.discard(b["id"])
        else:
            c.add(b["id"])
        self.render_editor()

    def collapse_all(self):
        for b in self.blocks:
            self.m.q_collapsed.add(b["id"])
        self.render_editor()

    def expand_all(self):
        self.m.q_collapsed = set()
        self.render_editor()

    # ------------------------------------------------------------------ Mehrere Zeilen
    def bulk_dialog(self, u):
        d = QDialog(self.m)
        d.setWindowTitle("Mehrere Zeilen einfügen")
        lay = QVBoxLayout(d)
        lab = QLabel("Eine Zeile pro Eintrag. Hat die Zeile mehrere Textfelder, trennst du sie mit Tabulator (so kommt es aus Excel oder "
                     "Tabellen). Die neuen Zeilen entstehen unter der gewählten Zeile.")
        lab.setWordWrap(True)
        lay.addWidget(lab)
        ed = QPlainTextEdit()
        ed.setPlaceholderText("M6c 0602 R004AB\nM6c 0602 R004LZA")
        lay.addWidget(ed)
        row = QHBoxLayout()
        row.addStretch(1)
        c = QPushButton("Abbrechen")
        ok = QPushButton("Einfügen")
        c.clicked.connect(d.reject)
        ok.clicked.connect(d.accept)
        row.addWidget(c)
        row.addWidget(ok)
        lay.addLayout(row)
        d.resize(520, 360)
        if d.exec() != QDialog.DialogCode.Accepted or not ed.toPlainText().strip():
            return
        made = Q.op_bulk(self.m.q_doc, self.idx_of(u["id"]), ed.toPlainText())
        if made:
            self.commit()
            self.changed(focus=(made[-1]["id"], 0))
            self.m.status.showMessage("%d Zeilen eingefügt." % len(made), 5000)

    # ------------------------------------------------------------------ Kopfdaten
    def make_head_data(self):
        m = self.m
        fl = Q.head_fields(m.q_doc["head"], m.q_headnames or [])
        if not fl:
            return None
        box = QFrame()
        box.setFrameShape(QFrame.Shape.StyledPanel)
        g = QVBoxLayout(box)
        g.setContentsMargins(6, 4, 6, 4)
        g.setSpacing(2)
        t = QLabel("Kopfdaten (stehen oben in der Datei, zum Beispiel im Seitenkopf)")
        f = t.font()
        f.setBold(True)
        t.setFont(f)
        g.addWidget(t)
        for fd in fl:
            row = QHBoxLayout()
            lab = QLabel("\\" + fd["name"])
            lab.setStyleSheet("QLabel { background-color: palette(alternate-base); border: 1px solid palette(mid); border-radius: 3px; padding: 1px 4px; }")
            lab.setFixedWidth(120)
            row.addWidget(lab)
            ed = QLineEdit(fd["value"])
            if fd["name"] == "Untertitel":
                ed.setPlaceholderText("Untertitel (darf leer bleiben)")
            ed.textEdited.connect(lambda v, ed=ed, name=fd["name"]: self.on_head_edit(ed, name, v))
            ed.editingFinished.connect(self.commit_if_changed)
            row.addWidget(ed, 1)
            g.addLayout(row)
        return box

    def on_head_edit(self, ed, name, v):
        if Q.brace_delta(v) != 0:
            ed.setStyleSheet(BAD_CSS)
            ed.setToolTip("Geschweifte Klammern sind nicht ausgeglichen. Der Wert wird so nicht übernommen.")
            return
        ed.setStyleSheet("")
        ed.setToolTip("")
        Q.set_head_field(self.m.q_doc, name, v, self.opts, self.m.q_headnames)
        self._type_timer.start()

    # ------------------------------------------------------------------ Grafikzeilen
    def asset_dirs(self):
        m = self.m
        dirs = []
        for d in (self.target_dir(), m.q_dir):
            if d and d not in dirs:
                dirs.append(d)
        return dirs

    def find_asset(self, path):
        p = path[2:] if path.startswith("./") else path
        for d in self.asset_dirs():
            for c in (os.path.join(d, p), os.path.join(d, "build", p)):
                if os.path.isfile(c):
                    return c
        return None

    def make_img_row(self, u):
        im = u["img"]
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        th = QLabel()
        th.setFixedSize(56, 40)
        th.setAlignment(Qt.AlignmentFlag.AlignCenter)
        p = self.find_asset(im["file"])
        if p:
            pm = QPixmap(p)
            if not pm.isNull():
                th.setPixmap(pm.scaled(56, 40, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        else:
            th.setText("?")
        h.addWidget(th)
        nm = QLabel(im["file"])
        nm.setToolTip(im["file"])
        h.addWidget(nm)
        if not p:
            miss = QLabel("fehlt im Zielordner")
            miss.setStyleSheet("color: #d33;")
            h.addWidget(miss)
        h.addWidget(QLabel("Breite"))
        sp = QDoubleSpinBox()
        sp.setRange(0.2, 40)
        sp.setSingleStep(0.1)
        sp.setDecimals(2)
        sp.setSuffix(" cm")
        sp.setValue(float(im["w"]))
        sl = QSlider(Qt.Orientation.Horizontal)
        sl.setRange(5, 170)
        sl.setValue(int(min(17, im["w"]) * 10))
        sl.setMaximumWidth(160)
        sl.setToolTip("Breite ziehen (bis 17 cm, größere Werte im Zahlenfeld)")

        def apply(v):
            if v > 0:
                Q.op_set_img(u, w=v)
                self._type_timer.start()
        sp.valueChanged.connect(lambda v: (sl.blockSignals(True), sl.setValue(int(min(17, v) * 10)), sl.blockSignals(False), apply(v)))
        sl.valueChanged.connect(lambda v: (sp.blockSignals(True), sp.setValue(v / 10), sp.blockSignals(False), apply(v / 10)))
        sp.editingFinished.connect(self.commit_if_changed)
        sl.sliderReleased.connect(self.commit_if_changed)
        h.addWidget(sp)
        h.addWidget(sl)
        al = QComboBox()
        for v, t in (("l", "links"), ("c", "Mitte"), ("r", "rechts")):
            al.addItem(t, v)
        al.setCurrentIndex(["l", "c", "r"].index(im["a"]))
        al.currentIndexChanged.connect(lambda i, al=al: (Q.op_set_img(u, a=al.itemData(i)), self.flush_typing(), self.commit_if_changed(), self.apply_model()))
        h.addWidget(al)
        h.addStretch(1)
        return w

    def image_dialog(self, u):
        d = QDialog(self.m)
        d.setWindowTitle("Grafik einfügen")
        lay = QVBoxLayout(d)
        base = self.target_dir()
        cd = os.path.join(base, "content") if base else None
        files = []
        if cd and os.path.isdir(cd):
            files = sorted([f for f in os.listdir(cd) if f.lower().endswith((".png", ".jpg", ".jpeg"))],
                           key=lambda s: [int(x) if x.isdigit() else x.lower() for x in __import__("re").split(r"(\d+)", s)])
        info = QLabel()
        info.setWordWrap(True)
        if files:
            info.setText("%d Bild(er) im Ordner content von „%s“. Anklicken fügt es unter der gewählten Zeile ein." % (len(files), base))
        else:
            info.setText("Im Zielordner „%s“ gibt es keinen Ordner content mit Bildern (png, jpg). Lege ihn dort an oder wähle unten eine "
                         "Datei. Sie muss dann im Ordner content liegen." % (base or "–"))
        lay.addWidget(info)
        chosen = []
        if files:
            grid = QGridLayout()
            for i, n in enumerate(files):
                b = QToolButton()
                b.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
                pm = QPixmap(os.path.join(cd, n))
                b.setIcon(QIcon(pm.scaled(96, 72, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)))
                b.setIconSize(QSize(96, 72))
                b.setText(n if len(n) < 20 else n[:17] + "…")
                b.setToolTip(n)
                b.setFixedSize(116, 108)
                b.clicked.connect(lambda _=False, n=n: (chosen.append("content/" + n), d.accept()))
                grid.addWidget(b, i // 4, i % 4)
            w = QWidget()
            w.setLayout(grid)
            sc = QScrollArea()
            sc.setWidget(w)
            sc.setWidgetResizable(True)
            sc.setMinimumHeight(240)
            lay.addWidget(sc, 1)
        row = QHBoxLayout()
        other = QPushButton("Andere Datei wählen …")

        def pick():
            p, _ = QFileDialog.getOpenFileName(d, "Bild wählen", cd if cd and os.path.isdir(cd) else (base or os.path.expanduser("~")),
                                               "Bilder (*.png *.jpg *.jpeg)")
            if p:
                chosen.append("content/" + os.path.basename(p))
                if not os.path.dirname(os.path.abspath(p)).endswith("content"):
                    self.m.status.showMessage("Lege die Datei „%s“ in den Ordner content." % os.path.basename(p), 10000)
                d.accept()
        other.clicked.connect(pick)
        cancel = QPushButton("Abbrechen")
        cancel.clicked.connect(d.reject)
        row.addWidget(other)
        row.addStretch(1)
        row.addWidget(cancel)
        lay.addLayout(row)
        d.resize(560, 420)
        if d.exec() != QDialog.DialogCode.Accepted or not chosen:
            return
        self.commit_if_changed()
        nu = Q.op_insert_image(self.m.q_doc, self.idx_of(u["id"]), chosen[0], 3, "l")
        self.commit()
        self.changed(focus=(nu["id"], 0, True))

    # ------------------------------------------------------------------ Warnungen, Hinweis
    def render_warnings(self):
        if self.m.q_doc is None:
            return
        w = Q.check_doc(self.m.q_doc, self.opts)
        self.lbl_warn.setText("  ".join("⚠ " + x["msg"] for x in w))

    def render_reminder(self):
        m = self.m
        if m.q_doc is None:
            return
        imgs_all = [p[2:] if p.startswith("./") else p for p in Q.find_images(m.q_doc, self.opts)]
        imgs = [p for p in imgs_all if not p.startswith("content/")]
        miss_content = [p for p in imgs_all if p.startswith("content/") and not self.find_asset(p)]
        parts = ["<b>Hinweis:</b> Die .tex wird im Ordner „%s“ gespeichert." % (self.target_dir() or "–")]
        if imgs:
            parts.append(("Die Bilder " if len(imgs) > 1 else "Das Logo muss unter dem Namen ") + ", ".join("<b>%s</b>" % p for p in imgs)
                         + (" müssen vorhanden sein." if len(imgs) > 1 else " vorhanden sein (so steht es in der Vorlage)."))
            for p in imgs:
                if self.find_asset(p):
                    parts.append("<span style='color:#2a8a2a'>✓ %s gefunden.</span>" % p)
                else:
                    parts.append("<span style='color:#d33'>✗ %s fehlt im Zielordner und in build!</span>" % p)
        if miss_content:
            parts.append("<span style='color:#d33'>✗ Fehlt im Ordner content: %s</span>" % ", ".join(miss_content))
        self.lbl_remind.setText(" ".join(parts))

    # ------------------------------------------------------------------ Dateiname, Schrift
    def on_name_edited(self, v):
        self.m.q_name = v
        self.m.q_name_auto = False

    def update_size_box(self):
        d = self.m.q_doc
        f = Q.find_name_size(d["head"]) if d else None
        self.grp_size.setVisible(bool(f))
        if f:
            self.sp_size.blockSignals(True)
            self.sp_size.setValue(int(round(f["size"])))
            self.sp_size.blockSignals(False)
        self.lbl_size.setText("")

    def on_size(self, v):
        if self._building or self.m.q_doc is None:
            return
        r = Q.set_name_size(self.m.q_doc, v)
        if not r:
            return
        self.lbl_size.setText(r["note"])
        self.commit_if_changed()
        self.apply_model()

    # ------------------------------------------------------------------ Zielordner
    def target_dir(self):
        m = self.m
        d = m.settings.get("quick_outdir") or ""
        if d and os.path.isdir(d):
            return d
        if m.path:
            return os.path.dirname(m.path)
        if m.q_dir and os.path.isdir(m.q_dir):
            return m.q_dir
        return os.path.expanduser("~")

    def update_out_ui(self):
        d = self.m.settings.get("quick_outdir") or ""
        auto = not (d and os.path.isdir(d))
        self.lbl_out.setText(os.path.basename(self.target_dir().rstrip("/")) or self.target_dir())
        self.lbl_out.setToolTip(self.target_dir())
        self.btn_outclr.setVisible(not auto)

    def choose_outdir(self):
        p = QFileDialog.getExistingDirectory(self.m, "Zielordner wählen", self.target_dir())
        if p:
            self.m.settings["quick_outdir"] = p
            self.update_out_ui()
            self.render_reminder()
            self.render_editor()

    def clear_outdir(self):
        self.m.settings["quick_outdir"] = ""
        self.update_out_ui()
        self.render_reminder()
        self.render_editor()

    # ------------------------------------------------------------------ Vorlagen
    def fill_tpl_combo(self, select=None):
        m = self.m
        self.cmb_tpl.blockSignals(True)
        self.cmb_tpl.clear()
        for name, _ in m.builtin_templates():
            self.cmb_tpl.addItem(name + " (eingebaut)", "builtin:" + name)
        for name in m.stored_templates():
            self.cmb_tpl.addItem(name + " (gemerkt)", "store:" + name)
        self.cmb_tpl.addItem("— geladene Datei —", "file")
        key = select or m.q_tpl_key or "file"
        i = self.cmb_tpl.findData(key)
        self.cmb_tpl.setCurrentIndex(i if i >= 0 else self.cmb_tpl.count() - 1)
        self.cmb_tpl.blockSignals(False)

    def on_tpl_chosen(self, i):
        key = self.cmb_tpl.itemData(i)
        m = self.m
        if key == "file":
            self.fill_tpl_combo()
            return
        kind, name = key.split(":", 1)
        text = None
        if kind == "builtin":
            text = dict(m.builtin_templates()).get(name)
        else:
            text = m.read_stored_template(name)
        if text is None:
            self.fill_tpl_combo()
            return
        if not m.open_template(text, name, key, None):
            self.fill_tpl_combo()

    def load_file(self):
        m = self.m
        start = self.target_dir()
        p, _ = QFileDialog.getOpenFileName(m, "LaTeX-Vorlage laden", start, "LaTeX (*.tex);;Alle Dateien (*)")
        if not p:
            return
        try:
            with open(p, "rb") as f:
                raw = f.read()
            text = raw.decode("utf-8", errors="replace")
        except OSError as e:
            QMessageBox.warning(m, "Vorlage laden", str(e))
            return
        m.open_template(text, os.path.splitext(os.path.basename(p))[0], "file", os.path.dirname(p))

    def keep_template(self):
        m = self.m
        if m.q_doc is None:
            return
        name = Q.clean_name(m.q_tpl) or "Vorlage"
        try:
            d = m.template_store_dir()
            os.makedirs(d, exist_ok=True)
            with open(os.path.join(d, name + ".tex"), "w", encoding="utf-8", newline="") as f:
                f.write(m.q_original.replace("\n", m.q_doc["eol"]) if m.q_doc["eol"] == "\r\n" else m.q_original)
        except OSError as e:
            QMessageBox.warning(m, "Vorlage merken", "Das Merken hat nicht geklappt:\n%s" % e)
            return
        m.q_tpl_key = "store:" + name
        self.fill_tpl_combo()
        m.status.showMessage("Vorlage „%s“ gemerkt." % name, 6000)

    def forget_template(self):
        key = self.cmb_tpl.currentData()
        if not key or not str(key).startswith("store:"):
            self.m.status.showMessage("Zum Vergessen zuerst eine gemerkte Vorlage in der Liste wählen.", 6000)
            return
        name = key[6:]
        try:
            os.remove(os.path.join(self.m.template_store_dir(), name + ".tex"))
        except OSError:
            pass
        if self.m.q_tpl_key == key:
            self.m.q_tpl_key = "file"
        self.fill_tpl_combo()
        self.m.status.showMessage("Vorlage vergessen.", 5000)

    def reset(self):
        m = self.m
        if m.q_doc is None:
            return
        if QMessageBox.question(m, "Zurücksetzen", "Alle Änderungen verwerfen und die Vorlage so laden, wie sie war?") \
                != QMessageBox.StandardButton.Yes:
            return
        text = m.q_original
        try:
            doc = Q.parse_tex(text)
        except Q.TexError:
            return
        doc["eol"] = m.tex_eol
        m.q_doc = doc
        m.q_undo, m.q_redo = [], []
        m.q_last = Q.snap(doc)
        m.q_collapsed = set()
        self.raw_edit = None
        m._loading = True
        try:
            m.tex_edit.setPlainText(text)
        finally:
            m._loading = False
        m.q_text_sig = text
        m.set_modified(False)
        self.show_view()

    def update_template(self):
        """Vorlage als neue, fortlaufend nummerierte Datei speichern (Name01.tex, Name02.tex …)."""
        m = self.m
        if m.q_doc is None:
            return
        self.flush_typing()
        self.commit_if_changed()
        warns = Q.check_doc(m.q_doc, self.opts)
        if warns and QMessageBox.question(
                m, "Vorlage aktualisieren", "Es gibt Warnungen (%d): Klammern sind nicht ausgeglichen. Trotzdem als Vorlage speichern?"
                % len(warns)) != QMessageBox.StandardButton.Yes:
            return
        text = Q.serialize_file(m.q_doc, dict(self.opts, autoBreak=False))   # ohne die Umbruch-Ergänzungen
        d = QDialog(m)
        d.setWindowTitle("Vorlage aktualisieren")
        lay = QVBoxLayout(d)
        intro = QLabel("Die bearbeitete Vorlage wird als neue, fortlaufend nummerierte Datei gespeichert. Das Original bleibt unverändert.")
        intro.setWordWrap(True)
        lay.addWidget(intro)
        info = QLabel()
        info.setWordWrap(True)
        lay.addWidget(info)
        row = QHBoxLayout()
        pick = QPushButton("Ordner wählen …")
        row.addWidget(pick)
        row.addStretch(1)
        lay.addLayout(row)
        btns = QHBoxLayout()
        btns.addStretch(1)
        b_cancel = QPushButton("Abbrechen")
        b_last = QPushButton("")
        b_new = QPushButton("")
        b_new.setDefault(True)
        for b in (b_cancel, b_last, b_new):
            btns.addWidget(b)
        lay.addLayout(btns)
        state = {"dir": self.target_dir(), "name": None, "first": True, "result": None}

        def refresh():
            dr = state["dir"]
            names = os.listdir(dr) if os.path.isdir(dr) else []
            nm, first = Q.next_template_name(m.q_tpl, names)
            state["name"], state["first"] = nm, first
            info.setText("Zielordner: <b>%s</b><br><small>%s</small>" % (
                dr, "In diesem Ordner liegt noch keine nummerierte Fassung, die Datei wird neu angelegt." if first
                else "Es gibt dort schon nummerierte Fassungen, die nächste Nummer wird vergeben."))
            b_new.setText("Als „%s“ speichern" % nm)
            w = m.q_wrote
            show_last = bool(w and os.path.dirname(w) == dr and os.path.exists(w))
            b_last.setVisible(show_last)
            if show_last:
                b_last.setText("„%s“ überschreiben" % os.path.basename(w))

        def choose():
            p = QFileDialog.getExistingDirectory(d, "Zielordner wählen", state["dir"])
            if p:
                state["dir"] = p
                m.settings["quick_outdir"] = p
                self.update_out_ui()
                refresh()

        def done(which):
            state["result"] = which
            d.accept()
        pick.clicked.connect(choose)
        b_cancel.clicked.connect(d.reject)
        b_new.clicked.connect(lambda: done("new"))
        b_last.clicked.connect(lambda: done("last"))
        refresh()
        d.resize(520, 220)
        if d.exec() != QDialog.DialogCode.Accepted:
            return
        target = os.path.join(state["dir"], os.path.basename(m.q_wrote) if state["result"] == "last" else state["name"])
        try:
            with open(target, "w", encoding="utf-8", newline="") as f:
                f.write(text)
        except OSError as e:
            QMessageBox.warning(m, "Vorlage aktualisieren", "Speichern fehlgeschlagen:\n%s" % e)
            return
        m.q_wrote = target
        m.status.showMessage("Vorlage gespeichert: %s (das Original ist unverändert)." % target, 10000)

    # ------------------------------------------------------------------ Speichern, Kopieren, PDF
    def save_tex(self):
        m = self.m
        if m.q_doc is None:
            return False
        self.flush_typing()
        self.commit_if_changed()
        name = Q.clean_name(self.ed_name.text())
        if not name:
            QMessageBox.information(m, "Dateiname", "Bitte zuerst oben einen Dateinamen eingeben. Er erscheint auch im Seitenkopf.")
            self.ed_name.setFocus()
            return False
        warns = Q.check_doc(m.q_doc, self.opts)
        if warns and QMessageBox.question(
                m, "Speichern", "Es gibt Warnungen (%d): Klammern sind nicht ausgeglichen, die Datei lässt sich dann eventuell nicht "
                "übersetzen. Trotzdem speichern?" % len(warns)) != QMessageBox.StandardButton.Yes:
            return False
        target = os.path.join(self.target_dir(), name + ".tex")
        if os.path.exists(target) and (not m.path or os.path.abspath(target) != os.path.abspath(m.path)):
            if QMessageBox.question(m, "Speichern", "Im Ordner „%s“ gibt es schon eine Datei „%s.tex“. Überschreiben?"
                                    % (self.target_dir(), name)) != QMessageBox.StandardButton.Yes:
                return False
        self.apply_model()
        m.q_name = name
        ok = m.save_to(target)
        if ok:
            self.show_view()
        return ok

    def copy_latex(self):
        if self.m.q_doc is None:
            return
        self.flush_typing()
        QApplication.clipboard().setText(Q.serialize(self.m.q_doc, self.opts))
        self.m.status.showMessage("LaTeX-Code in die Zwischenablage kopiert.", 5000)

    def save_pdf(self):
        m = self.m
        pdf = m.pdf_loaded
        if not pdf or not os.path.exists(pdf):
            m.status.showMessage("Noch kein PDF vorhanden – bitte zuerst übersetzen (F5).", 6000)
            return
        name = (Q.clean_name(self.ed_name.text()) or "Dokument") + ".pdf"
        p, _ = QFileDialog.getSaveFileName(m, "PDF speichern", os.path.join(self.target_dir(), name), "PDF (*.pdf)")
        if not p:
            return
        if not p.lower().endswith(".pdf"):
            p += ".pdf"
        try:
            shutil.copyfile(pdf, p)
        except OSError as e:
            QMessageBox.warning(m, "PDF speichern", str(e))
            return
        m.status.showMessage("PDF gespeichert: " + p, 6000)

    # ------------------------------------------------------------------ Übersetzen (Anzeige)
    def sync_compile(self):
        m = self.m
        self.lbl_status.setText(m.lbl_compile.text())
        self.btn_compile.setEnabled(m.btn_compile.isEnabled())
        if self.log.toPlainText() != m.log.toPlainText():
            self.log.setPlainText(m.log.toPlainText())
        if self.cmb_engine.currentText() != m.cmb_engine.currentText():
            self.cmb_engine.blockSignals(True)
            self.cmb_engine.setCurrentText(m.cmb_engine.currentText())
            self.cmb_engine.blockSignals(False)

    def _log_dbl(self, ev):
        import re
        cur = self.log.cursorForPosition(ev.position().toPoint())
        mt = re.match(r"Zeile (\d+):", cur.block().text())
        if mt:
            n = int(mt.group(1))
            self.tabs.setCurrentWidget(self.src)
            b = self.src.document().findBlockByNumber(n - 1)
            c = QTextCursor(b)
            self.src.setTextCursor(c)
            self.src.centerCursor()
        else:
            QPlainTextEdit.mouseDoubleClickEvent(self.log, ev)

    def show_preview_tab(self):
        self.tabs.setCurrentIndex(0)
