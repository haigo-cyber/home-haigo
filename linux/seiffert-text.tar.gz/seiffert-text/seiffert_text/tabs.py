"""Farbige Dokument-Tabs und Anbindung an TeXstudio."""
import os
import shutil
import subprocess

from PySide6.QtCore import QPoint, QRect, Qt, Signal
from PySide6.QtGui import QColor, QPainter
from PySide6.QtWidgets import QTabBar

# Namen und Farben der Tab-Palette. Neue Tabs bekommen reihum die erste Farbe, die noch nicht vergeben ist.
TAB_COLORS = [("Blau", "#3584e4"), ("Grün", "#2ec27e"), ("Orange", "#ff7800"), ("Rot", "#e01b24"),
              ("Violett", "#9141ac"), ("Türkis", "#1c9ba8"), ("Gelb", "#e5a50a"), ("Rosa", "#d6409f"),
              ("Grau", "#77767b")]


def next_free_color(used):
    used = {u.lower() for u in used if u}
    for _, c in TAB_COLORS:
        if c.lower() not in used:
            return c
    return TAB_COLORS[len(used) % len(TAB_COLORS)][1]


class Tab:
    """Alles, was zu einem geöffneten Dokument gehört und nicht im Fenster selbst liegt."""
    _n = 0

    def __init__(self, color):
        Tab._n += 1
        self.id = Tab._n
        self.color = color
        self.doc = None             # QTextDocument der formatierten Ansicht
        self.s = {}                 # gesicherte Attribute des Hauptfensters
        self.md_text = None
        self.tex_text = None
        self.log_text = ""
        self.lbl_compile = ""
        self.cursor = 0
        self.scroll = 0
        self.zoom = 0
        self.colored_for = None     # Pfad, für den die gemerkte Farbe schon angewendet wurde
        self.widget = None          # bei einem PDF-Tab: das eingebettete PDF-Fenster (sonst None)

    @property
    def is_pdf(self):
        return self.widget is not None

    @property
    def path(self):
        return self.s.get("path")

    @property
    def modified(self):
        return bool(self.s.get("modified"))


class ColorTabBar(QTabBar):
    """Tab-Leiste, in der jeder Tab eine eigene Farbe trägt."""
    contextRequested = Signal(int, QPoint)
    emptyDoubleClicked = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.color_of = None
        self.setMovable(True)
        self.setTabsClosable(True)
        self.setExpanding(False)
        self.setDocumentMode(True)
        self.setUsesScrollButtons(True)
        self.setElideMode(Qt.TextElideMode.ElideMiddle)
        self.setDrawBase(True)
        self._press_index = -1
        self._dragging = False

    def mousePressEvent(self, e):
        self._press_index = self.tabAt(e.position().toPoint())
        self._dragging = False
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        if self._press_index >= 0 and (e.buttons() & Qt.MouseButton.LeftButton):
            self._dragging = True
        super().mouseMoveEvent(e)

    def mouseReleaseEvent(self, e):
        super().mouseReleaseEvent(e)
        self._dragging = False
        self._press_index = -1
        self.update()

    def mouseDoubleClickEvent(self, e):
        if self.tabAt(e.position().toPoint()) < 0:
            self.emptyDoubleClicked.emit()
        else:
            super().mouseDoubleClickEvent(e)

    def contextMenuEvent(self, e):
        i = self.tabAt(e.pos())
        if i >= 0:
            self.contextRequested.emit(i, e.globalPos())

    def tabSizeHint(self, i):
        s = super().tabSizeHint(i)
        s.setWidth(min(max(s.width(), 110), 260))
        s.setHeight(max(s.height(), 28))
        return s

    def paintEvent(self, ev):
        super().paintEvent(ev)
        if self.color_of is None:
            return
        p = QPainter(self)
        cur = self.currentIndex()
        for i in range(self.count()):
            if self._dragging and i == self._press_index:
                continue        # der gezogene Tab wird vom Stil an anderer Stelle gezeichnet
            col = self.color_of(i)
            if not col:
                continue
            r = self.tabRect(i)
            if not r.isValid():
                continue
            c = QColor(col)
            sel = i == cur
            tint = QColor(c)
            tint.setAlpha(125 if sel else 80)
            p.fillRect(r.adjusted(0, 0, -1, -1), tint)
            bar = QColor(c)
            bar.setAlpha(255 if sel else 170)
            p.fillRect(QRect(r.left(), r.top(), r.width() - 1, 4 if sel else 3), bar)
            if sel:
                p.fillRect(QRect(r.left(), r.bottom() - 1, r.width() - 1, 2), bar)
        p.end()


# ---------------------------------------------------------------------------------------- TeXstudio
def find_texstudio(configured=""):
    """Liefert den Programmaufruf als Liste oder None. Reihenfolge: eingestellter Pfad, PATH, Flatpak."""
    if configured and os.path.isfile(configured) and os.access(configured, os.X_OK):
        return [configured]
    w = shutil.which("texstudio")
    if w:
        return [w]
    for p in (os.path.expanduser("~/.local/bin/texstudio"), "/opt/texstudio/texstudio",
              "/usr/local/bin/texstudio"):
        if os.path.isfile(p) and os.access(p, os.X_OK):
            return [p]
    fp = shutil.which("flatpak")
    if fp:
        try:
            r = subprocess.run([fp, "info", "org.texstudio.TeXstudio"], capture_output=True, timeout=10)
            if r.returncode == 0:
                return [fp, "run", "org.texstudio.TeXstudio"]
        except Exception:
            pass
    return None


def launch_texstudio(cmd, path, line=1):
    """Öffnet path in TeXstudio an der angegebenen Zeile (Option --line laut Handbuchseite von TeXstudio).
    Läuft bereits eine Instanz, bekommt sie die Datei; sonst startet TeXstudio neu."""
    args = list(cmd) + ["--line", str(max(1, int(line))), path]
    subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     start_new_session=True)
    return args


def file_sig(path):
    try:
        st = os.stat(path)
        return (st.st_mtime_ns, st.st_size)
    except OSError:
        return None
