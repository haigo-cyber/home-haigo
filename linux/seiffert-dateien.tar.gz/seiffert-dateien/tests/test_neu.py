#!/usr/bin/env python3
"""Prüfungen für die Ergänzungen in Version 2.6: Farbmodul, eigene Befehle im Starter, Verlauf der Zwischenablage, Befehl seiffert,
Text vom Bildschirm. Aufruf:  QT_QPA_PLATFORM=offscreen python tests/test_neu.py
Alles läuft in einem eigenen, leeren Benutzerordner; die echten Einstellungen werden nicht angefasst."""
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HOME = tempfile.mkdtemp(prefix="sd-test-home-")
TMP = tempfile.mkdtemp(prefix="sd-test-tmp-")
os.environ.update(HOME=HOME, XDG_CONFIG_HOME=HOME + "/.config", XDG_DATA_HOME=HOME + "/.local/share", XDG_CACHE_HOME=HOME + "/.cache",
                  TMPDIR=TMP, SEIFFERT_STARTER_NOHIDE="1")
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
tempfile.tempdir = TMP
sys.path.insert(0, HERE)
CFG = os.path.join(HOME, ".config", "seiffert-dateien")
os.makedirs(os.path.join(CFG, "befehle.d"))
PASS = FAIL = 0


def check(name, cond, info=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        print("FEHLER: %s %s" % (name, info))


def wait(cond, secs=5.0, app=None):
    end = time.time() + secs
    while time.time() < end:
        if app is not None:
            app.processEvents()
        if cond():
            return True
        time.sleep(0.02)
    return False


# ------------------------------------------------------------------ Punkt 2: Farbmodul
import skins  # noqa: E402

css = open(os.path.join(HERE, "index.html"), encoding="utf-8").read()
for s in skins.SKINS:
    for dark in (False, True):
        if s == "petrol":
            blk = re.search(r':root\[data-theme="dark"\]\{(.*?)\}' if dark else r':root\{(.*?)\}', css, re.S).group(1)
        else:
            sel = ':root[data-skin="%s"]%s{' % (s, '[data-theme="dark"]' if dark else ':not([data-theme="dark"])')
            blk = css[css.index(sel) + len(sel):].split("}", 1)[0]
        got = dict(re.findall(r"--([a-z0-9-]+):\s*(#[0-9a-fA-F]{6})", blk))
        pal = skins.palette(s, dark)
        for k, v in got.items():
            key = k.replace("-", "_")
            if key in pal:
                check("Farbe %s %s %s" % (s, "dunkel" if dark else "hell", k), pal[key] == v.lower(), "%s != %s" % (pal[key], v))
check("SKIN_COL", skins.SKIN_COL["wald"] == ("#2b6a3d", "#7fc68f"))
check("Auswahl ohne Datei", skins.read_choice() == ("petrol", "auto"))
import backend as B  # noqa: E402
import starter as ST  # noqa: E402
import starterextra as SX  # noqa: E402
check("Starter nimmt Farben aus skins", ST.SKIN_COL is skins.SKIN_COL and B.SKINS is skins.SKINS)
src = open(os.path.join(HERE, "oberflaeche.py"), encoding="utf-8").read()
check("Oberfläche nimmt Farben aus skins", "SKIN_COL = skins.SKIN_COL" in src and '"#245d73"' not in src)
check("Version 2.9", B.VERSION == "2.9")

# Farbdesign umstellen ohne laufendes Seifferts Dateien: Datei wird geändert, andere Schlüssel bleiben
os.makedirs(CFG, exist_ok=True)
json.dump({"skin": "petrol", "theme": "auto", "favorites": [{"x": 1}]}, open(os.path.join(CFG, "config.json"), "w"))
check("set_design Datei", SX.set_design(skin="wald", theme="dark") == "datei")
d = json.load(open(os.path.join(CFG, "config.json")))
check("set_design Inhalt", d["skin"] == "wald" and d["theme"] == "dark" and d["favorites"] == [{"x": 1}], str(d))
cur = skins.current()
check("current", cur["skin"] == "wald" and cur["dark"] is True and cur["colors"]["accent"] == "#7fc68f", str(cur))
try:
    SX.set_design(skin="lila")
    check("set_design lehnt Unbekanntes ab", False)
except ValueError:
    check("set_design lehnt Unbekanntes ab", True)
import termsettings as T  # noqa: E402
r = T.resolve(json.loads(json.dumps(T.DEFAULTS)), "design")
check("Terminal folgt Farbdesign", r["colors"]["background"] == "#101713" and r["colors"]["cursor"] == "#7fc68f" and r["dark"], str(r["colors"]))
check("Terminal-Schema in Liste", any(t["id"] == "design" and "Wald" in t["label"] for t in T.theme_list()))
check("Terminal-Syntax lesbar", min(T.contrast(v, r["colors"]["background"]) for v in r["syntax"].values()) >= 3.6)
SX.set_design(theme="light")
r = T.resolve(json.loads(json.dumps(T.DEFAULTS)), "design")
check("Terminal hell", r["colors"]["background"] == "#edf2ee" and not r["dark"]
      and min(T.contrast(v, r["colors"]["background"]) for v in r["syntax"].values()) >= 3.6, str(r["colors"]))
st = json.loads(json.dumps(T.DEFAULTS)); st["theme"] = "design"
check("Terminal-Einstellung design gültig", T.clean(st)["theme"] == "design" if hasattr(T, "clean") else True)
os.remove(os.path.join(CFG, "config.json"))

# ------------------------------------------------------------------ Punkt 1: Befehle (ohne Oberfläche)
MARK = os.path.join(HOME, "marke.txt")
json.dump([{"id": "a1", "name": "Sicherung starten", "line": "echo sicher > %s" % MARK, "created": 1},
           {"id": "a2", "name": "Auswahl packen", "line": "tar czf x.tgz {auswahl}"},
           {"id": "a3", "name": "Ordner zeigen", "line": "echo {ordner} > %s" % MARK},
           {"id": "a4", "name": "System aktualisieren", "line": "sudo pacman -Syu"},
           {"id": "a5", "name": "Kaputt", "line": "gibtesnicht-xyz --los"},
           {"id": "a6", "name": "Verkettet", "line": "printf a > %s && printf b >> %s; cat %s | tr ab AB > %s.2" % (MARK, MARK, MARK, MARK)}],
          open(os.path.join(CFG, "commands.json"), "w"))
json.dump([{"name": "Tafel verbinden", "line": "echo tafel > %s" % MARK, "desc": "Bildschirm auf die Tafel spiegeln", "words": ["airplay", "apple tv"], "confirm": True},
           {"name": "", "line": "x"}, "unsinn", {"name": "Ohne Zeile"}],
          open(os.path.join(CFG, "befehle.d", "seiffert-funk.json"), "w"))
open(os.path.join(CFG, "befehle.d", "kaputt.json"), "w").write("{nicht json")
uc = SX.user_commands()
names = [c["name"] for c in uc]
check("Befehle gelesen", names == ["Sicherung starten", "Ordner zeigen", "System aktualisieren", "Kaputt", "Verkettet", "Tafel verbinden"], str(names))
check("sudo ins Terminal", next(c for c in uc if c["name"] == "System aktualisieren")["terminal"] and not uc[0]["terminal"])
check("Drop-in Felder", uc[-1]["confirm"] and uc[-1]["source"] == "seiffert-funk" and uc[-1]["words"] == ["airplay", "apple tv"])
bi = SX.builtin_commands()
check("eingebaute Aktionen", len(bi) == 1 + 7 + 3 + 2 + 4 + 1 and len(SX.builtin_commands(clip=False)) == 17)
SX.run_line(uc[0]["line"])
check("Befehl im Hintergrund", wait(lambda: os.path.exists(MARK) and open(MARK).read() == "sicher\n"))
SX.run_line(uc[1]["line"])
check("{ordner} = persönlicher Ordner", wait(lambda: open(MARK).read() == HOME + "\n"), open(MARK).read())
SX.run_line(uc[4]["line"])
check("Verkettung läuft über die Shell", wait(lambda: os.path.exists(MARK + ".2") and open(MARK + ".2").read() == "AB"))
try:
    SX.run_line("gibtesnicht-xyz --los")
    check("unbekanntes Programm gemeldet", False)
except ValueError as e:
    check("unbekanntes Programm gemeldet", "gibtesnicht-xyz" in str(e), str(e))
# Terminal: mit einem Ersatz-Terminal, das seine Argumente aufschreibt
BIN = os.path.join(HOME, ".local", "bin")
os.makedirs(BIN)
fake = os.path.join(BIN, "seiffert-terminal")
open(fake, "w").write('#!/bin/sh\nprintf "%%s\\n" "$@" > %s/term-args.txt\n' % HOME)
os.chmod(fake, 0o755)
os.environ["PATH"] = BIN + os.pathsep + os.environ["PATH"]
SX.run_line("sudo pacman -Syu", terminal=True)
check("Terminal-Aufruf", wait(lambda: os.path.exists(HOME + "/term-args.txt")) and open(HOME + "/term-args.txt").read().startswith("-e\n")
      and "sudo pacman -Syu" in open(HOME + "/term-args.txt").read() and "Enter schließt" in open(HOME + "/term-args.txt").read())

# ------------------------------------------------------------------ Punkt 3: Verlauf (ohne Oberfläche)
cs = SX.ClipStore(limit=3)
check("leer und zu lang abgelehnt", not cs.add("") and not cs.add("  \n") and not cs.add("x" * 200_001) and not cs.add(None))
for t in ("eins", "zwei", "drei", "zwei", "vier"):
    cs.add(t)
check("Verlauf: neueste zuerst, ohne Doppelte, begrenzt", [i["text"] for i in cs.items()] == ["vier", "zwei", "drei"], str([i["text"] for i in cs.items()]))
check("Verlauf get und leeren", cs.get(cs.items()[1]["key"]) == "zwei" and cs.clear() == 3 and len(cs) == 0)
check("Titel", SX.clip_title("\n\n  Erste   Zeile  \nzweite") == "Erste Zeile" and len(SX.clip_title("a" * 200)) == 60)
check("Info", SX.clip_info("ab\ncd", 100.0, 100.0 + 125) == "5 Zeichen, 2 Zeilen, vor 2 Min.")

# ------------------------------------------------------------------ Starter: Suche
backend = B.Backend()
f = ST.Finder(backend)
hits = f.commands("sicher")
check("Suche findet eigenen Befehl", hits and hits[0].title == "Sicherung starten" and hits[0].kind == "command", str([h.title for h in hits]))
check("Suche über Stichwort aus befehle.d", [h.title for h in f.commands("airplay")] == ["Tafel verbinden"])
check("Suche über Befehlszeile", any(h.title == "System aktualisieren" for h in f.commands("pacman")))
check("Suche Farbdesign", [h.title for h in f.commands("farbdesign wald")] == ["Farbdesign: Wald"])
check("Suche Texterkennung", f.commands("ocr")[0].extra["builtin"] == "ocr" and f.commands("text vom bild")[0].title == "Text vom Bildschirm lesen")
alle = f.commands("", 40)
check("ohne Eingabe: eigene zuerst", [h.title for h in alle[:6]] == names and len(alle) == 6 + 18, str([h.title for h in alle[:7]]))
f.clip.add("Hallo Köln, Straße 5")
f.clip.add("zweiter Text\nmit Zeile")
check("Verlauf-Suche mit Umlauten", [h.title for h in f.clips("koeln strasse")] == ["Hallo Köln, Straße 5"])
check("Verlauf ohne Eingabe", [h.title for h in f.clips("")] == ["zweiter Text", "Hallo Köln, Straße 5"])
merged = ST.Finder.merge({"cmd": f.commands("sicher"), "sys": f.system("sicher")}, "all", 16)
check("merge kennt neue Sorten", merged and merged[0].kind == "command")

# ------------------------------------------------------------------ Starter: Oberfläche (offscreen)
Cloud, QApplication = ST.build_ui()
from PySide6.QtCore import Qt  # noqa: E402
from PySide6.QtGui import QGuiApplication  # noqa: E402
from PySide6.QtTest import QTest  # noqa: E402
app = QApplication(["test"])
win = Cloud(f, backend)
win.summon()
app.processEvents()
check("Reiter vorhanden", [c[0] for c in win.cats] == ["all", "favapp", "app", "file", "folder", "text", "command", "clip", "system"], str(win.cats))
os.remove(MARK)
QTest.keyClicks(win.edit, "sicherung")
check("Blase für Befehl", wait(lambda: win.items and win.items[0].kind == "command", 3, app), str([(i.kind, i.title) for i in win.items]))
img = win.grab().toImage()
check("Wolke zeichnet mit neuer Sorte", not img.isNull())
QTest.keyClick(win.edit, Qt.Key.Key_Return)
check("Enter führt Befehl aus und schließt", wait(lambda: os.path.exists(MARK), 3, app) and not win.isVisible())
# mit Nachfrage
win.summon(); os.remove(MARK)
QTest.keyClicks(win.edit, "tafel verb")
wait(lambda: win.items and win.items[0].title == "Tafel verbinden", 3, app)
QTest.keyClick(win.edit, Qt.Key.Key_Return)
app.processEvents()
check("Nachfrage vor Befehl mit confirm", win.isVisible() and "Enter bestätigt" in win.msg and not os.path.exists(MARK), win.msg)
QTest.keyClick(win.edit, Qt.Key.Key_Return)
check("zweites Enter führt aus", wait(lambda: os.path.exists(MARK), 3, app))
# Strg+Enter: im Terminal
win.summon(); os.remove(HOME + "/term-args.txt")
QTest.keyClicks(win.edit, "sicherung")
wait(lambda: win.items and win.items[0].kind == "command", 3, app)
QTest.keyClick(win.edit, Qt.Key.Key_Return, Qt.KeyboardModifier.ControlModifier)
check("Strg+Enter startet im Terminal", wait(lambda: os.path.exists(HOME + "/term-args.txt"), 3, app))
# Fehler bleibt sichtbar
win.summon()
QTest.keyClicks(win.edit, "kaputt")
wait(lambda: win.items and win.items[0].title == "Kaputt", 3, app)
QTest.keyClick(win.edit, Qt.Key.Key_Return)
app.processEvents()
check("Fehlermeldung in der Wolke", win.isVisible() and "nicht gefunden" in win.msg, win.msg)
# Farbdesign über den Starter
win.summon()
QTest.keyClicks(win.edit, "farbdesign beere")
wait(lambda: win.items and win.items[0].title == "Farbdesign: Beere", 3, app)
QTest.keyClick(win.edit, Qt.Key.Key_Return)
app.processEvents()
d = json.load(open(os.path.join(CFG, "config.json")))
check("Farbdesign umgestellt und Wolke folgt", d["skin"] == "beere" and win.accent == skins.SKIN_COL["beere"] and win.isVisible(), "%s %s" % (d.get("skin"), win.accent))
# Reiter Befehle ohne Eingabe
win.summon(); win.set_cat("command"); app.processEvents()
check("Reiter Befehle zeigt alle", len(win.items) == min(win.cap, 18) and win.items[0].kind == "command", str(len(win.items)))
# Zwischenablage
cb = QGuiApplication.clipboard()
cb.setText("Text aus einem anderen Programm")
check("Verlauf merkt Kopiertes", wait(lambda: f.clip.items() and f.clip.items()[0]["text"] == "Text aus einem anderen Programm", 3, app))
cb.setText("neuester")
wait(lambda: f.clip.items()[0]["text"] == "neuester", 3, app)
win.summon(); win.set_cat("clip"); app.processEvents()
check("Reiter Zwischenablage", [i.title for i in win.items][:2] == ["neuester", "Text aus einem anderen Programm"], str([i.title for i in win.items]))
QTest.keyClicks(win.edit, "anderen")
wait(lambda: len(win.items) == 1, 3, app)
QTest.keyClick(win.edit, Qt.Key.Key_Return)
check("Enter legt alten Text zurück", wait(lambda: cb.text() == "Text aus einem anderen Programm", 3, app) and not win.isVisible(), cb.text())
check("zurückgelegter Text steht vorn", f.clip.items()[0]["text"] == "Text aus einem anderen Programm")
win.summon()
QTest.keyClicks(win.edit, "verlauf leeren")
wait(lambda: win.items and win.items[0].extra.get("builtin") == "clipclear", 3, app)
QTest.keyClick(win.edit, Qt.Key.Key_Return); app.processEvents()
check("Verlauf leeren", len(f.clip) == 0 and "geleert" in win.msg, win.msg)
# abschalten
backend.api_set_config({"starter": {"src_clip": False, "src_cmds": False}})
cb.setText("darf nicht gemerkt werden"); app.processEvents(); time.sleep(0.1); app.processEvents()
win.summon(); app.processEvents()
check("abgeschaltet: nichts gemerkt, Reiter weg", len(f.clip) == 0 and [c[0] for c in win.cats] == ["all", "favapp", "app", "file", "folder", "text", "system"], str(win.cats))
QTest.keyClicks(win.edit, "sicherung"); wait(lambda: False, 0.4, app)
check("abgeschaltet: keine Befehle", not any(i.kind == "command" for i in win.items))
backend.api_set_config({"starter": {"src_clip": True, "src_cmds": True}})
check("Einstellungen überleben Speichern ohne die neuen Schlüssel",
      backend.api_set_config({"starter": {"bubbles": 12}})["starter"]["src_cmds"] is True)
win.hide()

# ------------------------------------------------------------------ Punkt 4: Text vom Bildschirm
import bildtext as BT  # noqa: E402
check("Sprachwahl", BT.pick_langs("deu+eng", ["deu", "eng", "fra"]) == ("deu+eng", []) and BT.pick_langs("deu+eng", ["eng"]) == ("eng", ["deu"]))
check("Textbereinigung", BT.clean_text("a  \n\n\n b\n\x0c\n") == "a\n\n b")
check("Argumente", BT.parse_args(["--rect", "1,2,30,40", "--lang=eng", "--delay", "0.5"])["rect"] == (1, 2, 30, 40)
      and BT.parse_args(["--rect", "1,2"])["error"] and BT.parse_args(["--quatsch"])["error"])
if shutil.which("tesseract"):
    from PySide6.QtGui import QColor, QFont, QImage, QPainter, QPixmap  # noqa: E402
    TEXT = ["Übungsblatt 7: Brüche kürzen", "Löse die Aufgaben 1 bis 4 im Heft.", "Größter gemeinsamer Teiler"]
    pm = QPixmap(900, 300); pm.fill(QColor("#ffffff"))
    p = QPainter(pm); fnt = QFont("DejaVu Sans"); fnt.setPixelSize(26); p.setFont(fnt); p.setPen(QColor("#111111"))
    for n, ln in enumerate(TEXT):
        p.drawText(40, 70 + n * 60, ln)
    p.end()
    path = os.path.join(HOME, "seite.png"); pm.save(path)
    text, note = BT.recognize(path, "deu+eng")
    check("Texterkennung aus Datei", all(ln in text for ln in TEXT), repr(text))
    # Auswahl mit der Maus: nur die mittlere Zeile
    Selector, _QC, _QG, QRect = BT.build_selector()
    sel = Selector(pm, QRect(0, 0, 900, 300)); sel.show(); app.processEvents()
    from PySide6.QtCore import QPoint  # noqa: E402
    QTest.mouseClick(sel, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier, QPoint(50, 50)); app.processEvents()
    check("bloßer Klick wählt nichts", not sel.done)
    QTest.mousePress(sel, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier, QPoint(20, 100))
    QTest.mouseMove(sel, QPoint(600, 150)); QTest.mouseRelease(sel, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier, QPoint(700, 150))
    app.processEvents()
    check("Rahmen gezogen", sel.done and sel.result == QRect(QPoint(20, 100), QPoint(700, 150)), str(sel.result))
    part = BT.crop(pm, sel.result, 900); part.save(path)
    text, _ = BT.recognize(path, "deu+eng")
    check("Texterkennung im Ausschnitt", text.strip() == TEXT[1], repr(text))
    # dunkler Hintergrund (Terminal): wird erkannt, vor dem Lesen umgekehrt und vergrößert
    dk = QPixmap(900, 300); dk.fill(QColor("#2e3436"))
    p2 = QPainter(dk); p2.setFont(fnt); p2.setPen(QColor("#d3d7cf"))
    for n, ln in enumerate(TEXT):
        p2.drawText(40, 70 + n * 60, ln)
    p2.end()
    dimg = BT.crop(dk, QRect(0, 0, 900, 300), 900)
    check("dunkler Grund wird umgekehrt", dimg.pixelColor(2, 2).value() > 200 and dimg.width() > 900 and BT.is_dark(dk.toImage()) and not BT.is_dark(pm.toImage()))
    dimg.save(path)
    text, _ = BT.recognize(path, "deu")
    check("Texterkennung auf dunklem Grund", all(ln in text for ln in TEXT), repr(text))
    check("fehlende Sprachdaten werden deutlich gemeldet", "Umlaute" in BT.recognize(path, "xyz")[1] and BT.recognize(path, "xyz")[1].count("pacman") == 1)
    check("Standardsprache deutsch", BT.parse_args([])["lang"] == "deu")
    sel2 = Selector(pm, QRect(0, 0, 900, 300)); sel2.show(); QTest.keyClick(sel2, Qt.Key.Key_Escape)
    check("Esc bricht ab", sel2.done and sel2.result is None)
    blank = QImage(200, 100, QImage.Format.Format_RGB32); blank.fill(QColor("#000000"))
    check("leeres Foto erkannt", BT.looks_empty(blank) and not BT.looks_empty(pm.toImage()))
else:
    print("übersprungen: tesseract fehlt")

# ------------------------------------------------------------------ Punkt 5: Befehl seiffert
import seiffert_cli as CLI  # noqa: E402
SH = os.path.join(HOME, ".local", "share")
os.makedirs(SH + "/seiffert-text/app/seiffert_text"); open(SH + "/seiffert-text/app/seiffert_text/__init__.py", "w").write('APP_NAME = "Seifferts Text"\nVERSION = "0.14"\n')
os.makedirs(SH + "/seiffert-funk/seiffert_funk"); open(SH + "/seiffert-funk/seiffert_funk/config.py", "w").write('import os\nVERSION = "1.0"\n')
os.makedirs(SH + "/seiffert-zeit/seiffert_zeit"); open(SH + "/seiffert-zeit/seiffert_zeit/app.py", "w").write('print(1)\n')
os.makedirs(SH + "/applications")
for name, body, title in (("seiffert-text", 'exec "%s/seiffert-text/venv/bin/python" -m seiffert_text "$@"' % SH, "Seifferts Text"),
                          ("seiffert-funk", 'exec python3 "%s/seiffert-funk/seiffert_funk/app.py" "$@"' % SH, "Seifferts Funk"),
                          ("seiffert-zeit", 'echo zeit "$@" > %s/zeit-args.txt' % HOME, "Seifferts Zeit")):
    open(os.path.join(BIN, name), "w").write("#!/bin/sh\n%s\n" % body); os.chmod(os.path.join(BIN, name), 0o755)
    open(SH + "/applications/%s.desktop" % name, "w").write("[Desktop Entry]\nName=%s\nExec=%s\n" % (title, name))
os.environ["PATH"] = BIN
progs = {p["short"]: p for p in CLI.programs()}
os.environ["PATH"] = BIN + os.pathsep + "/usr/local/bin:/usr/bin:/bin"
check("Programme gefunden", sorted(progs) == ["funk", "terminal", "text", "zeit"], str(sorted(progs)))
check("Versionen", progs["text"]["version"] == "0.14" and progs["funk"]["version"] == "1.0" and progs["zeit"]["version"] == "", str({k: v["version"] for k, v in progs.items()}))
check("Namen aus Menüeinträgen", progs["text"]["name"] == "Seifferts Text")
pl = list(progs.values())
check("Abkürzung", CLI.find_program("te", pl)[1] != "" and CLI.find_program("tex", pl)[0]["short"] == "text" and CLI.find_program("seiffert-zeit", pl)[0]["short"] == "zeit"
      and CLI.find_program("xyz", pl)[0] is None)
cli = [sys.executable, os.path.join(HERE, "seiffert_cli.py")]
r = subprocess.run(cli, capture_output=True, text=True)
check("seiffert listet", r.returncode == 0 and "text" in r.stdout and "0.14" in r.stdout and "Seifferts Funk" in r.stdout, r.stdout + r.stderr)
r = subprocess.run(cli + ["zeit", "a", "b c"], capture_output=True, text=True)
check("seiffert NAME startet mit Argumenten", r.returncode == 0 and open(HOME + "/zeit-args.txt").read() == "zeit a b c\n", r.stderr)
r = subprocess.run(cli + ["start", "gibtsnicht"], capture_output=True, text=True)
check("unbekanntes Programm", r.returncode == 2 and "Kein Seiffert-Programm" in r.stderr)
r = subprocess.run(cli + ["design", "indigo", "dunkel", "--json"], capture_output=True, text=True)
check("seiffert design setzt und gibt JSON", r.returncode == 0 and json.loads(r.stdout)["skin"] == "indigo" and json.loads(r.stdout)["colors"]["accent"] == "#a3aef2", r.stdout + r.stderr)
r = subprocess.run(cli + ["design"], capture_output=True, text=True)
check("seiffert design zeigt", "Indigo" in r.stdout and "Dunkel" in r.stdout, r.stdout)
r = subprocess.run(cli + ["design", "--css"], capture_output=True, text=True)
check("seiffert design --css", r.stdout.startswith(":root{--bg:#12141d") and "--accent-ink:#12163a" in r.stdout, r.stdout)
r = subprocess.run(cli + ["design", "rosa"], capture_output=True, text=True)
check("seiffert design lehnt ab", r.returncode == 2)
r = subprocess.run(cli + ["pruefe"], capture_output=True, text=True)
check("seiffert pruefe", r.returncode == 0 and "Hilfsprogramme" in r.stdout and "tesseract" in r.stdout, r.stdout + r.stderr)
# Archiv installieren
src_dir = os.path.join(HOME, "bau", "seiffert-probe"); os.makedirs(src_dir)
open(src_dir + "/install.sh", "w").write('#!/bin/sh\necho installiert > "$HOME/probe-installiert.txt"\ncp daten.txt "$HOME/probe-daten.txt"\n')
open(src_dir + "/daten.txt", "w").write("inhalt")
arch = os.path.join(HOME, "seiffert-probe.tar.gz")
with tarfile.open(arch, "w:gz") as t:
    t.add(src_dir, arcname="seiffert-probe")
r = subprocess.run(cli + ["install", arch], capture_output=True, text=True)
check("seiffert install", r.returncode == 0 and open(HOME + "/probe-daten.txt").read() == "inhalt", r.stdout + r.stderr)
check("Auspackordner entfernt", not [x for x in os.listdir(TMP) if x.startswith("seiffert-install-")])
bad = os.path.join(HOME, "seiffert-boese.tar.gz")
with tarfile.open(bad, "w:gz") as t:
    ti = tarfile.TarInfo("../../ausbruch.txt"); ti.size = 0; t.addfile(ti)
r = subprocess.run(cli + ["install", bad], capture_output=True, text=True)
check("Archiv mit Pfad nach außen abgelehnt", r.returncode == 1 and "außerhalb" in r.stderr and not os.path.exists(os.path.join(HOME, "..", "ausbruch.txt")), r.stderr)
with tarfile.open(bad, "w:gz") as t:
    ti = tarfile.TarInfo("seiffert-x/link"); ti.type = tarfile.SYMTYPE; ti.linkname = "/etc/passwd"; t.addfile(ti)
r = subprocess.run(cli + ["install", bad], capture_output=True, text=True)
check("Archiv mit Verweis abgelehnt", r.returncode == 1, r.stderr)
r = subprocess.run(cli + ["install", HOME + "/gibtsnicht.tar.gz"], capture_output=True, text=True)
check("fehlendes Archiv", r.returncode == 1)
os.makedirs(HOME + "/Downloads"); shutil.copy(arch, HOME + "/Downloads/")
r = subprocess.run(cli + ["install"], capture_output=True, text=True)
check("seiffert install ohne Angabe zeigt Downloads", "seiffert-probe.tar.gz" in r.stdout, r.stdout + r.stderr)

backend.shutdown() if hasattr(backend, "shutdown") else None
print("%d Prüfungen bestanden, %d fehlgeschlagen" % (PASS, FAIL))
shutil.rmtree(HOME, ignore_errors=True); shutil.rmtree(TMP, ignore_errors=True)
os._exit(1 if FAIL else 0)
