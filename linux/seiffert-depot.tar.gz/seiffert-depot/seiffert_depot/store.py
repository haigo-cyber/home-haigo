"""Hauptdatei und Laptop-Sicherungen.

Die Linux-App führt die Daten. Das eingebettete HTML-Tool arbeitet mit seinem localStorage, jede Änderung wird hierher
gespiegelt. Wahrheit ist die Hauptdatei depot-daten.json im Datenordner (gleiches Format wie die Drive-Datei und die
Sicherungsdatei des HTML-Tools, lässt sich also dort mit Sicherung einlesen laden). Beim Start wird der localStorage
des Tools immer aus dieser Datei gefüllt.

Laptop-Sicherung: täglich eine Kopie des Standes vor der ersten Änderung des Tages (Unterordner Sicherungen, die letzten 30),
dazu Kopien mit Zusatz (manuell, vor-leerung, vor-wiederherstellung, die letzten 20).
"""
import datetime
import hashlib
import json
import os
import re
import shutil
import threading
import time
from pathlib import Path

from .config import atomic_write

LS_KEY = 'seifferts_depot_v1'
REG_KEY = LS_KEY + '_reg'
PREV_KEY = LS_KEY + '_prev'
DK = 'seifferts_depot_drive_v1'
DEF_NAME = 'Mein Depot'
ID_RE = re.compile(r'^[A-Za-z0-9_-]{1,40}$')
MAIN = 'depot-daten.json'
BACKUP_DIR = 'Sicherungen'
KEEP_DAILY = 30
KEEP_TAGGED = 20
DAILY_RE = re.compile(r'^depot-sicherung-\d{4}-\d{2}-\d{2}\.json$')
BNAME_RE = re.compile(r'^depot-sicherung-\d{4}-\d{2}-\d{2}(-\d{4}-[a-z0-9-]{1,30})?\.json$')
TAG_RE = re.compile(r'^[a-z0-9-]{1,30}$')


def depot_key(i):
    return LS_KEY if i == 'main' else LS_KEY + '__' + i


def empty_state():
    return {'positions': [], 'txs': [], 'prices': {}, 'cash': [], 'meta': {'lastBackup': None}}


def has_data_state(s):
    return bool(isinstance(s, dict) and (s.get('positions') or s.get('txs') or s.get('cash')))


def has_data_ws(depots):
    return len(depots) > 1 or any(has_data_state(d['state']) for d in depots)


def iso_now():
    return datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + 'Z'


def parse_payload(txt):
    """Liest Hauptdatei, Drive-Datei oder Sicherungsdatei des HTML-Tools (Format 1 oder 2) in eine Liste von Depots."""
    o = json.loads(txt)
    if not isinstance(o, dict):
        raise ValueError('kein Objekt')
    if isinstance(o.get('depots'), list):
        raw = o['depots']
    else:
        st = o.get('data') if isinstance(o.get('data'), dict) else o
        raw = [{'id': 'main', 'name': DEF_NAME, 'state': st}]
    out, seen = [], set()
    for d in raw:
        if not isinstance(d, dict):
            continue
        i = str(d.get('id', ''))
        if not ID_RE.match(i) or i in seen:
            continue
        seen.add(i)
        st = d.get('state') if isinstance(d.get('state'), dict) else empty_state()
        out.append({'id': i, 'name': (str(d.get('name') or DEF_NAME).strip()[:60] or DEF_NAME), 'state': st})
    if not out:
        out = [{'id': 'main', 'name': DEF_NAME, 'state': empty_state()}]
    return out


def payload_obj(depots):
    single = len(depots) == 1 and depots[0]['id'] == 'main' and depots[0]['name'] == DEF_NAME
    o = {'app': 'seifferts-depot', 'format': 1 if single else 2, 'saved': iso_now(), 'data': depots[0]['state']}
    if not single:
        o['depots'] = [{'id': d['id'], 'name': d['name'], 'state': d['state']} for d in depots]
    return o


def _compact(o):
    return json.dumps(o, ensure_ascii=False, separators=(',', ':'))


class Store:
    def __init__(self, folder, intern_path, log=None):
        self.folder = Path(folder)
        self.intern_path = Path(intern_path)
        self.log = log or (lambda m: None)
        self.lock = threading.RLock()
        self.ls = {}
        self.intern = {}
        self.error = ''
        self.startup_notes = []
        self.external_change = False
        self._last_body = None
        self._due = None
        self._intern_due = None
        self._stop = False
        self._thread = None

    # ---------- Laden ----------
    def load(self):
        self.folder.mkdir(parents=True, exist_ok=True)
        (self.folder / BACKUP_DIR).mkdir(exist_ok=True)
        try:
            o = json.loads(self.intern_path.read_text(encoding='utf-8'))
            self.intern = o if isinstance(o, dict) else {}
        except (OSError, ValueError):
            self.intern = {}
        main = self.folder / MAIN
        depots = None
        rewrite = False
        if main.exists():
            try:
                raw = main.read_bytes()
                depots = parse_payload(raw.decode('utf-8'))
                h = hashlib.sha256(raw).hexdigest()
                if self.intern.get('hash') and self.intern['hash'] != h:
                    self.external_change = True
                    self.startup_notes.append('Die Hauptdatei wurde außerhalb der App geändert. Ihr Stand gilt und wird nach Google Drive übernommen.')
            except Exception as e:
                ts = time.strftime('%Y%m%d-%H%M%S')
                bad = main.with_name('depot-daten.defekt-%s.json' % ts)
                try:
                    os.replace(main, bad)
                except OSError:
                    pass
                note = 'Die Hauptdatei war nicht lesbar (%s) und wurde als %s zur Seite gelegt.' % (e, bad.name)
                for b in sorted((self.folder / BACKUP_DIR).glob('depot-sicherung-*.json'), reverse=True):
                    try:
                        depots = parse_payload(b.read_text(encoding='utf-8'))
                        note += ' Geladen wurde die Sicherungskopie %s.' % b.name
                        rewrite = True
                        break
                    except Exception:
                        continue
                else:
                    note += ' Es gab keine brauchbare Sicherungskopie, die Daten beginnen leer (Google Drive kann den Stand zurückholen).'
                self.startup_notes.append(note)
                self.log(note)
        active = self.intern.get('aktiv')
        self.ls = {}
        if depots:
            ids = [d['id'] for d in depots]
            if active not in ids:
                active = ids[0]
            for d in depots:
                self.ls[depot_key(d['id'])] = _compact(d['state'])
            self.ls[REG_KEY] = _compact({'depots': [{'id': d['id'], 'name': d['name']} for d in depots], 'active': active})
            self._last_body = self._body_key(depots)
        if isinstance(self.intern.get('dk'), str):
            self.ls[DK] = self.intern['dk']
        if isinstance(self.intern.get('prev'), str):
            self.ls[PREV_KEY] = self.intern['prev']
        if self.external_change and DK in self.ls:
            try:
                dk = json.loads(self.ls[DK])
                dk['dirty'] = True
                self.ls[DK] = _compact(dk)
                self.intern['dk'] = self.ls[DK]
                self._intern_due = time.monotonic()
            except ValueError:
                pass
        if rewrite:
            self.write_main(force=True)
        return self

    # ---------- Zugriff durch das Tool ----------
    def snapshot(self):
        with self.lock:
            return dict(self.ls)

    def set(self, key, val):
        with self.lock:
            self.ls[key] = val
            self._touch(key, val)

    def remove(self, key):
        with self.lock:
            self.ls.pop(key, None)
            self._touch(key, None)

    def _touch(self, key, val):
        now = time.monotonic()
        if key == DK:
            self._set_intern('dk', val)
        elif key == PREV_KEY:
            self._set_intern('prev', val)
        else:
            if key == REG_KEY and val:
                try:
                    a = json.loads(val).get('active')
                    if isinstance(a, str):
                        self._set_intern('aktiv', a)
                except ValueError:
                    pass
            self._due = now + 0.6

    def _set_intern(self, k, v):
        if v is None:
            self.intern.pop(k, None)
        else:
            self.intern[k] = v
        self._intern_due = time.monotonic() + 0.5

    # ---------- Schreiben ----------
    def depots_from_ls(self):
        try:
            reg = json.loads(self.ls.get(REG_KEY) or 'null')
        except ValueError:
            reg = None
        lst = []
        if isinstance(reg, dict) and isinstance(reg.get('depots'), list):
            for d in reg['depots']:
                if isinstance(d, dict) and ID_RE.match(str(d.get('id', ''))):
                    lst.append({'id': str(d['id']), 'name': (str(d.get('name') or DEF_NAME).strip()[:60] or DEF_NAME)})
        if not lst:
            lst = [{'id': 'main', 'name': DEF_NAME}]
        out = []
        for d in lst:
            raw = self.ls.get(depot_key(d['id']))
            try:
                st = json.loads(raw) if raw else empty_state()
            except ValueError:
                st = empty_state()
            out.append({'id': d['id'], 'name': d['name'], 'state': st if isinstance(st, dict) else empty_state()})
        return out

    @staticmethod
    def _body_key(depots):
        return json.dumps([[d['id'], d['name'], d['state']] for d in depots], sort_keys=True, ensure_ascii=False)

    def write_main(self, force=False):
        with self.lock:
            self._due = None
            try:
                depots = self.depots_from_ls()
                body = self._body_key(depots)
                main = self.folder / MAIN
                if not force and body == self._last_body and main.exists():
                    return False
                self.folder.mkdir(parents=True, exist_ok=True)
                (self.folder / BACKUP_DIR).mkdir(exist_ok=True)
                if main.exists():
                    self._daily_backup(main)
                    if not has_data_ws(depots):
                        try:
                            if has_data_ws(parse_payload(main.read_text(encoding='utf-8'))):
                                self._copy_backup(main, 'vor-leerung')
                        except Exception:
                            pass
                text = json.dumps(payload_obj(depots), ensure_ascii=False, indent=1)
                atomic_write(main, text)
                self._last_body = body
                self.intern['hash'] = hashlib.sha256(text.encode('utf-8')).hexdigest()
                self._write_intern()
                self.error = ''
                return True
            except Exception as e:
                self.error = 'Speichern in die Hauptdatei fehlgeschlagen: %s' % e
                self.log(self.error)
                self._due = time.monotonic() + 5
                return False

    def _write_intern(self):
        self._intern_due = None
        try:
            atomic_write(self.intern_path, json.dumps(self.intern, ensure_ascii=False))
        except Exception as e:
            self.error = 'Interne Einstellungen konnten nicht gespeichert werden: %s' % e
            self.log(self.error)

    def flush(self):
        with self.lock:
            if self._due is not None:
                self.write_main()
            if self._intern_due is not None:
                self._write_intern()

    def start(self):
        if self._thread:
            return
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _run(self):
        while not self._stop:
            time.sleep(0.2)
            now = time.monotonic()
            with self.lock:
                if self._due is not None and now >= self._due:
                    self.write_main()
                if self._intern_due is not None and now >= self._intern_due:
                    self._write_intern()

    def stop(self):
        self._stop = True
        self.flush()

    # ---------- Sicherungskopien auf dem Laptop ----------
    def _daily_backup(self, main):
        dst = self.folder / BACKUP_DIR / ('depot-sicherung-%s.json' % datetime.date.today().isoformat())
        if not dst.exists():
            shutil.copy2(main, dst)
            self._prune()

    def _copy_backup(self, src, tag):
        n = datetime.datetime.now()
        name = 'depot-sicherung-%s-%s-%s.json' % (n.strftime('%Y-%m-%d'), n.strftime('%H%M'), tag)
        dst = self.folder / BACKUP_DIR / name
        shutil.copy2(src, dst)
        self._prune()
        return name

    def manual_backup(self, tag='manuell'):
        if not TAG_RE.match(tag or ''):
            raise ValueError('Ungültiger Zusatz')
        with self.lock:
            self.write_main(force=True)
            if self.error:
                raise OSError(self.error)
            return self._copy_backup(self.folder / MAIN, tag)

    def _prune(self):
        files = sorted((p.name for p in (self.folder / BACKUP_DIR).glob('depot-sicherung-*.json')), reverse=True)
        daily = [f for f in files if DAILY_RE.match(f)]
        tagged = [f for f in files if not DAILY_RE.match(f)]
        for f in daily[KEEP_DAILY:] + tagged[KEEP_TAGGED:]:
            try:
                (self.folder / BACKUP_DIR / f).unlink()
            except OSError:
                pass

    def list_backups(self):
        out = []
        for p in sorted((self.folder / BACKUP_DIR).glob('depot-sicherung-*.json'), key=lambda x: x.name, reverse=True):
            if not BNAME_RE.match(p.name):
                continue
            try:
                st = p.stat()
            except OSError:
                continue
            out.append({'name': p.name, 'size': st.st_size,
                        'mtime': datetime.datetime.fromtimestamp(st.st_mtime, datetime.timezone.utc).isoformat()})
        return out

    def read_backup(self, name):
        if not BNAME_RE.match(name or ''):
            raise ValueError('Ungültiger Dateiname')
        return (self.folder / BACKUP_DIR / name).read_text(encoding='utf-8')

    def info(self):
        main = self.folder / MAIN
        zuletzt = ''
        try:
            zuletzt = datetime.datetime.fromtimestamp(main.stat().st_mtime, datetime.timezone.utc).isoformat()
        except OSError:
            pass
        bl = self.list_backups()
        return {'datenordner': str(self.folder), 'hauptdatei': str(main), 'sicherungsordner': str(self.folder / BACKUP_DIR),
                'zuletzt': zuletzt, 'anzahl': len(bl), 'neueste': bl[0]['name'] if bl else '', 'fehler': self.error,
                'extern': self.external_change}
