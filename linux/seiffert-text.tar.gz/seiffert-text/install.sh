#!/bin/bash
# Installation von Seifferts Text (ohne sudo, nach ~/.local)
set -e
HIER="$(cd "$(dirname "$0")" && pwd)"
ZIEL="$HOME/.local/share/seiffert-text"
BIN="$HOME/.local/bin"
APPS="$HOME/.local/share/applications"
ICONS="$HOME/.local/share/icons/hicolor"

echo "== Seifferts Text wird installiert =="
command -v python3 >/dev/null || { echo "python3 fehlt."; exit 1; }
mkdir -p "$ZIEL" "$BIN" "$APPS"

# Programmdateien (alte Fassung auch bei Schreibschutz ersetzen)
if [ -d "$ZIEL/app" ]; then chmod -R u+w "$ZIEL/app"; rm -rf "$ZIEL/app"; fi
mkdir -p "$ZIEL/app"
cp -r "$HIER/seiffert_text" "$ZIEL/app/"
chmod -R u+w "$ZIEL/app"
find "$ZIEL/app" -name __pycache__ -type d -prune -exec rm -rf {} +

# Python-Umgebung
if [ ! -x "$ZIEL/venv/bin/python" ]; then
  echo "Python-Umgebung wird angelegt …"
  python3 -m venv "$ZIEL/venv"
fi
if ! "$ZIEL/venv/bin/python" -c "import PySide6, openpyxl" 2>/dev/null; then
  echo "PySide6 und openpyxl werden geladen (einmalig, das kann dauern) …"
  "$ZIEL/venv/bin/pip" install --quiet --upgrade pip
  "$ZIEL/venv/bin/pip" install --quiet -r "$HIER/requirements.txt"
fi

# Startbefehl
cat > "$BIN/seiffert-text" <<STARTER
#!/bin/sh
export PYTHONPATH="$ZIEL/app\${PYTHONPATH:+:\$PYTHONPATH}"
exec "$ZIEL/venv/bin/python" -m seiffert_text "\$@"
STARTER
chmod +x "$BIN/seiffert-text"

# Symbole
for g in 32 48 64 128 256; do
  mkdir -p "$ICONS/${g}x${g}/apps"
  cp "$HIER/seiffert_text/icons/icon-$g.png" "$ICONS/${g}x${g}/apps/seiffert-text.png"
done

# Menüeintrag
cat > "$APPS/seiffert-text.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=Seifferts Text
GenericName=Textverarbeitung
Comment=Textverarbeitung für ODT, Markdown und LaTeX
Exec=$BIN/seiffert-text %F
Icon=seiffert-text
Terminal=false
Categories=Office;WordProcessor;
StartupWMClass=seiffert-text
MimeType=application/vnd.oasis.opendocument.text;text/markdown;text/x-tex;application/vnd.openxmlformats-officedocument.wordprocessingml.document;application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;application/vnd.oasis.opendocument.spreadsheet;application/msword;application/vnd.ms-excel;
DESKTOP
command -v update-desktop-database >/dev/null && update-desktop-database "$APPS" 2>/dev/null || true
command -v gtk-update-icon-cache >/dev/null && gtk-update-icon-cache -q -t "$ICONS" 2>/dev/null || true

# Hilfsprogramm zum Entfernen
cat > "$ZIEL/uninstall.sh" <<UNINST
#!/bin/bash
rm -rf "$ZIEL" "$BIN/seiffert-text" "$APPS/seiffert-text.desktop"
for g in 32 48 64 128 256; do rm -f "$ICONS/\${g}x\${g}/apps/seiffert-text.png"; done
echo "Seifferts Text wurde entfernt. Einstellungen liegen noch in ~/.config/seiffert-text."
UNINST
chmod +x "$ZIEL/uninstall.sh"

echo
echo "Fertig. Start über das Menü (Büro) oder im Terminal mit: seiffert-text"
case ":$PATH:" in *":$BIN:"*) ;; *) echo "Hinweis: $BIN steht nicht im PATH." ;; esac
command -v pdflatex >/dev/null || echo "Hinweis: pdflatex wurde nicht gefunden. Für die PDF-Vorschau wird TeX Live benötigt."
command -v soffice >/dev/null || echo "Hinweis: LibreOffice wurde nicht gefunden. Es wird nur für doc, xls, rtf, sxw, ppt und den Word-Export gebraucht."
