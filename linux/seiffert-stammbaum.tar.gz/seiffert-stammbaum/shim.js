/* Nachbildung der Browser-Funktionen, die QtWebEngine nicht kennt.
   Wird vor dem Stammbaum-Code geladen; die HTML-Datei bleibt unveraendert.
   Dateien und Ordner: File-System-Access-API ueber Pfade in Python.
   Google: Nachbildung von google.accounts.oauth2 (Anmeldung ueber die Seite des Tools im normalen Browser).
   Netz: Aufrufe an www.googleapis.com laufen ueber Python.
   Gespeicherte Handles (IndexedDB) bestehen nur aus Pfad und Name und werden beim Lesen wiederhergestellt. */
(function () {
  "use strict";
  if (window.__stShim) return;
  window.__stShim = true;

  /* ---------- Verbindung zu Python ---------- */
  let bridge = null;
  const ready = new Promise((res) => {
    (function init() {
      if (typeof qt !== "undefined" && qt.webChannelTransport && typeof QWebChannel === "function") {
        new QWebChannel(qt.webChannelTransport, (ch) => { bridge = ch.objects.bridge; hook(); res(); });
      } else setTimeout(init, 5);
    })();
  });
  const call = (name, ...args) => ready.then(() => new Promise((res) => bridge[name](...args, res)));
  const J = async (name, ...args) => { const r = await call(name, ...args); return r ? JSON.parse(r) : null; };
  const pend = new Map();
  let rid = 0;
  function hook() {
    bridge.httpDone.connect((id, s) => { const p = pend.get(id); if (p) { pend.delete(id); p(JSON.parse(s)); } });
    bridge.authDone.connect((id, s) => { const p = pend.get(id); if (p) { pend.delete(id); p(JSON.parse(s)); } });
  }

  function b64(u8) {
    let s = "";
    for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
    return btoa(s);
  }
  function unb64(s) {
    const bin = atob(s), u8 = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
    return u8;
  }
  async function bytesOf(data) {
    if (data == null) return new Uint8Array(0);
    if (typeof data === "string") return new TextEncoder().encode(data);
    if (data instanceof Blob) return new Uint8Array(await data.arrayBuffer());
    if (data instanceof ArrayBuffer) return new Uint8Array(data);
    if (ArrayBuffer.isView(data)) return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
    if (data && data.type === "write") return bytesOf(data.data);
    throw new TypeError("Nicht unterstuetzter Datentyp beim Schreiben");
  }
  const dom = (name, msg) => new DOMException(msg || name, name);
  const joinP = (a, b) => (a.endsWith("/") ? a : a + "/") + b;
  const MIME = { ged: "text/plain", gedcom: "text/plain", txt: "text/plain", json: "application/json", pdf: "application/pdf",
    jpg: "image/jpeg", jpeg: "image/jpeg", png: "image/png", gif: "image/gif", webp: "image/webp", tif: "image/tiff", tiff: "image/tiff",
    bmp: "image/bmp", svg: "image/svg+xml", html: "text/html", htm: "text/html", md: "text/markdown", csv: "text/csv" };
  const mimeOf = (n) => MIME[(n.split(".").pop() || "").toLowerCase()] || "";

  /* ---------- Handles ---------- */
  class FSBase {
    constructor(kind, path, name) { this.__fsh = kind; this.path = path; this.name = name; }
    get kind() { return this.__fsh; }
    async isSameEntry(o) { return !!o && o.path === this.path; }
    async queryPermission() { return "granted"; }
    async requestPermission() { return "granted"; }
  }
  class FileHandle extends FSBase {
    constructor(path, name) { super("file", path, name); }
    async getFile() {
      const st = await J("stat", this.path);
      if (!st || !st.exists || st.isDir) throw dom("NotFoundError", "Datei nicht gefunden: " + this.name);
      const r = await fetch("/__fs/read?p=" + encodeURIComponent(this.path));
      if (!r.ok) throw dom("NotAllowedError", "Datei nicht lesbar: " + this.name);
      const blob = await r.blob();
      return new File([blob], this.name, { lastModified: st.mtime, type: mimeOf(this.name) });
    }
    async createWritable() {
      const path = this.path, chunks = [];
      return {
        async write(d) { chunks.push(await bytesOf(d)); },
        async seek() {}, async truncate() {},
        async close() {
          let n = 0; for (const c of chunks) n += c.length;
          const all = new Uint8Array(n); let o = 0;
          for (const c of chunks) { all.set(c, o); o += c.length; }
          const r = await J("writeFile", path, b64(all));
          if (r && r.error) throw dom("NotAllowedError", r.error);
        },
        async abort() { chunks.length = 0; }
      };
    }
  }
  class DirHandle extends FSBase {
    constructor(path, name) { super("directory", path, name); }
    async *entries() {
      const l = await J("listDir", this.path);
      if (!l || l.error) throw dom("NotAllowedError", (l && l.error) || "Ordner nicht lesbar");
      for (const e of l) yield [e.name, e.kind === "directory" ? new DirHandle(joinP(this.path, e.name), e.name) : new FileHandle(joinP(this.path, e.name), e.name)];
    }
    [Symbol.asyncIterator]() { return this.entries(); }
    async *keys() { for await (const [n] of this.entries()) yield n; }
    async *values() { for await (const [, h] of this.entries()) yield h; }
    async getFileHandle(name, o) {
      const p = joinP(this.path, name), st = await J("stat", p);
      if (st && st.exists) { if (st.isDir) throw dom("TypeMismatchError"); return new FileHandle(p, name); }
      if (!(o && o.create)) throw dom("NotFoundError", name);
      const r = await J("writeFile", p, "");
      if (r && r.error) throw dom("NotAllowedError", r.error);
      return new FileHandle(p, name);
    }
    async getDirectoryHandle(name, o) {
      const p = joinP(this.path, name), st = await J("stat", p);
      if (st && st.exists) { if (!st.isDir) throw dom("TypeMismatchError"); return new DirHandle(p, name); }
      if (!(o && o.create)) throw dom("NotFoundError", name);
      const r = await J("makeDir", p);
      if (r && r.error) throw dom("NotAllowedError", r.error);
      return new DirHandle(p, name);
    }
    async removeEntry(name, o) {
      const r = await J("removeEntry", joinP(this.path, name), !!(o && o.recursive));
      if (r && r.error) throw dom("NotAllowedError", r.error);
    }
    async resolve(h) {
      if (!h || !h.path) return null;
      if (h.path === this.path) return [];
      const pre = this.path.endsWith("/") ? this.path : this.path + "/";
      return h.path.startsWith(pre) ? h.path.slice(pre.length).split("/") : null;
    }
  }
  window.FileSystemFileHandle = FileHandle;
  window.FileSystemDirectoryHandle = DirHandle;

  function filtersOf(types) {
    const out = [];
    for (const t of types || []) {
      const ex = [];
      for (const k in (t.accept || {})) for (const e of t.accept[k]) ex.push("*" + e);
      if (ex.length) out.push((t.description || "Dateien") + " (" + ex.join(" ") + ")");
    }
    return out;
  }
  const opts = (o) => JSON.stringify({ filters: filtersOf(o && o.types), multiple: !!(o && o.multiple), id: (o && o.id) || "",
    startIn: (o && o.startIn && o.startIn.path) || "", suggestedName: (o && o.suggestedName) || "" });
  window.showOpenFilePicker = async (o) => {
    const r = await J("pickOpen", opts(o));
    if (!r || !r.length) throw dom("AbortError", "Abgebrochen");
    return r.map((x) => new FileHandle(x.path, x.name));
  };
  window.showSaveFilePicker = async (o) => {
    const r = await J("pickSave", opts(o));
    if (!r) throw dom("AbortError", "Abgebrochen");
    return new FileHandle(r.path, r.name);
  };
  window.showDirectoryPicker = async (o) => {
    const r = await J("pickDir", opts(o));
    if (!r) throw dom("AbortError", "Abgebrochen");
    return new DirHandle(r.path, r.name);
  };

  /* Gespeicherte Handles (IndexedDB) bestehen nach dem Klonen nur noch aus Daten. Beim Lesen wieder zu Handles machen. */
  function revive(v) {
    if (v && typeof v === "object") {
      if (Array.isArray(v)) return v.some((x) => x && x.__fsh) ? v.map(revive) : v;
      if (v.__fsh && Object.getPrototypeOf(v) === Object.prototype) return v.__fsh === "directory" ? new DirHandle(v.path, v.name) : new FileHandle(v.path, v.name);
    }
    return v;
  }
  try {
    const d = Object.getOwnPropertyDescriptor(IDBRequest.prototype, "result");
    Object.defineProperty(IDBRequest.prototype, "result", { configurable: true, enumerable: d.enumerable, get() { return revive(d.get.call(this)); } });
  } catch (e) {}

  /* ---------- Netz: Google-APIs ueber Python ---------- */
  const realFetch = window.fetch.bind(window);
  async function proxyFetch(url, init) {
    const method = (init.method || "GET").toUpperCase();
    const headers = {};
    const h = init.headers;
    if (h) { if (typeof h.forEach === "function" && !Array.isArray(h)) h.forEach((v, k) => { headers[k] = v; }); else if (Array.isArray(h)) h.forEach(([k, v]) => { headers[k] = v; }); else Object.assign(headers, h); }
    const body = init.body == null ? "" : b64(await bytesOf(init.body));
    await ready;
    const id = ++rid;
    const res = await new Promise((resolve) => { pend.set(id, resolve); bridge.httpStart(id, JSON.stringify({ url, method, headers, body })); });
    if (res.error) throw new TypeError("Netzwerkfehler: " + res.error);
    if (res.status === 401) bridge.forgetToken();
    const nb = res.status === 204 || res.status === 205 || res.status === 304;
    return new Response(nb ? null : unb64(res.body), { status: res.status, headers: res.headers });
  }
  window.fetch = function (input, init) {
    const url = typeof input === "string" ? input : (input && input.url) || "";
    if (/^https:\/\/www\.googleapis\.com\//.test(url)) return proxyFetch(url, init || (typeof input === "object" && input) || {});
    return realFetch(input, init);
  };

  /* ---------- Google-Anmeldung ---------- */
  window.google = { accounts: { oauth2: {
    initTokenClient(cfg) {
      return { requestAccessToken(o) {
        ready.then(() => {
          const id = ++rid;
          pend.set(id, (r) => {
            if (r && r.access_token) { if (cfg.callback) cfg.callback({ access_token: r.access_token, expires_in: r.expires_in, token_type: "Bearer", scope: cfg.scope }); }
            else if (cfg.error_callback) cfg.error_callback({ type: (r && r.error) || "popup_closed", message: (r && r.message) || "Anmeldung fehlgeschlagen" });
          });
          bridge.authStart(id, cfg.client_id || "", cfg.scope || "", JSON.stringify({ gesture: !!(navigator.userActivation && navigator.userActivation.isActive) }));
        });
      } };
    },
    revoke(t, done) { if (done) done({}); }
  } } };

  /* ---------- Kartenbibliothek aus dem Programmpaket statt aus dem Netz ---------- */
  const LEAF = /^https:\/\/cdnjs\.cloudflare\.com\/ajax\/libs\/leaflet\/1\.9\.4\/leaflet\.min\.(js|css)$/;
  const mapLeaf = (u) => { const m = LEAF.exec(u); return m ? "/vendor/leaflet/leaflet." + m[1] : u; };
  try {
    const sd = Object.getOwnPropertyDescriptor(HTMLScriptElement.prototype, "src");
    Object.defineProperty(HTMLScriptElement.prototype, "src", { configurable: true, enumerable: sd.enumerable, get() { return sd.get.call(this); }, set(v) { sd.set.call(this, mapLeaf(String(v))); } });
    const ld = Object.getOwnPropertyDescriptor(HTMLLinkElement.prototype, "href");
    Object.defineProperty(HTMLLinkElement.prototype, "href", { configurable: true, enumerable: ld.enumerable, get() { return ld.get.call(this); }, set(v) { ld.set.call(this, mapLeaf(String(v))); } });
  } catch (e) {}

  /* ---------- Drucken als PDF ---------- */
  window.print = () => { ready.then(() => bridge.printPdf()); };
})();
