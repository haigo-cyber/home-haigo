"""Seifferts ToDo als Linux-Programm (PySide6 mit QtWebEngine)."""
import json
import os
import sys
import urllib.parse
from pathlib import Path

from . import __version__
from . import server as srv


def _chromium_flags():
    flags = os.environ.get("QTWEBENGINE_CHROMIUM_FLAGS", "")
    try:
        if srv.Settings().get("software_rendering") and "--disable-gpu" not in flags:
            flags += " --disable-gpu"
    except Exception:
        pass
    os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = flags.strip()


def main(driver=None):
    _chromium_flags()
    from PySide6.QtCore import Qt, QTimer, QUrl, QLockFile, Signal, QObject, QSize
    from PySide6.QtGui import QAction, QDesktopServices, QIcon, QKeySequence
    from PySide6.QtWidgets import (QApplication, QFileDialog, QInputDialog, QMainWindow, QMessageBox,
                                   QPlainTextEdit, QDialog, QVBoxLayout, QLabel, QDialogButtonBox)
    from PySide6.QtWebEngineCore import (QWebEnginePage, QWebEngineProfile, QWebEngineSettings,
                                         QWebEngineUrlRequestInterceptor)
    from PySide6.QtWebEngineWidgets import QWebEngineView

    ALLOWED_HOSTS = {"127.0.0.1", "localhost", "cdn.jsdelivr.net"}   # jsdelivr: PDF-Anzeige im Arbeitsbereich

    class Interceptor(QWebEngineUrlRequestInterceptor):
        def interceptRequest(self, info):
            u = info.requestUrl()
            if u.scheme() in ("http", "https", "ws", "wss", "ftp") and u.host() not in ALLOWED_HOSTS:
                info.block(True)

    class Page(QWebEnginePage):
        def __init__(self, profile, parent=None):
            super().__init__(profile, parent)
            try:
                self.permissionRequested.connect(self._perm)
            except Exception:
                pass

        def _perm(self, perm):
            try:
                name = str(perm.permissionType()).lower()
                if "clipboard" in name:
                    perm.grant()
                else:
                    perm.deny()
            except Exception:
                pass

        def acceptNavigationRequest(self, url, nav_type, is_main):
            if is_main and url.scheme() in ("http", "https") and url.host() not in ("127.0.0.1", "localhost"):
                QDesktopServices.openUrl(url)
                return False
            return super().acceptNavigationRequest(url, nav_type, is_main)

        def createWindow(self, _type):
            tmp = QWebEnginePage(self.profile(), self)
            tmp.urlChanged.connect(lambda u: (QDesktopServices.openUrl(u) if u.scheme() in ("http", "https") else None,
                                              tmp.deleteLater()))
            return tmp

    class Bridge(QObject):
        login_requested = Signal(str, str)

    def app_icon():
        ic = QIcon()
        for n in (16, 22, 24, 32, 48, 64, 128, 256):
            f = Path(__file__).with_name("icons") / f"seiffert-todo-{n}.png"
            if f.exists():
                ic.addFile(str(f), QSize(n, n))
        return ic

    class Main(QMainWindow):
        def __init__(self, app_srv, no_browser=False):
            super().__init__()
            self.srv = app_srv
            self.no_browser = no_browser
            self.closing = False
            self.bridge = Bridge()
            self.bridge.login_requested.connect(self.on_login)
            self.srv.auth.on_login = lambda state, scope: self.bridge.login_requested.emit(state, scope)
            self.setWindowTitle("Seifferts ToDo")
            self.resize(1180, 820)
            self.setWindowIcon(app_icon())
            self.profile = QWebEngineProfile(self)           # ohne Namen: nichts bleibt im Browserprofil liegen
            self.interceptor = Interceptor(self)
            self.profile.setUrlRequestInterceptor(self.interceptor)
            self.profile.downloadRequested.connect(self.on_download)
            self.page = Page(self.profile, self)
            st = self.page.settings()
            for attr in ("JavascriptCanAccessClipboard", "JavascriptCanPaste"):
                try:
                    st.setAttribute(getattr(QWebEngineSettings.WebAttribute, attr), True)
                except Exception:
                    pass
            self.view = QWebEngineView(self)
            self.view.setPage(self.page)
            self.setCentralWidget(self.view)
            self.view.setZoomFactor(float(self.srv.settings.get("zoom") or 1.0))
            self.build_menu()
            self.view.load(QUrl(self.srv.url()))

        # ---- Menü
        def act(self, menu, text, fn, shortcut=None, checkable=False, checked=False):
            a = QAction(text, self)
            if shortcut:
                a.setShortcut(QKeySequence(shortcut))
            if checkable:
                a.setCheckable(True)
                a.setChecked(checked)
                a.toggled.connect(fn)
            else:
                a.triggered.connect(lambda *_: fn())
            menu.addAction(a)
            return a

        def js(self, code, cb=None):
            if cb:
                self.page.runJavaScript(code, cb)
            else:
                self.page.runJavaScript(code)

        def build_menu(self):
            m = self.menuBar().addMenu("&Datei")
            self.act(m, "Jetzt abgleichen", lambda: self.js("window.__linuxSyncNow && window.__linuxSyncNow(true)"), "Ctrl+R")
            self.act(m, "Neu bei Google anmelden", lambda: self.js("window.__linuxForceLogin && window.__linuxForceLogin()"))
            self.act(m, "Google-Anmelde-Adresse ändern …", lambda: self.ask_handoff_url(force=True))
            m.addSeparator()
            self.act(m, "Beim Start automatisch anmelden", lambda v: self.srv.settings.set("auto_anmelden", bool(v)),
                     checkable=True, checked=bool(self.srv.settings.get("auto_anmelden")))
            self.act(m, "Anmeldung für einen Neustart merken (etwa eine Stunde)", self.set_token_merken,
                     checkable=True, checked=bool(self.srv.settings.get("token_merken")))
            m.addSeparator()
            self.act(m, "Lokale Kopien öffnen (Ordner)", lambda: self.open_path(srv.KOPIEN_DIR))
            self.act(m, "Datenordner öffnen", lambda: self.open_path(srv.DATA_DIR))
            self.act(m, "Protokoll öffnen", lambda: self.open_path(srv.DATA_DIR / "protokoll.txt"))
            m.addSeparator()
            self.act(m, "Beenden", self.close, "Ctrl+Q")
            v = self.menuBar().addMenu("&Ansicht")
            self.act(v, "Vergrößern", lambda: self.zoom(+0.1), "Ctrl++")
            self.act(v, "Verkleinern", lambda: self.zoom(-0.1), "Ctrl+-")
            self.act(v, "Normale Größe", lambda: self.zoom(0), "Ctrl+0")
            self.act(v, "Seite neu laden", self.view.reload, "Ctrl+Shift+R")
            h = self.menuBar().addMenu("&Hilfe")
            self.act(h, "Fehlersuche bei der Anmeldung", self.help_login)
            self.act(h, "Über", self.about)

        def set_token_merken(self, v):
            self.srv.settings.set("token_merken", bool(v))
            if not v:
                self.srv.auth._forget_file()

        def zoom(self, d):
            z = 1.0 if d == 0 else max(0.5, min(3.0, round(self.view.zoomFactor() + d, 2)))
            self.view.setZoomFactor(z)
            self.srv.settings.set("zoom", z)

        def open_path(self, p):
            p = Path(p)
            if p.suffix == "":
                p.mkdir(parents=True, exist_ok=True)
            if not QDesktopServices.openUrl(QUrl.fromLocalFile(str(p))):
                QMessageBox.information(self, "Seifferts ToDo", f"Bitte von Hand öffnen:\n{p}")

        def help_login(self):
            QMessageBox.information(self, "Fehlersuche bei der Anmeldung",
                "Wenn nach dem Klick auf Anmelden nur die normale ToDo-Seite im Browser erscheint oder die App endlos wartet:\n\n"
                "1. Protokoll lesen (Datei, Protokoll öffnen). Dort steht bei jedem Versuch, was geschah.\n"
                "2. Prüfen, ob die Anmelde-Adresse stimmt (Datei, Google-Anmelde-Adresse ändern). Es ist die Adresse der "
                "veröffentlichten ToDo-Seite auf GitHub Pages, ohne Anhang wie #daten.\n"
                "3. Prüfen, ob auf GitHub Pages die neue index.html mit dem Block linuxHandOff liegt.\n\n"
                "Die Anmeldung gilt etwa eine Stunde. Danach zeigt die Anzeige oben rechts, dass sie erneuert werden muss.")

        def about(self):
            QMessageBox.information(self, "Seifferts ToDo",
                f"Seifferts ToDo für Linux, Version {__version__}\n\nGoogle (Tabelle, Drive, Kalender, Tasks) bleibt führend. "
                "Die App holt beim Start den Stand, schreibt Änderungen sofort zurück und gleicht regelmäßig ab.")

        # ---- Anmeldung über den Browser
        def ask_handoff_url(self, force=False):
            cur = self.srv.settings.get("handoff_url") or ""
            env = os.environ.get("SEIFFERT_TODO_HANDOFF_URL")
            if env and not force:
                return env
            if cur and not force:
                u, err = srv.clean_handoff_url(cur)
                if not err:
                    if u != cur:
                        self.srv.settings.set("handoff_url", u)
                    return u
            text = cur
            while True:
                text, ok = QInputDialog.getText(
                    self, "Google-Anmelde-Adresse",
                    "Internetadresse der veröffentlichten ToDo-Seite (GitHub Pages):\n"
                    "Über sie wird die Anmeldung bei Google abgewickelt. Sie wird nur einmal abgefragt.",
                    text=text)
                if not ok:
                    return ""
                u, err = srv.clean_handoff_url(text)
                if err:
                    QMessageBox.warning(self, "Adresse prüfen", err)
                    continue
                self.srv.settings.set("handoff_url", u)
                return u

        def on_login(self, state, scope):
            url = self.ask_handoff_url()
            if not url:
                self.srv.auth.fail(state, "Keine Anmelde-Adresse eingegeben")
                return
            q = urllib.parse.urlencode({"linuxport": self.srv.port, "linuxstate": state, "linuxscope": scope})
            full = url + ("&" if "?" in url else "?") + q
            srv.log("Anmelde-Adresse: " + url)
            if self.no_browser:
                (srv.DATA_DIR / "test-login-url.txt").write_text(full, "utf-8")
                return
            if not QDesktopServices.openUrl(QUrl(full)):
                dlg = QDialog(self)
                dlg.setWindowTitle("Anmeldung im Browser")
                lay = QVBoxLayout(dlg)
                lay.addWidget(QLabel("Der Browser ließ sich nicht öffnen. Bitte diese Adresse von Hand im Browser öffnen:"))
                box = QPlainTextEdit(full)
                box.setReadOnly(True)
                lay.addWidget(box)
                bb = QDialogButtonBox(QDialogButtonBox.Ok)
                bb.accepted.connect(dlg.accept)
                lay.addWidget(bb)
                dlg.resize(640, 220)
                dlg.exec()

        # ---- Downloads
        def on_download(self, d):
            name = d.downloadFileName() or "datei"
            start = Path.home() / "Dokumente" if (Path.home() / "Dokumente").exists() else Path.home()
            path, _ = QFileDialog.getSaveFileName(self, "Speichern unter", str(start / name))
            if not path:
                d.cancel()
                return
            p = Path(path)
            d.setDownloadDirectory(str(p.parent))
            d.setDownloadFileName(p.name)
            d.accept()

        # ---- Beenden: erst alles zu Google schreiben
        def closeEvent(self, ev):
            if self.closing:
                ev.accept()
                return
            ev.ignore()
            self.closing = True
            self._answered = False
            self._attempt = getattr(self, "_attempt", 0) + 1
            n = self._attempt
            QTimer.singleShot(4000, lambda: n == self._attempt and self._pending_answer(None))
            self.js("window.__linuxPending ? window.__linuxPending() : null", self._pending_answer)

        def _pending_answer(self, res):
            if self._answered:
                return
            self._answered = True
            try:
                j = json.loads(res) if res else {}
            except Exception:
                j = {}
            if not j.get("pending"):
                return self.finish()
            if not j.get("tokenOk", True):
                return self.ask_force("Es gibt Änderungen, die noch nicht in Google gesichert sind, und die Anmeldung ist abgelaufen.")
            self.setWindowTitle("Seifferts ToDo – sichere Änderungen …")
            self.js("window.__linuxFlushStart && window.__linuxFlushStart()")
            self._tries = 0
            self._poll()

        def _poll(self):
            self._tries += 1
            if self._tries > 60:
                return self.ask_force("Das Sichern in Google dauert zu lange.")
            self.js("window.__linuxFlushState ? window.__linuxFlushState() : 'ok'", self._poll_answer)

        def _poll_answer(self, st):
            st = st or ""
            if st == "ok":
                return self.finish()
            if st.startswith("fail"):
                return self.ask_force("Nicht alle Änderungen konnten in Google gesichert werden (" + st[5:] + ").")
            QTimer.singleShot(300, self._poll)

        def ask_force(self, why):
            self.setWindowTitle("Seifferts ToDo")
            r = QMessageBox.question(self, "Nicht alles gesichert",
                                     why + "\n\nDie Änderungen bleiben in der lokalen Sicherung der Seite, werden aber erst beim nächsten Start "
                                     "wieder nach Google geschrieben, wenn du dann angemeldet bist.\n\nTrotzdem beenden?",
                                     QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if r == QMessageBox.Yes:
                self.finish()
            else:
                self.closing = False

        def finish(self):
            self.js("window.__linuxLsFlush && window.__linuxLsFlush()")
            QTimer.singleShot(500, self._really_close)

        def _really_close(self):
            self.srv.stop()
            self.closing = True
            self.close()
            QApplication.quit()

    # ---- Start
    app = QApplication(sys.argv)
    app.setApplicationName("seiffert-todo")
    app.setDesktopFileName("seiffert-todo")
    app.setWindowIcon(app_icon())
    srv.DATA_DIR.mkdir(parents=True, exist_ok=True)
    lock = QLockFile(str(srv.DATA_DIR / "app.lock"))
    lock.setStaleLockTime(0)
    if not lock.tryLock(100):
        QMessageBox.information(None, "Seifferts ToDo", "Seifferts ToDo läuft schon.")
        return 1
    html = None
    hp = srv.Settings().get("html_datei")
    if hp and Path(hp).exists():
        html = hp
    s = srv.App(html_path=html)
    s.start()
    w = Main(s, no_browser=bool(os.environ.get("SEIFFERT_TODO_NO_BROWSER")))
    w.show()
    if driver:
        import threading
        threading.Thread(target=driver, args=(w, s, app), daemon=True).start()
    code = app.exec()
    lock.unlock()
    return code
