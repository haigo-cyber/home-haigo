#!/usr/bin/env bash
# Seifferts Zeit: Installation ohne sudo nach ~/.local
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
APP=seiffert-zeit
DATA="${XDG_DATA_HOME:-$HOME/.local/share}/$APP"
BIN="$HOME/.local/bin"
APPS="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
ICONS="${XDG_DATA_HOME:-$HOME/.local/share}/icons/hicolor"

command -v python3 >/dev/null || { echo "python3 fehlt (Arch: sudo pacman -S python)"; exit 1; }
mkdir -p "$DATA" "$BIN" "$APPS"

echo "== Python-Umgebung"
if [ ! -x "$DATA/venv/bin/python" ]; then
  if [ "${SZ_NO_PIP:-}" = "1" ]; then python3 -m venv --system-site-packages "$DATA/venv"; else python3 -m venv "$DATA/venv" || { echo "python3 -m venv fehlgeschlagen (Debian und Ubuntu: sudo apt install python3-venv)"; exit 1; }; fi
fi
if [ "${SZ_NO_PIP:-}" != "1" ]; then
  "$DATA/venv/bin/pip" install --upgrade pip -q
  "$DATA/venv/bin/pip" install -q PySide6-Essentials PySide6-WebEngine
  if ! "$DATA/venv/bin/python" -c "from PySide6.QtWebEngineWidgets import QWebEngineView" 2>/dev/null; then
    "$DATA/venv/bin/pip" install -q PySide6-Addons
  fi
fi
"$DATA/venv/bin/python" -c "from PySide6.QtWebEngineWidgets import QWebEngineView; print('QtWebEngine in Ordnung')"

echo "== Programmdateien"
chmod -R u+w "$DATA/app" 2>/dev/null || true
rm -rf "$DATA/app"
mkdir -p "$DATA/app"
cp -r "$HERE/seiffert_zeit" "$DATA/app/"
chmod -R u+w "$DATA/app"
cp "$HERE/uninstall.sh" "$HERE/INSTALLATION.txt" "$DATA/" 2>/dev/null || true

cat > "$BIN/seiffert-zeit" <<LAUNCH
#!/usr/bin/env bash
export PYTHONPATH="$DATA/app\${PYTHONPATH:+:\$PYTHONPATH}"
exec "$DATA/venv/bin/python" -m seiffert_zeit "\$@"
LAUNCH
chmod +x "$BIN/seiffert-zeit"

echo "== Menüeintrag und Symbol"
for n in 16 22 24 32 48 64 128 256; do
  mkdir -p "$ICONS/${n}x${n}/apps"
  cp "$HERE/seiffert_zeit/icons/icon-$n.png" "$ICONS/${n}x${n}/apps/seiffert-zeit.png"
done
cat > "$APPS/seiffert-zeit.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=Seifferts Zeit
GenericName=Arbeitszeiterfassung
Comment=Arbeitszeit in Schulstunden erfassen und auswerten
Exec=$BIN/seiffert-zeit
Icon=seiffert-zeit
Terminal=false
Categories=Office;
StartupWMClass=seiffert-zeit
DESK
command -v update-desktop-database >/dev/null && update-desktop-database "$APPS" 2>/dev/null || true
command -v gtk-update-icon-cache >/dev/null && gtk-update-icon-cache -q -t "$ICONS" 2>/dev/null || true

echo
echo "Fertig. Start: Menü Büro, Seifferts Zeit, oder im Terminal: seiffert-zeit"
case ":$PATH:" in *":$BIN:"*) ;; *) echo "Hinweis: $BIN steht nicht im PATH (der Menüeintrag funktioniert trotzdem).";; esac
