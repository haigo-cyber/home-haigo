from PIL import Image, ImageDraw
import math, os
os.makedirs("seiffert_zeit/icons", exist_ok=True)
S = 1024
im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
d = ImageDraw.Draw(im)
d.rounded_rectangle([40, 40, S - 40, S - 40], radius=200, fill=(47, 111, 159, 255))
cx = cy = S // 2
d.ellipse([cx - 340, cy - 340, cx + 340, cy + 340], fill=(255, 255, 255, 255))
for i in range(12):
    a = i * math.pi / 6
    r0, r1 = (270, 320) if i % 3 == 0 else (295, 320)
    d.line([cx + r0 * math.sin(a), cy - r0 * math.cos(a), cx + r1 * math.sin(a), cy - r1 * math.cos(a)], fill=(47, 111, 159, 255), width=22 if i % 3 == 0 else 12)
d.line([cx, cy, cx, cy - 230], fill=(31, 35, 40, 255), width=34)
d.line([cx, cy, cx + 160, cy + 60], fill=(224, 138, 30, 255), width=34)
d.ellipse([cx - 28, cy - 28, cx + 28, cy + 28], fill=(31, 35, 40, 255))
for n in (16, 22, 24, 32, 48, 64, 128, 256):
    im.resize((n, n), Image.LANCZOS).save("seiffert_zeit/icons/icon-%d.png" % n)
