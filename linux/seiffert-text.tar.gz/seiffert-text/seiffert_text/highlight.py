"""Syntaxfärbung für LaTeX und Markdown."""
import re

from PySide6.QtCore import QRegularExpression
from PySide6.QtGui import QColor, QFont, QSyntaxHighlighter, QTextCharFormat


def _fmt(color, bold=False, italic=False):
    f = QTextCharFormat()
    f.setForeground(QColor(color))
    if bold:
        f.setFontWeight(QFont.Weight.Bold)
    if italic:
        f.setFontItalic(True)
    return f


def palette(dark):
    if dark:
        return dict(cmd="#7ab7ff", env="#e6c07b", comment="#7f8c8d", math="#c3a6ff", brace="#d19a66",
                    head="#7ab7ff", code="#98c379", link="#61afef", mark="#e5c07b")
    return dict(cmd="#0b5ea8", env="#9a5b00", comment="#7a7a7a", math="#6f42c1", brace="#b05a00",
                head="#0b5ea8", code="#2e7d32", link="#1a5fb4", mark="#9a5b00")


class LatexHighlighter(QSyntaxHighlighter):
    def __init__(self, doc, dark=False):
        super().__init__(doc)
        self.set_dark(dark)

    def set_dark(self, dark):
        p = palette(dark)
        self.f = {k: _fmt(v, bold=k in ("env", "head")) for k, v in p.items()}
        self.f["comment"] = _fmt(p["comment"], italic=True)
        self.rehighlight()

    def highlightBlock(self, text):
        for m in re.finditer(r"\\[A-Za-z@]+\*?|\\.", text):
            self.setFormat(m.start(), m.end() - m.start(), self.f["cmd"])
        for m in re.finditer(r"\\(?:begin|end)\{[^}]*\}", text):
            self.setFormat(m.start(), m.end() - m.start(), self.f["env"])
        for m in re.finditer(r"(?<!\\)\$\$?[^$]*\$\$?", text):
            self.setFormat(m.start(), m.end() - m.start(), self.f["math"])
        for m in re.finditer(r"[{}\[\]]", text):
            self.setFormat(m.start(), 1, self.f["brace"])
        m = re.search(r"(?<!\\)%.*$", text)
        if m:
            self.setFormat(m.start(), m.end() - m.start(), self.f["comment"])


class MarkdownHighlighter(QSyntaxHighlighter):
    def __init__(self, doc, dark=False):
        super().__init__(doc)
        self.set_dark(dark)

    def set_dark(self, dark):
        p = palette(dark)
        self.f = {"head": _fmt(p["head"], bold=True), "code": _fmt(p["code"]), "link": _fmt(p["link"]),
                  "mark": _fmt(p["mark"], bold=True), "bold": _fmt(p["cmd"], bold=True),
                  "ital": _fmt(p["cmd"], italic=True), "quote": _fmt(p["comment"], italic=True)}
        self.rehighlight()

    def highlightBlock(self, text):
        if re.match(r"^\s{0,3}#{1,6}\s", text):
            self.setFormat(0, len(text), self.f["head"])
            return
        if re.match(r"^\s*>", text):
            self.setFormat(0, len(text), self.f["quote"])
        if text.startswith("```") or text.startswith("~~~"):
            self.setFormat(0, len(text), self.f["code"])
        m = re.match(r"^\s*(?:[-*+]|\d+[.)])\s", text)
        if m:
            self.setFormat(m.start(), m.end() - m.start(), self.f["mark"])
        for m in re.finditer(r"`[^`]+`", text):
            self.setFormat(m.start(), m.end() - m.start(), self.f["code"])
        for m in re.finditer(r"\*\*[^*]+\*\*|__[^_]+__", text):
            self.setFormat(m.start(), m.end() - m.start(), self.f["bold"])
        for m in re.finditer(r"(?<![*\w])\*[^*\s][^*]*\*(?!\*)|(?<![_\w])_[^_\s][^_]*_(?!\w)", text):
            self.setFormat(m.start(), m.end() - m.start(), self.f["ital"])
        for m in re.finditer(r"!?\[[^\]]*\]\([^)]*\)", text):
            self.setFormat(m.start(), m.end() - m.start(), self.f["link"])
        if re.match(r"^\s*\|", text):
            self.setFormat(0, len(text), self.f["mark"])
