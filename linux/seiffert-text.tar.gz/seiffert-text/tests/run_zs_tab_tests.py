"""Zuschnitt als Tab in Seifferts Text (offscreen): python tests/run_zs_tab_tests.py"""
import os
import sys
import tempfile

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import pymupdf
from PySide6.QtCore import QRectF
from PySide6.QtGui import QColor, QImage
from PySide6.QtWidgets import QApplication, QMessageBox

import seiffert_text.app as A
from seiffert_text import zs_core

tmp = tempfile.mkdtemp(prefix="zs-tab-test-")
saved = []
A.save_settings = lambda d: saved.append(dict(d))
A.load_settings = lambda: {"engine": "pdflatex", "recent": [], "foreign_to_latex": True, "zoom": 0, "auto_compile": False}
zs_core.CFG_FILE = os.path.join(tmp, "alt", "settings.json")
warns = []
QMessageBox.warning = staticmethod(lambda *a, **k: warns.append(a[2:]) or QMessageBox.Ok)
QMessageBox.information = staticmethod(lambda *a, **k: QMessageBox.Ok)
QMessageBox.question = staticmethod(lambda *a, **k: QMessageBox.Yes)
qapp = QApplication([])
ok_count, fails = 0, []


def check(name, cond, extra=""):
    global ok_count
    if cond:
        ok_count += 1
    else:
        fails.append(name)
        print("FEHLER:", name, extra)


pdf = os.path.join(tmp, "a.pdf")
doc = pymupdf.open()
for i in range(3):
    p = doc.new_page(width=600, height=800)
    p.insert_text((50, 60), f"Seite {i + 1}", fontsize=14)
doc.save(pdf)
png = os.path.join(tmp, "b.png")
im = QImage(300, 200, QImage.Format_RGB32)
im.fill(QColor("red"))
im.save(png)
jpg = os.path.join(tmp, "c.jpg")
im.save(jpg, "JPG", 95)
txt = os.path.join(tmp, "d.txt")
open(txt, "w").write("x")
bad = os.path.join(tmp, "kaputt.pdf")
open(bad, "w").write("kein pdf")

w = A.MainWindow()
w.show()
n0 = len(w.tabs)
t1 = w.open_zuschnitt_tab(pdf)
check("PDF-Tab entsteht", t1 is not None and t1.is_pdf and t1.s.get("zs") is True)
check("Tabtext mit Schere", w.tabbar.tabText(w.tabbar.count() - 1).startswith("✂ a.pdf"))
check("Tab ist aktiv", w.cur_pdf is t1)
check("Doppelt öffnen wechselt nur", w.open_zuschnitt_tab(pdf) is t1 and len(w.tabs) == n0 + 1)
w.open_file(png)
check("PNG über open_file im Zuschnitt", len(w.tabs) == n0 + 2 and w.cur_pdf.widget.kind == "img")
w.open_file(jpg)
check("JPEG über open_file im Zuschnitt", len(w.tabs) == n0 + 3 and w.cur_pdf.widget.kind == "img")
check("Text-Datei wird abgelehnt", w.open_zuschnitt_tab(txt) is None and len(w.tabs) == n0 + 3)
check("kaputte PDF wird abgelehnt", w.open_zuschnitt_tab(bad) is None and len(w.tabs) == n0 + 3)

# Zuschneiden und speichern: neue Datei, Original unverändert
zw = t1.widget
w._show_pdf(t1)
orig_size = os.path.getsize(pdf)
zw.canvas.crop = QRectF(100, 100, 300, 300)
zw.apply_crop(False)
check("Tab zeigt Änderung", w.tabbar.tabText(w._index_of(t1)).startswith("* "))
zw.cmd_save()
check("Neue Datei a-bearbeitet.pdf", os.path.exists(os.path.join(tmp, "a-bearbeitet.pdf")))
check("Original unverändert", os.path.getsize(pdf) == orig_size)

# Speichern in Text-Einstellungen
n = len(saved)
zw.cfg["open_dir"] = tmp
zw.persist()
check("Einstellungen landen in Text", len(saved) > n and saved[-1].get("zs_open_dir") == tmp)
check("zs_cfg liest sie zurück", w.zs_cfg()["open_dir"] == tmp)

# Menü
acts = [a.text() for m in w.menuBar().findChildren(type(w.menuBar().addMenu("x"))) for a in m.actions()]
check("Menüeintrag Zuschnitt", any("Zuschnitt: PDF oder Bild" in t for t in acts))
check("Menüeintrag Zusammenfügen", any("PDFs zusammenfügen" in t for t in acts))

# Tab schließen
n = len(w.tabs)
w.close_tab(w._index_of(t1))
check("Zuschnitt-Tab schließt", len(w.tabs) == n - 1 and t1.id not in w.tabs)
w.close()

# Start mit zuschnitt=True
w2 = A.MainWindow([pdf, png], zuschnitt=True)
w2.show()
for _ in range(5):
    qapp.processEvents()
import time
time.sleep(0.05)
qapp.processEvents()
check("zuschnitt=True öffnet beide Dateien", sum(1 for t in w2.tabs.values() if t.s.get("zs")) == 2)
w2.close()

# Übernahme alter Einstellungen
os.makedirs(os.path.dirname(zs_core.CFG_FILE), exist_ok=True)
zs_core.save_settings({"save_dir": "", "open_dir": "/alt", "backup": False}, zs_core.CFG_FILE)
w3 = A.MainWindow()
c = w3.zs_cfg()
check("alte Zuschnitt-Einstellungen als Vorgabe", c["open_dir"] == "/alt" and c["backup"] is False, str(c))
w3.close()

print(f"{ok_count} Prüfungen bestanden, {len(fails)} Fehler")
sys.exit(1 if fails else 0)
