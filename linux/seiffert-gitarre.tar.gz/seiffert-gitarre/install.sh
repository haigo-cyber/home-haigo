#!/usr/bin/env bash
# Installiert Seifferts Gitarre ohne sudo nach ~/.local
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
APP=seiffert-gitarre
PREFIX="${HOME}/.local/share/${APP}"
BIN="${HOME}/.local/bin"
APPS="${HOME}/.local/share/applications"
ICONS="${HOME}/.local/share/icons/hicolor/scalable/apps"

command -v python3 >/dev/null || { echo "python3 fehlt."; exit 1; }
mkdir -p "$PREFIX" "$BIN" "$APPS" "$ICONS"

echo "Programmdateien kopieren ..."
rm -rf "$PREFIX/app"
mkdir -p "$PREFIX/app"
cp -r "$HERE/seiffert_gitarre" "$PREFIX/app/"
cp "$HERE/seiffert_gitarre/seiffert-gitarre.svg" "$ICONS/${APP}.svg"

if [ ! -x "$PREFIX/venv/bin/python" ]; then
  echo "Python-Umgebung anlegen ..."
  python3 -m venv "$PREFIX/venv"
fi
echo "Python-Pakete installieren (beim ersten Mal einige Minuten) ..."
"$PREFIX/venv/bin/python" -m pip install --upgrade pip >/dev/null
"$PREFIX/venv/bin/python" -m pip install -r "$HERE/requirements.txt"

cat > "$BIN/$APP" <<LAUNCH
#!/usr/bin/env bash
export PYTHONPATH="$PREFIX/app"
exec "$PREFIX/venv/bin/python" -m seiffert_gitarre "\$@"
LAUNCH
chmod +x "$BIN/$APP"

cat > "$APPS/${APP}.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=Seifferts Gitarre
Comment=Gitarre mit Effekten, Schlagzeug und Keyboard
Exec=$BIN/$APP
Icon=$APP
Terminal=false
Categories=AudioVideo;Audio;Music;
DESKTOP
command -v update-desktop-database >/dev/null && update-desktop-database "$APPS" >/dev/null 2>&1 || true

echo
if ! "$PREFIX/venv/bin/python" -c "import sounddevice" >/dev/null 2>&1; then
  echo "WICHTIG: Die Audio-Bibliothek PortAudio fehlt. Einmalig installieren:"
  echo "    sudo pacman -S portaudio"
  echo "Danach das Programm starten."
else
  echo "PortAudio gefunden."
fi
echo "Fertig. Start über das Anwendungsmenü (Seifferts Gitarre) oder im Terminal: $APP"
case ":$PATH:" in *":$BIN:"*) ;; *) echo "Hinweis: $BIN ist nicht im PATH, der Menüeintrag funktioniert trotzdem.";; esac
