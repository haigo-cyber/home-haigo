#!/usr/bin/env python3
"""Farbdesigns der Seiffert-Programme an einer Stelle.

Seifferts Dateien, der Starter, die Oberfläche und das Terminal nehmen die Farben von hier. Andere Seiffert-Programme können das gewählte
Farbdesign ebenfalls übernehmen: entweder dieses Modul einbinden (es braucht nur die Standardbibliothek) oder den Befehl
"seiffert design --json" aufrufen. Die Wahl selbst steht in config.json von Seifferts Dateien (Schlüssel skin und theme).

Die Werte entsprechen dem Stylesheet in index.html; tests/test_neu.py prüft, dass beide übereinstimmen."""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

APP_ID = "seiffert-dateien"
SKINS = ("petrol", "wald", "bernstein", "beere", "indigo", "graphit", "terrakotta")
LABELS = {"petrol": "Petrol", "wald": "Wald", "bernstein": "Bernstein", "beere": "Beere", "indigo": "Indigo", "graphit": "Graphit",
          "terrakotta": "Terrakotta"}
THEMES = ("auto", "light", "dark")
THEME_LABELS = {"auto": "Automatisch", "light": "Hell", "dark": "Dunkel"}

# Grundfarben (Farbdesign Petrol); die anderen Designs überschreiben nur, was abweicht
BASE = {
    "light": {"bg": "#eef1f5", "panel": "#ffffff", "ink": "#1c2530", "muted": "#566477", "line": "#d5dce5", "line2": "#e6ebf1", "ctl": "#7b8898",
              "accent": "#245d73", "accent_ink": "#ffffff", "accent_soft": "#dcebf0",
              "focus": "#e9a52b", "warn": "#9a4216", "ok": "#2a6f46", "danger": "#b3261e"},
    "dark": {"bg": "#11161c", "panel": "#19212a", "ink": "#e6ebf1", "muted": "#a3b0c0", "line": "#2b3643", "line2": "#222c37", "ctl": "#6f8196",
             "accent": "#6fb7cf", "accent_ink": "#0c1a20", "accent_soft": "#1d3440",
             "focus": "#e0a233", "warn": "#eb9a66", "ok": "#6cc08d", "danger": "#f58f88"},
}
OVER = {
    "petrol": {"light": {}, "dark": {}},
    "wald": {"light": {"accent": "#2b6a3d", "accent_soft": "#dcefe1", "bg": "#edf2ee"},
             "dark": {"accent": "#7fc68f", "accent_ink": "#0d1d12", "accent_soft": "#1b3523", "bg": "#101713", "panel": "#18221b"}},
    "bernstein": {"light": {"accent": "#85530a", "accent_soft": "#f6e6c8", "bg": "#f4f0e8"},
                  "dark": {"accent": "#e6b04f", "accent_ink": "#231703", "accent_soft": "#3b2d12", "bg": "#17140f", "panel": "#211c14"}},
    "beere": {"light": {"accent": "#8a2b5c", "accent_soft": "#f4dfea", "bg": "#f3eef1"},
              "dark": {"accent": "#e69ac3", "accent_ink": "#2a0f1d", "accent_soft": "#3d2030", "bg": "#181217", "panel": "#221a20"}},
    "indigo": {"light": {"accent": "#3f4ba8", "accent_soft": "#e0e3f6", "bg": "#eef0f6"},
               "dark": {"accent": "#a3aef2", "accent_ink": "#12163a", "accent_soft": "#272b52", "bg": "#12141d", "panel": "#1b1e2b"}},
    "graphit": {"light": {"accent": "#38424d", "accent_soft": "#e1e5ea", "bg": "#eeeff1"},
                "dark": {"accent": "#b9c4d0", "accent_ink": "#12161b", "accent_soft": "#2b333c", "bg": "#121315", "panel": "#1b1d20"}},
    "terrakotta": {"light": {"accent": "#9c3f26", "accent_soft": "#f5e0d8", "bg": "#f4eeeb"},
                   "dark": {"accent": "#f0a58c", "accent_ink": "#2b0f06", "accent_soft": "#412319", "bg": "#171210", "panel": "#211a17"}},
}


def palette(skin: str = "petrol", dark: bool = False) -> dict:
    """Alle Farben eines Farbdesigns, hell oder dunkel, als Hexwerte."""
    mode = "dark" if dark else "light"
    out = dict(BASE[mode])
    out.update(OVER.get(skin, OVER["petrol"])[mode])
    return out


# (Akzent der hellen Darstellung, Akzent der dunklen Darstellung): so brauchen es Starter und Oberfläche
SKIN_COL = {s: (palette(s, False)["accent"], palette(s, True)["accent"]) for s in SKINS}


def config_dir() -> Path:
    return Path(os.environ.get("XDG_CONFIG_HOME") or (Path.home() / ".config")) / APP_ID


def read_choice() -> tuple[str, str]:
    """Gewähltes Farbdesign und Darstellung (auto, light, dark) aus config.json; fehlt die Datei, gilt Petrol und auto."""
    skin, theme = "petrol", "auto"
    try:
        with open(config_dir() / "config.json", encoding="utf-8") as f:
            d = json.load(f)
        if isinstance(d, dict):
            if d.get("skin") in SKINS:
                skin = d["skin"]
            if d.get("theme") in THEMES:
                theme = d["theme"]
    except (OSError, ValueError):
        pass
    return skin, theme


def system_dark() -> bool | None:
    """Fragt den Desktop, ob er dunkel eingestellt ist. None, wenn sich das nicht feststellen lässt."""
    for schema, key in (("org.gnome.desktop.interface", "color-scheme"), ("org.cinnamon.desktop.interface", "gtk-theme"),
                        ("org.mate.interface", "gtk-theme"), ("org.gnome.desktop.interface", "gtk-theme")):
        try:
            r = subprocess.run(["gsettings", "get", schema, key], capture_output=True, text=True, timeout=1.5)
        except (OSError, subprocess.SubprocessError):
            return None
        val = r.stdout.strip().strip("'").lower() if r.returncode == 0 else ""
        if not val:
            continue
        if key == "color-scheme":
            if val == "prefer-dark":
                return True
            if val == "prefer-light":
                return False
            continue
        return "dark" in val or "black" in val
    return None


def current(dark: bool | None = None) -> dict:
    """Das gerade gültige Farbdesign mit allen Farben. dark vorgeben, wenn das aufrufende Programm selbst weiß, ob es dunkel ist."""
    skin, theme = read_choice()
    if dark is None:
        if theme == "auto":
            sd = system_dark()
            dark = bool(sd)
        else:
            dark = theme == "dark"
    return {"skin": skin, "label": LABELS[skin], "theme": theme, "dark": bool(dark), "colors": palette(skin, bool(dark))}


def css_vars(colors: dict) -> str:
    """Die Farben als CSS-Variablen (für Programme mit HTML-Oberfläche): --accent, --accent-ink, --bg ..."""
    return ";".join("--%s:%s" % (k.replace("_", "-"), v) for k, v in colors.items())


if __name__ == "__main__":
    cur = current()
    if "--css" in sys.argv[1:]:
        print(":root{%s}" % css_vars(cur["colors"]))
    else:
        print(json.dumps(cur, ensure_ascii=False, indent=1))
