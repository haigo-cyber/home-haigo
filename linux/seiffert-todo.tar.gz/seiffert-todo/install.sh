#!/usr/bin/env bash
# Installation von Seifferts ToDo ohne sudo (alles unter ~/.local)
set -euo pipefail
HIER="$(cd "$(dirname "$0")" && pwd)"
DATA="${XDG_DATA_HOME:-$HOME/.local/share}/seiffert-todo"
BIN="$HOME/.local/bin"
APPS="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
ICONS="${XDG_DATA_HOME:-$HOME/.local/share}/icons/hicolor"

command -v python3 >/dev/null || { echo "python3 fehlt. Auf Arch: sudo pacman -S python"; exit 1; }
mkdir -p "$DATA" "$BIN" "$APPS"

echo "Programmdateien kopieren …"
if [ -d "$DATA/app" ]; then chmod -R u+w "$DATA/app" 2>/dev/null || true; rm -rf "$DATA/app"; fi
mkdir -p "$DATA/app"
cp -r "$HIER/seiffert_todo" "$DATA/app/"
chmod -R u+w "$DATA/app"

if [ ! -x "$DATA/venv/bin/python" ]; then
  echo "Python-Umgebung anlegen …"
  python3 -m venv "$DATA/venv"
fi
echo "PySide6 installieren (beim ersten Mal einige Minuten, etwa 300 MB) …"
"$DATA/venv/bin/python" -m pip install --quiet --upgrade pip
"$DATA/venv/bin/python" -m pip install --quiet "PySide6>=6.6"

cat > "$BIN/seiffert-todo" <<LAUNCH
#!/usr/bin/env bash
export PYTHONPATH="$DATA/app\${PYTHONPATH:+:\$PYTHONPATH}"
exec "$DATA/venv/bin/python" -m seiffert_todo "\$@"
LAUNCH
chmod +x "$BIN/seiffert-todo"

for n in 16 22 24 32 48 64 128 256; do
  mkdir -p "$ICONS/${n}x${n}/apps"
  cp -f "$HIER/seiffert_todo/icons/seiffert-todo-$n.png" "$ICONS/${n}x${n}/apps/seiffert-todo.png"
done

cat > "$APPS/seiffert-todo.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=Seifferts ToDo
Comment=ToDo-App mit Google-Tabelle, Kalender und Tasks
Exec=$BIN/seiffert-todo
Icon=$DATA/app/seiffert_todo/icons/seiffert-todo-256.png
Terminal=false
Categories=Office;Utility;
StartupWMClass=seiffert-todo
DESK
chmod +x "$APPS/seiffert-todo.desktop"
command -v update-desktop-database >/dev/null && update-desktop-database "$APPS" 2>/dev/null || true
command -v gtk-update-icon-cache >/dev/null && gtk-update-icon-cache -q -t "$ICONS" 2>/dev/null || true

echo
echo "Fertig. Start über den Menüeintrag Seifferts ToDo oder im Terminal: seiffert-todo"
case ":$PATH:" in *":$BIN:"*) ;; *) echo "Hinweis: $BIN ist nicht im PATH. Der Menüeintrag funktioniert trotzdem.";; esac
