/* Seifferts ToDo (Linux): wird nach der Seite geladen.
   Sync-Anzeige, Abgleich beim Start, regelmäßiges Holen, Nachholen nach Fehlern, Sichern beim Schließen. */
(function () {
  "use strict";
  var L = window.__LINUX || {};
  var S = window.__linuxSync;
  if (!S) return;
  var plog = window.__linuxLog || function () {};
  var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  var tryG = function (f, d) { try { return f(); } catch (e) { return d; } };

  /* gleichzeitige Token-Anfragen teilen sich einen Anmeldevorgang
     (die Seite kennt nur einen Platz für den Rückruf, sonst bliebe ein Aufruf ewig hängen) */
  (function () {
    var orig = window.requestToken, shared = null;
    if (typeof orig !== "function") return;
    window.requestToken = function (interactive) {
      if (shared) return shared;
      shared = Promise.resolve(orig(interactive)).then(function (r) { shared = null; return r; }, function (e) { shared = null; throw e; });
      return shared;
    };
  })();

  /* ---------- Anzeige ---------- */
  var pill = document.createElement("button");
  pill.id = "linuxSyncPill";
  pill.type = "button";
  pill.style.cssText = "border:1px solid rgba(128,128,128,.4);background:transparent;color:inherit;border-radius:12px;padding:2px 9px;font-size:12px;line-height:18px;margin-right:6px;cursor:pointer;white-space:nowrap;max-width:46vw;overflow:hidden;text-overflow:ellipsis";
  var dot = document.getElementById("syncDot");
  if (dot && dot.parentNode) dot.parentNode.insertBefore(pill, dot);
  else { pill.style.cssText += ";position:fixed;right:8px;top:8px;z-index:9999;background:#fff;color:#000"; document.body.appendChild(pill); }

  function hhmm(t) { return new Date(t).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" }); }
  function booted() { var n = document.getElementById("nav"); return !!(n && n.style.display === "flex" && tryG(function () { return !!accessToken && !!spreadsheetId; }, false)); }
  function tokenLeftMs() { return S.expiresAt - Date.now(); }
  function render() {
    var left = tokenLeftMs(), txt, col;
    if (S.loginPending) { txt = "Warte auf Anmeldung im Browser …"; col = "#d98a00"; }
    else if (!S.expiresAt || left <= 0) { txt = booted() ? "Anmeldung abgelaufen – erneuern" : "Nicht angemeldet"; col = "#c0392b"; }
    else if (S.needResync) { txt = "Nicht synchron – wird nachgeholt"; col = "#c0392b"; }
    else if (S.inflight > 0) { txt = "Gleiche ab …"; col = "#d98a00"; }
    else if (left < 5 * 60000) { txt = "Anmeldung endet in " + Math.max(1, Math.ceil(left / 60000)) + " Min – erneuern"; col = "#d98a00"; }
    else if (S.lastOk) { txt = "Synchron · " + hhmm(S.lastOk); col = "#2e9e5b"; }
    else { txt = "Verbunden"; col = "#2e9e5b"; }
    pill.textContent = "● " + txt;
    pill.style.color = col;
    pill.title = (S.lastError ? S.lastError + "\n" : "") + (S.expiresAt && left > 0 ? "Anmeldung gültig bis " + hhmm(S.expiresAt) : "Klicken: Anmeldung erneuern oder jetzt abgleichen");
  }
  S.listeners.push(render);
  setInterval(render, 15000);
  render();

  pill.addEventListener("click", function () {
    var left = tokenLeftMs();
    if (S.loginPending) { window.__linuxForceLogin(); return; }
    if (!S.expiresAt || left < 5 * 60000) { renewLogin(); return; }
    window.__linuxSyncNow(true);
  });

  async function renewLogin() {
    await window.__linuxForceLogin();
    if (booted()) window.__linuxSyncNow(false);
    else if (typeof signIn === "function") signIn();
  }

  /* ---------- Abgleich ---------- */
  function tasksDirty() {
    return tryG(function () {
      if (tasks.length !== tasksBase.size) return true;
      return tasks.some(function (t) { return tasksBase.get(t.id) !== taskRowKey(t); });
    }, false);
  }
  function logsDirty() {
    return tryG(function () {
      var key = function (l) { return l.itemId + "|" + l.date; };
      var snap = new Set(logsSnapshotAtLoad.map(key));
      return logs.length !== logsSnapshotAtLoad.length || logs.some(function (l) { return !snap.has(key(l)); });
    }, false);
  }
  function listDirty(kind) {
    return tryG(function () {
      var c = LISTCFG[kind], base = listBase[kind], local = c.get() || [];
      if (listLoadErr[kind]) return false;
      if (local.length !== base.size) return true;
      return local.some(function (x) { return x && x.id && base.get(x.id) !== JSON.stringify(x); });
    }, false);
  }
  function planDirty() { return tryG(function () { return !!(tp.pending || tm.pending); }, false); }
  function wsDirtyNow() { return tryG(function () { return !!(wsDirty.size || wsDeleted.size); }, false); }
  function busy() { return tryG(function () { return _busyCount > 0; }, false) || S.inflight > 0; }

  function pendingKinds(all) {
    var f = S.failedKinds, k = [];
    if (tasksDirty() || (!all && f.Tasks)) k.push("Tasks");
    if (logsDirty() || (!all && f.Log)) k.push("Log");
    if (listDirty("projects") || (!all && f.Projects)) k.push("Projects");
    if (listDirty("notes") || (!all && f.Notes)) k.push("Notes");
    if (listDirty("links") || (!all && f.Links)) k.push("Links");
    if (planDirty() || wsDirtyNow() || (!all && (f.Drive || f.Sonst))) k.push("Plan");
    return k;
  }
  var resyncRunning = false, resyncTimer = null;
  async function resync(all) {
    if (resyncRunning) return false;
    if (!booted() || tokenLeftMs() <= 0) return false;
    resyncRunning = true;
    var ok = true, kinds = pendingKinds(all);
    try {
      if (kinds.length) plog("Abgleich (" + (all ? "alles" : "Nachholen") + "): " + kinds.join(", "));
      for (var i = 0; i < kinds.length; i++) {
        try {
          var k = kinds[i];
          if (k === "Tasks") await saveTasks();
          else if (k === "Log") await saveLogs();
          else if (k === "Projects") await saveProjects();
          else if (k === "Notes") await saveNotes();
          else if (k === "Links") await saveLinks();
          else if (k === "Plan") {
            if (tryG(function () { return tm.pending; }, false)) await tmSave();
            if (tryG(function () { return tp.pending; }, false)) await tpSave();
            if (wsDirtyNow()) await wsFlush();
          }
          delete S.failedKinds[k === "Plan" ? "Drive" : k];
          if (k === "Plan") delete S.failedKinds.Sonst;
        } catch (e) { ok = false; plog("Abgleich " + kinds[i] + " fehlgeschlagen: " + String((e && e.message) || e).slice(0, 120)); }
      }
      if (ok && !busy()) { S.failedKinds = {}; S.needResync = false; }
    } finally { resyncRunning = false; S.emit(); }
    return ok;
  }
  window.__linuxResyncSoon = function () {
    if (resyncTimer || resyncRunning) return;
    resyncTimer = setTimeout(function () { resyncTimer = null; resync(false); }, 3000);
  };

  /* Jetzt abgleichen: lokale Änderungen schreiben, dann Serverstand holen */
  window.__linuxSyncNow = async function (verbose) {
    if (!booted()) { if (verbose) tryG(function () { toast("Noch nicht angemeldet"); }); return false; }
    if (tokenLeftMs() <= 0) { renewLogin(); return false; }
    var ok = await resync(true);
    var ch = false;
    try { ch = await refreshFromServer(true); } catch (e) { ok = false; }
    if (ok) S.lastOk = Date.now();
    S.emit();
    if (verbose) tryG(function () { toast(ok ? (ch ? "Abgeglichen – Änderungen von anderen Geräten übernommen" : "Abgeglichen – alles aktuell") : "Abgleich nicht vollständig – siehe Anzeige oben"); });
    return ok;
  };

  /* ---------- regelmäßig holen ---------- */
  function visibleNow() { return document.visibilityState === "visible"; }
  setInterval(function () {
    if (!booted() || !visibleNow() || tokenLeftMs() <= 0) return;
    if (S.needResync) { resync(false); return; }
    tryG(function () { return refreshFromServer(true); });   // die Seite selbst holt sonst frühestens nach 90 Sekunden
  }, 60000);
  setInterval(function () {      // nach Fehlern nachholen, auch wenn das Fenster nicht sichtbar ist
    if (S.needResync && booted() && tokenLeftMs() > 0) resync(false);
  }, 15000);
  window.addEventListener("focus", function () { if (booted() && tokenLeftMs() > 0) { tryG(function () { refreshFromServer(false); }); if (S.needResync) resync(false); } });
  window.addEventListener("online", function () { if (S.needResync) resync(false); });

  /* ---------- Beenden ---------- */
  window.__linuxPending = function () {
    if (!booted()) return JSON.stringify({ pending: false, booted: false });
    var k = pendingKinds(true);
    return JSON.stringify({ pending: k.length > 0 || busy() || S.needResync, kinds: k, busy: busy(), needResync: S.needResync, tokenOk: tokenLeftMs() > 0 });
  };
  var flushState = "idle";
  window.__linuxFlushStart = function () {
    flushState = "running";
    (async function () {
      try {
        if (tokenLeftMs() <= 0) { flushState = "fail:Anmeldung abgelaufen"; return; }
        var ok = await resync(true);
        for (var i = 0; i < 40 && busy(); i++) await sleep(250);
        if (typeof window.__linuxLsFlush === "function") window.__linuxLsFlush();
        flushState = (ok && !busy()) ? "ok" : "fail:Nicht alles konnte geschrieben werden";
      } catch (e) { flushState = "fail:" + String((e && e.message) || e).slice(0, 100); }
    })();
    return "started";
  };
  window.__linuxFlushState = function () { return flushState; };

  /* ---------- Start: sofort anmelden und Daten holen ---------- */
  setTimeout(function () {
    if (!L.autoLogin) return;
    if (typeof signIn !== "function") return;
    plog("Start: Anmeldung und Abgleich");
    signIn();
  }, 300);
})();
