"""Pfade und Einstellungen von Seifferts Depot (Linux-App)."""
import json
import os
import threading
from pathlib import Path

APP_NAME = 'seiffert-depot'
VERSION = '0.1'


def _xdg(env, fallback):
    v = os.environ.get(env)
    return Path(v) if v else Path.home() / fallback


CONFIG_DIR = _xdg('XDG_CONFIG_HOME', '.config') / APP_NAME
DATA_DIR = _xdg('XDG_DATA_HOME', '.local/share') / APP_NAME
SETTINGS_FILE = CONFIG_DIR / 'settings.json'
INTERN_FILE = DATA_DIR / 'intern.json'
LOG_FILE = DATA_DIR / 'protokoll.txt'
LOCK_FILE = DATA_DIR / 'lock'
PKG_DIR = Path(__file__).resolve().parent

DEFAULTS = {
    # Ordner mit der Hauptdatei depot-daten.json und dem Unterordner Sicherungen (leer = Dokumente/Seifferts Depot)
    'datenordner': '',
    # Internetadresse der veröffentlichten HTML-Fassung (GitHub Pages), über die die Google-Anmeldung läuft
    'handoff_url': '',
    # Eigene HTML-Fassung statt der mitgelieferten (leer = mitgeliefert)
    'html_datei': '',
    # auto, hell oder dunkel
    'farbschema': 'auto',
    # true schaltet die Grafikbeschleunigung aus (bei schwarzem Fenster)
    'software_rendering': False,
    'zoom': 1.0,
    'fenster': [1180, 860],
}


def documents_dir():
    """Dokumentenordner des Benutzers (xdg-user-dirs), sonst ~/Dokumente, ~/Documents oder das Home-Verzeichnis."""
    home = Path.home()
    f = _xdg('XDG_CONFIG_HOME', '.config') / 'user-dirs.dirs'
    try:
        for line in f.read_text(encoding='utf-8').splitlines():
            line = line.strip()
            if line.startswith('XDG_DOCUMENTS_DIR='):
                v = line.split('=', 1)[1].strip().strip('"').replace('$HOME', str(home))
                if v and Path(v) != home:
                    return Path(v)
    except OSError:
        pass
    for n in ('Dokumente', 'Documents'):
        if (home / n).is_dir():
            return home / n
    return home


def atomic_write(path, text):
    """Schreibt eine Datei über eine Temporärdatei und benennt sie dann um (kein halbes Ergebnis bei Absturz)."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.tmp')
    with open(tmp, 'w', encoding='utf-8') as f:
        f.write(text)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)
    try:
        fd = os.open(str(path.parent), os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    except OSError:
        pass


class Settings:
    def __init__(self, path=None):
        self.path = Path(path) if path else SETTINGS_FILE
        self.lock = threading.RLock()
        self.data = dict(DEFAULTS)
        self.load()

    def load(self):
        try:
            o = json.loads(self.path.read_text(encoding='utf-8'))
            if isinstance(o, dict):
                for k in DEFAULTS:
                    if k in o:
                        self.data[k] = o[k]
        except (OSError, ValueError):
            pass

    def get(self, k):
        with self.lock:
            return self.data.get(k, DEFAULTS.get(k))

    def set(self, k, v):
        with self.lock:
            self.data[k] = v
            self.save()

    def save(self):
        with self.lock:
            try:
                atomic_write(self.path, json.dumps(self.data, ensure_ascii=False, indent=1))
            except OSError:
                pass

    def datenordner(self):
        v = os.environ.get('SEIFFERT_DEPOT_DATENORDNER') or self.get('datenordner')
        if v:
            return Path(os.path.expanduser(str(v)))
        return documents_dir() / 'Seifferts Depot'

    def html_datei(self):
        v = self.get('html_datei')
        if v and Path(os.path.expanduser(str(v))).is_file():
            return Path(os.path.expanduser(str(v)))
        return PKG_DIR / 'depot.html'
