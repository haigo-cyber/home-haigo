APP_NAME = "Seifferts Text"
VERSION = "0.6"
