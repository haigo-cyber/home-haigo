"""QTextDocument -> LaTeX."""
import hashlib
import os
import re

from PySide6.QtCore import QBuffer, QIODevice, QUrl, Qt
from PySide6.QtGui import QImage, QTextCursor, QTextDocument, QTextFormat, QTextListFormat, QFont, QTextCharFormat

from .common import (PROP_RAW_BLOCK, PROP_RAW_INLINE, PROP_ORIG_SRC, PROP_UNNUM, LS,
                     DEFAULT_PREAMBLE, heading_cmds)

ESC = {
    "\\": r"\textbackslash{}", "&": r"\&", "%": r"\%", "$": r"\$", "#": r"\#", "_": r"\_",
    "{": r"\{", "}": r"\}", "~": r"\textasciitilde{}", "^": r"\textasciicircum{}",
    "\u00a0": "~", "\t": "~~~~", "\u200b": "",
}
ORDERED = {QTextListFormat.Style.ListDecimal, QTextListFormat.Style.ListLowerAlpha,
           QTextListFormat.Style.ListUpperAlpha, QTextListFormat.Style.ListLowerRoman,
           QTextListFormat.Style.ListUpperRoman}
NUM_RE = re.compile(r"^[-+\u2212]?[\d.,\s]+\s*[%€]?$")
WRAP = 90


def esc(s):
    return "".join(ESC.get(ch, ch) for ch in s)


def wrap_par(text):
    """Bricht lange Zeilen an Leerzeichen um. Geschützte Leerzeichen (\\x00) bleiben."""
    out = []
    for line in text.split("\n"):
        if len(line) <= WRAP:
            out.append(line)
            continue
        cur = ""
        for w in line.split(" "):
            if cur and len(cur) + 1 + len(w) > WRAP:
                out.append(cur)
                cur = w
            else:
                cur = w if not cur else cur + " " + w
        out.append(cur)
    return "\n".join(out).replace("\x00", " ")


def ensure_packages(preamble, body):
    need = []
    checks = [(r"\\uline|\\sout", "ulem", r"\IfFileExists{ulem.sty}{\usepackage[normalem]{ulem}}{\newcommand{\uline}[1]{\underline{##1}}\newcommand{\sout}[1]{##1}}"),
              (r"\\href\{", "hyperref", r"\IfFileExists{hyperref.sty}{\usepackage[hidelinks]{hyperref}}{\newcommand{\href}[2]{##2}\newcommand{\url}[1]{\texttt{##1}}}"),
              (r"\\includegraphics", "graphicx", r"\usepackage{graphicx}"),
              (r"\\begin\{longtable\}", "longtable", r"\usepackage{longtable}"),
              (r"\\arraybackslash", "array", r"\usepackage{array}")]
    for pat, name, line in checks:
        if re.search(pat, body) and name not in preamble:
            need.append(line)
    if not need:
        return preamble
    m = re.search(r"\\documentclass(?:\[[^\]]*\])?\{[^}]*\}[^\n]*\n", preamble)
    ins = "\n".join(need) + "\n"
    if m:
        return preamble[:m.end()] + ins + preamble[m.end():]
    return ins + preamble


class Exporter:
    def __init__(self, doc, preamble=None, base_dir=None):
        self.doc = doc
        self.base_dir = base_dir
        self.preamble = preamble or DEFAULT_PREAMBLE
        self.cmds = heading_cmds(self.preamble)
        self.images = {}       # Dateiname -> Bytes
        self._hash = {}

    # ---------- Hilfen ----------
    def _walk(self, first, end_pos, inside=None):
        items = []
        b = first
        while b.isValid() and b.position() <= end_pos:
            tbl = QTextCursor(b).currentTable()
            if tbl is not None and inside is not None and tbl.firstPosition() == inside.firstPosition():
                tbl = None
            if tbl is not None:
                items.append(("table", tbl))
                b = self.doc.findBlock(tbl.lastPosition() + 1)
                if b.isValid() and b.position() <= tbl.lastPosition():
                    b = b.next()
                continue
            items.append(("p", b))
            b = b.next()
        return items

    def _image_tex(self, fmt):
        name = fmt.name()
        orig = fmt.property(PROP_ORIG_SRC) if fmt.hasProperty(PROP_ORIG_SRC) else None
        w = fmt.width()
        opt = ""
        if w and w > 0:
            cm = w / 96.0 * 2.54
            opt = "[width=\\linewidth]" if cm >= 15.9 else "[width=%.1fcm]" % cm
        if orig:
            return "\\includegraphics%s{%s}" % (opt, orig)
        res = self.doc.resource(QTextDocument.ResourceType.ImageResource, QUrl(name))
        img = res if isinstance(res, QImage) else None
        if img is None or img.isNull():
            if self.base_dir and not name.startswith(("http:", "https:")) and \
                    os.path.isfile(os.path.join(self.base_dir, name)):
                img = QImage(os.path.join(self.base_dir, name))
            if img is None or img.isNull():
                return "\\includegraphics%s{%s}" % (opt, name)
        buf = QBuffer()
        buf.open(QIODevice.OpenModeFlag.WriteOnly)
        img.save(buf, "PNG")
        data = bytes(buf.data())
        h = hashlib.sha1(data).hexdigest()
        fn = self._hash.get(h)
        if fn is None:
            fn = "bild%d.png" % (len(self._hash) + 1)
            self._hash[h] = fn
            self.images[fn] = data
        return "\\includegraphics%s{bilder/%s}" % (opt, fn)

    def _frag_key(self, cf, heading):
        bold = cf.fontWeight() >= 700 and not heading
        tt = cf.fontFixedPitch() or any("mono" in f.lower() or "courier" in f.lower()
                                        for f in cf.fontFamilies() or [])
        va = cf.verticalAlignment()
        href = cf.anchorHref() if cf.isAnchor() else ""
        return (bold, cf.fontItalic(), cf.fontUnderline() and not href, cf.fontStrikeOut(), bool(tt),
                va == QTextCharFormat.VerticalAlignment.AlignSuperScript,
                va == QTextCharFormat.VerticalAlignment.AlignSubScript, href)

    def _wrapfmt(self, s, key):
        bold, ital, und, st, tt, sup, sub, href = key
        if not s:
            return s
        lead = s[:len(s) - len(s.lstrip(" "))]
        trail = s[len(s.rstrip(" ")):] if s.strip(" ") else ""
        core = s.strip(" ")
        if not core:
            return s
        if tt:
            core = "\\texttt{%s}" % core
        if sup:
            core = "\\textsuperscript{%s}" % core
        if sub:
            core = "\\textsubscript{%s}" % core
        if st:
            core = "\\sout{%s}" % core
        if und:
            core = "\\uline{%s}" % core
        if ital:
            core = "\\textit{%s}" % core
        if bold:
            core = "\\textbf{%s}" % core
        if href:
            u = href.replace("%", "\\%").replace("#", "\\#")
            core = "\\href{%s}{%s}" % (u, core)
        return lead + core + trail

    def inline(self, block, in_cell=False):
        heading = block.blockFormat().headingLevel() > 0
        parts = []   # (kind, text, key)
        it = block.begin()
        while not it.atEnd():
            frag = it.fragment()
            it += 1
            cf = frag.charFormat()
            txt = frag.text()
            if cf.isImageFormat():
                parts.append(("raw", self._image_tex(cf.toImageFormat()), None))
                continue
            if cf.hasProperty(PROP_RAW_INLINE):
                r = txt.replace(LS, "\n")
                if r.lstrip().startswith("%") or "\n%" in r:
                    r = r.rstrip("\n") + "\n"
                elif re.search(r"\\[A-Za-z]+$", r):
                    r += " "
                parts.append(("raw", r, None))
                continue
            key = self._frag_key(cf, heading)
            parts.append(("txt", txt, key))
        # gleiche Formate zusammenfassen
        merged = []
        for p in parts:
            if merged and p[0] == "txt" and merged[-1][0] == "txt" and merged[-1][2] == p[2]:
                merged[-1] = ("txt", merged[-1][1] + p[1], p[2])
            else:
                merged.append(p)
        out = []
        for kind, txt, key in merged:
            if kind == "raw":
                out.append(txt.replace(" ", "\x00"))
            else:
                if in_cell:
                    txt = txt.replace(LS, " ")
                    out.append(self._wrapfmt(esc(txt), key))
                else:
                    pieces = txt.split(LS)
                    out.append(("\\\\\n").join(self._wrapfmt(esc(p), key) for p in pieces))
        return "".join(out)

    def _block_kind(self, b):
        bf = b.blockFormat()
        if bf.hasProperty(PROP_RAW_BLOCK):
            return "raw"
        if bf.hasProperty(QTextFormat.Property.BlockCodeFence):
            return "code"
        if bf.hasProperty(QTextFormat.Property.BlockTrailingHorizontalRulerWidth):
            return "hr"
        if b.textList() is not None:
            return "list"
        if bf.headingLevel() > 0:
            return "head"
        return "par"

    def _env_key(self, b):
        bf = b.blockFormat()
        if bf.hasProperty(QTextFormat.Property.BlockQuoteLevel) and bf.property(QTextFormat.Property.BlockQuoteLevel):
            return "quote"
        a = bf.alignment()
        if a & Qt.AlignmentFlag.AlignHCenter:
            return "center"
        if a & Qt.AlignmentFlag.AlignRight:
            return "flushright"
        return None

    # ---------- Ausgabe ----------
    def emit(self, items):
        out = []
        i = 0
        n = len(items)
        while i < n:
            kind, obj = items[i]
            if kind == "table":
                out.append(self.table(obj))
                i += 1
                continue
            k = self._block_kind(obj)
            if k == "raw":
                out.append(obj.text().replace(LS, "\n"))
                i += 1
            elif k == "hr":
                out.append("\\noindent\\rule{\\linewidth}{0.4pt}")
                i += 1
            elif k == "code":
                lines = []
                while i < n and items[i][0] == "p" and self._block_kind(items[i][1]) == "code":
                    lines.append(items[i][1].text().replace(LS, "\n"))
                    i += 1
                out.append("\\begin{verbatim}\n" + "\n".join(lines) + "\n\\end{verbatim}")
            elif k == "head":
                lvl = min(6, obj.blockFormat().headingLevel())
                star = "*" if obj.blockFormat().hasProperty(PROP_UNNUM) else ""
                out.append("\\%s%s{%s}" % (self.cmds[lvl - 1], star, wrap_par(self.inline(obj, True))))
                i += 1
            elif k == "list":
                grp = []
                while i < n and items[i][0] == "p" and self._block_kind(items[i][1]) == "list":
                    grp.append(items[i][1])
                    i += 1
                out.append(self.lists(grp))
            else:
                env = self._env_key(obj)
                paras = []
                while (i < n and items[i][0] == "p" and self._block_kind(items[i][1]) == "par"
                       and self._env_key(items[i][1]) == env):
                    b = items[i][1]
                    txt = self.inline(b)
                    if txt.strip():
                        paras.append(wrap_par(txt))
                    i += 1
                if paras:
                    body = "\n\n".join(paras)
                    out.append("\\begin{%s}\n%s\n\\end{%s}" % (env, body, env) if env else body)
        return "\n\n".join(x for x in out if x != "")

    def lists(self, blocks):
        lines = []
        stack = []   # (indent, ordered)
        for b in blocks:
            fmt = b.textList().format()
            ind = max(1, fmt.indent())
            od = fmt.style() in ORDERED
            while stack and stack[-1][0] > ind:
                lines.append("  " * (len(stack) - 1) + "\\end{%s}" % ("enumerate" if stack[-1][1] else "itemize"))
                stack.pop()
            if stack and stack[-1][0] == ind and stack[-1][1] != od:
                lines.append("  " * (len(stack) - 1) + "\\end{%s}" % ("enumerate" if stack[-1][1] else "itemize"))
                stack.pop()
            if not stack or stack[-1][0] < ind:
                lines.append("  " * len(stack) + "\\begin{%s}" % ("enumerate" if od else "itemize"))
                stack.append((ind, od))
            txt = wrap_par(self.inline(b)).replace("\n", "\n" + "  " * len(stack) + "  ")
            lines.append(("  " * len(stack) + "\\item " + txt).rstrip())
        while stack:
            lines.append("  " * (len(stack) - 1) + "\\end{%s}" % ("enumerate" if stack[-1][1] else "itemize"))
            stack.pop()
        return "\n".join(lines)

    def _cell_text(self, tbl, cell, multi):
        items = self._walk(cell.firstCursorPosition().block(), cell.lastCursorPosition().position(), tbl)
        texts = []
        for kind, obj in items:
            if kind == "p":
                t = self.inline(obj, True).replace("\n", " ")
                if t.strip():
                    texts.append(t.replace("\x00", " "))
        return (" \\newline " if multi else " ").join(texts), len(texts)

    def table(self, tbl):
        nr, nc = tbl.rows(), tbl.columns()
        if nr == 0 or nc == 0:
            return ""
        cells = {}
        maxlen = [4] * nc
        multi = [False] * nc
        numeric = [True] * nc
        hasnum = [False] * nc
        for r in range(nr):
            for c in range(nc):
                cell = tbl.cellAt(r, c)
                if cell.row() != r or cell.column() != c:
                    continue
                txt, nb = self._cell_text(tbl, cell, False)
                plain = re.sub(r"\\[A-Za-z]+\{?|[{}\x00]", "", txt)
                cs = max(1, cell.columnSpan())
                cells[(r, c)] = (cell, cs)
                if cs == 1:
                    maxlen[c] = max(maxlen[c], min(len(plain), 60))
                    if nb > 1 or len(plain) > 32:
                        multi[c] = True
                    if r > 0 and plain.strip():
                        if NUM_RE.match(plain.strip()):
                            hasnum[c] = True
                        else:
                            numeric[c] = False
        use_p = any(multi) or nc >= 6
        sz = "\\footnotesize" if nc >= 10 else ("\\small" if nc >= 7 else "")
        total = float(sum(maxlen))
        frac = [m / total for m in maxlen]
        hdr = tbl.format().headerRowCount() > 0
        rule = r"\arrayrulewidth"

        def pcol(f, extra_cols=0):
            base = "%.3f\\dimexpr\\linewidth-%d\\tabcolsep-%d%s\\relax" % (f, 2 * nc, nc + 1, rule)
            if extra_cols:
                return ">{%s\\raggedright\\arraybackslash}p{\\dimexpr %s+%d\\tabcolsep+%d%s\\relax}" % (
                    sz, base, 2 * extra_cols, extra_cols, rule)
            return ">{%s\\raggedright\\arraybackslash}p{\\dimexpr %s\\relax}" % (sz, base)

        spec = "|"
        for c in range(nc):
            if use_p:
                spec += pcol(frac[c]) + "|"
            else:
                spec += (">{%s}" % sz if sz else "") + ("r" if numeric[c] and hasnum[c] else "l") + "|"
        rows_tex = []
        for r in range(nr):
            parts = []
            c = 0
            while c < nc:
                if (r, c) in cells:
                    cell, cs = cells[(r, c)]
                    txt, _ = self._cell_text(tbl, cell, use_p)
                    if cs > 1:
                        if use_p:
                            f = sum(frac[c:c + cs])
                            cspec = "|" + pcol(f, cs - 1) + "|"
                        else:
                            cspec = "|l|"
                        txt = "\\multicolumn{%d}{%s}{%s}" % (cs, cspec, txt)
                    parts.append(txt)
                    c += cs
                else:
                    parts.append("")
                    c += 1
            rows_tex.append(" & ".join(parts) + " \\\\")
        if nr > 40:
            lines = ["\\begin{longtable}{%s}" % spec, "\\hline"]
            if hdr:
                lines += [rows_tex[0], "\\hline", "\\endhead"]
                body = rows_tex[1:]
            else:
                body = rows_tex
            for rt in body:
                lines += [rt, "\\hline"]
            lines.append("\\end{longtable}")
            return "\n".join(lines)
        lines = ["\\begin{center}"]
        lines += ["\\begin{tabular}{%s}" % spec, "\\hline"]
        for rt in rows_tex:
            lines += [rt, "\\hline"]
        lines += ["\\end{tabular}", "\\end{center}"]
        return "\n".join(x for x in lines if x)

    # ---------- Gesamtdokument ----------
    def export(self):
        items = self._walk(self.doc.begin(), 10 ** 9)
        body = self.emit(items)
        pre = ensure_packages(self.preamble, body)
        text = pre.rstrip("\n") + "\n\n\\begin{document}\n\n" + body + "\n\n\\end{document}\n"
        return text, self.images


def export_latex(doc, preamble=None, base_dir=None):
    return Exporter(doc, preamble, base_dir).export()
