"""Formatvorlagen: LaTeX-Vorgabe (Präambel) -> Formatspezifikation -> ODT-Vorlage (.ott) und Word-Vorlage (.dotx).

Die Spezifikation (spec) ist ein einfaches Wörterbuch und wird als JSON gespeichert. Sie wird ausgelesen aus
\\documentclass, geometry, Schriftpaketen und fontspec, Zeilenabstand, Absatzabstand, titlesec, KOMA-Schriften,
sectsty, fancyhdr und scrlayer-scrpage, Farben (xcolor) und Sprache (babel). Was nicht erkannt wird, steht im
Bericht (report), damit nichts stillschweigend verloren geht.
"""
import json
import os
import re
import shutil
import tempfile
import zipfile
from xml.sax.saxutils import escape

PT_PER_CM = 28.3465

NAMED_COLORS = {
    "black": "000000", "white": "FFFFFF", "red": "FF0000", "green": "00FF00", "blue": "0000FF",
    "cyan": "00FFFF", "magenta": "FF00FF", "yellow": "FFFF00", "gray": "808080", "darkgray": "404040",
    "lightgray": "BFBFBF", "orange": "FF8000", "purple": "BF0040", "brown": "BF8040", "olive": "808000",
    "teal": "008080", "violet": "800080", "pink": "FFBFBF", "lime": "BFFF00",
}
# Größen der LaTeX-Größenbefehle je Grundgröße (Standardklassen)
SIZE_TABLE = {
    10: dict(tiny=5, scriptsize=7, footnotesize=8, small=9, normalsize=10, large=12, Large=14.4, LARGE=17.28, huge=20.74, Huge=24.88),
    11: dict(tiny=6, scriptsize=8, footnotesize=9, small=10, normalsize=10.95, large=12, Large=14.4, LARGE=17.28, huge=20.74, Huge=24.88),
    12: dict(tiny=6, scriptsize=8, footnotesize=10, small=10.95, normalsize=12, large=14.4, Large=17.28, LARGE=20.74, huge=24.88, Huge=24.88),
}
SERIF, SANS, MONO = "Liberation Serif", "Liberation Sans", "Liberation Mono"


def default_spec(name="Neue Vorlage"):
    return {
        "name": name, "paper": [21.0, 29.7], "margins": {"top": 2.5, "bottom": 2.5, "left": 2.5, "right": 2.5},
        "font": SERIF, "sans": SANS, "mono": MONO, "size": 12.0, "line": 1.0, "parskip": 0.25, "indent": 0.0,
        "justify": False, "color": None, "lang": "de-DE", "list_gap": 0.08,
        "headings": {}, "header": None, "footer": None, "header_rule": False, "footer_rule": False,
        "report": [],
    }


# ---------------------------------------------------------------- LaTeX lesen
def _strip_comments(tex):
    return re.sub(r"(?<!\\)%.*", "", tex)


def _group(s, i):
    """s[i] == '{' -> (Inhalt, Position nach der schließenden Klammer) oder (None, i)."""
    if i >= len(s) or s[i] != "{":
        return None, i
    d = 0
    for j in range(i, len(s)):
        c = s[j]
        if c == "\\":
            continue
        if c == "{" and (j == 0 or s[j - 1] != "\\"):
            d += 1
        elif c == "}" and s[j - 1] != "\\":
            d -= 1
            if d == 0:
                return s[i + 1:j], j + 1
    return None, i


def _opt(s, i):
    j = i
    while j < len(s) and s[j] in " \t\r\n":
        j += 1
    if j < len(s) and s[j] == "[":
        k = s.find("]", j)
        if k > 0:
            return s[j + 1:k], k + 1
    return None, i


def _skipws(s, i):
    while i < len(s) and s[i] in " \t\r\n":
        i += 1
    return i


def commands(tex, name, nargs=1):
    """Alle Aufrufe \\name[opt]{a}{b}... -> Liste (opt, [args])."""
    out = []
    for m in re.finditer(r"\\" + re.escape(name) + r"(?![A-Za-z@])\*?", tex):
        i = m.end()
        opt, i = _opt(tex, i)
        args = []
        for _ in range(nargs):
            i = _skipws(tex, i)
            g, j = _group(tex, i)
            if g is None:
                break
            args.append(g)
            i = j
        out.append((opt, args, m.start()))
    return out


def to_cm(val, base=11.0, baseline=13.6):
    """LaTeX-Länge -> cm oder None."""
    if val is None:
        return None
    v = re.split(r"\bplus\b|\bminus\b", val.strip())[0].strip()
    m = re.fullmatch(r"(-?[0-9]*\.?[0-9]+)\s*(cm|mm|in|pt|bp|em|ex|\\baselineskip|\\normalbaselineskip|\\parskip|\\baselinestretch)?", v)
    if not m:
        return None
    n = float(m.group(1))
    u = m.group(2) or "pt"
    if u == "cm":
        return n
    if u == "mm":
        return n / 10
    if u == "in":
        return n * 2.54
    if u == "pt":
        return n / 72.27 * 2.54
    if u == "bp":
        return n / 72.0 * 2.54
    if u == "em":
        return n * base / PT_PER_CM
    if u == "ex":
        return n * 0.45 * base / PT_PER_CM
    if u in ("\\baselineskip", "\\normalbaselineskip"):
        return n * baseline / PT_PER_CM
    return None


def parse_color_defs(tex):
    cols = dict(NAMED_COLORS)
    for opt, a, _ in commands(tex, "definecolor", 3):
        if len(a) < 3:
            continue
        name, model, spec = a[0].strip(), a[1].strip(), a[2].strip()
        try:
            if model == "HTML":
                cols[name] = spec.upper()
            elif model == "RGB":
                r, g, b = [int(float(x)) for x in spec.split(",")]
                cols[name] = "%02X%02X%02X" % (r, g, b)
            elif model == "rgb":
                r, g, b = [float(x) for x in spec.split(",")]
                cols[name] = "%02X%02X%02X" % (round(r * 255), round(g * 255), round(b * 255))
            elif model == "gray":
                g = round(float(spec) * 255)
                cols[name] = "%02X%02X%02X" % (g, g, g)
        except (ValueError, TypeError):
            continue
    return cols


def parse_font_cmds(fmt, cols, base):
    """Schriftbefehle in einem Format (\\Large\\bfseries\\color{x} ...) -> Eigenschaften."""
    p = {}
    sizes = SIZE_TABLE[base if base in SIZE_TABLE else 11]
    for m in re.finditer(r"\\(tiny|scriptsize|footnotesize|small|normalsize|large|Large|LARGE|huge|Huge)(?![A-Za-z])", fmt):
        p["size"] = sizes[m.group(1)]
    m = re.search(r"\\fontsize\{([0-9.]+)(?:pt)?\}", fmt)
    if m:
        p["size"] = float(m.group(1))
    if re.search(r"\\(bfseries|textbf|bf)(?![A-Za-z])", fmt):
        p["bold"] = True
    if re.search(r"\\mdseries", fmt):
        p["bold"] = False
    if re.search(r"\\(itshape|slshape|textit|it|em)(?![A-Za-z])", fmt):
        p["italic"] = True
    if re.search(r"\\sffamily|\\textsf", fmt):
        p["family"] = "sans"
    elif re.search(r"\\rmfamily|\\textrm", fmt):
        p["family"] = "serif"
    elif re.search(r"\\ttfamily|\\texttt", fmt):
        p["family"] = "mono"
    if re.search(r"\\scshape|\\textsc", fmt):
        p["smallcaps"] = True
    if re.search(r"\\MakeUppercase|\\uppercase", fmt):
        p["upper"] = True
    if re.search(r"\\centering", fmt):
        p["align"] = "center"
    elif re.search(r"\\raggedleft", fmt):
        p["align"] = "right"
    elif re.search(r"\\raggedright", fmt):
        p["align"] = "left"
    m = re.search(r"\\(?:color|textcolor)(?:\[[^\]]*\])?\{([^}]+)\}", fmt)
    if m and m.group(1) in cols:
        p["color"] = cols[m.group(1)]
    return p


LEVELS = {"article": ["section", "subsection", "subsubsection", "paragraph"],
          "report": ["chapter", "section", "subsection", "subsubsection"],
          "book": ["chapter", "section", "subsection", "subsubsection"]}
KOMA = {"scrartcl": "article", "scrreprt": "report", "scrbook": "book", "article": "article",
        "report": "report", "book": "book", "extarticle": "article", "extreport": "report",
        "memoir": "book", "amsart": "article"}


def _default_headings(cls, base):
    s = SIZE_TABLE[base if base in SIZE_TABLE else 11]
    if cls == "article":
        d = [dict(size=s["Large"], before=0.45, after=0.25), dict(size=s["large"], before=0.42, after=0.2),
             dict(size=s["normalsize"], before=0.42, after=0.2), dict(size=s["normalsize"], before=0.4, after=0.0)]
    else:
        d = [dict(size=s["huge"], before=1.4, after=0.9), dict(size=s["Large"], before=0.45, after=0.25),
             dict(size=s["large"], before=0.42, after=0.2), dict(size=s["normalsize"], before=0.42, after=0.2)]
    return {i + 1: dict(x, bold=True, italic=False, family=None, color=None, align="left", upper=False, smallcaps=False)
            for i, x in enumerate(d)}


def _hf_text(raw, cols):
    """Text einer Kopf- oder Fußzeile: \\thepage -> {page}, \\today -> {date}, Befehle entfernt."""
    t = raw
    t = re.sub(r"\\thepage|\\pagemark", "{page}", t)
    t = re.sub(r"\\today", "{date}", t)
    t = re.sub(r"\\(?:thetotalpages|pageref\{LastPage\})", "{pages}", t)
    t = re.sub(r"\\leftmark|\\rightmark|\\nouppercase|\\slshape|\\itshape|\\bfseries|\\small|\\footnotesize|\\scriptsize|\\sffamily|\\color\{[^}]*\}", "", t)
    t = re.sub(r"\\(?:textbf|textit|textsc|emph|textsf|textrm|texttt|textcolor\{[^}]*\})\{([^{}]*)\}", r"\1", t)
    t = re.sub(r"\\jobname", "", t)
    t = t.replace("\\hfill", " ").replace("\\quad", "  ").replace("~", " ").replace("\\&", "&").replace("\\_", "_")
    t = re.sub(r"\\[A-Za-z]+\*?", "", t)
    t = t.replace("{", "{ ").replace("}", " }")
    t = re.sub(r"\{ (page|date|pages) \}", r"{\1}", t)
    t = t.replace("{ ", "").replace(" }", "")
    return re.sub(r"\s+", " ", t).strip()


def spec_from_latex(tex, name="Vorlage"):
    """Liest eine LaTeX-Datei (Präambel genügt) und liefert die Spezifikation."""
    spec = default_spec(name)
    rep = spec["report"]
    src = _strip_comments(tex)
    pre = src.split("\\begin{document}")[0]
    cols = parse_color_defs(pre)
    ok, miss = [], []

    # --- Dokumentklasse, Größe, Papier
    cls, base, opts = "article", 10, ""
    m = re.search(r"\\documentclass(?:\[([^\]]*)\])?\{([^}]+)\}", pre)
    if m:
        opts = m.group(1) or ""
        cn = m.group(2).strip()
        cls = KOMA.get(cn, "article")
        if cn not in KOMA:
            miss.append("Dokumentklasse %s (wie article behandelt)" % cn)
        mm = re.search(r"(\d+(?:\.\d+)?)pt", opts)
        if mm:
            base = int(float(mm.group(1)))
        elif cn.startswith("scr"):
            mm = re.search(r"fontsize=(\d+(?:\.\d+)?)pt", opts)
            base = 11 if not mm else int(float(mm.group(1)))
        else:
            base = 10
        if re.search(r"letterpaper", opts):
            spec["paper"] = [21.59, 27.94]
        elif re.search(r"a5paper", opts):
            spec["paper"] = [14.8, 21.0]
        ok.append("Klasse %s, Grundgröße %d pt" % (cn, base))
    size_pt = {10: 10.0, 11: 10.95, 12: 12.0}.get(base, float(base))
    sizes = SIZE_TABLE[base if base in SIZE_TABLE else 11]
    # Grundgröße aus \@setfontsize\normalsize{size}{leading} (so schreibt der PDF-Import)
    m = re.search(r"\\@setfontsize\\normalsize\{?([0-9.]+)(?:bp|pt)?\}?\{?([0-9.]+)(?:bp|pt)?\}?", pre)
    leading = None
    if m:
        size_pt = float(m.group(1))
        leading = float(m.group(2))
        base = int(round(size_pt))
        sizes = SIZE_TABLE[base if base in SIZE_TABLE else 11]
        ok.append("Grundschrift %.1f pt, Zeilenabstand %.1f pt" % (size_pt, leading))
    spec["size"] = round(size_pt, 2)
    if cls != "article" and not re.search(r"oneside", opts) and re.search(r"twoside", opts):
        miss.append("zweiseitiger Satz (twoside)")
    if re.search(r"twocolumn", opts):
        miss.append("zweispaltiger Satz (twocolumn)")

    # --- Seitenränder (geometry)
    geo = ""
    for opt, a, _ in commands(pre, "usepackage", 1):
        if a and "geometry" in a[0]:
            geo += "," + (opt or "")
    for _, a, _ in commands(pre, "geometry", 1):
        geo += "," + a[0]
    if geo:
        mg = spec["margins"]
        if re.search(r"a4paper", geo):
            spec["paper"] = [21.0, 29.7]
        elif re.search(r"letterpaper", geo):
            spec["paper"] = [21.59, 27.94]
        elif re.search(r"a5paper", geo):
            spec["paper"] = [14.8, 21.0]
        pm = re.search(r"paperwidth\s*=\s*([^,]+)", geo)
        ph = re.search(r"paperheight\s*=\s*([^,]+)", geo)
        if pm and ph and to_cm(pm.group(1)) and to_cm(ph.group(1)):
            spec["paper"] = [to_cm(pm.group(1)), to_cm(ph.group(1))]
        if re.search(r"landscape", geo):
            spec["paper"] = spec["paper"][::-1]
        for key, targets in (("margin", ("top", "bottom", "left", "right")), ("hmargin", ("left", "right")),
                             ("vmargin", ("top", "bottom")), ("left", ("left",)), ("right", ("right",)),
                             ("top", ("top",)), ("bottom", ("bottom",)), ("inner", ("left",)), ("outer", ("right",)),
                             ("lmargin", ("left",)), ("rmargin", ("right",)), ("tmargin", ("top",)), ("bmargin", ("bottom",))):
            for mm in re.finditer(r"(?<![A-Za-z])%s\s*=\s*([^,}]+)" % key, geo):
                v = to_cm(mm.group(1), size_pt)
                if v is not None:
                    for t in targets:
                        mg[t] = round(v, 2)
        mm = re.search(r"(?<![A-Za-z])total\s*=\s*\{([^,}]+),\s*([^}]+)\}", geo)
        if mm:
            tw, th = to_cm(mm.group(1)), to_cm(mm.group(2))
            if tw and th:
                mg["left"] = mg["right"] = round((spec["paper"][0] - tw) / 2, 2)
                mg["top"] = mg["bottom"] = round((spec["paper"][1] - th) / 2, 2)
        ok.append("Seitenränder aus geometry")
    else:
        # LaTeX-Standard: Textbreite ca. 345 pt bei A4 und 10 pt
        mg = spec["margins"]
        tw = {10: 345.0, 11: 360.0, 12: 390.0}.get(base, 360.0) / 72.27 * 2.54
        mg["left"] = mg["right"] = round((spec["paper"][0] - tw) / 2, 2)
        mg["top"] = 2.5
        mg["bottom"] = 3.0
        rep.append("Keine geometry-Angabe: Ränder nach LaTeX-Standard geschätzt.")

    # --- Schriften
    fam = SERIF
    pk = " ".join(a[0] for _, a, _ in commands(pre, "usepackage", 1) if a)
    sf_default = bool(re.search(r"\\renewcommand\{?\\familydefault\}?\{?\\sfdefault", pre))
    tt_default = bool(re.search(r"\\renewcommand\{?\\familydefault\}?\{?\\ttdefault", pre))
    main_set = False
    for cmd, key in (("setmainfont", "font"), ("setsansfont", "sans"), ("setmonofont", "mono")):
        for _, a, _ in commands(pre, cmd, 1):
            if a:
                nm = a[0].strip()
                if key == "font":
                    fam, main_set = nm, True
                else:
                    spec[key] = nm
                ok.append("Schrift %s" % nm)
    if not main_set:
        if sf_default:
            fam = spec["sans"]
        elif tt_default:
            fam = spec["mono"]
        elif not re.search(r"\b(mathptmx|times|tgtermes|newtxtext|libertine|libertinus|tgschola|palatino|mathpazo|charter)\b", pk):
            rep.append("Schrift: LaTeX-Standardschrift (Latin Modern) ist in Word und LibreOffice meist nicht da; Ersatz %s." % SERIF)
    spec["font"] = fam

    # --- Abstände
    m = re.search(r"\\linespread\{([0-9.]+)\}", pre)
    stretch = float(m.group(1)) if m else 1.0
    if re.search(r"\\onehalfspacing", pre):
        stretch = 1.25
    elif re.search(r"\\doublespacing", pre):
        stretch = 1.667
    m = re.search(r"\\setstretch\{([0-9.]+)\}", pre)
    if m:
        stretch = float(m.group(1))
    m = re.search(r"\\renewcommand\{?\\baselinestretch\}?\{([0-9.]+)\}", pre)
    if m:
        stretch = float(m.group(1))
    if leading is None:
        leading = {10: 12.0, 11: 13.6, 12: 14.5}.get(base, size_pt * 1.2)
    # Proportionaler Zeilenabstand: Liberation-Schriften haben rund 1,15 mal Schriftgröße als einfachen Zeilenabstand
    spec["line"] = round(max(0.8, leading * stretch / (size_pt * 1.15)), 3)
    ok.append("Zeilenabstand %d Prozent" % round(spec["line"] * 100))
    baseline = leading * stretch
    parskip, indent = 0.0, {10: 15.0, 11: 17.0, 12: 17.5}.get(base, 17.0) / 72.27 * 2.54
    if re.search(r"\\usepackage(?:\[[^\]]*\])?\{parskip\}", pre) or re.search(r"parskip(?:=(?:half|full|on|true))?", opts):
        parskip, indent = 0.5 * baseline / PT_PER_CM, 0.0
        if re.search(r"parskip=full", opts):
            parskip = baseline / PT_PER_CM
    for _, a, _ in commands(pre, "setlength", 2):
        if len(a) == 2:
            v = to_cm(a[1], size_pt, baseline)
            if a[0].strip() == "\\parskip" and v is not None:
                parskip = max(0.0, v)
            elif a[0].strip() == "\\parindent" and v is not None:
                indent = max(0.0, v)
    spec["parskip"] = round(parskip, 3) if parskip else 0.0
    spec["indent"] = round(indent, 3)
    spec["justify"] = not re.search(r"\\raggedright(?![A-Za-z])", pre)
    m = re.search(r"\\setlist(?:\[[^\]]*\])?\{[^}]*itemsep=([^,}]+)", pre)
    if m and to_cm(m.group(1), size_pt, baseline) is not None:
        spec["list_gap"] = round(to_cm(m.group(1), size_pt, baseline), 3)

    # --- Sprache
    if re.search(r"\\usepackage(?:\[[^\]]*\])?\{(?:babel|polyglossia)\}", pre) or "ngerman" in pre or "german" in pre:
        if re.search(r"ngerman|german|\\setmainlanguage\{german\}", pre):
            spec["lang"] = "de-DE"
        elif re.search(r"english|british|american", pre):
            spec["lang"] = "en-GB" if "british" in pre else "en-US"
        elif re.search(r"french", pre):
            spec["lang"] = "fr-FR"
    else:
        spec["lang"] = "en-US"
    ok.append("Sprache " + spec["lang"])

    # --- Überschriften
    heads = _default_headings(cls, base)
    names = LEVELS[cls]

    def level_of(cmdname):
        c = cmdname.lstrip("\\").strip()
        return names.index(c) + 1 if c in names else None

    def apply(lvl, props):
        h = heads[lvl]
        for k, v in props.items():
            h[k] = v
    # titlesec
    for opt, a, pos in commands(pre, "titleformat", 2):
        if not a:
            continue
        lv = level_of(a[0])
        if lv is None:
            miss.append("titleformat für %s" % a[0])
            continue
        apply(lv, parse_font_cmds(a[1] if len(a) > 1 else "", cols, base))
        ok.append("Überschrift %s (titlesec)" % a[0].strip())
    for opt, a, pos in commands(pre, "titlespacing", 4):
        if len(a) < 4:
            continue
        lv = level_of(a[0])
        if lv is None:
            continue
        b, af = to_cm(a[2], size_pt, baseline), to_cm(a[3], size_pt, baseline)
        if b is not None:
            heads[lv]["before"] = round(max(0, b), 3)
        if af is not None:
            heads[lv]["after"] = round(max(0, af), 3)
    # KOMA
    for cmd in ("setkomafont", "addtokomafont"):
        for _, a, _ in commands(pre, cmd, 2):
            if len(a) == 2:
                nm = a[0].strip()
                if nm in names:
                    apply(names.index(nm) + 1, parse_font_cmds(a[1], cols, base))
                    ok.append("Überschrift %s (KOMA-Schrift)" % nm)
                elif nm == "disposition":
                    for lv in heads:
                        apply(lv, parse_font_cmds(a[1], cols, base))
                    ok.append("Überschriften (KOMA disposition)")
    # sectsty
    for nm in names + ["part"]:
        for _, a, _ in commands(pre, nm + "font", 1):
            if a and nm in names:
                apply(names.index(nm) + 1, parse_font_cmds(a[0], cols, base))
                ok.append("Überschrift %s (sectsty)" % nm)
    for _, a, _ in commands(pre, "allsectionsfont", 1):
        if a:
            for lv in heads:
                apply(lv, parse_font_cmds(a[0], cols, base))
            ok.append("alle Überschriften (sectsty)")
    spec["headings"] = {str(k): v for k, v in heads.items()}
    if re.search(r"\\titleformat\{\\(?:chapter|part)", pre) and cls == "article":
        miss.append("titleformat für Kapitel (die Klasse hat keine Kapitel)")

    # --- Kopf- und Fußzeile
    ps = re.search(r"\\pagestyle\{([^}]+)\}", pre)
    style = ps.group(1) if ps else "plain"
    hdr, ftr = {"L": "", "C": "", "R": ""}, {"L": "", "C": "", "R": ""}
    if style in ("fancy", "scrheadings", "headings", "myheadings"):
        hf = style in ("fancy", "scrheadings")
        if re.search(r"\\fancyhf\{\}|\\clearpairofpagestyles|\\ihead\{\}|\\cfoot\{\}", pre):
            pass
        elif style == "fancy" and re.search(r"\\fancyhf", pre) is None:
            ftr["C"] = "{page}"
        if hf:
            def put(target, pos_list, txt):
                for p in pos_list:
                    target[p] = txt
            for cmd, tgt, pos in (("lhead", hdr, "L"), ("chead", hdr, "C"), ("rhead", hdr, "R"),
                                  ("lfoot", ftr, "L"), ("cfoot", ftr, "C"), ("rfoot", ftr, "R"),
                                  ("ihead", hdr, "L"), ("ohead", hdr, "R"), ("ifoot", ftr, "L"), ("ofoot", ftr, "R")):
                for opt, a, _ in commands(pre, cmd, 1):
                    if a:
                        put(tgt, [pos], _hf_text(a[0], cols))
            for cmd, tgt in (("fancyhead", hdr), ("fancyfoot", ftr)):
                for opt, a, _ in commands(pre, cmd, 1):
                    if a:
                        o = (opt or "C").upper()
                        zones = [z for z in "LCR" if z in re.sub(r"[^LCRlcr]", "", o).upper()] or ["C"]
                        if "E" in o and "O" not in o:
                            continue        # nur gerade Seiten
                        for z in zones:
                            tgt[z] = _hf_text(a[0], cols)
            def rule(nm, default):
                m = re.search(r"\\renewcommand\{?\\%s\}?\{\s*([^}]*)\}" % nm, pre)
                if not m:
                    return default
                v = to_cm(m.group(1))
                return bool(v and v > 0)
            has_h = any(hdr.values())
            has_f = any(ftr.values())
            spec["header_rule"] = rule("headrulewidth", style == "fancy") and has_h
            spec["footer_rule"] = rule("footrulewidth", False) and has_f
        else:
            miss.append("Kopfzeile \"%s\" (nur fancyhdr und scrlayer-scrpage werden gelesen)" % style)
        ok.append("Kopf- und Fußzeile (%s)" % style)
    elif style == "plain":
        ftr["C"] = "{page}"
    elif style == "empty":
        pass
    spec["header"] = hdr if any(hdr.values()) else None
    spec["footer"] = ftr if any(ftr.values()) else None

    # --- Nicht gelesenes melden
    for cmd, what in (("multicolumn", "Spalten"), ("usetikzlibrary", "TikZ"), ("lstset", "Quelltext-Format (listings)"),
                      ("renewcommand\\thesection", "Gliederungsnummern"), ("titleformat\\*", "")):
        pass
    if re.search(r"\\renewcommand\{?\\the(?:section|subsection|chapter)\}?", pre) or re.search(r"\\titleformat.*\{\\thesection", pre):
        miss.append("Nummerierung der Überschriften")
    if re.search(r"\\usepackage(?:\[[^\]]*\])?\{(?:tcolorbox|mdframed|framed)\}", pre):
        miss.append("Kästen (tcolorbox, mdframed)")
    if re.search(r"\\newcommand", pre):
        miss.append("eigene Makros (\\newcommand) – sie gehören zum Inhalt, nicht zur Formatvorlage")
    rep.insert(0, "Erkannt: " + "; ".join(ok) + "." if ok else "Erkannt: nur Standardwerte.")
    if miss:
        rep.append("Nicht übernommen: " + "; ".join(miss) + ".")
    return spec


# ---------------------------------------------------------------- ODT-Vorlage
def _x(s):
    return escape(s)


def _cm(v):
    return "%.3fcm" % v


def _hex(c):
    return "#" + c if c else None


def heading_xml(spec, lvl, body_font):
    h = spec["headings"].get(str(lvl)) or spec["headings"].get("4")
    props = ['fo:font-size="%.2fpt"' % h.get("size", spec["size"]),
             'fo:font-weight="%s"' % ("bold" if h.get("bold", True) else "normal"),
             'fo:font-style="%s"' % ("italic" if h.get("italic") else "normal")]
    fam = h.get("family")
    if fam:
        nm = {"sans": spec["sans"], "serif": spec["font"], "mono": spec["mono"]}[fam]
        props.append('style:font-name="%s" fo:font-family="\'%s\'"' % (_x(nm), _x(nm)))
    if h.get("color"):
        props.append('fo:color="#%s"' % h["color"])
    if h.get("upper"):
        props.append('fo:text-transform="uppercase"')
    if h.get("smallcaps"):
        props.append('fo:font-variant="small-caps"')
    al = {"center": "center", "right": "end", "left": "start"}.get(h.get("align", "left"), "start")
    pp = ('fo:margin-top="%s" fo:margin-bottom="%s" fo:keep-with-next="always" fo:text-align="%s" fo:text-indent="0cm"'
          % (_cm(h.get("before", 0.4)), _cm(h.get("after", 0.2)), al))
    return ('<style:style style:name="Heading_20_%d" style:display-name="Heading %d" style:family="paragraph" '
            'style:parent-style-name="Heading" style:next-style-name="Text_20_Body" style:default-outline-level="%d">'
            '<style:paragraph-properties %s/><style:text-properties %s/></style:style>'
            % (lvl, lvl, lvl, pp, " ".join(props)))


def _hf_para(parts, width_cm, style):
    """Eine Zeile mit linkem, mittigem und rechtem Teil über Tabulatoren."""
    def seg(t):
        t = _x(t)
        t = t.replace("{page}", "<text:page-number text:select-page=\"current\">1</text:page-number>")
        t = t.replace("{pages}", "<text:page-count>1</text:page-count>")
        t = t.replace("{date}", "<text:date style:data-style-name=\"Dat\" text:date-value=\"2000-01-01\">01.01.2000</text:date>")
        return t
    L, C, R = (seg(parts.get(k, "")) for k in "LCR")
    return '<text:p text:style-name="%s">%s<text:tab/>%s<text:tab/>%s</text:p>' % (style, L, C, R)


def styles_parts(spec):
    """Liefert (font_face_decls, styles, automatic_styles, master_styles) als XML-Text."""
    p = spec
    mg = p["margins"]
    pw, ph = p["paper"]
    text_w = pw - mg["left"] - mg["right"]
    fonts = {p["font"], p["sans"], p["mono"], SERIF, MONO}
    for h in p["headings"].values():
        pass
    decl = "".join('<style:font-face style:name="%s" svg:font-family="\'%s\'"/>' % (_x(f), _x(f)) for f in sorted(fonts))
    col = ' fo:color="#%s"' % p["color"] if p.get("color") else ""
    just = "justify" if p.get("justify") else "start"
    heads = "".join(heading_xml(p, i, p["font"]) for i in range(1, 7))
    heads += "".join('<style:style style:name="Heading_20_%d_Unnum" style:family="paragraph" '
                     'style:parent-style-name="Heading_20_%d"/>' % (i, i) for i in range(1, 7))
    h1 = p["headings"].get("1", {})
    title_size = max(h1.get("size", p["size"] * 1.5) * 1.2, p["size"] * 1.8)
    fn = max(6.0, round(p["size"] * 0.8, 1))
    hdr_rule = 'fo:border-bottom="0.5pt solid #000000" fo:padding-bottom="0.1cm"' if p.get("header_rule") else ""
    ftr_rule = 'fo:border-top="0.5pt solid #000000" fo:padding-top="0.1cm"' if p.get("footer_rule") else ""
    tabs = ('<style:tab-stops><style:tab-stop style:position="%s" style:type="center"/>'
            '<style:tab-stop style:position="%s" style:type="right"/></style:tab-stops>' % (_cm(text_w / 2), _cm(text_w)))
    styles = (
        '<style:default-style style:family="paragraph"><style:paragraph-properties fo:orphans="2" fo:widows="2"/>'
        '<style:text-properties style:font-name="%(f)s" fo:font-size="%(s).2fpt" fo:language="%(lg)s" fo:country="%(ct)s"%(col)s/></style:default-style>'
        '<style:style style:name="Standard" style:family="paragraph" style:class="text">'
        '<style:paragraph-properties fo:line-height="%(ln)d%%"/></style:style>'
        '<style:style style:name="Heading" style:family="paragraph" style:parent-style-name="Standard" style:next-style-name="Text_20_Body" style:class="text">'
        '<style:paragraph-properties fo:margin-top="0.4cm" fo:margin-bottom="0.2cm" fo:keep-with-next="always"/></style:style>'
        '%(heads)s'
        '<style:style style:name="Title" style:family="paragraph" style:parent-style-name="Heading" style:next-style-name="Text_20_Body" style:class="chapter">'
        '<style:paragraph-properties fo:text-align="center" fo:margin-top="0cm" fo:margin-bottom="0.5cm"/>'
        '<style:text-properties fo:font-size="%(ts).1fpt" fo:font-weight="bold"/></style:style>'
        '<style:style style:name="Subtitle" style:family="paragraph" style:parent-style-name="Heading" style:next-style-name="Text_20_Body" style:class="chapter">'
        '<style:paragraph-properties fo:text-align="center" fo:margin-top="0cm" fo:margin-bottom="0.4cm"/>'
        '<style:text-properties fo:font-size="%(ss).1fpt" fo:font-weight="normal"/></style:style>'
        '<style:style style:name="Text_20_Body" style:display-name="Text Body" style:family="paragraph" style:parent-style-name="Standard" style:class="text">'
        '<style:paragraph-properties fo:margin-top="0cm" fo:margin-bottom="%(pb)s" fo:text-indent="%(ind)s" fo:text-align="%(just)s" fo:line-height="%(ln)d%%"/></style:style>'
        '<style:style style:name="List_20_Contents" style:display-name="List Contents" style:family="paragraph" style:parent-style-name="Standard" style:class="list">'
        '<style:paragraph-properties fo:margin-top="0cm" fo:margin-bottom="%(lg2)s" fo:text-align="%(just)s" fo:line-height="%(ln)d%%"/></style:style>'
        '<style:style style:name="Table_20_Contents" style:display-name="Table Contents" style:family="paragraph" style:parent-style-name="Standard" style:class="extra"/>'
        '<style:style style:name="Quotations" style:family="paragraph" style:parent-style-name="Standard" style:class="html">'
        '<style:paragraph-properties fo:margin-left="1cm" fo:margin-right="0.5cm" fo:margin-top="0cm" fo:margin-bottom="%(pb)s" fo:text-align="%(just)s" fo:line-height="%(ln)d%%"/></style:style>'
        '<style:style style:name="Preformatted_20_Text" style:display-name="Preformatted Text" style:family="paragraph" style:parent-style-name="Standard" style:class="html">'
        '<style:paragraph-properties fo:margin-top="0cm" fo:margin-bottom="0cm"/>'
        '<style:text-properties style:font-name="%(mono)s" fo:font-size="%(ms).1fpt"/></style:style>'
        '<style:style style:name="Raw_20_Block" style:display-name="LaTeX Block" style:family="paragraph" style:parent-style-name="Standard">'
        '<style:paragraph-properties fo:margin-top="0.1cm" fo:margin-bottom="0.1cm" fo:background-color="#e6e6e6"/>'
        '<style:text-properties style:font-name="%(mono)s" fo:font-size="%(ms).1fpt"/></style:style>'
        '<style:style style:name="Raw_20_Text" style:display-name="LaTeX Text" style:family="text">'
        '<style:text-properties style:font-name="%(mono)s" fo:font-size="%(ms).1fpt" fo:background-color="#e6e6e6"/></style:style>'
        '<style:style style:name="Horizontal_20_Line" style:family="paragraph" style:parent-style-name="Standard">'
        '<style:paragraph-properties fo:margin-top="0cm" fo:margin-bottom="0.2cm" fo:border-bottom="0.5pt solid #000000" fo:padding="0cm"/></style:style>'
        '<style:style style:name="Footnote" style:family="paragraph" style:parent-style-name="Standard">'
        '<style:text-properties fo:font-size="%(fn).1fpt"/></style:style>'
        '<style:style style:name="Header" style:family="paragraph" style:parent-style-name="Standard" style:class="extra">'
        '<style:paragraph-properties fo:margin-bottom="0cm" %(hr)s>%(tabs)s</style:paragraph-properties>'
        '<style:text-properties fo:font-size="%(hs).1fpt"/></style:style>'
        '<style:style style:name="Footer" style:family="paragraph" style:parent-style-name="Standard" style:class="extra">'
        '<style:paragraph-properties fo:margin-bottom="0cm" %(fr)s>%(tabs)s</style:paragraph-properties>'
        '<style:text-properties fo:font-size="%(hs).1fpt"/></style:style>'
        '<number:date-style style:name="Dat"><number:day number:style="long"/><number:text>.</number:text>'
        '<number:month number:style="long"/><number:text>.</number:text><number:year number:style="long"/></number:date-style>'
    ) % dict(f=_x(p["font"]), s=p["size"], lg=p["lang"].split("-")[0], ct=(p["lang"].split("-") + ["DE"])[1], col=col,
             ln=round(p["line"] * 100), heads=heads, ts=title_size, ss=title_size * 0.6,
             pb=_cm(p["parskip"]), ind=_cm(p["indent"]), just=just, lg2=_cm(p["list_gap"]), mono=_x(p["mono"]),
             ms=max(6.0, round(p["size"] * 0.85, 1)), fn=fn, hr=hdr_rule, fr=ftr_rule, tabs=tabs,
             hs=max(6.0, round(p["size"] * 0.85, 1)))
    # Mit Kopf- oder Fußzeile liegt der Text um deren Höhe tiefer; die Ränder werden so verkleinert, dass der
    # Textbeginn dort bleibt, wo LaTeX ihn hat (geometry misst den Rand bis zum Text).
    top, bot = mg["top"], mg["bottom"]
    hdr_h = ftr_h = ""
    if p.get("header"):
        top = max(0.6, mg["top"] - 1.0)
        hdr_h = ('<style:header-style><style:header-footer-properties fo:min-height="%s" fo:margin-bottom="0.3cm"/></style:header-style>'
                 % _cm(max(0.3, mg["top"] - top - 0.3)))
    if p.get("footer"):
        bot = max(0.6, mg["bottom"] - 1.0)
        ftr_h = ('<style:footer-style><style:header-footer-properties fo:min-height="%s" fo:margin-top="0.3cm"/></style:footer-style>'
                 % _cm(max(0.3, mg["bottom"] - bot - 0.3)))
    auto = ('<style:page-layout style:name="pm1"><style:page-layout-properties fo:page-width="%s" fo:page-height="%s" '
            'fo:margin-top="%s" fo:margin-bottom="%s" fo:margin-left="%s" fo:margin-right="%s"/>%s%s</style:page-layout>'
            % (_cm(pw), _cm(ph), _cm(top), _cm(bot), _cm(mg["left"]), _cm(mg["right"]), hdr_h, ftr_h))
    master = '<style:master-page style:name="Standard" style:page-layout-name="pm1">'
    if p.get("header"):
        master += "<style:header>%s</style:header>" % _hf_para(p["header"], text_w, "Header")
    if p.get("footer"):
        master += "<style:footer>%s</style:footer>" % _hf_para(p["footer"], text_w, "Footer")
    master += "</style:master-page>"
    return decl, styles, auto, master


def write_ott(spec, path):
    """Schreibt die Spezifikation als ODT-Vorlage (.ott) mit allen Formaten und einem leeren Absatz."""
    from .odt_out import NS
    decl, styles, auto, master = styles_parts(spec)
    ns = NS
    st = ('<?xml version="1.0" encoding="UTF-8"?><office:document-styles %s office:version="1.2">'
          '<office:font-face-decls>%s</office:font-face-decls><office:styles>%s</office:styles>'
          '<office:automatic-styles>%s</office:automatic-styles><office:master-styles>%s</office:master-styles>'
          '</office:document-styles>' % (ns, decl, styles, auto, master))
    ct = ('<?xml version="1.0" encoding="UTF-8"?><office:document-content %s office:version="1.2">'
          '<office:automatic-styles/><office:body><office:text><text:p text:style-name="Text_20_Body"/>'
          '</office:text></office:body></office:document-content>' % ns)
    mime = "application/vnd.oasis.opendocument.text-template"
    manifest = ('<?xml version="1.0" encoding="UTF-8"?><manifest:manifest %s manifest:version="1.2">'
                '<manifest:file-entry manifest:full-path="/" manifest:media-type="%s"/>'
                '<manifest:file-entry manifest:full-path="content.xml" manifest:media-type="text/xml"/>'
                '<manifest:file-entry manifest:full-path="styles.xml" manifest:media-type="text/xml"/>'
                '<manifest:file-entry manifest:full-path="meta.xml" manifest:media-type="text/xml"/>'
                '</manifest:manifest>' % (NS, mime))
    meta = ('<?xml version="1.0" encoding="UTF-8"?><office:document-meta %s office:version="1.2"><office:meta>'
            '<meta:generator>Seifferts Text</meta:generator><dc:title>%s</dc:title></office:meta></office:document-meta>'
            % (NS, _x(spec.get("name", ""))))
    with zipfile.ZipFile(path, "w") as z:
        z.writestr(zipfile.ZipInfo("mimetype"), mime)
        z.writestr("META-INF/manifest.xml", manifest, zipfile.ZIP_DEFLATED)
        z.writestr("content.xml", ct, zipfile.ZIP_DEFLATED)
        z.writestr("styles.xml", st, zipfile.ZIP_DEFLATED)
        z.writestr("meta.xml", meta, zipfile.ZIP_DEFLATED)
    return path


def write_dotx(spec, path):
    """Word-Vorlage: ODT-Vorlage schreiben und von LibreOffice als dotx speichern."""
    from .readers import lo_convert
    with tempfile.TemporaryDirectory(prefix="seiffert-text-") as td:
        base = "vorlage"
        ott = write_ott(spec, os.path.join(td, base + ".ott"))
        out = lo_convert(ott, "dotx:MS Word 2007 XML Template", td, profile="seiffert-text-lo-vorlage")
        shutil.copyfile(out, path)
    return path


# ---------------------------------------------------------------- Speicher
def store_dir():
    d = os.path.join(os.path.expanduser("~"), ".config", "seiffert-text", "formatvorlagen")
    os.makedirs(d, exist_ok=True)
    return d


def _safe(name):
    s = re.sub(r"[^\w .-]", "_", name.strip(), flags=re.U).strip(" .")
    return s or "Vorlage"


def path_of(name, d=None):
    return os.path.join(d or store_dir(), _safe(name) + ".json")


def list_templates(d=None):
    out = []
    d = d or store_dir()
    for fn in sorted(os.listdir(d), key=str.lower):
        if fn.endswith(".json"):
            try:
                with open(os.path.join(d, fn), encoding="utf-8") as f:
                    sp = json.load(f)
                if isinstance(sp, dict) and "margins" in sp:
                    out.append(sp)
            except (OSError, ValueError):
                continue
    return out


def save_template(spec, d=None):
    with open(path_of(spec["name"], d), "w", encoding="utf-8") as f:
        json.dump(spec, f, ensure_ascii=False, indent=1)
    return path_of(spec["name"], d)


def load_template(name, d=None):
    with open(path_of(name, d), encoding="utf-8") as f:
        return json.load(f)


def delete_template(name, d=None):
    try:
        os.remove(path_of(name, d))
    except OSError:
        pass


def summary(spec):
    mg = spec["margins"]
    h = spec["headings"].get("1", {})
    return ("%s, %.1f pt, Zeilenabstand %d %%, Ränder %.1f/%.1f/%.1f/%.1f cm, Überschrift 1: %.1f pt%s" %
            (spec["font"], spec["size"], round(spec["line"] * 100), mg["top"], mg["right"], mg["bottom"], mg["left"],
             h.get("size", 0), " fett" if h.get("bold") else ""))
