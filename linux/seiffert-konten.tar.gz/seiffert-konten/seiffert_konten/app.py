"""Seifferts Konten als Linux-App (PySide6 mit QtWebEngine). Das HTML-Tool läuft eingebettet, die App führt die Daten."""
import fcntl
import json
import os
import subprocess
import sys

from . import config
from .config import Settings, DATA_DIR, INTERN_FILE, LOCK_FILE, LOG_FILE, PKG_DIR, VERSION
from .server import KontenServer, Logger
from .store import Store


def _chromium_flags(settings):
    flags = os.environ.get('QTWEBENGINE_CHROMIUM_FLAGS', '').split()
    scheme = settings.get('farbschema')
    if scheme == 'dunkel':
        flags.append('--blink-settings=preferredColorScheme=1')
    elif scheme == 'hell':
        flags.append('--blink-settings=preferredColorScheme=0')
    if settings.get('software_rendering'):
        flags.append('--disable-gpu')
    os.environ['QTWEBENGINE_CHROMIUM_FLAGS'] = ' '.join(flags)


def acquire_lock():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    fd = os.open(str(LOCK_FILE), os.O_RDWR | os.O_CREAT, 0o644)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        os.close(fd)
        return None
    return fd


def build_classes():
    """Qt-Klassen werden erst hier angelegt, damit das Modul auch ohne Oberfläche importiert werden kann."""
    from PySide6.QtCore import QObject, QTimer, QUrl, Signal
    from PySide6.QtGui import QAction, QDesktopServices, QIcon, QKeySequence
    from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineProfile, QWebEngineUrlRequestInterceptor
    from PySide6.QtWebEngineWidgets import QWebEngineView
    from PySide6.QtWidgets import QFileDialog, QMainWindow, QMessageBox

    class Blocker(QWebEngineUrlRequestInterceptor):
        """Die Seite darf nur mit der Linux-App sprechen. Alles andere (zum Beispiel die Google-Bibliothek) wird blockiert."""

        def interceptRequest(self, info):
            u = info.requestUrl()
            if u.scheme() in ('http', 'https', 'ws', 'wss', 'ftp') and u.host() != '127.0.0.1':
                info.block(True)

    class ExternalOpener(QWebEnginePage):
        def acceptNavigationRequest(self, url, nav_type, is_main):
            QDesktopServices.openUrl(url)
            QTimer.singleShot(0, self.deleteLater)
            return False

    class KontenPage(QWebEnginePage):
        def acceptNavigationRequest(self, url, nav_type, is_main):
            if url.scheme() in ('http', 'https') and url.host() != '127.0.0.1':
                QDesktopServices.openUrl(url)
                return False
            return True

        def createWindow(self, wtype):
            self._opener = ExternalOpener(self.profile(), self)
            return self._opener

    class Bridge(QObject):
        raise_requested = Signal()

    class KontenWindow(QMainWindow):
        def __init__(self, settings, store, server, bridge):
            super().__init__()
            self.settings, self.store, self.server = settings, store, server
            self.setWindowTitle('Seifferts Konten')
            icon = PKG_DIR / 'icon.png'
            if icon.exists():
                self.setWindowIcon(QIcon(str(icon)))
            w, h = (settings.get('fenster') or [1180, 860])[:2]
            self.resize(int(w), int(h))
            self.profile = QWebEngineProfile(self)  # ohne Namen: nichts bleibt im Browser-Speicher, die Linux-App führt die Daten
            self.blocker = Blocker(self)
            self.profile.setUrlRequestInterceptor(self.blocker)
            self.profile.downloadRequested.connect(self.on_download)
            self.page = KontenPage(self.profile, self)
            self.view = QWebEngineView(self)
            self.view.setPage(self.page)
            self.view.setZoomFactor(float(settings.get('zoom') or 1.0))
            self.setCentralWidget(self.view)
            self.pick_save = QFileDialog.getSaveFileName
            bridge.raise_requested.connect(self.bring_front)
            self._menus()
            self.statusBar().hide()

        # ---------- Menüs ----------
        def _menus(self):
            def act(menu, text, fn, keys=None):
                a = QAction(text, self)
                if keys is not None:
                    a.setShortcut(keys)
                a.triggered.connect(fn)
                menu.addAction(a)
                return a
            m = self.menuBar().addMenu('&Datei')
            act(m, 'Laptop-Sicherung jetzt anlegen', self.backup_now, 'Ctrl+Shift+S')
            act(m, 'Datenordner öffnen', self.open_folder)
            m.addSeparator()
            act(m, 'Google Drive im Browser öffnen', lambda: QDesktopServices.openUrl(QUrl('https://drive.google.com/drive/home')))
            act(m, 'Google-Anmelde-Adresse ändern …', lambda: self.page.runJavaScript('window.__LX && __LX.changeAddress()'))
            m.addSeparator()
            act(m, 'Andere HTML-Fassung laden …', self.choose_html)
            act(m, 'Mitgelieferte HTML-Fassung verwenden', self.reset_html)
            m.addSeparator()
            act(m, 'Beenden', self.close, QKeySequence.Quit)
            v = self.menuBar().addMenu('&Ansicht')
            act(v, 'Neu laden', self.view.reload, QKeySequence.Refresh)
            act(v, 'Größer', lambda: self.zoom(0.1), QKeySequence.ZoomIn)
            act(v, 'Kleiner', lambda: self.zoom(-0.1), QKeySequence.ZoomOut)
            act(v, 'Normale Größe', lambda: self.zoom(0), 'Ctrl+0')
            h = self.menuBar().addMenu('&Hilfe')
            act(h, 'Protokoll der Google-Zugriffe öffnen', lambda: self.open_path(LOG_FILE if LOG_FILE.exists() else DATA_DIR))
            act(h, 'Über Seifferts Konten', self.about)

        def zoom(self, d):
            z = 1.0 if d == 0 else max(0.5, min(3.0, round(self.view.zoomFactor() + d, 2)))
            self.view.setZoomFactor(z)
            self.settings.set('zoom', z)

        def open_path(self, p):
            try:
                subprocess.Popen(['xdg-open', str(p)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except OSError:
                pass

        def open_folder(self):
            self.open_path(self.store.folder)

        def toast(self, msg, ms=5000):
            self.page.runJavaScript('window.toast && toast(%s, %d)' % (json.dumps(msg), ms))

        def backup_now(self):
            try:
                name = self.store.manual_backup('manuell')
                self.toast('Laptop-Sicherung angelegt: ' + name)
            except Exception as e:
                QMessageBox.warning(self, 'Seifferts Konten', 'Die Sicherung war nicht möglich: %s' % e)

        def choose_html(self):
            p, _ = QFileDialog.getOpenFileName(self, 'HTML-Fassung von Seifferts Konten wählen', str(PKG_DIR), 'HTML (*.html *.htm)')
            if p:
                self.settings.set('html_datei', p)
                self.view.load(QUrl(self.server.url))

        def reset_html(self):
            self.settings.set('html_datei', '')
            self.view.load(QUrl(self.server.url))

        def about(self):
            QMessageBox.information(self, 'Seifferts Konten',
                'Seifferts Konten, Linux-App Version %s\n\nHTML-Fassung: %s\nDatenordner: %s\n\nDie Linux-App ist führend: Bei Unterschieden '
                'zwischen Laptop und Google Drive gilt der Stand hier.' % (VERSION, self.settings.html_datei(), self.store.folder))

        def bring_front(self):
            self.showNormal()
            self.raise_()
            self.activateWindow()

        # ---------- Downloads (Sicherungsdatei, CSV) ----------
        def on_download(self, d):
            name = d.downloadFileName() or 'download'
            start = os.path.join(str(config.documents_dir()), name)
            path, _ = self.pick_save(self, 'Speichern unter', start)
            if not path:
                d.cancel()
                return
            d.setDownloadDirectory(os.path.dirname(path))
            d.setDownloadFileName(os.path.basename(path))
            d.isFinishedChanged.connect(lambda: self.toast('Gespeichert: ' + path) if d.isFinished() else None)
            d.accept()

        def dispose(self):
            """Die Seite muss vor dem Profil gelöscht werden, sonst warnt QtWebEngine beim Beenden."""
            try:
                from shiboken6 import delete
                self.view.setPage(None)
                delete(self.page)
            except Exception:
                pass

        def closeEvent(self, e):
            try:
                self.settings.set('fenster', [self.width(), self.height()])
                self.store.stop()
                self.server.stop()
            finally:
                super().closeEvent(e)

    return {'Bridge': Bridge, 'KontenWindow': KontenWindow, 'KontenPage': KontenPage}


def main(argv=None):
    argv = list(sys.argv if argv is None else argv)
    settings = Settings()
    _chromium_flags(settings)
    from PySide6.QtCore import QTimer, QUrl
    from PySide6.QtWidgets import QApplication, QMessageBox
    app = QApplication(argv)
    app.setApplicationName('seiffert-konten')
    app.setApplicationDisplayName('Seifferts Konten')
    app.setDesktopFileName('seiffert-konten')

    lock = acquire_lock()
    if lock is None:
        QMessageBox.information(None, 'Seifferts Konten', 'Seifferts Konten läuft schon. Zwei Fenster würden dieselben Daten überschreiben.')
        return 1

    log = Logger()
    log('Start Seifferts Konten %s (Daten: %s)' % (VERSION, DATA_DIR))
    store = Store(settings.datenordner(), INTERN_FILE, log).load()
    store.start()
    C = build_classes()
    bridge = C['Bridge']()
    server = KontenServer(store, settings, log, on_raise=bridge.raise_requested.emit)
    server.start()
    win = C['KontenWindow'](settings, store, server, bridge)
    win.show()
    win.view.load(QUrl(server.url))

    def notes():
        for n in store.startup_notes:
            QMessageBox.warning(win, 'Seifferts Konten', n)
        store.startup_notes.clear()
    QTimer.singleShot(800, notes)
    rc = app.exec()
    store.stop()
    server.stop()
    win.dispose()
    return rc


if __name__ == '__main__':
    sys.exit(main())
