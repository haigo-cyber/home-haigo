"""Erzeugt die Symbole der Zentrale (seiffert_zentrale/icons/icon-N.png). Aufruf im Paketordner: python3 make_icons.py"""
from PIL import Image, ImageDraw
import os
os.makedirs("seiffert_zentrale/icons", exist_ok=True)
S = 1024
im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
d = ImageDraw.Draw(im)
d.rounded_rectangle([40, 40, S - 40, S - 40], radius=200, fill=(36, 93, 115, 255))        # Petrol wie im Farbdesign
cell, gap, x0, y0 = 250, 46, 0, 0
tot = 3 * cell + 2 * gap
x0 = y0 = (S - tot) // 2
cols = [(255, 255, 255), (255, 255, 255), (233, 165, 43), (255, 255, 255), (255, 255, 255), (255, 255, 255), (255, 255, 255), (255, 255, 255), (255, 255, 255)]
for i in range(9):
    r, c = divmod(i, 3)
    x, y = x0 + c * (cell + gap), y0 + r * (cell + gap)
    d.rounded_rectangle([x, y, x + cell, y + cell], radius=56, fill=cols[i] + ((255,) if i != 4 else (255,)))
d.rounded_rectangle([x0 + cell + gap, y0 + cell + gap, x0 + 2 * cell + gap, y0 + 2 * cell + gap], radius=56, fill=(233, 165, 43, 255))
for n in (16, 22, 24, 32, 48, 64, 128, 256):
    im.resize((n, n), Image.LANCZOS).save("seiffert_zentrale/icons/icon-%d.png" % n)
