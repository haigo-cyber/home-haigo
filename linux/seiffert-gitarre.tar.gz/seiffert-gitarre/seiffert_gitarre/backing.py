"""Begleitung: Schlagzeug-Sequencer und Keyboard als vorgerenderte Schleifen.

Die Schleifen werden außerhalb des Audio-Rückrufs berechnet (Hintergrund-Thread).
Im Rückruf wird nur noch gelesen, das kostet fast keine Rechenzeit.
"""
import re
import threading

import numpy as np

NOTE_PC = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}
CHORD_INTERVALS = {
    "": (0, 4, 7),
    "m": (0, 3, 7),
    "7": (0, 4, 7, 10),
    "m7": (0, 3, 7, 10),
    "maj7": (0, 4, 7, 11),
    "sus4": (0, 5, 7),
    "sus2": (0, 2, 7),
    "dim": (0, 3, 6),
    "aug": (0, 4, 8),
    "5": (0, 7, 12),
}
_CHORD_RE = re.compile(r"^([A-G])([#b]?)(maj7|m7|m|7|sus4|sus2|dim|aug|5|)$")


def parse_chords(text):
    """'Am F C7' -> [(Grundton als Tonhöhenklasse, Intervalle), ...]. ValueError bei Fehlern."""
    tokens = [t for t in re.split(r"[\s,|]+", text.strip()) if t]
    if not tokens:
        raise ValueError("Keine Akkorde angegeben")
    result = []
    for tok in tokens:
        m = _CHORD_RE.match(tok)
        if not m:
            raise ValueError("Unbekannter Akkord: " + tok)
        pc = NOTE_PC[m.group(1)]
        if m.group(2) == "#":
            pc += 1
        elif m.group(2) == "b":
            pc -= 1
        result.append((pc % 12, CHORD_INTERVALS[m.group(3)]))
    return result


def _fft_filter(x, sr, lo=None, hi=None):
    spec = np.fft.rfft(x)
    freqs = np.fft.rfftfreq(len(x), 1.0 / sr)
    mask = np.ones_like(freqs)
    if lo:
        mask *= 1.0 / (1.0 + (lo / np.maximum(freqs, 1.0)) ** 4)
    if hi:
        mask *= 1.0 / (1.0 + (freqs / hi) ** 4)
    return np.fft.irfft(spec * mask, len(x))


def _norm(x, peak=1.0):
    m = float(np.max(np.abs(x)))
    return x * (peak / m) if m > 0 else x


def make_drum_sounds(sr):
    rng = np.random.default_rng(7)

    def t(d):
        return np.arange(int(sr * d)) / sr

    tt = t(0.4)
    freq = 48 + 120 * np.exp(-tt * 30)
    kick = np.sin(2 * np.pi * np.cumsum(freq) / sr) * np.exp(-tt * 9)
    n = int(0.004 * sr)
    kick[:n] += rng.standard_normal(n) * 0.25
    kick = _norm(kick, 0.95)

    tt = t(0.3)
    noise = _fft_filter(rng.standard_normal(len(tt)), sr, lo=1800, hi=9000)
    body = np.sin(2 * np.pi * 185 * tt) * np.exp(-tt * 30) + 0.5 * np.sin(2 * np.pi * 330 * tt) * np.exp(-tt * 40)
    snare = _norm(noise * np.exp(-tt * 15), 0.8) + _norm(body, 0.6)
    snare = _norm(snare, 0.8)

    tt = t(0.06)
    hat = _norm(_fft_filter(rng.standard_normal(len(tt)), sr, lo=7000) * np.exp(-tt * 80), 0.35)
    tt = t(0.35)
    ohat = _norm(_fft_filter(rng.standard_normal(len(tt)), sr, lo=6500) * np.exp(-tt * 9), 0.35)
    tt = t(1.5)
    crash = _norm(_fft_filter(rng.standard_normal(len(tt)), sr, lo=4500) * np.exp(-tt * 2.6), 0.4)

    return {k: v.astype(np.float32) for k, v in
            {"kick": kick, "snare": snare, "hat": hat, "ohat": ohat, "crash": crash}.items()}


def _add_wrap(buf, start, snd, gain=1.0):
    length = len(buf)
    start %= length
    pos = 0
    remaining = len(snd)
    first = min(remaining, length - start)
    buf[start:start + first] += snd[:first] * gain
    pos += first
    remaining -= first
    while remaining > 0:
        m = min(remaining, length)
        buf[:m] += snd[pos:pos + m] * gain
        pos += m
        remaining -= m


def _tone(kind, f, dur, rel, sr):
    n_dur = max(1, int(dur * sr))
    n = n_dur + int(rel * sr)
    t = np.arange(n) / sr
    w = 2 * np.pi * f * t
    if kind == "epiano":
        y = (np.sin(w) + 0.45 * np.sin(2 * w) * np.exp(-t / 0.35) + 0.15 * np.sin(3 * w) * np.exp(-t / 0.15))
        y *= np.exp(-t / 1.1)
        att = int(0.004 * sr)
    elif kind == "organ":
        y = (np.sin(w) + 0.7 * np.sin(2 * w) + 0.5 * np.sin(3 * w) + 0.35 * np.sin(4 * w) + 0.2 * np.sin(6 * w)) / 2.75
        att = int(0.01 * sr)
    else:  # pad
        y = np.zeros(n)
        harmonics = max(1, min(14, int(7000 / f)))
        for detune in (2 ** (-6 / 1200), 2 ** (6 / 1200)):
            for h in range(1, harmonics + 1):
                y += np.sin(2 * np.pi * f * detune * h * t + h) / h ** 1.4
        y /= 2.0
        att = int(0.25 * sr)
    env = np.ones(n)
    if att > 0:
        env[:att] = np.linspace(0, 1, att, endpoint=False)
    n_rel = n - n_dur
    if n_rel > 0:
        env[n_dur:] = np.linspace(1, 0, n_rel) ** 2
    return (y * env).astype(np.float32)


def _bass_tone(f, dur, sr):
    n = int(dur * sr)
    t = np.arange(n) / sr
    y = np.sin(2 * np.pi * f * t) + 0.3 * np.sin(4 * np.pi * f * t)
    env = np.ones(n)
    a = int(0.008 * sr)
    r = min(n, int(0.06 * sr))
    env[:a] = np.linspace(0, 1, a, endpoint=False)
    env[n - r:] = np.linspace(1, 0, r)
    return (y * env * np.exp(-t / 1.5)).astype(np.float32)


def _midi_hz(m):
    return 440.0 * 2 ** ((m - 69) / 12.0)


def render_drums(pattern, steps, swing, bar_len, sounds):
    buf = np.zeros(bar_len, np.float32)
    gains = {"kick": 1.0, "snare": 0.9, "hat": 0.8, "ohat": 0.8, "crash": 0.8}
    for row, snd in sounds.items():
        cells = pattern.get(row, [])
        for i in range(min(steps, len(cells))):
            v = cells[i]
            if not v:
                continue
            pos = i + (swing / 3.0 if (steps == 16 and i % 2 == 1) else 0.0)
            start = int(round(pos * bar_len / steps))
            _add_wrap(buf, start, snd, gains.get(row, 1.0) * (1.0 if v == 1 else 0.5))
    return _norm(buf, 0.7) if np.max(np.abs(buf)) > 0 else buf


def _keys_events(style, notes, beat, bar_dur):
    if style == "pad":
        return [(0.0, notes, bar_dur * 0.98)]
    if style == "quarter":
        return [(k * beat, notes, beat * 0.85) for k in range(4)]
    if style == "eighth":
        return [(k * beat / 2, notes, beat / 2 * 0.8) for k in range(8)]
    if style == "offbeat":
        return [((k + 0.5) * beat, notes, beat * 0.35) for k in range(4)]
    # Arpeggio
    seq = list(notes[:3]) + [notes[0] + 12]
    seq = seq + seq[-2:0:-1]
    return [(k * beat / 2, [seq[k % len(seq)]], beat * 0.9) for k in range(8)]


def render_keys(chords, style, sound, bass, tempo, bar_len, sr):
    beat = 60.0 / tempo
    bar_dur = 4 * beat
    buf = np.zeros(bar_len * len(chords), np.float32)
    for b, (pc, intervals) in enumerate(chords):
        base = 60 + pc if pc < 6 else 48 + pc
        notes = [base + iv for iv in intervals]
        for t0, ns, dur in _keys_events(style, notes, beat, bar_dur):
            gain = 1.0 / np.sqrt(len(ns))
            for m in ns:
                snd = _tone(sound, _midi_hz(m), dur, 0.35, sr)
                _add_wrap(buf, int((b * bar_dur + t0) * sr), snd, gain)
        if bass:
            root = 36 + pc
            if style == "pad":
                hits = [(0.0, 2 * beat), (2 * beat, 2 * beat)]
            else:
                hits = [(k * beat, beat * 0.9) for k in range(4)]
            for t0, d in hits:
                snd = _bass_tone(_midi_hz(root), d, sr)
                _add_wrap(buf, int((b * bar_dur + t0) * sr), snd, 1.4)
    return _norm(buf, 0.5) if np.max(np.abs(buf)) > 0 else buf


class Backing:
    def __init__(self, sr=48000):
        self.sr = sr
        self.sounds = make_drum_sounds(sr)
        self.tempo = 100
        self.steps = 16
        self.swing = 0.0
        self.pattern = {}
        self.chords_text = "Am F C G"
        self.chords = parse_chords(self.chords_text)
        self.keys_style = "pad"
        self.keys_sound = "epiano"
        self.bass = True
        self.playing = False

        self.t = 0
        self._gain = 0.0
        self._used_bar = 0
        self._loops = None  # (bar_len, drum_loop, keys_loop)
        self._lock = threading.Lock()
        self._pending = False
        self._running = False

    # ---- Einstellungen (vom Oberflächen-Thread) ----
    def set_samplerate(self, sr):
        if sr != self.sr:
            self.sr = sr
            self.sounds = make_drum_sounds(sr)
            self._loops = None

    def set_chords(self, text):
        chords = parse_chords(text)  # kann ValueError auslösen
        self.chords_text = text
        self.chords = chords

    def play(self):
        self.playing = True

    def stop(self):
        self.playing = False

    # ---- Neuberechnen im Hintergrund ----
    def request_rebuild(self):
        with self._lock:
            self._pending = True
            if self._running:
                return
            self._running = True
        threading.Thread(target=self._work, daemon=True).start()

    def _work(self):
        while True:
            with self._lock:
                if not self._pending:
                    self._running = False
                    return
                self._pending = False
            try:
                self.rebuild_now()
            except Exception as exc:  # nie den Thread beenden
                self.last_error = repr(exc)

    def rebuild_now(self):
        sr = self.sr
        tempo = float(self.tempo)
        steps = self.steps
        swing = self.swing
        pattern = {k: list(v) for k, v in self.pattern.items()}
        chords = list(self.chords)
        style, sound, bass = self.keys_style, self.keys_sound, self.bass
        sounds = self.sounds
        bar_len = int(round(4 * 60.0 / tempo * sr))
        drums = render_drums(pattern, steps, swing, bar_len, sounds)
        keys = render_keys(chords, style, sound, bass, tempo, bar_len, sr)
        self._loops = (bar_len, drums, keys)

    # ---- Audio-Rückruf ----
    def render(self, n):
        """Gibt (Schlagzeug, Keyboard) als Float32-Felder der Länge n zurück."""
        zeros = np.zeros(n, np.float32)
        loops = self._loops
        if loops is None:
            return zeros, zeros
        bar_len, drum_loop, keys_loop = loops
        if self._used_bar and self._used_bar != bar_len:
            self.t = int(self.t * bar_len / self._used_bar)
        self._used_bar = bar_len
        target = 1.0 if self.playing else 0.0
        if target == 0.0 and self._gain == 0.0:
            self.t = 0
            return zeros, zeros
        idx = self.t + np.arange(n)
        d = drum_loop.take(idx, mode="wrap")
        k = keys_loop.take(idx, mode="wrap")
        if self._gain != target:
            ramp = np.linspace(self._gain, target, n, endpoint=False, dtype=np.float32)
            d = d * ramp
            k = k * ramp
            self._gain = target
        self.t = (self.t + n) % len(keys_loop)
        return d.astype(np.float32, copy=False), k.astype(np.float32, copy=False)
