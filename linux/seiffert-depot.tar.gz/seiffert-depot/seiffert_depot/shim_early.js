/* Seifferts Depot, Linux-App: Brücke zwischen dem HTML-Tool und der Linux-App (läuft vor dem Skript des Tools).
   1) localStorage wird aus dem Stand der Linux-App gefüllt, jede Änderung wird sofort an die Linux-App gemeldet.
   2) google.accounts.oauth2 ist nachgebaut: die Anmeldung läuft über den normalen Browser (linuxHandOff im veröffentlichten Tool).
   3) Aufrufe an www.googleapis.com laufen über die Linux-App (kein CORS-Problem). */
(function () {
  'use strict';
  var API = location.pathname.replace(/[^\/]*$/, '') + 'api/';
  var oFetch = window.fetch.bind(window);
  var LX = window.__LX = {api: API, fail: '', version: '__LX_VERSION__'};
  window.__lxInteractive = false;

  /* ---- 1) localStorage ---- */
  var SEED = /*__SEED__*/{};
  var proto = Storage.prototype, oSet = proto.setItem, oRem = proto.removeItem;
  try {
    localStorage.clear();
    Object.keys(SEED).forEach(function (k) { oSet.call(localStorage, k, SEED[k]); });
  } catch (e) { LX.fail = 'Der Speicher konnte nicht vorbereitet werden: ' + e.message; }

  function mine(k) { return typeof k === 'string' && k.indexOf('seifferts_depot') === 0; }
  function send(obj) {
    try {
      var x = new XMLHttpRequest();
      x.open('POST', API + 'ls', false);
      x.setRequestHeader('Content-Type', 'application/json');
      x.send(JSON.stringify(obj));
      if (x.status !== 200) LX.fail = 'Speichern auf dem Laptop fehlgeschlagen (Status ' + x.status + ')';
    } catch (e) { LX.fail = 'Speichern auf dem Laptop fehlgeschlagen: ' + e.message; }
  }
  proto.setItem = function (k, v) {
    oSet.call(this, k, v);
    if (this === window.localStorage && mine(String(k))) send({op: 'set', k: String(k), v: String(v)});
  };
  proto.removeItem = function (k) {
    oRem.call(this, k);
    if (this === window.localStorage && mine(String(k))) send({op: 'remove', k: String(k)});
  };

  /* ---- Hilfen ---- */
  function jget(p) { return oFetch(API + p, {cache: 'no-store'}).then(function (r) { return r.json(); }); }
  function jpost(p, o) {
    return oFetch(API + p, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(o || {})})
      .then(function (r) { return r.json(); });
  }
  LX.get = jget; LX.post = jpost;

  /* ---- 2) Google-Anmeldung ---- */
  function askAddress(cur) {
    return window.modal({
      title: 'Anmeldung bei Google',
      text: 'Die Anmeldung läuft über die veröffentlichte Fassung von Seifferts Depot in deinem normalen Browser. ' +
            'Bitte trage einmal die Internetadresse ein, unter der du Seifferts Depot im Browser öffnest, also die veröffentlichte depot.html (zum Beispiel auf GitHub Pages). ' +
            'Das ist nicht die Adresse eines Drive-Ordners. Sie wird gespeichert und lässt sich später ändern.',
      fields: [{label: 'Internetadresse der veröffentlichten Fassung', value: cur || ''}],
      ok: 'Weiter'
    }).then(function (r) {
      if (!r) return null;
      return jpost('config', {handoffUrl: r[0].trim()}).then(function (j) {
        if (j.error) { if (window.toast) window.toast(j.error, 7000); throw Object.assign(new Error(j.error), {code: 'adresse_ungueltig'}); }
        return j.handoffUrl;
      });
    });
  }
  /* Die Adresse wird vor dem Start der Anmeldung geklärt, damit das Zeitlimit des Tools erst danach läuft. */
  /* Gespeicherte Adresse ändern (Karte Google Drive und Menü Datei) */
  LX.changeAddress = function () {
    return jget('config').then(function (c) { return askAddress(c.handoffOk ? c.handoffUrl : ''); }).then(function (url) {
      if (url && window.toast) window.toast('Anmelde-Adresse gespeichert', 4000);
      return url;
    });
  };
  LX.ensureAddress = function () { return jget('config').then(function (c) { return c.handoffOk ? c.handoffUrl : askAddress(''); }); };
  function login(interactive) {
    /* Ohne Klick öffnet die App keinen Browser: die Hintergrund-Sicherung wartet dann auf die Anmeldung. */
    if (!interactive) return Promise.reject({soft: true, code: 'interaction_required'});
    return LX.ensureAddress().then(function (url) {
      if (!url) throw {code: 'popup_closed', message: 'Abgebrochen'};
      return jpost('login/start').then(function (s) {
        if (s.error) { if (window.toast) window.toast(s.error, 7000); throw {code: 'popup_failed_to_open', message: s.error}; }
        if (s.opened === false) {
          if (window.modal) window.modal({title: 'Browser konnte nicht geöffnet werden',
            text: 'Öffne bitte diese Adresse selbst in deinem Browser (markieren und kopieren). Die Anmeldung wird dann wie sonst an die App übergeben.',
            fields: [{label: 'Adresse', value: s.url}], ok: 'Schließen'});
        } else if (window.toast) window.toast('Der Browser wurde geöffnet. Bitte dort bei Google anmelden.', 9000);
        function warten() {
          return jget('login/wait?state=' + encodeURIComponent(s.state)).then(function (r) { return r && r.pending ? warten() : r; });
        }
        return warten();
      });
    }).then(function (r) {
      if (r && r.access_token) {
        return {access_token: r.access_token, expires_in: +r.expires_in || 3600, token_type: 'Bearer',
                scope: 'https://www.googleapis.com/auth/drive.file'};
      }
      throw {code: (r && r.error) || 'popup_closed', message: 'Anmeldung nicht abgeschlossen'};
    });
  }
  window.google = {accounts: {oauth2: {
    initTokenClient: function (cfg) {
      return {requestAccessToken: function () {
        login(!!window.__lxInteractive).then(function (r) { cfg.callback(r); }, function (e) {
          if (e && e.soft) cfg.callback({error: e.code});
          else if (cfg.error_callback) cfg.error_callback({type: (e && e.code) || 'unknown', message: e && e.message});
          else cfg.callback({error: (e && e.code) || 'unknown'});
        });
      }};
    },
    revoke: function (tok, cb) {
      jpost('revoke', {token: tok}).then(function () { if (cb) cb({successful: true}); }, function () { if (cb) cb({successful: false}); });
    },
    hasGrantedAllScopes: function () { return true; },
    hasGrantedAnyScope: function () { return true; }
  }}};

  /* ---- 3) Zugriffe auf Google über die Linux-App ---- */
  function headersObj(h) {
    var o = {};
    if (!h) return o;
    if (typeof h.forEach === 'function' && !Array.isArray(h) && h.constructor !== Object) h.forEach(function (v, k) { o[k] = v; });
    else if (Array.isArray(h)) h.forEach(function (p) { o[p[0]] = p[1]; });
    else Object.keys(h).forEach(function (k) { o[k] = h[k]; });
    return o;
  }
  function gfetch(url, init) {
    return jpost('google', {method: init.method || 'GET', url: url, headers: headersObj(init.headers), body: init.body == null ? null : String(init.body)})
      .then(function (j) {
        if (!j.status) throw new TypeError(j.error || 'Failed to fetch');
        var nullBody = j.status === 204 || j.status === 205 || j.status === 304;
        return new Response(nullBody ? null : j.body, {status: j.status, headers: {'Content-Type': j.contentType || 'application/json'}});
      });
  }
  window.fetch = function (input, init) {
    var url = typeof input === 'string' ? input : (input && input.url) || '';
    if (/^https:\/\/www\.googleapis\.com\//.test(url)) return gfetch(url, init || {});
    return oFetch(input, init);
  };
})();
