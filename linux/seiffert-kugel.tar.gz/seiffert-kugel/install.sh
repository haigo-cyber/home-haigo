#!/usr/bin/env bash
# Kugel-Uebersicht fuer cosmic-comp: holt die zu deinem COSMIC passende Quelle, baut sie mit dem Patch
# und legt das Ergebnis nach ~/.local/bin/cosmic-comp-kugel. Ohne sudo, ersetzt nichts am System.
#
#   ./install.sh            bauen und installieren (kann beim ersten Mal einige Minuten dauern)
#   ./install.sh --testen   die gebaute Version in einem Fenster starten (aus einer laufenden Sitzung)
#   ./install.sh --aktivieren   ersetzt /usr/bin/cosmic-comp (sudo, mit Sicherung)
#   ./install.sh --zurueck      stellt die Sicherung wieder her (sudo)
set -euo pipefail

HIER="$(cd "$(dirname "$0")" && pwd)"
PATCH="$HIER/cosmic-comp-kugel.patch"
ARBEIT="${XDG_CACHE_HOME:-$HOME/.cache}/seiffert-kugel"
ZIEL="$HOME/.local/bin/cosmic-comp-kugel"
SYSTEM=/usr/bin/cosmic-comp

case "${1:-}" in
  --testen)
    [ -x "$ZIEL" ] || { echo "Zuerst ./install.sh ohne Option ausfuehren."; exit 1; }
    echo "Starte die Kugel-Version in einem Fenster. Beenden mit Strg+C im Terminal."
    exec "$ZIEL" ;;
  --aktivieren)
    [ -x "$ZIEL" ] || { echo "Zuerst ./install.sh ohne Option ausfuehren."; exit 1; }
    [ -e "$SYSTEM.orig" ] || sudo cp "$SYSTEM" "$SYSTEM.orig"
    sudo install -m 755 "$ZIEL" "$SYSTEM"
    echo "Fertig. Bitte abmelden und neu anmelden. Zurueck geht es mit ./install.sh --zurueck"
    echo "Hinweis: Ein Paketupdate von cosmic-comp ueberschreibt die Datei wieder, dann ./install.sh --aktivieren erneut."
    exit 0 ;;
  --zurueck)
    [ -e "$SYSTEM.orig" ] || { echo "Keine Sicherung gefunden ($SYSTEM.orig)."; exit 1; }
    sudo install -m 755 "$SYSTEM.orig" "$SYSTEM"
    echo "Original wiederhergestellt. Bitte abmelden und neu anmelden."
    exit 0 ;;
  "") ;;
  *) echo "Unbekannte Option: $1"; exit 1 ;;
esac

# 1. Fehlende Pakete nachinstallieren (nur Arch)
PAKETE="base-devel git rust just lld pkgconf libxkbcommon libinput mesa seatd systemd-libs pixman libdisplay-info wayland fontconfig libxcb"
if command -v pacman >/dev/null 2>&1; then
  fehlt=$(pacman -T $PAKETE || true)
  if [ -n "$fehlt" ]; then
    echo "Es fehlen Pakete: $fehlt"
    sudo pacman -S --needed --noconfirm $fehlt
  fi
fi

# 2. Passende Version bestimmen: die des installierten Pakets
TAG="${KUGEL_TAG:-}"
if [ -z "$TAG" ] && command -v pacman >/dev/null 2>&1; then
  v=$(pacman -Q cosmic-comp 2>/dev/null | awk '{print $2}' | sed -E 's/^[0-9]+://; s/-[0-9]+$//' || true)
  [ -n "$v" ] && TAG="epoch-$v"
fi
if [ -z "$TAG" ]; then
  TAG="epoch-1.10.0"
  echo "cosmic-comp ist nicht installiert, nehme die gepruefte Version $TAG."
fi
if ! git ls-remote --exit-code --tags https://github.com/pop-os/cosmic-comp "$TAG" >/dev/null 2>&1; then
  echo "Kein passender Tag fuer die installierte Version gefunden (${TAG:-unbekannt})."
  echo "Mit KUGEL_TAG=epoch-1.10.0 ./install.sh kannst du einen Tag von Hand angeben."
  exit 1
fi
echo "Verwende cosmic-comp $TAG"

# 3. Quelle holen und patchen
rm -rf "$ARBEIT"; mkdir -p "$ARBEIT"
git -c advice.detachedHead=false clone --quiet --depth 1 --branch "$TAG" https://github.com/pop-os/cosmic-comp "$ARBEIT/cosmic-comp"
cd "$ARBEIT/cosmic-comp"
if ! git apply --check "$PATCH" 2>/dev/null; then
  echo "Der Patch passt nicht auf $TAG. Bitte schick mir diese Meldung, dann passe ich ihn an."
  exit 1
fi
git apply "$PATCH"

# 4. Bauen und installieren
cargo build --release
mkdir -p "$(dirname "$ZIEL")"
install -m 755 target/release/cosmic-comp "$ZIEL"

cat <<EOT

Fertig: $ZIEL

Naechste Schritte:
  1. Ausprobieren:   ./install.sh --testen
  2. Tastenkuerzel:  COSMIC Einstellungen, Tastatur, Eigene Kuerzel, neuer Eintrag mit dem Befehl
                     cosmic-comp-sphere  (zum Beispiel auf Super+S)
  3. Dauerhaft:      ./install.sh --aktivieren   (und danach neu anmelden)
EOT
