"""Eingebautes Terminal für Seifferts Dateien: Shell-Sitzungen über ein Pseudo-Terminal (pty).
Die Ausgabe geht als Base64 an die Oberfläche (Ereignis „term“), Eingaben kommen über api_term_write."""
from __future__ import annotations

import atexit
import base64
import fcntl
import os
import pty
import select
import shutil
import signal
import struct
import subprocess
import termios
import threading
import time

import backend as B

AppError = B.AppError
MAX_SESSIONS = 8
ENV_NAME = __import__("re").compile(r"^[A-Za-z_][A-Za-z0-9_]{0,63}$")


def _set_size(fd: int, cols: int, rows: int) -> None:
    fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack("HHHH", max(2, rows), max(2, cols), 0, 0))


class Terminals:
    TERM_PROGRAM = "seiffert-dateien"      # Seifferts Terminal setzt hier seinen eigenen Namen ein
    MAX_TERMS = MAX_SESSIONS

    def _term_init(self) -> None:
        if getattr(self, "_term_ready", False):
            return
        self._term_ready = True
        self._terms: dict[int, dict] = {}
        self._term_next = 1
        self._term_lock = threading.Lock()
        atexit.register(self._term_close_all)

    def _term_close_all(self) -> None:
        for tid in list(getattr(self, "_terms", {})):
            try:
                self.api_term_close(tid)
            except Exception:  # noqa: BLE001
                pass

    def api_term_open(self, cwd: str = "", cols: int = 80, rows: int = 24, shell: str = "", args: list | None = None,
                      env: dict | None = None, login: bool = False) -> dict:
        """Öffnet eine Sitzung. shell/args/env/login sind optional (Seifferts Terminal: Profile); ohne Angabe läuft $SHELL."""
        self._term_init()
        with self._term_lock:
            if len(self._terms) >= self.MAX_TERMS:
                raise AppError("Es laufen schon %d Terminals. Bitte eines schließen." % self.MAX_TERMS)
            tid = self._term_next
            self._term_next += 1
        d = os.path.expanduser(cwd) if cwd else os.path.expanduser("~")
        if not os.path.isdir(d):
            d = os.path.expanduser("~")
        wanted = (shell or "").strip()
        if wanted:
            found = wanted if os.path.isabs(wanted) and os.access(wanted, os.X_OK) else shutil.which(os.path.expanduser(wanted))
            if not found:
                raise AppError("Das Programm \"%s\" wurde nicht gefunden." % wanted)
            shell = found
        else:
            shell = os.environ.get("SHELL") or shutil.which("bash") or "/bin/sh"
            if not os.path.exists(shell):
                shell = shutil.which("sh") or "/bin/sh"
        extra = [str(a) for a in (args or []) if isinstance(a, (str, int, float))][:50]
        if login and not extra and os.path.basename(shell) in ("bash", "zsh", "fish", "sh", "dash", "ksh"):
            extra = ["-l"]
        master, slave = pty.openpty()
        env_extra = env
        try:
            _set_size(slave, int(cols), int(rows))
            env = dict(os.environ)
            env.update(TERM="xterm-256color", COLORTERM="truecolor", TERM_PROGRAM=self.TERM_PROGRAM)
            for k in ("QT_QPA_PLATFORM", "QTWEBENGINE_CHROMIUM_FLAGS", "SD_DEBUG", "PYTHONINSPECT"):
                env.pop(k, None)
            for k, v in (env_extra or {}).items():
                if isinstance(k, str) and ENV_NAME.match(k) and isinstance(v, str):
                    env[k] = v
            argv = [shell] + extra
            setsid = shutil.which("setsid")
            if setsid:
                argv = [setsid, "--ctty", shell] + extra
            proc = subprocess.Popen(argv, stdin=slave, stdout=slave, stderr=slave, cwd=d, env=env, close_fds=True,
                                    **({} if setsid else {"start_new_session": True}))
        except OSError as e:
            os.close(master)
            os.close(slave)
            raise AppError("Das Terminal konnte nicht gestartet werden: " + (e.strerror or str(e)))
        os.close(slave)
        t = {"proc": proc, "fd": master, "cwd": d, "shell": shell, "alive": True}
        with self._term_lock:
            self._terms[tid] = t
        threading.Thread(target=self._term_reader, args=(tid, t), name="sd-term-%d" % tid, daemon=True).start()
        return {"id": tid, "shell": os.path.basename(shell), "cwd": d}

    def _term_reader(self, tid: int, t: dict) -> None:
        fd, proc = t["fd"], t["proc"]
        while t["alive"]:
            try:
                r, _, _ = select.select([fd], [], [], 0.5)
            except (OSError, ValueError):
                break
            if not r:
                if proc.poll() is not None:
                    # Prozess ist beendet; Rest der Ausgabe noch lesen
                    try:
                        r2, _, _ = select.select([fd], [], [], 0.05)
                    except (OSError, ValueError):
                        break
                    if not r2:
                        break
                continue
            try:
                data = os.read(fd, 65536)
            except OSError:
                break
            if not data:
                break
            self.emit("term", {"id": tid, "data": base64.b64encode(data).decode("ascii")})
        t["alive"] = False
        try:
            code = proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            code = None
        self.emit("term", {"id": tid, "exit": code})

    def _term(self, tid: int) -> dict:
        self._term_init()
        t = self._terms.get(int(tid))
        if not t:
            raise AppError("Dieses Terminal gibt es nicht mehr.")
        return t

    def api_term_write(self, id: int, data: str) -> bool:
        t = self._term(id)
        if not t["alive"]:
            return False
        buf = (data or "").encode("utf-8", "replace")
        view = memoryview(buf)
        deadline = time.monotonic() + 3
        while view and time.monotonic() < deadline:
            try:
                _, w, _ = select.select([], [t["fd"]], [], 0.2)
                if w:
                    n = os.write(t["fd"], view)
                    view = view[n:]
            except OSError:
                return False
        return not view

    def api_term_resize(self, id: int, cols: int, rows: int) -> bool:
        t = self._term(id)
        try:
            _set_size(t["fd"], int(cols), int(rows))
        except OSError:
            return False
        return True

    HERDR_DIRS = ("~/.local/bin", "~/.cargo/bin", "~/bin", "/usr/local/bin", "/usr/bin", "/opt/homebrew/bin")

    def api_herdr_status(self) -> dict:
        """Ist herdr (Terminal-Multiplexer für Coding-Agenten, herdr.dev) installiert? Sucht auch dort, wo der Installer es ablegt,
        weil eine aus dem Menü gestartete Anwendung oft nicht den PATH der Shell hat."""
        path = shutil.which("herdr")
        if not path:
            for d in self.HERDR_DIRS:
                c = os.path.join(os.path.expanduser(d), "herdr")
                if os.path.isfile(c) and os.access(c, os.X_OK):
                    path = c
                    break
        if not path:
            return {"found": False, "path": "", "version": ""}
        ver = ""
        try:
            r = subprocess.run([path, "--version"], capture_output=True, text=True, timeout=4, stdin=subprocess.DEVNULL)
            ver = (r.stdout or r.stderr).strip().splitlines()[0][:80] if (r.stdout or r.stderr).strip() else ""
        except (OSError, subprocess.SubprocessError):
            pass
        return {"found": True, "path": path, "version": ver}

    def api_term_state(self, id: int) -> dict:
        t = self._term(id)
        proc = t["proc"]
        alive = t["alive"] and proc.poll() is None
        idle = False
        cwd = t["cwd"]
        if alive:
            try:
                idle = os.tcgetpgrp(t["fd"]) == proc.pid
            except OSError:
                idle = False
            try:
                cwd = os.readlink("/proc/%d/cwd" % proc.pid)
            except OSError:
                pass
        return {"alive": alive, "idle": idle, "cwd": cwd}

    def api_term_close(self, id: int) -> bool:
        self._term_init()
        with self._term_lock:
            t = self._terms.pop(int(id), None)
        if not t:
            return False
        t["alive"] = False
        proc = t["proc"]
        try:
            pgid = os.getpgid(proc.pid)
        except OSError:
            pgid = None
        if pgid != proc.pid:            # noch nicht in eigener Sitzung: auf keinen Fall die Gruppe der App treffen
            pgid = None
        for sig in (signal.SIGHUP, signal.SIGTERM, signal.SIGKILL):
            if proc.poll() is not None:
                break
            try:
                if pgid:
                    os.killpg(pgid, sig)
                else:
                    proc.send_signal(sig)
            except OSError:
                break
            try:
                proc.wait(timeout=0.4)
            except subprocess.TimeoutExpired:
                continue
        try:
            os.close(t["fd"])
        except OSError:
            pass
        return True
