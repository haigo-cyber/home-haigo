"""PDF-Quelltext: PDF als lesbaren Text öffnen, im Quelltext ändern, als neue Datei speichern.

Der Quelltext ist das PDF selbst in ausgepackter Form: Seiteninhalte stehen als lesbare Befehle da,
Bilder und Schriften als Hex-Zeichen. Beim Speichern werden die Längenangaben der Datenströme
neu berechnet und das Verzeichnis der Objekte repariert.
"""
import os
import re

from PySide6.QtCore import Qt
from PySide6.QtGui import QAction, QKeySequence, QTextCursor, QTextDocument
from PySide6.QtWidgets import (QApplication, QFileDialog, QInputDialog, QLabel, QLineEdit, QMainWindow,
                               QMessageBox)

from . import APP_NAME, VERSION
from .pdf_tools import PdfError, pymupdf
from .widgets import SourceEdit

_OBJ = re.compile(r"(\d+\s+\d+\s+obj\b)((?:(?!endobj).)*?)(\bstream\r?\n)(.*?)(\r?\n?endstream)", re.S)
_LEN = re.compile(r"/Length\s+(\d+\s+\d+\s+R|\d+)")


def pdf_source_text(path):
    if pymupdf is None:
        raise PdfError("Für den PDF-Quelltext fehlt das Python-Paket PyMuPDF. Bitte ./install.sh erneut ausführen.")
    try:
        doc = pymupdf.open(path)
    except Exception as e:
        raise PdfError("Das PDF konnte nicht geöffnet werden: %s" % e)
    if doc.needs_pass:
        raise PdfError("Das PDF ist mit einem Kennwort geschützt.")
    if not doc.is_pdf:
        raise PdfError("Die Datei ist kein PDF.")
    data = doc.tobytes(garbage=3, expand=255, ascii=True, pretty=True, clean=True,
                       deflate_images=True, deflate_fonts=True)
    doc.close()
    return data.decode("latin-1")


def fix_lengths(text):
    """Längenangaben aller Datenströme neu berechnen (sie stimmen nach einer Änderung nicht mehr)."""
    def f(m):
        head = _LEN.sub("/Length %d" % len(m.group(4).encode("latin-1")), m.group(2), count=1)
        return m.group(1) + head + m.group(3) + m.group(4) + m.group(5)
    return _OBJ.sub(f, text)


def build_pdf(text, dest):
    """Quelltext als PDF nach dest schreiben. Liefert (Seitenzahl, Hinweise)."""
    try:
        raw = fix_lengths(text).encode("latin-1")
    except UnicodeEncodeError as e:
        ch = text[e.start]
        line = text.count("\n", 0, e.start) + 1
        raise PdfError("Zeile %d enthält das Zeichen „%s“, das im PDF-Quelltext nicht direkt stehen kann. "
                       "Text in einem PDF muss in der Kodierung der jeweiligen Schrift stehen." % (line, ch))
    pymupdf.TOOLS.reset_mupdf_warnings()
    try:
        doc = pymupdf.open(stream=raw, filetype="pdf")
        n = doc.page_count
        if n < 1:
            raise ValueError("keine Seiten")
        for page in doc:                    # jede Seite einmal auswerten, damit Fehler jetzt auffallen
            page.get_text()
    except Exception as e:
        raise PdfError("Aus diesem Quelltext lässt sich kein PDF bilden (%s). Es wurde nichts gespeichert." % e)
    notes = [w for w in pymupdf.TOOLS.mupdf_warnings().split("\n")
             if w and "repair" not in w and "xref" not in w and "generation number" not in w
             and "? obj" not in w]
    tmp = dest + ".teil"
    try:
        doc.save(tmp, garbage=3, deflate=True)
        doc.close()
        os.replace(tmp, dest)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)
    return n, notes


def unicode_maps(text):
    """ToUnicode-Tabellen aus dem Quelltext: Liste von {zeichen: code-hex}."""
    maps = []
    for m in re.finditer(r"begincmap(.*?)endcmap", text, re.S):
        body = m.group(1)
        d = {}
        for blk in re.finditer(r"beginbfchar(.*?)endbfchar", body, re.S):
            for a, b in re.findall(r"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>", blk.group(1)):
                try:
                    d.setdefault(bytes.fromhex(b).decode("utf-16-be"), a.lower())
                except Exception:
                    pass
        for blk in re.finditer(r"beginbfrange(.*?)endbfrange", body, re.S):
            for a, b, c in re.findall(r"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>", blk.group(1)):
                try:
                    lo, hi, uni = int(a, 16), int(b, 16), int(c, 16)
                    for k in range(min(hi - lo + 1, 65536)):
                        d.setdefault(chr(uni + k), ("%0" + str(len(a)) + "x") % (lo + k))
                except Exception:
                    pass
        if d:
            maps.append(d)
    return maps


def encode_text(text, maps):
    """Mögliche Hex-Schreibweisen eines sichtbaren Textes (je Schrift eine)."""
    out = []
    for d in maps:
        if all(ch in d for ch in text):
            h = "".join(d[ch] for ch in text)
            if h not in out:
                out.append(h)
    return out


class PdfSourceWindow(QMainWindow):
    def __init__(self, path, main=None):
        super().__init__()
        self.main = main
        self.path = os.path.abspath(path)
        self.saved_as = None
        text = pdf_source_text(self.path)
        if len(text) > 60_000_000:
            raise PdfError("Der Quelltext dieses PDF ist zu groß für den Editor (%d MB)." % (len(text) // 1_000_000))
        self.maps = unicode_maps(text)
        self.hits = []
        self.resize(1100, 800)
        if main is not None:
            self.setWindowIcon(main.windowIcon())
        self.edit = SourceEdit()
        self.edit.setLineWrapMode(SourceEdit.LineWrapMode.NoWrap)
        self.edit.setPlainText(text)
        self.edit.document().setModified(False)
        self.edit.document().modificationChanged.connect(lambda _: self.update_title())
        self.setCentralWidget(self.edit)
        if main is not None and main.settings.get("paper_light", False):
            self.edit.setStyleSheet("QPlainTextEdit { background-color: #ffffff; color: #000000; }")

        def A(text, slot, key=None):
            a = QAction(text, self)
            a.triggered.connect(slot)
            if key:
                a.setShortcut(QKeySequence(key))
            return a
        a_save = A("Als neues PDF speichern …", self.save_as, "Ctrl+S")
        a_show = A("Gespeichertes PDF ansehen", self.show_result, "F5")
        a_find = A("Suchen", lambda: self.search.setFocus(), "Ctrl+F")
        a_next = A("Weitersuchen", self.find_next, "F3")
        a_text = A("Sichtbaren Text im Quelltext finden …", self.find_visible, "Ctrl+Shift+F")
        a_dec = A("Markierten Code entschlüsseln", self.decode_selection, "Ctrl+D")
        a_goto = A("Gehe zu Zeile …", self.goto_line, "Ctrl+G")
        mb = self.menuBar()
        m = mb.addMenu("&Datei")
        m.addAction(a_save)
        m.addAction(a_show)
        m.addSeparator()
        m.addAction(A("Schließen", self.close, "Ctrl+W"))
        m = mb.addMenu("&Bearbeiten")
        m.addAction(A("Rückgängig", self.edit.undo, "Ctrl+Z"))
        m.addAction(A("Wiederholen", self.edit.redo, "Ctrl+Shift+Z"))
        m.addSeparator()
        for a in (a_find, a_next, a_text, a_dec, a_goto):
            m.addAction(a)
        m = mb.addMenu("&Hilfe")
        m.addAction(A("Hinweise zum PDF-Quelltext", self.help))
        tb = self.addToolBar("Quelltext")
        tb.setMovable(False)
        tb.addAction(a_save)
        tb.addAction(a_show)
        tb.addSeparator()
        tb.addWidget(QLabel(" Suchen: "))
        self.search = QLineEdit()
        self.search.setMaximumWidth(280)
        self.search.returnPressed.connect(self.find_next)
        tb.addWidget(self.search)
        tb.addAction(a_text)
        tb.addAction(a_dec)
        self.statusBar().addPermanentWidget(QLabel("Version %s " % VERSION))
        self.update_title()
        self.statusBar().showMessage("Quelltext von %s. Gespeichert wird immer unter einem neuen Namen; "
                                     "das Original bleibt unverändert." % os.path.basename(self.path))

    def update_title(self):
        self.setWindowTitle("%s%s – %s %s PDF-Quelltext" % ("* " if self.edit.document().isModified() else "",
                                                         os.path.basename(self.path), APP_NAME, VERSION))

    # ---- Suchen
    def _find(self, needle, case=False):
        if not needle:
            return False
        flags = QTextDocument.FindFlag.FindCaseSensitively if case else QTextDocument.FindFlag(0)
        if self.edit.find(needle, flags):
            return True
        c = self.edit.textCursor()
        c.movePosition(QTextCursor.MoveOperation.Start)
        self.edit.setTextCursor(c)
        return self.edit.find(needle, flags)

    def find_next(self):
        if self.hits:
            for _ in range(len(self.hits)):
                h = self.hits.pop(0)
                self.hits.append(h)
                if self._find(h):
                    return
        if not self._find(self.search.text()):
            self.statusBar().showMessage("Nicht gefunden.", 4000)

    def find_visible(self):
        text, ok = QInputDialog.getText(self, "Sichtbaren Text finden",
                                        "Text, wie er auf der Seite steht (ein Wort oder Wortteil):")
        if not ok or not text:
            return
        codes = encode_text(text, self.maps)
        self.hits = ["<" + c + ">" for c in codes] + codes + ["(" + text + ")", text]
        self.search.setText("")
        src = self.edit.toPlainText().lower()
        found = [h for h in self.hits if h.lower() in src]
        if not found:
            self.hits = []
            QMessageBox.information(self, APP_NAME, (
                "„%s“ wurde im Quelltext nicht als zusammenhängende Zeichenfolge gefunden.\n\n"
                "Mögliche Gründe: Der Text ist im PDF in Stücke zerlegt (zwischen den Buchstaben stehen "
                "Abstandswerte), die Schrift hat keine Zuordnungstabelle, oder die Seite ist ein Bild. "
                "Versuchen Sie ein kürzeres Wortstück.") % text)
            return
        self.hits = found
        self.find_next()
        self.statusBar().showMessage("Schreibweise im Quelltext: %s   (F3 sucht weiter)" % "  oder  ".join(found[:3]),
                                     15000)

    def decode_selection(self):
        sel = self.edit.textCursor().selectedText().strip().strip("<>").replace(" ", "")
        if not sel or not re.fullmatch(r"[0-9A-Fa-f]+", sel):
            self.statusBar().showMessage("Bitte eine Hex-Zeichenfolge markieren, zum Beispiel <0102030405>.", 6000)
            return
        res = []
        for d in self.maps:
            inv = {v: k for k, v in d.items()}
            width = len(next(iter(inv)))
            if len(sel) % width:
                continue
            parts = [sel[i:i + width].lower() for i in range(0, len(sel), width)]
            if all(p in inv for p in parts):
                s = "".join(inv[p] for p in parts)
                if s not in res:
                    res.append(s)
        if res:
            QMessageBox.information(self, APP_NAME, "Der markierte Code bedeutet (je nach Schrift):\n\n" + "\n".join(res[:8]))
        else:
            self.statusBar().showMessage("Der Code passt zu keiner Zuordnungstabelle im PDF.", 6000)

    def goto_line(self):
        n, ok = QInputDialog.getInt(self, "Gehe zu Zeile", "Zeile:", 1, 1, max(1, self.edit.blockCount()))
        if ok:
            self.edit.goto_line(n)

    # ---- Speichern
    def save_as(self):
        start = self.saved_as or (os.path.splitext(self.path)[0] + " (bearbeitet).pdf")
        p, _ = QFileDialog.getSaveFileName(self, "Als neues PDF speichern", start, "PDF (*.pdf)")
        if not p:
            return False
        if not p.lower().endswith(".pdf"):
            p += ".pdf"
        return self.save_to(p)

    def save_to(self, p):
        if os.path.abspath(p) == self.path:
            QMessageBox.warning(self, APP_NAME, "Bitte einen neuen Dateinamen wählen. Das Original wird nicht überschrieben.")
            return False
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            n, notes = build_pdf(self.edit.toPlainText(), p)
        except PdfError as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.warning(self, APP_NAME, str(e))
            return False
        except Exception as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.warning(self, APP_NAME, "Speichern fehlgeschlagen:\n%s: %s" % (type(e).__name__, e))
            return False
        QApplication.restoreOverrideCursor()
        self.saved_as = os.path.abspath(p)
        self.edit.document().setModified(False)
        msg = "Gespeichert: %s (%d Seite(n))." % (self.saved_as, n)
        if notes:
            QMessageBox.information(self, APP_NAME, msg + "\n\nBeim Auswerten des Quelltexts gab es Hinweise, das PDF "
                                    "kann fehlerhaft aussehen:\n" + "\n".join(notes[:10]))
        self.statusBar().showMessage(msg + " F5 zeigt das Ergebnis.", 15000)
        return True

    def show_result(self):
        if not self.saved_as:
            self.statusBar().showMessage("Bitte zuerst als neues PDF speichern.", 5000)
            return
        if self.main is not None:
            self.main.open_file(self.saved_as)

    def help(self):
        QMessageBox.information(self, APP_NAME, (
            "Dieses Fenster zeigt das PDF selbst in ausgepackter Form. Seiteninhalte stehen zwischen "
            "stream und endstream als Befehle, zum Beispiel:\n\n"
            "BT … ET   Textblock\n/F1 24 Tf   Schrift F1 in 24 Punkt\n56.8 778.2 Td   Position\n"
            "(Text) Tj  oder  <0102> Tj   Text ausgeben\n0 0 0 rg   Füllfarbe (rot grün blau, 0 bis 1)\n"
            "x y b h re f   gefülltes Rechteck\n\n"
            "Text steht in vielen PDFs nicht als lesbare Buchstaben da, sondern als Hex-Code der jeweiligen "
            "Schrift (zum Beispiel <0102030405>). „Sichtbaren Text im Quelltext finden“ rechnet ein Wort in "
            "diese Schreibweise um und springt zur Stelle; „Markierten Code entschlüsseln“ zeigt, was ein Code "
            "bedeutet. Eingebettete Schriften enthalten oft nur die Buchstaben, die im Dokument vorkommen; "
            "andere Buchstaben lassen sich dann mit dieser Schrift nicht schreiben.\n\n"
            "Die Längenangaben (/Length) und das Objektverzeichnis müssen Sie nicht pflegen, sie werden beim "
            "Speichern neu berechnet. Gespeichert wird immer unter einem neuen Namen. Lässt sich aus dem "
            "Quelltext kein PDF bilden, wird nichts geschrieben."))

    def closeEvent(self, e):
        if self.edit.document().isModified():
            r = QMessageBox.question(self, APP_NAME, "Der Quelltext wurde geändert. Als neues PDF speichern?",
                                     QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard
                                     | QMessageBox.StandardButton.Cancel)
            if r == QMessageBox.StandardButton.Cancel or (r == QMessageBox.StandardButton.Save and not self.save_as()):
                e.ignore()
                return
        if self.main is not None and self in self.main.children_windows:
            self.main.children_windows.remove(self)
        e.accept()
