import os
import sys


def main():
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import QApplication
    from . import APP_NAME
    from .app import MainWindow, app_icon
    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    app = QApplication(sys.argv)
    app.setApplicationName("seiffert-text")
    app.setApplicationDisplayName(APP_NAME)
    app.setDesktopFileName("seiffert-text")
    app.setWindowIcon(app_icon())
    win = MainWindow([os.path.abspath(a) for a in args])
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
