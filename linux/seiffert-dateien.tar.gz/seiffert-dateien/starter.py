#!/usr/bin/env python3
"""Seifferts Starter: eine Wolke mit Eingabezeile zum schnellen Starten von Programmen, Dateien und Ordnern.

Er läuft als kleiner Hintergrunddienst und erscheint, wenn man ihn mit "seiffert-starter" aufruft
(zum Beispiel über ein Tastenkürzel wie Super+Leertaste). Programme kommen aus den .desktop-Dateien, Dateien und
Texttreffer aus dem Volltextindex von Seifferts Dateien, Ordner werden in Seifferts Dateien geöffnet.
Dateien öffnen sich mit dem Programm, das dort unter "Dateitypen und Programme" festgelegt ist."""
from __future__ import annotations

import os
import sys

SOCKET = "seiffert-starter-%s" % (os.getuid() if hasattr(os, "getuid") else "user")


def quick_send(argv: list[str]) -> bool:
    """Schneller Weg für das Tastenkürzel: Läuft der Starter schon, wird der Befehl sofort über den Socket geschickt,
    ohne erst Qt und die Suche zu laden (rund 30 statt 200 Millisekunden). Gibt True zurück, wenn damit alles erledigt ist."""
    import socket
    cmd, daemon = "toggle", False
    for a in argv[1:]:
        if a == "--daemon":
            daemon = True
        elif a in ("--show", "--hide", "--quit", "--toggle"):
            cmd = a[2:]
    path = os.path.join(os.environ.get("TMPDIR") or "/tmp", SOCKET)      # dort legt Qt (QLocalServer) den Socket an
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as c:
            c.settimeout(0.3)
            c.connect(path)
            if not daemon:                                               # Autostart bei laufendem Dienst: nichts tun
                c.sendall(cmd.encode())
                c.shutdown(socket.SHUT_WR)
                try:
                    c.recv(16)                                           # warten, bis der Starter gelesen und aufgelegt hat
                except OSError:
                    pass
        return True
    except (OSError, AttributeError):
        return False                                                     # läuft nicht (oder kein Unix-Socket): normaler Start


if __name__ == "__main__" and quick_send(sys.argv):
    sys.exit(0)

import json  # noqa: E402
import math  # noqa: E402
import threading  # noqa: E402
import time  # noqa: E402
from dataclasses import dataclass, field  # noqa: E402

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import backend as B  # noqa: E402
import foldericons as FI  # noqa: E402
import icongen as IG  # noqa: E402
import startersetup as SS  # noqa: E402

NAME = "Seifferts Starter"
KIND_ORDER = {"app": 0, "folder": 1, "file": 2, "text": 3, "system": 4}
KIND_LABEL = {"app": "Programm", "folder": "Ordner", "file": "Datei", "text": "Text", "system": "System"}
CATS = [("all", "Alles"), ("app", "Programme"), ("file", "Dateien"), ("folder", "Ordner"), ("text", "Volltext"), ("system", "System")]
# Anthrazit mit Metallglanz. Die Blasen sind anthrazitfarben mit einem Hauch ihrer Sorte (Weiß darauf hat weit über 4,5:1 Kontrast, auch
# halbdurchsichtig über Weiß, geprüft in tests/ui_starter.py); die Sorte erkennt man außerdem am Metallton des Rands: Programm Stahlblau,
# Ordner Gold, Datei Titan-Violett, Text Grünbronze, System Kupfer.
FILL = {"app": "#1d2a33", "folder": "#2e2819", "file": "#272235", "text": "#1c2d26", "system": "#33201f"}
METAL = {"app": ("#cfe6f5", "#6f9cb9"), "folder": ("#f6e3b0", "#b8873a"), "file": ("#e3d6f6", "#8a6fb5"),
         "text": ("#cdeedd", "#5b9876"), "system": ("#f8c9bd", "#b1523f")}   # (heller Schein, Grundton des Metalls)
STEEL = ("#e8edf2", "#8d97a3", "#3a4048")                                    # Rand der Platten: Schein, Mitte, Dunkel
TITLE_SERIF = False                                                          # Titel in der Wolke: False = klare Groteskschrift, True = Serifenschrift der App
PANEL = "#15181c"
FG, FG2, RING = "#ffffff", "#c9d4df", "#ffd479"
PANEL_ALPHA = 236
MAX_BUBBLES = 16
GLOSS = 112                # hellster Punkt der Blasen (Prozent)
LOOKS = ("metall", "aurora", "hud", "obsidian")
ENV_STYLE = os.environ.get("SEIFFERT_STARTER_STYLE", "")      # nur zum Ausprobieren: überstimmt die Einstellung
STYLE = ENV_STYLE if ENV_STYLE in LOOKS else "metall"          # Look der Wolke, wird beim Erscheinen aus den Einstellungen übernommen
NEON = {"app": "#35d0ff", "folder": "#ffb347", "file": "#b37bff", "text": "#4dffb0", "system": "#ff6a5c"}   # Leuchtfarbe je Sorte (nur die neuen Looks)
BUBBLE_ALPHA = 215         # kleinste Deckkraft der Blasenfläche (von 255); Blasen sind halbdurchsichtig wie die Karten des Karussells
# Farbdesigns von Seifferts Dateien: (Akzent dunkel, Akzent hell). Der Starter übernimmt das gewählte Farbdesign.
SKIN_COL = {"petrol": ("#245d73", "#6fb7cf"), "wald": ("#2b6a3d", "#7fc68f"), "bernstein": ("#85530a", "#e6b04f"),
            "beere": ("#8a2b5c", "#e69ac3"), "indigo": ("#3f4ba8", "#a3aef2"), "graphit": ("#38424d", "#b9c4d0"),
            "terrakotta": ("#9c3f26", "#f0a58c")}
SERIF = ["Iowan Old Style", "Palatino Linotype", "Palatino", "Book Antiqua", "Georgia", "DejaVu Serif", "serif"]


def panel_for(skin: str) -> str:
    """Anthrazitfläche mit einem Hauch der Farbe des Farbdesigns."""
    acc = SKIN_COL.get(skin, SKIN_COL["petrol"])[0].lstrip("#")
    base = (0x16, 0x19, 0x1d)
    mix = [round(int(acc[i:i + 2], 16) * 0.06 + base[k] * 0.94) for k, i in enumerate((0, 2, 4))]
    return "#%02x%02x%02x" % tuple(mix)


@dataclass
class Item:
    kind: str                 # app | folder | file | text
    title: str
    key: str                  # Programm-ID oder Pfad
    sub: str = ""             # Ordner, Beschreibung
    snippet: str = ""
    score: float = 0.0
    extra: dict = field(default_factory=dict)


# ---------------------------------------------------------------------------------------------- Suche
def _tokens(q: str) -> list[list[str]]:
    """Jedes Wort wird zu seinen Schreibweisen (ue/ü/u, ss/ß, oe/ö/o), damit Überblick auch mit ueberblick gefunden wird."""
    out = []
    for t in (q or "").split():
        if t.strip():
            v = {B.fold(t)} | set(B.spelling_variants(B.fold(t)))
            out.append(sorted(v, key=len, reverse=True))
    return out


def _forms(s: str) -> list[str]:
    return list({B.fold(s), B.canon(s.casefold())})


def match_score(toks: list[list[str]], title: str, extra: list[str] | None = None) -> float:
    """0 = passt nicht. Alle Wörter müssen passen; Anfang des Namens und Wortanfänge zählen mehr."""
    if not toks:
        return 0.0
    forms = _forms(title)
    words = [w for f in forms for w in f.replace("-", " ").replace("_", " ").replace(".", " ").split()]
    other = " ".join(f for e in (extra or []) for f in _forms(e))
    total = 0.0
    for variants in toks:
        best = 0.0
        for t in variants:
            for ft in forms:
                if ft == t:
                    best = max(best, 100.0)
                elif ft.startswith(t):
                    best = max(best, 85.0)
                elif t in ft:
                    best = max(best, 45.0)
            if any(w.startswith(t) for w in words):
                best = max(best, 65.0)
            if not best and other and t in other:
                best = 25.0
        if not best:
            return 0.0
        total += best
    return total / len(toks)


class Finder:
    """Sucht in Programmen, Favoriten und Ordnern, im Index (Dateien, Texte) und merkt sich, was oft gestartet wird."""

    def __init__(self, backend: "B.Backend", state_path: str | None = None) -> None:
        self.b = backend
        self.state_path = state_path or os.path.join(str(B.data_dir()), "starter.json")
        self.use: dict = {"app": {}, "path": {}}
        self._lock = threading.Lock()
        self._appic: dict[str, str] = {}
        self.reload_use()

    def reload_use(self) -> None:
        use: dict = {"app": {}, "path": {}}
        try:
            with open(self.state_path, encoding="utf-8") as f:
                d = json.load(f)
            if isinstance(d, dict):
                use["app"] = {k: int(v) for k, v in (d.get("app") or {}).items() if isinstance(v, (int, float))}
                use["path"] = {k: int(v) for k, v in (d.get("path") or {}).items() if isinstance(v, (int, float))}
        except (OSError, ValueError):
            pass
        self.use = use

    def refresh(self) -> None:
        """Liest Einstellungen (aus Seifferts Dateien) und Nutzungsdaten neu, damit Änderungen sofort gelten."""
        try:
            with self.b._cfg_lock:
                self.b.cfg = self.b._load_config()
        except Exception:  # noqa: BLE001 - alte Einstellungen bleiben gültig
            pass
        self._appic.clear()
        self.reload_use()

    def opts(self) -> dict:
        o = dict(B.STARTER_DEFAULTS)
        o.update(self.b.cfg.get("starter") or {})
        return o

    # ---- Nutzung merken
    def bump(self, kind: str, key: str) -> None:
        if not self.opts()["learn"]:
            return
        bucket = self.use["app" if kind == "app" else "path"]
        with self._lock:
            bucket[key] = bucket.get(key, 0) + 1
            if len(bucket) > 400:
                for k, _ in sorted(bucket.items(), key=lambda kv: kv[1])[:100]:
                    bucket.pop(k, None)
            try:
                os.makedirs(os.path.dirname(self.state_path), exist_ok=True)
                tmp = self.state_path + ".tmp"
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(self.use, f)
                os.replace(tmp, self.state_path)
            except OSError:
                pass

    def _bonus(self, kind: str, key: str) -> float:
        if not self.opts()["learn"]:
            return 0.0
        return min(15.0, 3.0 * self.use["app" if kind == "app" else "path"].get(key, 0))

    # ---- Quellen
    def apps(self, query: str, limit: int = 8) -> list[Item]:
        toks = _tokens(query)
        apps = self.b.api_apps_list()["apps"]
        out = []
        for a in apps:
            if toks:
                sc = match_score(toks, a["name"], [a["generic"], a["comment"]] + a["keywords"])
                if sc <= 0:
                    continue
            else:
                sc = 0.0
            sc += self._bonus("app", a["id"])
            if not toks and sc <= 0:
                continue
            out.append(Item("app", a["name"], a["id"], a["generic"] or a["comment"], score=sc, extra={"icon": a["icon"]}))
        out.sort(key=lambda i: (-i.score, B.fold(i.title)))
        return out[:limit]

    def favorites(self, query: str, limit: int = 8) -> list[Item]:
        toks = _tokens(query)
        out = []
        for f in self.b.cfg.get("favorites", []):
            if f.get("kind") != "path" or not os.path.isdir(f.get("target", "")):
                continue
            title = f.get("name") or os.path.basename(f["target"].rstrip("/")) or f["target"]
            sc = match_score(toks, title, [f["target"]]) if toks else 20.0
            if toks and sc <= 0:
                continue
            out.append(Item("folder", title, f["target"], f["target"],
                            score=sc + 20 + self._bonus("folder", f["target"]), extra={"fav": True, "color": str(f.get("color") or "")}))
        out.sort(key=lambda i: -i.score)
        return out[:limit]

    def folders(self, query: str, cid: int = 0, limit: int = 8, seconds: float = 1.0) -> list[Item]:
        toks = _tokens(query)
        if not toks:
            return []
        roots = [r for r in self.b.cfg.get("roots", []) if os.path.isdir(r)] or [os.path.expanduser("~")]
        seen, out = set(), []
        for r in roots[:6]:
            try:
                res = self.b.call("search_names", {"query": query, "root": r, "kind": "dir", "limit": 40, "max_seconds": seconds}, cid)
            except B.AppError:
                continue
            for e in res.get("results", []):
                if e["path"] in seen:
                    continue
                seen.add(e["path"])
                sc = match_score(toks, e["name"])
                if sc <= 0:
                    continue
                out.append(Item("folder", e["name"], e["path"], os.path.dirname(e["path"]), score=sc + self._bonus("folder", e["path"]) - 0.02 * e["path"].count("/")))
        out.sort(key=lambda i: -i.score)
        return out[:limit]

    def app_icon_for(self, path: str) -> str:
        """Symbolname des Programms, das zum Dateityp gehört (eigene Zuordnung vor Systemstandard); leer, wenn keins gefunden wird.
        Das Ergebnis wird je Dateiendung gemerkt, denn die Auflösung kann einen Aufruf von xdg-mime kosten."""
        ext = os.path.splitext(path)[1].lower()
        key = ext or path
        if key not in self._appic:
            try:
                a = self.b.app_for_path(path)
            except Exception:  # noqa: BLE001
                a = None
            self._appic[key] = (a or {}).get("icon", "") if a else ""
        return self._appic[key]

    def files(self, query: str, cid: int = 0, limit: int = 10) -> list[Item]:
        toks = _tokens(query)
        if not toks or max(len(t[0]) for t in toks) < 3:
            return []
        try:
            res = self.b.call("search_text", {"query": query, "limit": limit * 2}, cid)
        except B.AppError:
            return []
        out = []
        for h in res.get("results", []):
            nm = match_score(toks, h["name"])
            if nm > 0:
                it = Item("file", h["name"], h["path"], os.path.dirname(h["path"]), score=nm + self._bonus("file", h["path"]), extra={"ext": h.get("ext", "")})
            else:
                it = Item("text", h["name"], h["path"], os.path.dirname(h["path"]), snippet=h.get("snippet", ""),
                          score=30.0 + (10.0 if h.get("tier") else 0.0) + self._bonus("file", h["path"]), extra={"ext": h.get("ext", "")})
            out.append(it)
        out.sort(key=lambda i: -i.score)
        out = out[:limit]
        if self.opts().get("icons", True):
            for it in out:
                it.extra["appicon"] = self.app_icon_for(it.key)
        return out

    def system(self, query: str, limit: int = 5) -> list[Item]:
        """Systembefehle (Herunterfahren, Abmelden, ...). Nur bei Eingabe von mindestens zwei Zeichen, nie ohne Eingabe."""
        toks = _tokens(query)
        if not toks or len(query.strip()) < 2:
            return []
        conf = self.opts().get("sys") or {}
        out = []
        for sid, label, desc, words, ask, _c in SS.SYSTEM_CMDS:
            if not SS.system_enabled(sid, conf) or not SS.effective_command(sid, conf):
                continue
            sc = match_score(toks, label, words + [desc])
            if sc > 0:
                # klarer Treffer auf den Namen (ab vier Zeichen): gleichauf mit Programmen, sonst nur Beiwerk
                strong = sc >= 85.0 and len(query.strip()) >= 4
                out.append(Item("system", label, sid, desc, score=sc + 1.0 if strong else sc - 8.0, extra={"ask": ask}))
        out.sort(key=lambda i: -i.score)
        return out[:limit]

    def idle(self) -> list[Item]:
        """Ohne Eingabe: oft gestartete Programme und Favoriten."""
        o = self.opts()
        apps = [a for a in self.apps("", 12) if a.score > 0][:6] if o["src_apps"] else []
        return apps + (self.favorites("", 6) if o["src_favs"] else [])

    @staticmethod
    def merge(parts: dict[str, list[Item]], cat: str = "all", cap: int = MAX_BUBBLES) -> list[Item]:
        cap = max(1, int(cap))
        allitems = [i for lst in parts.values() for i in lst if cat == "all" or i.kind == cat or (cat == "file" and i.kind == "text")]
        if cat == "all":
            quota = {"app": 6, "folder": 5, "file": 5, "text": 4, "system": 3}
            pick, cnt = [], {k: 0 for k in quota}
            for i in sorted(allitems, key=lambda i: (-i.score, KIND_ORDER[i.kind])):
                if cnt[i.kind] < quota[i.kind] and len(pick) < cap:
                    pick.append(i)
                    cnt[i.kind] += 1
            return pick
        return sorted(allitems, key=lambda i: (-i.score, KIND_ORDER[i.kind]))[:cap]


# ---------------------------------------------------------------------------------------------- Öffnen
def open_in_dateien(path: str, select: str | None = None) -> bool:
    """Öffnet einen Ordner in Seifferts Dateien (laufende Instanz oder neuer Start)."""
    from PySide6.QtCore import QProcess
    from PySide6.QtNetwork import QLocalSocket
    name = "%s-%s" % (B.APP_ID, os.getuid() if hasattr(os, "getuid") else "user")
    sock = QLocalSocket()
    sock.connectToServer(name)
    payload = path + ("\x1f" + select if select else "")
    if sock.waitForConnected(300):
        sock.write(payload.encode("utf-8"))
        sock.flush()
        sock.waitForBytesWritten(500)
        sock.disconnectFromServer()
        return True
    here = os.path.dirname(os.path.abspath(__file__))
    app = os.path.join(here, "app.py")
    if os.path.isfile(app):
        return QProcess.startDetached(sys.executable, [app, path])
    import shutil
    exe = shutil.which("seiffert-dateien")
    return bool(exe) and QProcess.startDetached(exe, [path])


# ---------------------------------------------------------------------------------------------- Oberfläche
def build_ui():
    """Importiert Qt erst hier, damit die Suchlogik ohne Oberfläche getestet werden kann."""
    from PySide6.QtCore import QByteArray, QEvent, QObject, QPointF, QRect, QRectF, QSize, Qt, QTimer, QVariantAnimation, Signal
    from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor, QFont, QFontMetrics, QGuiApplication, QIcon, QLinearGradient, QPainter,
                               QPainterPath, QPalette, QPen, QPixmap, QRadialGradient)
    from PySide6.QtSvg import QSvgRenderer
    from PySide6.QtWidgets import QApplication, QLineEdit, QWidget

    W, H = 1000, 660
    IN_RECT = QRect(60, 30, W - 120, 56)
    CHIPS_Y = 98
    CLOUD = QRect(40, 140, W - 80, H - 140 - 92)
    DETAIL = QRect(60, H - 84, W - 120, 64)

    # ---- Programm-Symbole: Symbolthema des Desktops, absolute Pfade und die üblichen pixmaps-Ordner
    class IconBox:
        """Sucht Symbole von Programmen und hält sie zwischen. Nichts gefunden = None (dann gibt es keine Marke)."""
        EXT = (".svg", ".png", ".xpm", ".svgz")

        def __init__(self) -> None:
            self.icons: dict[str, QIcon | None] = {}
            self.pix: dict[tuple, QPixmap | None] = {}
            self.theme_read = 0.0

        def read_theme(self) -> None:
            """Symbolthema aus den Cinnamon-Einstellungen holen (höchstens alle 30 Sekunden), sonst das von Qt erkannte lassen."""
            if time.time() - self.theme_read < 30:
                return
            self.theme_read = time.time()
            name = ""
            try:
                import subprocess
                r = subprocess.run(["gsettings", "get", "org.cinnamon.desktop.interface", "icon-theme"], capture_output=True, text=True, timeout=1.5)
                if r.returncode == 0:
                    name = r.stdout.strip().strip("'\"")
            except (OSError, ValueError, __import__("subprocess").SubprocessError):
                pass
            if name and name != QIcon.themeName():
                QIcon.setThemeName(name)
                self.icons.clear()
                self.pix.clear()
            if not QIcon.fallbackThemeName():
                QIcon.setFallbackThemeName("hicolor")

        def _dirs(self) -> list[str]:
            data = os.environ.get("XDG_DATA_DIRS") or "/usr/local/share:/usr/share"
            home = os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share")
            return [home] + [d for d in data.split(":") if d]

        def find(self, name: str) -> QIcon | None:
            if not name:
                return None
            if name in self.icons:
                return self.icons[name]
            ic = None
            if os.path.isabs(name):
                if os.path.isfile(name):
                    cand = QIcon(name)
                    ic = cand if not cand.isNull() else None
            else:
                cand = QIcon.fromTheme(name)
                if not cand.isNull():
                    ic = cand
                else:
                    pth = IG.find_icon_file(name, QIcon.themeName())          # Notlösung: Ordner des Symbolthemas selbst durchsuchen
                    if pth:
                        c2 = QIcon(pth)
                        ic = c2 if not c2.isNull() else None
            self.icons[name] = ic
            return ic

        def pixmap(self, name: str, px: int) -> QPixmap | None:
            k = (name, px)
            if k not in self.pix:
                ic = self.find(name)
                pm = ic.pixmap(QSize(px * 2, px * 2)) if ic else None
                self.pix[k] = pm if pm is not None and not pm.isNull() else None
            return self.pix[k]

        def _svg(self, data: bytes, px: int) -> QPixmap | None:
            r = QSvgRenderer(QByteArray(data))
            if not r.isValid():
                return None
            pm = QPixmap(px * 2, px * 2)
            pm.fill(Qt.GlobalColor.transparent)
            q = QPainter(pm)
            q.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            r.render(q)
            q.end()
            return pm

        def folder(self, style: str, base: str, px: int) -> QPixmap | None:
            """Ordnersymbol genau wie in Seifferts Dateien (Stil und Farbe), einmal gezeichnet und dann wiederverwendet."""
            k = ("\x00folder", style, base, px)
            if k not in self.pix:
                self.pix[k] = self._svg(FI.svg_doc(style, base), px)
            return self.pix[k]

        def extfile(self, ext: str, group: str, prog: str, px: int) -> QPixmap | None:
            """Symbol zur Dateiendung (Blatt mit Endung) und darauf das Programmsymbol des zugeordneten Programms, falls eins gefunden wird."""
            k = ("\x00ext", ext, prog, px)
            if k not in self.pix:
                inner = int(px * IG.PROG_BOX[2] / 64 * 2)
                pg = self.pixmap(prog, max(8, inner // 2)) if prog else None
                pm = self._svg(IG.ext_svg_doc(ext, group, pg is not None), px)
                if pm is not None and pg is not None:
                    q = QPainter(pm)
                    q.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
                    f = pm.width() / 64.0
                    x, y, w, h = (v * f for v in IG.PROG_BOX)
                    sc = pg.scaled(int(w), int(h), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
                    q.drawPixmap(int(x + (w - sc.width()) / 2), int(y + (h - sc.height()) / 2), sc)
                    q.end()
                self.pix[k] = pm
            return self.pix[k]

        def system(self, sid: str, px: int) -> QPixmap | None:
            k = ("\x00sys", sid, px)
            if k not in self.pix:
                data = IG.system_svg_doc(sid)
                self.pix[k] = self._svg(data, px) if data else None
            return self.pix[k]

        def fileglyph(self, px: int, stroke: str) -> QPixmap | None:
            k = ("\x00file", stroke, px)
            if k not in self.pix:
                self.pix[k] = self._svg(FI.file_svg_doc(stroke), px)
            return self.pix[k]

    ICONS = IconBox()

    def col(hexs: str, a: int = 255) -> QColor:
        c = QColor(hexs)
        c.setAlpha(a)
        return c

    def hue(c: QColor, deg: int) -> QColor:
        h, sat, l, a = c.hslHue(), c.hslSaturation(), c.lightness(), c.alpha()
        out = QColor()
        out.setHsl((max(h, 0) + deg) % 360, max(sat, 90), l, a)
        return out

    def serif(px: int, bold: bool = True) -> QFont:
        """Schrift für Titel: klare Grotesk (Standard) oder, mit TITLE_SERIF, die Serifenschrift der App."""
        f = QFont()
        if TITLE_SERIF:
            f.setFamilies(SERIF)
            f.setBold(bold)
        else:
            f.setWeight(QFont.Weight.DemiBold if bold else QFont.Weight.Normal)
        f.setPixelSize(px)
        return f

    def mixc(a, b, t: float, alpha: int = 255) -> QColor:
        """Mischt zwei Farben (Hexwerte oder QColor), t = 0 ergibt a, t = 1 ergibt b."""
        ca, cb = QColor(a), QColor(b)
        out = QColor(round(ca.red() + (cb.red() - ca.red()) * t), round(ca.green() + (cb.green() - ca.green()) * t),
                     round(ca.blue() + (cb.blue() - ca.blue()) * t))
        out.setAlpha(alpha)
        return out

    def chrome(center, cl: QColor, cd: QColor, c2: QColor) -> QConicalGradient:
        """Gebürsteter Metallrand: scharfe weiße Lichter, heller Ton, Grundton, tiefer Schatten (wie gedrehtes Chrom)."""
        g = QConicalGradient(center, 135)
        for pos, c in ((0.00, col("#ffffff", 245)), (0.07, cl), (0.17, c2), (0.27, cd), (0.36, cl), (0.44, col("#ffffff", 235)), (0.52, cl),
                       (0.63, c2), (0.74, cd), (0.86, c2), (0.94, cl), (1.00, col("#ffffff", 245))):
            g.setColorAt(pos, c)
        return g

    class Bridge(QObject):
        got = Signal(int, str, list)

    def wrap(text: str, fm: QFontMetrics, width: int, lines: int) -> list[str]:
        import re
        pieces = []                                                      # (Stück, Trenner danach)
        for m in re.finditer(r"([^\s_.\-]+[_.\-]*)(\s*)", text):
            pieces.append((m.group(1), " " if m.group(2) else ""))
        out, cur = [], ""
        for w, sep in pieces:
            while fm.horizontalAdvance(w) > width:                      # sehr lange Stücke hart trennen
                k = max(1, len(w) * width // max(1, fm.horizontalAdvance(w)) - 1)
                if cur:
                    out.append(cur.rstrip())
                    cur = ""
                out.append(w[:k])
                w = w[k:]
            if fm.horizontalAdvance(cur + w) <= width:
                cur += w + sep
            else:
                out.append(cur.rstrip())
                cur = w + sep
        if cur.strip():
            out.append(cur.rstrip())
        if len(out) > lines:
            out = out[:lines]
            out[-1] = fm.elidedText(out[-1] + " …", Qt.TextElideMode.ElideRight, width)
        return out or [""]

    class Cloud(QWidget):
        def __init__(self, finder: Finder, backend: "B.Backend") -> None:
            super().__init__(None, Qt.WindowType.FramelessWindowHint | Qt.WindowType.Tool | Qt.WindowType.WindowStaysOnTopHint)
            self.f, self.b = finder, backend
            self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
            self.setWindowTitle(NAME)
            self.setFixedSize(W, H)
            self.setMouseTracking(True)
            self.items: list[Item] = []
            self._bodies: dict = {}
            self.rects: list[QRectF] = []
            self.sel = 0
            self.cat = "all"
            self.gen = 0
            self.parts: dict[str, list[Item]] = {}
            self.chip_rects: list[tuple[QRect, str]] = []
            self.pop = 1.0
            self.nohide_env = bool(os.environ.get("SEIFFERT_STARTER_NOHIDE"))
            self.autohide = not self.nohide_env
            self.show_icons = True
            self.fstyle, self.fcolor, self.accent_dark = "flach", "design", SKIN_COL["petrol"][1]
            self.panel = PANEL
            self.accent = SKIN_COL["petrol"]
            self.cats = list(CATS)
            self.armed = None
            self.edit = QLineEdit(self)
            self.edit.setGeometry(IN_RECT.adjusted(18, 6, -18, -6))
            self.edit.setPlaceholderText("Programm, Datei oder Ordner suchen …")
            self.edit.setStyleSheet("QLineEdit{background:transparent;border:0;color:%s;font-size:22px;selection-background-color:%s;selection-color:#0f1720}"
                                    % (FG, RING))
            self.apply_options()
            pal = self.edit.palette()
            pal.setColor(QPalette.ColorRole.PlaceholderText, QColor(FG2))
            self.edit.setPalette(pal)
            self.edit.textChanged.connect(self._changed)
            self.edit.installEventFilter(self)
            self.bridge = Bridge()
            self.bridge.got.connect(self._got)
            self.timer = QTimer(self)
            self.timer.setSingleShot(True)
            self.timer.setInterval(90)
            self.timer.timeout.connect(self._run)
            self.anim = QVariantAnimation(self)
            self.anim.setDuration(160)
            self.anim.setStartValue(0.0)
            self.anim.setEndValue(1.0)
            self.anim.valueChanged.connect(lambda v: (setattr(self, "pop", float(v)), self.update()))
            self.msg = ""
            self.moved = False

        # ---- Anzeigen und Verstecken
        def apply_options(self) -> None:
            """Übernimmt Einstellungen aus Seifferts Dateien: Farbdesign, Quellen, Verhalten."""
            o = self.f.opts()
            self._bodies.clear()                                     # Farben oder Look können sich geändert haben
            skin = self.f.b.cfg.get("skin", "petrol")
            self.accent = SKIN_COL.get(skin, SKIN_COL["petrol"])
            self.panel = panel_for(skin)
            global STYLE
            STYLE = ENV_STYLE if ENV_STYLE in LOOKS else (o.get("look") if o.get("look") in LOOKS else "metall")
            self.autohide = bool(o["autohide"]) and not self.nohide_env
            self.cap = int(o["bubbles"])
            self.show_icons = bool(o.get("icons", True))
            cfg = self.f.b.cfg
            self.fstyle = cfg.get("folder_style") if cfg.get("folder_style") in FI.STYLES else "flach"
            self.fcolor = cfg.get("folder_color") if cfg.get("folder_color") in FI.COLORS else "design"
            self.accent_dark = SKIN_COL.get(skin, SKIN_COL["petrol"])[1]
            if self.show_icons:
                ICONS.read_theme()
            have = {"app": o["src_apps"], "file": o["src_files"], "text": o["src_files"], "folder": o["src_favs"] or o["src_folders"], "system": o["src_system"]}
            self.cats = [c for c in CATS if c[0] == "all" or have.get(c[0], True)]
            if self.cat not in [c[0] for c in self.cats]:
                self.cat = "all"

        def summon(self) -> None:
            self.f.refresh()
            self.apply_options()
            scr = QGuiApplication.screenAt(QCursor.pos()) or QGuiApplication.primaryScreen()
            g = scr.availableGeometry()
            self.move(g.x() + (g.width() - W) // 2, g.y() + max(20, (g.height() - H) // 3))
            self.edit.clear()
            self.msg = ""
            self.cat = "all"
            self._run()
            self.show()
            self.raise_()
            self.activateWindow()
            self.edit.setFocus()

        def toggle(self) -> None:
            if self.isVisible():
                self.hide()
            else:
                self.summon()

        def changeEvent(self, ev) -> None:  # noqa: N802
            if ev.type() == QEvent.Type.ActivationChange and self.isVisible() and not self.isActiveWindow() and self.autohide:
                QTimer.singleShot(120, lambda: (self.hide() if self.isVisible() and not self.isActiveWindow() else None))
            super().changeEvent(ev)

        # ---- Suche
        def _changed(self, _t: str) -> None:
            self.timer.start()

        def _run(self) -> None:
            self.gen += 1
            self.moved = False
            gen, q, cat = self.gen, self.edit.text().strip(), self.cat
            self.b.cancel(gen - 1)
            if not q:
                self.parts = {"idle": self.f.idle()}
                self._rebuild()
                return
            o = self.f.opts()
            self.parts = {"app": self.f.apps(q) if o["src_apps"] and cat in ("all", "app") else [],
                          "fav": self.f.favorites(q) if o["src_favs"] and cat in ("all", "folder") else [],
                          "sys": self.f.system(q) if o["src_system"] and cat in ("all", "system") else []}
            self._rebuild()
            if o["src_folders"] and cat in ("all", "folder"):
                threading.Thread(target=lambda: self.bridge.got.emit(gen, "folder", self.f.folders(q, gen)), daemon=True).start()
            if o["src_files"] and cat in ("all", "file", "text"):
                threading.Thread(target=lambda: self.bridge.got.emit(gen, "file", self.f.files(q, gen)), daemon=True).start()

        def _got(self, gen: int, kind: str, items: list) -> None:
            if gen != self.gen:
                return
            self.parts[kind] = items
            self._rebuild(keep=True)

        def _rebuild(self, keep: bool = False) -> None:
            old = self.items[self.sel].key if keep and self.items and self.sel < len(self.items) else None
            seen, merged = set(), []
            for i in self.f.merge(self.parts, self.cat, self.cap):
                k = (i.kind if i.kind == "app" else "p", i.key)
                if k not in seen:
                    seen.add(k)
                    merged.append(i)
            self.items = merged
            if not keep:
                self.disarm()
            held = bool(self.armed and old == self.armed[0])
            self.sel = next((n for n, i in enumerate(self.items) if i.key == old), 0) if (old and (self.moved or held)) else 0
            self._layout()
            if not keep or len(self.items) != len(self.rects):
                self.anim.stop()
                self.anim.start()
            self.update()

        # ---- Wolke anordnen: größter Treffer in der Mitte, die anderen spiralförmig darum
        def _layout(self) -> None:
            rects: list[QRectF] = []
            cx, cy = CLOUD.center().x(), CLOUD.center().y()
            area = QRectF(CLOUD)
            for n, _it in enumerate(self.items):
                w, h = (210, 108) if n == 0 else (176, 94) if n < 4 else (154, 84) if n < 10 else (136, 74)
                placed = None
                for shrink in (1.0, 0.88, 0.76):
                    ww, hh = w * shrink, h * shrink
                    r = 0.0
                    ang = n * 0.9
                    for _ in range(420):
                        x, y = cx + r * math.cos(ang) * 1.45, cy + r * math.sin(ang)
                        rc = QRectF(x - ww / 2, y - hh / 2, ww, hh)
                        if area.contains(rc) and all(self._free(rc, o) for o in rects):
                            placed = rc
                            break
                        ang += 0.55
                        r += 2.2
                    if placed:
                        break
                rects.append(placed if placed else QRectF(-999, -999, 1, 1))
            self.rects = rects

        @staticmethod
        def _free(a: QRectF, b: QRectF) -> bool:
            dx, dy = a.center().x() - b.center().x(), a.center().y() - b.center().y()
            sx, sy = (a.width() + b.width()) / 2 + 4, (a.height() + b.height()) / 2 + 4
            return (dx / sx) ** 2 + (dy / sy) ** 2 >= 1.0

        # ---- Tasten
        def eventFilter(self, obj, ev) -> bool:  # noqa: N802
            if obj is self.edit and ev.type() == QEvent.Type.KeyPress:
                return self._key(ev)
            return super().eventFilter(obj, ev)

        def keyPressEvent(self, ev) -> None:  # noqa: N802
            if not self._key(ev):
                super().keyPressEvent(ev)

        def _key(self, ev) -> bool:
            k, m = ev.key(), ev.modifiers()
            K = Qt.Key
            if k == K.Key_Escape:
                if self.armed:
                    self.disarm()
                    self.update()
                elif self.edit.text():
                    self.edit.clear()
                else:
                    self.hide()
                return True
            if k in (K.Key_Return, K.Key_Enter):
                self.activate(alt=bool(m & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.AltModifier)))
                return True
            if k in (K.Key_Tab, K.Key_Backtab):
                step = -1 if (k == K.Key_Backtab or m & Qt.KeyboardModifier.ShiftModifier) else 1
                ids = [c for c, _ in self.cats]
                self.set_cat(ids[(ids.index(self.cat) + step) % len(ids)])
                return True
            if k in (K.Key_Up, K.Key_Down, K.Key_Left, K.Key_Right):
                self.move_sel({K.Key_Up: (0, -1), K.Key_Down: (0, 1), K.Key_Left: (-1, 0), K.Key_Right: (1, 0)}[k])
                return True
            return False

        def set_cat(self, cat: str) -> None:
            self.cat = cat
            self._run()

        def move_sel(self, d: tuple[int, int]) -> None:
            self.disarm()
            if not self.items:
                return
            cur = self.rects[self.sel].center()
            best, bs = None, 1e18
            for n, r in enumerate(self.rects):
                if n == self.sel or r.x() < 0:
                    continue
                dx, dy = r.center().x() - cur.x(), r.center().y() - cur.y()
                along = dx * d[0] + dy * d[1]
                if along <= 1:
                    continue
                perp = abs(dx * d[1]) + abs(dy * d[0])
                s = along + 2.2 * perp
                if s < bs:
                    best, bs = n, s
            if best is None:                                          # am Rand: reihum
                best = (self.sel + (1 if d[0] + d[1] > 0 else -1)) % len(self.items)
            self.sel = best
            self.moved = True
            self.update()

        def disarm(self) -> None:
            if self.armed:
                self.armed = None
                self.msg = ""

        def run_system(self, it: Item) -> None:
            o = self.f.opts()
            cmd = SS.effective_command(it.key, o.get("sys"))
            if not cmd:
                raise B.AppError("Für \"%s\" ist kein Befehl bekannt. Trage ihn unter Einstellungen, Starter einrichten, ein." % it.title)
            import subprocess
            try:
                subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
            except OSError as e:
                raise B.AppError("\"%s\" ließ sich nicht ausführen: %s" % (it.title, e))

        def activate(self, alt: bool = False, index: int | None = None) -> None:
            if index is not None:
                if index != self.sel:
                    self.disarm()
                self.sel = index
            if not self.items:
                return
            it = self.items[self.sel]
            try:
                if it.kind == "system":
                    if it.extra.get("ask") and self.f.opts()["sys_confirm"]:
                        if not (self.armed and self.armed[0] == it.key and time.time() - self.armed[1] < 8.0):
                            self.armed = (it.key, time.time())
                            self.msg = "%s? Enter bestätigt, Esc bricht ab." % it.title
                            self.update()
                            return
                    self.armed = None
                    self.run_system(it)                   # schlägt der Start fehl, bleibt die Wolke mit der Meldung offen
                    self.hide()
                    return
                if it.kind == "app":
                    self.b.call("launch_app", {"app_id": it.key})
                    self.f.bump("app", it.key)
                elif it.kind == "folder":
                    open_in_dateien(it.key)
                    self.f.bump("folder", it.key)
                elif alt:
                    open_in_dateien(os.path.dirname(it.key), select=it.key)
                    self.f.bump("file", it.key)
                else:
                    self.b.call("open_path", {"path": it.key})
                    self.f.bump("file", it.key)
            except B.AppError as e:
                self.msg = str(e)
                self.update()
                return
            self.hide()

        # ---- Maus
        def _hit(self, pos) -> int:
            for n in range(len(self.rects) - 1, -1, -1):
                r = self.rects[n]
                if r.x() >= 0 and ((pos.x() - r.center().x()) / (r.width() / 2)) ** 2 + ((pos.y() - r.center().y()) / (r.height() / 2)) ** 2 <= 1.0:
                    return n
            return -1

        def mouseMoveEvent(self, ev) -> None:  # noqa: N802
            n = self._hit(ev.position())
            if n >= 0 and n != self.sel:
                self.sel = n
                self.moved = True
                self.update()

        def mousePressEvent(self, ev) -> None:  # noqa: N802
            p = ev.position().toPoint()
            for rc, cid in self.chip_rects:
                if rc.contains(p):
                    self.set_cat(cid)
                    return
            n = self._hit(ev.position())
            if n >= 0:
                self.activate(alt=bool(ev.modifiers() & Qt.KeyboardModifier.ControlModifier), index=n)

        # ---- Zeichnen
        # ---- Zeichnen: Glas und Metall wie die Karten des Karussells
        def _plate_new(self, p: QPainter, rc: QRectF, radius: float, rim: bool, alpha: int, strong: bool) -> None:
            """Platten der neuen Looks. Aurora: Indigo mit Verlaufsrand. HUD: Schwarz mit Leuchtlinie und Eckwinkeln. Obsidian: Glas mit Ölfilmrand."""
            p.setPen(Qt.PenStyle.NoPen)
            if STYLE == "aurora":
                g = QLinearGradient(rc.topLeft(), rc.bottomRight())
                g.setColorAt(0.0, col("#1a1440", alpha))
                g.setColorAt(0.6, col("#0c0a22", alpha))
                g.setColorAt(1.0, col("#05040f", alpha))
            elif STYLE == "hud":
                g = QLinearGradient(rc.topLeft(), rc.bottomLeft())
                g.setColorAt(0.0, col("#0b1219", alpha))
                g.setColorAt(1.0, col("#04070a", alpha))
            else:
                g = QLinearGradient(rc.topLeft(), rc.bottomRight())
                g.setColorAt(0.0, col("#1c1f26", alpha))
                g.setColorAt(0.5, col("#0b0c10", alpha))
                g.setColorAt(1.0, col("#050507", alpha))
            p.setBrush(g)
            p.drawRoundedRect(rc, radius, radius)
            if STYLE == "obsidian":
                gl = QLinearGradient(rc.topLeft(), QPointF(rc.left(), rc.top() + rc.height() * 0.5))
                gl.setColorAt(0.0, col("#ffffff", 40))
                gl.setColorAt(0.9, col("#ffffff", 5))
                gl.setColorAt(1.0, col("#ffffff", 0))
                p.setBrush(gl)
                p.drawRoundedRect(rc.adjusted(1.6, 1.6, -1.6, -rc.height() * 0.5), radius - 1.5, radius - 1.5)
            if STYLE == "hud":
                p.setPen(QPen(col("#35d0ff", 12), 1))
                y = rc.top() + 3
                while y < rc.bottom() - 2:
                    p.drawLine(QPointF(rc.left() + radius * 0.4, y), QPointF(rc.right() - radius * 0.4, y))
                    y += 4
            if not rim:
                return
            p.setBrush(Qt.BrushStyle.NoBrush)
            r2 = rc.adjusted(0.9, 0.9, -0.9, -0.9)
            if STYLE == "hud":
                c = QColor("#35d0ff")
                for w, a in ((6, 18), (3, 34)) if strong else ((4, 14),):
                    p.setPen(QPen(col(c.name(), a), w))
                    p.drawRoundedRect(r2, radius, radius)
                p.setPen(QPen(col(c.name(), 150 if not strong else 215), 1.2))
                p.drawRoundedRect(r2, radius, radius)
                p.setPen(QPen(col("#aeeaff", 240), 2.2))                       # Eckwinkel, hell
                k = min(14.0, radius)
                for (x0, y0, sx, sy) in ((r2.left(), r2.top(), 1, 1), (r2.right(), r2.top(), -1, 1), (r2.left(), r2.bottom(), 1, -1), (r2.right(), r2.bottom(), -1, -1)):
                    p.drawLine(QPointF(x0 + sx * radius * 0.3, y0), QPointF(x0 + sx * (radius * 0.3 + k), y0))
                    p.drawLine(QPointF(x0, y0 + sy * radius * 0.3), QPointF(x0, y0 + sy * (radius * 0.3 + k)))
                return
            if STYLE == "aurora":
                if strong:
                    p.setPen(QPen(col("#7a5cff", 36), 6))
                    p.drawRoundedRect(r2, radius, radius)
                p.setPen(QPen(QBrush(self._spectrum(rc.center(), 160, 235 if strong else 170)), 1.8 if strong else 1.2))
            else:
                p.setPen(QPen(QBrush(self._spectrum(rc.center(), 320, 255 if strong else 190)), 1.8 if strong else 1.2))
            p.drawRoundedRect(r2, radius, radius)
            p.setPen(QPen(col("#ffffff", 28), 1))
            p.drawRoundedRect(rc.adjusted(2.4, 2.4, -2.4, -2.4), radius - 1.5, radius - 1.5)

        def _plate(self, p: QPainter, rc: QRectF, radius: float, rim: bool = True, alpha: int = PANEL_ALPHA, strong: bool = False) -> None:
            """Anthrazitplatte aus Glas und Metall: Farbverlauf von hellem Stahl nach Schwarz, Glanzlicht, Lichtkante und Chromrand."""
            if STYLE != "metall":
                self._plate_new(p, rc, radius, rim, alpha, strong)
                return
            base = QColor(self.panel)
            g = QLinearGradient(rc.topLeft(), rc.bottomLeft())
            g.setColorAt(0.0, mixc(base, "#707a85", 0.42, alpha))
            g.setColorAt(0.18, mixc(base, "#4a525c", 0.30, alpha))
            g.setColorAt(0.52, col(base.name(), alpha))
            g.setColorAt(1.0, mixc(base, "#000000", 0.45, alpha))
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(g)
            p.drawRoundedRect(rc, radius, radius)
            # Glanzlicht in der oberen Hälfte (scharfe Unterkante wie bei Glas)
            gl = QLinearGradient(rc.topLeft(), QPointF(rc.left(), rc.top() + rc.height() * 0.5))
            gl.setColorAt(0.0, col("#ffffff", 58))
            gl.setColorAt(0.92, col("#ffffff", 8))
            gl.setColorAt(1.0, col("#ffffff", 0))
            p.setBrush(gl)
            p.drawRoundedRect(rc.adjusted(1.6, 1.6, -1.6, -rc.height() * 0.5), radius - 1.5, radius - 1.5)
            # Wärme von unten: Widerschein der Akzentfarbe am unteren Rand
            wg = QLinearGradient(QPointF(rc.left(), rc.bottom()), QPointF(rc.left(), rc.bottom() - rc.height() * 0.42))
            wg.setColorAt(0.0, col(self.accent[1], 46 if strong else 28))
            wg.setColorAt(1.0, col(self.accent[1], 0))
            p.setBrush(wg)
            p.drawRoundedRect(rc.adjusted(1.6, rc.height() * 0.58, -1.6, -1.6), radius - 1.5, radius - 1.5)
            if rim:
                lite = mixc(STEEL[0], self.accent[1], 0.30 if strong else 0.12)
                pen = QPen(QBrush(chrome(rc.center(), lite, QColor(STEEL[2]), mixc(STEEL[1], self.accent[0], 0.18))), 2.2 if strong else 1.4)
                p.setPen(pen)
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawRoundedRect(rc.adjusted(0.9, 0.9, -0.9, -0.9), radius, radius)
                p.setPen(QPen(col("#000000", 120), 1))                   # dunkle Innenkante: Rand wirkt aufgesetzt
                p.drawRoundedRect(rc.adjusted(2.2, 2.2, -2.2, -2.2), radius - 1.5, radius - 1.5)

        def paintEvent(self, _ev) -> None:  # noqa: N802
            p = QPainter(self)
            p.setRenderHint(QPainter.RenderHint.Antialiasing)
            p.setRenderHint(QPainter.RenderHint.TextAntialiasing)
            lite = QColor(self.accent[1])
            # weiche, durchscheinende Wolke hinter den Blasen, mit Schein in der Farbe des Farbdesigns
            cloud = QPainterPath()
            cloud.setFillRule(Qt.FillRule.WindingFill)
            for r in self.rects:
                if r.x() >= 0:
                    cloud.addEllipse(r.adjusted(-34, -28, 34, 28))
            cg = QRadialGradient(QPointF(CLOUD.center()), CLOUD.width() * 0.55)
            if STYLE == "aurora":
                cg.setColorAt(0.0, col("#2a1f66", 150))
                cg.setColorAt(0.5, col("#0f0b2c", 138))
                cg.setColorAt(1.0, col("#04030c", 120))
            elif STYLE == "hud":
                cg.setColorAt(0.0, col("#0a1a24", 140))
                cg.setColorAt(1.0, col("#020406", 120))
            elif STYLE == "obsidian":
                cg.setColorAt(0.0, col("#16181e", 150))
                cg.setColorAt(1.0, col("#030304", 125))
            else:
                cg.setColorAt(0.0, mixc(self.panel, self.accent[0], 0.22, 150))
                cg.setColorAt(0.6, col(self.panel, 132))
                cg.setColorAt(1.0, mixc(self.panel, "#000000", 0.5, 120))
            p.fillPath(cloud, cg)
            p.setBrush(Qt.BrushStyle.NoBrush)
            if STYLE == "aurora":
                p.setPen(QPen(QBrush(self._spectrum(CLOUD.center(), 160, 90)), 1))
            elif STYLE == "hud":
                dash = QPen(col("#35d0ff", 90), 1)
                dash.setStyle(Qt.PenStyle.DashLine)
                p.setPen(dash)
            elif STYLE == "obsidian":
                p.setPen(QPen(QBrush(self._spectrum(CLOUD.center(), 320, 80)), 1))
            else:
                p.setPen(QPen(mixc("#c9d1da", lite, 0.25, 70), 1))
            p.drawPath(cloud.simplified())
            # Eingabezeile (halbtransparent, aber so deckend, dass die Schrift lesbar bleibt)
            self._plate(p, QRectF(IN_RECT), 28, strong=True)
            # Reiter
            f = QFont(self.font())
            f.setPixelSize(14)
            p.setFont(f)
            fm = QFontMetrics(f)
            x = IN_RECT.left() + 6
            self.chip_rects = []
            for cid, label in self.cats:
                w = fm.horizontalAdvance(label) + 28
                rc = QRect(x, CHIPS_Y, w, 28)
                on = cid == self.cat
                if on and STYLE != "metall":
                    self._plate(p, QRectF(rc), 14, strong=True)
                    p.setPen(Qt.PenStyle.NoPen)
                    gg = QLinearGradient(QPointF(rc.bottomLeft()), QPointF(rc.left(), rc.top()))
                    gg.setColorAt(0.0, col("#35d0ff", 70))
                    gg.setColorAt(1.0, col("#35d0ff", 0))
                    p.setBrush(gg)
                    p.drawRoundedRect(QRectF(rc).adjusted(2, rc.height() * 0.4, -2, -2), 12, 12)
                elif on:
                    ac = QColor(self.accent[0])
                    g = QLinearGradient(QPointF(rc.topLeft()), QPointF(rc.bottomLeft()))
                    g.setColorAt(0.0, mixc(ac, "#ffffff", 0.22))
                    g.setColorAt(0.5, ac)
                    g.setColorAt(1.0, mixc(ac, "#000000", 0.45))
                    p.setPen(QPen(col(RING), 2))
                    p.setBrush(g)
                    p.drawRoundedRect(rc, 14, 14)
                    gl = QLinearGradient(QPointF(rc.topLeft()), QPointF(rc.left(), rc.center().y()))
                    gl.setColorAt(0.0, col("#ffffff", 70))
                    gl.setColorAt(1.0, col("#ffffff", 0))
                    p.setPen(Qt.PenStyle.NoPen)
                    p.setBrush(gl)
                    p.drawRoundedRect(QRectF(rc).adjusted(3, 2.5, -3, -rc.height() * 0.48), 11, 11)
                else:
                    self._plate(p, QRectF(rc), 14)
                p.setPen(col(FG if on else FG2))
                p.drawText(rc, Qt.AlignmentFlag.AlignCenter, label)
                self.chip_rects.append((rc, cid))
                x += w + 8
            # Blasen: erst die hinteren, die gewählte zuletzt (liegt oben)
            order = [n for n in range(len(self.items)) if n != self.sel] + ([self.sel] if self.items else [])
            for n in order:
                self._bubble(p, n, self.items[n], n == self.sel)
            if not self.items:
                rc = QRectF(CLOUD.center().x() - 230, CLOUD.center().y() - 26, 460, 52)
                self._plate(p, rc, 26)
                p.setPen(col(FG))
                f2 = QFont(self.font())
                f2.setPixelSize(16)
                p.setFont(f2)
                txt = "Nichts gefunden." if self.edit.text().strip() else "Tippe, um zu suchen."
                p.drawText(rc, Qt.AlignmentFlag.AlignCenter, txt)
            # Detailzeile
            self._plate(p, QRectF(DETAIL), 16)
            self._detail(p)
            p.end()

        # ---- Neue Looks: Aurora, Neon-HUD, Obsidian-Glas
        def _tone(self, kind: str):
            """(heller Ton, Grundton) der Sorte: im Metall-Look das Metall, sonst die Leuchtfarbe."""
            if STYLE == "metall":
                return QColor(METAL[kind][0]), QColor(METAL[kind][1])
            n = QColor(NEON[kind])
            return mixc(n, "#ffffff", 0.40), n

        @staticmethod
        def _spectrum(center, start: float = 200, alpha: int = 255) -> QConicalGradient:
            """Schillernder Verlauf: Cyan, Blau, Violett, Magenta, Bernstein, zurück zu Cyan."""
            g = QConicalGradient(center, start)
            for pos, c in ((0.00, "#35d0ff"), (0.20, "#4f7bff"), (0.40, "#b37bff"), (0.60, "#ff5fd2"), (0.80, "#ffb347"), (1.00, "#35d0ff")):
                g.setColorAt(pos, col(c, alpha))
            return g

        def _aura(self, p: QPainter, rr: QRectF, c: QColor, selected: bool) -> None:
            """Leuchthof um eine Blase: weiche Schichten in der Leuchtfarbe, bei Auswahl kräftiger."""
            layers = ((30, 20), (20, 30), (11, 44), (5, 60)) if selected else ((18, 10), (10, 16), (5, 24))
            p.setPen(Qt.PenStyle.NoPen)
            for k, a in layers:
                p.setBrush(col(c.name(), a))
                p.drawEllipse(rr.adjusted(-k, -k * 0.7, k, k * 0.7))

        def _body_aurora(self, p: QPainter, rr: QRectF, it: Item, selected: bool, base: QColor, mlite: QColor, mmid: QColor) -> None:
            """Look Aurora: Orb aus Indigo-Schwarz mit Nebel, Sternenstaub, Leuchtkante im Farbverlauf und Umlaufbahn."""
            p.setPen(Qt.PenStyle.NoPen)
            for k, a in ((14, 18), (8, 30), (4, 44)):
                p.setBrush(col("#000000", a))
                p.drawEllipse(rr.translated(0, 10).adjusted(-k + 6, -k / 2 + 3, k - 6, k / 2 - 3))
            self._aura(p, rr, mmid, selected)
            cx = rr.center()
            g = QRadialGradient(QPointF(cx.x() - rr.width() * 0.16, cx.y() - rr.height() * 0.22), rr.width() * 0.78)
            g.setColorAt(0.0, mixc("#241a52", mmid, 0.14, 240))
            g.setColorAt(0.55, col("#0e0b26", 246))
            g.setColorAt(1.0, col("#04030d", 250))
            p.setBrush(g)
            p.drawEllipse(rr)
            clip = QPainterPath()
            clip.addEllipse(rr.adjusted(1.5, 1.5, -1.5, -1.5))
            p.save()
            p.setClipPath(clip)
            for fx, fy, rad, c, al in ((0.80, 0.86, 0.62, mmid, 78), (0.14, 0.12, 0.55, QColor("#a45bff"), 66), (0.50, 1.02, 0.45, QColor("#ff5fd2"), 44)):
                rg = QRadialGradient(QPointF(rr.left() + rr.width() * fx, rr.top() + rr.height() * fy), rr.width() * rad)
                rg.setColorAt(0.0, col(c.name(), al))
                rg.setColorAt(1.0, col(c.name(), 0))
                p.setBrush(rg)
                p.drawRect(rr)
            seed = sum(ord(ch) for ch in it.title) + 7                       # Sternenstaub: feste Punkte je Titel, kein Flackern
            for q in range(26):
                seed = (seed * 1103515245 + 12345) & 0x7FFFFFFF
                px = rr.left() + (seed % 1000) / 1000 * rr.width()
                seed = (seed * 1103515245 + 12345) & 0x7FFFFFFF
                py = rr.top() + (seed % 1000) / 1000 * rr.height()
                p.setBrush(col("#ffffff", 30 + (seed % 5) * 9))
                p.drawEllipse(QPointF(px, py), 0.8 + (seed % 3) * 0.3, 0.8 + (seed % 3) * 0.3)
            p.restore()
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.setPen(QPen(col(mmid.name(), 40), 5))                           # Leuchtkante, weich
            p.drawEllipse(rr.adjusted(2, 2, -2, -2))
            p.setPen(QPen(QBrush(self._spectrum(rr.center(), 140)), 1.9))      # Haarlinie im Farbverlauf
            p.drawEllipse(rr.adjusted(1.2, 1.2, -1.2, -1.2))
            orb = QPainterPath()                                              # Umlaufbahn mit Satellit
            ring = rr.adjusted(8, 8, -8, -8)
            orb.arcMoveTo(ring, 205)
            orb.arcTo(ring, 205, 110)
            p.setPen(QPen(col(mlite.name(), 120), 1.1))
            p.drawPath(orb)
            end = orb.currentPosition()
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(col(mmid.name(), 70))
            p.drawEllipse(end, 5.0, 5.0)
            p.setBrush(col("#ffffff", 235))
            p.drawEllipse(end, 2.0, 2.0)
            if selected:
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.setPen(QPen(mixc(mmid, "#ffffff", 0.55), 2.6))
                p.drawEllipse(rr.adjusted(-3, -3, 3, 3))

        def _body_hud(self, p: QPainter, rr: QRectF, it: Item, selected: bool, base: QColor, mlite: QColor, mmid: QColor) -> None:
            """Look Neon-HUD: fast schwarze Scheibe, Rasterlinien, Ring aus Leuchtsegmenten, Teilstriche an den Himmelsrichtungen."""
            p.setPen(Qt.PenStyle.NoPen)
            for k, a in ((12, 16), (6, 30)):
                p.setBrush(col("#000000", a))
                p.drawEllipse(rr.translated(0, 9).adjusted(-k + 6, -k / 2 + 3, k - 6, k / 2 - 3))
            self._aura(p, rr, mmid, selected)
            g = QLinearGradient(rr.topLeft(), rr.bottomRight())
            g.setColorAt(0.0, mixc("#0b1118", mmid, 0.10, 238))
            g.setColorAt(1.0, col("#030507", 248))
            p.setBrush(g)
            p.drawEllipse(rr)
            clip = QPainterPath()
            clip.addEllipse(rr.adjusted(1.5, 1.5, -1.5, -1.5))
            p.save()
            p.setClipPath(clip)
            p.setPen(QPen(col(mmid.name(), 20), 1))                           # Rasterlinien
            y = rr.top() + 3
            while y < rr.bottom():
                p.drawLine(QPointF(rr.left(), y), QPointF(rr.right(), y))
                y += 4
            lg = QLinearGradient(QPointF(rr.left(), rr.bottom()), QPointF(rr.left(), rr.bottom() - rr.height() * 0.4))
            lg.setColorAt(0.0, col(mmid.name(), 54))
            lg.setColorAt(1.0, col(mmid.name(), 0))
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(lg)
            p.drawRect(rr)
            p.restore()
            p.setBrush(Qt.BrushStyle.NoBrush)
            for w, a in ((7, 26), (4, 44)):                                    # Schein der äußeren Linie
                p.setPen(QPen(col(mmid.name(), a), w))
                p.drawEllipse(rr.adjusted(1.5, 1.5, -1.5, -1.5))
            p.setPen(QPen(col(mlite.name(), 235), 1.5))
            p.drawEllipse(rr.adjusted(1, 1, -1, -1))
            seg = rr.adjusted(7, 7, -7, -7)                                   # zwölf Segmente, jedes 22 Grad mit 8 Grad Lücke
            pen = QPen(col(mmid.name(), 225), 2.4)
            pen.setCapStyle(Qt.PenCapStyle.FlatCap)
            p.setPen(pen)
            for q in range(12):
                p.drawArc(seg, int((q * 30 + 4) * 16), int(22 * 16))
            p.setPen(QPen(col(mlite.name(), 150), 1.2))                       # Teilstriche außen an Ost, Süd, West, Nord
            cxy = rr.center()
            a, b = rr.width() / 2, rr.height() / 2
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                p.drawLine(QPointF(cxy.x() + dx * (a - 13) * (1 if dy == 0 else 0), cxy.y() + dy * (b - 13) * (1 if dx == 0 else 0)),
                           QPointF(cxy.x() + dx * (a - 3) * (1 if dy == 0 else 0), cxy.y() + dy * (b - 3) * (1 if dx == 0 else 0)))
            if selected:
                p.setPen(QPen(mixc(mmid, "#ffffff", 0.6), 2.6))
                p.drawEllipse(rr.adjusted(-3, -3, 3, 3))

        def _body_obsidian(self, p: QPainter, rr: QRectF, it: Item, selected: bool, base: QColor, mlite: QColor, mmid: QColor) -> None:
            """Look Obsidian-Glas: tiefschwarzes Glas, schillernder Rand wie ein Ölfilm, heller Streifen oben, Tönung der Sorte unten."""
            p.setPen(Qt.PenStyle.NoPen)
            for k, a in ((16, 20), (9, 32), (4, 46)):
                p.setBrush(col("#000000", a))
                p.drawEllipse(rr.translated(0, 11).adjusted(-k + 6, -k / 2 + 3, k - 6, k / 2 - 3))
            if selected:
                self._aura(p, rr, mmid, True)
            g = QLinearGradient(rr.topLeft(), rr.bottomRight())
            g.setColorAt(0.0, col("#1d2026", 244))
            g.setColorAt(0.45, col("#0b0c10", 248))
            g.setColorAt(1.0, mixc("#030304", mmid, 0.10, 250))
            p.setBrush(g)
            p.drawEllipse(rr)
            rg = QRadialGradient(QPointF(rr.center().x() + rr.width() * 0.18, rr.bottom() - rr.height() * 0.04), rr.width() * 0.5)
            rg.setColorAt(0.0, col(mmid.name(), 74))
            rg.setColorAt(1.0, col(mmid.name(), 0))
            p.setBrush(rg)
            p.drawEllipse(rr.adjusted(2, rr.height() * 0.4, -2, -1))
            sp = QConicalGradient(rr.center(), 300)                            # matter Ölfilm über dem Glas
            for pos, c, al in ((0.0, "#35d0ff", 22), (0.25, "#b37bff", 18), (0.5, "#ff5fd2", 22), (0.75, "#ffb347", 18), (1.0, "#35d0ff", 22)):
                sp.setColorAt(pos, col(c, al))
            p.setBrush(sp)
            p.drawEllipse(rr.adjusted(3, 3, -3, -3))
            hl = QLinearGradient(rr.topLeft(), QPointF(rr.left(), rr.center().y()))   # heller Streifen oben mit scharfer Kante
            hl.setColorAt(0.0, col("#ffffff", 78))
            hl.setColorAt(0.6, col("#ffffff", 12))
            hl.setColorAt(0.85, col("#ffffff", 0))
            p.setBrush(hl)
            p.drawEllipse(QRectF(rr.left() + rr.width() * 0.07, rr.top() + rr.height() * 0.05, rr.width() * 0.86, rr.height() * 0.42))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.setPen(QPen(QBrush(self._spectrum(rr.center(), 320, 255)), 2.6))  # schillernder Rand
            p.drawEllipse(rr.adjusted(1.3, 1.3, -1.3, -1.3))
            p.setPen(QPen(col("#ffffff", 60), 1))
            p.drawEllipse(rr.adjusted(3.6, 3.6, -3.6, -3.6))
            if selected:
                p.setPen(QPen(mixc(mmid, "#ffffff", 0.55), 2.6))
                p.drawEllipse(rr.adjusted(-3, -3, 3, 3))

        def _body_metall(self, p: QPainter, rr: QRectF, it: Item, selected: bool, base: QColor, mlite: QColor, mmid: QColor) -> None:
            """Look Metall: Anthrazit mit Stahlverlauf und Chromrand."""
            p.setPen(Qt.PenStyle.NoPen)
            # weicher Schatten unter der Blase (Tiefe)
            for k, a in ((16, 16), (10, 24), (5, 34)):
                p.setBrush(col("#000000", a))
                p.drawEllipse(rr.translated(0, 11).adjusted(-k + 6, -k / 2 + 3, k - 6, k / 2 - 3))
            if selected:                                            # Schein im Metallton der Sorte
                for k, a in ((26, 24), (18, 34), (10, 48)):
                    p.setBrush(col(mlite.name(), a))
                    p.drawEllipse(rr.adjusted(-k, -k * 0.7, k, k * 0.7))
            # Dicke: fast schwarze Schichten hinter der Fläche, leicht nach unten rechts versetzt (Kante des Metallkörpers)
            for k in (3, 2, 1):
                p.setBrush(col(mixc("#07090b", mmid, 0.12 * (4 - k)).name(), 240))
                p.drawEllipse(rr.translated(1.6 * k, 2.4 * k))
            # Körper: Anthrazit, schräger Verlauf von hellem Stahl über den Grundton nach Schwarz, halbdurchsichtig
            g = QLinearGradient(rr.topLeft(), rr.bottomRight())
            g.setColorAt(0.0, mixc(base, "#aab5c1", 0.58, BUBBLE_ALPHA))
            g.setColorAt(0.22, mixc(base, "#78838f", 0.46, 232))
            g.setColorAt(0.50, mixc(base, "#394048", 0.38, 238))
            g.setColorAt(0.78, mixc(base, "#1b1e22", 0.40, 242))
            g.setColorAt(1.0, mixc(base, "#000000", 0.62, 246))
            p.setBrush(g)
            p.drawEllipse(rr)
            # gebürstetes Metall: schmales, schräges Lichtband wie von einer Leuchtstoffröhre
            band = QLinearGradient(rr.topLeft(), rr.bottomRight())
            for pos, al in ((0.10, 0), (0.17, 26), (0.22, 44), (0.27, 20), (0.34, 0), (0.58, 0), (0.64, 12), (0.69, 0)):
                band.setColorAt(pos, col("#ffffff", al))
            p.setBrush(band)
            p.drawEllipse(rr.adjusted(2, 2, -2, -2))
            # Widerschein von unten im Metallton (Körper wirkt gewölbt)
            rg = QRadialGradient(QPointF(rr.center().x(), rr.bottom() - rr.height() * 0.06), rr.width() * 0.46)
            rg.setColorAt(0.0, col(mmid.name(), 120))
            rg.setColorAt(1.0, col(mmid.name(), 0))
            p.setBrush(rg)
            p.drawEllipse(rr.adjusted(2, rr.height() * 0.45, -2, -1))
            # Glanzlicht oben (Glaskuppel mit scharfer Unterkante)
            gl = QLinearGradient(rr.topLeft(), QPointF(rr.left(), rr.center().y()))
            gl.setColorAt(0.0, col("#ffffff", 92))
            gl.setColorAt(0.55, col("#ffffff", 16))
            gl.setColorAt(0.80, col("#ffffff", 0))
            p.setBrush(gl)
            p.drawEllipse(QRectF(rr.left() + rr.width() * 0.09, rr.top() + rr.height() * 0.05, rr.width() * 0.82, rr.height() * 0.44))
            # Metallrand: Chrom im Ton der Sorte, innen eine feine Fasenlinie (hell oben, dunkel unten)
            p.setPen(QPen(QBrush(chrome(rr.center(), mlite, QColor("#171a1d"), mixc(mmid, "#ffffff", 0.18))), 2.8))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawEllipse(rr.adjusted(1.4, 1.4, -1.4, -1.4))
            rl = QPainterPath()                                                   # Randlicht unten: Metallkante fängt Licht von unten
            rl.arcMoveTo(rr.adjusted(5.5, 5.5, -5.5, -5.5), 200)
            rl.arcTo(rr.adjusted(5.5, 5.5, -5.5, -5.5), 200, 140)
            p.setPen(QPen(col(mlite.name(), 120), 1.5))
            p.drawPath(rl)
            bev = QLinearGradient(rr.topLeft(), rr.bottomLeft())
            bev.setColorAt(0.0, col("#ffffff", 120))
            bev.setColorAt(0.5, col("#ffffff", 10))
            bev.setColorAt(1.0, col("#000000", 150))
            p.setPen(QPen(QBrush(bev), 1.1))
            p.drawEllipse(rr.adjusted(3.6, 3.6, -3.6, -3.6))
            if selected:
                p.setPen(QPen(col(RING), 3))
                p.drawEllipse(rr.adjusted(-3, -3, 3, 3))

        def _body_cached(self, p: QPainter, rr: QRectF, it: Item, selected: bool, base: QColor, mlite: QColor, mmid: QColor, still: bool) -> None:
            """Zeichnet den Körper einer Blase aus einem Zwischenbild. Die vielen weichen Farbschichten kosten sonst bei jedem
            Neuzeichnen (jede Taste, jede Mausbewegung, jedes Bild der Einblendung) drei bis vier Millisekunden je Blase."""
            m = 46.0                                                 # Rand für Leuchthof und Schatten
            dev = float(self.devicePixelRatioF())
            zoom = 1.08 if selected else 1.0                         # die ausgewählte Blase ist 8 Prozent größer: dafür scharf vorhalten
            w, h = (rr.width() + 2 * m) * zoom, (rr.height() + 2 * m) * zoom
            # Lage auf dem Bildschirm in ganzen Gerätepixeln; der Bruchteil wird ins Zwischenbild eingerechnet, damit nichts verrutscht
            tl = p.worldTransform().map(QPointF(rr.x() - m, rr.y() - m)) if still else QPointF(0, 0)
            ox, oy = math.floor(tl.x() * dev) / dev, math.floor(tl.y() * dev) / dev
            fx, fy = round(tl.x() - ox, 3), round(tl.y() - oy, 3)
            key = (STYLE, it.kind, it.title, selected, round(rr.width(), 1), round(rr.height(), 1), dev, fx, fy, self.accent, self.panel)
            pm = self._bodies.get(key)
            if pm is None:
                if len(self._bodies) > 96:
                    self._bodies.clear()
                pm = QPixmap(int(math.ceil((w + 1) * dev)), int(math.ceil((h + 1) * dev)))
                pm.setDevicePixelRatio(dev)
                pm.fill(Qt.GlobalColor.transparent)
                q = QPainter(pm)
                q.setRenderHints(p.renderHints())
                q.translate(fx + w / 2, fy + h / 2)
                q.scale(zoom, zoom)
                q.setPen(Qt.PenStyle.NoPen)
                getattr(self, "_body_" + STYLE)(q, rr, it, selected, base, mlite, mmid)
                q.end()
                self._bodies[key] = pm
            if still:                                                # Ruhezustand: Pixel für Pixel, ohne Umrechnung
                p.save()
                p.resetTransform()
                p.drawPixmap(QPointF(ox, oy), pm)
                p.restore()
            else:                                                    # während der Einblendung wird das Bild verkleinert gezeichnet
                p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
                p.drawPixmap(QRectF(rr.x() - m, rr.y() - m, w / zoom, h / zoom), pm, QRectF(0, 0, w * dev, h * dev))
            p.setPen(Qt.PenStyle.NoPen)

        def _bubble(self, p: QPainter, n: int, it: Item, selected: bool) -> None:
            r = self.rects[n]
            if r.x() < 0:
                return
            delay = min(0.5, n * 0.03)
            t = max(0.0, min(1.0, (self.pop - delay) / (1 - delay)))
            sc = (0.6 + 0.4 * (1 - (1 - t) ** 3)) * (1.08 if selected else 1.0)
            base = QColor(FILL[it.kind])
            mlite, mmid = self._tone(it.kind)
            self._cur_kind = it.kind
            p.save()
            p.translate(r.center())
            p.scale(sc, sc)
            rr = QRectF(-r.width() / 2, -r.height() / 2, r.width(), r.height())
            p.setPen(Qt.PenStyle.NoPen)
            self._body_cached(p, rr, it, selected, base, mlite, mmid, t >= 1.0)
            rad = 26 if n < 4 else 21
            floating = it.kind in ("folder", "file", "text")
            side = ((64 if n < 4 else 52) if it.kind == "folder" else (58 if n < 4 else 48)) if floating else rad * 2 - 8
            pm = self._mark(it, side, STYLE == "metall")
            # Beschriftung: Titel in der Serifenschrift der App, darunter die Sorte als kleines Schild
            f = serif(15 if n < 4 else 13)
            fm = QFontMetrics(f)
            inner = int(rr.width() * (0.6 if pm else 0.72))
            dx = 7 if pm else 0                                      # Text rückt von der Marke ab
            lines = wrap(it.title, fm, inner, 3 if r.height() > 80 else 2)
            f2 = QFont(self.font())
            f2.setPixelSize(10)
            f2.setBold(True)
            f2.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 1.4)
            fm2 = QFontMetrics(f2)
            lab = (KIND_LABEL[it.kind] + ("  ★" if it.extra.get("fav") else "")).upper()
            lw = fm2.horizontalAdvance(lab) + 16
            lh = fm.lineSpacing()
            total = lh * len(lines) + 4 + 16
            y = -total / 2
            p.setFont(f)
            p.setPen(col(FG))
            for ln in lines:
                p.drawText(QRectF(-inner / 2 + dx, y, inner, lh), Qt.AlignmentFlag.AlignCenter, ln)
                y += lh
            pill = QRectF(-lw / 2 + dx, y + 4, lw, 16)
            pg = QLinearGradient(pill.topLeft(), pill.bottomLeft())
            pg.setColorAt(0.0, col("#1b1f24", 232))
            pg.setColorAt(1.0, col("#050607", 232))
            p.setPen(QPen(mixc(mmid, "#000000", 0.25, 210), 1))
            p.setBrush(pg)
            p.drawRoundedRect(pill, 8, 8)
            p.setFont(f2)
            p.setPen(mixc(mlite, "#ffffff", 0.35))
            p.drawText(pill, Qt.AlignmentFlag.AlignCenter, lab)
            if pm:
                if floating:
                    self._folder_mark(p, rr, pm, side)
                else:
                    self._badge(p, rr, pm, rad, selected)
            p.restore()

        def _fbase(self, it: Item) -> str:
            """Ordnerfarbe wie in Seifferts Dateien: Favoriten tragen ihre eigene Farbe (wie im Karussell), sonst gilt die Einstellung Ordnerfarbe."""
            c = str(it.extra.get("color") or "")
            if it.extra.get("fav") and len(c) == 7 and c[0] == "#" and all(h in "0123456789abcdefABCDEF" for h in c[1:]):
                return c.lower()
            return FI.base_color(it.title, self.fcolor, self.accent_dark)

        def _mark(self, it: Item, side: int, on_light: bool):
            """Symbol zu einem Treffer: Programm -> sein Symbol, Ordner -> Ordnersymbol im gewählten Stil, Datei -> Symbol des zugeordneten
            Programms, sonst ein allgemeines Dateisymbol. None bei Option aus und für Systembefehle."""
            if not self.show_icons:
                return None
            if it.kind == "folder":
                return ICONS.folder(self.fstyle, self._fbase(it), side)
            if it.kind == "app":
                return ICONS.pixmap(it.extra.get("icon") or "", side)
            if it.kind in ("file", "text"):
                ext = (it.extra.get("ext") or os.path.splitext(it.key)[1]).lower().lstrip(".")
                if not ext:
                    return ICONS.fileglyph(side, "#2b3a47" if on_light else "#c9d4df")
                return ICONS.extfile(ext, B.FILE_TYPES.get(ext, ("other", ""))[0], it.extra.get("appicon") or "", side)
            if it.kind == "system":
                return ICONS.system(it.key, side)
            return None

        def _folder_mark(self, p: QPainter, rr: QRectF, pm, side: int) -> None:
            """Ordnersymbol schwebt links oben vor der Blase, mit weichem Schatten (ohne Plakette, der Ordner ist selbst die Marke)."""
            a, b = rr.width() / 2, rr.height() / 2
            c = QPointF(-a * 0.80, -b * 0.56)
            p.setPen(Qt.PenStyle.NoPen)
            for k, al in ((14, 18), (8, 30), (3, 46)):
                p.setBrush(col("#000000", al))
                p.drawEllipse(QRectF(c.x() - side * 0.36 - k / 2, c.y() + side * 0.30 - k / 4, side * 0.72 + k, side * 0.16 + k / 2))
            p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
            p.drawPixmap(QRectF(c.x() - side / 2, c.y() - side / 2, side, side), pm, QRectF(pm.rect()))

        def _badge(self, p: QPainter, rr: QRectF, pm, rad: int, selected: bool) -> None:
            """Runde Glasplakette mit dem Symbol am oberen linken Rand der Blase, halb auf dem Rand (schwebt vor der Blase)."""
            a, b = rr.width() / 2, rr.height() / 2
            c = QPointF(-a * 0.80, -b * 0.60)
            disc = QRectF(c.x() - rad, c.y() - rad, rad * 2, rad * 2)
            p.setPen(Qt.PenStyle.NoPen)
            for k, al in ((5, 26), (3, 40)):
                p.setBrush(col("#000000", al))
                p.drawEllipse(disc.translated(1, 3).adjusted(-k / 2, -k / 2, k / 2, k / 2))
            if STYLE != "metall":
                mm = self._tone(self._cur_kind)[1]
                p.setBrush(col(mm.name(), 46))
                p.drawEllipse(disc.adjusted(-4, -4, 4, 4))
                dg = QRadialGradient(QPointF(c.x() - rad * 0.3, c.y() - rad * 0.4), rad * 1.5)
                dg.setColorAt(0.0, col("#2a2f3a", 250))
                dg.setColorAt(1.0, col("#07080b", 252))
                p.setBrush(dg)
                p.drawEllipse(disc)
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.setPen(QPen(col(RING if selected else mm.name(), 255 if selected else 235), 2.0))
                p.drawEllipse(disc.adjusted(1, 1, -1, -1))
                p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
                sd = rad * 2 - 8
                p.drawPixmap(QRectF(c.x() - sd / 2, c.y() - sd / 2, sd, sd), pm, QRectF(pm.rect()))
                return
            g = QRadialGradient(QPointF(c.x() - rad * 0.3, c.y() - rad * 0.4), rad * 1.5)
            g.setColorAt(0.0, col("#ffffff", 250))
            g.setColorAt(0.65, col("#e3e9ef", 246))
            g.setColorAt(1.0, col("#a9b4c0", 246))
            p.setBrush(g)
            p.drawEllipse(disc)
            p.setBrush(Qt.BrushStyle.NoBrush)
            if selected:
                p.setPen(QPen(col(RING), 2.2))
            else:
                p.setPen(QPen(QBrush(chrome(disc.center(), QColor("#f4f7fa"), QColor("#4d555e"), QColor("#9aa4af"))), 2.4))
            p.drawEllipse(disc.adjusted(1, 1, -1, -1))
            p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
            side = rad * 2 - 8
            p.drawPixmap(QRectF(c.x() - side / 2, c.y() - side / 2, side, side), pm, QRectF(pm.rect()))

        def _detail(self, p: QPainter) -> None:
            f = serif(16)
            p.setFont(f)
            r = DETAIL.adjusted(18, 8, -18, -8)
            if self.armed and not (self.items and self.items[self.sel].key == self.armed[0]):
                self.armed = None
                self.msg = ""
            if self.msg:
                p.setPen(col("#ffb4a8"))
                p.drawText(r, int(Qt.AlignmentFlag.AlignVCenter) | int(Qt.TextFlag.TextWordWrap), self.msg)
                return
            if not self.items:
                p.setPen(col(FG2))
                f = QFont(self.font())
                f.setPixelSize(15)
                p.setFont(f)
                p.drawText(r, Qt.AlignmentFlag.AlignVCenter, "Pfeiltasten wählen, Enter öffnet, Tab wechselt die Sorte, Esc schließt.")
                return
            it = self.items[self.sel]
            # Farbstreifen der Sorte links, wie die Farbe der Favoriten am Karussell
            p.setPen(Qt.PenStyle.NoPen)
            sg = QLinearGradient(QPointF(DETAIL.left(), DETAIL.top() + 10), QPointF(DETAIL.left(), DETAIL.bottom() - 10))
            tl, tm = self._tone(it.kind)
            sg.setColorAt(0.0, tl)
            sg.setColorAt(0.5, tm)
            sg.setColorAt(1.0, mixc(tm, "#000000", 0.55))
            p.setBrush(sg)
            p.drawRoundedRect(QRectF(DETAIL.left() + 7, DETAIL.top() + 10, 4, DETAIL.height() - 20), 2, 2)
            r = r.adjusted(6, 0, 0, 0)
            dside = 44 if it.kind in ("folder", "file", "text") else 40
            big = self._mark(it, dside, False)
            if big:                                                 # Symbol des Treffers (Programm, Ordner, Programm zur Datei) vor dem Namen
                p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
                p.drawPixmap(QRectF(r.x(), DETAIL.top() + (DETAIL.height() - dside) / 2, dside, dside), big, QRectF(big.rect()))
                r = r.adjusted(dside + 10, 0, 0, 0)
            fm = QFontMetrics(f)
            p.setPen(col(FG))
            p.drawText(QRectF(r.x(), r.y(), r.width(), 22), Qt.AlignmentFlag.AlignVCenter, fm.elidedText(it.title, Qt.TextElideMode.ElideRight, r.width()))
            f = QFont(self.font())
            f.setPixelSize(13)
            p.setFont(f)
            fm = QFontMetrics(f)
            p.setPen(col(FG2))
            hint = {"system": "Enter führt den Befehl aus (vorher wird nachgefragt)", "app": "Enter startet das Programm", "folder": "Enter öffnet den Ordner in Seifferts Dateien",
                    "file": "Enter öffnet die Datei, Strg+Enter zeigt ihren Ordner", "text": "Enter öffnet die Datei, Strg+Enter zeigt ihren Ordner"}[it.kind]
            home = os.path.expanduser("~")
            sub = ("~" + it.sub[len(home):]) if it.sub == home or it.sub.startswith(home + "/") else it.sub
            second = (it.snippet.strip().replace("\n", " ") if it.snippet else (sub or "")) or hint
            p.drawText(QRectF(r.x(), r.y() + 22, r.width(), 20), Qt.AlignmentFlag.AlignVCenter, fm.elidedText(second, Qt.TextElideMode.ElideMiddle, r.width()))

    return Cloud, QApplication


# ---------------------------------------------------------------------------------------------- Hauptprogramm
def main(argv: list[str]) -> int:
    cmd = "toggle"
    daemon = False
    for a in argv[1:]:
        if a == "--daemon":
            daemon = True
        elif a in ("--show", "--hide", "--quit", "--toggle"):
            cmd = a[2:]
    import sessionenv
    if daemon:                                           # Autostart: Fehler in eine Datei schreiben und auf die Sitzung warten
        sessionenv.log_to_file("starter.log")
        sessionenv.adopt_session(wait=60)
    else:
        if not sys.stderr or not sys.stderr.isatty():     # Start aus dem Menü oder per Tastenkürzel: Fehler sonst unsichtbar
            sessionenv.log_to_file("starter.log")
        sessionenv.adopt_session()
    Cloud, QApplication = build_ui()
    from PySide6.QtNetwork import QLocalServer, QLocalSocket
    app = QApplication([argv[0]])
    app.setApplicationName(NAME)
    app.setDesktopFileName("seiffert-starter")
    app.setQuitOnLastWindowClosed(False)
    sock = QLocalSocket()
    sock.connectToServer(SOCKET)
    if sock.waitForConnected(300):                       # läuft schon: Befehl weitergeben
        if daemon:
            return 0                                         # Autostart bei bereits laufendem Dienst: nichts tun
        sock.write(cmd.encode())
        sock.flush()
        sock.waitForBytesWritten(500)
        return 0
    if cmd == "quit":
        return 0
    QLocalServer.removeServer(SOCKET)
    server = QLocalServer()
    server.listen(SOCKET)
    backend = B.Backend()
    win = Cloud(Finder(backend), backend)

    def on_conn() -> None:
        c = server.nextPendingConnection()
        if not c:
            return

        def read() -> None:
            m = bytes(c.readAll()).decode("utf-8", "replace").strip()
            if m == "quit":
                app.quit()
            elif m == "hide":
                win.hide()
            elif m == "show":
                win.summon()
            else:
                win.toggle()
            c.disconnectFromServer()
        c.readyRead.connect(read)
    server.newConnection.connect(on_conn)
    if not daemon:
        win.summon()
    code = app.exec()
    server.close()
    backend.shutdown() if hasattr(backend, "shutdown") else None
    return code


if __name__ == "__main__":
    sys.exit(main(sys.argv))
