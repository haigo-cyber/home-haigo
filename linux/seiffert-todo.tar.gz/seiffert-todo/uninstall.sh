#!/usr/bin/env bash
# Entfernt das Programm. Daten (Kopien, Einstellungen) bleiben, außer du löschst die Ordner von Hand.
DATA="${XDG_DATA_HOME:-$HOME/.local/share}/seiffert-todo"
chmod -R u+w "$DATA/app" "$DATA/venv" 2>/dev/null
rm -rf "$DATA/app" "$DATA/venv"
rm -f "$HOME/.local/bin/seiffert-todo" "${XDG_DATA_HOME:-$HOME/.local/share}/applications/seiffert-todo.desktop"
for n in 16 22 24 32 48 64 128 256; do rm -f "${XDG_DATA_HOME:-$HOME/.local/share}/icons/hicolor/${n}x${n}/apps/seiffert-todo.png"; done
echo "Programm entfernt. Übrig sind: $DATA (Protokoll, lokale Kopien, gespeicherte Seiteneinstellungen) und ~/.config/seiffert-todo."
echo "Zum vollständigen Löschen: rm -rf \"$DATA\" ~/.config/seiffert-todo"
