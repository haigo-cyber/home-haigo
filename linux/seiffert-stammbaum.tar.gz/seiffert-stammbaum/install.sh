#!/bin/sh
# Installiert Seifferts Stammbaum fuer den aktuellen Benutzer (ohne sudo).
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
DATA=${XDG_DATA_HOME:-$HOME/.local/share}
APP="$DATA/seiffert-stammbaum-app"
BIN="$HOME/.local/bin"
DESK="$DATA/applications"
ICONS="$DATA/icons/hicolor"

if [ "$1" = "--remove" ]; then
  rm -rf "$APP" "$BIN/seiffert-stammbaum" "$DESK/seiffert-stammbaum.desktop" "$DATA/icons/hicolor/scalable/apps/seiffert-stammbaum.svg"
  for n in 16 22 24 32 48 64 96 128 180 256; do rm -f "$ICONS/${n}x${n}/apps/seiffert-stammbaum.png"; done
  command -v gtk-update-icon-cache >/dev/null 2>&1 && gtk-update-icon-cache -q -t "$ICONS" 2>/dev/null || true
  command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$DESK" 2>/dev/null || true
  echo "Entfernt. Einstellungen und Daten bleiben erhalten:"
  echo "  ${XDG_CONFIG_HOME:-$HOME/.config}/seiffert-stammbaum  (Einstellungen, Google-Zugang)"
  echo "  $DATA/seiffert-stammbaum  (gespeicherte Datei- und Ordnerverbindungen, Vorversionen)"
  exit 0
fi

PY=python3
if ! $PY -c "from PySide6 import QtWebEngineWidgets, QtWebChannel" 2>/dev/null; then
  echo "Hinweis: PySide6 mit QtWebEngine wurde nicht gefunden." >&2
  echo "  Arch:  sudo pacman -S pyside6 qt6-webengine" >&2
  echo "  oder:  python3 -m venv --system-site-packages $APP/venv && $APP/venv/bin/pip install PySide6 PySide6-WebEngine" >&2
  echo "Die Dateien werden trotzdem installiert." >&2
fi

mkdir -p "$APP" "$BIN" "$DESK"
rm -rf "$APP/vendor"
rm -f "$APP/app.py" "$APP/shim.js" "$APP/stammbaum.html" "$APP/seiffert-stammbaum.svg" "$APP/icon.png"
cp "$HERE/app.py" "$HERE/shim.js" "$HERE/stammbaum.html" "$APP/"
cp "$HERE/icons/seiffert-stammbaum-256.png" "$APP/icon.png"
cp -r "$HERE/vendor" "$APP/vendor"
chmod -R u+w "$APP"
rm -f "$ICONS/scalable/apps/seiffert-stammbaum.svg"
for n in 16 22 24 32 48 64 96 128 180 256; do
  mkdir -p "$ICONS/${n}x${n}/apps"
  cp "$HERE/icons/seiffert-stammbaum-$n.png" "$ICONS/${n}x${n}/apps/seiffert-stammbaum.png"
done
command -v gtk-update-icon-cache >/dev/null 2>&1 && gtk-update-icon-cache -q -t "$ICONS" 2>/dev/null || true
cat > "$BIN/seiffert-stammbaum" <<LAUNCH
#!/bin/sh
PY=python3
[ -x "$APP/venv/bin/python" ] && PY="$APP/venv/bin/python"
exec "\$PY" "$APP/app.py" "\$@"
LAUNCH
chmod +x "$BIN/seiffert-stammbaum"
cat > "$DESK/seiffert-stammbaum.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=Seifferts Stammbaum
GenericName=Stammbaum
Comment=Stammbaum mit GEDCOM-Datei, Medienordner und Google-Drive-Sicherung
Exec="$BIN/seiffert-stammbaum"
Icon=seiffert-stammbaum
Terminal=false
StartupNotify=true
Categories=Office;Education;
StartupWMClass=seiffert-stammbaum
DESKTOP
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$DESK" 2>/dev/null || true
echo "Fertig. Start über das Menü (Seifferts Stammbaum) oder mit:  $BIN/seiffert-stammbaum"
case ":$PATH:" in *":$BIN:"*) ;; *) echo "Hinweis: $BIN steht nicht in PATH. Das Menü funktioniert trotzdem." ;; esac
