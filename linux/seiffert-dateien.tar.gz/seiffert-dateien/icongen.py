"""Symbole erzeugen und finden (nur Standardbibliothek, ohne Oberfläche testbar).

1. Programm-Symbole im Symbolthema des Desktops finden (Datei, nicht nur Name), auch für die Dateimanager-Oberfläche als data:-Adresse.
2. Ein eigenes Symbol je Dateiendung: Blatt mit Endung, Farbe nach Dateiart und Platz für das Symbol des zugeordneten Programms.
3. Systembefehl-Symbole im Strichstil von Seifferts Dateien (Herunterfahren, Neu starten, Abmelden, Sperren, Ruhezustand).
"""
from __future__ import annotations

import base64
import glob
import os
import re
import subprocess
import time

import foldericons as FI

# ---------------------------------------------------------------------------------------------- Programm-Symbole finden
_theme = {"name": "", "at": 0.0}
SIZE_RE = re.compile(r"(\d+)(?:x\d+)?")


def current_theme() -> str:
    """Name des Symbolthemas aus den Cinnamon-Einstellungen (höchstens alle 30 Sekunden neu gelesen); leer, wenn nicht ermittelbar."""
    if time.time() - _theme["at"] < 30:
        return _theme["name"]
    _theme["at"] = time.time()
    name = ""
    try:
        r = subprocess.run(["gsettings", "get", "org.cinnamon.desktop.interface", "icon-theme"], capture_output=True, text=True, timeout=1.5)
        if r.returncode == 0:
            name = r.stdout.strip().strip("'\"")
    except (OSError, subprocess.SubprocessError, ValueError):
        pass
    _theme["name"] = name
    return name


def data_dirs() -> list[str]:
    home = os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share")
    rest = [d for d in (os.environ.get("XDG_DATA_DIRS") or "/usr/local/share:/usr/share").split(":") if d]
    return [home] + rest


def _inherits(theme: str, dirs: list[str], seen: set | None = None) -> list[str]:
    seen = seen if seen is not None else set()
    if theme in seen:
        return []
    seen.add(theme)
    out = [theme]
    for d in dirs:
        try:
            for line in open(os.path.join(d, "icons", theme, "index.theme"), encoding="utf-8", errors="replace"):
                if line.startswith("Inherits="):
                    for t in line.split("=", 1)[1].strip().split(","):
                        t = t.strip()
                        if t:
                            out += [x for x in _inherits(t, dirs, seen) if x not in out]
                    return out
        except OSError:
            continue
    return out


def _size_of(path: str) -> int:
    for part in reversed(path.split(os.sep)[:-1]):
        m = SIZE_RE.fullmatch(part)
        if m:
            return int(m.group(1))
    return 0


def _best(hits: list[str]) -> str:
    """Vektorbild zuerst, sonst das Pixelbild mit der Größe, die 64 Pixel am nächsten kommt (lieber größer als kleiner)."""
    hits = [h for h in hits if "symbolic" not in h]
    svg = [h for h in hits if h.lower().endswith((".svg", ".svgz"))]
    if svg:
        return sorted(svg)[0]
    png = [h for h in hits if h.lower().endswith(".png")]
    if png:
        return sorted(png, key=lambda h: (abs(_size_of(h) - 64) + (0 if _size_of(h) >= 64 else 40), h))[0]
    return ""


_found: dict[tuple, str] = {}


def find_icon_file(name: str, theme: str = "") -> str:
    """Pfad der Symboldatei zu einem Namen aus der .desktop-Datei (Icon=...): absoluter Pfad, Thema samt Erbe, hicolor, übrige Themen, pixmaps."""
    if not name:
        return ""
    if os.path.isabs(name):
        return name if os.path.isfile(name) else ""
    theme = theme or current_theme()
    key = (name, theme, tuple(data_dirs()))
    if key in _found:
        return _found[key]
    stem = name.rsplit(".", 1)[0] if name.lower().endswith((".png", ".svg", ".xpm", ".svgz")) else name
    dirs = data_dirs()
    themes = _inherits(theme, dirs) if theme else []
    for t in ("hicolor",):
        if t not in themes:
            themes.append(t)
    for d in dirs:                                           # alle weiteren Themen zuletzt
        try:
            for t in sorted(os.listdir(os.path.join(d, "icons"))):
                if t not in themes and os.path.isdir(os.path.join(d, "icons", t)):
                    themes.append(t)
        except OSError:
            pass
    home_icons = os.path.expanduser("~/.icons")
    res = ""
    esc = glob.escape(stem)
    for t in themes:
        hits: list[str] = []
        for base in [os.path.join(d, "icons") for d in dirs] + [home_icons]:
            tb = glob.escape(os.path.join(base, t))
            for pat in ("*/apps/", "*/*/apps/", "apps/*/", "apps/"):
                for e in (".svg", ".svgz", ".png"):
                    hits += glob.glob(os.path.join(tb, pat, esc + e))
        res = _best(hits)
        if res:
            break
    if not res:
        for d in dirs + ["/usr"]:
            for e in (".svg", ".png", ".xpm"):
                p = os.path.join(d, "pixmaps", stem + e)
                if os.path.isfile(p):
                    res = p
                    break
            if res:
                break
    _found[key] = res
    return res


def data_uri(path: str, max_bytes: int = 300_000) -> str:
    """Datei als data:-Adresse für die Oberfläche; leer bei zu großen oder nicht darstellbaren Dateien (xpm, svgz)."""
    ext = os.path.splitext(path)[1].lower()
    mime = {".svg": "image/svg+xml", ".png": "image/png"}.get(ext)
    if not mime:
        return ""
    try:
        if os.path.getsize(path) > max_bytes:
            return ""
        with open(path, "rb") as f:
            return "data:%s;base64,%s" % (mime, base64.b64encode(f.read()).decode("ascii"))
    except OSError:
        return ""


# ---------------------------------------------------------------------------------------------- Symbol je Dateiendung
GROUP_COLORS = {"pdf": "#c0392b", "doc": "#2f6fb5", "sheet": "#2e8b57", "slides": "#d9822b", "tex": "#1f8a8a", "code": "#6b5bd6",
                "text": "#6b7a89", "image": "#a56bc4", "audio": "#c8566b", "video": "#b5443a", "archive": "#9a6b3f"}
PROG_BOX = (19.0, 17.0, 26.0, 26.0)           # wohin das Programmsymbol auf dem Blatt kommt (x, y, Breite, Höhe im 64er-Raster)


def ext_label(ext: str) -> str:
    e = (ext or "").lower().lstrip(".")
    return (e[:5] if e else "?").upper()


def ext_color(ext: str, group: str = "") -> str:
    """Farbe nach Dateiart (aus FILE_TYPES), sonst fest aus der Endung abgeleitet, damit jede Endung immer dieselbe Farbe hat."""
    if group in GROUP_COLORS:
        return GROUP_COLORS[group]
    return FI.PALETTE[FI.js_hash((ext or "").lower().lstrip(".")) % len(FI.PALETTE)]


def ext_markup(ext: str, group: str = "", with_prog: bool = False) -> str:
    """Blatt mit Eselsohr, Endung im farbigen Band unten; ohne Programmsymbol ein paar Textzeilen als Füllung."""
    c = ext_color(ext, group)
    dk, pale = FI.tone(c, -0.35), FI.tone(c, 0.72)
    lab = ext_label(ext)
    fs = 13 if len(lab) <= 3 else 11 if len(lab) == 4 else 9.4
    body = ('<path d="M13 5h27l11 11v43H13z" fill="#f6f8fb" stroke="%s" stroke-width="2.4" stroke-linejoin="round"/>'
            '<path d="M40 5l11 11H40z" fill="%s" stroke="%s" stroke-width="2" stroke-linejoin="round"/>' % (dk, pale, dk))
    if not with_prog:
        body += '<path d="M20 22h24M20 29h24M20 36h15" stroke="#b4bfcb" stroke-width="2.6" stroke-linecap="round" fill="none"/>'
    body += ('<path d="M14.2 44h35.6v14.8H14.2z" fill="%s"/>'
             '<text x="32" y="%s" text-anchor="middle" font-family="DejaVu Sans, Arial, Helvetica, sans-serif" font-weight="700" font-size="%s" fill="#ffffff">%s</text>'
             % (c, "55.1" if fs > 10 else "54.6", fs, lab.replace("&", "&amp;").replace("<", "&lt;")))
    return body


def ext_svg(ext: str, group: str = "", with_prog: bool = False) -> str:
    """Vollständiges svg-Element (für die Oberfläche)."""
    return '<svg class="xsv" viewBox="0 0 64 64" aria-hidden="true">%s</svg>' % ext_markup(ext, group, with_prog)


def ext_svg_doc(ext: str, group: str = "", with_prog: bool = False, px: int = 192) -> bytes:
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="%d" height="%d">%s</svg>' % (px, px, ext_markup(ext, group, with_prog))).encode("utf-8")


# ---------------------------------------------------------------------------------------------- Systembefehle
SYSTEM_GLYPHS = {
    "shutdown": '<path d="M32 9v21"/><path d="M19.5 17.5a21 21 0 1 0 25 0"/>',
    "reboot": '<path d="M51 33a19 19 0 1 1-6.6-14.4"/><path d="M47 8v13H34"/>',
    "logout": '<path d="M27 10H13v44h14"/><path d="M26 32h28"/><path d="M44 21l10 11-10 11"/>',
    "lock": '<rect x="13" y="28" width="38" height="26" rx="5"/><path d="M21 28v-8a11 11 0 0 1 22 0v8"/><path d="M32 37v8"/>',
    "suspend": '<path d="M47 40a19 19 0 1 1-23-28 15 15 0 0 0 23 28z"/><path d="M44 10v10M39 15h10"/>',
}
SYSTEM_STROKE = "#8a2236"


def system_svg_doc(sid: str, stroke: str = SYSTEM_STROKE, px: int = 192) -> bytes:
    g = SYSTEM_GLYPHS.get(sid)
    if not g:
        return b""
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="%d" height="%d" fill="none" stroke="%s" stroke-width="4.2" '
            'stroke-linecap="round" stroke-linejoin="round">%s</svg>' % (px, px, stroke, g)).encode("utf-8")
