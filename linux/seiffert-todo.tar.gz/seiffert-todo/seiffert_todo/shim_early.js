/* Seifferts ToDo (Linux): wird vor der Seite geladen.
   1. localStorage aus der Datei befüllen und Änderungen zurückspiegeln
   2. google.accounts.oauth2 nachbauen (Anmeldung über den Browser, Übergabe an 127.0.0.1)
   3. Aufrufe an Google über Python leiten und den Zustand der Synchronisation mitführen */
(function () {
  "use strict";
  var L = window.__LINUX || {};
  var BASE = L.base || "/";
  var origFetch = window.fetch.bind(window);

  /* ---------- localStorage ---------- */
  try {
    var ls = L.ls || {};
    var keys = Object.keys(ls);
    for (var i = 0; i < keys.length; i++) Storage.prototype.setItem.call(localStorage, keys[i], ls[keys[i]]);
  } catch (e) {}
  var lsPend = { set: {}, del: {}, clear: false }, lsTimer = null;
  function lsFlush() {
    clearTimeout(lsTimer); lsTimer = null;
    var d = { set: lsPend.set, del: Object.keys(lsPend.del), clear: lsPend.clear };
    if (!lsPend.clear && !Object.keys(d.set).length && !d.del.length) return;
    lsPend = { set: {}, del: {}, clear: false };
    try { origFetch(BASE + "api/ls", { method: "POST", body: JSON.stringify(d), keepalive: true }).catch(function () {}); } catch (e) {}
  }
  function lsSched() { if (!lsTimer) lsTimer = setTimeout(lsFlush, 500); }
  var sSet = Storage.prototype.setItem, sDel = Storage.prototype.removeItem, sClr = Storage.prototype.clear;
  Storage.prototype.setItem = function (k, v) {
    sSet.call(this, k, v);
    if (this === window.localStorage) { k = String(k); lsPend.set[k] = String(v); delete lsPend.del[k]; lsSched(); }
  };
  Storage.prototype.removeItem = function (k) {
    sDel.call(this, k);
    if (this === window.localStorage) { k = String(k); delete lsPend.set[k]; lsPend.del[k] = 1; lsSched(); }
  };
  Storage.prototype.clear = function () {
    sClr.call(this);
    if (this === window.localStorage) { lsPend = { set: {}, del: {}, clear: true }; lsSched(); }
  };
  window.addEventListener("pagehide", lsFlush);
  window.__linuxLsFlush = lsFlush;

  /* ---------- Zustand der Synchronisation ---------- */
  var S = window.__linuxSync = {
    inflight: 0, lastOk: 0, lastWriteOk: 0, lastError: "", failedKinds: {}, needResync: false,
    expiresAt: 0, scope: "", loginPending: false, loginMsg: "", listeners: []
  };
  function emit() { S.listeners.forEach(function (f) { try { f(); } catch (e) {} }); }
  S.emit = emit;
  if (L.auth && L.auth.valid) { S.expiresAt = Date.now() + L.auth.expires_in * 1000; S.scope = L.auth.scope || ""; }
  function plog(msg) { try { origFetch(BASE + "api/log", { method: "POST", body: JSON.stringify({ msg: msg }) }).catch(function () {}); } catch (e) {} }
  window.__linuxLog = plog;
  function J(path, body) {
    return origFetch(BASE + path, body === undefined ? {} : { method: "POST", body: JSON.stringify(body) }).then(function (r) { return r.json(); });
  }
  var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };

  /* ---------- google.accounts.oauth2 ---------- */
  var DEFAULT_SCOPE = "";
  function deliver(cfg, r) {
    S.expiresAt = Date.now() + (r.expires_in || 3600) * 1000;
    S.scope = r.scope || S.scope;
    S.loginPending = false; S.loginMsg = ""; emit();
    var resp = { access_token: r.token, expires_in: r.expires_in, scope: r.scope || "", token_type: "Bearer" };
    if (cfg.callback) cfg.callback(resp);
  }
  function failLogin(cfg, msg) {
    S.loginPending = false; S.loginMsg = msg || "Anmeldung abgebrochen"; emit();
    plog("Anmeldung fehlgeschlagen: " + S.loginMsg);
    if (cfg.error_callback) cfg.error_callback({ type: "popup_closed", message: S.loginMsg });
    else if (cfg.callback) cfg.callback({ error: "access_denied", error_description: S.loginMsg });
  }
  /* Der Browser wird nur geöffnet, wenn jemand am Rechner ist: beim Start (einmal), auf ausdrücklichen Wunsch
     oder wenn in den letzten zwei Minuten getippt oder geklickt wurde. Sonst würde eine abgelaufene Anmeldung
     im Hintergrund immer neue Browser-Tabs öffnen. */
  var lastUser = 0, startBudget = 1;
  ["pointerdown", "keydown", "wheel"].forEach(function (n) {
    window.addEventListener(n, function () { lastUser = Date.now(); }, { capture: true, passive: true });
  });
  function mayOpenBrowser() {
    if (Date.now() - lastUser < 120000) return true;
    if (startBudget > 0) { startBudget--; return true; }
    return false;
  }
  async function runLogin(cfg, o, force) {
    var scope = (o && o.scope) || cfg.scope || "";
    if (!DEFAULT_SCOPE) DEFAULT_SCOPE = cfg.scope || "";
    try {
      if (!force && !S.loginPending) {
        var a = await J("api/auth");
        var need = !a.valid || (a.scope && scope.split(/\s+/).some(function (x) { return x && a.scope.split(/\s+/).indexOf(x) < 0; }));
        if (need && !mayOpenBrowser()) {
          S.expiresAt = a.valid ? S.expiresAt : 0;
          plog("Anmeldung nötig, aber niemand am Rechner: kein Browser geöffnet");
          return failLogin(cfg, "Anmeldung abgelaufen");
        }
      }
      var r = await J("api/login/start", { scope: scope, force: !!force });
      if (r.status === "ok") return deliver(cfg, r);
      S.loginPending = true; S.loginMsg = "Bitte im Browser bei Google anmelden …"; emit();
      var state = r.state, t0 = Date.now();
      while (Date.now() - t0 < 310000) {
        await sleep(1500);
        var w = await J("api/login/wait?state=" + encodeURIComponent(state));
        if (w.status === "ok") return deliver(cfg, w);
        if (w.status === "superseded") { state = w.state; continue; }
        if (w.status === "fail") return failLogin(cfg, w.message);
      }
      failLogin(cfg, "Zeit abgelaufen");
    } catch (e) { failLogin(cfg, "Anmeldung nicht möglich: " + (e && e.message || e)); }
  }
  window.google = { accounts: { oauth2: {
    initTokenClient: function (cfg) {
      return { requestAccessToken: function (o) { runLogin(cfg, o || {}, false); } };
    },
    revoke: function (tok, cb) { J("api/logout", {}).catch(function () {}); S.expiresAt = 0; emit(); if (cb) setTimeout(function () { cb({ successful: true }); }, 0); },
    hasGrantedAllScopes: function () { return true; },
    hasGrantedAnyScope: function () { return true; }
  } } };
  window.__linuxForceLogin = function () {
    /* Anmeldung auf Wunsch erneuern: neuen Versuch erzwingen, der Browser öffnet sich neu */
    var cfg = { scope: DEFAULT_SCOPE, callback: function (resp) { if (typeof accessToken !== "undefined") { try { accessToken = resp.access_token; } catch (e) {} } }, error_callback: function () {} };
    return runLogin(cfg, {}, true);
  };

  /* ---------- fetch: Google über Python ---------- */
  var GURL = /^https:\/\/(www|sheets|tasks)\.googleapis\.com\//;
  function kindOf(url) {
    var m = /\/values\/([A-Za-z]+)(?:!|%21)/.exec(url);
    if (m) return m[1];
    if (/\/upload\/drive\/|\/drive\/v3\/files/.test(url)) return "Drive";
    if (/\/calendar\//.test(url)) return "Kalender";
    if (/tasks\.googleapis/.test(url)) return "GTasks";
    return "Sonst";
  }
  window.fetch = async function (input, init) {
    var url = typeof input === "string" ? input : (input && input.url) || String(input);
    if (!GURL.test(url)) return origFetch(input, init);
    var req = (typeof Request !== "undefined" && input instanceof Request) ? input : null;
    init = init || {};
    var method = String(init.method || (req && req.method) || "GET").toUpperCase();
    var h = {};
    var hs = init.headers || (req && req.headers);
    if (hs) {
      if (typeof Headers !== "undefined" && hs instanceof Headers) hs.forEach(function (v, k) { h[k] = v; });
      else if (Array.isArray(hs)) hs.forEach(function (p) { h[p[0]] = p[1]; });
      else Object.keys(hs).forEach(function (k) { h[k] = hs[k]; });
    }
    var body = init.body !== undefined ? init.body : null;
    if (body === null && req && method !== "GET") body = await req.arrayBuffer();
    var payload = null;
    if (body !== null && body !== undefined) {
      if (typeof body === "string" || body instanceof ArrayBuffer) payload = body;
      else {
        var rr = new Response(body);
        var ct = rr.headers.get("content-type");
        var hasCt = Object.keys(h).some(function (k) { return k.toLowerCase() === "content-type"; });
        if (ct && (!hasCt || /boundary/.test(ct))) h["Content-Type"] = ct;
        payload = await rr.arrayBuffer();
      }
    }
    var kind = kindOf(url), write = method !== "GET";
    S.inflight++; emit();
    var res = null, netfail = false;
    try {
      res = await origFetch(BASE + "api/g", {
        method: "POST", signal: init.signal,
        headers: { "X-G-Url": encodeURIComponent(url), "X-G-Method": method, "X-G-Headers": encodeURIComponent(JSON.stringify(h)) },
        body: payload
      });
      if (res.headers.get("X-G-Netfail")) netfail = true;
    } catch (e) {
      S.inflight = Math.max(0, S.inflight - 1); emit();
      if (e && e.name === "AbortError") throw e;
      netfail = true; res = null;
    }
    if (netfail) {
      if (res) S.inflight = Math.max(0, S.inflight - 1);
      S.lastError = "Keine Verbindung zu Google"; S.failedKinds[kind] = 1; S.needResync = true;
      plog("Netzfehler bei " + method + " " + kind); emit();
      throw new TypeError("Failed to fetch");
    }
    S.inflight = Math.max(0, S.inflight - 1);
    var st = res.status;
    if (st < 400) {
      S.lastOk = Date.now(); if (write) S.lastWriteOk = S.lastOk; S.lastError = "";
      if (!Object.keys(S.failedKinds).length) S.needResync = false;
      if (S.needResync && typeof window.__linuxResyncSoon === "function") window.__linuxResyncSoon();
    } else if (st === 401 || st === 429 || st >= 500) {
      if (st === 401) { S.expiresAt = 0; try { await J("api/login/expired", {}); } catch (e) {} }
      S.lastError = st === 401 ? "Anmeldung abgelaufen" : "Google antwortet mit Fehler " + st;
      if (kind !== "Kalender") { S.failedKinds[kind] = 1; S.needResync = true; }
      plog("Fehler " + st + " bei " + method + " " + kind);
    }
    emit();
    var buf = (st === 204 || st === 205 || st === 304) ? null : await res.arrayBuffer();
    return new Response(buf, { status: st, headers: { "Content-Type": res.headers.get("Content-Type") || "application/octet-stream" } });
  };

  /* Dienstarbeiter gibt es hier nicht */
  try { if (navigator.serviceWorker) navigator.serviceWorker.register = function () { return Promise.reject(new Error("aus")); }; } catch (e) {}
})();
