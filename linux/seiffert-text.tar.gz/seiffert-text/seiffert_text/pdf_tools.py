"""PDF: Text als Dokument auslesen und PDF direkt ändern (über PyMuPDF, falls installiert)."""
import os
import re
import shutil
from collections import Counter

try:
    import pymupdf
except Exception:          # PyMuPDF fehlt oder passt nicht zum System
    pymupdf = None

from .readers import para, txt, ReaderError

_FONT_CACHE = None
FAMILY = {"sans": "LiberationSans", "serif": "LiberationSerif", "mono": "LiberationMono"}
FALLBACK = {"sans": "DejaVuSans", "serif": "DejaVuSerif", "mono": "DejaVuSansMono"}
BASE14 = {"sans": ("helv", "hebo", "heit", "hebi"), "serif": ("tiro", "tibo", "tiit", "tibi"),
          "mono": ("cour", "cobo", "coit", "cobi")}


class PdfError(Exception):
    pass


def available():
    return pymupdf is not None


# ---------------------------------------------------------------- PDF -> Dokument
def pdf_to_blocks(path):
    """Text des PDF als Absätze und Überschriften (für die LaTeX- und Markdown-Ansicht)."""
    if pymupdf is None:
        return _blocks_qt(path)
    try:
        doc = pymupdf.open(path)
    except Exception as e:
        raise ReaderError("Das PDF konnte nicht gelesen werden: %s" % e)
    if doc.needs_pass:
        raise ReaderError("Das PDF ist mit einem Kennwort geschützt.")
    pages, sizes = [], Counter()
    for page in doc:
        d = page.get_text("dict", sort=True)
        pages.append(d)
        for b in d.get("blocks", []):
            for ln in b.get("lines", []):
                for sp in ln.get("spans", []):
                    sizes[round(sp["size"])] += len(sp["text"])
    if not sizes:
        raise ReaderError("Das PDF enthält keinen auslesbaren Text (vermutlich nur gescannte Bilder).")
    body = sizes.most_common(1)[0][0]
    blocks = [para([txt(os.path.splitext(os.path.basename(path))[0])], h=1)]
    for d in pages:
        for b in d.get("blocks", []):
            if b.get("type", 0) != 0:
                continue
            inl, maxsize, last = [], 0, ""
            for ln in b.get("lines", []):
                parts = [sp for sp in ln.get("spans", []) if sp["text"]]
                if not parts:
                    continue
                if inl:
                    if last.endswith("-") and parts[0]["text"][:1].islower():
                        inl[-1]["s"] = inl[-1]["s"][:-1]
                    elif not last.endswith(" "):
                        inl.append(txt(" "))
                for sp in parts:
                    fl = sp.get("flags", 0)
                    maxsize = max(maxsize, sp["size"])
                    inl.append(txt(sp["text"], b=bool(fl & 16), i=bool(fl & 2)))
                    last = sp["text"]
            text = "".join(x["s"] for x in inl).strip()
            if not text:
                continue
            level = 0
            if len(text) < 200:
                if maxsize >= body * 1.6:
                    level = 2
                elif maxsize >= body * 1.25:
                    level = 3
                elif maxsize >= body * 1.1 and all(x.get("b") for x in inl if x["s"].strip()):
                    level = 4
            if level:
                blocks.append(para([txt(re.sub(r"\s+", " ", text))], h=level))
            else:
                merged = []
                for x in inl:
                    if merged and {k: v for k, v in merged[-1].items() if k != "s"} == \
                            {k: v for k, v in x.items() if k != "s"}:
                        merged[-1]["s"] += x["s"]
                    else:
                        merged.append(dict(x))
                merged[0]["s"] = merged[0]["s"].lstrip()
                merged[-1]["s"] = merged[-1]["s"].rstrip()
                blocks.append(para([m for m in merged if m["s"]]))
    return blocks


def _blocks_qt(path):
    try:
        from PySide6.QtPdf import QPdfDocument
    except Exception:
        raise ReaderError("Zum Lesen von PDF-Dateien fehlt das Python-Paket PyMuPDF.")
    doc = QPdfDocument(None)
    doc.load(path)
    if doc.pageCount() <= 0:
        raise ReaderError("Das PDF konnte nicht gelesen werden.")
    blocks = [para([txt(os.path.splitext(os.path.basename(path))[0])], h=1)]
    for n in range(doc.pageCount()):
        text = doc.getAllText(n).text()
        for chunk in re.split(r"\n\s*\n", text):
            t = re.sub(r"\s+", " ", chunk).strip()
            if t:
                blocks.append(para([txt(t)]))
    return blocks


# ---------------------------------------------------------------- Schriften
def _fonts():
    global _FONT_CACHE
    if _FONT_CACHE is None:
        _FONT_CACHE = {}
        for root in ("/usr/share/fonts", "/usr/local/share/fonts", os.path.expanduser("~/.local/share/fonts"),
                     os.path.expanduser("~/.fonts")):
            for dp, _, files in os.walk(root):
                for f in files:
                    if f.lower().endswith(".ttf"):
                        _FONT_CACHE.setdefault(f[:-4], os.path.join(dp, f))
    return _FONT_CACHE


def pick_font(flags):
    """(fontname, fontfile) passend zu Serife, Dicktengleichheit, fett und kursiv."""
    kind = "mono" if flags & 8 else ("serif" if flags & 4 else "sans")
    bold, ital = bool(flags & 16), bool(flags & 2)
    style = {(False, False): "Regular", (True, False): "Bold", (False, True): "Italic", (True, True): "BoldItalic"}
    fonts = _fonts()
    name = "%s-%s" % (FAMILY[kind], style[(bold, ital)])
    if name in fonts:
        return "Sf" + name.replace("-", ""), fonts[name]
    dj = FALLBACK[kind] + {(False, False): "", (True, False): "-Bold", (False, True): "-Oblique",
                           (True, True): "-BoldOblique"}[(bold, ital)]
    if dj in fonts:
        return "Sf" + dj.replace("-", ""), fonts[dj]
    return BASE14[kind][(1 if bold else 0) + (2 if ital else 0)], None


def _rgb(c):
    return ((c >> 16) & 255) / 255.0, ((c >> 8) & 255) / 255.0, (c & 255) / 255.0


# ---------------------------------------------------------------- PDF direkt ändern
class PdfEditor:
    def __init__(self, path):
        if pymupdf is None:
            raise PdfError("Zum Bearbeiten von PDF-Dateien fehlt das Python-Paket PyMuPDF. "
                           "Bitte ./install.sh erneut ausführen (mit Internetverbindung).")
        self.path = os.path.abspath(path)
        try:
            self.doc = pymupdf.open(self.path)
        except Exception as e:
            raise PdfError("Das PDF konnte nicht geöffnet werden: %s" % e)
        if self.doc.needs_pass:
            raise PdfError("Das PDF ist mit einem Kennwort geschützt.")
        if not self.doc.is_pdf:
            raise PdfError("Die Datei ist kein PDF.")
        self.undo = []
        self.modified = False
        self.backed_up = False

    def count(self):
        return self.doc.page_count

    # ---- Rückgängig
    def snapshot(self):
        self.undo.append(self.doc.tobytes())
        limit = 15 if len(self.undo[-1]) < 20_000_000 else 3
        del self.undo[:-limit]
        self.modified = True

    def undo_last(self):
        if not self.undo:
            return False
        data = self.undo.pop()
        self.doc.close()
        self.doc = pymupdf.open(stream=data, filetype="pdf")
        self.modified = True
        return True

    # ---- Anzeige
    def render(self, pno, zoom):
        pix = self.doc[pno].get_pixmap(matrix=pymupdf.Matrix(zoom, zoom), alpha=False)
        return pix.samples, pix.width, pix.height, pix.stride

    def page_size(self, pno):
        r = self.doc[pno].rect
        return r.width, r.height

    # ---- Text
    def line_at(self, pno, x, y):
        """Textzeile an der Stelle (PDF-Punkte) oder None."""
        page = self.doc[pno]
        best = None
        for b in page.get_text("dict").get("blocks", []):
            for ln in b.get("lines", []):
                spans = [s for s in ln.get("spans", []) if s["text"].strip()]
                if not spans:
                    continue
                x0, y0, x1, y1 = ln["bbox"]
                if x0 - 2 <= x <= x1 + 2 and y0 - 1 <= y <= y1 + 1:
                    s = spans[0]
                    uniform = all((round(q["size"], 1), q.get("flags", 0), q.get("color", 0)) ==
                                  (round(s["size"], 1), s.get("flags", 0), s.get("color", 0)) for q in spans)
                    best = {"uniform": uniform,"text": "".join(s2["text"] for s2 in ln["spans"]).rstrip(), "bbox": tuple(ln["bbox"]),
                            "origin": tuple(s["origin"]), "size": s["size"], "color": s.get("color", 0),
                            "flags": s.get("flags", 0), "dir": tuple(ln.get("dir", (1, 0)))}
        return best

    def _check(self, page):
        if page.rotation:
            raise PdfError("Auf einer gedrehten Seite kann Text nicht geändert werden.")

    def _redact(self, page, rects):
        for r in rects:
            page.add_redact_annot(pymupdf.Rect(r), fill=False, cross_out=False)
        page.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_NONE, graphics=pymupdf.PDF_REDACT_LINE_ART_NONE)

    def _insert(self, page, point, text, size, color, flags):
        name, file = pick_font(flags)
        kw = {"fontsize": size, "fontname": name, "color": color}
        if file:
            kw["fontfile"] = file
        page.insert_text(pymupdf.Point(point), text, **kw)

    def _shrink(self, bbox):
        x0, y0, x1, y1 = bbox
        h = y1 - y0
        return (x0 - 0.5, y0 + h * 0.18, x1 + 0.5, y1 - h * 0.18)

    def replace_line(self, pno, line, new_text):
        page = self.doc[pno]
        self._check(page)
        if abs(line["dir"][0] - 1) > 0.01 or abs(line["dir"][1]) > 0.01:
            raise PdfError("Schräg oder senkrecht gesetzter Text kann nicht geändert werden.")
        self.snapshot()
        self._redact(page, [self._shrink(line["bbox"])])
        if new_text.strip():
            self._insert(page, line["origin"], new_text, line["size"], _rgb(line["color"]), line["flags"])

    def _width(self, text, size, flags):
        name, file = pick_font(flags)
        try:
            f = pymupdf.Font(fontfile=file) if file else pymupdf.Font(name)
            return f.text_length(text, fontsize=size)
        except Exception:
            return len(text) * size * 0.5

    def replace_all(self, old, new):
        """Ersetzt jeden Treffer; liefert (Anzahl, übersprungene Treffer).

        Jede betroffene Zeile wird entfernt und Abschnitt für Abschnitt (mit jeweils eigener Größe, Farbe und
        Schriftart) neu gesetzt; folgende Abschnitte rücken nach, damit nichts überlappt.
        """
        if not old:
            return 0, 0
        pat = re.compile(re.escape(old), re.IGNORECASE)
        todo, skipped = [], 0
        for pno in range(self.doc.page_count):
            page = self.doc[pno]
            lines = []
            for b in page.get_text("dict").get("blocks", []):
                for ln in b.get("lines", []):
                    spans = [sp for sp in ln.get("spans", []) if sp["text"]]
                    whole = "".join(sp["text"] for sp in spans)
                    total = len(pat.findall(whole))
                    if not total:
                        continue
                    inside = sum(len(pat.findall(sp["text"])) for sp in spans)
                    d = ln.get("dir", (1, 0))
                    if page.rotation or abs(d[0] - 1) > 0.01 or abs(d[1]) > 0.01 or inside == 0:
                        skipped += total
                        continue
                    skipped += total - inside
                    lines.append((ln, spans, inside))
            if lines:
                todo.append((pno, lines))
        if not todo:
            return 0, skipped
        self.snapshot()
        n = 0
        for pno, lines in todo:
            page = self.doc[pno]
            self._redact(page, [self._shrink(ln["bbox"]) for ln, _, _ in lines])
            for ln, spans, cnt in lines:
                x, shifted = None, False
                for sp in spans:
                    text = pat.sub(lambda m: new, sp["text"])
                    ox, oy = sp["origin"]
                    px = x if (shifted and x is not None) else ox
                    if text.strip():
                        self._insert(page, (px, oy), text, sp["size"], _rgb(sp.get("color", 0)), sp.get("flags", 0))
                    if text != sp["text"]:
                        shifted = True
                    x = px + self._width(text, sp["size"], sp.get("flags", 0))
                n += cnt
        return n, skipped

    def add_text(self, pno, x, y, text, size, flags=0):
        page = self.doc[pno]
        self._check(page)
        self.snapshot()
        lines = text.split("\n")
        for k, line in enumerate(lines):
            if line:
                self._insert(page, (x, y + k * size * 1.25), line, size, (0, 0, 0), flags)

    # ---- Formularfelder
    def field_count(self):
        try:
            return int(self.doc.is_form_pdf or 0)
        except Exception:
            return 0

    @staticmethod
    def _on_name(w):
        """Name des Ein-Zustands eines Ankreuzfelds oder Optionsknopfs."""
        try:
            for st in (w.button_states() or {}).get("normal") or []:
                if st and st != "Off":
                    return st
        except Exception:
            pass
        st = w.on_state()
        return st if isinstance(st, str) and st else "Yes"

    @staticmethod
    def _pdf_name(st):
        """Zustandsname als gültiger PDF-Name (Sonderzeichen als #xx)."""
        raw = re.sub(r"\\([0-7]{3})", lambda m: chr(int(m.group(1), 8)), st)
        out = "/"
        for ch in raw.encode("latin-1", "replace"):
            c = chr(ch)
            out += c if (33 <= ch <= 126 and c not in "#/%()<>[]{}") else "#%02x" % ch
        return out

    def fields(self, pno):
        """Formularfelder der Seite mit Lage in Anzeige-Koordinaten (PDF-Punkte)."""
        page = self.doc[pno]
        out = []
        rot = page.rotation_matrix
        for w in page.widgets():
            t = w.field_type
            kind = {pymupdf.PDF_WIDGET_TYPE_TEXT: "text", pymupdf.PDF_WIDGET_TYPE_CHECKBOX: "check",
                    pymupdf.PDF_WIDGET_TYPE_RADIOBUTTON: "radio", pymupdf.PDF_WIDGET_TYPE_COMBOBOX: "combo",
                    pymupdf.PDF_WIDGET_TYPE_LISTBOX: "list"}.get(t)
            if kind is None:
                continue
            flags = w.field_flags or 0
            r = w.rect * rot
            r.normalize()
            val = w.field_value
            if kind in ("check", "radio"):
                state = self.doc.xref_get_key(w.xref, "AS")
                val = state[0] == "name" and state[1] not in ("/Off", "")
            out.append({"xref": w.xref, "kind": kind, "name": w.field_name or "", "value": val,
                        "rect": (r.x0, r.y0, r.x1, r.y1), "choices": list(w.choice_values or []),
                        "multiline": bool(flags & pymupdf.PDF_TX_FIELD_IS_MULTILINE),
                        "password": bool(flags & pymupdf.PDF_TX_FIELD_IS_PASSWORD),
                        "editable": bool(flags & pymupdf.PDF_CH_FIELD_IS_EDIT),
                        "readonly": bool(flags & pymupdf.PDF_FIELD_IS_READ_ONLY),
                        "maxlen": int(w.text_maxlen or 0), "fontsize": float(w.text_fontsize or 0),
                        "font": str(w.text_font or ""), "align": self._quadding(w.xref)})
        return out

    def _quadding(self, xref):
        """Ausrichtung des Feldtexts: 0 links, 1 mittig, 2 rechts (auch vom Elternfeld oder Formular geerbt)."""
        doc = self.doc
        try:
            x = xref
            for _ in range(8):
                q = doc.xref_get_key(x, "Q")
                if q[0] == "int":
                    return int(q[1])
                par = doc.xref_get_key(x, "Parent")
                if par[0] != "xref":
                    break
                x = int(par[1].split()[0])
            q = doc.xref_get_key(doc.pdf_catalog(), "AcroForm/Q")
            if q[0] == "int":
                return int(q[1])
        except Exception:
            pass
        return 0

    def set_field(self, pno, xref, value):
        page = self.doc[pno]
        target = None
        for w in page.widgets():
            if w.xref == xref:
                target = w
                break
        if target is None:
            raise PdfError("Das Formularfeld wurde nicht gefunden.")
        self.snapshot()
        t = target.field_type
        if t in (pymupdf.PDF_WIDGET_TYPE_CHECKBOX, pymupdf.PDF_WIDGET_TYPE_RADIOBUTTON):
            self._set_button(target, bool(value), t == pymupdf.PDF_WIDGET_TYPE_RADIOBUTTON)
            return
        target.field_value = "" if value is None else str(value)
        target.update()

    def _set_button(self, w, on, radio):
        doc = self.doc
        name = self._pdf_name(self._on_name(w)) if on else "/Off"
        doc.xref_set_key(w.xref, "AS", name)
        parent = doc.xref_get_key(w.xref, "Parent")
        if parent[0] == "xref":
            pxref = int(parent[1].split()[0])
            doc.xref_set_key(pxref, "V", name)
            kids = doc.xref_get_key(pxref, "Kids")
            if radio and on and kids[0] == "array":
                for k in re.findall(r"(\d+) 0 R", kids[1]):
                    if int(k) != w.xref:
                        doc.xref_set_key(int(k), "AS", "/Off")
        else:
            doc.xref_set_key(w.xref, "V", name)
            if radio and on:                     # Knöpfe gleichen Namens ohne gemeinsames Elternfeld
                for page in doc:
                    for o in page.widgets():
                        if (o.xref != w.xref and o.field_type == pymupdf.PDF_WIDGET_TYPE_RADIOBUTTON
                                and o.field_name == w.field_name):
                            doc.xref_set_key(o.xref, "AS", "/Off")
                            doc.xref_set_key(o.xref, "V", name)

    # ---- Seiten
    def delete_page(self, pno):
        if self.doc.page_count <= 1:
            raise PdfError("Die letzte Seite kann nicht gelöscht werden.")
        self.snapshot()
        self.doc.delete_page(pno)

    def rotate_page(self, pno, deg=90):
        self.snapshot()
        page = self.doc[pno]
        page.set_rotation((page.rotation + deg) % 360)

    def move_page(self, pno, delta):
        to = pno + delta
        if to < 0 or to >= self.doc.page_count:
            return pno
        self.snapshot()
        if delta > 0:
            self.doc.move_page(pno, to + 1)
        else:
            self.doc.move_page(pno, to)
        return to

    def append_pdf(self, other):
        try:
            src = pymupdf.open(other)
        except Exception as e:
            raise PdfError("Die Datei konnte nicht geöffnet werden: %s" % e)
        if not src.is_pdf:
            raise PdfError("Die Datei ist kein PDF.")
        self.snapshot()
        self.doc.insert_pdf(src)
        src.close()

    # ---- Speichern
    def save(self, dest):
        dest = os.path.abspath(dest)
        tmp = dest + ".teil"
        try:
            self.doc.save(tmp, garbage=3, deflate=True)
            chk = pymupdf.open(tmp)
            ok = chk.page_count == self.doc.page_count
            chk.close()
            if not ok:
                raise PdfError("Die geschriebene Datei ist unvollständig. Es wurde nichts überschrieben.")
            if dest == self.path and not self.backed_up and os.path.exists(self.path):
                shutil.copy2(self.path, self.path + ".bak")
                self.backed_up = True
            data = self.doc.tobytes()
            self.doc.close()
            os.replace(tmp, dest)
            self.doc = pymupdf.open(stream=data, filetype="pdf")
            self.path = dest
            self.modified = False
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)
