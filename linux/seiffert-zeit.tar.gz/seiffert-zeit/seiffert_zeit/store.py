import json, os, re, threading, time
from pathlib import Path
from .config import atomic_write, log

FORMAT = {"app": "seifferts-zeit", "format": 1}


class Store:
    def __init__(self, settings):
        self.s = settings
        self.lock = threading.RLock()
        self.dir = settings.data_dir()
        self.main = self.dir / "zeit-daten.json"
        self.backups = self.dir / "Sicherungen"
        self.state = None
        self.seq = 1
        self._mtime = 0
        self.last_backup = ""
        self.load()

    # ---- Lesen
    def _read(self, path):
        j = json.loads(Path(path).read_text("utf-8"))
        d = j.get("data", j)
        if not isinstance(d, dict) or not isinstance(d.get("entries"), list):
            raise ValueError("kein Zeitdaten-Format")
        return d

    def load(self):
        with self.lock:
            self.dir.mkdir(parents=True, exist_ok=True)
            if self.main.exists():
                try:
                    self.state = self._read(self.main)
                    self._mtime = self.main.stat().st_mtime
                    return
                except Exception as e:
                    log("Hauptdatei unlesbar (%s), versuche Sicherung" % e)
                    bad = self.main.with_name("zeit-daten.defekt-%d.json" % int(time.time()))
                    try:
                        self.main.replace(bad)
                    except OSError:
                        pass
                    for p in sorted(self.backups.glob("zeit-sicherung-*.json"), reverse=True):
                        try:
                            self.state = self._read(p)
                            log("Stand aus %s geladen" % p.name)
                            self.s.set(drive_dirty=True)
                            self._write_main()
                            return
                        except Exception:
                            continue
            self.state = None

    def is_empty(self):
        return not self.state or not self.state.get("entries")

    def check_external(self):
        """Hauptdatei ausserhalb der App geaendert: ihr Stand gilt."""
        with self.lock:
            try:
                mt = self.main.stat().st_mtime
            except OSError:
                return False
            if mt == self._mtime:
                return False
            try:
                d = self._read(self.main)
            except Exception:
                self._mtime = mt
                return False
            self._mtime = mt
            if d != self.state:
                self.state = d
                self.seq += 1
                self.s.set(drive_dirty=True)
                log("Hauptdatei von aussen geaendert, Stand uebernommen")
                return True
            return False

    # ---- Schreiben
    def _payload(self):
        return json.dumps({**FORMAT, "saved": time.strftime("%Y-%m-%dT%H:%M:%S"), "data": self.state},
                          ensure_ascii=False, indent=1)

    def _write_main(self):
        atomic_write(self.main, self._payload())
        self._mtime = self.main.stat().st_mtime

    def put(self, obj):
        with self.lock:
            if obj == self.state:
                return
            self.state = obj
            self._write_main()
            self.s.set(drive_dirty=True)
            try:
                self.backup(None)
            except Exception as e:
                log("Tagessicherung fehlgeschlagen: %s" % e)

    def replace(self, obj):
        """Von Drive uebernommen: Seite muss neu laden."""
        with self.lock:
            if not self.is_empty():
                self.backup("vor-drive-uebernahme")
            self.state = obj
            self._write_main()
            self.seq += 1
            self.s.set(drive_dirty=False)

    def backup(self, suffix):
        with self.lock:
            if self.state is None:
                return None
            self.backups.mkdir(parents=True, exist_ok=True)
            day = time.strftime("%Y-%m-%d")
            if suffix:
                name = "zeit-sicherung-%s-%s-%s.json" % (day, time.strftime("%H%M%S"), suffix)
            else:
                name = "zeit-sicherung-%s.json" % day
            atomic_write(self.backups / name, self._payload())
            self.last_backup = time.strftime("%d.%m.%Y %H:%M")
            self._prune()
            return name

    def _prune(self):
        daily, extra = [], []
        for p in self.backups.glob("zeit-sicherung-*.json"):
            (daily if re.fullmatch(r"zeit-sicherung-\d{4}-\d\d-\d\d\.json", p.name) else extra).append(p)
        for lst, keep in ((daily, 30), (extra, 20)):
            lst.sort(key=lambda p: p.name, reverse=True)
            for p in lst[keep:]:
                try:
                    p.unlink()
                except OSError:
                    pass

    def raw_bytes(self):
        with self.lock:
            return self._payload().encode("utf-8")

    def parse(self, raw):
        j = json.loads(raw.decode("utf-8") if isinstance(raw, bytes) else raw)
        d = j.get("data", j)
        if not isinstance(d, dict) or not isinstance(d.get("entries"), list):
            raise ValueError("Drive-Datei hat kein Zeitdaten-Format")
        return d
