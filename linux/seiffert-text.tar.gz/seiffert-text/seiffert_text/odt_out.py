"""Eigener ODT-Schreiber (QTextDocument -> .odt) mit echten Überschriften, Listen und Tabellen."""
import os
import re
import zipfile
from xml.sax.saxutils import escape, quoteattr

from PySide6.QtCore import QBuffer, QIODevice, QUrl, Qt
from PySide6.QtGui import QImage, QTextCursor, QTextDocument, QTextFormat, QTextCharFormat

from .common import PROP_RAW_BLOCK, PROP_RAW_INLINE, PROP_UNNUM, LS
from .latex_out import Exporter, ORDERED

NS = ('xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" '
      'xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" '
      'xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" '
      'xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" '
      'xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" '
      'xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0" '
      'xmlns:xlink="http://www.w3.org/1999/xlink" '
      'xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0" '
      'xmlns:dc="http://purl.org/dc/elements/1.1/" '
      'xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" '
      'xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" '
      'xmlns:loext="urn:org:documentfoundation:names:experimental:office:xmlns:loext:1.0"')

HEAD_SIZES = {1: 20, 2: 16, 3: 14, 4: 12, 5: 12, 6: 12}


def xesc(s):
    return escape(s)


def text_xml(s):
    """Text mit Leerzeichen-Regeln von ODF (mehrfache Leerzeichen als text:s)."""
    out = []
    for k, part in enumerate(s.split(LS)):
        if k:
            out.append("<text:line-break/>")
        part = escape(part)
        part = re.sub(r" {2,}", lambda m: ' <text:s text:c="%d"/>' % (len(m.group(0)) - 1), part)
        if part.startswith(" "):
            part = "<text:s/>" + part[1:]
        if part.endswith(" "):
            part = part[:-1] + "<text:s/>"
        out.append(part)
    return "".join(out)


class OdtWriter(Exporter):
    def __init__(self, doc, base_dir=None):
        super().__init__(doc, None, base_dir)
        self.tstyles = {}
        self.pics = {}          # Pfad im Paket -> Bytes
        self.picn = 0
        self.tablen = 0
        self.table_styles = []

    # ---------- Zeichenformate ----------
    def tname(self, key):
        bold, ital, und, st, tt, sup, sub, href = key[:8]
        flags = (bold, ital, und, st, tt, sup, sub)
        if not any(flags):
            return None
        if flags not in self.tstyles:
            self.tstyles[flags] = "T%d" % (len(self.tstyles) + 1)
        return self.tstyles[flags]

    def inline_xml(self, block, in_cell=False):
        heading = block.blockFormat().headingLevel() > 0
        parts = []
        it = block.begin()
        while not it.atEnd():
            frag = it.fragment()
            it += 1
            cf = frag.charFormat()
            txt = frag.text()
            if cf.isImageFormat():
                parts.append(("img", cf.toImageFormat(), None))
            elif cf.hasProperty(PROP_RAW_INLINE):
                parts.append(("raw", txt.replace(LS, "\n"), None))
            else:
                parts.append(("txt", txt, self._frag_key(cf, heading)))
        merged = []
        for p in parts:
            if merged and p[0] == "txt" and merged[-1][0] == "txt" and merged[-1][2] == p[2]:
                merged[-1] = ("txt", merged[-1][1] + p[1], p[2])
            else:
                merged.append(p)
        out = []
        for kind, val, key in merged:
            if kind == "img":
                out.append(self.image_xml(val))
            elif kind == "raw":
                m = re.fullmatch(r"\s*\\footnote\{(.*)\}\s*", val, re.S)
                if m:
                    note = re.sub(r"\\([&%$#_{}])", r"\1", m.group(1))
                    note = re.sub(r"\\textbackslash\{\}", "\\\\", note)
                    out.append('<text:note text:note-class="footnote"><text:note-citation>*</text:note-citation>'
                               '<text:note-body><text:p text:style-name="Footnote">%s</text:p></text:note-body></text:note>'
                               % text_xml(note))
                else:
                    out.append('<text:span text:style-name="Raw_20_Text">%s</text:span>' % text_xml(val))
            else:
                x = text_xml(val)
                name = self.tname(key)
                if name:
                    x = '<text:span text:style-name="%s">%s</text:span>' % (name, x)
                if key[7]:
                    x = '<text:a xlink:type="simple" xlink:href=%s>%s</text:a>' % (quoteattr(key[7]), x)
                out.append(x)
        return "".join(out)

    def image_xml(self, fmt):
        res = self.doc.resource(QTextDocument.ResourceType.ImageResource, QUrl(fmt.name()))
        img = res if isinstance(res, QImage) else None
        if (img is None or img.isNull()) and self.base_dir and \
                os.path.isfile(os.path.join(self.base_dir, fmt.name())):
            img = QImage(os.path.join(self.base_dir, fmt.name()))
        if img is None or img.isNull():
            return '<text:span text:style-name="Raw_20_Text">%s</text:span>' % xesc("[Bild: %s]" % fmt.name())
        buf = QBuffer()
        buf.open(QIODevice.OpenModeFlag.WriteOnly)
        img.save(buf, "PNG")
        self.picn += 1
        path = "Pictures/bild%d.png" % self.picn
        self.pics[path] = bytes(buf.data())
        w = fmt.width() if fmt.width() > 0 else img.width()
        h = fmt.height() if fmt.height() > 0 else img.height()
        wc, hc = w / 96.0 * 2.54, h / 96.0 * 2.54
        return ('<draw:frame draw:name="Bild%d" text:anchor-type="as-char" svg:width="%.2fcm" svg:height="%.2fcm">'
                '<draw:image xlink:href="%s" xlink:type="simple" xlink:show="embed" xlink:actuate="onLoad"/>'
                '</draw:frame>' % (self.picn, wc, hc, path))

    # ---------- Blöcke ----------
    def para_xml(self, block, style=None, in_cell=False):
        bf = block.blockFormat()
        kind = self._block_kind(block)
        content = self.inline_xml(block, in_cell)
        if kind == "head":
            lvl = min(6, bf.headingLevel())
            unn = "_Unnum" if bf.hasProperty(PROP_UNNUM) else ""
            return '<text:h text:style-name="Heading_20_%d%s" text:outline-level="%d">%s</text:h>' % (lvl, unn, lvl, content)
        a = bf.alignment()
        pstyle = style
        if pstyle is None:
            if bf.hasProperty(QTextFormat.Property.BlockQuoteLevel) and bf.property(QTextFormat.Property.BlockQuoteLevel):
                pstyle = "Quotations"
            elif a & Qt.AlignmentFlag.AlignHCenter:
                pstyle = "P_center"
            elif a & Qt.AlignmentFlag.AlignRight:
                pstyle = "P_right"
            elif a & Qt.AlignmentFlag.AlignJustify:
                pstyle = "P_justify"
            else:
                pstyle = "Text_20_Body"
        return '<text:p text:style-name="%s">%s</text:p>' % (pstyle, content)

    def blocks_xml(self, items, in_cell=False):
        out = []
        i = 0
        n = len(items)
        stack = []   # [ordered]
        item_open = []

        def close_lists(to=0):
            while len(stack) > to:
                if item_open[-1]:
                    out.append("</text:list-item>")
                out.append("</text:list>")
                stack.pop()
                item_open.pop()
        while i < n:
            kind, obj = items[i]
            if kind == "table":
                close_lists()
                out.append(self.table_xml(obj))
                i += 1
                continue
            k = self._block_kind(obj)
            if k != "list":
                close_lists()
            if k == "raw":
                lines = obj.text().split(LS)
                out.append('<text:p text:style-name="Raw_20_Block">%s</text:p>' % text_xml(LS.join(lines)))
            elif k == "hr":
                out.append('<text:p text:style-name="Horizontal_20_Line"/>')
            elif k == "code":
                out.append('<text:p text:style-name="Preformatted_20_Text">%s</text:p>' % text_xml(obj.text().replace(LS, " ")))
            elif k == "list":
                fmt = obj.textList().format()
                d = max(1, fmt.indent())
                od = fmt.style() in ORDERED
                while len(stack) > d:
                    close_lists(len(stack) - 1)
                if len(stack) == d and stack[-1] != od:
                    close_lists(d - 1)
                while len(stack) < d:
                    stack.append(od)
                    item_open.append(False)
                    out.append('<text:list text:style-name="%s">' % ("L_number" if od else "L_bullet"))
                    if len(stack) < d:
                        out.append("<text:list-item>")
                        item_open[-1] = True
                if item_open[-1]:
                    out.append("</text:list-item>")
                out.append("<text:list-item>")
                item_open[-1] = True
                content = self.inline_xml(obj, True)
                out.append('<text:p text:style-name="List_20_Contents">%s</text:p>' % content)
            else:
                if k == "par" and not self.inline_xml(obj, in_cell).strip():
                    i += 1
                    continue
                out.append(self.para_xml(obj, in_cell=in_cell))
            i += 1
        close_lists()
        return "".join(out)

    def table_xml(self, tbl):
        nr, nc = tbl.rows(), tbl.columns()
        self.tablen += 1
        name = "Tabelle%d" % self.tablen
        colw = 17.0 / nc
        self.table_styles.append(
            '<style:style style:name="%s" style:family="table"><style:table-properties style:width="17cm" '
            'table:align="margins"/></style:style>'
            '<style:style style:name="%s.col" style:family="table-column"><style:table-column-properties '
            'style:column-width="%.3fcm"/></style:style>' % (name, name, colw))
        hdr = tbl.format().headerRowCount() > 0
        out = ['<table:table table:name="%s" table:style-name="%s">' % (name, name),
               '<table:table-column table:style-name="%s.col" table:number-columns-repeated="%d"/>' % (name, nc)]
        for r in range(nr):
            if r == 0 and hdr:
                out.append("<table:table-header-rows>")
            out.append("<table:table-row>")
            for c in range(nc):
                cell = tbl.cellAt(r, c)
                if cell.row() != r or cell.column() != c:
                    out.append("<table:covered-table-cell/>")
                    continue
                items = self._walk(cell.firstCursorPosition().block(), cell.lastCursorPosition().position(), tbl)
                inner = self.blocks_xml(items, True) or '<text:p text:style-name="Table_20_Contents"/>'
                inner = inner.replace('text:style-name="Text_20_Body"', 'text:style-name="Table_20_Contents"')
                attrs = ""
                if cell.columnSpan() > 1:
                    attrs += ' table:number-columns-spanned="%d"' % cell.columnSpan()
                if cell.rowSpan() > 1:
                    attrs += ' table:number-rows-spanned="%d"' % cell.rowSpan()
                out.append('<table:table-cell table:style-name="Zelle" office:value-type="string"%s>%s</table:table-cell>'
                           % (attrs, inner))
            out.append("</table:table-row>")
            if r == 0 and hdr:
                out.append("</table:table-header-rows>")
        out.append("</table:table>")
        return "".join(out)

    # ---------- Dateien ----------
    def text_style_xml(self):
        out = []
        for flags, name in self.tstyles.items():
            bold, ital, und, st, tt, sup, sub = flags
            props = []
            if bold:
                props.append('fo:font-weight="bold"')
            if ital:
                props.append('fo:font-style="italic"')
            if und:
                props.append('style:text-underline-style="solid" style:text-underline-width="auto" style:text-underline-color="font-color"')
            if st:
                props.append('style:text-line-through-style="solid"')
            if tt:
                props.append('style:font-name="Liberation Mono" fo:font-family="\'Liberation Mono\'"')
            if sup:
                props.append('style:text-position="super 58%"')
            if sub:
                props.append('style:text-position="sub 58%"')
            out.append('<style:style style:name="%s" style:family="text"><style:text-properties %s/></style:style>'
                       % (name, " ".join(props)))
        return "".join(out)

    def content_xml(self, body):
        lists = []
        for nm, bullet in (("L_bullet", True), ("L_number", False)):
            lv = []
            for i in range(1, 11):
                ind = 0.63 * i
                if bullet:
                    lv.append('<text:list-level-style-bullet text:level="%d" text:bullet-char="•">'
                              '<style:list-level-properties text:list-level-position-and-space-mode="label-alignment">'
                              '<style:list-level-label-alignment text:label-followed-by="listtab" fo:margin-left="%.2fcm" fo:text-indent="-0.63cm"/>'
                              '</style:list-level-properties></text:list-level-style-bullet>' % (i, ind))
                else:
                    lv.append('<text:list-level-style-number text:level="%d" style:num-suffix="." style:num-format="1">'
                              '<style:list-level-properties text:list-level-position-and-space-mode="label-alignment">'
                              '<style:list-level-label-alignment text:label-followed-by="listtab" fo:margin-left="%.2fcm" fo:text-indent="-0.63cm"/>'
                              '</style:list-level-properties></text:list-level-style-number>' % (i, ind))
            lists.append('<text:list-style style:name="%s">%s</text:list-style>' % (nm, "".join(lv)))
        auto = (self.text_style_xml() + "".join(lists) + "".join(self.table_styles) +
                '<style:style style:name="P_center" style:family="paragraph" style:parent-style-name="Text_20_Body">'
                '<style:paragraph-properties fo:text-align="center"/></style:style>'
                '<style:style style:name="P_right" style:family="paragraph" style:parent-style-name="Text_20_Body">'
                '<style:paragraph-properties fo:text-align="end"/></style:style>'
                '<style:style style:name="P_justify" style:family="paragraph" style:parent-style-name="Text_20_Body">'
                '<style:paragraph-properties fo:text-align="justify"/></style:style>'
                '<style:style style:name="Zelle" style:family="table-cell"><style:table-cell-properties '
                'fo:padding="0.1cm" fo:border="0.5pt solid #000000"/></style:style>')
        return ('<?xml version="1.0" encoding="UTF-8"?><office:document-content %s office:version="1.2">'
                '<office:automatic-styles>%s</office:automatic-styles><office:body><office:text>%s</office:text>'
                '</office:body></office:document-content>' % (NS, auto, body))

    def styles_xml(self):
        heads = "".join(
            '<style:style style:name="Heading_20_%d" style:display-name="Heading %d" style:family="paragraph" '
            'style:parent-style-name="Heading" style:next-style-name="Text_20_Body" style:default-outline-level="%d">'
            '<style:text-properties fo:font-size="%dpt" fo:font-weight="bold"/></style:style>'
            % (i, i, i, HEAD_SIZES[i]) for i in range(1, 7))
        heads += "".join(
            '<style:style style:name="Heading_20_%d_Unnum" style:family="paragraph" '
            'style:parent-style-name="Heading_20_%d"/>' % (i, i) for i in range(1, 7))
        return ('<?xml version="1.0" encoding="UTF-8"?><office:document-styles %s office:version="1.2">'
                '<office:font-face-decls>'
                '<style:font-face style:name="Liberation Serif" svg:font-family="\'Liberation Serif\'" style:font-family-generic="roman"/>'
                '<style:font-face style:name="Liberation Mono" svg:font-family="\'Liberation Mono\'" style:font-family-generic="modern" style:font-pitch="fixed"/>'
                '</office:font-face-decls>'
                '<office:styles>'
                '<style:default-style style:family="paragraph"><style:paragraph-properties fo:orphans="2" fo:widows="2"/>'
                '<style:text-properties style:font-name="Liberation Serif" fo:font-size="12pt" fo:language="de" fo:country="DE"/></style:default-style>'
                '<style:style style:name="Standard" style:family="paragraph" style:class="text"/>'
                '<style:style style:name="Heading" style:family="paragraph" style:parent-style-name="Standard" style:next-style-name="Text_20_Body" style:class="text">'
                '<style:paragraph-properties fo:margin-top="0.4cm" fo:margin-bottom="0.2cm" fo:keep-with-next="always"/></style:style>'
                '%s'
                '<style:style style:name="Text_20_Body" style:display-name="Text Body" style:family="paragraph" style:parent-style-name="Standard" style:class="text">'
                '<style:paragraph-properties fo:margin-top="0cm" fo:margin-bottom="0.25cm"/></style:style>'
                '<style:style style:name="List_20_Contents" style:display-name="List Contents" style:family="paragraph" style:parent-style-name="Standard" style:class="list">'
                '<style:paragraph-properties fo:margin-top="0cm" fo:margin-bottom="0.08cm"/></style:style>'
                '<style:style style:name="Table_20_Contents" style:display-name="Table Contents" style:family="paragraph" style:parent-style-name="Standard" style:class="extra"/>'
                '<style:style style:name="Quotations" style:family="paragraph" style:parent-style-name="Standard" style:class="html">'
                '<style:paragraph-properties fo:margin-left="1cm" fo:margin-right="0.5cm" fo:margin-top="0cm" fo:margin-bottom="0.25cm"/></style:style>'
                '<style:style style:name="Preformatted_20_Text" style:display-name="Preformatted Text" style:family="paragraph" style:parent-style-name="Standard" style:class="html">'
                '<style:paragraph-properties fo:margin-top="0cm" fo:margin-bottom="0cm"/>'
                '<style:text-properties style:font-name="Liberation Mono" fo:font-size="10pt"/></style:style>'
                '<style:style style:name="Raw_20_Block" style:display-name="LaTeX Block" style:family="paragraph" style:parent-style-name="Standard">'
                '<style:paragraph-properties fo:margin-top="0.1cm" fo:margin-bottom="0.1cm" fo:background-color="#e6e6e6"/>'
                '<style:text-properties style:font-name="Liberation Mono" fo:font-size="10pt"/></style:style>'
                '<style:style style:name="Raw_20_Text" style:display-name="LaTeX Text" style:family="text">'
                '<style:text-properties style:font-name="Liberation Mono" fo:font-size="10pt" fo:background-color="#e6e6e6"/></style:style>'
                '<style:style style:name="Horizontal_20_Line" style:family="paragraph" style:parent-style-name="Standard">'
                '<style:paragraph-properties fo:margin-top="0cm" fo:margin-bottom="0.2cm" fo:border-bottom="0.5pt solid #000000" fo:padding="0cm"/></style:style>'
                '<style:style style:name="Footnote" style:family="paragraph" style:parent-style-name="Standard">'
                '<style:text-properties fo:font-size="10pt"/></style:style>'
                '</office:styles>'
                '<office:automatic-styles><style:page-layout style:name="pm1"><style:page-layout-properties '
                'fo:page-width="21cm" fo:page-height="29.7cm" fo:margin-top="2.5cm" fo:margin-bottom="2.5cm" '
                'fo:margin-left="2.5cm" fo:margin-right="2.5cm"/></style:page-layout></office:automatic-styles>'
                '<office:master-styles><style:master-page style:name="Standard" style:page-layout-name="pm1"/></office:master-styles>'
                '</office:document-styles>' % (NS, heads))

    def write(self, path):
        items = self._walk(self.doc.begin(), 10 ** 9)
        body = self.blocks_xml(items)
        content = self.content_xml(body)
        manifest = ['<?xml version="1.0" encoding="UTF-8"?><manifest:manifest %s manifest:version="1.2">'
                    '<manifest:file-entry manifest:full-path="/" manifest:media-type="application/vnd.oasis.opendocument.text"/>'
                    '<manifest:file-entry manifest:full-path="content.xml" manifest:media-type="text/xml"/>'
                    '<manifest:file-entry manifest:full-path="styles.xml" manifest:media-type="text/xml"/>'
                    '<manifest:file-entry manifest:full-path="meta.xml" manifest:media-type="text/xml"/>' % NS]
        for p in self.pics:
            manifest.append('<manifest:file-entry manifest:full-path="%s" manifest:media-type="image/png"/>' % p)
        manifest.append("</manifest:manifest>")
        meta = ('<?xml version="1.0" encoding="UTF-8"?><office:document-meta %s office:version="1.2"><office:meta>'
                '<meta:generator>Seifferts Text</meta:generator></office:meta></office:document-meta>' % NS)
        with zipfile.ZipFile(path, "w") as z:
            z.writestr(zipfile.ZipInfo("mimetype"), "application/vnd.oasis.opendocument.text")
            z.writestr("META-INF/manifest.xml", "".join(manifest), zipfile.ZIP_DEFLATED)
            z.writestr("content.xml", content, zipfile.ZIP_DEFLATED)
            z.writestr("styles.xml", self.styles_xml(), zipfile.ZIP_DEFLATED)
            z.writestr("meta.xml", meta, zipfile.ZIP_DEFLATED)
            for p, data in self.pics.items():
                z.writestr(p, data, zipfile.ZIP_DEFLATED)


def write_odt(doc, path, base_dir=None):
    OdtWriter(doc, base_dir).write(path)
