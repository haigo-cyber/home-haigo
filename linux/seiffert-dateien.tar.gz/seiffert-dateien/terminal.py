"""Eingebautes Terminal für Seifferts Dateien: Shell-Sitzungen über ein Pseudo-Terminal (pty).
Die Ausgabe geht als Base64 an die Oberfläche (Ereignis „term“), Eingaben kommen über api_term_write."""
from __future__ import annotations

import atexit
import base64
import fcntl
import os
import pty
import select
import shutil
import signal
import struct
import subprocess
import termios
import threading
import time

import backend as B

AppError = B.AppError
MAX_SESSIONS = 8


def _set_size(fd: int, cols: int, rows: int) -> None:
    fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack("HHHH", max(2, rows), max(2, cols), 0, 0))


class Terminals:
    def _term_init(self) -> None:
        if getattr(self, "_term_ready", False):
            return
        self._term_ready = True
        self._terms: dict[int, dict] = {}
        self._term_next = 1
        self._term_lock = threading.Lock()
        atexit.register(self._term_close_all)

    def _term_close_all(self) -> None:
        for tid in list(getattr(self, "_terms", {})):
            try:
                self.api_term_close(tid)
            except Exception:  # noqa: BLE001
                pass

    def api_term_open(self, cwd: str = "", cols: int = 80, rows: int = 24) -> dict:
        self._term_init()
        with self._term_lock:
            if len(self._terms) >= MAX_SESSIONS:
                raise AppError("Es laufen schon %d Terminals. Bitte eines schließen." % MAX_SESSIONS)
            tid = self._term_next
            self._term_next += 1
        d = os.path.expanduser(cwd) if cwd else os.path.expanduser("~")
        if not os.path.isdir(d):
            d = os.path.expanduser("~")
        shell = os.environ.get("SHELL") or shutil.which("bash") or "/bin/sh"
        if not os.path.exists(shell):
            shell = shutil.which("sh") or "/bin/sh"
        master, slave = pty.openpty()
        try:
            _set_size(slave, int(cols), int(rows))
            env = dict(os.environ)
            env.update(TERM="xterm-256color", COLORTERM="truecolor", TERM_PROGRAM="seiffert-dateien")
            for k in ("QT_QPA_PLATFORM", "QTWEBENGINE_CHROMIUM_FLAGS", "SD_DEBUG", "PYTHONINSPECT"):
                env.pop(k, None)
            argv = [shell]
            setsid = shutil.which("setsid")
            if setsid:
                argv = [setsid, "--ctty", shell]
            proc = subprocess.Popen(argv, stdin=slave, stdout=slave, stderr=slave, cwd=d, env=env, close_fds=True,
                                    **({} if setsid else {"start_new_session": True}))
        except OSError as e:
            os.close(master)
            os.close(slave)
            raise AppError("Das Terminal konnte nicht gestartet werden: " + (e.strerror or str(e)))
        os.close(slave)
        t = {"proc": proc, "fd": master, "cwd": d, "shell": shell, "alive": True}
        with self._term_lock:
            self._terms[tid] = t
        threading.Thread(target=self._term_reader, args=(tid, t), name="sd-term-%d" % tid, daemon=True).start()
        return {"id": tid, "shell": os.path.basename(shell), "cwd": d}

    def _term_reader(self, tid: int, t: dict) -> None:
        fd, proc = t["fd"], t["proc"]
        while t["alive"]:
            try:
                r, _, _ = select.select([fd], [], [], 0.5)
            except (OSError, ValueError):
                break
            if not r:
                if proc.poll() is not None:
                    # Prozess ist beendet; Rest der Ausgabe noch lesen
                    try:
                        r2, _, _ = select.select([fd], [], [], 0.05)
                    except (OSError, ValueError):
                        break
                    if not r2:
                        break
                continue
            try:
                data = os.read(fd, 65536)
            except OSError:
                break
            if not data:
                break
            self.emit("term", {"id": tid, "data": base64.b64encode(data).decode("ascii")})
        t["alive"] = False
        try:
            code = proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            code = None
        self.emit("term", {"id": tid, "exit": code})

    def _term(self, tid: int) -> dict:
        self._term_init()
        t = self._terms.get(int(tid))
        if not t:
            raise AppError("Dieses Terminal gibt es nicht mehr.")
        return t

    def api_term_write(self, id: int, data: str) -> bool:
        t = self._term(id)
        if not t["alive"]:
            return False
        buf = (data or "").encode("utf-8", "replace")
        view = memoryview(buf)
        deadline = time.monotonic() + 3
        while view and time.monotonic() < deadline:
            try:
                _, w, _ = select.select([], [t["fd"]], [], 0.2)
                if w:
                    n = os.write(t["fd"], view)
                    view = view[n:]
            except OSError:
                return False
        return not view

    def api_term_resize(self, id: int, cols: int, rows: int) -> bool:
        t = self._term(id)
        try:
            _set_size(t["fd"], int(cols), int(rows))
        except OSError:
            return False
        return True

    def api_term_state(self, id: int) -> dict:
        t = self._term(id)
        proc = t["proc"]
        alive = t["alive"] and proc.poll() is None
        idle = False
        cwd = t["cwd"]
        if alive:
            try:
                idle = os.tcgetpgrp(t["fd"]) == proc.pid
            except OSError:
                idle = False
            try:
                cwd = os.readlink("/proc/%d/cwd" % proc.pid)
            except OSError:
                pass
        return {"alive": alive, "idle": idle, "cwd": cwd}

    def api_term_close(self, id: int) -> bool:
        self._term_init()
        with self._term_lock:
            t = self._terms.pop(int(id), None)
        if not t:
            return False
        t["alive"] = False
        proc = t["proc"]
        try:
            pgid = os.getpgid(proc.pid)
        except OSError:
            pgid = None
        if pgid != proc.pid:            # noch nicht in eigener Sitzung: auf keinen Fall die Gruppe der App treffen
            pgid = None
        for sig in (signal.SIGHUP, signal.SIGTERM, signal.SIGKILL):
            if proc.poll() is not None:
                break
            try:
                if pgid:
                    os.killpg(pgid, sig)
                else:
                    proc.send_signal(sig)
            except OSError:
                break
            try:
                proc.wait(timeout=0.4)
            except subprocess.TimeoutExpired:
                continue
        try:
            os.close(t["fd"])
        except OSError:
            pass
        return True
