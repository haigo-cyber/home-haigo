#!/usr/bin/env python3
"""Starter-Design "Schreibtisch" für Seifferts Starter.

Eine Leiste oben (Name, Suchfeld, Uhr, Umschalter, Schließen), quadratische Knöpfe an der Seite (die Sorten: Alles, Programme, Dateien ...),
in der Mitte die Treffer als Kacheln, unten eine Zeile zum markierten Treffer. Das Fenster füllt auf Wunsch den ganzen Bildschirm und deckt
dabei das Panel des Desktops ab. Hintergrund: aus dem Farbschema erzeugt, ein eigenes Bild oder eine Farbe.

Die Klasse Desk erbt von der Wolke (Suche, Tasten, Aktionen, Symbole) und ersetzt nur Anordnung, Zeichnen und Mausbedienung.
Farben kommen aus skins.desk_palette (Farbdesign plus Farbschema dunkel, schwarz, metall, neon)."""
from __future__ import annotations

import math
import os
import time

import skins


def send_below(win_id: int) -> bool:
    """Bittet den Fenstermanager per Nachricht, das Fenster ganz nach unten zu legen (_NET_WM_STATE_BELOW).
    Manche Fenstermanager (openbox) beachten die Markierung beim Anzeigen nicht, die Nachricht aber schon."""
    try:
        import ctypes
        import ctypes.util
        lib = ctypes.util.find_library("X11")
        if not lib or not os.environ.get("DISPLAY"):
            return False
        x = ctypes.CDLL(lib)
        x.XOpenDisplay.restype = ctypes.c_void_p
        x.XOpenDisplay.argtypes = [ctypes.c_char_p]
        x.XInternAtom.restype = ctypes.c_ulong
        x.XInternAtom.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int]
        x.XDefaultRootWindow.restype = ctypes.c_ulong
        x.XDefaultRootWindow.argtypes = [ctypes.c_void_p]
        x.XSendEvent.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.c_int, ctypes.c_long, ctypes.c_void_p]
        x.XFlush.argtypes = [ctypes.c_void_p]
        x.XCloseDisplay.argtypes = [ctypes.c_void_p]
        d = x.XOpenDisplay(None)
        if not d:
            return False

        class Ev(ctypes.Structure):
            _fields_ = [("type", ctypes.c_int), ("serial", ctypes.c_ulong), ("send_event", ctypes.c_int),
                        ("display", ctypes.c_void_p), ("window", ctypes.c_ulong), ("message_type", ctypes.c_ulong),
                        ("format", ctypes.c_int), ("data", ctypes.c_long * 5), ("pad", ctypes.c_long * 8)]
        root = x.XDefaultRootWindow(d)
        for action in (0, 1):                                    # erst entfernen, dann setzen: sonst ignoriert der Fenstermanager die schon vorhandene Markierung
            ev = Ev()
            ev.type = 33                                         # ClientMessage
            ev.send_event = 1
            ev.display = d
            ev.window = int(win_id)
            ev.message_type = x.XInternAtom(d, b"_NET_WM_STATE", 0)
            ev.format = 32
            ev.data[0] = action                                  # _NET_WM_STATE_REMOVE / _NET_WM_STATE_ADD
            ev.data[1] = x.XInternAtom(d, b"_NET_WM_STATE_BELOW", 0)
            ev.data[3] = 1
            x.XSendEvent(d, root, 0, (1 << 20) | (1 << 19), ctypes.byref(ev))   # SubstructureRedirect | SubstructureNotify
            x.XFlush(d)
        x.XCloseDisplay(d)
        return True
    except Exception:
        return False

WEEKDAYS = ("Mo", "Di", "Mi", "Do", "Fr", "Sa", "So")
MONTHS = ("Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez")
BOTTOM = 66            # Höhe des Streifens unten (Zeile zum markierten Treffer)


def define(Cloud, env: dict):
    """Baut die Klasse Desk. env liefert die Hilfen aus starter.build_ui (col, mixc, wrap, ICONS, KIND_LABEL, NEON, METAL, Item)."""
    from PySide6.QtCore import QPoint, QPointF, QRect, QRectF, Qt, QTimer
    from PySide6.QtWidgets import QMenu, QWidget
    from PySide6.QtGui import QColor, QFont, QFontMetrics, QGuiApplication, QCursor, QLinearGradient, QPainter, QPainterPath, QPalette, QPen, QPixmap, QRadialGradient
    col, mixc, wrap, KIND_LABEL, NEON, METAL = env["col"], env["mixc"], env["wrap"], env["KIND_LABEL"], env["NEON"], env["METAL"]
    import backend as B
    import starterextra as SX

    def qc(h: str, a: int = 255) -> QColor:
        c = QColor(h)
        c.setAlpha(a)
        return c

    class _NoAnim:
        def stop(self) -> None:
            pass

        def start(self) -> None:
            pass

    class Desk(Cloud):
        surface = False                                          # Seifferts Oberfläche nutzt den Schreibtisch als Fläche (Klassenvorgabe, weil die Wolke schon im Aufbau fragt)
        def __init__(self, finder, backend) -> None:
            super().__init__(finder, backend)
            self.setMinimumSize(0, 0)
            self.setMaximumSize(16777215, 16777215)
            self.resize(1000, 640)
            self.depth = "off"
            self.spin_timer.stop()
            self.anim.stop()
            self.anim = _NoAnim()                                    # die Aufpoppen-Animation der Wolke wäre hier nur 10 Vollbild-Neuzeichnungen je Tastendruck
            self.pal = skins.desk_palette("petrol", "dunkel")
            self.o: dict = {}
            self.full = True
            self.btn = 64
            self.side = "left"
            self.dock: list[tuple[QRectF, str]] = []
            self.bar_btns: list[tuple[QRectF, str]] = []
            self.bar = QRectF()
            self.field = QRectF()
            self.dockbox = QRectF()
            self.favbox = QRectF()
            self.favs: list = []
            self._favitems: list = []
            self.surface = False                                     # Seifferts Oberfläche nutzt den Schreibtisch als Fläche: immer Ruhezustand statt Ausblenden
            self.resting = False                                     # Ruhezustand: als Hintergrund hinter allen Fenstern (Einstellung desk_resident)
            self.hot = ""                                            # Knopf unter der Maus ("cat:app", "switch", "close")
            self._bgc = None
            self._bgkey = None
            self.bg_note = ""
            self.edit.setStyleSheet("QLineEdit{background:transparent;border:0;font-size:19px;selection-background-color:#ffd479;selection-color:#0f1720;color:#fff}")
            self.clock = QTimer(self)
            self.clock.setInterval(15000)
            self.clock.timeout.connect(self._tick)
            self.apply_options()

        # ---- Einstellungen
        def apply_options(self) -> None:
            super().apply_options()
            o = self.f.opts()
            self.o = o
            self.depth = "off"
            self.pal = skins.desk_palette(self.f.b.cfg.get("skin", "petrol"), o.get("desk_scheme", "dunkel"))
            self.full = bool(o.get("desk_full", True))
            self.btn = max(32, min(128, int(o.get("desk_btn", 64))))
            self.side = "right" if o.get("desk_side") == "right" else "left"
            self.cap = 60
            self.autohide = self.autohide and not self._resident()      # als Hintergrund schließt er sich nie beim Wegklicken
            if hasattr(self, "edit"):
                pal = self.edit.palette()
                pal.setColor(QPalette.ColorRole.Text, QColor(self.pal["ink"]))
                pal.setColor(QPalette.ColorRole.PlaceholderText, QColor(self.pal["muted"]))
                self.edit.setPalette(pal)
                self.edit.setStyleSheet(self.edit.styleSheet().replace("color:#fff", "color:%s" % self.pal["ink"]))
            self._bgkey = None
            try:
                self._favitems = self.f.favapps("") if o.get("src_apps", True) else []
            except Exception:  # noqa: BLE001 - ohne Programmliste bleibt das Panel leer
                self._favitems = []
            self._geom()

        @staticmethod
        def wayland() -> bool:
            """Unter Wayland (zum Beispiel COSMIC) gibt es für Qt-Fenster kein "ganz unten": ein ruhender Schreibtisch würde über allen
            Fenstern liegen. Dort bleibt der Schreibtisch unsichtbar, bis man ihn ruft (Symbol der Oberfläche, Tastenkürzel)."""
            return QGuiApplication.platformName().startswith("wayland")

        def _resident(self) -> bool:
            if self.wayland():
                return False
            return self.surface or bool(self.f.opts().get("desk_resident", True))

        def _real_hide(self) -> None:
            QWidget.hide(self)

        def hide(self) -> None:
            """Schließen. Ist der Schreibtisch als Hintergrund eingestellt, geht er in den Ruhezustand (liegt hinter allen Fenstern), sonst verschwindet er."""
            if self._resident() and self.isVisible() and not self.resting:
                self.rest()
            else:
                self._real_hide()

        def rest(self) -> None:
            """Ruhezustand: Fenster in der Größe des nutzbaren Bildschirms (das Panel bleibt sichtbar), liegt ganz unten, nimmt keinen Fokus."""
            self.f.refresh()
            self.apply_options()
            scr = QGuiApplication.primaryScreen()
            self._real_hide()
            self.resting = True
            self.setWindowState(Qt.WindowState.WindowNoState)        # sonst bleibt das Vollbild von vorhin bestehen und das Fenster oben
            self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnBottomHint)
            g = scr.availableGeometry()
            if g == scr.geometry():
                g.setHeight(g.height() - 1)                      # ein Fenster über den ganzen Bildschirm behandelt z. B. openbox wie Vollbild und legt es nach oben
            self.setGeometry(g)
            self.edit.clear()
            self.msg = ""
            self.cat = "all"
            self._geom()
            self._run()
            self.show()
            self.lower()
            for ms in (60, 250, 800):                                # das Fenster ist erst nach dem Anzeigen wirklich da: danach noch einmal nach unten
                QTimer.singleShot(ms, lambda: self.lower() if self.resting and self.isVisible() else None)
            for ms in (120, 500):
                QTimer.singleShot(ms, lambda: send_below(int(self.winId())) if self.resting and self.isVisible() else None)
            self.clock.start()

        def summon(self) -> None:
            self.f.refresh()
            self.apply_options()
            scr = QGuiApplication.screenAt(QCursor.pos()) or QGuiApplication.primaryScreen()
            self._real_hide()                                        # Fensterart darf sich ändern: erst verstecken, dann neu zeigen
            self.resting = False
            self.setWindowState(Qt.WindowState.WindowNoState)
            if self.full:
                self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
                self.setGeometry(scr.geometry())
            else:
                self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Tool | Qt.WindowType.WindowStaysOnTopHint)
                g = scr.availableGeometry()
                w, h = max(820, int(g.width() * 0.86)), max(560, int(g.height() * 0.86))
                w, h = min(w, g.width()), min(h, g.height())
                self.setGeometry(g.x() + (g.width() - w) // 2, g.y() + (g.height() - h) // 2, w, h)
            self.edit.clear()
            self.msg = ""
            self.cat = "all"
            self._geom()
            self._run()
            if self.full:
                self.showFullScreen()
            else:
                self.show()
            self.raise_()
            self.activateWindow()
            self.edit.setFocus()
            self.clock.start()
            self._touch()

        def hideEvent(self, ev) -> None:  # noqa: N802
            self.clock.stop()
            super().hideEvent(ev)

        def _tick(self) -> None:
            if self.isVisible():
                self.update(self.bar.toAlignedRect().adjusted(-4, -4, 4, 4))

        def resizeEvent(self, ev) -> None:  # noqa: N802
            self._bgkey = None
            self._geom()
            if self.items:
                self._layout()
            super().resizeEvent(ev)

        # ---- Anordnung
        def _geom(self) -> None:
            w, h = self.width(), self.height()
            m = 16
            self.bar = QRectF(m, m, max(100, w - 2 * m), 52)
            n = max(1, len(self.cats))
            top = self.bar.bottom() + 16
            avail = max(80, h - top - BOTTOM - 6)
            pad = 10
            gap_ratio = 0.16
            s = float(self.btn)
            need = n * s + (n - 1) * s * gap_ratio + 2 * pad
            if need > avail:
                s = max(18.0, (avail - 2 * pad) / (n + (n - 1) * gap_ratio))
            gap = s * gap_ratio
            dw, dh = s + 2 * pad, n * s + (n - 1) * gap + 2 * pad
            x = m if self.side == "left" else w - m - dw
            y = top + max(0.0, (avail - dh) / 2)
            self.dockbox = QRectF(x, y, dw, dh)
            self.dock = []
            for i, (cid, _label) in enumerate(self.cats):
                self.dock.append((QRectF(x + pad, y + pad + i * (s + gap), s, s), cid))
            # Panel mit den Programm-Favoriten gegenüber (gleiche Knopfgröße, bei Platzmangel kleiner)
            self.favbox = QRectF()
            self.favs: list[tuple[QRectF, object]] = []
            if self.o.get("desk_favs", True):
                favs = list(getattr(self, "_favitems", []))
                k = max(1, len(favs))
                fs = s                                           # so groß wie die Sortenknöpfe (die bei Platzmangel schon kleiner sind)
                if k * fs + (k - 1) * fs * gap_ratio + 2 * pad > avail:
                    fs = max(18.0, (avail - 2 * pad) / (k + (k - 1) * gap_ratio))
                fg = fs * gap_ratio
                fw, fh = fs + 2 * pad, k * fs + (k - 1) * fg + 2 * pad
                fx = w - m - fw if self.side == "left" else m
                fy = top + max(0.0, (avail - fh) / 2)
                self.favbox = QRectF(fx, fy, fw, fh)
                for i, it in enumerate(favs):
                    self.favs.append((QRectF(fx + pad, fy + pad + i * (fs + fg), fs, fs), it))
            # Kopfleiste: Marke links, Uhr und Knöpfe rechts, das Suchfeld dazwischen
            bx = self.bar.right() - 12
            self.bar_btns = []
            for act, label in (("close", "Schließen  Esc"), ("switch", "Wolke  F2"), ("settings", "Einstellungen")):
                fm = QFontMetrics(self._pfont(12, True))
                bw = fm.horizontalAdvance(label) + 28
                self.bar_btns.append((QRectF(bx - bw, self.bar.y() + 9, bw, self.bar.height() - 18), act))
                bx -= bw + 8
            self._clock_x = bx - 120
            left = self.bar.x() + 16 + 28 + 10 + QFontMetrics(self._pfont(15, True)).horizontalAdvance("Seifferts Starter") + 22
            fx = left + 150
            fw = max(160.0, self._clock_x - 16 - fx)
            self.field = QRectF(fx, self.bar.y() + 8, fw, self.bar.height() - 16)
            self.edit.setGeometry(int(self.field.x() + 34), int(self.field.y() + 3), int(self.field.width() - 46), int(self.field.height() - 6))

        def _tile_size(self) -> tuple[int, int]:
            t = max(104, min(190, int(self.btn * 2.0)))
            return t, int(t * 1.12)

        def _grid_area(self) -> QRectF:
            m = 16
            w, h = self.width(), self.height()
            top = self.bar.bottom() + 16
            if self.side == "left":
                x0 = self.dockbox.right() + 22
                x1 = (self.favbox.left() - 22) if not self.favbox.isNull() else w - m
            else:
                x0 = (self.favbox.right() + 22) if not self.favbox.isNull() else m
                x1 = self.dockbox.left() - 22
            return QRectF(x0, top, max(60.0, x1 - x0), max(60.0, h - top - BOTTOM - 6))

        def _layout(self) -> None:
            area = self._grid_area()
            tw, th = self._tile_size()
            gap = 16
            cols = max(1, int((area.width() + gap) // (tw + gap)))
            rows = max(1, int((area.height() + gap) // (th + gap)))
            capacity = cols * rows
            if len(self.items) > capacity:
                self.items = self.items[:capacity]
                self.sel = min(self.sel, len(self.items) - 1)
            total = cols * tw + (cols - 1) * gap
            x0 = area.x() + max(0.0, (area.width() - total) / 2)
            rects = []
            for n in range(len(self.items)):
                r, c = divmod(n, cols)
                rects.append(QRectF(x0 + c * (tw + gap), area.y() + 4 + r * (th + gap), tw, th))
            self.flat = self.rects = rects
            self.order = list(range(len(rects)))
            self.alph = [1.0] * len(rects)
            self.chip_rects = []

        # ---- Mehr Tasten
        def _key(self, ev) -> bool:
            if ev.key() == Qt.Key.Key_F2:
                self.switch_design()
                return True
            return super()._key(ev)

        def mouseMoveEvent(self, ev) -> None:  # noqa: N802
            self._touch(1.4)
            p = ev.position()
            hot = ""
            for rc, cid in self.dock:
                if rc.contains(p):
                    hot = "cat:" + cid
            for rc, act in self.bar_btns:
                if rc.contains(p):
                    hot = act
            for i, (rc, _it) in enumerate(self.favs):
                if rc.contains(p):
                    hot = "fav:%d" % i
            if not self.favs and not self.favbox.isNull() and self.favbox.contains(p):
                hot = "fav:none"
            n = self._hit(p)
            if n >= 0 and n != self.sel:
                self.sel = n
                self.moved = True
                self.update()
            if hot != self.hot:
                self.hot = hot
                self.update()

        def mousePressEvent(self, ev) -> None:  # noqa: N802
            p = ev.position()
            for rc, cid in self.dock:
                if rc.contains(p):
                    self.set_cat(cid)
                    self.edit.setFocus()
                    return
            for rc, act in self.bar_btns:
                if rc.contains(p):
                    if act == "close":
                        self.hide()
                    elif act == "settings":
                        self.settings_menu(rc)
                    else:
                        self.switch_design("wolke")
                    return
            for i, (rc, it) in enumerate(self.favs):
                if rc.contains(p):
                    if ev.button() == Qt.MouseButton.RightButton:
                        self.fav_menu(it, ev.globalPosition().toPoint())
                    elif ev.button() == Qt.MouseButton.LeftButton:
                        self.launch_fav(it)
                    return
            n = self._hit(p)
            if n >= 0 and ev.button() == Qt.MouseButton.RightButton:
                self.sel = n
                self.update()
                self.tile_menu(n, ev.globalPosition().toPoint())
                return
            if ev.button() != Qt.MouseButton.LeftButton:
                return
            if n >= 0:
                self.activate(alt=bool(ev.modifiers() & Qt.KeyboardModifier.ControlModifier), index=n)

        # ---- Menüs
        def _exec_menu(self, menu, pos: QPoint):
            self._menu_open = True                                    # sonst würde das Wegklick-Schließen beim Öffnen des Menüs zuschlagen
            try:
                return menu.exec(pos)
            finally:
                self._menu_open = False
                self.edit.setFocus()

        def tile_menu(self, n: int, pos: QPoint) -> None:
            """Rechtsklick auf eine Kachel: öffnen, bei Programmen auch als Favorit merken oder entfernen."""
            it = self.items[n]
            m = QMenu(self)
            a_open = m.addAction("Öffnen")
            a_fav = None
            if it.kind == "app":
                a_fav = m.addAction("Aus den Favoriten entfernen" if it.extra.get("favapp") else "Zu den Favoriten hinzufügen")
            got = self._exec_menu(m, pos)
            if got is None:
                return
            if got is a_open:
                self.activate(index=n)
            elif got is a_fav:
                self.toggle_favorite(n)

        def launch_fav(self, it) -> None:
            """Programm aus dem Favoriten-Panel starten."""
            try:
                self.b.call("launch_app", {"app_id": it.key})
                self.f.bump("app", it.key)
            except B.AppError as e:
                self.msg = str(e)
                self.update()
                return
            self.hide()

        def _panels(self) -> None:
            """Sortenknöpfe und Favoriten als Panels der Desktopumgebung anlegen (seiffert-panel create)."""
            self.msg = "Die Panels werden angelegt (MATE, LXDE oder LXQt). Mehr im Terminal: seiffert-panel status." if SX.create_panels() else \
                "seiffert-panel ist nicht installiert (./install.sh ausführen)."
            self.update()

        def fav_menu(self, it, pos: QPoint) -> None:
            m = QMenu(self)
            a_run = m.addAction("Starten")
            a_del = m.addAction("Aus den Favoriten entfernen")
            got = self._exec_menu(m, pos)
            if got is a_run:
                self.launch_fav(it)
            elif got is a_del:
                ids = [x for x in self.f.fav_ids() if x != it.key]
                self.set_opts({"app_favs": ids})
                self.msg = "%s ist kein Favorit mehr." % it.title
                if self.cat == "favapp":
                    self._run()
                self.update()

        def settings_menu(self, rc: QRectF) -> None:
            """Menü Einstellungen: häufige Wünsche direkt, alles Weitere im Dialog von Seifferts Dateien."""
            o = self.f.opts()
            m = QMenu(self)
            acts: dict = {}

            def add(menu, text, fn, checked=None, enabled=True):
                a = menu.addAction(text)
                if checked is not None:
                    a.setCheckable(True)
                    a.setChecked(bool(checked))
                a.setEnabled(enabled)
                acts[a] = fn
                return a

            add(m, "Favoriten zeigen", lambda: self.set_cat("favapp"), enabled=any(c == "favapp" for c, _ in self.cats))
            sel_app = bool(self.items) and self.sel < len(self.items) and self.items[self.sel].kind == "app"
            add(m, "Markiertes Programm als Favorit ein oder aus   Strg+D", lambda: self.toggle_favorite(), enabled=sel_app)
            m.addSeparator()
            sm = m.addMenu("Farbschema")
            for s in skins.DESK_SCHEMES:
                add(sm, skins.DESK_LABELS.get(s, s), lambda s=s: self._opt({"desk_scheme": s}), checked=o.get("desk_scheme") == s)
            bm = m.addMenu("Hintergrund")
            add(bm, "Aus dem Farbschema", lambda: self._opt({"desk_bg": "schema"}), checked=o.get("desk_bg") == "schema")
            add(bm, "Einfarbig", lambda: self._opt({"desk_bg": "farbe"}), checked=o.get("desk_bg") == "farbe")
            add(bm, "Eigenes Bild (gewählt unter Alle Einstellungen)", lambda: self._opt({"desk_bg": "bild"}), checked=o.get("desk_bg") == "bild", enabled=bool(o.get("desk_bg_image")))
            km = m.addMenu("Knöpfe an der Seite")
            add(km, "Auf die andere Seite" , lambda: self._opt({"desk_side": "right" if o.get("desk_side") == "left" else "left"}))
            add(km, "Größer", lambda: self._opt({"desk_btn": min(128, int(o.get("desk_btn", 64)) + 8)}), enabled=int(o.get("desk_btn", 64)) < 128)
            add(km, "Kleiner", lambda: self._opt({"desk_btn": max(32, int(o.get("desk_btn", 64)) - 8)}), enabled=int(o.get("desk_btn", 64)) > 32)
            add(m, "Panel mit Favoriten", lambda: self._opt({"desk_favs": not o.get("desk_favs", True)}), checked=o.get("desk_favs", True))
            add(m, "Vollbild", lambda: self._opt({"desk_full": not o.get("desk_full", True)}, resummon=True), checked=o.get("desk_full", True))
            add(m, "Dauer-Schreibtisch (liegt hinter allen Fenstern)", lambda: self._opt({"desk_resident": not o.get("desk_resident", True)}), checked=o.get("desk_resident", True))
            m.addSeparator()
            add(m, "Starter-Design: Wolke", lambda: self.switch_design("wolke"))
            add(m, "Panels der Desktopumgebung anlegen oder aktualisieren", lambda: self._panels(), enabled=SX.panel_cmd() is not None)
            add(m, "Alle Einstellungen …", lambda: self.open_settings("starter"))
            got = self._exec_menu(m, self.mapToGlobal(QPoint(int(rc.left()), int(rc.bottom()) + 4)))
            if got is not None and got in acts:
                acts[got]()

        def _opt(self, opts: dict, resummon: bool = False) -> None:
            self.set_opts(opts)
            self._bgkey = None
            if resummon and self.isVisible() and not self.resting:
                QTimer.singleShot(300, self.summon)                  # Fenstertyp (Vollbild oder Fenster) wird beim Erscheinen gesetzt
                return
            self._geom()
            self._layout()
            self.update()

        def _hit(self, pos) -> int:
            for n, r in enumerate(self.rects):
                if r.contains(pos):
                    return n
            return -1

        # ---- Zeichnen: Hintergrund
        def _pfont(self, px: int, bold: bool = False) -> QFont:
            f = QFont(self.font())
            f.setPixelSize(px)
            f.setBold(bold)
            return f

        def _background(self, w: int, h: int, dev: float) -> QPixmap:
            o, pal = self.o, self.pal
            img = str(o.get("desk_bg_image") or "")
            try:
                stamp = os.path.getmtime(img) if o.get("desk_bg") == "bild" and img else 0
            except OSError:
                stamp = -1
            key = (w, h, dev, pal["scheme"], pal["accent"], o.get("desk_bg"), img, stamp, o.get("desk_bg_color"), o.get("desk_bg_dim"), self.full)
            if self._bgkey == key and self._bgc is not None:
                return self._bgc
            pm = QPixmap(int(w * dev), int(h * dev))
            pm.setDevicePixelRatio(dev)
            pm.fill(Qt.GlobalColor.transparent)
            q = QPainter(pm)
            q.setRenderHint(QPainter.RenderHint.Antialiasing)
            q.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
            clip = QPainterPath()
            clip.addRoundedRect(QRectF(0, 0, w, h), 0 if self.full else 18, 0 if self.full else 18)
            q.setClipPath(clip)
            self.bg_note = ""
            mode = o.get("desk_bg", "schema")
            done = False
            if mode == "bild":
                src = QPixmap(img) if img else QPixmap()
                if src.isNull():
                    self.bg_note = "Das Hintergrundbild ließ sich nicht laden; es gilt der Hintergrund des Farbschemas."
                else:
                    sc = src.scaled(int(w * dev), int(h * dev), Qt.AspectRatioMode.KeepAspectRatioByExpanding, Qt.TransformationMode.SmoothTransformation)
                    q.drawPixmap(QPointF((w - sc.width() / dev) / 2, (h - sc.height() / dev) / 2), sc)
                    q.fillRect(QRectF(0, 0, w, h), qc("#000000", int(255 * int(o.get("desk_bg_dim", 35)) / 100)))
                    done = True
            elif mode == "farbe":
                c = QColor(str(o.get("desk_bg_color") or "#0b0f14"))
                q.fillRect(QRectF(0, 0, w, h), c)
                vg = QRadialGradient(QPointF(w / 2, h / 2), max(w, h) * 0.75)
                vg.setColorAt(0.55, qc("#000000", 0))
                vg.setColorAt(1.0, qc("#000000", 110))
                q.fillRect(QRectF(0, 0, w, h), vg)
                done = True
            if not done:
                self._scheme_background(q, w, h)
            q.setClipping(False)
            if not self.full:
                q.setBrush(Qt.BrushStyle.NoBrush)
                q.setPen(QPen(qc(pal["rim_hi"], 120), 1.2))
                q.drawRoundedRect(QRectF(0.6, 0.6, w - 1.2, h - 1.2), 18, 18)
            q.end()
            self._bgc, self._bgkey = pm, key
            return pm

        def _scheme_background(self, q: QPainter, w: int, h: int) -> None:
            pal = self.pal
            g = QLinearGradient(0, 0, w * 0.35, h)
            g.setColorAt(0.0, QColor(pal["bg0"]))
            g.setColorAt(1.0, QColor(pal["bg1"]))
            q.fillRect(QRectF(0, 0, w, h), g)
            if pal["metal"]:
                # gebürsteter Stahl: feine waagerechte Striche und ein breiter heller Streifen
                for y in range(0, h, 3):
                    a = 5 + (y * 7919 % 11)
                    q.fillRect(QRectF(0, y, w, 1), qc("#ffffff" if (y // 3) % 2 else "#000000", a))
                sheen = QLinearGradient(0, h * 0.1, w, h * 0.6)
                sheen.setColorAt(0.0, qc("#ffffff", 0))
                sheen.setColorAt(0.42, qc("#ffffff", 0))
                sheen.setColorAt(0.5, qc("#ffffff", 26))
                sheen.setColorAt(0.58, qc("#ffffff", 0))
                sheen.setColorAt(1.0, qc("#ffffff", 0))
                q.fillRect(QRectF(0, 0, w, h), sheen)
                return
            if pal["wave"] <= 0:
                return
            acc = QColor(pal["accent"])
            strength = pal["wave"]
            # Leuchtbänder wie Wellen: je ein Band aus mehreren übereinanderliegenden, immer dünneren Strichen (weicher Schein)
            specs = ((0.78, 0.62, 0.96, 1.00), (0.70, 0.52, 0.88, 0.80), (0.36, 0.12, 0.60, 0.55))
            for k, (y0, y1, y2, wgt) in enumerate(specs):
                path = QPainterPath(QPointF(-40, h * y0))
                path.cubicTo(QPointF(w * 0.28, h * (y0 + 0.30 * (y1 - y0) - 0.30)), QPointF(w * 0.46, h * (y1 + 0.28)), QPointF(w * 0.64, h * y1))
                path.cubicTo(QPointF(w * 0.80, h * (y1 - 0.15)), QPointF(w * 0.90, h * (y2 - 0.30)), QPointF(w + 40, h * (y2 - 0.40 + 0.04 * k)))
                for width, al in ((44, 7), (30, 11), (20, 17), (12, 28), (6, 52), (2.4, 120), (1.0, 210)):
                    c = QColor(acc)
                    c.setAlpha(int(min(255, al * strength * wgt)))
                    lg = QLinearGradient(0, 0, w, 0)
                    c0 = QColor(c)
                    c0.setAlpha(0)
                    lg.setColorAt(0.0, c0)
                    lg.setColorAt(0.35, c)
                    lg.setColorAt(0.8, c)
                    lg.setColorAt(1.0, c0)
                    pen = QPen(lg, width * (1.0 if k < 2 else 0.6))
                    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
                    q.setPen(pen)
                    q.setBrush(Qt.BrushStyle.NoBrush)
                    q.drawPath(path)

        # ---- Zeichnen: Teile
        def paintEvent(self, ev) -> None:  # noqa: N802
            p = QPainter(self)
            p.setRenderHint(QPainter.RenderHint.Antialiasing)
            p.setRenderHint(QPainter.RenderHint.TextAntialiasing)
            p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
            dev = float(self.devicePixelRatioF())
            p.drawPixmap(0, 0, self._background(self.width(), self.height(), dev))
            clip = QRectF(ev.rect()).adjusted(-24, -24, 24, 24)       # nur zeichnen, was vom Neuzeichnen betroffen ist (Schatten und Leuchten reichen darüber hinaus)
            if clip.intersects(self.bar.adjusted(-6, -6, 6, 6)):
                self._paint_bar(p)
            if clip.intersects(self.dockbox) or (not self.favbox.isNull() and clip.intersects(self.favbox)) or self.hot.startswith(("cat:", "fav:")):
                self._paint_dock(p)
                self._paint_favs(p)
            for n in range(len(self.items)):
                if clip.intersects(self.rects[n]):
                    self._tile(p, n)
            if not self.items:
                self._empty(p)
            self._paint_detail(p)

        def _plate(self, p: QPainter, rc: QRectF, radius: float, selected: bool = False, hot: bool = False, kind: str = "") -> None:
            """Fläche eines Knopfes oder einer Kachel im Stil des Farbschemas."""
            pal = self.pal
            accent = QColor(pal["accent"])
            p.setPen(Qt.PenStyle.NoPen)
            if pal["metal"]:
                g = QLinearGradient(rc.topLeft(), rc.bottomLeft())
                g.setColorAt(0.0, QColor(pal["tile_hi"]) if (selected or hot) else QColor(pal["tile"]))
                g.setColorAt(1.0, QColor(pal["tile_lo"]))
                p.setBrush(qc("#000000", 90))
                p.drawRoundedRect(rc.translated(0, 3), radius, radius)
                p.setBrush(g)
                p.drawRoundedRect(rc, radius, radius)
                rim = QLinearGradient(rc.topLeft(), rc.bottomRight())
                rim.setColorAt(0.0, QColor(pal["rim_hi"]))
                rim.setColorAt(0.5, QColor(pal["rim_lo"]))
                rim.setColorAt(1.0, QColor(pal["rim_hi"]))
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.setPen(QPen(accent if selected else rim, 2.4 if selected else 1.6))
                p.drawRoundedRect(rc.adjusted(0.8, 0.8, -0.8, -0.8), radius, radius)
                gl = QLinearGradient(rc.topLeft(), QPointF(rc.left(), rc.top() + rc.height() * 0.45))
                gl.setColorAt(0.0, qc("#ffffff", 46))
                gl.setColorAt(1.0, qc("#ffffff", 0))
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(gl)
                p.drawRoundedRect(rc.adjusted(2, 2, -2, -rc.height() * 0.5), radius - 2, radius - 2)
                return
            if pal["neon"]:
                glow = selected or hot
                if glow:
                    for k, al in ((16, 22), (10, 40), (5, 70)):
                        c = QColor(accent)
                        c.setAlpha(al)
                        p.setPen(QPen(c, k))
                        p.setBrush(Qt.BrushStyle.NoBrush)
                        p.drawRoundedRect(rc, radius, radius)
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QColor(pal["tile_hi"]) if glow else QColor(pal["tile"]))
                p.drawRoundedRect(rc, radius, radius)
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.setPen(QPen(accent if glow else QColor(pal["rim_lo"]), 2.0 if glow else 1.2))
                p.drawRoundedRect(rc.adjusted(0.6, 0.6, -0.6, -0.6), radius, radius)
                return
            if selected or hot:
                p.setBrush(qc(pal["accent"], 40))
                p.drawRoundedRect(rc.adjusted(-4, -4, 4, 4), radius + 3, radius + 3)
            g = QLinearGradient(rc.topLeft(), rc.bottomLeft())
            g.setColorAt(0.0, QColor(pal["tile_hi"]) if (selected or hot) else QColor(pal["tile"]))
            g.setColorAt(1.0, QColor(pal["tile_lo"]) if not (selected or hot) else QColor(pal["tile"]))
            p.setBrush(g)
            p.drawRoundedRect(rc, radius, radius)
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.setPen(QPen(accent if selected else QColor(pal["rim_lo"]) if not hot else QColor(pal["rim_hi"]), 2.0 if selected else 1.0))
            p.drawRoundedRect(rc.adjusted(0.5, 0.5, -0.5, -0.5), radius, radius)

        def _paint_bar(self, p: QPainter) -> None:
            pal = self.pal
            bar = self.bar
            self._plate(p, bar, 16)
            # Marke
            logo = QRectF(bar.x() + 14, bar.y() + 11, 30, bar.height() - 22)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(pal["accent"]))
            p.drawRoundedRect(logo, 8, 8)
            p.setPen(QColor(pal["accent_ink"]))
            p.setFont(self._pfont(16, True))
            p.drawText(logo, Qt.AlignmentFlag.AlignCenter, "S")
            p.setPen(QColor(pal["ink"]))
            p.setFont(self._pfont(15, True))
            tx = logo.right() + 10
            p.drawText(QRectF(tx, bar.y(), 190, bar.height()), int(Qt.AlignmentFlag.AlignVCenter), "Seifferts Starter")
            lab = dict(self.cats).get(self.cat, "")
            if self.cat != "all":
                p.setPen(QColor(pal["muted"]))
                p.setFont(self._pfont(13))
                p.drawText(QRectF(self.field.x() - 120, bar.y(), 110, bar.height()), int(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight), lab)
            # Suchfeld
            fr = self.field
            p.setPen(QPen(qc(pal["rim_lo"] if not pal["neon"] else pal["accent"], 200 if not pal["neon"] else 120), 1.0))
            p.setBrush(qc("#000000", 70))
            p.drawRoundedRect(fr, fr.height() / 2, fr.height() / 2)
            cx, cy, r = fr.x() + 18, fr.center().y() - 1, 5.5
            p.setPen(QPen(QColor(pal["muted"]), 1.8))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawEllipse(QPointF(cx, cy), r, r)
            p.drawLine(QPointF(cx + r * 0.72, cy + r * 0.72), QPointF(cx + r * 1.5, cy + r * 1.5))
            # Datum und Uhr
            t = time.localtime()
            p.setPen(QColor(pal["muted"]))
            p.setFont(self._pfont(13))
            p.drawText(QRectF(self._clock_x - 60, bar.y(), 118, bar.height()), int(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight),
                       "%s %d. %s" % (WEEKDAYS[t.tm_wday], t.tm_mday, MONTHS[t.tm_mon - 1]))
            p.setPen(QColor(pal["ink"]))
            p.setFont(self._pfont(16, True))
            p.drawText(QRectF(self._clock_x + 64, bar.y(), 66, bar.height()), int(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft), "%02d:%02d" % (t.tm_hour, t.tm_min))
            # Knöpfe rechts
            for rc, act in self.bar_btns:
                hot = self.hot == act
                primary = act == "close"
                p.setPen(Qt.PenStyle.NoPen)
                if primary:
                    p.setBrush(QColor(pal["accent"]) if not hot else QColor(mixc(QColor(pal["accent"]), QColor("#ffffff"), 0.2)))
                else:
                    p.setBrush(qc(pal["tile_hi"] if hot else pal["tile"], 255))
                p.drawRoundedRect(rc, rc.height() / 2, rc.height() / 2)
                if not primary:
                    p.setBrush(Qt.BrushStyle.NoBrush)
                    p.setPen(QPen(qc(pal["rim_lo"] if not hot else pal["accent"], 255), 1.0))
                    p.drawRoundedRect(rc.adjusted(0.5, 0.5, -0.5, -0.5), rc.height() / 2, rc.height() / 2)
                p.setPen(QColor(pal["accent_ink"]) if primary else QColor(pal["ink"]))
                p.setFont(self._pfont(12, True))
                p.drawText(rc, Qt.AlignmentFlag.AlignCenter, {"close": "Schließen  Esc", "switch": "Wolke  F2"}.get(act, "Einstellungen"))

        def _paint_dock(self, p: QPainter) -> None:
            pal = self.pal
            self._plate(p, self.dockbox, 18)
            for rc, cid in self.dock:
                on = cid == self.cat
                hot = self.hot == "cat:" + cid
                if on:
                    if pal["neon"]:
                        for k, al in ((14, 26), (8, 50)):
                            p.setPen(QPen(qc(pal["accent"], al), k))
                            p.setBrush(Qt.BrushStyle.NoBrush)
                            p.drawRoundedRect(rc, rc.width() * 0.24, rc.width() * 0.24)
                    p.setPen(Qt.PenStyle.NoPen)
                    p.setBrush(QColor(pal["accent"]))
                    p.drawRoundedRect(rc, rc.width() * 0.24, rc.width() * 0.24)
                else:
                    self._plate(p, rc, rc.width() * 0.24, hot=hot)
                self._glyph(p, cid, rc, QColor(pal["accent_ink"]) if on else QColor(pal["accent"] if not pal["metal"] else pal["ink"]))
            if self.hot.startswith("cat:"):                          # Name des Knopfes unter der Maus, daneben
                for rc, cid in self.dock:
                    if self.hot == "cat:" + cid:
                        name = dict(self.cats).get(cid, "")
                        f = self._pfont(13, True)
                        fm = QFontMetrics(f)
                        wd = fm.horizontalAdvance(name) + 24
                        x = rc.right() + 14 if self.side == "left" else rc.left() - 14 - wd
                        tip = QRectF(x, rc.center().y() - 15, wd, 30)
                        self._plate(p, tip, 10)
                        p.setPen(QColor(pal["ink"]))
                        p.setFont(f)
                        p.drawText(tip, Qt.AlignmentFlag.AlignCenter, name)

        def _paint_favs(self, p: QPainter) -> None:
            """Panel mit den Programm-Favoriten: ein Klick startet das Programm, Rechtsklick öffnet ein Menü."""
            if self.favbox.isNull():
                return
            pal = self.pal
            self._plate(p, self.favbox, 18)
            if not self.favs:
                rc = QRectF(self.favbox.x() + 10, self.favbox.y() + 10, self.favbox.width() - 20, self.favbox.width() - 20)
                self._glyph(p, "favapp", rc, QColor(pal["muted"]))
            for i, (rc, it) in enumerate(self.favs):
                hot = self.hot == "fav:%d" % i
                self._plate(p, rc, rc.width() * 0.24, hot=hot)
                side = int(rc.width() * 0.62)
                pm = self._mark(it, side, False)
                if pm:
                    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
                    p.drawPixmap(QRectF(rc.center().x() - side / 2, rc.center().y() - side / 2, side, side).toRect(), pm)
                else:
                    p.setPen(QColor(pal["accent"]))
                    p.setFont(self._pfont(max(10, int(rc.width() * 0.4)), True))
                    p.drawText(rc, Qt.AlignmentFlag.AlignCenter, (it.title[:1] or "?").upper())
            if self.hot.startswith("fav:"):                          # Name des Programms unter der Maus, daneben (zur Mitte hin)
                if self.hot == "fav:none":
                    name, rc = "Noch keine Favoriten: Rechtsklick auf ein Programm", self.favbox
                else:
                    i = int(self.hot[4:])
                    if i >= len(self.favs):
                        return
                    rc, it = self.favs[i]
                    name = it.title
                f = self._pfont(13, True)
                wd = QFontMetrics(f).horizontalAdvance(name) + 24
                x = rc.left() - 14 - wd if self.side == "left" else rc.right() + 14
                tip = QRectF(x, rc.center().y() - 15, wd, 30)
                self._plate(p, tip, 10)
                p.setPen(QColor(pal["ink"]))
                p.setFont(f)
                p.drawText(tip, Qt.AlignmentFlag.AlignCenter, name)

        def _glyph(self, p: QPainter, cid: str, rc: QRectF, color: QColor) -> None:
            """Einfache Linienzeichen für die Sorten (keine Datei nötig)."""
            s = rc.width()
            c = rc.center()
            u = s * 0.30                                              # halbe Zeichenfläche
            pen = QPen(color, max(1.6, s * 0.07))
            pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
            p.setPen(pen)
            p.setBrush(Qt.BrushStyle.NoBrush)
            if cid == "all":
                for dx in (-1, 1):
                    for dy in (-1, 1):
                        p.drawRoundedRect(QRectF(c.x() + dx * u * 0.52 - u * 0.4, c.y() + dy * u * 0.52 - u * 0.4, u * 0.8, u * 0.8), u * 0.18, u * 0.18)
            elif cid == "favapp":
                pts = []
                for k in range(10):
                    r = u * (1.05 if k % 2 == 0 else 0.46)
                    a = -math.pi / 2 + k * math.pi / 5
                    pts.append(QPointF(c.x() + r * math.cos(a), c.y() + 0.05 * u + r * math.sin(a)))
                p.drawPolygon(pts)
            elif cid == "app":
                p.drawRoundedRect(QRectF(c.x() - u, c.y() - u * 0.8, u * 2, u * 1.6), u * 0.22, u * 0.22)
                p.drawLine(QPointF(c.x() - u, c.y() - u * 0.28), QPointF(c.x() + u, c.y() - u * 0.28))
                p.drawPoint(QPointF(c.x() - u * 0.62, c.y() - u * 0.54))
            elif cid == "file":
                path = QPainterPath(QPointF(c.x() - u * 0.7, c.y() - u))
                path.lineTo(c.x() + u * 0.2, c.y() - u)
                path.lineTo(c.x() + u * 0.7, c.y() - u * 0.5)
                path.lineTo(c.x() + u * 0.7, c.y() + u)
                path.lineTo(c.x() - u * 0.7, c.y() + u)
                path.closeSubpath()
                p.drawPath(path)
                for k in (0.05, 0.42):
                    p.drawLine(QPointF(c.x() - u * 0.38, c.y() + u * k), QPointF(c.x() + u * 0.38, c.y() + u * k))
            elif cid == "folder":
                path = QPainterPath(QPointF(c.x() - u, c.y() - u * 0.6))
                path.lineTo(c.x() - u * 0.25, c.y() - u * 0.6)
                path.lineTo(c.x() + u * 0.05, c.y() - u * 0.3)
                path.lineTo(c.x() + u, c.y() - u * 0.3)
                path.lineTo(c.x() + u, c.y() + u * 0.7)
                path.lineTo(c.x() - u, c.y() + u * 0.7)
                path.closeSubpath()
                p.drawPath(path)
            elif cid == "text":
                p.drawEllipse(QPointF(c.x() - u * 0.15, c.y() - u * 0.15), u * 0.62, u * 0.62)
                p.drawLine(QPointF(c.x() + u * 0.3, c.y() + u * 0.3), QPointF(c.x() + u * 0.95, c.y() + u * 0.95))
                p.drawLine(QPointF(c.x() - u * 0.42, c.y() - u * 0.15), QPointF(c.x() + u * 0.12, c.y() - u * 0.15))
            elif cid == "command":
                p.drawRoundedRect(QRectF(c.x() - u, c.y() - u * 0.8, u * 2, u * 1.6), u * 0.22, u * 0.22)
                p.drawPolyline([QPointF(c.x() - u * 0.55, c.y() - u * 0.3), QPointF(c.x() - u * 0.1, c.y()), QPointF(c.x() - u * 0.55, c.y() + u * 0.3)])
                p.drawLine(QPointF(c.x() + u * 0.05, c.y() + u * 0.32), QPointF(c.x() + u * 0.5, c.y() + u * 0.32))
            elif cid == "clip":
                p.drawRoundedRect(QRectF(c.x() - u * 0.78, c.y() - u * 0.85, u * 1.56, u * 1.95), u * 0.2, u * 0.2)
                p.drawRoundedRect(QRectF(c.x() - u * 0.34, c.y() - u * 1.08, u * 0.68, u * 0.42), u * 0.12, u * 0.12)
                for k in (-0.05, 0.38):
                    p.drawLine(QPointF(c.x() - u * 0.4, c.y() + u * k), QPointF(c.x() + u * 0.4, c.y() + u * k))
            elif cid == "system":
                p.drawArc(QRectF(c.x() - u * 0.85, c.y() - u * 0.78, u * 1.7, u * 1.7), 120 * 16, -300 * 16)
                p.drawLine(QPointF(c.x(), c.y() - u * 1.0), QPointF(c.x(), c.y() - u * 0.1))
            else:
                p.drawEllipse(c, u * 0.5, u * 0.5)

        def _tone_color(self, kind: str) -> QColor:
            if self.pal["neon"] and kind in NEON:
                return QColor(NEON[kind])
            if kind in METAL:
                return QColor(METAL[kind][0] if self.pal["metal"] else METAL[kind][1])
            return QColor(self.pal["accent"])

        def _tile(self, p: QPainter, n: int) -> None:
            it, rc, pal = self.items[n], self.rects[n], self.pal
            sel = n == self.sel
            self._plate(p, rc, 18, selected=sel, kind=it.kind)
            side = int(rc.width() * 0.42)
            pm = self._mark(it, side, False)
            icy = rc.y() + rc.height() * 0.10
            ir = QRectF(rc.center().x() - side / 2, icy, side, side)
            if pm:
                p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
                if it.kind in ("system", "command", "clip"):          # diese Symbole sind für helle Grund gezeichnet: helle Platte darunter
                    pr = ir.adjusted(-5, -5, 5, 5)
                    p.setPen(Qt.PenStyle.NoPen)
                    pg = QLinearGradient(pr.topLeft(), pr.bottomLeft())
                    pg.setColorAt(0.0, QColor("#ffffff"))
                    pg.setColorAt(1.0, QColor("#c9d2db"))
                    p.setBrush(pg)
                    p.drawRoundedRect(pr, side * 0.24, side * 0.24)
                p.drawPixmap(ir, pm, QRectF(pm.rect()))
            else:
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(self._tone_color(it.kind))
                p.drawRoundedRect(ir, side * 0.26, side * 0.26)
                p.setPen(QColor(pal["accent_ink"]))
                p.setFont(self._pfont(int(side * 0.5), True))
                p.drawText(ir, Qt.AlignmentFlag.AlignCenter, (it.title[:1] or "?").upper())
            f = self._pfont(13, True)
            fm = QFontMetrics(f)
            lines = wrap(it.title, fm, int(rc.width() - 16), 2)
            p.setFont(f)
            p.setPen(QColor(pal["ink"]))
            y = ir.bottom() + 8
            for ln in lines:
                p.drawText(QRectF(rc.x() + 8, y, rc.width() - 16, fm.lineSpacing()), Qt.AlignmentFlag.AlignCenter, ln)
                y += fm.lineSpacing()
            f2 = self._pfont(10, True)
            f2.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 1.2)
            p.setFont(f2)
            lab = (KIND_LABEL[it.kind] + ("  ★" if it.extra.get("fav") or it.extra.get("favapp") else "")).upper()
            p.setPen(self._tone_color(it.kind) if not pal["metal"] else QColor(pal["muted"]))
            p.drawText(QRectF(rc.x() + 6, rc.bottom() - 22, rc.width() - 12, 16), Qt.AlignmentFlag.AlignCenter, lab)

        def _empty(self, p: QPainter) -> None:
            area = self._grid_area()
            p.setPen(QColor(self.pal["muted"]))
            p.setFont(self._pfont(16))
            txt = "Nichts gefunden." if self.edit.text().strip() else "Tippe, um zu suchen. Die Knöpfe an der Seite wählen die Sorte."
            p.drawText(QRectF(area.x(), area.y() + 30, area.width(), 40), Qt.AlignmentFlag.AlignCenter, txt)

        def _paint_detail(self, p: QPainter) -> None:
            pal = self.pal
            r = QRectF(16, self.height() - BOTTOM + 4, self.width() - 32, BOTTOM - 20)
            self._plate(p, r, 14)
            inner = r.adjusted(18, 4, -18, -4)
            if self.armed and not (self.items and self.items[self.sel].key == self.armed[0]):
                self.armed = None
                self.msg = ""
            note = self.msg or self.bg_note
            if note:
                p.setPen(QColor(pal["warn"]))
                p.setFont(self._pfont(14))
                p.drawText(inner, int(Qt.AlignmentFlag.AlignVCenter) | int(Qt.TextFlag.TextWordWrap), note)
                return
            if not self.items:
                p.setPen(QColor(pal["muted"]))
                p.setFont(self._pfont(14))
                p.drawText(inner, Qt.AlignmentFlag.AlignVCenter, "Pfeiltasten wählen, Enter öffnet, Tab wechselt die Sorte, Strg+D Favorit, F2 Wolke, Esc schließt.")
                return
            it = self.items[self.sel]
            p.setFont(self._pfont(15, True))
            fm = QFontMetrics(p.font())
            p.setPen(QColor(pal["ink"]))
            p.drawText(QRectF(inner.x(), inner.y(), inner.width(), 20), Qt.AlignmentFlag.AlignVCenter, fm.elidedText(it.title, Qt.TextElideMode.ElideRight, int(inner.width())))
            hint = {"system": "Enter führt den Befehl aus (vorher wird nachgefragt)", "app": "Enter startet das Programm", "folder": "Enter öffnet den Ordner in Seifferts Dateien",
                    "file": "Enter öffnet die Datei, Strg+Enter zeigt ihren Ordner", "text": "Enter öffnet die Datei, Strg+Enter zeigt ihren Ordner",
                    "command": "Enter führt den Befehl aus, Strg+Enter im Terminal", "clip": "Enter legt den Text wieder in die Zwischenablage"}[it.kind]
            home = os.path.expanduser("~")
            sub = ("~" + it.sub[len(home):]) if it.sub == home or it.sub.startswith(home + "/") else it.sub
            second = (it.snippet.strip().replace("\n", " ") if it.snippet else (sub or "")) or hint
            p.setFont(self._pfont(12))
            fm = QFontMetrics(p.font())
            p.setPen(QColor(pal["muted"]))
            p.drawText(QRectF(inner.x(), inner.y() + 21, inner.width(), 18), Qt.AlignmentFlag.AlignVCenter, fm.elidedText(second, Qt.TextElideMode.ElideMiddle, int(inner.width())))

    return Desk
