"""Tabellen (xlsx, xlsm, ods) laden und formaterhaltend speichern.

Wie bei odt_patch.py wird die Datei nicht neu erzeugt. Geändert werden nur die Bytes der bearbeiteten
Zellen im XML des jeweiligen Blatts; Formate, Spaltenbreiten, Diagramme, Bilder und alles Übrige
bleiben unverändert. Gespeicherte Formelergebnisse werden entfernt, damit Excel und LibreOffice
beim Öffnen neu rechnen.
"""
import datetime
import io
import os
import re
import shutil
import zipfile
from xml.parsers import expat
from xml.sax.saxutils import escape, quoteattr
import xml.etree.ElementTree as ET

from .readers import fmt_cell

_TAG = re.compile(rb'''(?:[^>"']|"[^"]*"|'[^']*')*>''')
_NUM = re.compile(r"^[+-]?(?:\d{1,3}(?:\.\d{3})+|\d+)(?:,\d+)?\s*(%?)$")
_NUM_EN = re.compile(r"^[+-]?\d+\.\d+$")
_DATE = re.compile(r"^(\d{1,2})\.(\d{1,2})\.(\d{4})$")
_REF = re.compile(r"^\$?([A-Za-z]{1,3})\$?(\d+)$")

NS_T = "urn:oasis:names:tc:opendocument:xmlns:table:1.0"
NS_O = "urn:oasis:names:tc:opendocument:xmlns:office:1.0"
NS_X = "urn:oasis:names:tc:opendocument:xmlns:text:1.0"
NS_C = "urn:org:documentfoundation:names:experimental:calc:xmlns:calcext:1.0"
MAX_SHOW_ROWS = 20000
MAX_SHOW_COLS = 500


class SheetError(Exception):
    pass


class Cell:
    __slots__ = ("text", "input", "formula", "bold", "right", "isdate", "kind")

    def __init__(self, text="", input="", formula=False, bold=False, right=False, isdate=False, kind=""):
        self.text, self.input, self.formula = text, input, formula
        self.bold, self.right, self.isdate, self.kind = bold, right, isdate, kind


class Sheet:
    def __init__(self, name):
        self.name = name
        self.cells = {}
        self.merges = []
        self.nrows = 0
        self.ncols = 0


def col_name(c):
    s = ""
    c += 1
    while c:
        c, r = divmod(c - 1, 26)
        s = chr(65 + r) + s
    return s


def col_index(name):
    n = 0
    for ch in name.upper():
        n = n * 26 + ord(ch) - 64
    return n - 1


def de_num(v):
    if isinstance(v, float) and v == int(v) and abs(v) < 1e15:
        v = int(v)
    s = repr(v) if isinstance(v, float) else str(v)
    if "e" in s or "E" in s:
        s = ("%.15f" % v).rstrip("0").rstrip(".")
    return s.replace(".", ",")


def parse_input(s):
    """Eingabe deuten: ('empty',), ('formula', text), ('num', wert, prozent), ('date', date), ('text', text)."""
    t = s.strip()
    if t == "":
        return ("empty",)
    if t.startswith("=") and len(t) > 1:
        return ("formula", t[1:])
    if s.startswith("'"):
        return ("text", s[1:])
    m = _NUM.match(t)
    if m:
        z = t.rstrip("% ").replace(".", "").replace(",", ".")
        v = float(z)
        return ("num", v / 100 if m.group(1) else v, bool(m.group(1)))
    if _NUM_EN.match(t):
        return ("num", float(t), False)
    m = _DATE.match(t)
    if m:
        try:
            return ("date", datetime.date(int(m.group(3)), int(m.group(2)), int(m.group(1))))
        except ValueError:
            pass
    return ("text", s)


def _numstr(v):
    if v == int(v) and abs(v) < 1e15:
        return str(int(v))
    return repr(float(v))


def _apply(data, ops):
    """ops: (start, ende, ersatz, rang) auf Bytes anwenden."""
    ops = sorted(ops, key=lambda o: (o[0], o[1], o[3]))
    out, pos = [], 0
    for a, b, rep, _ in ops:
        if a < pos:
            raise SheetError("Die Änderungen überschneiden sich (interner Fehler).")
        out.append(data[pos:a])
        out.append(rep)
        pos = b
    out.append(data[pos:])
    return b"".join(out)


def _write_zip(src, tmp, replace, drop=()):
    with zipfile.ZipFile(src) as zin, zipfile.ZipFile(tmp, "w") as zout:
        infos = zin.infolist()
        infos.sort(key=lambda i: i.filename != "mimetype")
        for info in infos:
            if info.filename in drop:
                continue
            data = replace.get(info.filename)
            if data is None:
                data = zin.read(info.filename)
            ni = zipfile.ZipInfo(info.filename, info.date_time)
            ni.compress_type = zipfile.ZIP_STORED if info.filename == "mimetype" else info.compress_type
            ni.external_attr = info.external_attr
            zout.writestr(ni, data)


class _Base:
    def __init__(self, path):
        self.path = os.path.abspath(path)
        self.sheets = []
        self.backed_up = False
        self.has_formulas = False
        self.load()

    def save(self, dest, edits):
        """edits: {blattnummer: {(zeile, spalte): eingabe}}"""
        dest = os.path.abspath(dest)
        tmp = dest + ".teil"
        try:
            self._build(tmp, edits)
            self._verify(tmp, edits)
            if dest == self.path and not self.backed_up:
                shutil.copy2(self.path, self.path + ".bak")
                self.backed_up = True
            os.replace(tmp, dest)
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)

    def _verify(self, tmp, edits):
        new = type(self)(tmp)
        for si, cells in edits.items():
            for (r, c), inp in cells.items():
                got = new.sheets[si].cells.get((r, c))
                want = parse_input(inp)
                ok = True
                if want[0] == "empty":
                    ok = got is None or (got.input == "" and not got.formula)
                elif got is None:
                    ok = False
                elif want[0] == "formula":
                    ok = got.formula
                elif want[0] == "num":
                    g = parse_input(got.input)
                    ok = g[0] == "num" and abs(g[1] - want[1]) <= 1e-9 * max(1.0, abs(want[1]))
                elif want[0] == "text":
                    ok = got.input == want[1] or got.text == want[1]
                if not ok:
                    raise SheetError("Sicherheitsprüfung fehlgeschlagen bei Zelle %s%d (Blatt %s). "
                                     "Die Datei wurde nicht verändert."
                                     % (col_name(c), r + 1, self.sheets[si].name))


# ============================================================================ XLSX
class XlsxFile(_Base):
    kind = "xlsx"
    formula_hint = "Formeln in englischer Schreibweise mit Komma als Trenner, zum Beispiel =SUM(A1:A5) oder =IF(A1>0,A1,0)"

    def load(self):
        try:
            import openpyxl
        except ImportError:
            raise SheetError("Das Python-Paket openpyxl fehlt.")
        with open(self.path, "rb") as fh:
            raw = io.BytesIO(fh.read())
        wbf = openpyxl.load_workbook(raw, data_only=False)
        raw.seek(0)
        wbv = openpyxl.load_workbook(raw, data_only=True)
        with zipfile.ZipFile(self.path) as z:
            self.names = z.namelist()
            wbx = ET.fromstring(z.read("xl/workbook.xml"))
            rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
        rmap = {r.get("Id"): r.get("Target") for r in rels}
        main = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
        rid = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"
        self.parts = {}
        for s in wbx.iter(main + "sheet"):
            t = rmap.get(s.get(rid), "")
            t = t.lstrip("/") if t.startswith("/") else "xl/" + t
            self.parts[s.get("name")] = t
        for ws in wbf.worksheets:
            sh = Sheet(ws.title)
            sh.part = self.parts.get(ws.title)
            wv = wbv[ws.title]
            for (r, c), cell in ws._cells.items():
                v = cell.value
                if v is None:
                    continue
                formula = cell.data_type == "f"
                bold = bool(cell.font and cell.font.b)
                if formula:
                    ftxt = v if isinstance(v, str) else "=" + str(getattr(v, "text", "") or "")
                    cv = wv._cells.get((r, c))
                    val = cv.value if cv is not None else None
                    text = fmt_cell(val, cell.number_format) if val is not None else ""
                    sh.cells[(r - 1, c - 1)] = Cell(text, ftxt, True, bold,
                                                    isinstance(val, (int, float)), cell.is_date, "f")
                    self.has_formulas = True
                    continue
                text = fmt_cell(v, cell.number_format)
                if isinstance(v, bool):
                    inp, kind = ("WAHR" if v else "FALSCH"), "b"
                elif isinstance(v, (int, float)):
                    if "%" in (cell.number_format or ""):
                        inp = de_num(round(v * 100, 10)) + "%"
                    else:
                        inp = de_num(v)
                    kind = "n"
                elif isinstance(v, datetime.datetime):
                    inp = v.strftime("%d.%m.%Y") if (v.hour, v.minute, v.second) == (0, 0, 0) \
                        else v.strftime("%d.%m.%Y %H:%M")
                    kind = "d"
                elif isinstance(v, datetime.date):
                    inp, kind = v.strftime("%d.%m.%Y"), "d"
                else:
                    inp, kind = str(v), "s"
                    if parse_input(inp)[0] != "text":
                        inp = "'" + inp
                sh.cells[(r - 1, c - 1)] = Cell(text, inp, False, bold, kind in ("n", "d"),
                                                cell.is_date, kind)
            for rng in ws.merged_cells.ranges:
                sh.merges.append((rng.min_row - 1, rng.min_col - 1,
                                  rng.max_row - rng.min_row + 1, rng.max_col - rng.min_col + 1))
            sh.nrows = max([k[0] for k in sh.cells] + [-1]) + 1
            sh.ncols = max([k[1] for k in sh.cells] + [-1]) + 1
            self.sheets.append(sh)
        self.epoch1904 = bool(wbf.epoch and wbf.epoch.year == 1904)

    # ---- Blatt-XML vermessen
    def _scan(self, data):
        p = expat.ParserCreate()
        info = {"sd": None, "rows": []}
        st = {"row": None, "cell": None, "lastr": 0, "lastc": -1}

        def tagend(i):
            return _TAG.match(data, i).end()

        def start(name, attrs):
            i = p.CurrentByteIndex
            if name == "sheetData":
                info["sd"] = {"start": i}
            elif name == "row" and info["sd"] is not None and st["row"] is None:
                r = int(attrs["r"]) if "r" in attrs else st["lastr"] + 1
                st["lastr"] = r
                st["lastc"] = -1
                st["row"] = {"r": r - 1, "start": i, "cells": []}
            elif name == "c" and st["row"] is not None and st["cell"] is None:
                m = _REF.match(attrs.get("r", ""))
                col = col_index(m.group(1)) if m else st["lastc"] + 1
                st["lastc"] = col
                st["cell"] = {"c": col, "start": i, "s": attrs.get("s"), "f": None, "v": None, "master": False}
            elif name == "f" and st["cell"] is not None:
                st["cell"]["f"] = True
                if attrs.get("ref") and attrs.get("t") in ("shared", "array", "dataTable"):
                    st["cell"]["master"] = True
            elif name == "v" and st["cell"] is not None:
                st["cell"]["v"] = [i, None]

        def end(name):
            i = p.CurrentByteIndex
            def close(d):
                d["selfclose"] = data[i - 2:i] == b"/>" and tagend(d["start"]) == i
                d["endtag"] = i
                d["end"] = i if d["selfclose"] else tagend(i)
            if name == "v" and st["cell"] is not None and st["cell"]["v"]:
                v = st["cell"]["v"]
                v[1] = i if (data[i - 2:i] == b"/>" and tagend(v[0]) == i) else tagend(i)
            elif name == "c" and st["cell"] is not None:
                close(st["cell"])
                st["row"]["cells"].append(st["cell"])
                st["cell"] = None
            elif name == "row" and st["row"] is not None and st["cell"] is None:
                close(st["row"])
                info["rows"].append(st["row"])
                st["row"] = None
            elif name == "sheetData" and info["sd"] is not None and "end" not in info["sd"]:
                close(info["sd"])

        p.StartElementHandler = start
        p.EndElementHandler = end
        p.Parse(data, True)
        if info["sd"] is None:
            raise SheetError("Unbekannter Aufbau des Tabellenblatts.")
        return info

    def _cell_xml(self, r, c, inp, style, isdate):
        ref = "%s%d" % (col_name(c), r + 1)
        s = ' s="%s"' % style if style else ""
        kind = parse_input(inp)
        if kind[0] == "empty":
            return ('<c r="%s"%s/>' % (ref, s)).encode() if style else b""
        if kind[0] == "formula":
            return ('<c r="%s"%s><f>%s</f></c>' % (ref, s, escape(kind[1]))).encode("utf-8")
        if kind[0] == "num":
            return ('<c r="%s"%s><v>%s</v></c>' % (ref, s, _numstr(kind[1]))).encode()
        if kind[0] == "date" and isdate:
            base = datetime.date(1904, 1, 1) if self.epoch1904 else datetime.date(1899, 12, 30)
            return ('<c r="%s"%s><v>%d</v></c>' % (ref, s, (kind[1] - base).days)).encode()
        text = kind[1] if kind[0] == "text" else inp.strip()
        return ('<c r="%s"%s t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>'
                % (ref, s, escape(text))).encode("utf-8")

    def _patch_sheet(self, data, sheet, cells):
        info = self._scan(data)
        ops = []
        rows = {row["r"]: row for row in info["rows"]}
        by_row = {}
        for (r, c), inp in cells.items():
            by_row.setdefault(r, {})[c] = inp
        touched = set()
        for r, edits in by_row.items():
            row = rows.get(r)

            def xml(c, style=None):
                old = sheet.cells.get((r, c))
                return self._cell_xml(r, c, edits[c], style, bool(old and old.isdate))
            if row is None:
                body = b"".join(xml(c) for c in sorted(edits))
                if not body:
                    continue
                frag = ('<row r="%d">' % (r + 1)).encode() + body + b"</row>"
                later = [x for x in info["rows"] if x["r"] > r]
                sd = info["sd"]
                if later:
                    pos = min(later, key=lambda x: x["r"])["start"]
                    ops.append((pos, pos, frag, r))
                elif sd["selfclose"]:
                    ops.append((sd["start"], sd["end"], b"<sheetData>" + frag + b"</sheetData>", r))
                else:
                    ops.append((sd["endtag"], sd["endtag"], frag, r))
                continue
            have = {cell["c"]: cell for cell in row["cells"]}
            new = []
            for c in sorted(edits):
                cell = have.get(c)
                if cell is not None:
                    if cell["master"]:
                        raise SheetError("Zelle %s%d ist die Ausgangszelle einer geteilten Formel oder "
                                         "Matrixformel und kann hier nicht geändert werden."
                                         % (col_name(c), r + 1))
                    touched.add(id(cell))
                    ops.append((cell["start"], cell["end"], xml(c, cell["s"]), c))
                else:
                    x = xml(c)
                    if x:
                        new.append((c, x))
            if not new:
                continue
            if row["selfclose"]:
                st = data[row["start"]:row["end"]][:-2].rstrip() + b">"
                ops.append((row["start"], row["end"], st + b"".join(x for _, x in new) + b"</row>", 0))
            else:
                for c, x in new:
                    later = [cell for cell in row["cells"] if cell["c"] > c]
                    pos = min(later, key=lambda q: q["c"])["start"] if later else row["endtag"]
                    ops.append((pos, pos, x, c))
        # gespeicherte Formelergebnisse entfernen, damit beim Öffnen neu gerechnet wird
        for row in info["rows"]:
            for cell in row["cells"]:
                if cell["f"] and cell["v"] and id(cell) not in touched:
                    ops.append((cell["v"][0], cell["v"][1], b"", 0))
        return _apply(data, ops)

    def _build(self, tmp, edits):
        replace, drop = {}, set()
        with zipfile.ZipFile(self.path) as z:
            for si, sh in enumerate(self.sheets):
                if not sh.part or sh.part not in self.names:
                    if edits.get(si):
                        raise SheetError("Das Blatt %s wurde in der Datei nicht gefunden." % sh.name)
                    continue
                replace[sh.part] = self._patch_sheet(z.read(sh.part), sh, edits.get(si, {}))
            if "xl/calcChain.xml" in self.names:
                drop.add("xl/calcChain.xml")
                ct = z.read("[Content_Types].xml")
                replace["[Content_Types].xml"] = re.sub(rb'<Override[^>]*calcChain[^>]*/>', b"", ct)
                rl = z.read("xl/_rels/workbook.xml.rels")
                replace["xl/_rels/workbook.xml.rels"] = re.sub(rb'<Relationship[^>]*calcChain[^>]*/>', b"", rl)
            wb = z.read("xl/workbook.xml")
            if b"fullCalcOnLoad" not in wb:
                wb2 = re.sub(rb"<calcPr(?=[\s/>])", b'<calcPr fullCalcOnLoad="1"', wb, count=1)
                if wb2 != wb:
                    replace["xl/workbook.xml"] = wb2
        _write_zip(self.path, tmp, replace, drop)


# ============================================================================ ODS
def _of_to_show(f):
    """of:=SUM([.A1:.B2]) -> =SUM(A1:B2)"""
    if f.startswith("of:"):
        f = f[3:]
    elif ":" in f.split("=", 1)[0]:
        f = f.split(":", 1)[1]

    def ref(m):
        parts = []
        for p in m.group(1).split(":"):
            if p.startswith("."):
                p = p[1:]
            elif p.startswith("$") and "." in p:
                p = p[1:]
            parts.append(p)
        return ":".join(parts)
    out, i = [], 0
    for m in re.finditer(r'"(?:[^"]|"")*"|\[([^\]]*)\]', f):
        out.append(f[i:m.start()])
        out.append(m.group(0) if m.group(1) is None else ref(m))
        i = m.end()
    out.append(f[i:])
    return "".join(out)


_SHOWREF = re.compile(r"""("(?:[^"]|"")*")|((?:'[^']+'|[A-Za-z_À-ɏ][\wÀ-ɏ]*)\.)?"""
                      r"""(\$?[A-Za-z]{1,3}\$?\d+)(?::((?:'[^']+'|[A-Za-z_À-ɏ][\wÀ-ɏ]*)\.)?"""
                      r"""(\$?[A-Za-z]{1,3}\$?\d+))?(?![\w(])""")


def _show_to_of(f):
    """SUM(A1:B2) -> of:=SUM([.A1:.B2])"""
    def rep(m):
        if m.group(1):
            return m.group(1)
        s1 = ("$" + m.group(2)) if m.group(2) else "."
        a = s1 + m.group(3).upper()
        if m.group(5):
            s2 = ("$" + m.group(4)) if m.group(4) else "."
            a += ":" + s2 + m.group(5).upper()
        return "[" + a + "]"
    # Bezüge nur dort ersetzen, wo kein Funktionsname oder Bezeichner davor steht
    out, i = [], 0
    for m in _SHOWREF.finditer(f):
        if m.group(1) is None and m.start() > 0 and (f[m.start() - 1].isalnum() or f[m.start() - 1] in "_."):
            continue
        out.append(f[i:m.start()])
        out.append(rep(m))
        i = m.end()
    out.append(f[i:])
    return "of:=" + "".join(out)


class OdsFile(_Base):
    kind = "ods"
    formula_hint = "Formeln in englischer Schreibweise mit Semikolon als Trenner, zum Beispiel =SUM(A1:A5) oder =IF(A1>0;A1;0)"

    def load(self):
        with zipfile.ZipFile(self.path) as z:
            self.data = z.read("content.xml")
        self._scan()
        for t in self.tables:
            sh = Sheet(t["name"])
            for row in t["rows"]:
                if row["r0"] >= MAX_SHOW_ROWS:
                    break
                for cell in row["cells"]:
                    if cell["covered"] or (not cell["text"] and not cell["formula"] and not cell["span"]):
                        continue
                    if not cell["text"] and not cell["formula"]:
                        obj = None
                    else:
                        obj = self._cell_obj(cell)
                    for dr in range(min(row["rep"], 200 if obj else 1)):
                        for dc in range(min(cell["rep"], 200 if obj else 1)):
                            r, c = row["r0"] + dr, cell["c0"] + dc
                            if c >= MAX_SHOW_COLS:
                                break
                            if obj:
                                sh.cells[(r, c)] = obj
                            if cell["span"]:
                                sh.merges.append((r, c, cell["span"][0], cell["span"][1]))
            sh.nrows = max([k[0] for k in sh.cells] + [-1]) + 1
            sh.ncols = max([k[1] for k in sh.cells] + [-1]) + 1
            self.sheets.append(sh)

    def _cell_obj(self, cell):
        a = cell["attrs"]
        vt = a.get(self.q_o + ":value-type", "")
        text = cell["text"]
        if cell["formula"]:
            self.has_formulas = True
            return Cell(text, _of_to_show(cell["formula"]), True, False, vt in ("float", "currency", "percentage"),
                        vt == "date", "f")
        if vt in ("float", "currency", "percentage"):
            try:
                v = float(a.get(self.q_o + ":value", "0"))
            except ValueError:
                v = 0.0
            inp = de_num(round(v * 100, 10)) + "%" if vt == "percentage" else de_num(v)
            return Cell(text, inp, False, False, True, False, "n")
        if vt == "date":
            dv = a.get(self.q_o + ":date-value", "")
            m = re.match(r"(\d{4})-(\d\d)-(\d\d)(?:T(\d\d):(\d\d))?", dv)
            inp = text
            if m:
                inp = "%s.%s.%s" % (m.group(3), m.group(2), m.group(1))
                if m.group(4) and (m.group(4), m.group(5)) != ("00", "00"):
                    inp += " %s:%s" % (m.group(4), m.group(5))
            return Cell(text, inp, False, False, True, True, "d")
        inp = text
        if vt == "string" and parse_input(inp)[0] != "text":
            inp = "'" + inp
        return Cell(text, inp, False, False, False, False, "s")

    def _scan(self):
        data = self.data
        p = expat.ParserCreate()
        self.ns = {}
        self.tables = []
        st = {"table": None, "row": None, "cell": None, "depth": 0, "tdepth": 0, "para": 0, "skip": 0,
              "inspread": False}

        def tagend(i):
            return _TAG.match(data, i).end()

        def nm(name):
            pre, _, loc = name.partition(":")
            return self.ns.get(pre), loc

        def start(name, attrs):
            for k, v in attrs.items():
                if k.startswith("xmlns:"):
                    self.ns.setdefault(k[6:], v)
            st["depth"] += 1
            uri, loc = nm(name)
            i = p.CurrentByteIndex
            if uri == NS_O and loc == "spreadsheet":
                st["inspread"] = True
                return
            if not st["inspread"]:
                return
            cell = st["cell"]
            if cell is not None:
                if uri == NS_O and loc == "annotation":
                    st["skip"] += 1
                elif uri == NS_T and loc == "table":
                    st["skip"] += 1
                elif st["skip"]:
                    if (uri == NS_O and loc == "annotation") or (uri == NS_T and loc == "table"):
                        st["skip"] += 1
                elif uri == NS_X and loc == "p":
                    if cell["np"]:
                        cell["buf"].append("\n")
                    cell["np"] += 1
                elif uri == NS_X and loc == "s":
                    try:
                        cell["buf"].append(" " * int(attrs.get(self.pre[NS_X] + ":c", "1")))
                    except ValueError:
                        cell["buf"].append(" ")
                elif uri == NS_X and loc == "tab":
                    cell["buf"].append("\t")
                elif uri == NS_X and loc == "line-break":
                    cell["buf"].append("\n")
                return
            if uri != NS_T:
                return
            if loc == "table" and st["table"] is None:
                self.pre = {u: k for k, u in self.ns.items()}
                st["table"] = {"name": attrs.get(name.partition(":")[0] + ":name", "Tabelle"), "rows": [],
                               "start": i, "depth": st["depth"], "nextr": 0}
            elif loc == "table-row" and st["table"] is not None and st["row"] is None:
                tp = name.partition(":")[0]
                try:
                    rep = int(attrs.get(tp + ":number-rows-repeated", "1"))
                except ValueError:
                    rep = 1
                st["row"] = {"start": i, "rep": rep, "cells": [], "r0": st["table"]["nextr"], "nextc": 0,
                             "qname": name}
                st["table"]["nextr"] += rep
            elif loc in ("table-cell", "covered-table-cell") and st["row"] is not None:
                tp = name.partition(":")[0]
                try:
                    rep = int(attrs.get(tp + ":number-columns-repeated", "1"))
                except ValueError:
                    rep = 1
                span = None
                try:
                    cs = int(attrs.get(tp + ":number-columns-spanned", "1"))
                    rs = int(attrs.get(tp + ":number-rows-spanned", "1"))
                    if cs > 1 or rs > 1:
                        span = (rs, cs)
                except ValueError:
                    pass
                st["cell"] = {"start": i, "rep": rep, "covered": loc != "table-cell", "attrs": dict(attrs),
                              "c0": st["row"]["nextc"], "buf": [], "np": 0, "qname": name, "span": span,
                              "formula": attrs.get(tp + ":formula"), "depth": st["depth"]}
                st["row"]["nextc"] += rep

        def end(name):
            i = p.CurrentByteIndex
            depth = st["depth"]
            st["depth"] -= 1
            if not st["inspread"]:
                return
            uri, loc = nm(name)

            def close(d):
                d["selfclose"] = data[i - 2:i] == b"/>" and tagend(d["start"]) == i
                d["endtag"] = i
                d["end"] = i if d["selfclose"] else tagend(i)
            cell = st["cell"]
            if cell is not None:
                if depth == cell["depth"]:
                    close(cell)
                    cell["text"] = "".join(cell.pop("buf"))
                    st["row"]["cells"].append(cell)
                    st["cell"] = None
                    st["skip"] = 0
                elif st["skip"] and ((uri == NS_O and loc == "annotation") or (uri == NS_T and loc == "table")):
                    st["skip"] -= 1
                return
            if uri == NS_T and loc == "table-row" and st["row"] is not None:
                close(st["row"])
                st["table"]["rows"].append(st["row"])
                st["row"] = None
            elif uri == NS_T and loc == "table" and st["table"] is not None and depth == st["table"]["depth"]:
                self.tables.append(st["table"])
                st["table"] = None
            elif uri == NS_O and loc == "spreadsheet":
                st["inspread"] = False

        def chars(s):
            cell = st["cell"]
            if cell is not None and not st["skip"] and cell["np"]:
                cell["buf"].append(s)

        p.StartElementHandler = start
        p.EndElementHandler = end
        p.CharacterDataHandler = chars
        p.buffer_text = True
        p.Parse(data, True)
        self.pre = {u: k for k, u in self.ns.items()}
        if NS_T not in self.pre or NS_O not in self.pre or NS_X not in self.pre:
            raise SheetError("Unbekannter Aufbau der ODS-Datei.")
        self.q_t, self.q_o, self.q_x = self.pre[NS_T], self.pre[NS_O], self.pre[NS_X]
        self.q_c = self.pre.get(NS_C)

    # ---- einzelne Zellen
    def _keep_attrs(self, cell, rep=None, strip_value=True):
        t = self.q_t
        keep = (t + ":style-name", t + ":content-validation-name", t + ":number-columns-spanned",
                t + ":number-rows-spanned", t + ":number-matrix-columns-spanned",
                t + ":number-matrix-rows-spanned")
        out = ""
        for k, v in cell["attrs"].items():
            if k.startswith("xmlns"):
                continue
            if k == t + ":number-columns-repeated":
                continue
            if strip_value and k not in keep:
                continue
            out += " %s=%s" % (k, quoteattr(v))
        if rep and rep > 1:
            out += ' %s:number-columns-repeated="%d"' % (t, rep)
        return out

    def _orig_cell(self, cell, rep):
        """Unveränderte Zelle mit anderer Wiederholungszahl."""
        if rep == cell["rep"]:
            return self.data[cell["start"]:cell["end"]]
        head = "<%s%s" % (cell["qname"], self._keep_attrs(cell, rep, strip_value=False))
        if cell["selfclose"]:
            return (head + "/>").encode("utf-8")
        inner = self.data[_TAG.match(self.data, cell["start"]).end():cell["endtag"]]
        return (head + ">").encode("utf-8") + inner + ("</%s>" % cell["qname"]).encode()

    def _strip_cached(self, cell, rep):
        """Formelzelle ohne gespeichertes Ergebnis (Kommentar bleibt erhalten)."""
        t, o = self.q_t, self.q_o
        attrs = ""
        for k, v in cell["attrs"].items():
            if k.startswith("xmlns") or k == t + ":number-columns-repeated":
                continue
            if k.startswith(o + ":") or (self.q_c and k == self.q_c + ":value-type"):
                continue
            attrs += " %s=%s" % (k, quoteattr(v))
        if rep > 1:
            attrs += ' %s:number-columns-repeated="%d"' % (t, rep)
        inner = b""
        if not cell["selfclose"]:
            raw = self.data[_TAG.match(self.data, cell["start"]).end():cell["endtag"]]
            mark = ("</%s:annotation>" % o).encode()
            k = raw.rfind(mark)
            if k >= 0:
                inner = raw[:k + len(mark)]
        head = ("<%s%s" % (cell["qname"], attrs)).encode("utf-8")
        if inner:
            return head + b">" + inner + ("</%s>" % cell["qname"]).encode()
        return head + b"/>"

    def _new_cell(self, cell, inp):
        t, o, x, cx = self.q_t, self.q_o, self.q_x, self.q_c
        name = "%s:table-cell" % t
        attrs = self._keep_attrs(cell) if cell is not None else ""
        if cell is not None and cell["covered"]:
            raise SheetError("Eine Zelle innerhalb eines verbundenen Bereichs kann nicht geändert werden.")
        kind = parse_input(inp)
        old_vt = cell["attrs"].get(o + ":value-type", "") if cell is not None else ""

        def cal(v):
            return ' %s:value-type="%s"' % (cx, v) if cx else ""
        if kind[0] == "empty":
            return ("<%s%s/>" % (name, attrs)).encode("utf-8")
        if kind[0] == "formula":
            return ("<%s%s %s:formula=%s/>" % (name, attrs, t, quoteattr(_show_to_of(kind[1])))).encode("utf-8")
        if kind[0] == "num":
            vt = "percentage" if (kind[2] or old_vt == "percentage") else \
                ("currency" if old_vt == "currency" else "float")
            extra = ""
            if vt == "currency" and cell["attrs"].get(o + ":currency"):
                extra = " %s:currency=%s" % (o, quoteattr(cell["attrs"][o + ":currency"]))
            shown = de_num(round(kind[1] * 100, 10)) + " %" if vt == "percentage" else de_num(kind[1])
            return ('<%s%s %s:value-type="%s" %s:value="%s"%s%s><%s:p>%s</%s:p></%s>'
                    % (name, attrs, o, vt, o, _numstr(kind[1]), extra, cal(vt), x, shown, x, name)).encode("utf-8")
        if kind[0] == "date":
            return ('<%s%s %s:value-type="date" %s:date-value="%s"%s><%s:p>%s</%s:p></%s>'
                    % (name, attrs, o, o, kind[1].isoformat(), cal("date"), x,
                       kind[1].strftime("%d.%m.%Y"), x, name)).encode("utf-8")
        text = kind[1]
        ps = "".join("<%s:p>%s</%s:p>" % (x, self._text(line), x) for line in text.split("\n"))
        return ('<%s%s %s:value-type="string"%s>%s</%s>'
                % (name, attrs, o, cal("string"), ps, name)).encode("utf-8")

    def _text(self, s):
        out, prev = "", True
        for ch in s:
            if ch == " " and prev:
                out += "<%s:s/>" % self.q_x
            elif ch == "\t":
                out += "<%s:tab/>" % self.q_x
                prev = True
                continue
            elif ch >= " ":
                out += escape(ch)
            prev = ch == " "
        return out

    # ---- Zeilen
    def _row_inner(self, row, edits, strip):
        """Inhalt einer Zeile neu zusammensetzen. edits: {spalte: eingabe}"""
        data = self.data
        out = []
        if row["selfclose"]:
            pos = None
        else:
            pos = _TAG.match(data, row["start"]).end()
        for cell in row["cells"]:
            out.append(data[pos:cell["start"]])
            pos = cell["end"]
            c0, rep = cell["c0"], cell["rep"]
            mine = sorted(c for c in edits if c0 <= c < c0 + rep)
            is_f = bool(cell["formula"])
            if not mine:
                out.append(self._strip_cached(cell, rep) if (is_f and strip) else data[cell["start"]:cell["end"]])
                continue
            cur = c0
            for c in mine:
                if c > cur:
                    out.append(self._strip_cached(cell, c - cur) if (is_f and strip)
                               else self._orig_cell(cell, c - cur))
                out.append(self._new_cell(cell, edits[c]))
                cur = c + 1
            if cur < c0 + rep:
                out.append(self._strip_cached(cell, c0 + rep - cur) if (is_f and strip)
                           else self._orig_cell(cell, c0 + rep - cur))
        if pos is not None:
            out.append(data[pos:row["endtag"]])
        last = row["cells"][-1]["c0"] + row["cells"][-1]["rep"] if row["cells"] else 0
        beyond = sorted(c for c in edits if c >= last)
        cur = last
        for c in beyond:
            if parse_input(edits[c])[0] == "empty":
                continue
            if c > cur:
                out.append(('<%s:table-cell %s:number-columns-repeated="%d"/>' % (self.q_t, self.q_t, c - cur)).encode())
            out.append(self._new_cell(None, edits[c]))
            cur = c + 1
        return b"".join(out)

    def _row_tag(self, row, rep):
        st = self.data[row["start"]:_TAG.match(self.data, row["start"]).end()]
        if row["selfclose"]:
            st = st[:-2].rstrip() + b">"
        st = re.sub((r' %s:number-rows-repeated="[^"]*"' % self.q_t).encode(), b"", st)
        if rep > 1:
            st = st[:-1] + (' %s:number-rows-repeated="%d">' % (self.q_t, rep)).encode()
        return st

    def _row_xml(self, row, rep, edits, strip):
        end = ("</%s>" % row["qname"]).encode()
        return self._row_tag(row, rep) + self._row_inner(row, edits, strip) + end

    def _build(self, tmp, edits):
        ops = []
        strip = True
        for ti, t in enumerate(self.tables):
            by_row = {}
            for (r, c), inp in edits.get(ti, {}).items():
                by_row.setdefault(r, {})[c] = inp
            total = t["rows"][-1]["r0"] + t["rows"][-1]["rep"] if t["rows"] else 0
            below = sorted(r for r in by_row if r >= total)
            if below:
                if not t["rows"]:
                    raise SheetError("In ein Blatt ohne Zeilen kann nicht geschrieben werden.")
                rn = "%s:table-row" % self.q_t
                dummy = {"cells": [], "selfclose": True, "start": 0, "endtag": 0}
                out, cur = [], total
                for r in below:
                    inner = self._row_inner(dummy, by_row[r], False)
                    if not inner:
                        continue
                    if r > cur:
                        out.append(('<%s %s:number-rows-repeated="%d"><%s:table-cell/></%s>'
                                    % (rn, self.q_t, r - cur, self.q_t, rn)).encode())
                    out.append(("<%s>" % rn).encode() + inner + ("</%s>" % rn).encode())
                    cur = r + 1
                pos = t["rows"][-1]["end"]
                ops.append((pos, pos, b"".join(out), 1))
            for row in t["rows"]:
                r0, rep = row["r0"], row["rep"]
                mine = sorted(r for r in by_row if r0 <= r < r0 + rep)
                has_f = any(c["formula"] for c in row["cells"])
                if not mine:
                    if has_f and strip:
                        for cell in row["cells"]:
                            if cell["formula"]:
                                ops.append((cell["start"], cell["end"], self._strip_cached(cell, cell["rep"]), 0))
                    continue
                out, cur = [], r0
                for r in mine:
                    if r > cur:
                        out.append(self._row_xml(row, r - cur, {}, strip))
                    out.append(self._row_xml(row, 1, by_row[r], strip))
                    cur = r + 1
                if cur < r0 + rep:
                    out.append(self._row_xml(row, r0 + rep - cur, {}, strip))
                ops.append((row["start"], row["end"], b"".join(out), 0))
        new = _apply(self.data, ops)
        try:
            ET.fromstring(new)
        except ET.ParseError as e:
            raise SheetError("Interner Fehler beim Zusammensetzen (%s)." % e)
        _write_zip(self.path, tmp, {"content.xml": new})


def open_sheet_file(path):
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx", ".xlsm"):
        return XlsxFile(path)
    if ext == ".ods":
        return OdsFile(path)
    raise SheetError("Dieses Tabellenformat kann nicht direkt bearbeitet werden.")


def recalculated_copy(path, find_soffice, lo_convert):
    """Kopie mit von LibreOffice berechneten Formelergebnissen (nur zum Anzeigen). None, wenn nicht möglich."""
    try:
        if not find_soffice():
            return None
        ext = os.path.splitext(path)[1].lower().lstrip(".")
        return lo_convert(path, "xlsx" if ext in ("xlsx", "xlsm") else "ods")
    except Exception:
        return None
