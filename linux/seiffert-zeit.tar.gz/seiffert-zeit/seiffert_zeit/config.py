import json, os, subprocess, tempfile, threading, time
from pathlib import Path

APP = "seiffert-zeit"
CONF_DIR = Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config") / APP
DATA_HOME = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share") / APP
SETTINGS_FILE = CONF_DIR / "settings.json"
LOG_FILE = DATA_HOME / "protokoll.txt"
_log_lock = threading.Lock()


def log(msg):
    """Protokoll ohne Token und ohne Inhalte."""
    try:
        with _log_lock:
            DATA_HOME.mkdir(parents=True, exist_ok=True)
            if LOG_FILE.exists() and LOG_FILE.stat().st_size > 300_000:
                LOG_FILE.replace(LOG_FILE.with_suffix(".alt.txt"))
            with open(LOG_FILE, "a", encoding="utf-8") as f:
                f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + str(msg) + "\n")
    except Exception:
        pass


def documents_dir():
    try:
        out = subprocess.run(["xdg-user-dir", "DOCUMENTS"], capture_output=True, text=True, timeout=3).stdout.strip()
        if out and Path(out) != Path.home():
            return Path(out)
    except Exception:
        pass
    for n in ("Dokumente", "Documents"):
        if (Path.home() / n).is_dir():
            return Path.home() / n
    return Path.home() / "Documents"


def atomic_write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=path.name + ".", suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data if isinstance(data, bytes) else data.encode("utf-8"))
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


class Settings:
    DEFAULTS = {
        "datenordner": "", "handoff_url": "", "client_id": "", "zoom": 1.0,
        "html_datei": "", "software_rendering": False,
        "drive_remote_modified": "", "drive_dirty": True, "drive_last": "",
        "geometry": "",
    }

    def __init__(self):
        self.lock = threading.RLock()
        self.d = dict(self.DEFAULTS)
        try:
            self.d.update(json.loads(SETTINGS_FILE.read_text("utf-8")))
        except Exception:
            pass

    def get(self, k):
        with self.lock:
            return self.d.get(k, self.DEFAULTS.get(k))

    def set(self, **kw):
        with self.lock:
            self.d.update(kw)
            try:
                atomic_write(SETTINGS_FILE, json.dumps(self.d, indent=1, ensure_ascii=False))
            except Exception as e:
                log("Einstellungen nicht gespeichert: %s" % e)

    def data_dir(self):
        v = self.get("datenordner")
        return Path(v) if v else documents_dir() / "Seifferts Zeit"
