# Seifferts Update 1.0

Ein Befehl für alle Seiffert-Programme.

Einrichten (einmal): tar -xzf seiffert-update.tar.gz, cd seiffert-update, ./install.sh
Das legt den Befehl seiffert-update und den Sammelordner ~/Seiffert-Archive an.

Aktualisieren: die aktuellen Archive (seiffert-dateien.tar.gz, seiffert-zeit.tar.gz, ...) in ~/Seiffert-Archive legen, dann im Terminal:

    seiffert-update

Pro Programm zählt das neueste Archiv (Namen mit Version oder " (1)" gehören zum selben Programm).
Seifferts Dateien kommt zuerst. Unveränderte Archive (gleiche Prüfsumme) werden übersprungen.
Jedes Archiv wird in einen vorübergehenden Ordner entpackt (Pfade nach außen, Verweise und Sonderdateien werden abgelehnt)
und mit sh install.sh installiert. Ein Archiv ohne install.sh wird mit Meldung übersprungen.

Optionen: --trocken (nur anzeigen), --erzwingen (alles neu), --liste (Stand zeigen), -- --surface (an jedes install.sh weitergeben).
Eigener Ordner: seiffert-update ORDNER oder Umgebungsvariable SEIFFERT_ARCHIVE.
Dieses Paket selbst kann ebenfalls als seiffert-update.tar.gz im Sammelordner liegen und aktualisiert sich dann mit.
Stand: ~/.local/share/seiffert-update/stand.json
