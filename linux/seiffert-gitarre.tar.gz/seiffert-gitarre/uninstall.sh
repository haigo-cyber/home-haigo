#!/usr/bin/env bash
# Entfernt Seifferts Gitarre. Die Einstellungen (~/.config/seiffert-gitarre) bleiben erhalten.
APP=seiffert-gitarre
rm -rf "${HOME}/.local/share/${APP}"
rm -f "${HOME}/.local/bin/${APP}" "${HOME}/.local/share/applications/${APP}.desktop" \
      "${HOME}/.local/share/icons/hicolor/scalable/apps/${APP}.svg"
echo "Entfernt."
