"""Lokaler Server (nur 127.0.0.1) für das eingebettete HTML-Tool.

Er liefert die HTML-Seite aus (mit eingefügten Brücken-Skripten), nimmt Änderungen des localStorage entgegen, führt die
Zugriffe auf www.googleapis.com aus (kein CORS-Problem) und nimmt die Google-Anmeldung aus dem normalen Browser entgegen.
Alle Adressen für die Seite liegen unter einem zufälligen Pfad, der nur der Linux-App bekannt ist.
"""
import http.client
import json
import socket
import os
import re
import secrets
import subprocess
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from .config import LOG_FILE, PKG_DIR, VERSION
from .store import TAG_RE

GOOGLE_PREFIX = 'https://www.googleapis.com/'
REVOKE_URL = 'https://oauth2.googleapis.com/revoke'
MAX_BODY = 200 * 1024 * 1024


def _read(name):
    return (PKG_DIR / name).read_text(encoding='utf-8')


class Logger:
    def __init__(self, path=LOG_FILE):
        self.path = path
        self.lock = threading.Lock()

    def __call__(self, msg):
        line = '%s %s\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), msg)
        with self.lock:
            try:
                self.path.parent.mkdir(parents=True, exist_ok=True)
                if self.path.exists() and self.path.stat().st_size > 300_000:
                    os.replace(self.path, self.path.with_name(self.path.name + '.1'))
                with open(self.path, 'a', encoding='utf-8') as f:
                    f.write(line)
            except OSError:
                pass


def open_in_browser(url):
    """Öffnet eine Adresse im normalen Browser. Gibt False zurück, wenn das nicht geklappt hat."""
    try:
        p = subprocess.Popen(['xdg-open', url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError:
        import webbrowser
        try:
            return bool(webbrowser.open(url))
        except Exception:
            return False
    try:
        return p.wait(timeout=4) == 0
    except subprocess.TimeoutExpired:
        return True  # xdg-open läuft noch, weil der Browser gerade startet


def check_handoff_url(s):
    """Prüft die Adresse der veröffentlichten Fassung. Gibt (Adresse, Fehlertext) zurück, Fehlertext ist leer bei Erfolg."""
    u = (s or '').strip()
    if not u:
        return '', 'Es ist keine Adresse eingetragen.'
    if u.count('://') > 1:
        return '', 'Die Adresse enthält mehrere „https://“ und ist vermutlich beim Einfügen durcheinander geraten. Bitte das Feld leeren und die Adresse einmal einfügen.'
    if '://' not in u:
        u = 'https://' + u
    try:
        p = urllib.parse.urlparse(u)
        host = (p.hostname or '').lower()
    except ValueError:
        return '', 'Das ist keine gültige Internetadresse.'
    if p.scheme != 'https' or '.' not in host or p.username or host in ('127.0.0.1', 'localhost'):
        return '', 'Das ist keine gültige Internetadresse. Sie muss mit https:// beginnen.'
    if host == 'google.com' or host.endswith('.google.com') or host.endswith('.googleusercontent.com') or host.endswith('.googleapis.com'):
        return '', ('Das ist eine Adresse von Google (zum Beispiel Drive). Gebraucht wird die Adresse, unter der du Seifferts Konten im Browser öffnest, '
                    'also die veröffentlichte konten.html (zum Beispiel auf GitHub Pages), nicht ein Drive-Ordner.')
    if 'linuxport=' in u or 'linuxstate=' in u:
        return '', 'Bitte die Adresse ohne den Teil ?linuxport=… eintragen.'
    return urllib.parse.urlunparse(p._replace(fragment='')), ''  # ein Teil nach # (zum Beispiel #daten) gehört nicht zur Adresse


def valid_handoff_url(s):
    return bool(check_handoff_url(s)[0])


class _Verbindung(http.client.HTTPSConnection):
    """HTTPS-Verbindung, die IPv4 zuerst versucht und je Adresse nur kurz wartet (Python probiert sonst jede Adresse bis zum vollen Zeitlimit)."""
    def connect(self):
        fehler = None
        infos = socket.getaddrinfo(self.host, self.port, 0, socket.SOCK_STREAM)
        infos.sort(key=lambda i: 0 if i[0] == socket.AF_INET else 1)
        for af, typ, proto, _, adresse in infos:
            sock = socket.socket(af, typ, proto)
            try:
                sock.settimeout(6)
                sock.connect(adresse)
                sock.settimeout(self.timeout)
                self.sock = sock
                ziel = self.host
                if self._tunnel_host:  # Zugriff über einen Proxy (Umgebungsvariable https_proxy)
                    ziel = self._tunnel_host
                    self._tunnel()
                self.sock = self._context.wrap_socket(self.sock, server_hostname=ziel)
                return
            except OSError as e:
                fehler = e
                sock.close()
        raise fehler or OSError('keine Adresse gefunden')


class _HttpsHandler(urllib.request.HTTPSHandler):
    def https_open(self, req):
        return self.do_open(_Verbindung, req, context=self._context)


class KontenServer:
    def __init__(self, store, settings, log=None, on_raise=None, opener=None):
        self.store = store
        self.settings = settings
        self.log = log or Logger()
        self.on_raise = on_raise or (lambda: None)
        self.opener = opener or open_in_browser
        self.secret = secrets.token_urlsafe(16)
        self.pending = {}
        self.plock = threading.Lock()
        srv = self

        class Handler(_Handler):
            pass
        Handler.srv = srv
        self.httpd = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.httpd.daemon_threads = True
        self.port = self.httpd.server_address[1]
        self.html_provider = lambda: self.settings.html_datei().read_text(encoding='utf-8')
        self.early = _read('shim_early.js')
        self.late = _read('shim_late.js')

    @property
    def url(self):
        return 'http://127.0.0.1:%d/%s/' % (self.port, self.secret)

    def start(self):
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def stop(self):
        try:
            self.httpd.shutdown()
            self.httpd.server_close()
        except Exception:
            pass

    # ---------- Seite ----------
    def build_page(self, html):
        html = re.sub(r'<script[^>]*accounts\.google\.com/gsi/client[^>]*></script>\s*', '', html)
        html = html.replace('interactive ? 120000 : 15000', 'interactive ? 300000 : 15000')
        seed = json.dumps(self.store.snapshot(), ensure_ascii=True).replace('</', '<\\/').replace('<!--', '<\\!--')
        early = self.early.replace('/*__SEED__*/{}', seed).replace('__LX_VERSION__', VERSION)
        if '<head>' in html:
            html = html.replace('<head>', '<head>\n<script>\n' + early + '\n</script>', 1)
        else:
            html = '<script>\n' + early + '\n</script>\n' + html
        i = html.rfind('</body>')
        late = '<script>\n' + self.late + '\n</script>\n'
        return html[:i] + late + html[i:] if i >= 0 else html + late

    # ---------- Google ----------
    def google_call(self, req):
        url = str(req.get('url', ''))
        if not url.startswith(GOOGLE_PREFIX):
            return {'status': 400, 'body': 'Adresse nicht erlaubt', 'contentType': 'text/plain'}
        real = url
        base = os.environ.get('SEIFFERT_KONTEN_GOOGLE_BASE')  # nur für Tests mit einer Nachbildung der Drive-Schnittstelle
        if base:
            real = base.rstrip('/') + '/' + url[len(GOOGLE_PREFIX):]
        hdr = {k: v for k, v in (req.get('headers') or {}).items() if str(k).lower() in ('authorization', 'content-type')}
        body = req.get('body')
        data = body.encode('utf-8') if isinstance(body, str) else None
        method = str(req.get('method') or 'GET').upper()
        r = urllib.request.Request(real, data=data, method=method, headers=hdr)
        host = urllib.parse.urlparse(real).hostname
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({})) if host in ('127.0.0.1', 'localhost') else urllib.request.build_opener(_HttpsHandler())
        t0 = time.time()
        u = urllib.parse.urlparse(url)
        what = '%s %s%s' % (method, u.path, ('?' + u.query[:100]) if u.query else '')
        try:
            try:
                resp = opener.open(r, timeout=60)
                status, ct, payload = resp.status, resp.headers.get('Content-Type'), resp.read()
            except urllib.error.HTTPError as e:
                status, ct, payload = e.code, e.headers.get('Content-Type'), e.read()
            self.log('Google %s -> %s (%d ms)' % (what, status, (time.time() - t0) * 1000))
            return {'status': status, 'contentType': ct or 'application/json', 'body': payload.decode('utf-8', 'replace')}
        except Exception as e:
            self.log('Google %s -> Fehler: %s' % (what, e))
            return {'status': 0, 'error': str(e)}

    def revoke(self, token):
        try:
            if os.environ.get('SEIFFERT_KONTEN_GOOGLE_BASE'):
                return
            data = urllib.parse.urlencode({'token': token}).encode()
            urllib.request.urlopen(urllib.request.Request(REVOKE_URL, data=data, method='POST'), timeout=15).read()
            self.log('Google Token widerrufen')
        except Exception as e:
            self.log('Google Widerruf nicht möglich: %s' % e)

    # ---------- Anmeldung über den Browser ----------
    def login_start(self):
        url = self.settings.get('handoff_url')
        url = url or ''
        if not valid_handoff_url(url):
            return {'error': check_handoff_url(url)[1] or 'Es ist noch keine Adresse der veröffentlichten HTML-Fassung eingetragen.', 'badAddress': True}
        state = secrets.token_urlsafe(18)
        with self.plock:
            now = time.time()
            for k in [k for k, v in self.pending.items() if now - v['time'] > 600]:
                self.pending.pop(k, None)
            for old in self.pending.values():  # frühere, nicht abgeschlossene Versuche beenden
                if not old['event'].is_set():
                    old['result'] = {'error': 'ersetzt'}
                    old['event'].set()
            self.pending[state] = {'event': threading.Event(), 'result': None, 'time': now}
        url = check_handoff_url(url)[0]  # ohne #-Teil, sonst landen die Angaben hinter dem # und die Seite sieht sie nie
        if url != self.settings.get('handoff_url'):
            self.settings.set('handoff_url', url)
        full = '%s%slinuxport=%d&linuxstate=%s' % (url, '&' if '?' in url else '?', self.port, state)
        opened = self.opener(full) is not False
        self.log('Anmeldung: Browser %s (Adresse %s)' % ('geöffnet' if opened else 'konnte NICHT geöffnet werden', url))
        return {'state': state, 'opened': opened, 'url': full}

    def login_wait(self, state):
        """Kurze Abfrage statt langem Warten: Chromium erlaubt nur wenige Verbindungen je Adresse, offene Abfragen würden die App blockieren."""
        with self.plock:
            p = self.pending.get(state)
        if not p:
            return {'error': 'unbekannt'}
        if not p['event'].wait(10):
            if time.time() - p['time'] > 290:
                with self.plock:
                    self.pending.pop(state, None)
                self.log('Anmeldung: keine Antwort aus dem Browser')
                return {'error': 'timeout'}
            return {'pending': True}
        with self.plock:
            self.pending.pop(state, None)
        return p['result'] or {'error': 'abgebrochen'}

    def handle_handoff(self, h):
        if h.command == 'GET':
            form = urllib.parse.parse_qs(urllib.parse.urlparse(h.path).query)
        else:
            form = urllib.parse.parse_qs(h._body().decode('utf-8', 'replace'))
        state = (form.get('state') or [''])[0]
        with self.plock:
            p = self.pending.get(state)
        if not p or time.time() - p['time'] > 600:
            h._html(400, 'Diese Anmeldung gehört zu keiner offenen Anfrage der Linux-App. Bitte in der App noch einmal auf Anmelden klicken.')
            return
        token = (form.get('access_token') or [''])[0]
        if token:
            try:
                exp = int((form.get('expires_in') or ['3600'])[0])
            except ValueError:
                exp = 3600
            p['result'] = {'access_token': token, 'expires_in': max(60, min(exp, 86400))}
            self.log('Anmeldung: Token aus dem Browser erhalten')
        else:
            p['result'] = {'error': (form.get('error') or ['abgebrochen'])[0][:60]}
        p['event'].set()
        try:
            self.on_raise()
        except Exception:
            pass
        h._html(200, 'Die Anmeldung wurde an Seifferts Konten übergeben. Du kannst diesen Browser-Tab schließen und zur Linux-App zurückkehren.')

    # ---------- API ----------
    def api(self, h, method, name, q):
        if method == 'POST' and name == 'ls':
            o = json.loads(h._body() or b'{}')
            k = o.get('k')
            if not isinstance(k, str) or not k.startswith('seifferts_konten'):
                return h._json({'error': 'Schlüssel nicht erlaubt'}, 400)
            if o.get('op') == 'set' and isinstance(o.get('v'), str):
                self.store.set(k, o['v'])
            elif o.get('op') == 'remove':
                self.store.remove(k)
            else:
                return h._json({'error': 'Befehl nicht erlaubt'}, 400)
            return h._json({'ok': True})
        if method == 'GET' and name == 'info':
            d = self.store.info()
            cur = self.settings.get('handoff_url') or ''
            d.update({'version': VERSION, 'handoffUrl': cur, 'handoffOk': valid_handoff_url(cur) if cur else False})
            return h._json(d)
        if name == 'config':
            if method == 'POST':
                o = json.loads(h._body() or b'{}')
                u, err = check_handoff_url(str(o.get('handoffUrl', '')))
                if err:
                    return h._json({'error': err})
                self.settings.set('handoff_url', u)
            cur = self.settings.get('handoff_url') or ''
            return h._json({'handoffUrl': cur, 'handoffOk': valid_handoff_url(cur) if cur else False})
        if method == 'POST' and name == 'login/start':
            h._body()
            return h._json(self.login_start())
        if method == 'GET' and name == 'login/wait':
            return h._json(self.login_wait((q.get('state') or [''])[0]))
        if method == 'POST' and name == 'google':
            return h._json(self.google_call(json.loads(h._body() or b'{}')))
        if method == 'POST' and name == 'revoke':
            o = json.loads(h._body() or b'{}')
            if isinstance(o.get('token'), str):
                threading.Thread(target=self.revoke, args=(o['token'],), daemon=True).start()
            return h._json({'ok': True})
        if method == 'POST' and name == 'backup/new':
            o = json.loads(h._body() or b'{}')
            tag = o.get('tag') or 'manuell'
            if not TAG_RE.match(tag):
                return h._json({'error': 'Ungültiger Zusatz'}, 400)
            try:
                return h._json({'name': self.store.manual_backup(tag)})
            except Exception as e:
                return h._json({'error': 'Sicherung nicht möglich: %s' % e})
        if method == 'GET' and name == 'backup/list':
            return h._json({'liste': self.store.list_backups()})
        if method == 'GET' and name == 'backup/read':
            try:
                return h._json({'text': self.store.read_backup((q.get('name') or [''])[0])})
            except Exception as e:
                return h._json({'error': 'Sicherung nicht lesbar: %s' % e})
        if method == 'POST' and name == 'openfolder':
            h._body()
            try:
                subprocess.Popen(['xdg-open', str(self.store.folder)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except OSError as e:
                return h._json({'error': str(e)})
            return h._json({'ok': True})
        if method == 'POST' and name == 'log':
            o = json.loads(h._body() or b'{}')
            self.log(str(o.get('msg', ''))[:300])
            return h._json({'ok': True})
        return h._json({'error': 'unbekannt'}, 404)


class _Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    srv = None

    def log_message(self, *a):
        pass

    def _body(self):
        n = int(self.headers.get('Content-Length') or 0)
        if n > MAX_BODY:
            raise ValueError('zu groß')
        return self.rfile.read(n) if n else b''

    def _send(self, code, data=b'', ctype='application/json; charset=utf-8'):
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(data)

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj, ensure_ascii=False).encode('utf-8'))

    def _html(self, code, text):
        body = ('<!DOCTYPE html><html lang="de"><meta charset="utf-8"><title>Seifferts Konten</title>'
                '<body style="font:18px system-ui;max-width:34em;margin:4em auto;padding:0 1em"><h1>Seifferts Konten</h1><p>%s</p></body></html>'
                % text.replace('&', '&amp;').replace('<', '&lt;'))
        self._send(code, body.encode('utf-8'), 'text/html; charset=utf-8')

    def do_GET(self):
        self._route('GET')

    def do_POST(self):
        self._route('POST')

    def _route(self, method):
        srv = self.srv
        try:
            if self.headers.get('Host', '') != '127.0.0.1:%d' % srv.port:
                self.close_connection = True
                return self._send(403, b'Host', 'text/plain')
            u = urllib.parse.urlparse(self.path)
            if u.path == '/handoff' and method in ('GET', 'POST'):
                return srv.handle_handoff(self)
            pre = '/%s/' % srv.secret
            if not u.path.startswith(pre):
                self.close_connection = True
                return self._send(404, b'404', 'text/plain')
            rest = u.path[len(pre):]
            if method == 'GET' and rest in ('', 'index.html'):
                html = srv.html_provider()
                return self._send(200, srv.build_page(html).encode('utf-8'), 'text/html; charset=utf-8')
            if rest.startswith('api/'):
                return srv.api(self, method, rest[4:], urllib.parse.parse_qs(u.query))
            self._send(404, b'404', 'text/plain')
        except (BrokenPipeError, ConnectionResetError):
            self.close_connection = True
        except Exception as e:
            self.close_connection = True
            srv.log('Serverfehler %s: %r' % (self.path.split('?')[0], e))
            try:
                self._json({'error': str(e)}, 500)
            except Exception:
                pass
