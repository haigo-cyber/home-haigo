import json, os, urllib.error, urllib.parse, urllib.request
from .config import log

API = os.environ.get("SZ_SHEETS_API", "https://sheets.googleapis.com/v4/spreadsheets")


class SheetsError(Exception):
    pass


def _req(token, method, url, body=None):
    h = {"Authorization": "Bearer " + token}
    if body is not None:
        h["Content-Type"] = "application/json"
    req = urllib.request.Request(url, method=method, headers=h, data=json.dumps(body).encode() if body is not None else None)
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            d = r.read()
        return json.loads(d) if d else {}
    except urllib.error.HTTPError as e:
        log("Sheets %s -> %s" % (method, e.code))
        raise SheetsError("Google Tabellen antwortet mit Fehler %s" % e.code)
    except (urllib.error.URLError, OSError):
        raise SheetsError("Keine Verbindung zu Google")


def row(x):
    """Zeile im Format des Blatts Fokus im ToDo (id, ref, title, meta, tags, next, start, end, ms, mod). Gelöschte Sitzungen haben ms 0."""
    ms = 0 if x.get("del") else int(round(float(x.get("ms") or 0)))
    return [str(x["id"]), x.get("ref", ""), x.get("title", ""), x.get("meta", ""), ",".join(x.get("tags") or []),
            "1" if x.get("next") else "0", x["start"], x.get("end", ""), str(ms), x.get("mod", "") or ""]


def _read(token, base):
    r = _req(token, "GET", base + "/values/" + urllib.parse.quote("Fokus!A2:J"))
    return [list(c) + [""] * (10 - len(c)) for c in (r.get("values") or [])]


def push_fokus(token, sheet_id, sessions):
    """Haengt Sitzungen an, deren id im Blatt fehlt, und aktualisiert Zeilen, die hier spaeter bearbeitet wurden (Spalte mod).
    Fehlt das Blatt Fokus, wird es nicht angelegt (das ToDo legt es mit Kopfzeile an)."""
    base = "%s/%s" % (API, urllib.parse.quote(sheet_id, safe=""))
    try:
        vals = _read(token, base)
    except SheetsError as e:
        if "400" in str(e):
            raise SheetsError("Das Blatt Fokus fehlt in der ToDo-Tabelle (bitte einmal das ToDo öffnen)")
        raise
    have = {}
    for i, c in enumerate(vals):
        if c[0]:
            have[c[0]] = (i + 2, c[9] or "")
    keys = set()
    for c in vals:
        try:
            if c[8] not in ("", None) and int(float(c[8])) > 0:
                keys.add((c[6], str(int(float(c[8])))))   # gleicher Start und gleiche Dauer ist dieselbe Sitzung
        except ValueError:
            pass
    new, upd = [], []
    for x in sessions:
        if not x.get("start") or not x.get("end"):
            continue
        sid = str(x.get("id"))
        if sid in have:
            rn, smod = have[sid]
            if (x.get("mod") or "") > smod:
                upd.append({"range": "Fokus!A%d:J%d" % (rn, rn), "values": [row(x)]})
        elif x.get("del") or (x["start"], str(int(round(float(x.get("ms") or 0))))) not in keys:
            new.append(row(x))
    if upd:
        _req(token, "POST", base + "/values:batchUpdate", {"valueInputOption": "RAW", "data": upd})
    if new:
        _req(token, "POST", base + "/values/" + urllib.parse.quote("Fokus!A1") + ":append?valueInputOption=RAW&insertDataOption=INSERT_ROWS", {"values": new})
    log("Fokus: %d Sitzungen neu, %d geaendert in der ToDo-Tabelle" % (len(new), len(upd)))
    return len(new) + len(upd)


def pull_fokus(token, sheet_id):
    """Liest alle Sitzungen aus dem Blatt Fokus (nur lesen). Gibt (Zeilen, Zahl uebersprungener Zeilen) zurueck."""
    base = "%s/%s" % (API, urllib.parse.quote(sheet_id, safe=""))
    out, skipped = [], 0
    for c in _read(token, base):
        if not c[0]:
            continue
        if not c[6] or not c[7]:
            skipped += 1
            continue
        try:
            ms = int(float(c[8] or 0))
        except ValueError:
            skipped += 1
            continue
        d = {"id": c[0], "ref": c[1], "title": c[2], "meta": c[3], "tags": [t.strip() for t in str(c[4]).split(",") if t.strip()],
             "next": c[5] == "1", "start": c[6], "end": c[7], "ms": ms, "mod": c[9] or ""}
        if ms <= 0:
            d["del"] = True
        out.append(d)
    return out[-900:], skipped


def todo_local_file():
    base = os.environ.get("XDG_DATA_HOME") or os.path.join(os.path.expanduser("~"), ".local", "share")
    return os.path.join(base, "seiffert-todo", "daten.json")


def effective_id(settings):
    """Tabellen-ID der ToDo-Tabelle: erst der eingetragene Wert, sonst die ID, die das Linux-ToDo lokal gemerkt hat (nur gelesen)."""
    v = (settings.get("todo_sheet_id") or "").strip()
    if v:
        return v, "eingetragen"
    try:
        with open(todo_local_file(), encoding="utf-8") as f:
            d = json.load(f)
        v = str(d.get("ssid") or "").strip() if isinstance(d, dict) else ""
        if v and all(c.isalnum() or c in "-_" for c in v):
            return v, "vom Linux-ToDo"
    except (OSError, ValueError):
        pass
    return "", ""
