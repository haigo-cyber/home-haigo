"""Formaterhaltendes Speichern von ODT-Dateien, die nicht aus Seifferts Text stammen.

Die Originaldatei wird nicht neu geschrieben. Es wird nur content.xml an den Stellen geändert,
an denen ein Absatz bearbeitet, eingefügt oder gelöscht wurde; alle anderen Bytes der Datei
(Vorlagen, Seitenformat, Tabellenbreiten, Schriften, Kopfzeilen, Bilder ...) bleiben, wie sie sind.
Was sich so nicht speichern lässt, löst PatchError aus; dann bleibt die Datei unangetastet.
"""
import os
import re
import shutil
import zipfile
from collections import Counter
from xml.parsers import expat
from xml.sax.saxutils import escape, quoteattr
import xml.etree.ElementTree as ET

from PySide6.QtGui import QTextFormat, QTextTable

from .common import PROP_SRC, PROP_RAW_BLOCK, PROP_RAW_INLINE, LS
from .readers import NS_ODF, q, local, esc

OBJ = "￼"
PLAIN = (False, False, False, False, 0, False, "", False)
_TAG = re.compile(rb'''(?:[^>"']|"[^"]*"|'[^']*')*>''')
_WS = re.compile(r"[ \t\r\n]+|[^ \t\r\n]")
_XMLNS = re.compile(r' xmlns:[\w.\-]+="[^"]*"')
_OUTTAG = re.compile(r"<[^<>]+>")
_IDS = re.compile(rb' (?:xml:id|[\w.\-]+:id)="[^"]*"')
SIMPLE_TAGS = {"span", "a", "s", "tab", "line-break", "soft-page-break"}
SKIP_TAGS = {"annotation", "bookmark", "bookmark-start", "bookmark-end", "soft-page-break",
             "tracked-changes", "change", "change-start", "change-end"}
FLAGS = (("b", 'fo:font-weight="bold" style:font-weight-asian="bold" style:font-weight-complex="bold"'),
         ("i", 'fo:font-style="italic" style:font-style-asian="italic" style:font-style-complex="italic"'),
         ("u", 'style:text-underline-style="solid" style:text-underline-width="auto" '
               'style:text-underline-color="font-color"'),
         ("s", 'style:text-line-through-style="solid" style:text-line-through-type="single"'),
         ("p", 'style:text-position="super 58%"'),
         ("d", 'style:text-position="sub 58%"'),
         ("t", 'style:font-name="Liberation Mono" fo:font-family="\'Liberation Mono\'" '
               'style:font-pitch="fixed"'))


class PatchError(Exception):
    """Die Änderung lässt sich nicht formaterhaltend in die Originaldatei schreiben."""


class _Fallback(Exception):
    pass


def is_own_file(path):
    """Datei wurde von Seifferts Text selbst geschrieben (dann darf sie neu geschrieben werden)."""
    try:
        with zipfile.ZipFile(path) as z:
            return "meta.xml" in z.namelist() and b"<meta:generator>Seifferts Text" in z.read("meta.xml")
    except Exception:
        return False


def fmt_key(cf):
    va = int(cf.verticalAlignment().value)
    return (cf.fontWeight() >= 600, bool(cf.fontItalic()), bool(cf.fontUnderline()) and not cf.isAnchor(),
            bool(cf.fontStrikeOut()), va if va in (1, 2) else 0, bool(cf.fontFixedPitch()),
            cf.anchorHref() if cf.isAnchor() else "", bool(cf.property(PROP_RAW_INLINE)))


def char_keys(blk):
    keys = []
    it = blk.begin()
    while not it.atEnd():
        fr = it.fragment()
        if fr.isValid():
            keys.extend([fmt_key(fr.charFormat())] * len(fr.text()))
        it += 1
    return keys


def block_sig(blk):
    bf = blk.blockFormat()
    lst = blk.textList()
    return (bf.headingLevel(), lst is not None,
            int(lst.format().style().value) if lst is not None else 0,
            lst.format().indent() if lst is not None else 0,
            int(bf.alignment().value) & 0x0f, bool(bf.property(PROP_RAW_BLOCK)),
            bf.intProperty(QTextFormat.Property.BlockQuoteLevel))


def iter_blocks(doc):
    blk = doc.begin()
    while blk.isValid():
        yield blk
        blk = blk.next()


def table_sig(doc):
    out = []

    def walk(frame):
        for f in frame.childFrames():
            if isinstance(f, QTextTable):
                spans = tuple((f.cellAt(r, c).rowSpan(), f.cellAt(r, c).columnSpan())
                              for r in range(f.rows()) for c in range(f.columns()))
                out.append((f.rows(), f.columns(), spans))
            walk(f)
    walk(doc.rootFrame())
    return out


def norm(s):
    return "".join(s.split())


def _snapshot(doc):
    """(Absätze mit Quelle, übrige Inhalte) des Dokuments."""
    cur, static = {}, Counter()
    for blk in iter_blocks(doc):
        src = blk.blockFormat().intProperty(PROP_SRC) - 1
        t = blk.text()
        if src < 0:
            if t:
                static[t] += 1
            continue
        cur.setdefault(src, []).append((t, char_keys(blk), block_sig(blk)))
    return cur, static


class OdtSource:
    def __init__(self, path, doc):
        self.path = os.path.abspath(path)
        with zipfile.ZipFile(path) as z:
            self.data = z.read("content.xml")
            self.names = set(z.namelist())
            self.sizes = {i.filename: i.file_size for i in z.infolist()}
        self.backed_up = False
        self._scan()
        self.base, self.static = _snapshot(doc)
        self.tables = table_sig(doc)
        if any(s >= len(self.paras) for s in self.base):
            raise PatchError("Die Absätze der Datei konnten nicht zugeordnet werden.")

    # ------------------------------------------------------------ Quelle vermessen
    def _scan(self):
        data = self.data
        p = expat.ParserCreate()
        self.ns = {}
        self.paras = []
        self.auto = None
        stack = []

        def tname(name):
            pre, _, loc = name.partition(":")
            return self.ns.get(pre), loc

        def start(name, attrs):
            for k, v in attrs.items():
                if k.startswith("xmlns:"):
                    self.ns.setdefault(k[6:], v)
            d = {"name": name, "start": p.CurrentByteIndex, "end": None,
                 "parent": stack[-1] if stack else None, "np": 0, "nc": 0}
            if stack:
                stack[-1]["nc"] += 1
            uri, loc = tname(name)
            if uri == NS_ODF["text"] and loc in ("p", "h"):
                if stack:
                    stack[-1]["np"] += 1
                self.paras.append(d)
            elif uri == NS_ODF["office"] and loc == "automatic-styles":
                self.auto = d
            stack.append(d)

        def end(name):
            d = stack.pop()
            i = p.CurrentByteIndex
            d["selfclose"] = (data[i - 2:i] == b"/>" and _TAG.match(data, d["start"]).end() == i)
            d["endtag"] = i
            d["end"] = i if d["selfclose"] else _TAG.match(data, i).end()

        p.StartElementHandler = start
        p.EndElementHandler = end
        p.Parse(data, True)
        self.pre = {uri: pre for pre, uri in self.ns.items()}
        if NS_ODF["text"] not in self.pre:
            raise PatchError("Unbekannter Aufbau der ODT-Datei.")
        self.tp = self.pre[NS_ODF["text"]]
        for pre, uri in self.ns.items():
            try:
                ET.register_namespace(pre, uri)
            except ValueError:
                pass
        self.wrap_open = ("<w" + "".join(' xmlns:%s=%s' % (k, quoteattr(v)) for k, v in self.ns.items())
                          + ">").encode("utf-8")

    def _local(self, d):
        return d["name"].partition(":")[2] if d else ""

    def _starttag(self, d, clean=False):
        st = self.data[d["start"]:_TAG.match(self.data, d["start"]).end()]
        if d["selfclose"]:
            st = st[:-2].rstrip() + b">"
        if clean:
            st = _IDS.sub(b"", st)
        return st

    def _endtag(self, d):
        return ("</%s>" % d["name"]).encode("utf-8")

    def _parse(self, frag):
        return ET.fromstring(self.wrap_open + frag + b"</w>")[0]

    # ------------------------------------------------------------ Abbild eines Absatzes
    def _project(self, el):
        """Zeichen des Absatzes, wie sie im Editor stehen, mit ihrer Herkunft im XML."""
        out = []

        def slot(holder, which):
            s = holder.text if which == "text" else holder.tail
            if not s:
                return
            for m in _WS.finditer(s):
                ch = m.group(0)
                out.append((" " if ch[0] in " \t\r\n" else ch, "t", holder, which, m.start(), m.end()))

        def atom(elem, text):
            for ch in text:
                out.append((ch, "e", elem, len(text)))

        def walk(e):
            slot(e, "text")
            for ch in e:
                tag = local(ch.tag)
                if tag == "span" and ch.get(q("text", "style-name")) == "Raw_20_Text":
                    atom(ch, "".join(ch.itertext()))
                elif tag in ("span", "a"):
                    walk(ch)
                elif tag == "s":
                    try:
                        atom(ch, " " * int(ch.get(q("text", "c"), "1")))
                    except ValueError:
                        atom(ch, " ")
                elif tag == "tab":
                    atom(ch, "    ")
                elif tag == "line-break":
                    atom(ch, LS)
                elif tag == "note":
                    body = ch.find(q("text", "note-body"))
                    parts = []
                    if body is not None:
                        for p in body.iter(q("text", "p")):
                            parts.append("".join(p.itertext()).strip())
                    atom(ch, "\\footnote{%s}" % esc(" ".join(x for x in parts if x)))
                elif tag == "frame":
                    img = ch.find(q("draw", "image"))
                    href = img.get(q("xlink", "href")) if img is not None else None
                    if href and not href.startswith("http") and self.sizes.get(href):
                        atom(ch, OBJ)
                elif tag in SKIP_TAGS:
                    pass
                else:
                    walk(ch)
                slot(ch, "tail")
        walk(el)
        a, b = 0, len(out)
        while a < b and out[a][0] == " ":
            a += 1
        while b > a and out[b - 1][0] == " ":
            b -= 1
        return out[a:b]

    # ------------------------------------------------------------ Textänderung im XML
    def _pieces(self, text, prev_space):
        """Text als Folge aus Zeichenketten und ODF-Elementen (Leerzeichen, Umbruch, Tabulator)."""
        out, buf = [], ""
        for ch in text:
            if ch == OBJ:
                raise PatchError("Es wurde ein Bild eingefügt.")
            if ch == " " and prev_space:
                el = ET.Element(q("text", "s"))
            elif ch == LS or ch == "\n":
                el = ET.Element(q("text", "line-break"))
            elif ch == "\t":
                el = ET.Element(q("text", "tab"))
            else:
                if ch >= " ":
                    buf += ch
                prev_space = ch == " "
                continue
            prev_space = True
            if buf:
                out.append(buf)
                buf = ""
            out.append(el)
        if buf:
            out.append(buf)
        return out

    def _edit(self, el, proj, P, E, ins):
        parent = {c: p for p in el.iter() for c in p}
        if 0 < P < len(proj) and proj[P - 1][1] == "e" and proj[P][1] == "e" and proj[P - 1][2] is proj[P][2]:
            raise _Fallback()
        if 0 < E < len(proj) and proj[E - 1][1] == "e" and proj[E][1] == "e" and proj[E - 1][2] is proj[E][2]:
            raise _Fallback()
        elem_del, text_del = {}, []
        for c in proj[P:E]:
            if c[1] == "t":
                text_del.append(c[2:6])
            else:
                elem_del[c[2]] = elem_del.get(c[2], 0) + 1
        if P > 0:
            c = proj[P - 1]
            slot = (c[2], c[3], c[5]) if c[1] == "t" else (c[2], "tail", 0)
            prev_space = c[0] == " "
        elif proj and proj[0][1] == "t":
            c = proj[0]
            slot = (c[2], c[3], c[4])
            prev_space = True
        else:
            slot = (el, "text", len(el.text or ""))
            prev_space = True
        for holder, which, a, b in sorted(text_del, key=lambda x: -x[2]):
            s = (holder.text if which == "text" else holder.tail) or ""
            s = s[:a] + s[b:]
            if which == "text":
                holder.text = s
            else:
                holder.tail = s
        for e, n in elem_del.items():
            if local(e.tag) == "s":
                try:
                    cnt = int(e.get(q("text", "c"), "1"))
                except ValueError:
                    cnt = 1
                if n < cnt:
                    e.set(q("text", "c"), str(cnt - n))
                    continue
            elif local(e.tag) not in ("line-break", "frame"):
                total = sum(1 for c in proj if c[1] == "e" and c[2] is e)
                if n < total:
                    raise _Fallback()
            par = parent[e]
            kids = list(par)
            i = kids.index(e)
            if e.tail:
                if i > 0:
                    kids[i - 1].tail = (kids[i - 1].tail or "") + e.tail
                else:
                    par.text = (par.text or "") + e.tail
            par.remove(e)
        pieces = self._pieces(ins, prev_space)
        if not pieces:
            return
        holder, which, off = slot
        s = (holder.text if which == "text" else holder.tail) or ""
        off = min(off, len(s))
        buf, after = s[:off], s[off:]
        if which == "text":
            container, idx = holder, 0
        else:
            container = parent[holder]
            idx = list(container).index(holder) + 1
        last = None

        def put(v):
            if last is not None:
                last.tail = v
            elif which == "text":
                holder.text = v
            else:
                holder.tail = v
        for pc in pieces:
            if isinstance(pc, str):
                buf += pc
            else:
                put(buf)
                buf = ""
                container.insert(idx, pc)
                idx += 1
                last = pc
        put(buf + after)

    def _serialize(self, d, el):
        inner = escape(el.text or "") + "".join(ET.tostring(c, encoding="unicode") for c in el)
        inner = _OUTTAG.sub(lambda m: _XMLNS.sub("", m.group(0)), inner)
        return self._starttag(d) + inner.encode("utf-8") + self._endtag(d)

    # ------------------------------------------------------------ Absatz neu erzeugen
    def _inline(self, text, keys, styles):
        tp = self.tp
        out = []
        i, n = 0, len(text)
        prev_space = True
        while i < n:
            j = i
            while j < n and keys[j] == keys[i]:
                j += 1
            b, it, u, st, va, tt, href, raw = keys[i]
            if raw:
                raise PatchError("LaTeX-Rohtext lässt sich nicht in diese ODT-Datei schreiben.")
            x = ""
            for pc in self._pieces(text[i:j], prev_space):
                x += escape(pc) if isinstance(pc, str) else "<%s:%s/>" % (tp, local(pc.tag))
            prev_space = text[j - 1] in (" ", LS, "\t")
            fl = "".join(f for f, on in zip("bius", (b, it, u, st)) if on)
            fl += "p" if va == 1 else ("d" if va == 2 else "")
            fl += "t" if tt else ""
            if fl:
                styles.add(fl)
                x = '<%s:span %s:style-name="SfT_%s">%s</%s:span>' % (tp, tp, fl, x, tp)
            if href:
                xl = self.pre.get(NS_ODF["xlink"])
                if not xl:
                    raise PatchError("Links lassen sich in diese ODT-Datei nicht schreiben.")
                x = '<%s:a %s:type="simple" %s:href=%s>%s</%s:a>' % (tp, xl, xl, quoteattr(href), x, tp)
            out.append(x)
            i = j
        return "".join(out).encode("utf-8")

    def _style_defs(self, styles):
        sp, fo = self.pre.get(NS_ODF["style"]), self.pre.get(NS_ODF["fo"])
        res = b""
        for fl in sorted(styles):
            name = ('%s:name="SfT_%s"' % (sp, fl)).encode()
            if name in self.data:
                continue
            props = " ".join(p for f, p in FLAGS if f in fl)
            props = props.replace("style:", sp + ":").replace("fo:", (fo or "fo") + ":")
            res += ('<%s:style %s:name="SfT_%s" %s:family="text"><%s:text-properties %s/></%s:style>'
                    % (sp, sp, fl, sp, sp, props, sp)).encode("utf-8")
        return res

    def _changed(self, d, old, new, styles):
        otext, okeys, _ = old
        ntext, nkeys, _ = new
        el = self._parse(self.data[d["start"]:d["end"]])
        proj = self._project(el)
        if "".join(c[0] for c in proj) == otext:
            P = 0
            m = min(len(otext), len(ntext))
            while P < m and otext[P] == ntext[P]:
                P += 1
            S = 0
            while S < m - P and otext[len(otext) - 1 - S] == ntext[len(ntext) - 1 - S]:
                S += 1
            eo, en = len(otext) - S, len(ntext) - S
            allowed = set()
            if P > 0:
                allowed.add(okeys[P - 1])
            if P < len(otext):
                allowed.add(okeys[P])
            if not otext:
                allowed.add(PLAIN)
            if okeys[:P] == nkeys[:P] and okeys[eo:] == nkeys[en:] and all(k in allowed for k in nkeys[P:en]):
                try:
                    self._edit(el, proj, P, eo, ntext[P:en])
                    return self._serialize(d, el)
                except _Fallback:
                    pass
        if any(local(e.tag) not in SIMPLE_TAGS for e in el.iter() if e is not el):
            raise PatchError("In einem Absatz mit Fußnote, Bild, Feld oder Ähnlichem wurde die "
                             "Zeichenformatierung geändert: „%s“" % ntext[:60])
        return self._starttag(d) + self._inline(ntext, nkeys, styles) + self._endtag(d)

    # ------------------------------------------------------------ neue content.xml
    def build(self, doc):
        if table_sig(doc) != self.tables:
            raise PatchError("Der Aufbau einer Tabelle wurde geändert (Zeilen, Spalten, verbundene Zellen) "
                             "oder eine Tabelle wurde eingefügt oder gelöscht.")
        cur, static = _snapshot(doc)
        if static != self.static:
            raise PatchError("Es wurde Inhalt eingefügt oder geändert, der keinem Absatz der Originaldatei "
                             "zugeordnet werden kann (zum Beispiel eingefügter formatierter Text, eine neue "
                             "Liste, Rohtext oder ein Umbau über die Markdown- oder LaTeX-Ansicht).")
        if any(s not in self.base for s in cur):
            raise PatchError("Unbekannter Absatz im Dokument.")
        tp = self.tp
        ops, styles, deleted = [], set(), []
        for src, olds in self.base.items():
            d = self.paras[src]
            news = cur.get(src)
            if len(olds) > 1:
                if news is None or [(x[0], x[2]) for x in news] != [(x[0], x[2]) for x in olds]:
                    raise PatchError("Ein Code-Absatz oder eine in der Datei wiederholte Tabellenzelle wurde geändert.")
                continue
            old = olds[0]
            if news is None:
                deleted.append(d)
                continue
            k = 0
            if len(news) > 1:
                def score(nb):
                    a, b = old[0], nb[0]
                    m = min(len(a), len(b))
                    P = 0
                    while P < m and a[P] == b[P]:
                        P += 1
                    S = 0
                    while S < m - P and a[len(a) - 1 - S] == b[len(b) - 1 - S]:
                        S += 1
                    return P + S
                k = max(range(len(news)), key=lambda j: (score(news[j]), -j))
            par = d["parent"]
            in_item = self._local(par) in ("list-item", "list-header")
            for j, nb in enumerate(news):
                if j == k:
                    if nb[2] != old[2]:
                        raise PatchError("Absatzart, Liste oder Ausrichtung wurde geändert: „%s“" % nb[0][:60])
                    if nb[0] != old[0] or nb[1] != old[1]:
                        ops.append((d["start"], d["end"], self._changed(d, old, nb, styles)))
                    continue
                if nb[2] == old[2]:
                    frag = self._starttag(d, True) + self._inline(nb[0], nb[1], styles) + self._endtag(d)
                    if in_item and nb[2][1]:
                        frag = self._starttag(par, True) + frag + self._endtag(par)
                        pos = par["start"] if j < k else par["end"]
                    else:
                        pos = d["start"] if j < k else d["end"]
                elif old[2][0] and nb[2][0] == 0 and not nb[2][1] and not nb[2][5]:
                    frag = (('<%s:p %s:style-name="Standard">' % (tp, tp)).encode()
                            + self._inline(nb[0], nb[1], styles) + ("</%s:p>" % tp).encode())
                    pos = d["start"] if j < k else d["end"]
                else:
                    raise PatchError("Absatzart, Liste oder Ausrichtung wurde geändert: „%s“" % nb[0][:60])
                ops.append((pos, pos, frag))
        # gelöschte Absätze
        loaded = Counter(id(self.paras[s]["parent"]) for s in self.base)
        gone = Counter(id(d["parent"]) for d in deleted)
        done = set()
        for d in deleted:
            par = d["parent"]
            pid = id(par)
            all_gone = gone[pid] == loaded[pid] and par is not None and par["np"] == gone[pid]
            pl = self._local(par)
            if pl == "table-cell" and all_gone and par["nc"] == par["np"]:
                if pid not in done:
                    done.add(pid)
                    st = self._starttag(d)
                    ops.append((d["start"], d["end"], st[:-1] + b"/>"))
                    continue
            elif pl in ("list-item", "list-header") and all_gone and par["nc"] == par["np"]:
                if pid not in done:
                    done.add(pid)
                    ops.append((par["start"], par["end"], b""))
                continue
            ops.append((d["start"], d["end"], b""))
        if styles:
            defs = self._style_defs(styles)
            if defs:
                if self.auto is None or self.auto["selfclose"]:
                    raise PatchError("Die Zeichenformatierung lässt sich in diese Datei nicht schreiben.")
                ops.append((self.auto["endtag"], self.auto["endtag"], defs))
        if not ops:
            return self.data
        ops = [o for _, o in sorted(enumerate(ops), key=lambda x: (x[1][0], x[1][1], x[0]))]
        out, pos = [], 0
        for a, b, rep in ops:
            if a < pos:
                raise PatchError("Die Änderungen überschneiden sich.")
            out.append(self.data[pos:a])
            out.append(rep)
            pos = b
        out.append(self.data[pos:])
        new = b"".join(out)
        try:
            ET.fromstring(new)
        except ET.ParseError as e:
            raise PatchError("Interner Fehler beim Zusammensetzen (%s)." % e)
        return new

    # ------------------------------------------------------------ Datei schreiben
    def save(self, doc, dest, check):
        """Schreibt nach dest. check(pfad) prüft die fertige Datei und liefert True, wenn der Text stimmt."""
        content = self.build(doc)
        dest = os.path.abspath(dest)
        tmp = dest + ".teil"
        try:
            with zipfile.ZipFile(self.path) as zin, zipfile.ZipFile(tmp, "w") as zout:
                infos = zin.infolist()
                infos.sort(key=lambda i: i.filename != "mimetype")
                for info in infos:
                    data = content if info.filename == "content.xml" else zin.read(info.filename)
                    ni = zipfile.ZipInfo(info.filename, info.date_time)
                    ni.compress_type = (zipfile.ZIP_STORED if info.filename == "mimetype"
                                        else info.compress_type)
                    ni.external_attr = info.external_attr
                    zout.writestr(ni, data)
            if not check(tmp):
                raise PatchError("Die Sicherheitsprüfung ist fehlgeschlagen: Die geschriebene Datei enthält "
                                 "nicht denselben Text wie das Dokument im Editor.")
            if dest == self.path and not self.backed_up:
                shutil.copy2(self.path, self.path + ".bak")
                self.backed_up = True
            os.replace(tmp, dest)
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)
