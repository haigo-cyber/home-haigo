"""Verwaltung von Seifferts Oberfläche aus Seifferts Dateien heraus: alle Einstellungen (surface.json), Autostart,
Starten, Beenden und Neuladen. Die Oberfläche selbst ist oberflaeche.py (GTK, eigener Prozess). Wird als Mischklasse in Backend eingebunden."""
from __future__ import annotations

import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import backend as B
import surfacecfg as SC

AppError = B.AppError
UID = os.getuid() if hasattr(os, "getuid") else "user"
SOCKET = os.path.join(tempfile.gettempdir(), "seiffert-oberflaeche-%s" % UID)
HERE = Path(__file__).resolve().parent


def _send(text: str, timeout: float = 0.5) -> bool:
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(timeout)
    try:
        s.connect(SOCKET)
        s.sendall(text.encode("utf-8"))
        return True
    except OSError:
        return False
    finally:
        s.close()


class SurfaceSetup:
    _gi_python_cache: tuple[float, str] | None = None
    _check_cache: tuple[float, dict] | None = None

    # ------------------------------------------------------------ Hilfen
    @staticmethod
    def _autostart_file_surface() -> Path:
        return Path(os.environ.get("XDG_CONFIG_HOME") or (Path.home() / ".config")) / "autostart" / "seiffert-oberflaeche.desktop"

    def _gi_python(self) -> str:
        """Ein Python, das GTK 3 über PyGObject laden kann (auf Arch das System-Python); leer, wenn keines gefunden wird."""
        c = SurfaceSetup._gi_python_cache
        if c and time.time() - c[0] < 60:
            return c[1]
        found = ""
        import glob
        cands = [shutil.which("python3"), "/usr/bin/python3", sys.executable, shutil.which("python")] + sorted(glob.glob("/usr/bin/python3.[0-9]*"), reverse=True)
        seen: set[str] = set()
        for cand in cands:
            if not cand or not os.path.exists(cand) or cand in seen:
                continue
            seen.add(cand)
            try:
                r = subprocess.run([cand, "-c", "import gi; gi.require_version('Gtk','3.0'); from gi.repository import Gtk"],
                                   capture_output=True, timeout=8)
            except (OSError, subprocess.SubprocessError):
                continue
            if r.returncode == 0:
                found = cand
                break
        SurfaceSetup._gi_python_cache = (time.time(), found)
        return found

    def _surface_cmd(self) -> list[str]:
        """Befehl, der die Oberfläche startet: installierter Befehl, sonst ein Python mit GTK und oberflaeche.py."""
        for p in (Path.home() / ".local" / "bin" / "seiffert-oberflaeche", shutil.which("seiffert-oberflaeche")):
            if p and os.access(str(p), os.X_OK):
                return [str(p)]
        return [self._gi_python() or "python3", str(HERE / "oberflaeche.py")]

    def _surface_running(self) -> bool:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(0.4)
        try:
            s.connect(SOCKET)
            return True
        except OSError:
            return False
        finally:
            s.close()

    def _surface_check(self) -> dict:
        c = SurfaceSetup._check_cache
        if c and time.time() - c[0] < 30:
            return c[1]
        out = {"gtk": False, "layer_shell": False, "layer_active": False}
        cmd = self._surface_cmd()
        try:
            r = subprocess.run(cmd + ["--check"], capture_output=True, text=True, timeout=10, stdin=subprocess.DEVNULL)
            import json
            if r.returncode == 0 and r.stdout.strip():
                out = json.loads(r.stdout.strip().splitlines()[-1])
        except (OSError, subprocess.SubprocessError, ValueError):
            pass
        SurfaceSetup._check_cache = (time.time(), out)
        return out

    @staticmethod
    def surface_alt_x() -> bool:
        """Gilt Alt+X als Tastenkürzel zum Beenden? (Einstellung der Oberfläche, gilt auch für Seifferts Dateien.)"""
        try:
            return bool(SC.load()["alt_x"])
        except Exception:  # noqa: BLE001
            return True

    # ------------------------------------------------------------ Schnittstelle
    def api_surface_get(self) -> dict:
        return {"conf": SC.load(), "defaults": dict(SC.SURFACE_DEFAULTS), "ranges": {k: list(v) for k, v in SC.INT_RANGES.items()}}

    def api_surface_set(self, patch: dict) -> dict:
        """Einstellungen der Oberfläche ändern (nur die übergebenen Felder) und eine laufende Oberfläche neu laden lassen."""
        if not isinstance(patch, dict):
            raise AppError("Einstellungen ungültig.")
        try:
            conf = SC.update(patch)
        except ValueError as e:
            raise AppError(str(e))
        except OSError as e:
            raise AppError("Die Einstellungen der Oberfläche lassen sich nicht speichern: %s" % e)
        _send("reload")
        return {"conf": conf}

    def api_surface_reset(self) -> dict:
        try:
            SC.save(dict(SC.SURFACE_DEFAULTS))
        except OSError as e:
            raise AppError("Die Einstellungen lassen sich nicht zurücksetzen: %s" % e)
        _send("reload")
        return {"conf": SC.load()}

    def api_surface_status(self, check: bool = False) -> dict:
        cmd = self._surface_cmd()
        st = {
            "running": self._surface_running(),
            "autostart": self._autostart_file_surface().exists(),
            "installed": len(cmd) == 1,
            "command": " ".join(cmd),
            "session": os.environ.get("XDG_SESSION_TYPE", ""),
            "desktop": os.environ.get("XDG_CURRENT_DESKTOP", ""),
            "starter_installed": bool(shutil.which("seiffert-starter") or (Path.home() / ".local" / "bin" / "seiffert-starter").exists()),
        }
        if check:
            st["check"] = self._surface_check()
        return st

    def api_surface_apply(self, autostart: bool) -> dict:
        """Autostart der Oberfläche ein- oder ausschalten (Datei in ~/.config/autostart, gilt auch unter COSMIC)."""
        f = self._autostart_file_surface()
        notes: list[str] = []
        if autostart:
            cmd = self._surface_cmd()
            if not self._gi_python() and len(cmd) > 1:
                raise AppError("Für die Oberfläche fehlt GTK 3 mit PyGObject. Arch: sudo pacman -S python-gobject gtk3 gtk-layer-shell librsvg")
            f.parent.mkdir(parents=True, exist_ok=True)
            f.write_text("[Desktop Entry]\nType=Application\nName=Seifferts Oberfläche\nComment=Hintergrund, Symbole und Starter-Symbol\n"
                         "Exec=%s --autostart\nIcon=seiffert-dateien\nTerminal=false\nX-GNOME-Autostart-enabled=true\n" % " ".join(cmd), encoding="utf-8")
            notes.append("Die Oberfläche startet künftig beim Anmelden.")
        else:
            try:
                f.unlink()
            except FileNotFoundError:
                pass
            notes.append("Die Oberfläche startet nicht mehr automatisch beim Anmelden.")
        st = self.api_surface_status()
        st["notes"] = notes
        return st

    def api_surface_control(self, action: str) -> dict:
        if action not in ("start", "stop", "restart", "reload"):
            raise AppError("Unbekannte Aktion.")
        cmd = self._surface_cmd()
        if action == "reload":
            if not _send("reload"):
                raise AppError("Die Oberfläche läuft gerade nicht.")
            return {"ok": True}
        if action in ("stop", "restart"):
            _send("quit")
            for _ in range(20):                            # bis zu zwei Sekunden warten, bis der Socket weg ist
                if not self._surface_running():
                    break
                time.sleep(0.1)
        if action in ("start", "restart"):
            if not self._gi_python() and len(cmd) > 1:
                raise AppError("Für die Oberfläche fehlt GTK 3 mit PyGObject. Arch: sudo pacman -S python-gobject gtk3 gtk-layer-shell librsvg")
            subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        return {"ok": True}
