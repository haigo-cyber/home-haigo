/* Seifferts Terminal: Syntaxfärbung ohne Abhängigkeiten.
   - matchRules(): zeilenweise Hervorhebung nach den Regeln aus den Einstellungen (für die Ausgabe im Terminal)
   - highlight(): Zerlegung ganzer Dateien nach Sprache (für „Datei in Farben anzeigen“)
   - toAnsi(): macht aus den Teilstücken Text mit 24-Bit-Farben für xterm.js */
(function (root) {
  "use strict";
  const W = (s) => new Set(s.split(/\s+/).filter(Boolean));

  const CLIKE_KW = W(`auto break case char const continue default do double else enum extern float for goto if inline int long register restrict return short signed sizeof static struct switch typedef union unsigned void volatile while class namespace template typename public private protected virtual override final new delete this using try catch throw bool true false nullptr null abstract interface extends implements import package instanceof synchronized boolean byte fn let mut pub impl trait use mod match loop where async await move ref dyn crate self Self as in func go defer chan map range select var type fallthrough string val fun object when is by data sealed companion lateinit open init guard protocol extension typealias foreach function echo global require include_once yield lambda`);
  const JS_KW = W(`break case catch class const continue debugger default delete do else export extends finally for function if import in instanceof let new of return static super switch this throw try typeof var void while with yield async await from as type interface enum implements public private protected readonly abstract namespace declare keyof null true false undefined NaN get set`);
  const PY_KW = W(`and as assert async await break class continue def del elif else except finally for from global if import in is lambda nonlocal not or pass raise return try while with yield match case None True False self cls`);
  const SH_KW = W(`if then else elif fi for while until do done case esac in function select time return exit break continue local export readonly declare unset source alias set shift trap eval exec`);
  const SQL_KW = W(`select from where and or not in is null as join left right inner outer full cross on group by order having limit offset insert into values update set delete create table alter drop index view primary key foreign references unique default distinct union all case when then else end exists between like ilike count sum avg min max asc desc with begin commit rollback true false`);
  const SCRIPT_KW = W(`def end class module if elsif elif else unless while until for do begin rescue ensure return yield require include my our sub use strict local function print foreach FROM RUN CMD COPY ADD ENV EXPOSE WORKDIR ENTRYPOINT then fi nil true false not and or`);
  const YAML_KW = W(`true false null yes no on off True False Null`);

  const B = "(?<![^\\n])";                       // Zeilenanfang
  const S = (re) => new RegExp(re, "y");

  const LANGS = {
    python: { line: ["#"], block: [], strings: ['"""', "'''", '"', "'"], kw: PY_KW, capType: true,
      special: [[S(B + "[ \\t]*@[\\w.]+"), "var"]] },
    js: { line: ["//"], block: [["/*", "*/"]], strings: ["`", '"', "'"], kw: JS_KW, capType: true, multi: ["`"] },
    clike: { line: ["//"], block: [["/*", "*/"]], strings: ['"'], kw: CLIKE_KW, capType: true,
      special: [[S("'(?:\\\\.|[^'\\\\\\n])+'"), "str"], [S(B + "[ \\t]*#[ \\t]*[a-z]+"), "kw"]] },
    shell: { line: ["#"], block: [], strings: ['"', "'"], rawStrings: ["'"], kw: SH_KW,
      special: [[S("\\$\\{[^}\\n]*\\}|\\$[A-Za-z_]\\w*|\\$[0-9@#?!$*-]"), "var"], [S("(?<=\\s)--?[A-Za-z][\\w-]*"), "op"]] },
    json: { line: [], block: [], strings: ['"'], kw: W("true false null"),
      special: [[S('"(?:[^"\\\\\\n]|\\\\.)*"(?=\\s*:)'), "type"]] },
    html: { line: [], block: [], strings: [], kw: new Set(), noNum: true, noIdent: true,
      special: [[S("<!--[\\s\\S]*?-->"), "com"], [S("<![A-Za-z][^>]*>"), "com"], [S("<\\/?[A-Za-z][\\w:.-]*"), "kw"], [S("\\/?>"), "kw"],
        [S("[A-Za-z_:@][\\w:.@-]*(?==)"), "type"], [S("(?<==)(?:\"[^\"]*\"|'[^']*')"), "str"], [S("&#?\\w+;"), "num"]] },
    css: { line: [], block: [["/*", "*/"]], strings: ['"', "'"], kw: new Set(),
      special: [[S("@[\\w-]+"), "kw"], [S("!important"), "kw"], [S("#[0-9a-fA-F]{3,8}\\b"), "num"],
        [S("[.#][A-Za-z_-][\\w-]*(?=[^;{}]*\\{)"), "type"], [S("[A-Za-z-]+(?=\\s*:(?!:))"), "var"]] },
    md: { line: [], block: [], strings: [], kw: new Set(), noNum: true, noIdent: true,
      special: [[S(B + "#{1,6}[ \\t].*"), "kw"], [S(B + "```[\\s\\S]*?(?:```|(?![\\s\\S]))"), "str"], [S("`[^`\\n]+`"), "str"],
        [S("\\[[^\\]\\n]*\\]\\([^)\\n]*\\)"), "url"], [S("\\*\\*[^*\\n]+\\*\\*"), "type"], [S(B + "[ \\t]*(?:[-*+]|\\d+\\.)(?=[ \\t])"), "op"], [S(B + ">.*"), "com"]] },
    tex: { line: ["%"], block: [], strings: [], kw: new Set(), noIdent: true,
      special: [[S("\\\\[A-Za-z@]+\\*?"), "kw"], [S("\\\\[^A-Za-z\\s]"), "op"], [S("\\$\\$[\\s\\S]*?\\$\\$|\\$[^$\\n]+\\$"), "str"], [S("[{}\\[\\]]"), "op"]] },
    yaml: { line: ["#"], block: [], strings: ['"', "'"], kw: YAML_KW,
      special: [[S(B + "[ \\t-]*[A-Za-z_][\\w.-]*(?=\\s*:)"), "type"]] },
    ini: { line: ["#", ";"], block: [], strings: ['"', "'"], kw: YAML_KW,
      special: [[S(B + "\\[[^\\]\\n]+\\]"), "kw"], [S(B + "[A-Za-z_][\\w.-]*(?=\\s*=)"), "type"]] },
    sql: { line: ["--"], block: [["/*", "*/"]], strings: ["'", '"'], kw: SQL_KW, ci: true },
    diff: { line: [], block: [], strings: [], kw: new Set(), noNum: true, noIdent: true,
      special: [[S(B + "(?:diff |index ).*"), "kw"], [S(B + "(?:\\+\\+\\+|---) .*"), "kw"], [S(B + "@@.*@@.*"), "info"],
        [S(B + "\\+.*"), "add"], [S(B + "-.*"), "del"]] },
    script: { line: ["#"], block: [], strings: ['"', "'"], kw: SCRIPT_KW, capType: true,
      special: [[S("\\$\\{[^}\\n]*\\}|\\$[A-Za-z_]\\w*"), "var"]] },
  };

  const EXT = {
    py: "python", pyw: "python", js: "js", mjs: "js", cjs: "js", ts: "js", jsx: "js", tsx: "js",
    c: "clike", h: "clike", cpp: "clike", hpp: "clike", cc: "clike", cxx: "clike", java: "clike", cs: "clike", go: "clike", rs: "clike",
    kt: "clike", kts: "clike", swift: "clike", dart: "clike", scala: "clike", php: "clike", sol: "clike", vue: "html",
    sh: "shell", bash: "shell", zsh: "shell", fish: "shell", ksh: "shell", profile: "shell", bashrc: "shell", zshrc: "shell",
    json: "json", jsonl: "json", ndjson: "json", geojson: "json",
    html: "html", htm: "html", xhtml: "html", xml: "html", svg: "html", gpx: "html", kml: "html", opml: "html", ui: "html",
    css: "css", scss: "css", less: "css", md: "md", markdown: "md", rst: "md", adoc: "md",
    tex: "tex", ltx: "tex", sty: "tex", cls: "tex", bib: "tex", dtx: "tex",
    yml: "yaml", yaml: "yaml", toml: "ini", ini: "ini", cfg: "ini", conf: "ini", desktop: "ini", properties: "ini", service: "ini",
    sql: "sql", diff: "diff", patch: "diff", rb: "script", pl: "script", pm: "script", r: "script", lua: "script", ps1: "script",
    mk: "script", cmake: "script", gradle: "clike", tf: "script",
  };
  const NAMES = { makefile: "script", dockerfile: "script", pkgbuild: "shell", cmakelists: "script", ".bashrc": "shell", ".zshrc": "shell", ".profile": "shell" };

  function detect(name, text) {
    const base = String(name || "").toLowerCase().split("/").pop();
    if (NAMES[base]) return NAMES[base];
    const ext = base.includes(".") ? base.split(".").pop() : "";
    if (EXT[ext]) return EXT[ext];
    const m = /^#!\s*(?:\/usr\/bin\/env\s+)?(\S+)/.exec(text || "");
    if (m) {
      const p = m[1].split("/").pop();
      if (/^(ba|z|k|da|fi)?sh$/.test(p)) return "shell";
      if (/^python/.test(p)) return "python";
      if (/^(node|deno|bun)$/.test(p)) return "js";
      if (/^(ruby|perl|lua|Rscript)$/.test(p)) return "script";
    }
    const head = (text || "").slice(0, 300).trimStart();
    if (/^\{[\s\S]*"/.test(head) || /^\[\s*[{"\d]/.test(head)) return "json";
    if (/^<\?xml|^<!DOCTYPE html|^<html/i.test(head)) return "html";
    if (/^diff --git|^--- .*\n\+\+\+ /.test(head)) return "diff";
    return "";
  }

  const DEF_TYPE = W("class struct enum interface trait impl type namespace module package union");
  const DEF_FN = W("def function fn func fun sub");
  const NUM_RE = /(?:0[xX][0-9a-fA-F_]+|0[bB][01_]+|\d[\d_]*(?:\.\d+)?(?:[eE][+-]?\d+)?[A-Za-z%]*|\.\d+(?:[eE][+-]?\d+)?[A-Za-z%]*)/y;
  const ID_RE = /[A-Za-z_$À-￿][\w$À-￿]*/y;
  const OP_RE = /[+\-*\/%=<>!&|^~?]+/y;

  /** Zerlegt Text in Teilstücke [Klasse|null, Text]. Teilstücke dürfen Zeilenumbrüche enthalten. */
  function tokenize(text, L) {
    const spans = [];
    let plain = "", i = 0;
    const n = text.length;
    const flush = () => { if (plain) { spans.push([null, plain]); plain = ""; } };
    const emit = (cls, s) => { flush(); spans.push([cls, s]); };
    let kwId = "", kwEnd = -1;                                  // letztes Schlüsselwort (für „class Foo“, „def name“)
    outer:
    while (i < n) {
      const c = text[i];
      if (L.special) {
        for (const [re, cls] of L.special) {
          re.lastIndex = i;
          const m = re.exec(text);
          if (m && m[0].length) { emit(cls, m[0]); i += m[0].length; continue outer; }
        }
      }
      for (const [o, cl] of L.block) {
        if (text.startsWith(o, i)) {
          let j = text.indexOf(cl, i + o.length);
          j = j < 0 ? n : j + cl.length;
          emit("com", text.slice(i, j)); i = j; continue outer;
        }
      }
      for (const p of L.line) {
        if (text.startsWith(p, i) && !(p === "#" && i > 0 && /[\w$&#]/.test(text[i - 1]))) {
          let j = text.indexOf("\n", i);
          if (j < 0) j = n;
          emit("com", text.slice(i, j)); i = j; continue outer;
        }
      }
      for (const d of L.strings) {
        if (!text.startsWith(d, i)) continue;
        const triple = d.length === 3 || (L.multi && L.multi.includes(d));
        const esc = !(L.rawStrings && L.rawStrings.includes(d));
        let j = i + d.length;
        while (j < n) {
          if (esc && text[j] === "\\") { j += 2; continue; }
          if (text.startsWith(d, j)) { j += d.length; break; }
          if (!triple && text[j] === "\n") break;
          j++;
        }
        j = Math.min(j, n);
        emit("str", text.slice(i, j)); i = j; continue outer;
      }
      if (!L.noNum && (c >= "0" && c <= "9" || c === "." && text[i + 1] >= "0" && text[i + 1] <= "9") && !(i > 0 && /[\w$]/.test(text[i - 1]))) {
        NUM_RE.lastIndex = i;
        const m = NUM_RE.exec(text);
        if (m) { emit("num", m[0]); i += m[0].length; continue; }
      }
      if (!L.noIdent) {
        ID_RE.lastIndex = i;
        const m = ID_RE.exec(text);
        if (m) {
          const id = m[0], key = L.ci ? id.toLowerCase() : id;
          let cls = null;
          if (L.kw.has(key)) { cls = "kw"; kwId = key; kwEnd = i + id.length; }
          else if (kwEnd >= 0 && /^[ \t]+$/.test(text.slice(kwEnd, i)) && (DEF_TYPE.has(kwId) || DEF_FN.has(kwId))) cls = DEF_TYPE.has(kwId) ? "type" : "fn";
          else {
            let k = i + id.length;
            while (text[k] === " " || text[k] === "\t") k++;
            if (text[k] === "(") cls = "fn";
            else if (L.capType && /^[A-Z][A-Za-z0-9]*[a-z]/.test(id)) cls = "type";
          }
          if (cls) emit(cls, id); else plain += id;
          i += id.length; continue;
        }
        if (!L.noOp) {
          OP_RE.lastIndex = i;
          const o = OP_RE.exec(text);
          if (o) { emit("op", o[0]); i += o[0].length; continue; }
        }
      }
      plain += c; i++;
    }
    flush();
    return spans;
  }

  /** Teilstücke durch Zeilenumbrüche trennen: Liste von Zeilen, jede eine Liste von [Klasse|null, Text]. */
  function splitLines(spans) {
    const lines = [[]];
    for (const [cls, t] of spans) {
      const parts = t.split("\n");
      parts.forEach((p, k) => {
        if (k > 0) lines.push([]);
        if (p) lines[lines.length - 1].push([cls, p]);
      });
    }
    return lines;
  }

  /** Regeln anwenden (Zeile für Zeile). rules: [{re, color, bg}] mit globalem RegExp. plain: optional Liste (je Zeichen true = ohne eigene Farbe).
      Gibt nicht überlappende Treffer [{start, end, color, bg}] zurück; Regeln weiter vorn haben Vorrang. */
  function matchRules(s, rules, plain) {
    const out = [];
    if (!s) return out;
    const claimed = new Uint8Array(s.length);
    for (const r of rules) {
      r.re.lastIndex = 0;
      let m, guard = 0;
      while ((m = r.re.exec(s)) && guard++ < 500) {
        const len = m[0].length;
        if (!len) { r.re.lastIndex++; continue; }
        const a = m.index, b = a + len;
        let free = true;
        for (let k = a; k < b; k++) { if (claimed[k] || (plain && plain[k] === false)) { free = false; break; } }
        if (!free) continue;
        claimed.fill(1, a, b);
        out.push({ start: a, end: b, color: r.color, bg: r.bg || "" });
      }
    }
    return out.sort((x, y) => x.start - y.start);
  }

  /** Eine Zeile nach Regeln in Teilstücke zerlegen (Rückfall für Dateien ohne bekannte Sprache). */
  function ruleSpans(line, rules) {
    const ms = matchRules(line, rules, null);
    const out = [];
    let pos = 0;
    for (const m of ms) {
      if (m.start > pos) out.push([null, line.slice(pos, m.start)]);
      out.push([m.color, line.slice(m.start, m.end)]);
      pos = m.end;
    }
    if (pos < line.length) out.push([null, line.slice(pos)]);
    return out;
  }

  /** Datei farbig zerlegen. Gibt { lang, lines } zurück; lines = Liste von Zeilen mit [Klasse|Farbe|null, Text]. */
  function highlight(text, name, rules) {
    const lang = detect(name, text);
    if (lang && LANGS[lang]) return { lang, lines: splitLines(tokenize(text, LANGS[lang])) };
    return { lang: "", lines: text.split("\n").map((l) => ruleSpans(l, rules || [])) };
  }

  const hex2rgb = (h) => { h = h.replace("#", ""); if (h.length === 3) h = h.replace(/./g, "$&$&"); return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)]; };
  const sgr = (h) => "\x1b[38;2;" + hex2rgb(h).join(";") + "m";

  /** Fertigt Text für xterm.js: Zeilen mit Zeilennummern und 24-Bit-Farben. colors: Klasse → #rrggbb; fg und dim für Text und Nummern. */
  function toAnsi(lines, colors, opts) {
    opts = opts || {};
    const tab = opts.tab || 4;
    const width = String(lines.length).length;
    const out = [];
    lines.forEach((ln, idx) => {
      let s = "";
      if (opts.numbers !== false) s += sgr(colors.dim) + String(idx + 1).padStart(width, " ") + " │ " + "\x1b[0m";
      let col = 0;
      for (const [cls, t] of ln) {
        let text = "";
        for (const ch of t.replace(/\r/g, "")) {
          if (ch === "\t") { const k = tab - (col % tab); text += " ".repeat(k); col += k; }
          else { text += ch.replace(/[\x00-\x08\x0b-\x1f\x7f]/g, "·"); col++; }
        }
        const colr = cls ? (cls[0] === "#" ? cls : colors[cls]) : null;
        s += colr ? sgr(colr) + text + "\x1b[0m" : text;
      }
      out.push(s);
    });
    return out.join("\r\n") + "\r\n";
  }

  const lib = { LANGS, detect, tokenize, splitLines, matchRules, ruleSpans, highlight, toAnsi };
  if (typeof module !== "undefined" && module.exports) module.exports = lib; else root.SyntaxLib = lib;
})(typeof window !== "undefined" ? window : globalThis);
