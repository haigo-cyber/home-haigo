import json, os, sys, tempfile, threading, time, urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1])); sys.path.insert(0, str(Path(__file__).resolve().parent))
os.environ["HOME"] = tempfile.mkdtemp(); os.environ.pop("XDG_CONFIG_HOME", None); os.environ.pop("XDG_DATA_HOME", None)
rows = [["id","ref","title","meta","tags","next","start","end","ms"], ["t|1","task:a","Alt","","job","0","2026-11-20T08:00:00.000Z","2026-11-20T08:10:00.000Z","600000"]]
calls = []; sheet = {"exists": True}
class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _j(self, o, c=200):
        b = json.dumps(o).encode(); self.send_response(c); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        calls.append("GET " + self.path)
        if self.headers.get("Authorization") != "Bearer TESTTOKEN": return self._j({}, 401)
        if not sheet["exists"]: return self._j({"error": "range"}, 400)
        self._j({"values": [r for r in rows[1:]] if "A2%3AJ" in self.path else [[r[0]] for r in rows[1:]]})
    def do_POST(self):
        calls.append("POST " + self.path)
        n = int(self.headers.get("Content-Length") or 0); b = json.loads(self.rfile.read(n))
        rows.extend(b["values"]); self._j({})
httpd = ThreadingHTTPServer(("127.0.0.1", 0), H); threading.Thread(target=httpd.serve_forever, daemon=True).start()
os.environ["SZ_SHEETS_API"] = "http://127.0.0.1:%d/v4/spreadsheets" % httpd.server_address[1]
from seiffert_zeit import sheets
from seiffert_zeit.config import Settings
from seiffert_zeit.store import Store
from seiffert_zeit.server import App
_n = lambda i: sum(map(ord, i))
S = lambda i, t="Neu": {"id": i, "ref": "", "title": t, "meta": "", "tags": [], "next": False, "start": "2026-11-22T09:%02d:00.000Z" % (_n(i) % 50), "end": "2026-11-22T10:59:00.000Z", "ms": 1800000 + _n(i) * 1000}
ok = 0
def chk(n, c):
    global ok
    assert c, n; ok += 1; print("ok  ", n)
# Direkt
chk("neue Sitzung wird angehaengt", sheets.push_fokus("TESTTOKEN", "SID", [S("z|1")]) == 1 and rows[-1][0] == "z|1" and rows[-1][8] == str(1800000 + _n("z|1") * 1000) and rows[-1][5] == "0")
chk("zweiter Push schreibt nichts doppelt", sheets.push_fokus("TESTTOKEN", "SID", [S("z|1"), {"id": "t|1", "start": "x", "end": "y"}]) == 0 and len(rows) == 3)
chk("bestehende Zeile unveraendert", rows[1][2] == "Alt")
sheet["exists"] = False
try: sheets.push_fokus("TESTTOKEN", "SID", [S("z|2")]); chk("fehlendes Blatt meldet Fehler", False)
except sheets.SheetsError as e: chk("fehlendes Blatt meldet Fehler, legt nichts an", "fehlt" in str(e) and len(rows) == 3)
sheet["exists"] = True
# Ueber den Server
s = Settings(); st = Store(s); a = App(s, st, lambda: None); a.start()
def call(path, body):
    r = urllib.request.Request("http://127.0.0.1:%d/%s/api/%s" % (a.port, a.secret, path), method="POST", data=json.dumps(body).encode(), headers={"Content-Type": "application/json", "Host": "127.0.0.1:%d" % a.port})
    return json.loads(urllib.request.urlopen(r).read())
r = call("fokus/push", {"rows": [S("z|3")]}); chk("ohne Tabellen-ID: nichts geschrieben, klare Meldung", r["ok"] is False and len(rows) == 3)
call("settings", {"todo_sheet_id": "SID"})
r = call("fokus/push", {"rows": [S("z|3")]}); chk("ohne Anmeldung: nichts geschrieben", r["ok"] is False and len(rows) == 3)
a.sync.drive.set_token("TESTTOKEN", 3600)
r = call("fokus/push", {"rows": [S("z|3"), S("z|4")]}); chk("mit Anmeldung: 2 Sitzungen geschrieben", r["ok"] and r["n"] == 2 and len(rows) == 5)
r = call("fokus/push", {"rows": [S("z|3"), S("z|4")]}); chk("wiederholt: keine Doppelten", r["n"] == 0 and len(rows) == 5)
page = urllib.request.urlopen(a.url()).read().decode()
chk("Seite hat Fokus-Reiter und Scope-Erweiterung", "vFokus" in page and "linuxsheets" in page)
import webbrowser; opened = []; webbrowser.open = lambda u: opened.append(u) or True
s.set(handoff_url="https://example.invalid/zeit.html", client_id="cid"); call("settings", {"todo_sheet_id": "SID"})
a.sync.begin_login(); chk("Anmeldung mit linuxsheets, wenn Tabelle eingetragen", "linuxsheets=1" in opened[-1])
call("settings", {"todo_sheet_id": ""}); a.sync.begin_login(); chk("ohne Tabelle: Scope unveraendert (kein linuxsheets)", "linuxsheets" not in opened[-1])
call("settings", {"todo_sheet_id": "SID"})
rows.append(["t|9","task:x","Aus ToDo","","evt,job","0","2026-11-22T07:00:00.000Z","2026-11-22T12:00:00.000Z","18000000"])
r = call("fokus/pull", {}); got = [x for x in r["rows"] if x["id"] == "t|9"]
chk("Pull liest Sitzung aus ToDo-Tabelle", r["ok"] and got and got[0]["ms"] == 18000000 and got[0]["tags"] == ["evt", "job"])
chk("Pull ohne Anmeldung liefert nichts", (setattr(a.sync.drive, "token", None), call("fokus/pull", {}))[1]["ok"] is False)
# ID automatisch aus der lokalen ToDo-Datei
call("settings", {"todo_sheet_id": ""})
chk("ohne ID und ohne ToDo-Datei: nichts", sheets.effective_id(s) == ("", ""))
td = Path(os.environ["HOME"]) / ".local" / "share" / "seiffert-todo"; td.mkdir(parents=True)
(td / "daten.json").write_text(json.dumps({"ssid": "AUTO_ID-1", "tasks": []}))
os.environ.pop("XDG_DATA_HOME", None)
chk("ID wird aus dem Linux-ToDo gelesen", sheets.effective_id(s) == ("AUTO_ID-1", "vom Linux-ToDo"))
a.sync.drive.set_token("TESTTOKEN", 3600)
r = call("fokus/pull", {}); chk("Pull funktioniert mit automatischer ID", r["ok"] and r["src"] == "vom Linux-ToDo")
(td / "daten.json").write_text(json.dumps({"ssid": "../böse"}))
chk("unsichere ID wird abgelehnt", sheets.effective_id(s)[0] == "")
call("settings", {"todo_sheet_id": "MANUELL"}); chk("eingetragene ID hat Vorrang", sheets.effective_id(s) == ("MANUELL", "eingetragen"))
# Schutz gegen Doppelte: gleicher Start und gleiche Dauer unter anderer id wird nicht angehaengt
call("settings", {"todo_sheet_id": "SID"}); a.sync.drive.set_token("TESTTOKEN", 3600)
d = S("z|dup"); d["start"], d["ms"] = rows[1][6], int(rows[1][8])
chk("gleiche Sitzung unter anderer id wird nicht doppelt angehaengt", sheets.push_fokus("TESTTOKEN", "SID", [d]) == 0)
print("FOKUS-TESTS OK:", ok)
