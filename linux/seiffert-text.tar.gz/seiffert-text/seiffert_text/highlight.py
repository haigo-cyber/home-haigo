"""Syntaxfärbung für LaTeX und Markdown."""
import re

from PySide6.QtCore import QRegularExpression
from PySide6.QtGui import QColor, QFont, QSyntaxHighlighter, QTextCharFormat


def _fmt(color, bold=False, italic=False):
    f = QTextCharFormat()
    f.setForeground(QColor(color))
    if bold:
        f.setFontWeight(QFont.Weight.Bold)
    if italic:
        f.setFontItalic(True)
    return f


def palette(dark):
    if dark:
        return dict(cmd="#7ab7ff", env="#e6c07b", comment="#7f8c8d", math="#c3a6ff", brace="#d19a66",
                    head="#7ab7ff", code="#98c379", link="#61afef", mark="#e5c07b")
    return dict(cmd="#0b5ea8", env="#9a5b00", comment="#7a7a7a", math="#6f42c1", brace="#b05a00",
                head="#0b5ea8", code="#2e7d32", link="#1a5fb4", mark="#9a5b00")


class LatexHighlighter(QSyntaxHighlighter):
    def __init__(self, doc, dark=False):
        super().__init__(doc)
        self.set_dark(dark)

    def set_dark(self, dark):
        p = palette(dark)
        self.f = {k: _fmt(v, bold=k in ("env", "head")) for k, v in p.items()}
        self.f["comment"] = _fmt(p["comment"], italic=True)
        self.rehighlight()

    def highlightBlock(self, text):
        for m in re.finditer(r"\\[A-Za-z@]+\*?|\\.", text):
            self.setFormat(m.start(), m.end() - m.start(), self.f["cmd"])
        for m in re.finditer(r"\\(?:begin|end)\{[^}]*\}", text):
            self.setFormat(m.start(), m.end() - m.start(), self.f["env"])
        for m in re.finditer(r"(?<!\\)\$\$?[^$]*\$\$?", text):
            self.setFormat(m.start(), m.end() - m.start(), self.f["math"])
        for m in re.finditer(r"[{}\[\]]", text):
            self.setFormat(m.start(), 1, self.f["brace"])
        m = re.search(r"(?<!\\)%.*$", text)
        if m:
            self.setFormat(m.start(), m.end() - m.start(), self.f["comment"])


class MarkdownHighlighter(QSyntaxHighlighter):
    def __init__(self, doc, dark=False):
        super().__init__(doc)
        self.set_dark(dark)

    def set_dark(self, dark):
        p = palette(dark)
        self.f = {"head": _fmt(p["head"], bold=True), "code": _fmt(p["code"]), "link": _fmt(p["link"]),
                  "mark": _fmt(p["mark"], bold=True), "bold": _fmt(p["cmd"], bold=True),
                  "ital": _fmt(p["cmd"], italic=True), "quote": _fmt(p["comment"], italic=True)}
        self.rehighlight()

    def highlightBlock(self, text):
        if re.match(r"^\s{0,3}#{1,6}\s", text):
            self.setFormat(0, len(text), self.f["head"])
            return
        if re.match(r"^\s*>", text):
            self.setFormat(0, len(text), self.f["quote"])
        if text.startswith("```") or text.startswith("~~~"):
            self.setFormat(0, len(text), self.f["code"])
        m = re.match(r"^\s*(?:[-*+]|\d+[.)])\s", text)
        if m:
            self.setFormat(m.start(), m.end() - m.start(), self.f["mark"])
        for m in re.finditer(r"`[^`]+`", text):
            self.setFormat(m.start(), m.end() - m.start(), self.f["code"])
        for m in re.finditer(r"\*\*[^*]+\*\*|__[^_]+__", text):
            self.setFormat(m.start(), m.end() - m.start(), self.f["bold"])
        for m in re.finditer(r"(?<![*\w])\*[^*\s][^*]*\*(?!\*)|(?<![_\w])_[^_\s][^_]*_(?!\w)", text):
            self.setFormat(m.start(), m.end() - m.start(), self.f["ital"])
        for m in re.finditer(r"!?\[[^\]]*\]\([^)]*\)", text):
            self.setFormat(m.start(), m.end() - m.start(), self.f["link"])
        if re.match(r"^\s*\|", text):
            self.setFormat(0, len(text), self.f["mark"])


# ---------------------------------------------------------------------------------------------
# Ansicht „Coding“: Farben für Programmcode und LaTeX
# ---------------------------------------------------------------------------------------------
def code_palette(dark):
    if dark:
        return dict(kw="#c678dd", ty="#56b6c2", const="#d19a66", str="#98c379", com="#7f8c8d", num="#d19a66",
                    fn="#61afef", deco="#e5c07b", tag="#e06c75", attr="#d19a66", var="#56b6c2", op="#abb2bf",
                    sec="#61afef", env="#e5c07b", math="#c3a6ff")
    return dict(kw="#8a2fa8", ty="#0b6ea8", const="#b35900", str="#2e7d32", com="#7a7a7a", num="#b35900",
                fn="#1a5fb4", deco="#9a5b00", tag="#a6192e", attr="#9a5b00", var="#0b6ea8", op="#555555",
                sec="#0b4f9c", env="#9a5b00", math="#6f42c1")


def _w(s):
    return frozenset(s.split())


_PY_TY = _w("int str float bool list dict set tuple bytes bytearray object type len range print open isinstance "
            "issubclass super self cls enumerate zip map filter sorted reversed min max sum abs any all repr id "
            "input iter next hash round format vars dir getattr setattr hasattr callable property staticmethod "
            "classmethod Exception ValueError TypeError KeyError IndexError OSError RuntimeError")
_JS_TY = _w("Array Object String Number Boolean Promise Map Set WeakMap Date Math JSON console window document "
            "Error RegExp Symbol parseInt parseFloat setTimeout setInterval require module exports process "
            "string number boolean any void never unknown")
_C_TY = _w("int char short long float double void unsigned signed size_t bool string vector map set auto "
           "uint8_t uint16_t uint32_t uint64_t int8_t int16_t int32_t int64_t FILE NULL std byte String Integer "
           "Object List Map Set Boolean Double Float Long")

# Sprachen: kw Schlüsselwörter, ty Typen und eingebaute Namen, const Konstanten, lc Zeilenkommentare,
# ml mehrzeilige Stücke (Beginn, Ende, Farbe), st Zeichenketten, extra (Muster, Farbe).
_STR_DQ = r'"(?:\\.|[^"\\])*(?:"|$)'
_STR_SQ = r"'(?:\\.|[^'\\])*(?:'|$)"
LANGS = {
    "python": dict(
        kw=_w("and as assert async await break class continue def del elif else except finally for from global if "
              "import in is lambda nonlocal not or pass raise return try while with yield match case"),
        ty=_PY_TY, const=_w("True False None"), lc=[r"#"],
        ml=[(r'[rRbBuUfF]{0,2}"""', '"""', "str"), (r"[rRbBuUfF]{0,2}'''", "'''", "str")],
        st=[r"[rRbBuUfF]{0,2}" + _STR_DQ, r"[rRbBuUfF]{0,2}" + _STR_SQ],
        extra=[(r"^\s*@[\w.]+", "deco")], defs=_w("def class")),
    "javascript": dict(
        kw=_w("break case catch class const continue debugger default delete do else export extends finally for "
              "function if import in instanceof let new of return static super switch this throw try typeof var "
              "void while with yield async await from as implements interface enum type namespace declare "
              "readonly public private protected abstract get set"),
        ty=_JS_TY, const=_w("true false null undefined NaN Infinity"), lc=[r"//"],
        ml=[(r"/\*", "*/", "com"), (r"`", "`", "str")], st=[_STR_DQ, _STR_SQ], extra=[], defs=_w("function class")),
    "json": dict(kw=frozenset(), ty=frozenset(), const=_w("true false null"), lc=[r"//"], ml=[(r"/\*", "*/", "com")],
                 st=[_STR_DQ], extra=[(r'"(?:\\.|[^"\\])*"(?=\s*:)', "attr")], defs=frozenset(), key_first=True),
    "c": dict(
        kw=_w("auto break case const continue default do else enum extern for goto if inline register restrict "
              "return sizeof static struct switch typedef union volatile while"),
        ty=_C_TY, const=_w("true false NULL"), lc=[r"//"], ml=[(r"/\*", "*/", "com")], st=[_STR_DQ, _STR_SQ],
        extra=[(r"^\s*#\s*\w+", "deco")], defs=_w("struct enum union")),
    "cpp": dict(
        kw=_w("alignas auto break case catch class const constexpr continue default delete do else enum explicit "
              "export extern for friend goto if inline namespace new noexcept operator override private protected "
              "public return sizeof static struct switch template this throw try typedef typename union using "
              "virtual volatile while final nullptr"),
        ty=_C_TY, const=_w("true false NULL nullptr"), lc=[r"//"], ml=[(r"/\*", "*/", "com")],
        st=[_STR_DQ, _STR_SQ], extra=[(r"^\s*#\s*\w+", "deco")], defs=_w("class struct enum namespace")),
    "java": dict(
        kw=_w("abstract assert break case catch class const continue default do else enum extends final finally "
              "for goto if implements import instanceof interface native new package private protected public "
              "return static strictfp super switch synchronized this throw throws transient try volatile while var"),
        ty=_C_TY, const=_w("true false null"), lc=[r"//"], ml=[(r"/\*", "*/", "com")], st=[_STR_DQ, _STR_SQ],
        extra=[(r"@\w+", "deco")], defs=_w("class interface enum")),
    "csharp": dict(
        kw=_w("abstract as base break case catch checked class const continue default delegate do else enum event "
              "explicit extern finally fixed for foreach goto if implicit in interface internal is lock namespace "
              "new operator out override params private protected public readonly ref return sealed sizeof static "
              "struct switch this throw try typeof unchecked unsafe using virtual volatile while var async await"),
        ty=_C_TY, const=_w("true false null"), lc=[r"//"], ml=[(r"/\*", "*/", "com")], st=[_STR_DQ, _STR_SQ],
        extra=[(r"^\s*#\s*\w+", "deco")], defs=_w("class struct interface enum namespace")),
    "go": dict(
        kw=_w("break case chan const continue default defer else fallthrough for func go goto if import interface "
              "map package range return select struct switch type var"),
        ty=_w("int int8 int16 int32 int64 uint uint8 uint16 uint32 uint64 float32 float64 string bool byte rune "
              "error any make new len cap append copy delete panic recover print println"),
        const=_w("true false nil iota"), lc=[r"//"], ml=[(r"/\*", "*/", "com"), (r"`", "`", "str")],
        st=[_STR_DQ, _STR_SQ], extra=[], defs=_w("func type")),
    "rust": dict(
        kw=_w("as async await break const continue crate dyn else enum extern fn for if impl in let loop match mod "
              "move mut pub ref return self Self static struct super trait type unsafe use where while"),
        ty=_w("i8 i16 i32 i64 i128 isize u8 u16 u32 u64 u128 usize f32 f64 bool char str String Vec Option Result "
              "Box Rc Arc HashMap HashSet"),
        const=_w("true false None Some Ok Err"), lc=[r"//"], ml=[(r"/\*", "*/", "com")], st=[_STR_DQ],
        extra=[(r"\b\w+!", "deco"), (r"#!?\[[^\]]*\]", "deco")], defs=_w("fn struct enum trait impl mod")),
    "php": dict(
        kw=_w("abstract and array as break callable case catch class clone const continue declare default do echo "
              "else elseif empty enddeclare endfor endforeach endif endswitch endwhile extends final finally fn for "
              "foreach function global if implements include include_once instanceof interface isset list match "
              "namespace new or print private protected public require require_once return static switch throw "
              "trait try unset use var while xor yield"),
        ty=_w("int float string bool array object null mixed void self parent"), const=_w("true false null TRUE FALSE NULL"),
        lc=[r"//", r"#"], ml=[(r"/\*", "*/", "com")], st=[_STR_DQ, _STR_SQ],
        extra=[(r"\$[A-Za-z_]\w*", "var"), (r"<\?php|\?>", "deco")], defs=_w("function class")),
    "shell": dict(
        kw=_w("if then else elif fi for while do done case esac in function select until return exit break continue "
              "local export readonly declare typeset source alias unset trap shift eval exec set"),
        ty=_w("echo cd ls grep sed awk cat rm cp mv mkdir rmdir chmod chown sudo apt pacman git python python3 pip "
              "make test read printf find xargs sort uniq head tail tar curl wget ssh scp kill ps tee touch ln "
              "which dirname basename"),
        const=_w("true false"), lc=[r"(?:(?<=\s)|^)#"], ml=[], st=[_STR_DQ, r"'[^']*(?:'|$)"],
        extra=[(r"\$(?:\w+|\{[^}]*\}|\([^)]*\)|[@#?$!*-])", "var"), (r"^#!.*$", "deco")], defs=frozenset()),
    "sql": dict(
        kw=_w("select from where insert into values update set delete create table alter drop index join inner left "
              "right outer full cross on group by order having limit offset union all distinct as and or not null is "
              "in like between exists case when then else end primary key foreign references default unique check "
              "begin commit rollback view trigger asc desc with returning add column constraint cascade truncate"),
        ty=_w("int integer bigint smallint varchar char text date time timestamp boolean bool float double decimal "
              "numeric serial blob json uuid count sum avg min max coalesce now"),
        const=_w("true false"), lc=[r"--"], ml=[(r"/\*", "*/", "com")], st=[_STR_SQ, _STR_DQ], extra=[],
        defs=frozenset(), ci=True),
    "yaml": dict(kw=frozenset(), ty=frozenset(), const=_w("true false null yes no on off True False Null"),
                 lc=[r"(?:(?<=\s)|^)#"], ml=[], st=[_STR_DQ, _STR_SQ],
                 extra=[(r"^\s*(?:-\s+)?[\w.\-/ ]+?(?=\s*:(?:\s|$))", "attr"), (r"[&*]\w+", "deco"),
                        (r"^---|^\.\.\.", "deco")], defs=frozenset()),
    "ini": dict(kw=frozenset(), ty=frozenset(), const=_w("true false yes no on off"), lc=[r"(?:(?<=\s)|^)[#;]"],
                ml=[], st=[_STR_DQ, _STR_SQ],
                extra=[(r"^\s*\[[^\]]*\]", "tag"), (r"^\s*[\w.\-]+(?=\s*[=:])", "attr")], defs=frozenset()),
    "css": dict(kw=_w("important"), ty=frozenset(), const=frozenset(), lc=[], ml=[(r"/\*", "*/", "com")],
                st=[_STR_DQ, _STR_SQ],
                extra=[(r"@[\w-]+", "deco"), (r"[.#][A-Za-z_][\w-]*(?=[^{;]*\{)", "fn"),
                       (r"::?[a-z-]+(?=[^{;]*\{)", "kw"), (r"(?<=[{;\s])[\w-]+(?=\s*:\s*[^;{}]*[;}])", "attr"),
                       (r"#[0-9a-fA-F]{3,8}\b", "num"), (r"-?\d*\.?\d+(?:px|em|rem|%|vh|vw|pt|cm|mm|s|ms|deg|fr)?", "num"),
                       (r"!\s*important", "kw")], defs=frozenset()),
}
LANGS["css"]["no_words"] = True
LANGS["typescript"] = LANGS["javascript"]

LANG_NAMES = {"python": "Python", "javascript": "JavaScript / TypeScript", "json": "JSON", "html": "HTML / XML",
              "css": "CSS", "c": "C", "cpp": "C++", "java": "Java", "csharp": "C#", "go": "Go", "rust": "Rust",
              "php": "PHP", "shell": "Shell", "sql": "SQL", "yaml": "YAML", "ini": "INI / TOML / Konfiguration",
              "latex": "LaTeX", "text": "Reiner Text"}

EXT_LANG = {}
for _lang, _exts in (("python", "py pyw pyi"), ("javascript", "js mjs cjs jsx ts tsx"),
                     ("json", "json jsonc webmanifest geojson"), ("html", "html htm xhtml svg xml xsl xslt rss plist"),
                     ("css", "css scss less"), ("c", "c h"), ("cpp", "cpp cc cxx hpp hh hxx"), ("java", "java"),
                     ("csharp", "cs"), ("go", "go"), ("rust", "rs"), ("php", "php"),
                     ("shell", "sh bash zsh ksh"), ("sql", "sql"), ("yaml", "yml yaml"),
                     ("ini", "toml ini cfg conf desktop service"), ("latex", "sty cls bib")):
    for _e in _exts.split():
        EXT_LANG["." + _e] = _lang
CODE_EXT = tuple(sorted(EXT_LANG))


def lang_for(path):
    import os
    return EXT_LANG.get(os.path.splitext(path or "")[1].lower(), "text")


class CodeHighlighter(QSyntaxHighlighter):
    """Färbt Programmcode (Sprache nach Dateiendung) und LaTeX; Zustände über mehrere Zeilen für Kommentare
    und mehrzeilige Zeichenketten."""

    def __init__(self, doc=None, dark=False, lang="text"):
        super().__init__(doc)
        self._dark = dark
        self._lang = lang
        self._build()

    def set_dark(self, dark):
        self._dark = dark
        self._build()
        self.rehighlight()

    def set_lang(self, lang):
        if lang != self._lang:
            self._lang = lang
            self._build()
            self.rehighlight()

    def lang(self):
        return self._lang

    def _build(self):
        p = code_palette(self._dark)
        self.f = {k: _fmt(v) for k, v in p.items()}
        for k in ("kw", "sec", "env"):
            self.f[k] = _fmt(p[k], bold=True)
        self.f["com"] = _fmt(p["com"], italic=True)
        self.spec = LANGS.get(self._lang)
        self.rx = None
        if self.spec is None:
            return
        s = self.spec
        parts = []
        for i, (a, _b, _c) in enumerate(s["ml"]):
            parts.append("(?P<ml%d>%s)" % (i, a))
        if s["lc"]:
            parts.append("(?P<lc>%s)" % "|".join(s["lc"]))
        for i, (rx, _c) in enumerate(s["extra"]):
            parts.append("(?P<x%d>%s)" % (i, rx))
        for i, rx in enumerate(s["st"]):
            parts.append("(?P<s%d>%s)" % (i, rx))
        parts.append(r"(?P<num>\b0[xX][0-9a-fA-F_]+\b|\b\d[\d_]*(?:\.\d+)?(?:[eE][+-]?\d+)?\b)")
        if not s.get("no_words"):
            parts.append(r"(?P<word>[A-Za-z_][A-Za-z0-9_]*)")
        self.rx = re.compile("|".join(parts), re.M)
        self._ci = s.get("ci", False)

    # -- Hauptlauf ------------------------------------------------------------------
    def highlightBlock(self, text):
        if self._lang == "latex":
            self._latex(text)
            return
        if self._lang == "html":
            self._html(text)
            return
        if self._lang == "pdf":
            self._pdf(text)
            return
        if self.rx is None:
            self.setCurrentBlockState(0)
            return
        self.setCurrentBlockState(self._run(text, 0, len(text), self.previousBlockState(), self.spec, self.rx))

    def _run(self, text, pos, end, state, spec, rx):
        ml = spec["ml"]
        if state > 0 and state <= len(ml):
            _a, close, col = ml[state - 1]
            k = text.find(close, pos, end)
            if k < 0:
                self.setFormat(pos, end - pos, self.f[col])
                return state
            self.setFormat(pos, k + len(close) - pos, self.f[col])
            pos = k + len(close)
        state = 0
        prev = ""
        defs = spec["defs"]
        ci = spec.get("ci", False)
        while pos < end:
            m = rx.search(text, pos, end)
            if not m:
                break
            g = m.lastgroup
            a, b = m.start(), m.end()
            if g.startswith("ml"):
                i = int(g[2:])
                _s, close, col = ml[i]
                k = text.find(close, b, end)
                if k < 0:
                    self.setFormat(a, end - a, self.f[col])
                    return i + 1
                self.setFormat(a, k + len(close) - a, self.f[col])
                pos = k + len(close)
                prev = ""
                continue
            if g == "lc":
                self.setFormat(a, end - a, self.f["com"])
                return 0
            if g[0] == "x" and g[1:].isdigit():
                self.setFormat(a, b - a, self.f[spec["extra"][int(g[1:])][1]])
            elif g[0] == "s" and g[1:].isdigit():
                self.setFormat(a, b - a, self.f["str"])
            elif g == "num":
                self.setFormat(a, b - a, self.f["num"])
            elif g == "word":
                w = m.group()
                key = w.lower() if ci else w
                if key in spec["kw"]:
                    self.setFormat(a, b - a, self.f["kw"])
                elif w in spec["const"] or key in spec["const"]:
                    self.setFormat(a, b - a, self.f["const"])
                elif key in spec["ty"]:
                    self.setFormat(a, b - a, self.f["ty"])
                elif prev in defs:
                    self.setFormat(a, b - a, self.f["fn"])
                elif b < end and text[b] == "(":
                    self.setFormat(a, b - a, self.f["fn"])
                prev = key
                pos = b
                continue
            prev = ""
            pos = b if b > a else a + 1
        return state

    # -- HTML und XML ------------------------------------------------------------------
    _HTML_TAG = re.compile(r"</?[A-Za-z][\w:.-]*|/?>")
    _HTML_ATTR = re.compile(r"""([\w:@.-]+)(\s*=\s*)("[^"]*"?|'[^']*'?|[^\s"'>]+)?""")

    def _html(self, text):
        state = self.previousBlockState()          # 0 Text, 1 Kommentar, 100 in script, 101 in style
        n = len(text)
        pos = 0
        if state == 1:
            k = text.find("-->")
            if k < 0:
                self.setFormat(0, n, self.f["com"])
                self.setCurrentBlockState(1)
                return
            self.setFormat(0, k + 3, self.f["com"])
            pos = k + 3
            state = 0
        while pos < n:
            if state in (100, 101):
                close = "</script" if state == 100 else "</style"
                k = text.lower().find(close, pos)
                end = n if k < 0 else k
                sub = LANGS["javascript"] if state == 100 else LANGS["css"]
                self._run(text, pos, end, 0, sub, self._sub_rx(state))
                if k < 0:
                    self.setCurrentBlockState(state)
                    return
                pos = k
                state = 0
            i = text.find("<", pos)
            if i < 0:
                break
            if text.startswith("<!--", i):
                k = text.find("-->", i + 4)
                if k < 0:
                    self.setFormat(i, n - i, self.f["com"])
                    self.setCurrentBlockState(1)
                    return
                self.setFormat(i, k + 3 - i, self.f["com"])
                pos = k + 3
                continue
            if text.startswith("<!", i) or text.startswith("<?", i):
                k = text.find(">", i)
                k = n if k < 0 else k + 1
                self.setFormat(i, k - i, self.f["deco"])
                pos = k
                continue
            m = self._HTML_TAG.match(text, i)
            if not m:
                pos = i + 1
                continue
            self.setFormat(m.start(), m.end() - m.start(), self.f["tag"])
            name = m.group().lstrip("</").lower()
            p = m.end()
            # Attribute bis zum Ende des Tags
            while p < n:
                while p < n and text[p] in " \t":
                    p += 1
                if p >= n:
                    break
                if text[p] == ">" or text.startswith("/>", p):
                    e = p + (2 if text[p] == "/" else 1)
                    self.setFormat(p, e - p, self.f["tag"])
                    p = e
                    if m.group()[1] != "/" and name in ("script", "style") and not text.startswith("/>", p - 2):
                        state = 100 if name == "script" else 101
                    break
                am = self._HTML_ATTR.match(text, p)
                if not am:
                    p += 1
                    continue
                self.setFormat(am.start(1), am.end(1) - am.start(1), self.f["attr"])
                if am.group(3):
                    self.setFormat(am.start(3), am.end(3) - am.start(3), self.f["str"])
                p = am.end()
            pos = p
        # Entitäten
        for m in re.finditer(r"&#?\w+;", text):
            self.setFormat(m.start(), m.end() - m.start(), self.f["const"])
        self.setCurrentBlockState(state)

    _sub_cache = {}

    def _sub_rx(self, state):
        key = (state, self._dark)
        if key not in self._sub_cache:
            sp = LANGS["javascript"] if state == 100 else LANGS["css"]
            parts = []
            for i, (a, _b, _c) in enumerate(sp["ml"]):
                parts.append("(?P<ml%d>%s)" % (i, a))
            if sp["lc"]:
                parts.append("(?P<lc>%s)" % "|".join(sp["lc"]))
            for i, (rx, _c) in enumerate(sp["extra"]):
                parts.append("(?P<x%d>%s)" % (i, rx))
            for i, rx in enumerate(sp["st"]):
                parts.append("(?P<s%d>%s)" % (i, rx))
            parts.append(r"(?P<num>\b\d[\d_]*(?:\.\d+)?\b)")
            if not sp.get("no_words"):
                parts.append(r"(?P<word>[A-Za-z_][A-Za-z0-9_]*)")
            self._sub_cache[key] = re.compile("|".join(parts), re.M)
        return self._sub_cache[key]

    # -- PDF-Quelltext ----------------------------------------------------------------
    _PDF_OPS = re.compile(r"(?<![\w*])(?:BT|ET|Tf|Tj|TJ|Td|TD|Tm|T\*|Tc|Tw|TL|Tr|Ts|Tz|re|f\*?|S|s|B\*?|b\*?|n|W\*?|"
                          r"cm|q|Q|m|l|c|v|y|h|g|G|rg|RG|k|K|cs|CS|sc|scn|SC|SCN|Do|gs|w|J|j|M|d|ri|i|sh|BI|ID|EI)(?![\w*])")
    _PDF_STR = re.compile(r"\((?:\\.|[^\\)])*\)|<[0-9A-Fa-f\s]*>(?!<)")
    _PDF_NAME = re.compile(r"/[^\s/\[\]<>()%]+")
    _PDF_NUM = re.compile(r"(?<![\w.])[-+]?\d*\.?\d+(?![\w.])")

    def _pdf(self, text):
        f = self.f
        state = self.previousBlockState()          # 0 Objekte, 1 in einem Datenstrom
        st = text.strip()
        if state == 1:
            if st.startswith("endstream"):
                self.setFormat(0, len(text), f["kw"])
                self.setCurrentBlockState(0)
                return
            if len(st) > 40 and re.fullmatch(r"[0-9A-Fa-f\s]+", st):
                self.setFormat(0, len(text), f["com"])     # Hex-Block (Bild, Schrift): zurückgenommen
                self.setCurrentBlockState(1)
                return
            body = text
            cpos = len(text)
            m = re.search(r"(?<!\\)%", text)
            if m:
                cpos = m.start()
                body = text[:cpos]
            for m in self._PDF_NUM.finditer(body):
                self.setFormat(m.start(), m.end() - m.start(), f["num"])
            for m in self._PDF_OPS.finditer(body):
                self.setFormat(m.start(), m.end() - m.start(), f["kw"])
            for m in self._PDF_NAME.finditer(body):
                self.setFormat(m.start(), m.end() - m.start(), f["attr"])
            for m in self._PDF_STR.finditer(body):
                self.setFormat(m.start(), m.end() - m.start(), f["str"])
            if cpos < len(text):
                self.setFormat(cpos, len(text) - cpos, f["com"])
            self.setCurrentBlockState(1)
            return
        if st.startswith("%"):
            self.setFormat(0, len(text), f["com"])
            self.setCurrentBlockState(0)
            return
        for m in self._PDF_NUM.finditer(text):
            self.setFormat(m.start(), m.end() - m.start(), f["num"])
        for m in re.finditer(r"\b\d+\s+\d+\s+R\b", text):
            self.setFormat(m.start(), m.end() - m.start(), f["fn"])
        for m in self._PDF_NAME.finditer(text):
            self.setFormat(m.start(), m.end() - m.start(), f["attr"])
        for m in self._PDF_STR.finditer(text):
            self.setFormat(m.start(), m.end() - m.start(), f["str"])
        for m in re.finditer(r"<<|>>|[\[\]]", text):
            self.setFormat(m.start(), m.end() - m.start(), f["op"])
        for m in re.finditer(r"\b(?:true|false|null)\b", text):
            self.setFormat(m.start(), m.end() - m.start(), f["const"])
        for m in re.finditer(r"\b\d+\s+\d+\s+obj\b|\bendobj\b|^\s*stream\s*$|\bxref\b|\btrailer\b|\bstartxref\b", text):
            self.setFormat(m.start(), m.end() - m.start(), f["sec"])
        self.setCurrentBlockState(1 if re.match(r"^\s*stream\s*$", text) else 0)

    # -- LaTeX ------------------------------------------------------------------------
    _TEX_SEC = re.compile(r"\\(?:part|chapter|(?:sub){0,2}section|paragraph|subparagraph)\*?")
    _TEX_DECL = re.compile(r"\\(?:documentclass|usepackage|RequirePackage|input|include|includegraphics|"
                           r"newcommand|renewcommand|providecommand|newenvironment|def|let|usetikzlibrary|"
                           r"geometry|bibliography|bibliographystyle|label|ref|cite|pagestyle|setlength)\b")

    def _latex(self, text):
        f = self.f
        state = self.previousBlockState()       # 0 normal, 1 in Formelumgebung \[ \] oder $$ $$
        n = len(text)
        # Kommentar bestimmen (erstes nicht maskiertes Prozentzeichen)
        cpos = n
        for m in re.finditer(r"(?<!\\)(?:\\\\)*%", text):
            cpos = m.end() - 1
            break
        body = text[:cpos]
        for m in re.finditer(r"\\[A-Za-z@]+\*?|\\.", body):
            self.setFormat(m.start(), m.end() - m.start(), f["fn"])
        for m in self._TEX_DECL.finditer(body):
            self.setFormat(m.start(), m.end() - m.start(), f["deco"])
        for m in self._TEX_SEC.finditer(body):
            self.setFormat(m.start(), m.end() - m.start(), f["sec"])
        for m in re.finditer(r"[{}\[\]()]", body):
            self.setFormat(m.start(), 1, f["op"])
        for m in re.finditer(r"(?<![\\\w])\d+(?:[.,]\d+)?", body):
            self.setFormat(m.start(), m.end() - m.start(), f["num"])
        for m in re.finditer(r"(?<!\\)[&~]|\\\\", body):
            self.setFormat(m.start(), m.end() - m.start(), f["const"])
        for m in re.finditer(r"\\(?:begin|end)\s*\{[^}]*\}", body):
            self.setFormat(m.start(), m.end() - m.start(), f["env"])
        # Formeln: $…$, $$…$$, \(…\), \[…\] (mehrzeilig nur für \[ \] und $$ $$)
        pos = 0
        while pos < len(body):
            if state in (1, 2):
                k = body.find("$$", pos) if state == 1 else body.find("\\]", pos)
                end = len(body) if k < 0 else k + 2
                self.setFormat(pos, end - pos, f["math"])
                if k < 0:
                    self.setCurrentBlockState(state)
                    return
                state = 0
                pos = end
                continue
            m = re.compile(r"\$\$|(?<!\\)\$|\\\(|\\\[").search(body, pos)
            if not m:
                break
            op = m.group()
            if op in ("$$", "\\["):
                close = "$$" if op == "$$" else "\\]"
                k = body.find(close, m.end())
                end = len(body) if k < 0 else k + 2
                self.setFormat(m.start(), end - m.start(), f["math"])
                if k < 0:
                    self.setCurrentBlockState(1 if close == "$$" else 2)
                    return
                pos = end
            else:
                close = {"$": "$", "\\(": "\\)"}[op]
                k = body.find(close, m.end())
                end = len(body) if k < 0 else k + len(close)
                self.setFormat(m.start(), end - m.start(), f["math"])
                pos = end
        if cpos < n:
            self.setFormat(cpos, n - cpos, f["com"])
        self.setCurrentBlockState(0)

