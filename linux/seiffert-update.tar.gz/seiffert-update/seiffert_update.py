#!/usr/bin/env python3
"""Seifferts Update: installiert alle Seiffert-Programme mit einem Befehl.

Lege die jeweils aktuellen Archive (.tar.gz) in den Sammelordner (Standard ~/Seiffert-Archive)
und rufe  seiffert-update  auf. Pro Programm zählt das neueste Archiv; unveränderte Archive
(gleiche Prüfsumme wie bei der letzten Installation) werden übersprungen.
Nur Standardbibliothek, läuft mit dem python3 des Systems.
"""
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
from pathlib import Path, PurePosixPath

VERSION = "1.0"
ENDUNGEN = (".tar.gz", ".tgz", ".tar.xz", ".txz", ".tar.bz2", ".tbz2", ".tar")
MAX_BYTES = 2 * 1024 ** 3


def standard_ordner():
    return Path(os.environ.get("SEIFFERT_ARCHIVE") or (Path.home() / "Seiffert-Archive"))


def stand_datei():
    basis = Path(os.environ.get("XDG_DATA_HOME") or (Path.home() / ".local" / "share"))
    return basis / "seiffert-update" / "stand.json"


def lade_stand():
    try:
        d = json.loads(stand_datei().read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def speichere_stand(stand):
    pfad = stand_datei()
    pfad.parent.mkdir(parents=True, exist_ok=True)
    tmp = pfad.with_name(pfad.name + ".tmp")
    tmp.write_text(json.dumps(stand, indent=1, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, pfad)


def programmname(datei):
    """seiffert-zeit-2.8 (1).tar.gz -> seiffert-zeit. Kein Archiv: None."""
    n = re.sub(r"\s*\([^)]*\)", "", datei)  # " (1)", " (dcaf9136)" vom Herunterladen
    for e in ENDUNGEN:
        if n.lower().endswith(e):
            n = n[: -len(e)]
            break
    else:
        return None
    n = re.sub(r"[-_ ]+\d{4}-\d{2}-\d{2}.*$", "", n)       # Datum am Ende
    n = re.sub(r"[-_ ]+v?\d+(\.\d+)*$", "", n)               # Versionsnummer am Ende
    n = n.strip(" -_.").lower()
    return n or None


def sammle(ordner):
    """-> (nehmen: {name: Pfad}, aeltere: [Pfad])"""
    gruppen = {}
    for p in ordner.iterdir():
        if p.name.startswith(".") or not p.is_file():
            continue
        name = programmname(p.name)
        if name:
            gruppen.setdefault(name, []).append(p)
    nehmen, aeltere = {}, []
    for name, liste in gruppen.items():
        liste.sort(key=lambda p: (p.stat().st_mtime, p.name))
        nehmen[name] = liste[-1]
        aeltere.extend(liste[:-1])
    return nehmen, aeltere


def reihenfolge(name):
    # Seifferts Dateien enthält Starter, Terminal und Oberfläche und kommt deshalb zuerst.
    return (0 if "dateien" in name else 1, name)


def sha256(pfad):
    h = hashlib.sha256()
    with open(pfad, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def sicher_auspacken(archiv, ziel):
    """Packt aus; lehnt Pfade nach außen, Verweise, Gerätedateien und überlange Inhalte ab."""
    ziel_real = os.path.realpath(ziel)
    with tarfile.open(archiv) as tf:
        mitglieder = tf.getmembers()
        gesamt = 0
        for m in mitglieder:
            p = PurePosixPath(m.name)
            if p.is_absolute() or ".." in p.parts or m.name.startswith("\\"):
                raise ValueError("Pfad nach außen: " + m.name)
            if m.issym() or m.islnk():
                raise ValueError("Verweis nicht erlaubt: " + m.name)
            if not (m.isfile() or m.isdir()):
                raise ValueError("Sonderdatei nicht erlaubt: " + m.name)
            ziel_pfad = os.path.realpath(os.path.join(ziel_real, m.name))
            if ziel_pfad != ziel_real and not ziel_pfad.startswith(ziel_real + os.sep):
                raise ValueError("Pfad nach außen: " + m.name)
            gesamt += max(m.size, 0)
            if gesamt > MAX_BYTES:
                raise ValueError("Archiv entpackt zu groß")
        if hasattr(tarfile, "data_filter"):
            tf.extractall(ziel_real, members=mitglieder, filter="data")
        else:
            tf.extractall(ziel_real, members=mitglieder)


def paketordner(ziel):
    ziel = Path(ziel)
    if (ziel / "install.sh").is_file():
        return ziel
    kandidaten = [k for k in ziel.iterdir() if k.is_dir() and (k / "install.sh").is_file()]
    return kandidaten[0] if len(kandidaten) == 1 else None


def paketversion(ordner):
    dateien = sorted(Path(ordner).glob("*.py"), key=lambda p: (p.name != "backend.py", p.name))
    for p in dateien:
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        m = re.search(r'^VERSION\s*=\s*["\']([^"\']+)["\']', text, re.M)
        if m:
            return m.group(1)
    return "?"


def installiere(archiv, extra):
    """-> (ok, Version, Meldung)"""
    tmp = tempfile.mkdtemp(prefix="seiffert-update-")
    try:
        try:
            sicher_auspacken(archiv, tmp)
        except tarfile.ReadError:
            return False, "?", "kein lesbares Archiv (beschädigt oder unvollständig geladen?)"
        except (tarfile.TarError, ValueError, OSError) as e:
            return False, "?", "Auspacken abgelehnt: %s" % e
        wurzel = paketordner(tmp)
        if wurzel is None:
            return False, "?", "kein install.sh im Archiv gefunden"
        version = paketversion(wurzel)
        try:
            r = subprocess.run(["sh", "install.sh"] + list(extra), cwd=str(wurzel),
                               stdin=subprocess.DEVNULL, timeout=900)
        except (OSError, subprocess.TimeoutExpired) as e:
            return False, version, "install.sh nicht ausgeführt: %s" % e
        if r.returncode != 0:
            return False, version, "install.sh endete mit Code %d" % r.returncode
        return True, version, ""
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


HILFE = """Seifferts Update %s

  seiffert-update [ORDNER] [Optionen] [-- Optionen für install.sh]

Installiert die neuesten Archive aus dem Sammelordner (Standard %s,
änderbar mit ORDNER oder der Umgebungsvariablen SEIFFERT_ARCHIVE).
Pro Programm zählt das neueste Archiv (Namen wie seiffert-zeit-2.8 (1).tar.gz gehören zu seiffert-zeit).
Archive, die sich seit der letzten Installation nicht geändert haben, werden übersprungen.

  -n, --trocken     nur anzeigen, was geschehen würde
  -f, --erzwingen   auch unveränderte Archive neu installieren
  -l, --liste       Sammelordner und letzten Stand anzeigen
  -h, --hilfe       diese Hilfe

Beispiel:  seiffert-update -- --surface   (reicht --surface an jedes install.sh weiter)
"""


def main(argv):
    extra = []
    if "--" in argv:
        i = argv.index("--")
        argv, extra = argv[:i], argv[i + 1:]
    trocken = erzwingen = liste = False
    ordner = None
    for a in argv:
        if a in ("-h", "--hilfe", "--help"):
            print(HILFE % (VERSION, standard_ordner()))
            return 0
        elif a in ("-n", "--trocken"):
            trocken = True
        elif a in ("-f", "--erzwingen"):
            erzwingen = True
        elif a in ("-l", "--liste"):
            liste = True
        elif a.startswith("-"):
            print("Unbekannte Option %s. Hilfe: seiffert-update --hilfe" % a, file=sys.stderr)
            return 2
        elif ordner is None:
            ordner = Path(a).expanduser()
        else:
            print("Nur ein Ordner erlaubt.", file=sys.stderr)
            return 2
    ordner = ordner or standard_ordner()
    if not ordner.is_dir():
        if trocken or liste:
            print("Sammelordner %s gibt es nicht." % ordner)
            return 1
        ordner.mkdir(parents=True, exist_ok=True)
        print("Sammelordner %s angelegt. Lege die Archive (.tar.gz) hinein und rufe seiffert-update erneut auf." % ordner)
        return 0
    nehmen, aeltere = sammle(ordner)
    if not nehmen:
        print("Keine Archive in %s gefunden." % ordner)
        return 1
    stand = lade_stand()
    zeilen, fehler = [], 0
    for name in sorted(nehmen, key=reihenfolge):
        pfad = nehmen[name]
        pruefsumme = sha256(pfad)
        alt = stand.get(name, {})
        gleich = alt.get("sha256") == pruefsumme
        if liste:
            letzte = alt.get("datum", "noch nie installiert")
            print("%-24s %-40s Version %-6s zuletzt: %s%s" % (
                name, pfad.name, alt.get("version", "?"), letzte,
                "  (unverändert)" if gleich else "  (neu oder geändert)"))
            continue
        if gleich and not erzwingen:
            zeilen.append("%-24s unverändert, übersprungen" % name)
            continue
        if trocken:
            zeilen.append("%-24s würde installiert (%s)" % (name, pfad.name))
            continue
        print("== %s (%s) ==" % (name, pfad.name), flush=True)
        ok, version, meldung = installiere(pfad, extra)
        if ok:
            stand[name] = {"sha256": pruefsumme, "datei": pfad.name, "version": version,
                           "datum": time.strftime("%d.%m.%Y %H:%M")}
            speichere_stand(stand)
            zeilen.append("%-24s installiert, Version %s" % (name, version))
        else:
            fehler += 1
            zeilen.append("%-24s FEHLER: %s" % (name, meldung))
    if liste:
        return 0
    for p in aeltere:
        zeilen.append("%-24s ältere Fassung ignoriert" % p.name)
    print("\nErgebnis:")
    for z in zeilen:
        print("  " + z)
    if fehler:
        print("\n%d Programm(e) nicht installiert, siehe oben." % fehler)
    return 1 if fehler else 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except KeyboardInterrupt:
        sys.exit(130)
